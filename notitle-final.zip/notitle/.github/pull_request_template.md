## What changed

Describe the user-visible and architectural change.

## Security and privacy

- [ ] No secrets or sensitive data are logged.
- [ ] New external input has validation and appropriate size/rate limits.
- [ ] Authorization impact was reviewed.
- [ ] Durable data additions have a documented purpose and retention need.
- [ ] No chat/voice content was added to analytics or general logs.

## Reliability

- [ ] Failure and timeout behavior is defined.
- [ ] Resource use is bounded.
- [ ] Database changes use a new migration.
- [ ] Rollback/compatibility impact was considered.

## Verification

- [ ] Unit/integration tests added or updated.
- [ ] Race-sensitive Go paths were tested with `-race`.
- [ ] Frontend type/lint/build checks pass.
- [ ] Smartphone behavior was checked at supported widths.
