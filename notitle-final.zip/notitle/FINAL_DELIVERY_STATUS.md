# Final cumulative source handover

Date: 2026-10-09 UTC / 2026-10-10 IST. Business baseline: finalized NoTitle V3.2. Read [START_HERE.md](START_HERE.md) first. This record supersedes earlier phase status descriptions for this delivery; it does not retroactively turn pending tests into passes.

**The entire cumulative Phases 1–10 source is included. It is not yet a production-validated release.** No live infrastructure, domain, merchant activation, operator appointment, outgoing notification, live charge/refund or public launch was performed. The archive contains source and deployment/test tools, not compiled binaries, installed dependencies, credentials or completed approvals.

## Final handover contents

- `START_HERE.md`: Windows/WSL2 and Linux prerequisites; checksum/extraction; authentic dependency preparation; local dev/static startup; real user journeys; test sequence; troubleshooting and maintenance.
- `docs/FINAL_ENVIRONMENT_REFERENCE.md`: all 73 backend settings, 70 distinct host Compose inputs, frontend/build/relay variables, secret file formats, ownership and provisioning. The inventories were checked against the supplied source and templates.
- `docs/FINAL_DEPLOYMENT_GUIDE.md`: two-host deployment, immutable candidate builds, DNS/TLS/private access, exact Compose ordering, schema 9, operator/policy installation, real recovery/monitoring setup, isolated acceptance, restricted production validation, cohort/public launch and rollback.
- `docs/FINAL_PAYMENT_GUIDE.md`: Cashfree sandbox/live account setup, file-backed credentials, server/frontend configuration, reviewed immutable catalog publication, webhook/SDK integration, sandbox verification, audited refunds, settlement/reconciliation and rotation.
- The cumulative Go/TypeScript/SQL application, responsive web assets, migrations, test suites, CI, Docker/Caddy/coturn definitions and Phase 1–10 contracts/runbooks. All 582 source files from the preceding Phase 10 ZIP are retained.

The finalized business features, matching rules, user roles and workflows remain unchanged. Mobile is the priority, with desktop feature parity. The requirement remains **200 connected participants including 25 simultaneous two-person calls and up to 100 waiting participants**; calling/waiting users are subsets of the connected total. Capacity has not been measured here.

## Corrections made during final review

1. Cashfree's signed webhook endpoint now acknowledges a committed durable inbox item with **HTTP 200**, matching the documented provider retry contract. It still refuses to acknowledge failed ingestion. The focused test tracks actual response writes so the default 200 of Go's response recorder cannot conceal an early acknowledgement. OpenAPI and provider notes agree.
2. Operations configuration compares key/journal paths with the other features' **effective defaults**. Omitting an environment variable cannot bypass the independent report/MFA encryption-key and deletion/hold-journal checks. Six default/explicit alias regression cases were added.
3. Payment setup now requires cumulative schema **9**, not the historical schema 7. Reviewed immutable catalog/legal data publication is distinguished from a new schema migration, which would require updated code/readiness/evidence bindings.
4. Production instructions now require owner-only secret files and actual container-user readability; the incompatible 0444 suggestion was removed. Local bootstrap's protected development workflow remains separate.
5. The pgBackRest template uses the actual PostgreSQL 18 data path and explicitly requires a reviewed backup role/image/overlay. A configuration example is not an installed backup service. The deployment order keeps the initial base closed until full-feature prerequisites and acceptance are ready.
6. Fresh local startup explicitly completes private-key initialization before starting the API with dependency startup disabled. Failure of initialization stops startup. Behavioral orchestration fixtures exercise development/static ordering and failure handling; they do not run Docker.
7. PostgreSQL role bootstrap reads its password values into psql through short-lived scoped environment variables rather than putting them in command arguments. SQL literal quoting and separate role privileges are preserved. Its fixture does not substitute for running real PostgreSQL initialization.
8. The final deployment guide includes a clean release export that preserves genuine locks and source modes while excluding development secrets/output, and a separate staging TLS path compatible with the actual staging entrypoint. Production-origin certificate configuration is not falsely presented as staging certificate issuance.

## Checks actually executed in this delivery

| Check | Result and boundary |
| --- | --- |
| `./scripts/phase10-source-check.sh` | **216 JavaScript tests passed**, zero failures/skips; **12 Python fixture tests passed**. Output is `docs/final-source-check.txt`. These include five startup/password-boundary fixtures using mocked Docker/psql, not those actual services. |
| Source credential/direct-version audit | Passed as part of that command. Bounded pattern scanning is not comprehensive security certification. |
| Shell/config syntax | All 24 supplied shell scripts passed `bash -n`; all 19 JSON and 12 YAML files parsed. New guide Bash examples were syntax-checked, not executed against a host. |
| API contract | 49 public paths, 54 unique operation IDs and 333 resolving local references. Cashfree success response is 200, with no stale 204 response in that endpoint contract. |
| Cumulative preservation | All 582 previous Phase 10 archive files retained. Final packaging separately checks entry integrity, secret/output exclusions and byte equality with the reviewed working tree. |
| `node scripts/audit.mjs --release` | **Blocked**, exit 1: authentic `server/go.sum` and `web/package-lock.json` are missing. |
| `./scripts/verify.sh` | **Blocked**, exit 1: Docker/Compose is unavailable in this workspace. It did not run its runtime suite. |
| New Go changes | Reviewed and regression tests authored; **not compiled or executed**. |

The workspace has Node 24 and Python 3.11. It lacks Go/gofmt, Docker/Compose and PostgreSQL tools; approved Go/npm registry requests returned HTTP 403. No transitive locks, checksum entries, image digests, compilation results, scan results or benchmark reports were fabricated. The SHA-256 delivered beside the ZIP is calculated from the actual archive bytes; it is unrelated to dependency verification or release approval.

## Work required before production launch

1. **Prepare and verify the actual release.** On an equipped host run `./scripts/bootstrap.sh prepare`; review genuine lockfiles, Go module changes and formatter output. Run `./scripts/verify.sh` and resolve all failures, including Go build/vet/race, real SQL/migrations/roles, Svelte checks/build, browsers and security scans. Freeze and fingerprint the resulting source, then build/scan digest-pinned images.
2. **Configure the actual operating environment.** Supply real domain/TLS/private administration, independent production secrets, reviewed policy/catalog/retention versions, actual merchant acceptance, trained primary/backup coverage and monitored notification receivers. The package does not create these external accounts/services.
3. **Install and prove recovery.** Complete the reviewed backup-capable PostgreSQL image/overlay, WAL scheduling, encrypted off-host storage and independent deletion/hold journal/key recovery. These are supplied as procedures/templates and still require environment-specific implementation and a real restore drill. Prove RPO/RTO and external host-loss detection.
4. **Run actual product acceptance.** Test all features, physical mobile and desktop browsers, real relay media/revocation, both six-hour 200/25 workloads, overload, dense friendship load and concurrent financial/safety/privacy/backup work. The proposed 4-GiB app and 1-GiB TURN hosts are unbenchmarked budgets; resize and retest if necessary.
5. **Complete payment acceptance.** Run real Cashfree sandbox callbacks/captures/refunds and reconcile exact ledger outcomes. Confirm the merchant's invoice/credit-note arrangement and the documented later-refund procedure for annual sales. No Payouts or automatic bank-transfer fallback is implemented. After prior bounded authorization, obtain genuine live capture/refund/settlement/bank evidence through restricted production validation.
6. **Open deliberately.** Record all current candidate-bound acceptance and named approvals, install the matching permit and open a supervised cohort through private owner MFA. Review a complete operating cycle before public expansion. Production starts closed; configuration files and source tests cannot authorize public launch.

Remaining compile/runtime defects, provider behavior and performance limits may emerge in those unexecuted gates. The source handover makes the implementation and completion path available; it cannot honestly certify a secure, high-performance production service before those checks pass.
