# Phase 6 source delivery

Date: 2026-10-09. Baseline: NoTitle V1 final implementation blueprint V3.2 and the cumulative Phase 5 source. This package contains Phases 1–6; earlier status records remain historical evidence.

**Implemented in source; runtime and production acceptance remain pending.** No public deployment, payment activation, real operator provisioning or additional paid provider was performed.

## Included

- Stay Connected for every guest/account pairing, with two affirmative consents, reciprocal-request deduplication, private refusal and withdrawal. Requests are scoped to the current interaction and cannot be reopened to repeatedly prompt the recipient.
- Temporary guest relationships survive refresh and brief disconnect under the same identity, without extending guest lifetime. Ending either guest identity or restarting the process removes them. Registration preserves accepted consent; unrelated account login does not import guest relationships.
- Normalized durable account friendships with consent timestamps, owner-scoped opaque handles, bounded admission and private online/busy/offline availability. No public account lookup, presence history or offline invitation queue.
- Online text invitations expire after 30 seconds and require explicit acceptance by an available friend. Random and friend conversations share one coordinator and allocator, so a busy interaction cannot be interrupted or overlapped. Audio invitations remain unavailable until Phase 7.
- Remove cancels invitations and ends active friend conversations. Block also installs the reciprocal safety barrier; unblock never restores a friendship. Deletion and stale-write protections invalidate revoked relationships. Temporary moderation restrictions suppress communication/presence without deleting accepted friends.
- Migration 6 adds one durable friendship table and account revision fences, with atomic block/deletion cleanup and explicit runtime privileges. Readiness requires schema 6; the isolated database gate inventories 21 durable tables and reverses/reapplies all migrations.
- Mobile-first `/friends`, live conversation consent controls, global invitation prompts and desktop parity. SPA navigation keeps the shared socket. Friend actions do not disable Next/End.
- Existing static Caddy frontend, single Go owner/API and PostgreSQL instance are retained. New feature flags, OpenAPI/protocol documentation, regression tests and a real HTTP/WebSocket smoke suite are included.

## Executed evidence

| Check | Actual outcome |
| --- | --- |
| `./scripts/phase6-source-check.sh` | **92 passed, 0 failed, 0 skipped:** 89 frontend Node tests and 3 deployment/source tests. Output: `docs/phase6-source-check.txt`. |
| Source credential-pattern/direct-version audit | Passed; this is not a comprehensive security scan. |
| TypeScript/Svelte script syntax | 70 executable source/test script sections parsed after type stripping. No Svelte compilation, import resolution or typecheck claim. |
| Shell/JSON/YAML syntax | 20 shell scripts passed `bash -n`; 7 JSON and 8 YAML files parsed. This does not validate Docker Compose runtime behavior. |
| Public OpenAPI | 26 paths, 30 unique operation IDs; all 158 local references resolve. Private moderation is excluded. |
| `./scripts/verify.sh` | Stopped because Docker/Compose is unavailable. |
| `node scripts/audit.mjs --release` | Failed as intended: authentic `web/package-lock.json` and `server/go.sum` are absent. |
| Go/PostgreSQL/browser execution | Not run. Go, gofmt, Docker and psql are unavailable; frontend dependencies and browsers are not installed. |

New authored tests include 15 coordinator/review regressions, 10 friends service tests, 9 PostgreSQL integration tests, protocol/HTTP/configuration/authorization checks and 9 Playwright cases. The full-stack smoke covers real cookie/CSRF/socket boundaries, mutual consent, private refusal, invitations, busy races, promotion, removal and blocking. These unexecuted tests are acceptance work to run, not passing evidence.

## Acceptance and operating limits

On a supported Docker host, run `./scripts/bootstrap.sh prepare`, review genuine dependency locks and formatting, then run `./scripts/verify.sh`. Resolve every compiler, race, database, security, Svelte and browser failure before enabling a deployed candidate. Complete `docs/phase6-acceptance.md` together with the preceding safety, identity and release gates. `FRIENDS_ENABLED` defaults off in staging/production and requires safety.

For guest registration, each newly registered endpoint's actual friendship revision is captured only after safety handoff through fresh trusted authorization. Closing before that authorization leaves accepted consent pending in RAM until a later authorization. An already registered peer can remain offline or logged out. The UI announces durable storage only after commit; a restart loses unpublished temporary consent.

Account-wide revision fences intentionally favor removal safety. An unrelated Remove/Block on either endpoint can invalidate an unpublished accepted connection; clients receive removal and must give fresh mutual consent. Already committed unrelated friendships are retained. The implementation never blindly refreshes a stale accepted revision, which could restore withdrawn consent after a delayed write or restart. A finer-grained revision design requires separate race analysis and tests.

The bounded local cache supports 20,000 relationships, with up to 100 per identity and a configurable lower new-admission cap. Presence frames are coalesced, but whole-graph maintenance still runs during owner turns. The dense 200-connected-user / 100-distinct-offline-friends-per-user regression checks structural bounds only. Measure sustained typing and receipt traffic, actor latency, allocations and peak RSS on the intended host before accepting performance. Resource limits remain provisional.

The required full-V1 minimum is **200 connected participants and 25 simultaneous two-person calls**. This delivery does not activate audio or establish measured capacity. Single-owner restarts interrupt live interactions; durable account friendships survive. Keep one API replica until a reviewed architecture change.

Additional provider subscriptions for Phase 6: **₹0/month and ₹0/year**, assuming measured headroom on the existing host. Existing hosting, backups, bandwidth and human moderation remain operating costs. No new recurring service was added.

Start with `README.md`, `docs/phase6-protocol.md` and `docs/phase6-acceptance.md`.
