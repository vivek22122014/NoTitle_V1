# NoTitle engineering instructions

Read README.md and docs/phase1-acceptance.md through docs/phase10-acceptance.md before changes. The authoritative business baseline is blueprint V3.2.

- Preserve mobile-first responsive behavior, desktop feature parity and the 200-connected/25-call minimum.
- One Go coordinator owns live state. Do not add a second app replica, Redis or a managed messaging service without an explicit architecture decision.
- Never log credentials, message content, query strings, raw user paths, cookies or recovery codes.
- Runtime database credentials must not own schemas or run migrations.
- No outgoing user-email provider, paid monitoring service or permanent staging subscription is required.
- Keep ordinary chat and temporary guest state out of PostgreSQL and browser persistence.
- Use the documented verification commands. Report unexecuted checks honestly.
- Never fabricate dependency locks, checksums, test results or benchmark capacity.
- Public SEO uses an explicit route allowlist. Unsupported URLs return404; private application paths remain noindex and outside the sitemap.
- Draft policies are local/controlled previews. Production requires approved actual operator, grievance, tax and privacy values tied to the reviewed content.
- The design-preview route is a development-only simulation. It must not request network, storage or microphone access, or imply that business features are active.
- Source archive delivery must exclude local secrets, dependency folders, binaries, generated bundles, logs and private environment files.


- Identity mutations must recheck session, generation, expiry and profile version inside the transaction. Never serialize storage records.
- Preserve deletion journal durability and startup replay. Never put its volume inside ordinary database rollback.
- Realtime tickets and resume secrets stay in memory and never enter URLs, browser storage or logs. Only the coordinator mutates participant, queue and interaction ownership.
- Trusted server authorization controls entitlements and safety. Never add a public Premium fixture or accept client-selected peer identities.
- Preserve strict mutual gender constraints and the single pool. Professional relevance never delays matching or partitions candidates.

- Text is escaped plain text only. Never persist ordinary transcripts or accept client-supplied transcript evidence. Report selection references the owner-frozen server buffer.
- All existing durable blocks/restrictions and pending handoff fences must stay authoritative even when text/report UI is disabled.
- Private moderation has separate operator identities, MFA and host-only cookies. Public routes must never mount its handler.
- Friendship requires mutual consent; guest links remain in RAM and accepted account links become durable only after commit. Decline stays private.
- Friend invitations use the existing interaction owner and expire after 30 seconds. Never interrupt busy peers, queue offline invitations or accept client-selected account/guest IDs.
- Remove, block and deletion must invalidate invitations and prevent stale friendship writes from restoring withdrawn consent. Never refresh an existing account's accepted revision blindly.
- Audio is audio-only Opus through approved TURN relays. Validate full SDP, ICE, call ownership, generation, epoch and negotiation; never add a direct-media fallback.
- No microphone capture without an explicit Call/Accept action. Signaling loss terminates audio and requires fresh consent; stop late permission results and all tracks on teardown.
- Keep the separate relay supervisor/watchdog fail-closed. Credential expiry is not allocation revocation; verify cancellation and reject replay until all old credentials expire. Capacity includes unresolved cleanup.
- Audio remains disabled by default. Do not claim five-second cancellation, thirty-second orphan cleanup or 200-connected/25-call capacity without real relay/device/load evidence.

- Payment prices and durations come from immutable versioned server snapshots. Commit intent before provider I/O; reuse the same references after unknown outcomes.
- Only server-fetched, validated captures grant Premium. Browser success and webhook claims never grant directly. Keep sandbox/live data and keys separated.
- Apply account-locked FIFO accounting before grant, hold, release or revoke. Preserve ordered adjustment history and exact integer paise/seconds.
- Full refund holds are scoped to the originating capture. Definitive failure restores unused held seconds from resolution; partial money does not imply time reduction.
- Billing actions require private MFA, an authorized billing role, a fresh signed preview and transactional audit. Financial records survive identity deletion under reviewed retention.
- Keep payment contact transient, optional email omitted, ordinary chat out of financial records and credentials/raw payloads out of logs. Never perform live money operations merely to validate source.
- Checkout, provider integration and annual sales remain separately gated. Source or sandbox tests do not establish underwriting, tax approval, settlement or 200-connected/25-call capacity.

- Public support must survive identity recovery and notification outages while its own database/clock remain usable. Keep case/status/deletion secrets in POST bodies and explicit user-saved files, never URLs or browser persistence.
- Retention policies require independent owner-MFA installation and immutable digests. Runtime credentials cannot approve policies. Purges require current purpose rules, hold/deletion replay and verified off-host journal recovery.
- Operator reads/actions recheck current roles/session generation and audit before disclosing evidence. Evidence exports are encrypted, scoped, bounded, single-use and expire.
- Alerts contain only opaque event refs and fixed codes. Unknown/stale observations are readiness failures; do not label local append/upload success as remote recoverability or self-monitoring as external monitoring.
- Phase9 runtime, migration, restore, notification delivery, staffing and legal gates remain pending until tested and recorded.

- Production starts in maintenance. Only a current private owner/MFA action with audited purpose and source/image/manifest-bound evidence may open admission.
- Drains stop new matching/invitation/call/checkout admission immediately and end remaining interactions within 120 seconds. Preserve safety, support and committed financial obligations while dependencies are healthy.
- Controlled production validation is finite, access-restricted and separately authorized. It cannot become public-launch approval; final launch requires all gates and supervised-cohort evidence before broader ingress.
- Keep release/load/evidence outputs outside source. Never label a Docker configuration ID as a registry manifest digest, or an invented Git commit as archive provenance.
- Capacity reports require real flowing relay media and measured server latency/headroom. Source fixtures, browser emulation, owner probes and browser RTT do not establish full device or server-performance acceptance.
- Keep a single Go owner during deploy/rollback. Never reverse production migrations or restore an old database as code rollback; preserve independent deletion and hold journals.
