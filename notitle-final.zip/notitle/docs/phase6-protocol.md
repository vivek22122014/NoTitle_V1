# Phase 6 mutual connections and invitations

Blueprint V3.2 remains authoritative. These contracts extend protocol version1 and the existing one-owner lifecycle; they do not enable audio or establish runtime acceptance. `docs/openapi.json` describes the public REST and envelope schemas. `friendtypes` defines private owner/storage contracts that deliberately refuse JSON serialization.

## Consent and current-participant scope

Every guest/account and Free/Premium combination can use Stay Connected. Registration is optional. The server derives the other participant from the current interaction; a client cannot name an account, select a peer, claim consent or grant a tier.

| Client event | Payload | Required envelope scope |
| --- | --- | --- |
| `friend.request` | `{}` | Current generation, interaction and epoch |
| `friend.accept` | `{request_ref}` | Same current interaction and epoch as the incoming request |
| `friend.decline` | `{request_ref}` | Same current interaction and epoch; recipient only |
| `friend.withdraw` | `{request_ref}` | Same current interaction and epoch; sender only |
| `friend.invite` | `{friend_ref, kind}` | Current generation; omit interaction and epoch |
| `friend.accept_invite` | `{invitation_ref}` | Current generation; omit interaction and epoch |
| `friend.decline_invite` | `{invitation_ref}` | Current generation; omit interaction and epoch |

All references are opaque16–128-character ASCII URL-safe strings, scoped again to the authenticated owner. Every command uses the existing bounded command IDs, generation checks, strict duplicate/unknown/null-field rejection, valid Unicode and8KiB frame cap. Replaying a request in another interaction is invalid. `kind` accepts the reserved `text`/`audio` vocabulary; this phase rejects audio as unavailable and does not request a microphone, issue relay credentials or pretend a call exists.

A single request is one person's affirmative consent. Acceptance or the peer's reciprocal request supplies the second consent and produces one normalized relationship. An explicit rejection is not announced to the sender: their Request sent state can remain until the interaction ends. The recipient's own incoming prompt closes. End/Next, invalidation, expiry or replacement removes pending consent without storing it. Accepted relationships survive ordinary conversation changes subject to their identity lifetime.

## Public views and events

`GET /api/v1/friends` returns `{friends:[]}`. Each item has `ref`, `display_name`, `created_at`, `durable`, `pending` and `presence`. Presence is only `online`, `busy` or `offline`, disclosed to accepted unblocked friends; no last-seen timestamp or presence history is collected. Guests use their stable session display pseudonym. `durable:false` means temporary; `pending:true` identifies a registered pair whose persistence has not succeeded. A pending relationship must never be described as saved across restart.

The ordinary realtime snapshot includes `friends_enabled`, optional `friend_request:{request_ref,direction}` and `friend_invitations:[]`, bounded to one active invitation per identity. Directions are `incoming` or `outgoing`. Each invitation view contains `invitation_ref`, `friend_ref`, `kind`, `expires_at`, `display_name` and `direction`. The interaction view includes `kind:random|friend` and, when the peer is an accepted friend, `friend_ref`; accepting Stay Connected during a random conversation does not change its origin.

| Server event | Payload and effect |
| --- | --- |
| `friend.request.sent`, `friend.request.received` | Request view; updates the affected person's own consent prompt |
| `friend.request.closed` | `{request_ref}`; closes the local prompt without announcing an explicit refusal to the sender |
| `friend.created`, `friend.persisted` | `{friend:FriendView}`; accepted connection, then durable confirmation only after commit |
| `friend.invitation.sent`, `friend.invitation.incoming` | Invitation view; explicit accept/not-now prompt |
| `friend.invitation.closed` | `{invitation_ref,reason}`; terminal `ended`, `expired` or `accepted` |
| `friend.removed`, `friend.expired` | `{friend_ref}`; invalidate the scoped handle and local entry |
| `friend.presence` | `{friend_ref,presence}`; permitted accepted-friend presence change |
| `friends.changed` | `{}`; invalidate and refetch the authenticated REST list |

The full friend list is never placed inside an8KiB socket snapshot. Frontend state remains in application memory, clears on signout/guest end, and ignores stale-generation or stale-epoch interaction events. Reconnect restores only live owner-held consent/invitation state and relationships valid for the same identity; it never reconstructs expired invitations or guest identities after restart.

## Invitation allocation and safety

Text invitations require an accepted unblocked relationship, valid unrestricted identities, an online available recipient and an available sender. They expire after30 seconds, remain in RAM and are never queued for offline delivery. Receiving an invitation does not change an existing conversation. Acceptance rechecks both endpoints and allocates one interaction through the same owner used by random matching. Queue joins, incoming acceptance, disconnect, Remove, Block, deletion and expiry cannot allocate overlapping interactions. Busy/offline failures use a generic unavailable result, not a public lookup of arbitrary users.

Explicit invitations do not run a second matchmaking pool or alter saved search preferences. They still enforce all identity, safety, capacity and availability rules. Text uses the existing message buffer, epoch and report machinery after acceptance. End returns both people to idle and preserves their accepted relationship. Next follows the established conversation rule and queues only its initiator.

`DELETE /api/v1/friends/{friendRef}` requires the current cookie, exact Origin, CSRF and empty JSON `{}`. It immediately hides the relationship, cancels invitations and ends an active friend interaction; durable completion returns `{removed:true}`. Unknown, foreign and unavailable references share404 `not_found`. A persistence failure does not restore local contact or falsely confirm durable deletion; retry the same removal. Remove allows future random matching, with fresh mutual consent needed to recreate the friendship.

`POST /api/v1/blocks` additionally accepts exactly `{friend_ref}`. It is mutually exclusive with current-interaction or ended-interaction scope. A trusted durable hydration resolves the relationship when needed, then the owner atomically applies the block, removes the friendship and cancels invitations. Blocks in either direction prevent matching and invitations. Unblock never restores consent or a friendship. Friendship handles cannot supply report evidence; reports still require current participation or a valid owner-issued ended-interaction reference.

## Storage, handoff and crash boundaries

Only accepted account–account friendships persist. PostgreSQL normalizes the two IDs with a unique pair and records consent timestamps. Guest endpoints, pending requests, invitations, presence and ordinary messages never become durable rows. Hydration is private and includes endpoint generations plus account friendship revisions; only the explicit owner view reaches the client.

Guest registration rebinds accepted links to the same participant, preserving both consent timestamps and deduplicating normalized pairs. A link stays temporary while either endpoint is a guest. Once both are registered, a bounded worker attempts persistence outside the coordinator, rechecking applicable session/account authority, restrictions, blocks, deletion and revisions. Each newly registered endpoint must complete the existing safety handoff and supply one fresh trusted authorization snapshot to capture its actual friendship revision; the owner never guesses revision1. Closing before that authorization leaves the accepted link pending until the next valid authorization. Any account endpoint already present at consent keeps its originally captured revision. An unrelated Remove/Block may conservatively invalidate an unpublished consent through the account revision; no retry silently rebases it. Existing-account login does not import another guest identity's links. Guest expiry/end purges both endpoint indexes; temporary peers receive an expiry invalidation. Friendship alone does not extend a guest's30-minute idle or24-hour absolute lifetime.

Owner mutations carry an opaque lease, subjects, server-derived session guards, both immutable captured friendship revisions, consent timestamps and version. Fresh account–account acceptance checks current session guards; promotion of an already accepted guest link preserves consent across logout and instead rechecks active account status, deletion, immutable friendship revisions and safety. Logout or credential rotation alone does not revoke that prior accepted consent. Transactions lock account rows in a deterministic order. Remove/Block advances friendship revisions so an older accepted-but-uncommitted write cannot resurrect a relationship across a crash, restart or later unblock. A stale friendship revision or failed applicable fresh-session authorization is terminal; the worker may not refresh the old consent's expected revision and retry it as new consent. Transient database failures may retry the same immutable mutation.

Removal tombstones hide stale hydrated rows. A successful insert whose lease no longer represents the current relation requires a compensating delete limited to that exact reference and pair; it must not delete a later consent. The owner keeps the compensation lease until acknowledgement. Deletion and persisted blocks remain authoritative on reload, including when new friend actions are feature-disabled. Restart loses all guest links, pending consent and invitations; durable account links reload only for currently valid, unblocked identities.

## Bounds and verification

Defaults are100 accepted relationships per identity (configurable downward),20,000 local relationships,200 pending requests and100 concurrent invitations, with one invitation per identity. Invitations have a hard30-second deadline. Owner persistence claims and retries are bounded; no network or database call runs inside the coordinator. These are admission bounds, not measured performance. The existing200-connected/25-two-person-call full-V1 requirement is unchanged; audio and load validation remain later gates.

Mandatory tests cover all tier combinations, reciprocal consent, private refusal, stale epochs, simultaneous accept/Block/Delete/expiry, busy recipients, normalized duplicate promotion, one-then-both registration, storage failure and crash windows, guest reconnect/TTL/restart, durable reload, owner-scoped removal and rejection of forged references. Authored Go/database/browser tests must be executed in the supported toolchain before acceptance. No ordinary conversation retention, offline inbox, paid infrastructure or additional application replica is introduced.
