# Phase 7 audio control and relay-only signaling

This extends protocol version1 without changing random matching, guest identity, mutual friendship or safety authority. Audio is nested inside the existing interaction. Feature flags alone do not establish release acceptance: configured audio also requires a synchronized, healthy private relay supervisor. See `phase7-acceptance.md` for the real relay and device gates.

## Consent, state and authority

Only current, connected, unrestricted interaction participants may request a call. The first request creates one opaque call reference and determines the offer owner. A crossing Call command from the peer is affirmative acceptance of that same call; it cannot create a second call or claim offer ownership. The caller sees REQUESTED, the recipient RINGING. The request expires after30seconds. Declining applies a15second interaction cooldown.

Acceptance reserves one of25 call slots before relay provisioning. ACCEPTED becomes CONNECTING only after the private relay grants its lease and the owner rechecks the call, participant generations, interaction epoch, current safety and supervisor boot. Each endpoint receives only its own credentials. Both endpoints must report connected for the current negotiation before CONNECTED is published. Call End preserves text; conversation End/Next/Block, logout, deletion, takeover or signaling loss also terminate audio. Signaling reconnection never resumes a previous call implicitly.

The accepted/connecting/connected population and uncertain relay cleanup share the25call cap. This is a configured admission bound, not evidence that200 connected participants and25 real two-person calls have passed a benchmark. Existing text and safety controls remain available when audio cannot be started.

## Client commands

Every row requires the current nonzero connection `generation`, `interaction_id` and `epoch` in the existing envelope. Extra fields, duplicate keys, null values and malformed Unicode are rejected. There is no peer/account identifier in any command.

| Type | Payload | Rule |
| --- | --- | --- |
| `call.request` | `{}` | Current peer only; one pending request |
| `call.accept` | `{call_ref}` | Incoming unexpired request only |
| `call.decline` | `{call_ref}` | Incoming request only |
| `call.end` | `{call_ref}` | Current call only; preserves text |
| `call.connected` | `{call_ref, negotiation}` | Current provisioned negotiation only |
| `webrtc.offer` | `{call_ref, negotiation, sdp}` | Designated offer owner only |
| `webrtc.answer` | `{call_ref, negotiation, sdp}` | Other endpoint, after one accepted offer |
| `webrtc.ice` | `{call_ref, negotiation, candidate, sdp_mid, sdp_mline_index}` | Approved relay candidate; media0 only |

`call_ref` uses16–128 URL-safe characters and is always scoped again by the owner. `negotiation` is a positive server-issued integer. `sdp_mid` is exactly `"0"`; `sdp_mline_index` is exactly0. End-of-candidates is represented by the validated SDP attribute when present; an empty trickle candidate is not forwarded.

The outer socket reader caps frames at64KiB before JSON decoding. Only `webrtc.offer` and `webrtc.answer` may exceed8KiB. Their SDP string is further capped at60KiB, and the complete JSON envelope still must fit64KiB. ICE candidate strings are at most1024bytes. The ordinary8KiB cap applies to authentication, text, call control, ICE and every other event. Compression remains disabled. Both socket directions apply event-specific limits.

## Server events and snapshots

| Type | Payload |
| --- | --- |
| `call.state` | `{call_ref,state,direction,offer_owner,expires_at}` |
| `call.credentials` | `{call_ref,negotiation,credentials}` |
| `call.ended` | `{call_ref,reason}` |
| `webrtc.offer` / `webrtc.answer` | Validated corresponding SDP payload |
| `webrtc.ice` | Validated corresponding ICE payload |

`direction` is incoming/outgoing; `offer_owner` is self/peer. The normal session snapshot adds `audio_enabled` and an optional `call` matching the call-state shape. It never includes TURN credentials. The CONNECTED expiry is the Go zero timestamp and does not represent a call duration limit; ring/setup deadlines apply only before connection. All credential/signaling events retain the same generation and interaction epoch scope as other interaction events.

The private `credentials` object contains `urls`, `username`, `credential`, `expires_at`, `refresh_at`, `relay_addresses`, `relay_min_port` and `relay_max_port`. Browser code constructs one ICE server entry from the first three fields, sets `iceTransportPolicy: "relay"` and `bundlePolicy: "max-bundle"`, and holds credentials only in RAM. Neither endpoint can request the other endpoint's credentials. No credentials, SDP or candidates enter logs or browser storage.

The blueprint's authenticated TURN-credential operation is implemented as a private server-pushed socket event after the asynchronous owner lease, rather than a second public REST dispenser. This preserves accepted-call authorization and avoids competing credential state paths. The public `/api/v1/voice/turn-credentials` route is not mounted.

## Full SDP and ICE validation

`internal/audiotypes/signaling.go` implements a narrow full-message grammar and rejects unsupported extensions. It does not merely search text for a relay flag. SDP must contain one audio section, one dynamic Opus/48000/2 payload, BUNDLE/mid0, `sendrecv`, DTLS SHA-256 fingerprint, an offer `actpass` or answer `active`/`passive` setup, and `rtcp-mux`. Expected ICE fields, bounded audio RTP extensions, Opus parameters and bounded SSRC/MSID fields are parsed. Video, application/data channels, extra media/codec sections, unknown attributes, remote-candidates, contact/session information, duplicate sensitive attributes and malformed line boundaries fail closed.

Every embedded candidate receives the same validation as trickle ICE. Only RTP component1, UDP relay candidates, configured relay IP literals and ports49152–50175 are accepted. Private, loopback, link-local, multicast, mapped-IPv6 and unknown addresses are rejected even if accidentally configured. Related candidate addresses must be `0.0.0.0` or `::` with a privacy placeholder port0 or9. Real host/server-reflexive related addresses are never forwarded. SDP `c=` and RTCP address fields must be placeholders or approved relays; the `o=` address permits only browser origin placeholders. No arbitrary address-bearing line is forwarded unparsed.

TURN TCP/TLS describes the browser-to-relay connection. The provisioned relay-to-peer transport is UDP, including when reaching TURN over TLS443. A browser that cannot produce this constrained audio description must show an honest audio failure and preserve text. New browser SDP forms require a reviewed parser change and real browser regression evidence; do not silently allow unknown attributes.

## Refresh, races and cleanup

Credentials initially expire after10minutes and refresh after5minutes. A refresh is authorized only for the still-active accepted call. The owner increments `negotiation` only when create/refresh credentials are published, resets offer/answer/candidate/connected counters and allows only the designated offer owner to begin the new ICE negotiation. Delayed SDP, ICE or connected acknowledgements from an earlier negotiation are rejected even though the interaction epoch is unchanged.

The private owner/worker interface consists of `AudioServerInstance`, `SetAudioRelayReady`, `ClaimAudioJobs` and `FinishAudioJob`. Jobs hold an opaque operation lease, call reference, monotonic version, app instance, absolute lease deadline and credential expiry. Database/network work stays outside the owner. The worker handles create, renew, refresh and revoke through the authenticated supervisor path. A stale successful provisioning result must be compensated by an idempotent terminal call revocation. End can claim an independent revoke while a create/refresh is still in flight. Capacity is released only after definitive cleanup; an uncertain result is never treated as a clean stop.

The30second relay lease is renewed every10seconds. Supervisor restart changes its boot identifier, clears allocations and requires application resynchronization. Revocation must also reject/cancel allocations created by replayed old credentials through their expiry, rather than only canceling a single currently observed allocation. Normal revocation within5seconds and orphan cleanup within30seconds are acceptance criteria requiring real coturn evidence. Source tests and mocked control paths cannot certify those timings.

## Privacy and validation evidence

Audio is DTLS-SRTP protected while coturn forwards it. No recording, transcription or voiceprint feature is introduced. Peers can still record externally. The SDP validator protects normal peer network-address disclosure; it cannot prevent a malicious consenting person from verbally or deliberately encoding their own identifying information. Ordinary audio and signaling remain temporary. The owner retains only the latest accepted call reference and request/accept/end timestamps alongside the current interaction and its existing ten-minute ended-report reference. Report Begin freezes a copy. Only explicit report submission puts that metadata into the existing encrypted case evidence; ordinary calls create no durable call-history row. Moderators can inspect the reference/timing, but cannot replay unrecorded audio.

Synthetic Go fixtures cover malformed envelopes, stale scope, typed frame limits, forbidden SDP sections/addresses and candidate variants. They require execution with the pinned Go toolchain. Browser/controller tests do not establish actual microphone, media, TURN allocation cancellation or load acceptance.

Primary protocol references: [RFC8839 ICE SDP procedures](https://www.rfc-editor.org/rfc/rfc8839.html), including privacy placeholders, and the [W3C WebRTC recommendation](https://www.w3.org/TR/webrtc/) for relay-only ICE and browser permission/connection behavior. The implementation intentionally supports a narrower audio subset than those general standards.
