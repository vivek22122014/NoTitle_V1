# NoTitle architecture — cumulative through Phase 7

This repository implements the foundation of NoTitle blueprint V3.2. The application is a mobile-first responsive website with desktop feature parity. It uses a static SvelteKit frontend, one Go process, PostgreSQL and Caddy.

```mermaid
flowchart TD
  Browser["Mobile or desktop browser"] --> Edge["Caddy"]
  Edge --> Static["Static SvelteKit build"]
  Edge --> API["Go HTTP service"]
  API --> Coordinator["One bounded coordinator"]
  API --> Database["Private PostgreSQL"]
  Migrations["Migration process"] --> Database
```

The development frontend may use Vite for live editing. The production-like local mode serves a built static bundle through Caddy and uses the same API paths. Production has no Node server.

## Phase 1 boundaries

- `web/`: design tokens, public entry page, unavailable application shell, accessible navigation and typed same-origin API client. It has no business authority.
- `server/`: configuration, HTTP lifecycle, safe logging/errors, clock and ID abstractions, health/readiness, PostgreSQL connection boundary and coordinator foundation.
- `server/migrations/`: versioned foundation schema and marker. No accounts, ordinary messages or fake product data.
- `deploy/`: local and release-oriented container definitions, Caddy and role initialization.
- `scripts/`: bootstrap, dependency-lock generation and verification commands.
- `docs/`: contracts, configuration, threat model, retention inventory and acceptance evidence.

The initial Phase 1 coordinator was a bounded skeleton; the Phase 3 and 4 extensions below supersede that boundary. Database/provider work belongs outside its loop. Only one authoritative application instance is supported; simply adding replicas would violate that ownership model.

## Capacity and product rules

Preserve the required minimum of 200 connected participants with 25 simultaneous two-person calls. The 50 people calling are included within 200; the queue's initial 100 waiting limit is also an included subset. Full-load evidence belongs to later feature-complete testing.

All Guest/Free/Premium identities eventually share one logical pool. Premium gender preferences must be mutual hard constraints. Professional preferences remain a tiny, fading soft tie-break. No infrastructure change in this phase relaxes any rule.

## Data and rollout

Use the runtime database role only for application access. Migration and initialization privileges belong to separate processes. Readiness requires the expected foundation schema; liveness is independent of database availability.

Normal conversation data and guest relationships will remain bounded RAM state under the reviewed retention design. Do not add ordinary-message tables, browser transcript persistence or Redis as a shortcut.

Phase 1 release configuration is an engineering baseline. Public launch still depends on authentication, safety/moderation, payment approval, retention/legal review, tested backups, media enforcement and the full acceptance matrix.


## Phase 2 public surface

Eleven public routes now share a mobile-first design and SEO metadata. An explicit application route allowlist uses a noindex/no-store fallback; unknown routes return404. Default preview output is non-indexable. Staging adds authentication. Production builds and runtime startup require matching approved mode/origin and reviewed legal data. See docs/seo-release-controls.md.

A development-only interaction preview demonstrates mobile layouts and state transitions without network, storage, media or payment side effects. The one-process backend architecture and full-V1 capacity requirements are unchanged. It does not implement domain operations.

## Phase 3 implemented extension

The single Go process now contains the identity service, PostgreSQL transaction adapter and same-origin HTTP account transport. The existing coordinator owns memory-only guests, profile versions, bounded handoff leases and participant-slot identity binding. No second process owner, Redis, external authentication provider or outgoing email service is added.

PostgreSQL migration 2 adds accounts, public profiles, private professional profiles and unique controlled interests, sessions, append-only consent and initial deletion jobs. Every sensitive mutation locks the account, then reads a fresh profile/session snapshot and checks status, generation, expiry and recent authentication where required. Profile edits compare client versions in both the transport snapshot and transaction. Recovery consumes its verifier once while rotating all credentials/sessions atomically.

A dedicated filesystem journal sits on a volume independent of PostgreSQL rollback. Startup serves liveness while holding identity routes closed until schema/role readiness and tombstone replay succeed. Subsequent maintenance retries pending durability and prunes bounded expired sessions. Permanent purge, off-host recovery orchestration and approved retention remain later gates. The journal contains only internal deletion/account references, generation and request time.

The production API memory budget increases from 256 to 384 MiB for bounded Argon2id work. This does not require a larger server or added subscription by itself; measure the entire colocated VM before selecting final capacity. One process remains appropriate for the V1 target, subject to the still-required 200-connected/25-call load test. Phase 3 adds identity plumbing; it does not certify realtime capacity.

## Phase 4 implemented extension

The same process now owns all waiting participants and interaction reservations. Same-origin REST issues cookie-bound one-use tickets; a maintained WebSocket transport validates the first frame, renews authorization and uses bounded buffers. The coordinator applies strictly mutual gender eligibility, capped fading relevance and recent-pair protection over one pool. It serializes pairing, Next/End, generation-safe reconnect, takeover and identity handoff. No socket write or database read runs inside the owner.

Migration 3 adds only private account matching preferences. Guest preferences, tickets, queue entries, active peer snapshots, command dedupe and recent-pair memory are ephemeral. Trusted entitlement and safety interfaces isolate later paid/moderation workflows; no browser claim can activate them. Current production entitlement behavior is Free.

A dependency supervisor holds admission closed until identity replay and PostgreSQL are ready. Known outages stop matching and have a five-second controlled teardown window. Failed post-commit safety publication latches the owner closed until process restart, so a healthy database probe cannot accidentally restore unsafe cached authorization.

| Component | Before Phase 4 | Current implementation |
| --- | --- | --- |
| Frontend | Static public/identity pages and simulation | Same deployment, live mobile-first chat control and preference editor |
| Go process | Identity and bounded guest owner | Same process plus ticket transport, shared matcher and reconnect |
| PostgreSQL | Identity, consent, sessions and deletion jobs | Adds private versioned preferences; no conversation table |
| Deployment | Caddy + one API + private PostgreSQL | Unchanged services and public ports |
| Paid infrastructure | None introduced by prior source phases | None added; no Redis or managed realtime subscription |
| Capacity | 200-connected/25-call requirement | 200 retained realtime slots, 100 waiting admission; audio still future |

The 384 MiB API limit is an initial budget, not measured Phase 4 capacity. Full-stack load, memory and outage tests remain mandatory. One owner simplifies correctness and initial costs but is one failure domain: restart ends guests and interactions. Registered identity/preferences survive. Multiple API replicas need explicit ownership/routing design; do not round-robin this in-memory state across independent processes.

## Phase 5 implemented extension

The existing WebSocket transport now carries escaped plain text, server sequences, relay acceptance and recipient-render acknowledgements. One coordinator retains bounded message and dedupe state, enforces bilateral blocks/restrictions and clears ordinary content at interaction end. Reconnect replays only surviving same-epoch RAM messages as individual bounded frames. The shared matching rules and admission limits are unchanged; no message broker or conversation database has been introduced.

Canonical Report/Block REST handlers submit priority commands to that same owner. Report Begin freezes a two-minute bounded snapshot; Submit persists only selected server-attributed messages, a separately labelled allegation and minimal case metadata. Report & Block first stops communication locally, then persists the applicable durable block with the report transaction. Storage errors never become a successful submission notification. Ten-minute ended references hold no transcript. Directed blocks are reciprocal contact exclusions; temporary guest references follow the existing in-session upgrade and cleanup controls.

The safety service performs PostgreSQL and encryption work outside the owner. Migration 4 adds reports, encrypted evidence, case-scoped subject mappings, registered blocks, restrictions, action history and legal-hold foundations. Migration 5 adds independent operator accounts, MFA sessions and audit. AES-256-GCM evidence keys and the separate MFA key are protected deployment inputs, not frontend values or database credentials. The private triage listener runs in the existing Go process behind the operator's VPN/access gateway, with its own origin, cookies and scoped roles. It has no unrestricted live-chat view.

When safety is enabled, guest registration creates a pending-safety fence in the account transaction. A leased worker persists the authoritative in-session block/restriction snapshot and removes that fence atomically. Until then, the account cannot obtain fresh realtime authorization. Pending rows surviving a crash remain closed for private operator reconciliation, preventing an unfinished guest upgrade from losing safety enforcement merely because RAM was lost. Fresh upgrades while the safety feature is disabled do not create new safety handoff work; disabling the feature never removes an existing durable fence. This is a durable admission fence, not an ordinary guest-profile or transcript store.

Realtime continues reading durable safety authorization even if text/report UI activation is disabled. Per-message work uses the owner's current authorization snapshot, the existing 30-second lease and ten-second renewal, rather than adding a database read for each send or delivery acknowledgement. Immediate priority invalidation and the five-second dependency-outage teardown remain enforced. A pending registration finalization produces retryable admission and retains the same reconnect proof within the existing 25-second grace; it never relaxes safety to meet a reconnect deadline.

| Component | Phase 5 change | Cost and operating consequence |
| --- | --- | --- |
| Static frontend | Live text, report evidence selection and block management | Same static hosting; mobile-first and desktop workflows remain identical |
| Single Go process | Bounded text/safety owner commands, storage service, private MFA triage listener | No extra application replica, worker subscription, Redis or external moderation service |
| PostgreSQL | Submitted safety material, durable blocks, operators and audit | Existing database; bounded queries and indexes, plus growing evidence/audit storage requiring measured budgeting |
| Private access and keys | Separate protected operator origin and recoverable encryption keys | Use the existing protected host/VPN where suitable; actual gateway, backup and staff costs depend on deployment |
| Capacity | Same 200-connected/25-call requirement | Text bounds and safety concurrency still require load/race tests; audio remains a later phase |

At 100 simultaneous interactions, the maximum 64-KiB message payload allowance totals 6.25 MiB before Go objects, 16,384-entry per-interaction dedupe maps, sockets/outboxes, drafts and other runtime memory. Up to 64 report snapshots add at most 4 MiB of text payload, again excluding overhead. These calculations are bounds on particular payloads, not a process memory or host-capacity benchmark. Keep the existing initial API budget under review using measured combined-load results.

Feature flags keep deployed text/safety off until accepted. Enabled deployed safety requires private moderation and explicit retention/coverage configuration, but those checks cannot appoint actual operators or prove the surrounding operations. Automatic case/evidence purge, full legal-hold handling, appeals/grievance automation and evidence export remain later scope. Phase 5 source does not establish public-release readiness or change the finalized retention/legal, backup, media or payment gates.


## Phase 6 implemented extension

Mutual connections use the existing coordinator, authenticated WebSocket and static frontend. Stay Connected is available to guests and registered accounts in every tier combination. Pending requests are interaction-scoped RAM state: both endpoints must affirmatively consent, reciprocal requests create one relationship, and a decline does not send a rejection announcement. Next or End clears the pending request while preserving an already accepted relationship.

Migration 6 stores only normalized account-account friendships, with a unique pair and opaque relationship reference. Accepted relationships containing a guest remain in bounded RAM with reverse endpoint indexes, consent times and identity generations. They survive conversation changes and a brief disconnect while that guest identity is valid; guest session end, expiry or process restart removes them. A guest's friends list uses the same session pseudonym. No guest row, persistent presence history, offline invitation queue or public person lookup is introduced.

Database work remains outside the owner. Durable acceptance and promotion use ordered account locks, current account/safety checks and captured account friendship revisions. Remove, Block and account deletion invalidate revisions so delayed work cannot recreate withdrawn consent after a crash. These revisions are account-wide: a Remove or Block involving another person can conservatively invalidate unrelated consent that has not yet been persisted. Already durable friendships remain intact. An invalidated pending relationship requires fresh mutual consent; a retry must never replace its captured revisions with newer values. Owner publication acknowledges the exact persistence result; stale successful inserts require guarded compensation. Failed storage never becomes a claim that a connection was saved permanently.

Registration rebinds accepted links to the registering person's new account and preserves the two original consents. The link remains temporary while either endpoint is a guest and becomes durable only after the guarded database commit. A newly registered endpoint starts with no captured friendship revision: its first fresh authenticated authorization after safety handoff supplies the authoritative value. The implementation never guesses revision 1. If that person closes the session before this authorization, the accepted link remains pending in RAM until a later valid authorization supplies the value. An endpoint that was already an account retains the revision captured with its consent; it is never silently refreshed.

After the necessary revisions are captured, promotion can finish while an account is offline or logged out. It rechecks active account status, the frozen revisions and safety; it does not require both old cookies to remain valid. Credential rotation does not by itself withdraw an already accepted relationship. Fresh account-account acceptance still checks its originating session guards, and any new interaction requires current authentication. A pending link is not restart-durable until persistence succeeds. Signing into an unrelated existing account does not import guest relationships.

Presence is projected only to accepted, unblocked friends. An online invitation expires after 30 seconds, carries an opaque relationship reference and requires explicit acceptance. The same owner allocates random and friend interactions, so accepting an invitation cannot create overlapping sessions or interrupt a busy person. Remove cancels outstanding invitations and ends an active friend interaction; Block also prevents future random matching. Unblock does not restore friendship. The contract reserves audio invitation intent, but Phase 6 refuses unavailable audio and never starts a microphone or pretends a call exists; Phase 7 must add the media controls before audio is enabled.

| Component | Phase 5 | Phase 6 change |
| --- | --- | --- |
| Static frontend | Random text, reports and block management | Stay Connected controls, friend list, scoped presence and accepted text invitations with the same mobile-first workflows |
| Single Go process | Shared matcher, text/safety and private triage | Bounded relationship/request/invitation state and guarded persistence worker; same interaction owner |
| PostgreSQL | Identity, safety, moderation and deletion | Normalized durable account friendships and durable stale-write revisions; no guest or invitation table |
| Deployment | Caddy, one API and private PostgreSQL | Same services, listeners, keys and host model; no added paid subscription |
| Capacity | 200 connected participants, 100 waiting; 25-call requirement pending | Same participant limits, plus bounded friend state; audio and combined-load acceptance remain pending |

Incremental infrastructure subscriptions are ₹0 per month and ₹0 per year under the assumption that the already budgeted host has sufficient measured capacity. This is not an all-in operating cost: relationship storage, encrypted backups, existing network/hosting and staffed safety operations still consume resources. Measure the new list, presence, invitation and promotion workload before changing host sizing. Optimize queries and vertically resize when required; adding independent API replicas still needs an explicit ownership/routing design.

## Phase 7 audio and relay control

Audio extends the existing interaction, consent, generation and safety boundaries. It does not introduce another matchmaker, a managed media subscription, a production Node server or an ordinary-call database. The browser requests microphone access only after that person's explicit Call or Accept action. Text remains available while a call is requested, connected or unavailable. Guest, Free and Premium participants use the same call controls and limits. An accepted friendship is permission to receive an invitation, not permission to activate a microphone.

The single coordinator owns call consent, one outstanding request per interaction, the 30-second ringing deadline, 15-second decline cooldown, the accepted call reference and signaling ownership. Only the assigned offerer may initiate negotiation; simultaneous requests converge on one call. Every offer, answer and ICE candidate is scoped to the accepted call and current interaction epoch. Backend validation examines the complete audio-only SDP, embedded candidates and connection addresses as well as separate candidates. Video, data channels, non-relay candidates and unapproved relay addresses are rejected. Database and private relay-control I/O stay outside the coordinator.

```mermaid
flowchart TD
  Browser["Browser audio controls"] -->|"Accepted call signaling"| App["Existing Go application"]
  App -->|"Private renewable lease"| Supervisor["TURN-host supervisor"]
  Supervisor -->|"Inspect and cancel allocations"| TURN["coturn"]
  Browser -->|"Relay-only encrypted media"| TURN
```

Deploy coturn and its narrow supervisor on the separate relay VM. The application and PostgreSQL remain on the existing 2-vCPU/4-GiB candidate; the relay candidate remains 1 vCPU/1 GiB. TURN has a DNS-only hostname and a publicly trusted certificate. UDP/TCP 3478, TLS/TCP 443 and UDP 49152–50175 are the intended public relay ports. TURN/TLS is not HTTPS and must not pass through Cloudflare's ordinary HTTP proxy or Caddy's web routes. Keep administration, private control and aggregate metrics off public listeners.

Accepted calls receive random participant-specific TURN usernames with ten-minute credentials, refreshed at five minutes while current authorization remains valid. A separate renewable application lease lasts at most 30 seconds. Credential expiry is not an allocation revocation mechanism: the supervisor cancels allocations after call termination and continues detecting replayed credentials until their expiry. Supervisor startup must clear allocations and refuse new work until its application state is resynchronized. An application outage must not leave media running indefinitely; a browser disconnect ends audio rather than silently reopening the microphone on reconnect. The text interaction may still use its existing reconnect grace.

Next, End, Block, logout, deletion, loss of authorization and relevant friendship removal close the call and stop further credential issuance. Browser tracks and the peer connection are closed locally. The private supervisor independently enforces the accepted call lifecycle against coturn, including uncooperative peers. Required acceptance is allocation removal within five seconds under normal operation and orphan removal within the 30-second application lease deadline. These are targets that must be measured against the pinned coturn image, not guarantees created by source or configuration.

| Component | Phase 7 addition | Cost and scaling consequence |
| --- | --- | --- |
| Static SvelteKit frontend | Lazy audio controller, permission/error states, call consent, mute/end and text fallback | Same build and hosting; no media code or microphone activity on public landing pages |
| Existing Go application | Accepted-call ownership, strict signaling, scoped credentials and bounded private relay work | Same application host; measure owner latency and control-plane health at the combined workload |
| Existing PostgreSQL | No ordinary audio payload, SDP, ICE or call-history table | Existing safety reports retain only explicitly submitted permitted metadata/text under their own policy |
| Dedicated relay VM | coturn, certificate, allocation quotas and local cancellation supervisor | Previously budgeted separate relay; capacity and egress depend on actual devices, networks and usage |
| Release gates | Replay, crash, network/device and mixed-load evidence | Public audio remains off until enforceable teardown and privacy checks pass |

Keep admission at 200 connected participants, including the 50 people in 25 simultaneous two-person calls and any waiting users. Four allocations per participant require at least 200 simultaneous allocations for that call target, plus measured operational headroom within the 1,024-port range. ICE restart and credential refresh can overlap allocations; a call count is not an allocation count. Record relay CPU/RSS, actual allocations, bandwidth/egress, failed allocations and control/cancellation latency together with application/database performance. The 200-connected/25-call requirement is not satisfied by a unit test or by merely setting those limits.

The blueprint's planning assumptions are ₹97/USD and 18% tax, giving the previously budgeted USD6 relay a calculated ₹686.76/month or ₹8,241.12/year. This is an assumption-based estimate, not a current vendor quote; tax credits, exchange charges, temporary staging and excess transfer are excluded. No extra recurring supervisor license is required. See `docs/phase7-relay-runbook.md` for cost scenarios, operating boundaries and the remaining acceptance procedure.

The existing reporting path can freeze the latest accepted call's server-derived reference and requested/accepted/ended times with a Report Begin snapshot or bounded ended reference. Only an actual report submission writes that metadata into the existing encrypted interaction evidence; the audited private case view receives a sanitized projection. No ordinary call history, media recording or new audio table is created. An allegation and its timing do not establish what was said.

## Phase 8 Premium and financial operations

Payments extend the same Go process and PostgreSQL deployment. The static browser initiates authenticated, server-priced purchases and hands payment entry to approved Cashfree hosted checkout. A private server adapter verifies provider state; immutable purchase snapshots, attempts and one captured-purchase grant transaction control entitlement. Redirects, SDK callbacks, raw webhook assertions and browser badges confer no paid authority. A signed webhook is durably acknowledged before a bounded worker fetches authoritative state. Five-minute unresolved-order work and daily reconciliation use durable PostgreSQL jobs outside the coordinator.

Migration 7 adds versioned plans, purchases/attempts, FIFO duration lots, append-only adjustments, refund/dispute records, normalized webhook inbox, leased jobs and restricted reconciliation/review history. Existing accounts provide row-lock serialization. Ordinary chat, guest profiles, audio and peer-visible private data remain absent from these tables. The reviewed retention process must preserve financial obligations while detaching disabled/deleted identities; payment records never cascade away with identity erasure.

Each capture appends exact duration once. Elapsed time consumes the oldest available lot. Full-refund requests hold the originating lot's unused seconds; definitive failure restores that duration from resolution time, and success revokes only that held remainder. Partial compensation defaults to money-only, with explicit seconds for any approved duration treatment. A projection is rebuildable from ordered grant/adjustment accounting; expiry alone is not the financial source of truth. Realtime checks actual entitlement expiry at queue admission and match commit, and durable mutation fences prevent stale paid authorization during refunds and disputes.

| Component | Phase 8 change | Incremental fixed infrastructure |
| --- | --- | --- |
| Static frontend | Enabled catalog, hosted checkout handoff, processing, receipts and expiry consent | Same responsive build and hosting |
| Single Go process | Provider verification, webhook boundary, bounded worker/reconciliation and trusted entitlement bridge | Same API process; no extra replica or worker service |
| PostgreSQL | Financial ledger, ordered adjustments, jobs and reviewed operator history | Existing database; measure pool wait, growing indexes and encrypted backup usage |
| Private administration | Audited financial review, refund preview/action and dispute treatment | Existing private MFA listener and operator access path |
| Cashfree | One approved external gateway for hosted payment and original-instrument refunds | Usage fees under the actual merchant contract; no new recurring billing mandate |

The runtime checkout switch controls new purchases separately from reconciliation. Turning off new checkout must not erase existing paid rights, discard webhook work or stop processing unknown outcomes. Sandbox/live identities, credentials and references remain isolated. New plans default unpublished; annual publication additionally needs the approved later-refund route and unit-economics review. No source flag supplies underwriting, tax approval, staff coverage or live settlement proof.

The full-V1 minimum remains 200 connected participants and 25 simultaneous two-person calls. Include payment/reconciliation work, expiration, refund invalidation and operator activity in the six-hour mixed-load scenarios before claiming capacity. Keep the existing initial host budget unless measurements justify a resize; do not add Redis, a payment microservice, a second database, email delivery or permanent staging to solve an unmeasured problem. See `phase8-payments.md` for cost assumptions and the financial recovery procedure.
