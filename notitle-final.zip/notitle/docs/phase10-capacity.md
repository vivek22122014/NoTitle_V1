# Phase 10 capacity evidence

Status: harness source and offline contract tests implemented. No browser,
TURN, six-hour, host-capacity, cleanup or overload result was measured here.
A green fixture test is not an application load test. Preserve 200 connected,
100 waiting and 25 established two-person calls; failed evidence requires
optimization or a host upgrade and a complete retest.

## Executable workload

`node scripts/load-soak.mjs PERMIT FIXTURES OBSERVATION NEW_REPORT A|B|overload
[SECONDS]` runs the built application's real `/chat` route through the pinned
Playwright Chromium. Four separate browser processes keep the generator away
from the application/relay host. Generated microphone PCM travels through the
production WebRTC controller, actual Opus encryption and approved TURN relay.
It is synthetic test audio, not a real person's microphone and not synthetic
SDP. The observer measures real `RTCPeerConnection.getStats()` inbound/outbound
RTP byte increases and both selected relay candidates. It does not manufacture
stats, replace the controller, mock HTTP/WebSocket responses or record audio.
Browser/device and Wi-Fi/cellular/restrictive-network acceptance remains a
separate gate; this desktop Chromium load generator cannot establish it.

| Scenario | Waiting | Audio participants | Text-only participants | Total | Duration |
| --- | ---: | ---: | ---: | ---: | --- |
| A | 100 | 50 in 25 calls | 50 | 200 | At least 6 hours |
| B | 0 | 50 in 25 calls | 150 | 200 | At least 6 hours |
| Overload | Baseline A, then deliberate excess offers | Preserve 25 existing calls | Existing text pairs | Offer 400; admit at most200 | Bounded separate run |

At every interval the report also checks offered, accepted, peer-received and
rendered-ACK message progress. Expected offered rates are20/sec for A and40/sec
for B. Total offered traffic must reach98% of the target, every interval75%
(to allow a send tick at a sampling boundary), and after a bounded final acknowledgement drain, every offered message must be
accepted, received and acknowledged. The churn pair pauses
sends during its deliberate transition; all other participants continue. Any
unexpected server protocol error stops the soak. Server sample counts must
increase during the run; old positive histograms alone cannot pass.

All 200 participants are admitted before the 25 calls are established, so
initial call setup measurements include the full connection load. The timed
window begins after that setup and media warm-up. Every 30-second sample
must show the exact scenario counts, bidirectional flowing media for all50
endpoints and relay-only candidate selection. Samples must cover six hours with
no gap over45seconds. Churn is deliberately performed between sample points;
these measurements do not claim every participant remains connected during a
reconnect transition. A dropped required sample blocks acceptance rather than
silently subtracting failures from the denominator. A shorter `SECONDS` value
is useful for calibration and always fails the launch six-hour gate.

Every matched participant, including callers, sends a fixed synthetic message
once per five seconds through the authenticated production socket. The observer
uses the actual interaction/generation in memory; messages and identifiers
never enter reports. Every five minutes the driver exercises three successive
Next actions on one text pair, waiting4100ms before the former peer re-enters
so the existing four-second repeat exclusion has elapsed before that compatible
candidate becomes available, then reconnects one endpoint. In A, two strict
waiters briefly cancel search while remaining connected, making room for the
two churn participants; they rejoin before the next required100-waiter sample.
This preserves the existing queue-cap behavior instead of bypassing it. The driver pauses the other
renderer for two seconds while delivering a real synthetic message, and performs a two-request concurrent login/password-hash burst on a
dedicated synthetic account. The separate protocol/race suite covers rapid abusive Next and the exact
four-second boundary; the soak does not mislabel that intentional exclusion as
server processing delay. The renderer pause is an application slow-reader
exercise; separately test a TCP consumer that stops reading in the transport
backpressure/race suite. It is not proof that TCP send queues were saturated.
Inside the timed window it creates a mutual guest friendship via both affirmative UI
actions. Dense account friendship (200 users each with100 offline friends),
safety authorization race tests, expiry and reconnect device behavior remain
required separate acceptance evidence.

A uses101 pre-provisioned consenting test accounts:100 male accounts with
trusted Premium lasting at least eight hours and female-only preferences, plus
one for the101st-waiter probe. Test peers are Other, preserving strict mutual
incompatibility and one shared pool. The test never adds an entitlement endpoint
or writes a billing grant directly. Provision isolated accounts and sandbox
entitlements through approved existing fixtures/workflows. B requires only the
dedicated hash account; other participants are guests. `hash_account` and each
`waiting_accounts` entry contain only `username` and `password`. Optional
`http_credentials` supplies the temporary staging access gate. Credentials
stay in protected files and browser memory; do not reuse real-user accounts.

The overload run first maintains scenario A, prepares200 further identities,
and issues their realtime attempts together. It requires200 explicit
`CAPACITY_REACHED` rejections. It then requests a26th call from an admitted text
pair and requires clean rejection. After explicitly ending one text match and closing its idle participant
(which releases its slot without reconnect grace),
it retries an already-created incompatible account and requires rejection of
the101st waiting participant. All baseline text/audio participants must retain their interactions and
acknowledge a fresh synthetic message after the400-offered burst. Existing
callers must still show flowing relay media. After the explicit slot-release
probe, every other text pair and caller must remain intact. Separate server/relay observations must establish preserved safety
processing and measured five-second normal/30-second orphan allocation cleanup;
closing browser tabs is not allocation-revocation proof. The runner never
crashes a real host, sends live money, or fabricates those drill results.

## Permit, bounds and interruption

Prepare owner-only working copies of `deploy/load/*.example.json`. The permit
must identify the actual authorizer, current validity (maximum48hours), exact
isolated origin, approved relay hosts, source checksum and immutable digest for
api/web/migrate/postgres/turn. It expressly records no real users, only synthetic
accounts and no live money. It cannot authorize more than21600 soak seconds,
400 offered participants,200 admitted or25 calls. It must cover setup plus the
whole run. An overall watchdog is soak duration plus15minutes; it closes every browser
immediately on expiry. Browser page and bounded sample operations have15second
deadlines; teardown expiry is a failure. Run the temporary generator under an
OS/process supervisor with a final hard timeout as an independent safeguard
against a crashed driver/browser transport. Both Ctrl-C and
SIGTERM stop admission, close media and write a non-passing interrupted result.
Existing output files, symlinks, broad file permissions and oversized JSON
inputs are rejected before any target work. Do not place private fixtures in
the archive or repository. Keep staging protected by the existing gateway.

Do not alter source rate limits to make a benchmark pass. Account ramp-up is
paced for password-hash admission; synthetic guest ramp-up is also bounded.
If source-IP controls or generator CPU become a bottleneck, record the limitation
and use a reviewed schedule within the existing source and global limits.
Multiple generators can relieve generator CPU, but cannot bypass a shared Caddy
source bucket or the global hash budget. This implementation does not trust
forwarded headers or change abuse controls, and does not automatically provision
or coordinate distributed generators. Each hash burst counts two completed
requests; any rejected hash request makes the run fail.

## Independent server observations

`observation.json` is a protected local file, refreshed atomically at least once
every30seconds from the actual test host/private operator metrics and drill
runner. The example intentionally has null measurements. A script that merely
copies that example or sets `bounded:true` is not evidence. This harness does
not open a public metrics endpoint or invent an operator authentication token.
Integrate with the authenticated private operations export and existing host
collector; keep any operator session outside load reports.

A concrete local adapter is provided:

```bash
node scripts/load-collect.mjs baseline /secure/permit.json /secure/private-metrics.json /secure/load-A-ready.json /evidence/load-A-baseline.json
node scripts/load-collect.mjs collect /secure/permit.json /secure/private-metrics.json /secure/job-evidence.json /evidence/load-A-baseline.json /secure/observation.json
```

Run the collector on the actual application host. After ramp-up, the browser
runner writes `baseline_requested_at` and `run_id` to its protected output
report, then waits at most 60 seconds. Securely copy that ready checkpoint to
`load-A-ready.json`, obtain a fresh private metrics export after its timestamp,
and run `baseline` once. The baseline file is created exclusively and must not
be replaced. It binds the exact run, origin, source and five images, the actual
server sample timestamp, original process-start timestamp and all counters.

Run `collect` with that baseline immediately, then every 30 seconds, and copy
the owner-only aggregate output to the generator. The runner starts its timed
window only after observing that matching new baseline. Baseline capture must
be no more than 60 seconds before timed start; missing/late coordination blocks
the run. Prepare an existing protected local job or operator procedure to watch
the checkpoint and refresh exports; do not improvise this timing after launch.
Use a separate new baseline for B and overload, and preserve each baseline file
alongside its report so its recorded SHA-256 can be checked. Export `private-metrics.json`
through the current private MFA `/operations/metrics` form; never expose that
listener publicly. The adapter consumes its exact `{sampled_at,
window_started_at,server:{api,message,match},process:{go_heap_bytes,goroutines}}`
JSON. It reads real local `/proc/meminfo`, converts disjoint fixed histograms to
conservative bucket p95 bounds, retains the oldest input sample timestamp and
preserves each metric scope. Private operator sessions must be renewed during
a six-hour run using the existing MFA workflow.

`job-evidence.json` contains `origin`, `source_sha256`, `application_host:true`,
`observed_at`, `queues`, `workload`, and optional `overload` fields as shown in
the observation example. Values come from measured jobs/drills; the host
assertion must identify the actual app machine. Separate job-file matching overrides are rejected to prevent mixing measurement
windows. The adapter preserves the backend metric scope. The new conservative
`available_candidate_to_commit_upper_bound` runs from the later selected
participant's queue request reception through commit, including owner-mailbox
and pending paid-usage work. It can overcount cooldown or re-eligibility wait,
which is conservative. Historical `selected_pair_commit_processing` alone
cannot pass this gate; it is not silently relabeled. No arbitrary private fields are projected.

The collector subtracts the protected baseline from every histogram bucket and
sample count before calculating p95. Historical healthy traffic and ramp-up
cannot dilute a later performance collapse. Counter regression, changed scope,
or a different process-start timestamp rejects the observation; restarting the
application requires a new complete run. `window_started_at` is the actual
baseline sample time, never the process start or a newly invented timestamp.
The baseline hash and run identifier stay fixed through every report sample.
A metric with no samples since baseline is explicitly `samples:0,p95_ms:null`
and remains unassessed; all three metrics must show positive, increasing
in-window counts by the end. A null or absent metric cannot become 0ms.

Bind observations to `origin`, `source_sha256`, `run_id` and `baseline_sha256`;
`window_started_at` must be at or before the load window but no more than
60 seconds earlier, and `observed_at` must stay within 45 seconds. Record
actual host `MemTotal` and `MemAvailable` bytes (not free-process-heap), Go heap
bytes, current goroutines, bounded queue/high-water observations, ungranted
capture and overdue-job counts. Specify a reviewed goroutine bound; never set
it from the largest value seen after the fact. The last-quarter average heap
and goroutines must remain within10% of the first-quarter average; run a longer
investigation if this coarse stability check hides a trend. Every sample needs
at least25% host availability and at least1024MiB available.

Server processing metrics are deliberately separate from user/network elapsed
time. Supply conservative p95 bounds and positive sample counts:

| Key | Required scope | Strict p95 |
| --- | --- | ---: |
| api | `ordinary_api_server` | <300ms |
| message | `message_owner_processing` | <100ms |
| match | `available_candidate_to_commit_upper_bound` | <1000ms |

Use aggregate server histograms or reviewed server timing observations, never
browser RTT or the old coordinator probe as substitutes. For a fixed bucket
histogram, use the finite upper bound of the bucket containing the95th percentile;
an unbounded bucket cannot pass. Ordinary API excludes external-provider work
and WebSocket lifetime. A matching selection-scan or owner-only metric that excludes pending
authorization/commit delay cannot be relabeled as
`available_candidate_to_commit_upper_bound`. The conservative metric may fail
slow/cooldown cases unnecessarily; investigate and measure those cases rather
than replacing the metric with a narrower successful scan. Call setup is measured from real Call/Accept
signaling to peer connection and must have>=95% successful attempts and p95<10s.

`workload.payment_job`, `backup`, `moderation` and `safety_event` are monotonically
increasing completed-work counters from controlled sandbox fixtures and actual
job/backup/moderation execution. The driver takes its first fresh, run/baseline-bound counter snapshot with an
observation timestamp at or after timed start, then counts only progress in
later observations. Pre-run counts and completions before that first snapshot
are conservatively excluded;
at least one of each must complete during the timed window, with no growing
payment backlog. No background-work claim is made from merely having a timer
configured. The operator arranges these fixtures using the phase-specific
runbooks. In overload observations record actual safety continuity and verified
relay allocation cleanup timing; preserve the underlying private evidence
separately and bind it through the launch evidence manifest.

## Machine-readable acceptance

Reports use `schema_version:notitle-capacity-v1`, bind origin/source/images and
permit hash, and contain UTC ISO start/end timestamps, samples, measured setup,
fixed workload counts, exact baseline hash/time and fixed failure codes. They never contain identity,
profile, text, credential, URL-query, SDP or ICE fields. `result` is informative:
launch review recomputes `validateCapacityReport(report)` or
`validateOverloadReport(report)` exported from `scripts/load-contract.mjs`.
Missing server observations, real cleanup evidence, background work, full-path
match timing or prerequisites make reports fail closed. Signoff and artifact
checksums establish who reviewed a result; they cannot turn a null measurement
into a passing one.

The staging acceptance origin can differ from production. Record that mapping
and any reviewed origin/release-mode build differences in the release manifest;
never weaken load isolation to stress the public domain. See Phase10 launch
instructions for the exact release and artifact binding policy.

Offline checks:

```bash
node --test scripts/tests/load-*.test.mjs
node --check scripts/load-browser.mjs
node --check scripts/load-soak.mjs
```

These fixture tests cover permit safety, complete/missing performance evidence,
real-media markers, frozen RTP, sample gaps, memory/backlog thresholds, malformed
counts, overload cleanup, protected-file handling and private-field projection.
They do not start a browser or make a network request.
