# Phase 5 text and safety protocol

The Phase 4 same-origin cookie, CSRF, ticket, envelope, generation, epoch and single-owner rules remain in force. `docs/phase4-protocol.md` defines the base transport. Text and safety capability is server controlled: `session.ready` and state events expose `text_enabled`. Production must not enable text without the safety service and its operational acceptance. Call, WebRTC and friendship events remain unsupported in this phase.

## Text messages

Every command has `v`, `id`, `type`, `generation`, `interaction_id`, `epoch` and `payload`. Only a currently authorized participant in that exact connected interaction may send or acknowledge text. A client cannot supply a target identity, speaker, timestamp, server sequence for a new message, entitlement or restriction state.

| Event | Payload | Meaning |
| --- | --- | --- |
| Client `chat.send` | `client_send_id`, `text` | A new message or retry of the same content and send ID in the same interaction |
| Client `chat.delivery_ack` | `server_sequence` | Recipient acknowledges that the connected browser rendered a received message |
| Server `chat.message` | `server_sequence`, `client_send_id`, `sender`, `text`, `sent_at`, `delivered`, `replay` | Server-attributed message; `sender` is `self` or `peer`, scoped to the viewer |
| Server `chat.ack` | `client_send_id`, `server_sequence`, `status` | `accepted` means the in-memory relay accepted it; `delivered` means the recipient client acknowledged rendering |

The transport command ID and `client_send_id` have different jobs. Retry may use a new command ID after reconnect, but must preserve the send ID and content in the same interaction epoch. The actor assigns a monotonically increasing sequence within each interaction and rejects reuse of a send ID for different content. A receipt never proves that a human read the message. Missing acknowledgements produce an uncertain delivery state; clients must not label them as delivered or silently retry into another interaction.

The server retains at most 30 recent messages and 64 KiB of message payload per interaction, whichever limit is reached first. A separate bounded dedupe collection retains up to 16,384 accepted send IDs for that interaction. IDs are not evicted and later treated as new sends: at the dedupe ceiling, new sends receive a capacity response until the conversation ends. A sender may burst eight messages, with a sustained allowance of two messages per second. These are protective initial limits, not measured capacity results.

Text must contain 1–2,000 Unicode code points, occupy at most 6 KiB in UTF-8, and fit the ordinary 8 KiB encoded event after envelope overhead. Invalid UTF-8 and unmatched escaped UTF-16 surrogates are rejected. Unsupported control and format characters, including bidi override/isolate controls, are rejected without rewriting the supplied text. Newlines, ordinary RTL letters, emoji joiners, variation selectors and joining characters needed by normal writing are preserved. JSON escaping is accounted for before acceptance. User text is displayed using escaped text nodes only: no HTML, Markdown, embeds, previews or automatic links. Literal markup remains literal text.

## Reconnect and clearing

Reconnect keeps the Phase 4 same-instance, same-identity, same-epoch proof and 25-second deadline. A resumed connection first receives `session.ready`, then up to 30 individual `chat.message` events with `replay: true`. Each remains within 8 KiB; a complete transcript is never put into a large state event. The fresh 32-entry outbound queue accommodates the ready event and bounded replay. Delivery status accompanies each replayed message, so a second replay ACK stream is unnecessary. The client deduplicates by interaction and server sequence and keeps a bounded in-memory transcript.

`state.sync` provides metadata, not unbounded chat history. Next, End, Block, logout, deletion and reconnect expiry clear ordinary message state and the client transcript. Restart loses all ordinary chat and retry data. A frozen report draft is the explicit, time-limited exception described below; it is not conversation history. No transcript, draft, ticket or resume secret enters browser persistence or ordinary application logs.

## Report and block REST contract

Use the canonical authenticated, CSRF-protected `/api/v1` REST routes. They dispatch to the same coordinator as realtime commands. JSON must contain exact schema fields; client-transcript fields and arbitrary subject IDs are rejected.

| Route | Request | Response |
| --- | --- | --- |
| `POST /reports/begin` | Current `generation`, `interaction_id`, `epoch`; optional `block`; **or** an `ended_ref` and optional `block` | `handle`, `expires_at`, `messages`, `metadata_only`, `blocked` |
| `POST /reports` | `handle`, `submission_id`, `category`, `statement`, `selected_sequences` | `case_ref`, `submitted_at`, `blocked` after durable commit |
| `POST /blocks` | Current `generation`, `interaction_id`, `epoch`; **or** an `ended_ref` | A self-owned block view after the applicable persistence operation |
| `GET /blocks` | No target identity | `{blocks: [...]}`; each self-owned view contains `ref`, `display_name`, `created_at`, `durable`, `pending` |
| `DELETE /blocks/{blockRef}` | An authorized self-owned opaque block reference and empty JSON body `{}` | `{removed: true}` only after the guarded unblock operation |

Current-interaction and ended-reference authorization are mutually exclusive. `generation` is the live connection generation, not a user-selectable identity version. A current Report Begin verifies participation and copies only eligible messages already held by the server. Its 256-bit opaque handle expires after two minutes. Each evidence selector item has `server_sequence`, `speaker` (`self` or `peer`), `text` and `sent_at`. Leaving after Begin does not destroy that frozen draft. The service limits drafts to 64 globally and two per identity, with the same 30-message/64-KiB payload ceiling per draft.

When an interaction ends, a state event can include `ended_report_ref` and `ended_report_expires_at`. This self-owned, opaque reference lasts ten minutes and holds participant/timing metadata without ordinary message content. The collection is bounded at 2,000 references. Begin with that reference returns `metadata_only: true` and no transcript; the user must supply a statement. After expiry or restart, the formal grievance route is the fallback. An ended reference never grants access to another user's case or an arbitrary identity.

Submit accepts selected server sequences, never user-written transcript objects. Sequences must be distinct and present in the authorized frozen draft; at most 30 may be selected. The short statement is stored separately as a user allegation, capped at 2,000 Unicode code points and 6 KiB. Empty statements are permitted only when evidence is selected. The stable submission ID is 16–64 URL-safe characters and prevents duplicate cases on retry; changing details under an existing ID conflicts. The coordinator supplies private subject and attribution records to the storage service. Only selected server-attributed evidence is persisted with the case.

Categories are `harassment`, `threats`, `doxxing`, `confidentiality`, `targeted_false_accusations`, `scams`, `impersonation`, `suspected_underage_access`, `sexual_misconduct`, `spam` and `other`. Category alone does not establish severity or guilt. Manual review and urgent statements can escalate a case. Unrecorded audio cannot be replayed or presented as verified audio evidence.

## Safety ordering and ownership

Report & Block is Begin with `block: true`: the coordinator freezes eligible evidence, imposes the local directed block and ends communication in one owner turn. Submit persists the report, selected evidence and an applicable registered-to-registered block transactionally. A failed storage operation must not display “Report submitted”; the local block stays active and the draft keeps its original hard expiry. Retry uses the same submission ID. The UI explains the failure and offers the grievance route.

Either block direction prevents matching, text and reconnect. Block views reveal only blocks owned by the requester; they never reveal who blocked the requester. Guest-involving blocks remain temporary. In-session registration rebinds the same slot and block endpoints; promotion is possible only once both endpoints are durable accounts. Promotion has a coordinator-issued lease, bounded external database work and an explicit completion. An unblock reserves its own lease **before** durable deletion, excluding concurrent promotion and re-block races. Uncertain completion remains conservatively blocked until resolved; a late callback cannot silently erase a newer restriction.

Each identity's local block collection and durable block collection are each capped at 100; the merged self-owned view can therefore contain up to 200 distinct temporary/durable records. A trusted authorization snapshot may include at most 4,000 distinct blocked identities across both directions. The storage query reads one additional result to detect overflow; it must fail authorization closed rather than truncate the exclusion set. This bound is separate from the 4,000-record global local-block collection and is not a claim about tested memory capacity.

When safety is enabled, registration includes a durable pending-safety fence in the account transaction. The account cannot obtain new realtime authorization until its authoritative in-session block/restriction snapshot is finalized and the fence is removed in one transaction. A crash cannot turn an unfinished promotion into unrestricted account access: orphaned pending fences remain closed after restart and require private operator reconciliation, never automatic expiry. Fresh upgrades when safety is disabled create no new handoff fence; the feature flag cannot clear a pre-existing durable fence. Account authentication/settings and the grievance route remain separate from interaction admission. Concurrent upgrades are serialized through this handoff boundary so both endpoints cannot independently miss a required durable block.

After a successful report commit, the owner clears its frozen evidence and retains only the bounded receipt and request digest until the original draft expiry. Identical retry returns that receipt without recreating evidence or reapplying a subsequently removed block. Changed details remain a conflict. Promotion and restriction callbacks bind the exact lease/version/decision so an older storage completion cannot overwrite a newer unblock or moderation decision.

Storage and authorization work remain outside the coordinator loop. Trusted services capture the authorization fence before refreshing the principal and reading private state. The owner checks that fence and current identity/session/generation before accepting safety commands. Durable transactions recheck the account/session guard. Successful restriction changes invalidate live authorizations and immediately end affected interaction ownership; failed publication closes safety readiness rather than leaving active users authorized against stale safety data.

Internal `Guard`, `Subject`, `PreparedReport` and `BlockMutation` objects deliberately reject JSON serialization. Report evidence requires case-scoped speaker references and restricted subject mapping when persisted. Ordinary chat has no database table. New report/evidence retention and operator audit are covered by the Phase 5 safety schema and acceptance documents; reviewed legal retention and monitored operator coverage remain launch gates.
