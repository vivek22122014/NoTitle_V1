# Phase 7 audio relay and call-control runbook

This runbook applies to blueprint V3.2 and the cumulative Phase 7 source. It is a deployment and acceptance procedure, not evidence that a relay VM, certificate, firewall or live audio test has been provisioned. Read `PHASE7_STATUS.md` for checks actually executed and `docs/phase7-acceptance.md` for the complete acceptance matrix. Keep `AUDIO_ENABLED=false` until the relevant environment is prepared; production additionally requires actual safety evidence before `AUDIO_SAFETY_VERIFIED=true`.

## Topology and responsibility

Keep one application owner on the existing 2-vCPU/4-GiB application candidate, with Caddy, static SvelteKit and private PostgreSQL. Use the separately budgeted 1-vCPU/1-GiB relay candidate for coturn and its local supervisor/watchdog. The supervisor is narrow infrastructure control, not another application or public account service. These host sizes are planning candidates and require measurement under the combined workload.

The browser exchanges authorized signaling through the existing authenticated WebSocket. Media is audio-only Opus with DTLS-SRTP and relay-only ICE. The application issues no usable relay credentials before call acceptance. The supervisor binds random call-specific endpoint usernames to private leases, controls allocation cancellation and detects credential replay after revocation. The call-control worker performs network I/O outside the coordinator.

| Path | Intended exposure | Required deployment check |
| --- | --- | --- |
| Website and WebSocket | Existing HTTPS web host | Same-origin authentication and existing Caddy routing; ordinary Cloudflare HTTP proxy is permitted here |
| TURN UDP/TCP 3478 | Dedicated DNS-only TURN hostname | Correct public relay address, valid allocation authentication and no private-target relay |
| TURN TLS/TCP 443 | Same dedicated relay host | Publicly trusted TURN certificate; actual TURN-over-TLS test, not an HTTPS request |
| Relay UDP 49152–50175 | Dedicated relay host, exactly 1,024 ports | Host/provider firewall and coturn range agree; no wider accidental exposure |
| Application-to-supervisor | Restricted private HTTPS path with mutual TLS and independent token | Only the authorized application host/protected tunnel can connect; wrong certificate/token fails |
| coturn administration and metrics | Relay-local/private only | No external reachability, raw CLI proxy, public allocation viewer or user-identifying metric labels |

Do not cohost TURN on the application IP to save the relay allowance: the intended HTTPS and TURN/TLS listeners both need TCP443, and media abuse would share the application's failure domain. Do not place the TURN hostname behind Cloudflare's ordinary HTTP proxy. Do not open public database, application-management, coturn CLI or supervisor ports.

## Prepare a controlled staging environment

1. Prepare authentic dependency locks and format the source with `./scripts/bootstrap.sh prepare` on the supported Docker/registry environment. Review generated lock and formatter changes. Run `./scripts/verify.sh` and retain its exact result; a missing tool or package is a blocked check.
2. Review `deploy/turn/README.md` and its pinned relay deployment files. The authored build command is `docker compose -f deploy/turn/compose.yml build` from the repository root. Provision the temporary India-region relay candidate only through the operator's approved account. Record provider, region, machine resources, OS, image digest and actual billing terms. This source implementation does not provision or purchase a VM.
3. Create the real DNS-only TURN hostname and a publicly trusted certificate covering that hostname. Establish certificate renewal without exposing an unnecessary permanent service. Use separate certificates/CA trust for the private mutual-TLS control path; the public TURN certificate does not authorize application control.
4. Provision the protected private control token and certificate keys outside the source tree and application frontend. The control token is 64 hexadecimal characters encoding 32 random bytes, readable only by the required service identity; the relay template uses container UID65532. The supervisor generates the TURN signing secret and CLI password into its private tmpfs on each boot. Never put secrets in shell history, URLs, ordinary logs, generated support bundles or source archives.
5. Apply the narrow host/provider firewall rules in the table above. Confirm private, loopback, link-local, metadata and multicast relay-target denial for IPv4 and IPv6. Deny unauthenticated relay use and verify there is no unintended plaintext/private control exposure.
6. Start coturn with its supervisor/watchdog following the relay deployment README. Confirm startup allocation clearing and state resynchronization before leases are admitted. The app and supervisor must agree on the actual public relay addresses and ports. A healthy process or open TCP socket alone is insufficient.
7. Configure the application with the `AUDIO_*` inputs in `docs/configuration.md`. Base stacks leave audio off; the optional `deploy/audio/compose.app.yml` overlay mounts its four control files and enables the app settings without adding an application-host service or public port. Merge it after the ordinary deployment files only for the prepared environment. Keep exactly one API instance and retain all existing safety, moderation, deletion and identity prerequisites. Staging can set `AUDIO_ENABLED=true` to gather controlled evidence; production cannot use that exception to bypass the safety assertion.
8. Use synthetic participants and isolated browser contexts. Exercise random interactions and accepted friend audio invitations for Guest–Guest, Guest–Account and Account–Account. Verify text, Report/Block, Next and End remain reachable throughout. No person needs to register or purchase Premium to request or accept audio.
9. Complete every acceptance row below and save a sanitized record containing commands, versions, timestamps, device/network combinations, measurements and failures. Fix failures and repeat the affected tests. Do not claim passed real-device/coturn tests from mocks or a dependency-free source test.
10. Before production, finish the existing policy, staffed moderation/grievance, retention, backup/recovery, host-security and business gates. Set `AUDIO_SAFETY_VERIFIED=true` only against the reviewed passing evidence. A working staging call does not establish public-release readiness.

## Consent, negotiation and browser behavior

Call states cover IDLE, REQUESTED, RINGING, ACCEPTED, CONNECTING, CONNECTED and ENDED. One request may be outstanding per interaction. Ringing expires after 30 seconds, and decline applies a 15-second cooldown. Simultaneous requests must converge on one call with one assigned offerer. The server checks call reference, current connection generation and interaction epoch on signaling; a peer cannot choose an arbitrary recipient. Credential create/refresh also supplies a server-issued negotiation counter, and delayed SDP, ICE or connected acknowledgements from a previous negotiation are rejected. See `docs/phase7-protocol.md` for the exact envelopes.

The caller's explicit Call action permits requesting their microphone. The recipient's microphone remains untouched until their own Accept action and browser permission. Denied permission, unavailable devices and restricted playback must result in an understandable status and text fallback. A permission promise resolving after End, Next, disconnect or unmount must immediately stop any returned tracks. Mute disables the outgoing audio track; End stops capture and closes the peer connection.

Reconnect may preserve the text interaction under its existing 25-second grace, but must not silently reopen a stopped microphone or restore an ended call. Rotation and resize must preserve the interface without creating another call. Mobile keyboard, safe areas, background behavior and focus require physical-device verification, with desktop feature parity.

Validate the complete SDP, including every media section, connection address and embedded candidate, as well as separate trickle candidates. Accept only the configured public relay addresses and audio policy. Reject host/server-reflexive candidates, unrelated relay addresses, video and application/data sections. Browser relay-only configuration alone is not the security boundary. Public landing pages must not load or activate call media code.

## Credentials, leases and enforced shutdown

| Control | Required bound | Meaning |
| --- | --- | --- |
| Initial TURN credential validity | 10 minutes | Limits credential replay duration; does not terminate an existing allocation by itself |
| Refresh | At 5 minutes while authorized | New credentials require the same live accepted call and healthy control path |
| Private application call lease | At most 30 seconds, renewable only while valid | Bounds orphaned media after application failure independently of credential expiry |
| Normal revocation | Allocations removed within 5 seconds | Must be measured against real coturn, including fresh allocations created with revoked credentials |
| Supervisor restart | Clear old allocations and resynchronize before new leases | Lost RAM must not revive a previously revoked credential or old application instance |
| Supervisor failure | Watchdog prevents uncontrolled relay forwarding | Verify crashes and hangs; a healthy coturn process is unsafe if enforcement cannot run |

Next, End, Block, logout, deletion, loss of authorization and removal of an active friend interaction must close media. Stop issuing new credentials, stop browser tracks, close the peer connection and revoke the relay lease. The browser's cooperation is not sufficient: use a controlled client that deliberately keeps its allocation alive to prove supervisor enforcement.

After cancelling current allocations, continue monitoring the revoked usernames through credential expiry. A revoked credential can still authenticate with coturn before expiry; every allocation it recreates must be detected and cancelled within the normal-operation target. Include credential refresh overlap: revoking only the newest username cannot leave an older username active. Do not replace this control with a shorter credential expiry or a promise that browsers close voluntarily.

When control state is uncertain, stop accepting new calls and fail closed. Keep ordinary text available only while its own authorization/safety dependencies remain healthy. After a supervisor restart, an old app instance, stale control response or delayed renewal must not revive cancelled media. The relay README describes the actual startup/watchdog mechanism; test that mechanism rather than just the in-process lease model.

The authored Linux relay container runs `relay-supervisor` as PID1, with coturn and a watchdog as its children. A one-second successful enforcement heartbeat feeds a three-second watchdog. Failed inventory/cancellation, missing heartbeat or supervisor death stops coturn. Each container boot rotates the TURN signing secret, CLI password and supervisor boot ID, so pre-restart credentials cannot authenticate against the new secret. The controller caps its internal lease at 24 seconds and subtracts eight seconds from the application's original transmitted deadline: six seconds for polling, administrative I/O and cancellation confirmation, plus two seconds of allowed cross-host clock skew. It uses the earlier deadline and rejects a lease without positive remaining time. Local elapsed deadlines use a monotonic clock; these source mechanisms still require real process/transport timing tests.

An administrative cancellation command returning a prompt is not proof that an allocation ended. Explicit revoke and resynchronization require a second inventory showing the relevant allocations absent. If a requested cancellation is still present two seconds later, the supervisor stops coturn. Test this with deliberately delayed cancellation and credential replay, measuring from the original revocation or lease-loss event, not from when the next sweep starts.

Synchronize the application and relay host clocks and monitor their offset at no more than two seconds. The skew budget is an operating precondition; the control protocol cannot independently measure actual cross-host offset. It accepts a transmitted deadline no later than 32 seconds ahead of receipt to accommodate that bound, then applies the earlier internal deadline above. With equal clocks and no transit delay, a 30-second grant normally receives 22 seconds before cleanup begins. Include both directions of skew and clock-health failure in staging; keep audio disabled when clock health cannot be trusted. No environment variable increases the public 30-second orphan target or five-second normal-revocation target.

After validating a credential grant, the application schedules refresh five minutes after its own receipt time. This avoids asking a slower relay clock to rotate credentials before its five-minute interval has elapsed. Client/owner expiry remains the earlier of the relay's stated expiry or ten minutes after receipt. Exercise both directions of clock skew across multiple renewals in the long-call tests.

The image is pinned to `coturn/coturn:4.18.0-r0`; resolve its immutable digest and validate the administrative `ps`/`cs` format on that exact binary before acceptance. The deployment README explicitly records that tag-specific CLI compatibility and real cancellation were not executed in the authoring environment. If parsing fails, the supervisor stops the relay; do not loosen parsing merely to make a health check green. Certificate renewal requires an orderly drain and container restart in this template.

The authenticated private `GET /v1/metrics` endpoint shares the supervisor control listener. It exposes only `active_calls`, `revocation_records`, `allocations`, `cancellation_requests`, `control_failures`, `last_scan_at` and `ready`. Scrape only over the protected control path; retain no per-user labels. These counters do not measure end-to-end cancellation latency, audio quality or billed egress. Collect those separately through controlled timing tests and aggregate host/provider network counters. No public metrics port or paid monitoring service is added.

## Required runtime evidence

| Area | Test and evidence to record |
| --- | --- |
| Consent and permission | Page load/incoming request do not capture; explicit Call/Accept, denied/dismissed permission, missing/busy microphone, late permission resolution, mute/unmute and End on real browsers |
| Call races and scope | Reciprocal requests, duplicate acceptance, simultaneous decline/End, wrong offerer, stale generation/call/epoch, interaction switch and maximum outstanding-request behavior |
| Network privacy | Inspect the actual forwarded SDP and ICE for all test browser pairs; prove no client host/server-reflexive address reaches the peer and no video/data section can be negotiated |
| Network coverage | Android Chrome and iOS Safari first, desktop Chrome/Edge/Firefox and Safari where available; Wi-Fi, cellular and a network restricting UDP with TURN/TLS443 fallback |
| Existing workflows | Text during ringing/connected audio, friend invitation consent, current interaction safety reports, Report & Block, guest registration, account revocation, deletion and relationship removal |
| Reconnect and lifecycle | Mobile network switch, background/foreground, locked screen, refresh, old half-open socket, explicit takeover, process restart and late async callback; no automatic microphone restart |
| Long calls | Beyond 5-minute refresh and 10-minute original expiry, with actual allocation/credential overlap and ICE renegotiation behavior; no hidden direct-media fallback |
| Enforced teardown | Deliberately uncooperative client after End/Next/Block/Delete, replay of current and previous credentials, allocation recreation up to credential expiry; report measured maximum cancellation delay |
| Failure isolation | Kill/hang app, supervisor and coturn separately; lose private network/control authentication; restart in different orders; report measured orphan deadline and watchdog behavior |
| Capacity and abuse | 25 simultaneous calls within 200 connected users, additional-call rejection, credential/candidate flood, allocation exhaustion, port exhaustion, slow control and malformed CLI responses |
| Retention and logging | No ordinary audio/SDP/ICE/credential SQL row, browser persistence, logs, traces, core dump or packet archive; report statements/selected text remain governed by existing safety retention |
| Accessibility and layout | 320–430 CSS px phones, tablet and 1024–1920 px desktop, portrait/landscape, 200% text, screen reader, keyboard-visible composer/call/safety controls and 44 px targets |

Corporate networks can block audio despite TLS443 fallback. Show a clear failure and retain text; do not imply that every workplace network is supported. NoTitle provides no audio recording, so a moderator cannot replay an unrecorded conversation. The reporting path may preserve only the latest accepted call's server-derived reference and requested/accepted/ended times, frozen by the existing report/ended-reference lifecycle and encrypted only upon report submission. The audited case view must distinguish that metadata and a user's allegation from proof of speech. A participant may record independently or identify another person from their voice/content; product copy must not promise otherwise.

## Capacity and scaling

The minimum remains **200 simultaneous connected participants including 25 two-person calls**. Fifty callers and up to 100 waiting users are subsets of the connected total, not extra users. The configured limits are admission controls; they are not benchmark evidence.

Four allocations per participant imply `25 × 2 × 4 = 200` simultaneous allocations before operational headroom. Measure actual per-browser allocations, both transports, refresh/ICE overlap and cancellation churn. Configure adequate quota headroom within the 1,024-port range, and verify that reserve does not defeat total-call admission or permit unbounded abuse. Port count, allocation count and concurrent-call count measure different resources.

The authored template sets 256 total allocations: the required 200 plus 56 initial reserve, which is a candidate bound rather than measured headroom. The supervisor counts old/new credential generations together toward four allocations per participant. It retains at most 2,048 call/revocation records and denies new work when safe tracking capacity is exhausted. coturn bandwidth ceilings are 64,000 bytes/second per allocation and 16,384,000 bytes/second in aggregate; they are abuse limits, not evidence that the small relay VM can sustain those rates. The container's 768 MiB memory limit also needs whole-host verification on the 1 GiB candidate.

Run the mandatory mixed workload on the intended application and relay hosts: 200 authenticated sockets, 25 active calls, normal text and maximum-size bursts, friendship presence/list churn, reconnect/Next churn, moderation and two concurrent password hashes. Include the dense 20,000-relationship Phase 6 scenario. Record duration, offered/completed work, command p50/p95/p99, match/text/control latency, errors, dropped work, application and relay CPU/RSS, database/pool wait, allocation count, real relay bytes and cancellation delays. Keep at least the blueprint's 1 GiB application-host memory headroom under the accepted workload; tune from whole-host measurements.

Both mandatory workloads run at least six hours: A has 50 callers, 100 waiting and 50 text participants; B has 50 callers and 150 text participants. Callers may also text. The acceptance matrix sets the processing, API, match, call-setup and success-rate criteria and the excess-load check at 400 offered connections. Never lower the user's 200-connected/25-call minimum to fit an unmeasured host.

Increase capacity only after the current target passes. First remove unnecessary signaling/control work and investigate measured allocation or CPU pressure. Resize the relay when it lacks CPU/memory/throughput headroom; increase an egress allowance only after comparing the real bill and traffic. Optimize or vertically resize the application/database before splitting PostgreSQL. Multiple API instances require a reviewed live-state ownership/routing design; adding replicas cannot share this coordinator's RAM.

## Cost assumptions and scenarios

These figures reproduce the finalized blueprint's planning assumptions: **₹97/USD, 18% tax**, full-month USD24 application VM, USD6 relay VM, USD2 backup/log/request allowance and ₹1,500 annual domain allowance. They are arithmetic scenarios, not fresh provider prices, a tax determination or a purchasing recommendation. Exclude staff time, payment fees, excess transfer/storage, currency/card fees and temporary staging; retain a contingency separately. Current vendor terms must be verified when provisioning.

| Scenario | Calculated monthly INR | Calculated annual INR | Scope |
| --- | ---: | ---: | --- |
| Relay component only | ₹686.76 | ₹8,241.12 | USD6 × 97 × 1.18; already included in the full-V1 baseline below |
| App, backup/log allowance and domain; relay absent | ₹3,100.96 | ₹37,211.52 | Controlled text-only operation; does not meet the requested full-V1 audio requirement |
| Full planned infrastructure with dedicated relay | ₹3,787.72 | ₹45,452.64 | Original host sizes, baseline allowances and domain; no new paid supervisor or media subscription |
| Full baseline plus ₹250/month reserve | ₹4,037.72 | ₹48,452.64 | Reserve is funding set aside, not a vendor subscription |
| Temporary staging or usage above allowance | Actual additional billed amount | Sum of actual additional charges | Provision temporarily, record duration/usage and remove unneeded resources after approved tests; no permanent staging subscription assumed |

Audio bandwidth depends on actual on-wire rates, two-way activity, transport overhead and churn. For planning only, if each direction averages **64–128 kbit/s including overhead**, a two-person call produces approximately **0.0576–0.1152 decimal GB of relay egress per call-hour**. At 25 calls continuously for a 30-day month, that is about **1,036.8–2,073.6 GB**, before other traffic and deployment-specific accounting. This is a hypothetical traffic scenario, not measured Opus usage or a bill; do not confuse decimal GB with provider GiB allowances or assume pooled allowances without checking the contract. Measure real counters and bills before choosing a larger transfer plan.

Avoid a managed SFU/media platform for this two-person relay-only MVP unless measurements or future group-call requirements justify it. Avoid Redis, another database, paid presence, recording storage, transcription, public metrics, additional frontend hosting or permanent staging. These additions do not satisfy the currently required enforcement tests.

## Incident and rollback behavior

If revocation, replay detection, watchdog behavior or relay privacy fails, disable audio admission and explicitly terminate accepted calls through the private control path. If that path is unavailable or untrustworthy, the relay host's controlled emergency stop must stop forwarding; changing only the app flag or closing web sockets is insufficient. Preserve sanitized aggregate failure evidence and fixed operational error labels, never raw credentials or media.

After resolving the cause, repeat the failed safety test and affected long-call/crash cases before reenabling audio. Rotate compromised signing/control secrets with supervised teardown and clear allocation state; do not merely overwrite a file while assuming active media ended. Restart reconciliation and fresh consent are required. Keep one trusted application instance, preserve unrelated durable account/friend/safety data and independent deletion journals, and never use database DOWN migrations as an audio rollback.
