# Phase 9 operating procedures

Version: `operations-2026-10-10-draft`. This runbook is ready for operator rehearsal. It does not appoint staff, authorise external disclosures or prove production readiness. Assign actual people/contact channels and record a completed drill before public real-user testing. Follow `phase9-legal-matrix.md`, `phase9-acceptance.md` and the feature-specific Phase 5/7/8 runbooks together.

## Coverage record

| Duty | Primary | Backup | Required evidence |
| --- | --- | --- | --- |
| Safety and grievances | Unassigned | Unassigned | Named Grievance Officer, staffed urgent coverage, monitored intake and measured escalation |
| Billing/refunds/disputes | Unassigned | Unassigned | Merchant access, original-instrument refund competence, reserve/settlement reconciliation |
| Privacy/legal holds | Unassigned | Unassigned | Approved policy/source/effective dates, ownership verification, restricted export/disclosure access |
| Host/security/recovery | Unassigned | Unassigned | Private MFA access, independent key recovery, tested backups/journals, external monitor |

One person may cover several duties; nobody may assume the other person is watching. The private coverage document records shift start/end, approved monitored device/channel, absence handoff and escalation fallback. Staff need not receive raw case evidence in notifications. The incoming legal/business mailbox, where required, is monitored separately; NoTitle adds no outgoing user-email service.

## Private operator and policy commands

Run `adminctl` only on the approved private workstation/host with owner-only input files. Keep passwords, MFA codes, keys and DSNs out of shell arguments and command history. Existing provisioning remains an explicit migration-role operation; no default identity is created. `-action manage` accepts the lifecycle input documented by `adminctl`: target username, expected generation, action (`roles`, `disable`, `enable`, `reset_mfa`), reason and fresh authorizer username/password/TOTP. MFA reset additionally requires an exclusive protected enrollment output; verify the actual operator before importing it. On ambiguous commit outcome preserve enrollment and investigate the current generation instead of blindly retrying a reset.

Install the **already reviewed** retention manifest as an immutable DB version with:

```bash
adminctl -action install-retention-policy \
  -policy-file /private/retention.json \
  -input-file /private/policy-approval.json \
  -database-url-file /private/migration-dsn \
  -mfa-key-file /private/admin-key
```

`policy-approval.json` contains only `authorizer_username`, `authorizer_password`, `authorizer_code` and `reason`. The command requires the migration DB role and a current active owner with fresh password/single-use TOTP. It validates the approved manifest, stores its exact canonical digest and audits the real authorizer. Reusing a version with changed content fails. Install the matching manifest on the application through the reviewed release procedure. This command cannot create counsel/accountant approval, configure external retention, or activate a draft policy legitimately.

For evidence, prepare/download from the private case page and protect the separately displayed base64 key. On an authorised offline workstation:

```bash
adminctl -action decrypt-evidence \
  -encrypted-file /private/notitle-evidence.nte \
  -export-key-file /private/evidence-key \
  -output-file /private/new-evidence.json
```

The output must be a new protected file. Never paste evidence or its key into a terminal command, a support reply or a general channel. Record lawful purpose, recipients and copy-expiry/hold obligations; cryptographic integrity does not authorise disclosure.

## Existing legal-hold conversion

Existing Phase 5 holds continue blocking relevant erasure. Runtime credentials can read them but cannot create or release them through the old path. Convert deliberately: an authorised owner creates an equivalent purpose-scoped Phase 9 hold with the reviewed reason and next-review date, then verifies its independent journal and exact off-host record inventory. During controlled maintenance, the migration operator may append the reviewed legacy release action and update that specific legacy hold only after transactionally confirming the equivalent active journal-backed hold. Preserve the old hold and action history. Record the authorising owner-MFA audit, mapping and evidence; never guess approval/review dates or delete the legacy row to make a purge succeed. The temporary overlap preserves both barriers until conversion is verified.

## Critical safety or urgent grievance

1. Acknowledge the private alert and open the case through the MFA console. Confirm received time, category, deadline, authority and current owner. A delivery receipt is not acknowledgement. If the primary does not acknowledge within the configured urgent escalation interval, the backup takes ownership immediately.
2. For an immediate threat or suspected child involvement, apply the reviewed urgent protocol and route to the designated safety/legal owner. Record what is alleged versus what the service actually holds. Stop relevant contact through existing safety restrictions/Block controls when authorised; do not impose a permanent shared-network ban from one report.
3. Review only submitted, purpose-scoped evidence after its audit commits. No tool can replay unrecorded voice or retrieve ended ordinary chat. Preserve a justified narrow legal hold before required records expire. Never ask a complainant to upload unrelated private conversations or casually collect government ID.
4. Apply the applicable two/three/36-hour workflow when qualified; do not send urgent complaints to the general seven-day backlog. Validate a claimed governmental order through the authorised officer/counsel procedure. Do not disclose identity based on a threatening message alone.
5. Communicate an appropriate human response through the protected case, record action and outcome, and provide the approved appeal path. Do not expose reporter identity/internal notes. An internal appeal preserves history and does not postpone a statutory external remedy.
6. If notification, evidence access or staffing fails, activate the backup and reduce/disable new public interactions as required by the monitored-coverage gate. Keep the independent complaint path reachable during ordinary maintenance; for full host loss publish the approved alternative monitored incoming contact on the status/maintenance surface.

## Failed payment, missing Premium or refund

1. Billing-authorised MFA operator opens the original purchase from the restricted exception queue. Verify current merchant/environment and the owner-safe association. A complaint reference does not itself establish payment ownership.
2. Inspect captured attempts, immutable plan/amount, grant history and reconciliation age. Fetch/reconcile through the existing verified provider path; browser status, screenshots and client-selected payment IDs cannot grant Premium. Reuse the original order/refund identity after an unknown result.
3. For a refund, obtain a fresh signed preview showing exact refundable paise and originating-lot treatment. Record the approved decision; full hold/revoke affects only that lot. Failed-refund restoration uses the resolution-time semantics. Never edit aggregate expiry or subtract time by a money ratio.
4. Distinguish requested, provider processed and bank credited. Escalate dashboard/external refunds, duplicate captures, deleted-account payments, late success after failed refund and disputes. Preserve an auditable financial obligation even after identity deletion. Annual purchases stay off without the beyond-window route.
5. Reply through the protected support case with the minimum safe status. Reconcile provider totals, fees, refunds and settlements; weekly review does not permit an urgent exception to wait a week. Preserve evidence of the operator decision without copying gateway phone/card/bank secrets.

## Privacy request, export, correction or deletion

1. Establish the requester through the current self-authenticated route or the reviewed exceptional identity procedure. Retain the complaint access secret independently of account status. Wrong/no proof gets a safe response; username, amount or network address are insufficient.
2. Confirm purpose, current approved policy version, exact applicable deadline, financial obligations and holds. Do not fabricate a statutory universal privacy deadline; the case rules and signed legal register determine it. Correct profile facts through existing version-guarded self workflows when possible.
3. Export only the approved self-data projection. Exclude credentials, recovery/session secrets, other participants' private data, reporter identity, internal notes and unrestricted evidence. Authorised evidence export is a separate scoped, audited operational action. Store no reusable download URL in chat/email; follow the protected delivery/expiry procedure.
4. Deletion immediately disables access. Inspect each retention obligation and hold; execute only the authorised purge path. Track journal record durability and verified off-host copy separately. A local fsync or elapsed `retention_until` is not proof of complete erasure.
5. Explain what was removed, what remains restricted, why and the applicable schedule/review. Supply required self receipts through the approved closed-account verification route, without reviving the account or exposing another person's purchase.
6. A hold release is a reviewed event, not an instruction to erase immediately regardless of other duties. Re-evaluate all purpose rules; run a bounded retry-safe purge and record its audit. Missing approval, stale policy, corrupt journal or failed audit keeps destructive work stopped and alerts the owner.

## Security incident or app outage

1. External monitoring detects the failure independently of the app VM. Primary/backup records discovery time and declares severity. Use fixed-label outage notifications; keep secrets and personal data out of the response channel.
2. Contain suspected compromise using scoped feature disables/traffic controls and credential rotation while preserving evidence. Keep one logical coordinator. Do not start a second owner to simulate high availability. Kill switches must preserve durable provider inbox work and grievance access when the dependencies still operate.
3. The designated contact assesses CERT-In Annexure I and any other applicable notification duty immediately. Reporting clocks start at notice, not completed root cause. The authorised person makes required external reports through the verified official channel; this source package sends none.
4. For database/host loss, follow `deploy/operations/README.md`: compatible base+WAL, independently retained deletion and hold journals, session revocation, current restrictions and payment reconciliation before reopening. Restore unknown/corrupt journal state remains unavailable. Record achieved RPO/RTO and do not substitute scheduled-job success for recovery proof.
5. For TURN uncertainty, the independent supervisor/watchdog stops uncontrolled media. Test cancellation and credential replay, then require fresh user consent. Reconnecting text does not resume voice automatically.
6. Reopen gradually after safety/privacy/financial checks, communicate the actual interruption, and record root cause, action owner and next verification. Roll back schema-compatible code; do not restore a stale database to undo a release.

## Daily, weekly and periodic work

Daily: urgent/overdue case work, financial exceptions, failed/dead-letter notifications, deletion/hold readiness, archive integrity/lag, last recoverable WAL, disk growth, external probe, relay readiness and cost projection. An unavailable metric is an alert, not a zero. Escalate unowned work immediately.

Weekly: review automated capture/refund/dispute/fee/settlement comparisons, oldest queue work, abuse trends, least-privilege access, notification human acknowledgements and restore sample. Monthly: patch supported components, check secrets/TLS/domain renewal, reconcile processor/retention inventories and purge outcomes, review coverage and actual bills. Apply urgent security fixes promptly.

Quarterly and after material backup changes: complete isolated restore and deletion/hold/payment replay with the backup operator; test absent primary, unreachable notification receiver and lost app host. Review current legal sources and upcoming dates. In-app quarterly rule-consequence reminders require approved copy; do not create guest history to track them.

## Cost and resource assumptions

The implementation adds **₹0 fixed software subscription/month or year** when the existing host budget has headroom. This is not free operations: S3 storage/requests/transfer, incremental backup volume, existing host/network, incoming business contact, staff time and legal/accountant work remain payable. The blueprint's ₹97/USD and 18% tax are planning assumptions, not current quotes. Do not silently change already agreed host sizing or promise 200/25 capacity from configuration.

For budgeting, measure compressed security bytes/day `S`, average encrypted recovery bytes `B` and independent journal bytes `J`; a 180-day security minimum requires approximately `180×S` bytes plus lifecycle/version margin. Total planned storage is that amount plus the measured recoverable backup chain and `J`. Multiply the provider's reviewed INR/GiB-month rate and request/transfer rates, then annualise monthly recurring cost ×12. Reject a forecast that assumes zero archive requests, zero restore transfer or unlimited free staffing. Avoid a paid telemetry platform until measured operation warrants it.

Investigate around 140 connected users or 18 calls, CPU 65–70% for 15 minutes with rising latency, post-GC memory >75%, owner lag >100ms, growing oldest work, disk >70% or <30-day growth room. These trigger diagnosis. Vertically resize the demonstrated bottleneck and repeat the full workload before changing limits. Keep recording actual relay transfer; aggregate call counts alone do not determine egress charges.

## Reviewed rule publication

Follow `server/internal/operations/README.md` for versioned deadline and notice publication under the migration role. Runtime credentials cannot publish approved policy or legal timers. Install the retention manifest through the owner-MFA adminctl workflow. Keep publication, effective date, legal source and review dates distinct.
