# Dependency and build policy

Use exact direct versions and supported toolchains. Go 1.27.2, PostgreSQL 18.6, pgx 5.11.0 and Caddy 2.11.7 were checked against their maintainers' release pages on 9 October 2026. Frontend/tool versions are recorded in package manifests and build configuration.

- Commit genuine `server/go.sum` and `web/package-lock.json` after generating them on a machine with approved package-registry access.
- Never invent checksum values, hand-author a supposedly resolved transitive graph or silently substitute an unlocked release install.
- Release builds use `npm ci`, Go module verification and read-only module resolution. Missing locks block the build.
- Keep Go module sums, frontend lockfiles and selected toolchains in the same reviewed change.
- Resolve image tags to immutable digests in a network-enabled release environment; verify architecture, base image vulnerabilities and artifact provenance before deployment. A version tag is not an immutable digest.
- Update urgent security fixes promptly. Review routine updates regularly and major upgrades deliberately.
- Keep development, CI and release dependencies separate from product secrets.
- CI uses minimum token permissions. Do not put live merchant credentials in test jobs.
- No production build is performed on the application VM.

The generated source package does not contain fabricated lockfiles. Registry access was blocked in the implementation workspace, so resolving and committing real lockfiles remains an explicit Phase 1 acceptance dependency.

Primary references:
- https://go.dev/dl/
- https://github.com/jackc/pgx/releases
- https://www.postgresql.org/support/versioning/
- https://github.com/caddyserver/caddy/releases
- https://svelte.dev/docs/kit/adapter-static


Phase 3 adds `golang.org/x/crypto v0.57.0` for maintained Argon2id (verified against https://pkg.go.dev/golang.org/x/crypto on 9 October 2026). Default costs are 64 MiB, three iterations and one lane, with two concurrent jobs maximum. Review https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html and measure the actual VM before accepting these deployment parameters. Genuine transitive module sums and vulnerability checks remain required; no custom password-hashing primitive is introduced.

Phase 4 pins `github.com/coder/websocket v1.8.15` for maintained RFC6455 framing and bounded reads/writes, with compression disabled. Official references: https://github.com/coder/websocket/releases/tag/v1.8.15 and https://pkg.go.dev/github.com/coder/websocket@v1.8.15. Genuine module sums, compilation, race tests and vulnerability checks remain required; the Node raw client is only a test helper, not the production server implementation.
