# Search visibility and reviewed public releases

Phase 2 creates all eleven public documents in initial HTML. The eight application paths are excluded from the sitemap and receive noindex in their fallback HTML and server response. An explicit route allowlist prevents arbitrary URLs from returning the application shell. `robots.txt` allows crawling so search engines can see noindex; authentication and staging access control protect data separately.

## Three explicit build modes

| Mode | Configuration | Result |
| --- | --- | --- |
| Preview, default | No hostname required | Draft information, noindex on all pages, empty sitemap, no invented canonical or operator schema |
| Staging | `PUBLIC_RELEASE_MODE=staging` and actual HTTPS `PUBLIC_SITE_ORIGIN` | All pages noindex; deployment additionally requires access control |
| Production | `PUBLIC_RELEASE_MODE=production` and approved HTTPS `PUBLIC_SITE_ORIGIN` | Public pages indexable; unique canonicals, Open Graph, WebSite/Organization/BreadcrumbList and public-only sitemap |

No production hostname is supplied in this source package. Never substitute an example hostname. Build-time public environment settings are compiled into static HTML and JavaScript; changing runtime settings does not update them. The container marker prevents a preview build being relabeled as production at startup. Server configuration must also match the built origin.

## Legal and commercial inventory

`web/config/release.json` is deliberately incomplete and contains **public information only**, never secret keys, private case records or confidential review attachments. It identifies draft versions and proposed responsible roles. A reviewer must replace those with the actual operator, monitored incoming contacts, assigned Grievance Officer, approved tax treatment, policy owners, privacy statement, processors, retention entries, request procedure and legal-hold workflow. Review references identify records held separately. Validation checks completeness; it does not establish legal compliance or provide legal approval.

Production rejects incomplete policy approvals and retention entries, missing effective dates/legal sources, unresolved tax values, role-only policy owners and mismatched canonical origins. All thirteen data classes include financial records. Incoming published contact addresses do not add an outgoing application email service.

`web/config/plans.json` retains the four proposed fixed-duration INR offers for later payment implementation. All are disabled. No current price is advertised as purchasable. A fixed Phase 2 code guard rejects any enabled plan, sales activation or asserted payment readiness: editing configuration cannot enable a missing checkout. The payment phase must implement backend orders, capture validation, entitlements and checkout, pass its acceptance gates and then replace this guard. Commercial approval remains required, and the annual plan also requires its own unit-economics approval. Consumer totals include applicable taxes, and automatic renewal is false. Future public offers and checkout must consume the same enabled versioned catalog.

## Review and build sequence

1. Finalize product/policy copy and actual public facts with the responsible reviewers. Record reviews in the inventory and keep sales disabled until the later payment gate passes.
2. Use `cd web && npm run release:digest` to calculate the current review digest. It binds source, static assets, catalog and public release inventory, excluding only the digest field itself.
3. After review, record that digest in `approvals.contentSha256`. Changing legal facts, page copy or assets invalidates it. A digest records what was approved; it cannot replace a named human approval.
4. Set the actual `PUBLIC_SITE_ORIGIN` and `PUBLIC_RELEASE_MODE=production`, then run `npm run validate:release` and the complete verification suite. The checked-in draft is expected to fail production validation.
5. Build the container with those same settings. `postbuild` validates all public HTML, headings, unique metadata, supported internal links, search controls and exact sitemap URLs. It adds exact JSON-LD script hashes to Svelte's existing CSP and regenerates compressed HTML after changes. It never enables broad `unsafe-inline` scripts.
6. Verify routing and response headers through Caddy, with real 404 status for unknown paths. The build marker is internal and must never be served. Deploy only after all applicable launch gates, beyond Phase 2, pass.

Preview verification is `npm run validate:release`; production rejection can be exercised with `npm run validate:release -- --production`. Unit tests use synthetic review records only and do not alter or approve the checked-in inventory. Node checks exercise validators and HTML utilities; they do not replace the pending Svelte build and browser verification.

## Primary references checked for implementation

- SvelteKit static adapter: https://svelte.dev/docs/kit/adapter-static — prerender content and keep a separate application fallback. This repository remains pinned to SvelteKit 2; current documentation also describes later configuration APIs, so no framework migration is implied.
- Google noindex: https://developers.google.com/search/docs/crawling-indexing/block-indexing — make the directive visible to crawlers; robots exclusion is not a privacy boundary.
- Google canonical URLs: https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls — use consistent canonical URLs across document metadata and sitemap.

Search ranking and field Core Web Vitals are not established by this implementation. Add Search Console only after the real hostname and release are approved; use lab and real-device checks before launch, then assess mobile field performance when enough data exists.
