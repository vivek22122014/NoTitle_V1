# Phase 10 browser and device acceptance

This is an execution checklist and evidence template, not a record of passed browser tests. The source hardening preserves the mobile-first interface, desktop feature parity, shared pool, matching rules and 200-connected/25-call target. Browser fixtures cannot establish that capacity or real TURN/Cashfree behavior.

## Automated layers

Run after authentic dependencies have been installed and reviewed:

```bash
cd web
npm run check
npm run lint
npm run test:unit
npm run test:e2e
npm run test:cross-browser
npm run test:design
npm run test:payments-ui
```

`scripts/verify.sh` invokes `deploy/test/Web.Dockerfile`, which installs all three pinned Playwright engines and runs `test:cross-browser`. CI uses that same verification path; it does not silently fall back to Chromium when another engine is unavailable. The five projects replace the redundant Chromium-only invocation in that container.

`test:cross-browser` builds the static artifact and runs the ordinary fixture suite in Chromium, Firefox and WebKit, plus Android and iPhone viewport/device emulation. Install the three Playwright engines at the pinned package version first. API, payment and WebSocket responses in these browser tests are explicitly synthetic. The browser metadata attachment identifies the actual engine/version and runner OS; it does not identify a physical phone. WebKit is not branded Safari, and Chromium is not branded Chrome or Edge.

The main and cross-browser configurations turn off automatic traces, screenshots and video. Do not enable HAR, console/network dumps, tracing or screenshots on a real-account or live-payment run: these can capture cookies, transcripts, case secrets, SDP or payment contact. Use synthetic accounts and approved redacted evidence. The design-preview suite is an explicitly isolated simulation; any diagnostic artifact from it remains fixture-only. Never use a live merchant transaction to make an automated fixture pass.

New regressions cover maintenance admission versus existing conversations; strict maintenance projection; suspended-page owner recovery; expired reconnect proof; immediate offline handling; delayed microphone permission beyond absolute consent expiry; and return from an unresolved same-tab checkout. Simulated `pagehide`/`pageshow` events verify event handling, not the browser's actual bfcache eligibility, suspension scheduling, keyboard or background-media behavior.

## Production candidate static verification

The real `deploy/app/Caddy.Dockerfile` build runs `validate-release` and the finalizer using its actual `PUBLIC_RELEASE_MODE`, `PUBLIC_SITE_ORIGIN`, `PUBLIC_CHECKOUT_SDK_ENABLED` and `PUBLIC_CHECKOUT_ENVIRONMENT` build arguments. The finalizer checks every public document and the private app shell against exact compiled script/connect CSP origins, rejects script overrides and preloaded external SDKs, and binds the checkout controls into frontend build marker schema 2. Runtime preparation rejects old/missing checkout markers and sandbox-enabled production checkout, and copies the checkout markers outside served content.

This means the actual production candidate receives static checkout/CSP checks, not only the default preview used by UI CI. Production still requires its approved public-content digest. No synthetic legal approval is written to enable a build. The server configuration schema describes server variables; these four frontend build arguments remain documented here and in deployment instructions instead of being accepted by the Go environment schema.

A static candidate check does not prove the hosted Cashfree flow or that the restricted CSP covers every legitimate provider request. Exercise the approved integration on the actual candidate/origin in sandbox and, after separate authorization, with the controlled live transaction. If the provider requires another origin, review its documented purpose and update the explicit list and regression fixture; do not add wildcard or scheme-wide allowances to make a browser error disappear.

## Physical device and supported desktop record

Complete every row on the production-like approved HTTPS origin. Record the exact build/artifact digest, date, tester, OS/browser version, hardware, network and evidence reference. An empty cell is pending. Use separate rows for each materially different OS version in the supported release policy; the owner must define that policy before claiming support.

| Required environment | Hardware / OS version | Browser / version | Networks tested | Build and evidence | Result / defect |
| --- | --- | --- | --- | --- | --- |
| Physical Android phone | Pending | Google Chrome: pending | Wi-Fi, cellular, restrictive: pending | Pending | Not run |
| Physical iPhone | Pending | Safari: pending | Wi-Fi, cellular, restrictive: pending | Pending | Not run |
| Desktop Windows | Pending | Google Chrome: pending | Required network pairs: pending | Pending | Not run |
| Desktop Windows | Pending | Microsoft Edge: pending | Required network pairs: pending | Pending | Not run |
| Desktop supported OS | Pending | Firefox: pending | Required network pairs: pending | Pending | Not run |
| Physical Mac | macOS: pending | Safari: pending | Required network pairs: pending | Pending | Not run |

Record browser-to-browser audio pairs, not only independent page visits. Include Android–iPhone, Android–desktop, iPhone–desktop and the supported desktop engines, across different networks. A restrictive-network failure must show a bounded honest failure with working text and no direct-media fallback. There is no guarantee of uninterrupted background or locked-screen calling.

## Required journeys and assertions

| Journey | What must be demonstrated |
| --- | --- |
| Layout and orientation | Check 320–430 CSS px phone widths first, then 768–1920 px desktop; portrait/landscape, notch/safe areas, browser toolbar expansion/collapse and 200% text. No horizontal page overflow, hidden confirmation, overlapping action or inaccessible dismissal. Check unusually long names, case references and wrapped policy text. |
| Soft keyboard | On actual Android/iPhone, focus guest/profile/password/support/checkout fields and the message composer. Open/close keyboard, rotate with keyboard open and navigate form errors. Focused input, Send, End, report/block and dialog dismissal remain reachable by scrolling; no page or modal traps. Do not count viewport resizing as a keyboard test. |
| Keyboard and assistive technology | Complete guest entry, match, preferences, report/block, mutual connection, account privacy and checkout status using keyboard alone. Verify visible focus, modal focus containment/return, Escape where permitted, skip link, accessible labels and status announcements using TalkBack, VoiceOver and a desktop screen reader. Check reduced motion, readable contrast and at least 44px primary touch targets. |
| Guest/account identity | No identity, queue join, consent, microphone or payment starts on mount. Registration handoff retains only the authorized live epoch; logout, deletion and replacement revoke it. Refresh/cookie loss never recreates private guest data. |
| Call consent and permission | Incoming calls do not capture. Deny permission, grant then revoke it, cancel while permission is pending and grant after cancellation or consent expiry. Every late stream stops; Next/End/report/block remain usable. Repeated snapshots never authorize fresh capture. Test a removed microphone/headset. |
| App switching and screen lock | During ringing, permission, connecting and connected states, switch apps and lock/unlock. Observe actual OS behavior and tracks/relay allocations. If signaling fails or the document freezes, audio ends and fresh consent is required. No silent rejoin. Text resumes only within the remaining original grace. |
| Network change | Switch Wi-Fi↔cellular, disable connectivity and restore it, change network while permission is pending and exceed the 25-second match grace. Sending pauses immediately when interruption is known. Uncertain text, Next, friend invitations and checkout creates never replay automatically. |
| Back/forward cache | Leave the tab through same-tab navigation and return with Back on a real device. The mounted conversation controller remains usable; stale proof cannot restore an expired match. Audio is off after suspension. Verify End on a successfully resumed match. |
| Checkout return | Use approved sandbox first: cancel, leave/return, refresh callback, lose callback, background the payment app and let the SDK promise remain unresolved. Status becomes usable and verifies the same server purchase. An SDK success or URL flag never grants Premium; no duplicate intent/payment or retained payment-only phone. Live validation requires separate explicit authorization. |
| Maintenance | Start drain while idle, queued, text-matched, ringing and in accepted audio. Banner announces the actual scheduled close time; new matching, Next, invitations and call acceptance are disabled. Existing authorized text/audio can continue until server closure; End/report/block remain usable. Reconnect/resync preserves maintenance. Test closure and deliberate reopening. |
| Privacy and support | Protected case codes work after logout/account loss through POST bodies; no codes or transcript enter URL, browser persistence, provider request or logs. Self export requires recent authentication. Temporary codes clear on intended exits; saved user files are explicit. |
| SEO/static security | Public prerendered content remains meaningful without JS. Review actual production canonical/meta/sitemap, supported public/app routes, true404, app noindex/no-store, exact CSP, no public sourcemaps, no unexpected third-party requests and no CSP errors. The preview build intentionally does not satisfy production indexing. |

For each failed test, record reproducible steps, expected versus actual behavior, severity, owner and retest evidence. Do not paste secrets, transcripts, phone numbers or account names into the release record. An unresolved critical failure blocks launch. Automated fixtures, production-like acceptance, physical-device acceptance and explicitly authorized production smoke checks are distinct evidence stages.

## Source fixes in this phase

- Page suspension closes transport/media but preserves the in-memory controller required by an already mounted route. Returning checks elapsed time and reconnects only within the existing grace; it never queues or starts audio automatically.
- Offline and visibility events reconcile connection state promptly even when mobile timers were throttled. Ordinary transcript data stays in RAM and is cleared at the existing interaction boundary.
- Microphone permission completion checks absolute consent and relay credential expiry before creating a peer connection; a delayed timer cannot extend consent.
- Server-driven maintenance is projected through the normal snapshots and a fixed event, with a responsive status banner and separate admission controls. Accepted media is not terminated just because new admission is paused.
- Checkout page departure invalidates the old asynchronous launch result. A bfcache return can verify the saved purchase even if the prior SDK promise never settles; visibility return also triggers server verification without requiring a focus event.

No exact Svelte compilation, Playwright execution or physical-device run was available in the source-authoring environment. Fill results only after executing the listed checks with the pinned dependencies.
