# Cashfree payment setup, testing and launch

This is the operational guide for the payment implementation included in the cumulative NoTitle source. Start with the root `START_HERE.md` and `FINAL_DEPLOYMENT_GUIDE.md`, then `configuration.md`, `phase8-payments.md`, `phase8-acceptance.md` and `phase10-launch.md`. Source paths below are relative to the extracted `notitle` directory.

**Delivery status:** payment code, database migrations, operator screens, hosted checkout and tests are included. Successful compilation, PostgreSQL integration, real Cashfree sandbox delivery, live capture/refund/settlement and final production acceptance must be recorded on the actual candidate before launch. A feature switch or completed document is not evidence of those outcomes. The base templates deliberately keep financial processing and checkout off.

## 1. What the application sells

NoTitle is an adults-only workplace conversation service with pseudonymous guests, random text/audio conversations, mutual connections and paid matching preferences. Guest, Free and Premium users share the same matching pool. Audio, ordinary conversation, safety and mutual friendship are not Premium-only. Disclose this actual service, including paid gender preferences, during merchant onboarding; obtain written acceptance of this business before live activation.

The finalized proposed consumer totals and durations are:

| Catalog ID | Consumer total | Integer paise | Continuous duration |
| --- | ---: | ---: | ---: |
| `three-day` | ₹99 | 9,900 | 259,200 seconds / 72 hours |
| `seven-day` | ₹199 | 19,900 | 604,800 seconds / 168 hours |
| `thirty-day` | ₹499 | 49,900 | 2,592,000 seconds / 720 hours |
| `annual` | ₹1,499 | 149,900 | 31,536,000 seconds / 8,760 hours |

These are one-time purchases, without subscriptions, auto-renewal or debit mandates. Time runs continuously, including offline; additional purchases append time. Only the server catalog determines amount, duration and tax snapshot. Keep these business values unchanged unless the owner separately revises the product decision.

An accountant must approve the actual tax classification, tax-inclusive split, invoice/credit-note requirements and consumer disclosures. No tax rate is supplied as an approval. The application receipt is a financial purchase record; it is not proof that every statutory invoice requirement is satisfied. Establish and test the approved invoicing arrangement before launch. Annual sales additionally require approved economics, liquidity and a workable process for later valid refunds.

## 2. Cashfree account and environment preparation

1. Create or use the operator's own [Cashfree merchant account](https://merchant.cashfree.com/). Select **Payment Gateway**. This application does not integrate Payouts or Subscriptions, and their credentials are not interchangeable with Payment Gateway credentials.
2. Complete the provider's production activation/KYC, settlement bank and business review using actual operator details. Record the merchant identifier, approved line of business, payment methods, settlement schedule, fees, refund terms and written underwriting reference in the protected operating record. This ZIP does not supply any of these approvals.
3. Switch the dashboard to its **test/sandbox** environment. Under **Payment Gateway → Developers → API Keys**, generate the App ID and Secret Key using the required account authentication. Store them through the protected workflow below. Generate and store live keys separately only after production activation. Never place keys in frontend variables, screenshots, source, shell history or the ZIP.
4. Prepare a separate, access-controlled HTTPS staging origin, isolated database/volumes and sandbox credential directory. Use `APP_ENV=staging` with `PAYMENT_ENVIRONMENT=sandbox`. Production requires `APP_ENV=production` with `PAYMENT_ENVIRONMENT=production`; the server rejects mixed modes. Never copy sandbox financial records into production.
5. For live checkout, request website whitelisting under **Payment Gateway → Developers → Whitelisting → Add New → Website URL**. Submit the actual HTTPS domain and reviewed product/pricing/contact/terms/refund pages. Confirm approval before collecting live money. Resolve any staging-domain eligibility with Cashfree; do not assume a localhost/custom-port preview satisfies provider whitelisting.

Provider account/key instructions were checked against [API authentication](https://www.cashfree.com/docs/api-reference/authentication), [quickstart](https://www.cashfree.com/docs/payments/quickstart-guide) and [domain whitelisting](https://www.cashfree.com/docs/payments/online/go-live/whitelist). Dashboard labels and merchant eligibility can change; reconfirm them when provisioning.

## 3. Protect and mount credentials

The API runs as Linux UID/GID `65532:65532`. Prepare a dedicated directory outside the source tree, for example `/srv/notitle-secrets/sandbox-payments`, using a private editor/password manager or the operator's approved secret provisioning process. It must contain regular, non-symlink files:

| Host file | Contents | Owner/mode |
| --- | --- | --- |
| `client_id` | That environment's Payment Gateway App ID | `65532:65532`, `0400` or `0600` |
| `client_secret` | That environment's Payment Gateway Secret Key | `65532:65532`, `0400` or `0600` |
| `previous_secret` | Optional former signing secret during bounded rotation only | Same ownership/mode |

The directory must be owned by `65532:65532` with mode `0700`. The payment overlay mounts it read-only at `/var/lib/notitle/payment-keys`. The application rejects group/other-readable files, symlinks and nonregular files. Default file-backed Compose secrets commonly mount as `0444` and are unsuitable for this reader. Confirm the real mounted ownership and permissions, not only the YAML text.

On Docker Desktop, use WSL Linux storage or a separately provisioned Linux volume if host bind permissions cannot be preserved. Do not run the API as root or weaken secret checks. Keep payment credentials separate from database, report encryption, MFA, TURN and recovery keys. Do not include the directory in source archives or ordinary logs.

## 4. Set the backend and frontend configuration

All booleans are exact `true` or `false`. Put non-secret deployment choices and **paths** in the protected environment file used by Compose. Values in the table are decisions to make, not blanket permission to turn on production.

| Variable | Initial/processing-only setting | Checkout acceptance / launch setting |
| --- | --- | --- |
| `APP_ENV` | `staging` for sandbox; `production` for live | Must match the chosen environment |
| `PUBLIC_ORIGIN` | Actual same-origin HTTPS site | Must match the built frontend and approved domain |
| `PAYMENTS_ENABLED` | Base defaults `false`; payment overlay sets `true` | Keep `true` once purchases exist |
| `CHECKOUT_ENABLED` | `false` | `true` only for the authorized checkout scope |
| `PAYMENT_ENVIRONMENT` | `sandbox` or `production` | No cross-environment fallback |
| `PAYMENT_MERCHANT_ID` | Actual merchant identifier | Same merchant whose keys are mounted |
| `PAYMENT_SECRET_DIRECTORY` | Absolute dedicated host directory | Separate directories for sandbox/live |
| `CASHFREE_CLIENT_ID_FILE` | Overlay supplies `/var/lib/notitle/payment-keys/client_id` | Never a raw credential value |
| `CASHFREE_CLIENT_SECRET_FILE` | Overlay supplies `/var/lib/notitle/payment-keys/client_secret` | Current API and webhook secret |
| `PAYMENT_MERCHANT_APPROVED` | `false` until written underwriting | Must be `true` for live processing after approval |
| `PAYMENT_POLICY_APPROVED` | `false` until actual commercial/tax/privacy review | Must be `true` for live processing after approval |
| `PAYMENT_ANNUAL_APPROVED` | `false` | Additional annual-sale gate after approved economics and later-refund procedure |
| `CASHFREE_PREVIOUS_SECRET_CONTAINER_FILE` | Unset | Overlay-only old-key path during rotation |
| `CASHFREE_PREVIOUS_SECRET_FILE` | Unset | Runtime old-key path; overlay maps the preceding variable |
| `CASHFREE_PREVIOUS_SECRET_UNTIL` | Unset | RFC3339 expiry, future and no more than 24 hours from startup |

Payment processing also requires `IDENTITY_ENABLED=true`, `SAFETY_ENABLED=true` and `ADMIN_ENABLED=true`, with their own prerequisites and protected keys. Apply **all cumulative migrations through schema 9**; the historical Phase 8 minimum of schema 7 is not sufficient for this final application. Maintenance, legal review, audio and full operations have independent release gates. A payment setting does not open admission.

The static frontend needs these **build-time**, non-secret arguments:

| Build argument | Controlled sandbox build | Approved live build |
| --- | --- | --- |
| `PUBLIC_RELEASE_MODE` | `staging` for hosted staging, `preview` for local-only | `production` |
| `PUBLIC_SITE_ORIGIN` | Actual HTTPS staging origin; blank only for local preview | Actual canonical HTTPS origin |
| `PUBLIC_CHECKOUT_SDK_ENABLED` | `true` for sandbox checkout acceptance | `true` for the approved live candidate |
| `PUBLIC_CHECKOUT_ENVIRONMENT` | `sandbox` | `production` |

Setting those variables only in a running Caddy container does not change already built JavaScript or CSP. Rebuild the web image and record its real manifest digest. The browser, backend and returned checkout environment must agree. A processing-only web build can leave SDK access off while preserving receipts/status.

Use the canonical overlay order **base → staging (when used) → audio → payments → operations** from `FINAL_DEPLOYMENT_GUIDE.md`. For the complete controlled acceptance deployment, after all referenced files and variables are prepared:

```bash
docker compose --project-name notitle-acceptance --env-file /etc/notitle/acceptance.env \
  -f deploy/production/compose.yml -f deploy/staging/compose.yml \
  -f deploy/audio/compose.app.yml -f deploy/payments/compose.app.yml \
  -f deploy/operations/compose.app.yml config --quiet
```

This validates configuration without printing secrets or deploying. Preserve exactly that project, environment file and overlay order for migration and startup. For production use the deployment guide's `notitle` project and `/etc/notitle/production.env`, omitting only the staging overlay from this sequence. Wrapper scripts do not automatically add the payment overlay. Follow the complete deployment guide for actual startup and protected admission.

## 5. Publish reviewed catalog versions

Migration 7 creates version 1 of all four plans as **disabled**, with `tax_treatment=pending_review`. Economic/tax fields are immutable: updating those rows to a new tax decision is intentionally rejected. The runtime `notitle_app` role can only read the catalog. There is no public catalog editor or automatic tax approval.

1. Obtain a dated accountant/business review of every offer's total, exact seconds, tax treatment, included tax in paise, displayed name and availability. Use `not_applicable` only when that is the actual approved decision. For `inclusive`, supply the accountant-approved integer tax split. These values must agree with the approved public disclosures.
2. Create a reviewed CSV outside source with this exact column order. Use one fresh version per plan, greater than every existing version for that plan; `2` is appropriate only if version 1 is still the latest. Do not add placeholder rows or guessed tax figures.

```text
id,version,name,amount_paise,currency,duration_seconds,tax_treatment,tax_paise,enabled,annual_approved
```

3. Use an authorized migration-role session over the private database path. Configure the psql connection through a protected service/password file or interactive secret entry; do not put a DSN/password in command arguments. The runtime account must not publish plans. Create an approved publication SQL file outside source, replacing the CSV path with its actual absolute path. Run this version using `\i /protected/reviewed-publication.sql` inside an interactive `psql --no-psqlrc` session, with **no `--single-transaction` option**. The following transaction validates the finalized prices/durations and prevents accidental overwrite; it does **not** supply the human approval itself.

```sql
\set ON_ERROR_STOP on
BEGIN;
DO $$ BEGIN
  IF current_user <> 'notitle_migrate' THEN
    RAISE EXCEPTION 'Use the dedicated migration role';
  END IF;
  IF (SELECT count(*) FROM notitle.schema_version) <> 1
     OR NOT EXISTS (SELECT 1 FROM notitle.schema_version WHERE version = 9) THEN
    RAISE EXCEPTION 'Apply the cumulative schema first';
  END IF;
END $$;
LOCK TABLE notitle.premium_plans IN SHARE ROW EXCLUSIVE MODE;
CREATE TABLE notitle.catalog_publication_review
  (LIKE notitle.premium_plans INCLUDING CONSTRAINTS);
REVOKE ALL ON notitle.catalog_publication_review FROM PUBLIC, notitle_app;
\copy notitle.catalog_publication_review FROM '/protected/reviewed-premium-catalog.csv' WITH (FORMAT csv, HEADER true)
DO $$ BEGIN
  IF (SELECT count(*) FROM notitle.catalog_publication_review) <> 4
     OR (SELECT count(DISTINCT id) FROM notitle.catalog_publication_review) <> 4 THEN
    RAISE EXCEPTION 'Require one reviewed row for each of the four plans';
  END IF;
  IF EXISTS (SELECT 1 FROM notitle.catalog_publication_review a
    WHERE a.tax_treatment = 'pending_review'
      OR (a.tax_treatment = 'not_applicable' AND a.tax_paise <> 0)
      OR (a.id = 'three-day' AND (a.amount_paise <> 9900 OR a.duration_seconds <> 259200))
      OR (a.id = 'seven-day' AND (a.amount_paise <> 19900 OR a.duration_seconds <> 604800))
      OR (a.id = 'thirty-day' AND (a.amount_paise <> 49900 OR a.duration_seconds <> 2592000))
      OR (a.id = 'annual' AND (a.amount_paise <> 149900 OR a.duration_seconds <> 31536000))
      OR a.version <= COALESCE((SELECT max(p.version)
           FROM notitle.premium_plans p WHERE p.id = a.id), 0)) THEN
    RAISE EXCEPTION 'Unreviewed terms, changed business values or reused version';
  END IF;
END $$;
UPDATE notitle.premium_plans p SET enabled = false
WHERE p.enabled AND EXISTS (SELECT 1 FROM notitle.catalog_publication_review a WHERE a.id = p.id);
INSERT INTO notitle.premium_plans
  (id,version,name,amount_paise,currency,duration_seconds,tax_treatment,tax_paise,enabled,annual_approved)
SELECT id,version,name,amount_paise,currency,duration_seconds,tax_treatment,tax_paise,enabled,annual_approved
FROM notitle.catalog_publication_review;
DROP TABLE notitle.catalog_publication_review;
SELECT id,version,name,amount_paise,currency,duration_seconds,tax_treatment,tax_paise,enabled,annual_approved
FROM notitle.premium_plans ORDER BY id,version;
-- Inspect against the approved record in this same interactive session.
-- Execute COMMIT only if it agrees; otherwise execute ROLLBACK.
```

4. Rehearse on sandbox first. The catalog contains exactly the ten columns supplied above; all are non-null and there is no catalog `created_at` column. The clone does not need copied defaults because every field is supplied. `notitle_migrate` owns the schema/catalog and can create/drop this private helper table; `notitle_app` cannot publish plans. The helper is created and dropped inside this same transaction because database TEMP privileges are deliberately revoked; it must not survive a completed change. Keep the transaction open only long enough for inspection; execute `COMMIT` after confirming the output, or `ROLLBACK` on any mismatch/failure. Record the reviewed CSV/SQL digest, operator, change reference and result outside the public source package.

   The deployment guide's unattended `psql --single-transaction --file ...` procedure is an **alternative transaction wrapper**: prepare a separately reviewed copy of this file with `BEGIN;` removed and with no explicit `COMMIT` or `ROLLBACK`. Its `ON_ERROR_STOP` setting and single-transaction option then commit the whole approved change only on success. Do not nest the interactive transaction inside `--single-transaction`, and do not run the interactive version as an unattended file that exits before its deliberate commit.
5. Check `GET /api/v1/premium/plans` through the deployed origin. It must show only the intended versions with exact paise/seconds. Annual visibility additionally requires `PAYMENT_ANNUAL_APPROVED=true`; its database `enabled` and `annual_approved` flags are insufficient alone. Old purchases retain their original snapshot after a later plan is disabled or replaced.

Full-V1 acceptance still includes all finalized offers. Keeping annual disabled is a limited sales scope until its approval gate is completed, not deletion of the requirement.

## 6. Configure webhook delivery and checkout domains

For each environment and merchant separately:

1. In **Payment Gateway → Developers → Add Webhook Endpoint**, enter the exact endpoint `https://<actual-origin-host>/api/v1/webhooks/cashfree`. Replace the placeholder with that environment's real host. There is no trailing slash, query, session cookie or browser CSRF requirement on this provider route.
2. Select and record an explicitly tested webhook payload version offered by the dashboard. The outbound REST API is pinned to `2026-01-01`; that does not automatically select or prove a dashboard webhook version. Compare actual sandbox payloads with `server/internal/cashfree/webhook.go`, including refunds/disputes, before approving the selection.
3. Configure **Success Payment**, **Failed Payment**, **User Dropped Payment**, **Refund**, and the applicable **Dispute Created/Updated/Closed** events. Reconciliation polls are also present. Do not subscribe to unrelated Payouts/Subscription/instrument events. Review any extra settlement/charges event before enabling it: unknown signed events can create restricted review work and do not grant entitlement.
4. The server also supplies `order_meta.notify_url` with this same route when creating an order. Dashboard and order notifications can overlap; durable deduplication and financial uniqueness must make that harmless. Inspect the dashboard's `NOTIFY_URL` and custom-endpoint retry configuration so retries actually occur during temporary failures.
5. Keep the exact webhook route reachable by Cashfree through staging/maintenance/cohort ingress while keeping general staging access restricted. Remove neither signature verification nor general access control. Do not add a provider credential to a URL, bypass TLS, or expose the private administration listener. Preserve request bodies/headers unchanged through proxy/WAF; do not inject challenges, authentication redirects or cached responses.
6. Use the dashboard's **Test** and then genuine sandbox transaction deliveries. A reachable test callback alone does not prove capture/refund parsing. The included handler returns exactly **HTTP 200 with an empty body after durable inbox commit**, including duplicate valid deliveries. Cashfree's documented retry policy requires 200; a generic 204 success is insufficient for that contract. Forged signatures fail, and database/inbox failures remain retryable. Verify the actual response and retry cessation before enabling live delivery.

The adapter uses the current API secret for HMAC-SHA256 of the timestamp string followed by the **exact raw body**, Base64 encoded and compared in constant time. Headers are `x-webhook-timestamp` and `x-webhook-signature`. Bodies are bounded at 256 KiB. It rejects duplicate signature/timestamp headers and timestamps more than five minutes in the future; older authenticated retries rely on durable deduplication instead of an arbitrary short delivery-age cutoff. The inbox stores a minimal normalized event, never the raw customer/card/bank payload. A signed success event triggers a server fetch; it does not grant Premium directly.

See [webhook configuration](https://www.cashfree.com/docs/payments/online/webhooks/configure), [delivery/retry overview](https://www.cashfree.com/docs/payments/online/webhooks/overview) and [signature verification](https://www.cashfree.com/docs/api-reference/payments/latest/webhooks/signature-verification).

## 7. Understand and verify the checkout sequence

The included browser implementation loads `https://sdk.cashfree.com/js/v3/cashfree.js` only after the user explicitly continues to Cashfree. It calls `Cashfree({mode: 'sandbox' | 'production'})` and `checkout({paymentSessionId, redirectTarget: '_self'})`. This is a full-page hosted redirect, with card/UPI entry handled by the provider. The v3 CDN URL is versioned by major path, not an immutable content hash; record observed SDK behavior during release acceptance.

The compiled CSP permits `https://sdk.cashfree.com` for scripts and the SDK plus the selected API origin for connections. It does not add unrestricted wildcards or a payment iframe. Confirm the real sandbox flow in browser developer tools without exporting sensitive network captures. If an additional provider origin is genuinely required, review and add that exact origin in `web/src/lib/config/payment-csp.mjs`, rebuild and retest; do not relax the entire CSP.

| Stage | Included application contract | Required result |
| --- | --- | --- |
| Sign in | `/account/premium` | Current account; guests cannot buy |
| Catalog | `GET /api/v1/premium/plans` | Enabled immutable server offers, correct environment |
| Create purchase | `POST /api/v1/payments/orders` | `plan_id`, `plan_version`, stable `idempotency_key`, `customer_phone`; no client amount |
| Provider order | Backend `POST /orders` | Intent committed first, exact integer-money snapshot, stable order reference |
| Resume unknown/ready purchase | `POST /api/v1/payments/checkout` | Existing `purchase_ref`; same provider order, no blind replacement |
| Hosted redirect | Provider SDK | Server-issued `payment_session_id`; returned environment matches build |
| Return | `/payment/status?purchase_ref=<opaque-reference>` | Authenticated server verification; browser result grants nothing |
| Recheck | `POST /api/v1/payments/verify` | Server fetches order, all payment attempts and refunds |
| Entitlement | `GET /api/v1/me/premium` | One committed FIFO lot for one validated capture |
| Receipts | `GET /api/v1/me/receipts`, optionally `/{purchaseRef}` | Only that account's retained financial receipt |
| Refund status | `GET /api/v1/payments/{purchaseRef}/refunds` | Honest pending/processed/review state |

Browser mutations require the current account cookie, exact Origin and `X-CSRF-Token` from the existing authentication bootstrap. The return query contains an opaque purchase locator, never credentials or contact data; it is not proof of ownership. Keep query strings and account paths out of logs/analytics. Do not implement a browser-side Premium switch.

The payment-only phone is collected for the provider, disclosed before submission and kept out of the NoTitle account, peers and ledger. This implementation accepts an Indian ten-digit mobile number starting 6–9, optionally prefixed `+91`; optional customer email/name are omitted. Use the user's real contact in production, not a dummy value. Confirm provider/bank notification behavior during merchant review. Ordinary registration still requires neither phone nor email.

The backend uses fixed `https://sandbox.cashfree.com/pg` or `https://api.cashfree.com/pg` origins and `x-api-version: 2026-01-01`. It sends App ID/secret only in server headers, uses bounded eight-second provider requests and deterministic UUID-shaped idempotency keys. It does not follow provider redirects or inherit an arbitrary proxy. Successful capture validation checks merchant/environment, order/customer association, INR, exact amount, `SUCCESS`, captured status and timestamp before a ledger grant.

Official references: [API version/endpoints](https://www.cashfree.com/docs/api-reference/payments/latest/overview), [create order](https://www.cashfree.com/docs/api-reference/payments/latest/orders/create-order), [hosted checkout](https://www.cashfree.com/docs/payments/online/web/redirect).

## 8. Run the sandbox acceptance sequence

First generate authentic dependency locks on the supported Docker/registry environment and run cumulative verification:

```bash
./scripts/bootstrap.sh prepare
./scripts/verify.sh
```

Review generated locks/formatter changes before recording a candidate hash. `verify.sh` includes synthetic provider/unit/database/browser boundaries; it is not a real Cashfree test transaction. The source-only command `./scripts/phase10-source-check.sh` is also insufficient for gateway acceptance. `scripts/smoke-payments.mjs` deliberately tests the **disabled** integration on disposable data; do not point it at a live merchant or treat it as an enabled payment test.

After the controlled sandbox configuration, approved test catalog and webhook route are ready:

1. Register two synthetic test accounts and retain recovery codes only in their protected test record. Confirm a guest cannot purchase and one account cannot access the other's order/receipt/refund URL.
2. Use Cashfree's current [sandbox test data](https://www.cashfree.com/docs/payments/online/resources/sandbox-environment) for simulated instruments only. Do not enter production card details into test scripts or retain screenshots containing instruments/customer contact.
3. Buy each enabled plan from `/account/premium`. Verify the server display matches the submitted order; inspect hosted success, failure and user-abandoned flows. Only a server-verified successful capture may add the exact duration.
4. Close the browser before the return, lose connectivity, press Back, reload, and return after the account session expires. Resume/sign in and inspect the existing purchase. It must be recoverable without a duplicate purchase or an assumed success/failure. Test Android Chrome and physical iPhone Safari, then desktop Chrome/Edge/Firefox/Safari; browser emulation alone is insufficient.
5. Retry the same purchase request/key after a simulated timeout; change the plan under that key and confirm conflict. Exercise provider timeouts after create, delayed capture, failed attempt after success, duplicate events and concurrent browser/webhook/worker verification. Record one grant per purchase; a genuine extra capture must become a financial exception.
6. Test exact-byte signature tampering, wrong environment/secret, malformed/duplicate headers, delayed valid retries and database/inbox failure. Acknowledgement must follow durable commit. Replaying a valid event cannot grant or refund again. Use test fixtures or deliberately controlled sandbox fault injection, never raw production payload copies.
7. Buy stacked plans; consume some of the first lot. Test strict preferences at expiry, refund/hold, explicit Continue with everyone and all account/guest matching combinations. An untouched later lot must not be charged for use of an older lot. Run projection/replay tests for exact money/seconds.
8. Complete the refund procedure below for full, partial money-only, explicit partial-duration, failed, pending and timeout outcomes. Include dashboard-initiated refunds, duplicates, dispute deadline handling and deletion before a late payment/refund event.
9. Keep processing on while disabling new checkout and while draining maintenance admission. Existing jobs, signed webhooks, receipts and refund reconciliation must continue when their dependencies are healthy. Restart/restore tests must not erase paid obligations or resurrect deleted identities.
10. Complete `phase8-acceptance.md`; attach sanitized commands, provider references, source/image/config identities and failures to restricted evidence. Also include payment jobs, refunds, expiry and backups during both mandatory six-hour **200-connected / 25-call** workloads. Record actual results, not ticked boxes.

## 9. Perform an audited operator refund

Provision a separate operator through `adminctl` using `phase5-moderation.md` and current operations instructions. Give the minimum `billing_operator` role (or reviewed `owner` scope), enroll TOTP through the protected enrollment file, and confirm private login. There is no default billing user. Keep private host/origin, gateway access, MFA keys and migration credentials separate from the public application.

1. Log in to the private administration origin with password and MFA. Open `/billing`, enter the work purpose (5–1,000 characters), and open the relevant purchase using its stable internal reference. The backend audits disclosure. A phone number, amount or screenshot is not ownership proof.
2. Review the original immutable terms, successful payment ID, existing pending/processed refunds, disputes and provider dashboard. Reconcile any earlier unknown request before creating a new one. Multiple successful instruments require restricted review because this integration's refund API targets the order, not an operator-selected instrument.
3. In **Preview a refund**, enter the verified payment ID, **integer paise**, decision reason and treatment. `money_only` is the default partial-compensation treatment. `full` requires the full original capture with no earlier pending/processed refund. `duration` requires an explicitly approved positive number of whole seconds; do not infer seconds by dividing money.
4. Inspect captured/refundable amounts, originating lot's available time, paid-controls-use flag, purchase age and current revision. The UI signs the exact selection, operator session and revision for up to ten minutes. Those flags support the approved policy; they do not decide legal eligibility.
5. Confirm once. The application commits the refund request and applicable originating-lot hold before external provider work. Preserve its request key/reference. If the response is lost, inspect the existing request and reconcile; do not submit a fresh key merely because the screen timed out.
6. Reopen the order to verify the status and Cashfree association. `pending` means outcome outstanding, `processed` means provider-confirmed processing, and `review` needs investigation. Definitive failure releases unused held seconds starting at resolution. A successful full refund revokes only this purchase's remaining held time. Partial money-only compensation does not reduce time.
7. Verify refund status with the requester through the approved support channel. Provider processing is not proof of actual bank credit. Keep original fees/taxes and refund reserve obligations in the financial review.

The adapter uses ordinary `STANDARD` refunds. It sends new API refund requests at or beyond **180 days** to restricted review; this is the implemented conservative cutoff, not a newly verified universal merchant entitlement. Confirm the applicable provider/method window with Cashfree. No Payouts or automatic external bank-transfer fallback is implemented. The annual offer must stay unavailable until valid later claims have an approved, ownership-checked, audited procedure with duplicate-disbursement prevention and reconciliation. Do not change a pending request to failed or edit the ledger manually to simulate its completion.

Provider contract: [create refund](https://www.cashfree.com/docs/api-reference/payments/latest/refunds/create-refund), [get refund](https://www.cashfree.com/docs/api-reference/payments/latest/refunds/get-refund), [all order refunds](https://www.cashfree.com/docs/api-reference/payments/latest/refunds/get-all-refunds-for-an-order). Validate these using the merchant's actual sandbox responses before live approval.

## 10. Reconcile captures, refunds and settlements

The existing Go process handles durable PostgreSQL jobs; no additional worker host or paid queue is needed. Unknown/pending order and refund reconciliation is scheduled in bounded batches every five minutes. Daily gateway and settlement reconciliation uses `POST /recon` and `POST /settlement/recon`, durable cursors and bounded retries. Failed/unknown jobs create restricted review obligations. A marked-resolved review case does not move money, grant access or establish settlement.

Primary/backup billing operators must:

- Investigate known successful payments not granted within five minutes, overdue unknown requests, dead/review jobs, signature delivery failures and growing backlog.
- Compare provider captures/refunds, application lots/adjustments and receipt totals. Duplicate captures must appear as real extra money obligations, not be hidden by the plan price.
- Compare daily provider reconciliation totals, gateway fees and fee taxes, net settlement references and actual bank credits. Perform a recorded weekly review at minimum and act promptly on exceptions. A dashboard “settled” row alone is not independently observed bank credit.
- Preserve financial retention after identity deletion without recreating the account. Keep restricted evidence and bank records out of general release logs/source archives.
- Rehearse database/WAL recovery with independent deletion/hold journals, revoked restored sessions and provider reconciliation across the lost interval before reopening.

Use the protected operator views; do not expose a public financial dashboard or write SQL to mark captured/processed/settled. The application's read-only financial receipts are not an accounting-system replacement. Accountant-approved invoices, records and reconciliation ownership remain required.

## 11. Rotate keys and handle outages

For planned key rotation, pause new checkout (`CHECKOUT_ENABLED=false`) while retaining `PAYMENTS_ENABLED=true`. Coordinate provider regeneration and delivery semantics; the old key may cease authorizing API calls immediately. Provision the new current credential files and, when provider retries require it, the prior secret in a distinct protected `previous_secret` file. Set:

```text
CASHFREE_PREVIOUS_SECRET_CONTAINER_FILE=/var/lib/notitle/payment-keys/previous_secret
CASHFREE_PREVIOUS_SECRET_UNTIL=<actual-RFC3339-deadline-within-next-24-hours>
```

The placeholder is intentionally not executable configuration. Restart through the one-owner deployment/drain procedure, check new-key API access and both intended webhook cases, and reconcile any delivery gap. Previous-secret acceptance is verification-only and expires automatically; it is not an API-key fallback. Remove both rotation variables and the retired file after expiry, then restart with the current-key-only configuration. For a suspected compromised key, decide whether overlap is appropriate before retaining any old verification authority.

For provider outages, stop new checkout if needed and keep existing durable financial processing/retry state. Do not delete pending orders, grant from browser screenshots, assume a timeout failed or create replacement references. Database/clock/invalidation uncertainty must pause affected paid matching. Preserve support and safety access according to their own health constraints. Roll back only schema-compatible application images; never restore an older database simply to undo a release.

## 12. Move to live and launch

1. Finish the complete build, database, sandbox, security, mobile/device, load, backup/restore, rollback, legal/operator and tax gates for the exact source/configuration/image candidate. Resolve all critical money-integrity or security issues. Prepare named primary and backup operators and real monitored alert delivery.
2. Record written merchant approval for the real NoTitle product, approved disclosures/catalog, whitelisted live domain, live keys, actual fees/settlement schedule and annual-refund process where annual is enabled. Install the separate production configuration and schema with no sandbox-data promotion.
3. Build the production frontend with the correct canonical origin/SDK environment; deploy exactly one Go owner with immutable reviewed images, protected secrets, current policies and all required services. Production starts in maintenance. Leave public ingress restricted.
4. The owner must separately authorize bounded real-money validation with actual payer consent, amount/offer, limits, operator and evidence scope. Follow `phase10-launch.md` for the finite protected validation permit and private owner/MFA admission. Source tests or this guide do not authorize charges/refunds.
5. Within that authorized scope, perform a real hosted capture, verify exactly one grant/receipt, perform the reviewed refund, verify provider outcome and independent settlement/bank evidence when available. Do not call sandbox transactions or unobserved bank credit a live pass. If settlement arrives after the validation window, keep public admission closed and collect evidence through permitted financial processing.
6. Close the remaining launch evidence gates and request the actual deliberate owner launch decision. Begin the approved supervised cohort and expand only after its operating cycle and coverage checks. Retain the **200 connected / 25 simultaneous two-person calls** requirement; configured limits are not measured capacity.

## Troubleshooting

| Symptom | Check and next action |
| --- | --- |
| No plans visible | Schema 9 applied; reviewed newer catalog versions enabled; annual runtime/database gates. The seeded draft rows intentionally remain unpublished. |
| Checkout unavailable / 503 | Integration and checkout flags, identity/safety/admin prerequisites, maintenance/validation admission, healthy clock/database and correct environment. Preserve existing orders. |
| API fails startup reading credentials | Absolute paths, UID/GID 65532 ownership, regular files, private modes, correct mount; inline credential variables must be absent. |
| SDK blocked or checkout will not open | Rebuild settings, actual whitelist approval, environment/session pairing and observed narrow CSP errors. Do not expose keys or use a wildcard policy. |
| Cashfree reports success; Premium inactive | Inspect stable purchase, authoritative fetch/reconciliation job, exact amount/currency/capture state, missing association or publication fence. Browser success cannot override the ledger. |
| Webhook test fails / retries persist | Exact URL/method, unchanged raw bytes, content type, signature/timestamp headers, current/previous keys, provider-required success response after inbox commit, staging/WAF/maintenance routing. |
| 409 on refund confirmation | Preview expired or financial revision changed; reopen the audited order. First reconcile any unknown earlier submission and preserve its request key. |
| Refund stays pending/review | Original request/provider IDs, provider status, duplicate instruments, cutoff, balance and worker health. Never issue another refund blindly. |
| Provider processed but user has no bank credit | Follow the approved provider/bank tracing process; report the state accurately and do not fabricate a credit date. |
| Payment fees/net do not match | Confirm merchant contract, method-specific fee/tax, refund/chargeback adjustments, report period/currency and actual bank credit. No fixed advertised rate is assumed by code. |

## Source and documentation references

Implementation: `server/internal/config/payments.go`, `server/internal/cashfree/`, `server/internal/payments/`, `server/internal/billing/`, `server/internal/admin/billing*.go`, `server/migrations/00007_billing.sql`, cumulative migrations 8/9, `web/src/lib/payments/`, `web/src/lib/config/payment-csp.mjs`, and `deploy/payments/`.

Official Cashfree contract documentation was checked on **10 October 2026, Asia/Kolkata** (9 October UTC). The links above record the sources used for account/keys, environments/API version, hosted SDK, whitelisting, webhook authentication/delivery and refund contracts. Their review does not establish successful merchant onboarding, a transaction, live settlement or compatibility of future provider changes. Recheck the pinned contracts and exact dashboard configuration when executing this guide.
