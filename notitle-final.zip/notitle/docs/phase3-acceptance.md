# Phase 3 acceptance — guest accounts, profiles and deletion foundation

This phase implements the V3.2 identity scope. Source implementation is separate from acceptance. See `PHASE3_STATUS.md` for checks actually executed. Later realtime, friendship, audio, moderation, payment and full erasure workflows are not activated.

## Identity and privacy

- Entry requires an explicit Male/Female/Other selection, adult confirmation and the current Terms, Privacy and Community versions. No phone, email, date of birth, employer or identity document is requested.
- Guest identities, consent, verifiers and handoff reservations live only in the one coordinator. Authorized activity refreshes the 30-minute idle deadline; the 24-hour absolute deadline never slides. Restart ends guest sessions.
- Registration enforces the private username rules, bounded Unicode display/bio fields and controlled topic/professional vocabularies. Guest registration confirms the existing gender and transfers the same participant slot. Existing-account login does not import guest relationships.
- The peer DTO contains only display name, self-declared gender, bio and topic. The owner DTO may include their own private username/professional choices. No raw database model, account/session ID, credential verifier or entitlement enters a peer response.
- Profile PATCH uses a client version. Omitted fields are retained; blank or invalid gender is rejected. A stale version returns conflict rather than overwriting a newer edit.

## Authentication and lifecycle

- Argon2id hashes use independent random salts, bounded parsed parameters and at most two concurrent hashing jobs. Measure actual latency and peak RSS on the target VM before acceptance.
- Random 256-bit session secrets rotate on login, registration and credential changes; only hashes are retained. Session expiry is seven days idle and thirty days absolute. Sensitive operations require authentication within five minutes.
- Recovery uses the private username and saved high-entropy code. Password reset and code rotation invalidate prior sessions and the previous code atomically. Replay and concurrent reset attempts fail safely.
- All mutations, including unauthenticated entry/login/recovery, require exact Origin, JSON content and an independent CSRF token. Rate-limit rejection occurs before expensive password work. Duplicate cookies, unknown fields, oversized bodies and invalid methods fail safely.
- HTTPS cookies have Secure, HttpOnly, SameSite=Lax, Path=/ and no Domain. Only explicit loopback development permits separate insecure cookie names. No credentials enter browser storage, URLs, logs or telemetry.
- Logout revokes the current session. Logout-all revokes every account session. Transaction guards prevent a request authenticated before a concurrent logout, recovery or deletion from mutating afterward.

## Deletion and recovery barrier

- A recently reauthenticated, confirmed deletion immediately changes account status, revokes all sessions and invalidates coordinator identity references in the initial transaction/lifecycle operation.
- Deletion starts a job awaiting approved retention rules. User status distinguishes access disabled from independent tombstone durability and completed erasure; Phase 3 never reports full erasure.
- The journal is a dedicated protected volume outside the PostgreSQL volume. Atomic publish, file and directory fsync precede durable acknowledgement. Failed publication remains pending and receives bounded retries.
- Startup keeps identity routes/readiness closed until journal replay has disabled affected accounts in the current database. Stop the API before any database restore and restart it against the retained journal. Do not restore a live database underneath the running API.
- Before production, establish encrypted off-host journal/database backup, retention/legal holds, restore drills, monitoring, disk-full handling and the final erasure worker. A separate volume on one machine does not survive loss of that machine.

## Verification

Run `./scripts/bootstrap.sh prepare` with approved registry access to generate genuine dependency locks and formatting. Then run `./scripts/verify.sh`. It must execute Go vet/race/tests, mandatory real PostgreSQL integration and least-privilege checks, migration up/down/up, frontend type/lint/build/browser checks, vulnerability checks and real Caddy/API lifecycle smoke tests. Tests must not silently skip database integration in this gate.

Test physical Android Chrome and iOS Safari first, then desktop keyboard/screen reader and viewport reflow at 320–1920 CSS px. Test password managers, mobile keyboard, once-only recovery display, expired sessions and simultaneous tabs. Browser mocks exercise UI only; they do not establish backend or database acceptance.

The full-V1 target remains at least 200 connected participants including 25 simultaneous two-person calls. This phase introduces no matching/audio implementation or load-test result. Capacity and real device acceptance remain required later.
