# Phase 4 acceptance — realtime shared matchmaking and reconnect

This phase implements blueprint V3.2 Phase 4. Source delivery is not runtime or production acceptance. `PHASE4_STATUS.md` records evidence actually collected. Earlier identity, deletion, policy and mobile-first requirements remain in force. Text sending, report/block user workflows, audio, friendships and checkout remain later phases.

## Matching invariants

- Guests, Free and trusted Premium test identities share one bounded authoritative pool. No tier or profession bucket, overlap threshold or added wait stage is permitted.
- Both directional gender requirements, valid identities, availability, restrictions and reciprocal blocks are hard constraints. Specific gender requires active server-issued entitlement. Clients cannot name a peer or supply authorization snapshots.
- Select the oldest participant with a feasible partner, then score every compatible candidate by uncapped waiting age minus recent-pair penalty plus bounded relevance. An unmatched strict preference must not block unrelated pairs.
- A shared non-General topic adds at most 0.5 waiting-seconds. Each professional category contributes at most 0.1 per Premium direction, averaged across two directions for a maximum of 0.5. Choices use OR; interests use capped overlap. Unknown fields and No preference contribute zero. General Talk disables professional influence. Both bonuses vanish when either participant has waited five seconds.
- Commit both reservations and one interaction epoch in one owner turn. Match on relevant changes and a 100 ms timer. Profile changes while waiting update indexing; the active peer projection stays frozen until the next interaction.
- A prior pair is prohibited for four seconds, then receives the decaying penalty `60 * exp(-(t-4)/10)` until five minutes. If it is the only compatible pair, rematch at four seconds. Two skips in a minute show an advisory and never create a hidden exclusion.
- Premium expiry pauses strict gender searches until renewal or explicit Continue with everyone. Saved strict choices are retained. Everyone searches continue with professional influence disabled. Production authorization is Free in this phase; paid fixtures exist only inside tests.

## Connection, identity and privacy invariants

- Ticket creation requires cookie authentication, CSRF and exact Origin. Tickets are 256-bit, one use, 60-second secrets, held hashed in bounded memory. `/ws` accepts no query string; its first frame must authenticate within five seconds. Quotas precede participant allocation.
- Validate every envelope, including version, ID, connection generation, schema and interaction epoch. Reject duplicate keys, unexpected fields and unsupported later-phase actions. Ordinary frames are capped at 8 KiB; compression is disabled.
- One identity has one participant binding. A second tab requires explicit takeover, ending the old interaction before becoming active. Connection generations never repeat within the process. Old Detach, Next or End commands cannot affect a successor.
- Next ends both sides and queues only the initiator; End leaves both idle and preserves identity. Successful commands are deduplicated in a bounded connection context. An old epoch cannot affect a later match.
- A disconnected waiter leaves immediately. A matched peer is notified and retains bounded state for 25 seconds. Resume requires a current identity, secret, same server instance and epoch. At expiry, purge the interaction; restart cannot resurrect it. No transcript or message replay is implied by this phase.
- Heartbeats run every 20 seconds; dead connections expire at 45 seconds. Writes, outbound buffers and authorization jobs are bounded. Slow readers close recoverably without blocking the coordinator. Reconnect uses bounded backoff with jitter and never automatically starts a new search.
- Guest registration preserves the slot and references, rotates the cookie, and requires a fresh authenticated transport. A peer who left during upgrade is never recreated. Logout, deletion, recovery and credential changes revoke affected bindings.
- Dependency failure stops new matches, then ends existing sessions after a controlled five-second owner window if unresolved. Failed safety-state publication latches the owner closed until restart. Database/network work never runs inside the live-state owner.
- Private usernames, professional fields, account/session IDs, credentials and authorization snapshots never enter peer DTOs, logs or browser persistence. Tickets and resume secrets remain browser RAM only.

## Implementation and deployment sequence

1. Extract the cumulative source and read its status record. On a machine with Docker and approved registry access, run `./scripts/bootstrap.sh prepare` to resolve genuine dependency locks and format source. Review the resulting changes.
2. Run `./scripts/verify.sh`: source checks, Go vet/race tests, mandatory PostgreSQL integration, runtime grants, migration 3→2→1→absent→3 on a disposable database, Svelte type/lint/build/browser checks, vulnerability scans and real Caddy/identity/WebSocket smoke tests.
3. Start local development with `./scripts/bootstrap.sh`; inspect `/chat` and `/preferences` in two independent browser contexts. Use `./scripts/bootstrap.sh static` for the built Caddy deployment at localhost:8080. A second live tab must request takeover.
4. Test physical Android Chrome and iOS Safari first, then desktop keyboard/screen reader use. Check 320–1920 CSS px layouts, mobile keyboard, background/resume, network switching, takeover, identity expiry, restart and logout from another tab. Browser mocks establish UI behavior only.
5. Exercise fixed-clock policy, actor lifecycle/concurrency, parser fuzz seeds and real WebSocket tests. Run `go test ./internal/realtime -fuzz=FuzzEnvelopeDecode -fuzztime=60s` from `server/` on the pinned toolchain. Save failures without user credentials.
6. Benchmark 200 authenticated connected participants and the separate 100-waiter admission bound on the intended host. Record command/match processing p95/p99, reconnect latency, DB pool wait, CPU, peak RSS and slow-reader behavior. Hard-filter wait is not processing latency. Fixtures alone do not establish end-to-end capacity.
7. For controlled deployment, apply migration 3, use reviewed immutable image digests, configure the real HTTPS origin, reviewed identity policies and `REALTIME_ENABLED=true`, and keep one API replica. Deployed feature flags default off. Preserve the independent deletion journal and verify restore/restart behavior.
8. Public release remains gated by later feature and business/legal/security/backup acceptance. Test the required 25 simultaneous two-person calls when media exists; this phase cannot certify audio capacity.

## Cost and scaling boundary

Phase 4 adds no paid provider or host. Incremental subscription cost is ₹0/month and ₹0/year assuming the existing application/database host has measured headroom; this excludes existing hosting, backups and network costs and is not a capacity guarantee. One maintained Go WebSocket dependency handles server framing. The frontend remains static; no Node application server, Redis, broker or hosted realtime service is added.

Admission is bounded at 200 retained participants, including reconnect grace, and 100 waiting. A 201st participant or 101st otherwise-unmatched waiter receives a safe capacity response; explicit takeover can replace an existing binding at the cap. Monitor sustained CPU, RSS, coordinator latency and DB latency before increasing limits. First optimize and vertically resize the host; separate PostgreSQL later if measurements justify it. Multiple API replicas require a reviewed ownership/routing design, never a replica-count change alone.

During mobile network-change testing, include a half-open old socket that the server has not yet timed out. Fresh cookie authorization plus the same current RAM resume proof must safely replace that transport without ending the interaction; late old commands and detach callbacks must remain harmless. During guest registration, navigate through the real UI, verify the same interaction resumes with the rotated account cookie, and verify that a peer who leaves during registration is never restored.
