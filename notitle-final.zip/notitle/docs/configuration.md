# Application configuration

`server/internal/config` is authoritative. `configuration.schema.json` describes the recognized variable subset, not the entire process environment. Diagnostics identify fields without echoing secrets. Origin configuration is enforced by the separate authenticated HTTP and WebSocket checks; configuration alone does not establish deployment acceptance.

| Variable | Default | Constraint |
| --- | --- | --- |
| APP_ENV | development | development, test, staging, production |
| PUBLIC_ORIGIN | http://localhost:5173 | Origin only; HTTPS in staging/production |
| LOG_LEVEL | debug in development; info otherwise | debug, info, warn, error |
| HTTP_ADDR | :8080 | Host and numeric port 1–65535 |
| DATABASE_URL_FILE | none | Required in staging/production; regular nonempty file at most 64 KiB |
| DATABASE_URL | none | Dev/test alternative; mutually exclusive with file |
| HTTP_MAX_HEADER_BYTES |16384|1024–1048576|
| HTTP_MAX_BODY_BYTES |65536|1024–1048576|
| DB_MAX_CONNS |8|1–20|
| DB_MIN_CONNS |0|0 through DB_MAX_CONNS|

| Positive Go duration | Default | Maximum |
| --- | --- | --- |
| HTTP_READ_HEADER_TIMEOUT |5s|1m|
| HTTP_READ_TIMEOUT |15s|2m|
| HTTP_WRITE_TIMEOUT |15s|2m|
| HTTP_IDLE_TIMEOUT |1m|5m|
| HTTP_SHUTDOWN_TIMEOUT |15s|1m|
| DB_MAX_CONN_LIFETIME |30m|24h|
| DB_MAX_CONN_IDLE_TIME |5m|1h|
| DB_HEALTHCHECK_PERIOD |1m|5m|
| DB_CONNECT_TIMEOUT |10s|1m|
| DB_READINESS_TIMEOUT |1s|5s|

Read-header timeout cannot exceed read timeout; readiness timeout must be shorter than HTTP write timeout. WebSockets use separate handshake, authentication, write and heartbeat deadlines; ordinary HTTP write deadlines must not terminate a healthy upgraded connection.

PostgreSQL URI requires postgres/postgresql scheme, user, host and database. pgx validates additional options without exposing raw parser errors. Local Compose uses sslmode=disable only on a same-host private bridge. A remote database needs reviewed TLS, normally certificate verification.

Connections use UTC, explicit search path,5-second statement timeout,3-second lock timeout and 10-second idle-in-transaction timeout. Readiness requires `notitle_app`, the exact foundation schema marker, no elevated role flags/memberships and no database CREATE/TEMP or schema CREATE privileges.

Coordinator admission limits are 200 retained realtime participants and 100 waiting, with waiting participants included within connected. A disconnected matched participant reserves its slot during the 25-second grace window. Enabled audio separately admits at most 25 simultaneous two-person calls; those 50 callers are included within the 200 participants. These are configured limits, not measured capacity.

Deployment-only ports, image references, hostnames and secret paths are documented beside Compose files. Frontend Vite configuration is public; never put secrets there.

## Phase 3 identity

`IDENTITY_ENABLED` defaults to `true` for development/test and `false` for staging/production. Enabling deployed identity requires explicit non-draft `TERMS_VERSION`, `PRIVACY_VERSION` and `COMMUNITY_VERSION` values; this configuration is not a substitute for the public release review or Phase 3 acceptance. Local policy version defaults are `draft-phase3-v1` and must never be presented as legal approval.

`DELETION_TOMBSTONE_DIR` defaults to `/var/lib/notitle/tombstones`. The Linux deployment uses a dedicated `deletion_tombstones` volume owned by UID/GID 65532, mode 0700. The image seeds the directory permissions for a new Docker volume. Existing volumes/bind mounts must be provisioned with those permissions by the operator. Do not put it inside PostgreSQL storage or include it in ordinary database rollback. Startup rejects an unsafe/unwritable journal and identity routes remain closed until replay succeeds.

The current production template gives the API a 768 MiB container limit, within the blueprint's roughly 1-GiB Go/connection planning envelope, including two concurrent 64-MiB Argon2 jobs and bounded live state. This is an initial budget, not measured capacity. Benchmark and tune before deployment; do not weaken hashing to hide insufficient memory.

Readiness includes the current cumulative schema version 9, restricted runtime role, coordinator and deletion replay barrier. A background worker retries up to 100 pending tombstones and prunes up to 500 expired/revoked sessions per minute. It does not perform unapproved account-data purges. Runtime policy values must exactly match the UI metadata endpoint.

## Phase 4 realtime

`REALTIME_ENABLED` accepts only `true` or `false`. It defaults on in development/test when identity is enabled, and off in staging/production. Explicit realtime enablement without identity is rejected at startup. Migration 3 is required even when realtime is disabled; it adds owner-private matching preferences and no conversation storage.

The deployed public origin is also the sole accepted WebSocket Origin. `/ws` rejects query strings and requires a fresh cookie-bound ticket in its first frame. Caddy proxies the upgrade; no additional port is published. See `docs/phase4-protocol.md` for fixed protocol, admission and memory bounds. No environment variable can enable Premium test fixtures.

The realtime dependency supervisor probes the identity replay barrier and database every two seconds, with one-second probe/publication deadlines. A known outage immediately stops matching; continued failure ends live sessions after the coordinator's five-second controlled window. Independent 30-second authorization leases prevent stale authorization from remaining valid indefinitely. Grace periods are not an availability SLA.

## Phase 5 text, safety and private moderation

| Variable | Default | Constraint and purpose |
| --- | --- | --- |
| SAFETY_ENABLED | On locally when realtime is enabled; off deployed | Exact `true`/`false`; requires realtime. The server text capability follows this flag, so realtime alone cannot enable text without safety. Disabling it does not bypass existing durable blocks/restrictions. |
| EVIDENCE_KEYRING_FILE | `/run/secrets/evidence_keyring` | Clean absolute path to a protected JSON keyring; load failures stop enabled safety startup. |
| CASE_RETENTION_DAYS | `30` locally | Integer 1–3650; deployed safety requires an explicit reviewed value. This sets case/evidence `retention_until`, not an automatic deletion job. |
| CASE_RETENTION_POLICY_VERSION | `draft-phase5-local` locally | Stored with the case and evidence authentication metadata. Deployed safety requires a non-draft 1–64 character policy identifier using letters, digits, `.`, `_`, `-`, beginning with a letter or digit. |
| MODERATION_COVERAGE_CONFIRMED | Unset | Must be exactly `true` for deployed safety after actual monitored report/grievance coverage and backup operations are established. |
| ADMIN_ENABLED | On locally with safety; off deployed | Exact `true`/`false`; requires safety. Deployed enabled safety requires enabled private administration. |
| ADMIN_ADDR | `127.0.0.1:9090` | Separate valid listener address. Containers may bind internally to `:9090` only with host-loopback publication and a protected access path. |
| ADMIN_ORIGIN | `http://localhost:9090` locally; no deployed default | Exact dedicated private origin; deployed HTTPS and a hostname different from the public application are required. Local development may use different localhost ports. It must be reachable only through an authenticated VPN/access gateway. |
| ADMIN_MFA_KEY_FILE | `/run/secrets/admin_mfa_key` | Clean absolute path, different from the evidence keyring; private regular file containing base64 of exactly 32 random bytes. |

These enablement checks record technical prerequisites and operator assertions. They cannot establish that a real moderator, backup operator, grievance route, reviewed retention policy, gateway or TLS deployment exists. The minimum private triage surface and MFA must pass the gates in `docs/phase5-moderation.md` before real-user use. No default operator account is created.

The evidence keyring contains `active_key_id` and `keys`, a mapping from key IDs to standard base64 values for 32-byte AES keys. IDs use 1–48 letters, digits, underscores or hyphens; at most 16 keys are loaded. The regular keyring file is at most 16 KiB and must not be world accessible; use mode 0600 unless a dedicated container secret group is necessary. New evidence uses the active key. Preserve older decrypt keys while retained evidence or recovery backups require them. MFA uses a separate private key with no group/other file permissions. Protect independent recoverable key backups; losing either key cannot be fixed by restoring PostgreSQL alone.

Migration 4 adds restricted case/evidence, blocks, account safety state, immutable moderation actions and legal-hold foundations. Migration 5 adds separate operator identities, MFA sessions and append-only audit. All cumulative migrations are required even when the corresponding feature flag is off. Private administration is a separate listener in the existing Go process, never an `/admin` route on the public application. Address validation checks syntax, not the host firewall; verify exposure from outside the private network.

Realtime always reads durable safety authorization, including while the text/report feature flag is disabled. Text sends and rendering acknowledgements use current coordinator snapshots under the existing 30-second authorization lease, refreshed every ten seconds, with the five-second dependency-outage teardown. They do not perform a PostgreSQL query per message. Priority safety publication and authorization fences make known blocks/restrictions immediate; the lease bounds otherwise stale authorization.

Enabled safety also activates the trusted guest-registration handoff hook and finalization worker. Fresh guest upgrades with safety disabled do not create pending safety work; an older durable pending fence remains enforced regardless of the flag. A crash-orphaned fence requires private reconciliation and is never automatically deleted to restore access.

Fixed text/report bounds are documented in `docs/phase5-protocol.md`. No public configuration enables arbitrary transcript archival, device fingerprints or Premium fixtures. Audio and approved payment integration have separate Phase 7 and Phase 8 controls below. The local 30-day case setting is not a legal conclusion. Phase 5 stores retention timestamps and hold foundations but **does not automatically purge cases/evidence or implement the full hold lifecycle**; the reviewed Phase 9 worker and recovery treatment remain launch gates. Core dumps must be disabled and unencrypted swap must not retain content-handling memory.


## Phase 6 mutual connections and invitations

| Variable | Default | Constraint and purpose |
| --- | --- | --- |
| FRIENDS_ENABLED | On in development/test when safety is enabled; off in staging/production | Exact `true`/`false`; requires `SAFETY_ENABLED`. Enables mutual connections and online invitations. Audio additionally requires the Phase 7 audio feature and accepted relay controls. |
| FRIENDS_PER_IDENTITY | `100` | Integer 1–100. One value is passed to both the coordinator and the database service so temporary acceptance, durable acceptance and promotion share the same admission limit. |

Migration 6 is required even with friendships disabled. It adds normalized account friendships and the account friendship revision used to reject stale persistence after Remove, Block or deletion. This account-wide fence may conservatively invalidate unrelated unpublished consent; retries must not rebase onto a newer revision. Already durable friendships are unaffected. Keep the single coordinator and existing PostgreSQL deployment; no queue, presence service, offline inbox or additional public port is required.

Accepted guest links remain bounded RAM state. Their existence does not refresh the guest's 30-minute idle or 24-hour absolute lifetime. Invitations expire after 30 seconds and require both participants to be online and available; acceptance uses the existing interaction allocator. The per-identity setting is an admission bound, not a user-capacity benchmark. Changes to limits require review of the tests and measured owner memory/latency. Lowering an admission limit is not authorization to silently delete existing mutual consent.

A deployed `FRIENDS_ENABLED=true` requires all existing identity, realtime, text/safety and private moderation prerequisites. It neither enables audio nor satisfies the full 200-connected/25-call acceptance target. Disabling friendship UI must not bypass durable blocks, restrictions, deletion cleanup or stale-write fencing.

## Phase 7 application audio controls

`AUDIO_ENABLED` defaults off in every environment, including local development. It requires safety, hence the existing identity/realtime, moderation and retention prerequisites where applicable. No separate database migration is required for ordinary audio; Phase 8 raises the cumulative schema to version 7. Enabling an app flag cannot create a relay host, firewall, certificate or functioning private control path.

| Variable | Default | Constraint and purpose |
| --- | --- | --- |
| AUDIO_ENABLED | `false` | Exact `true`/`false`; requires `SAFETY_ENABLED=true`. Enables accepted-call control only when a configured supervisor is usable. |
| AUDIO_SAFETY_VERIFIED | `false` | Production audio requires exactly `true` after the actual Phase 7 safety matrix passes. Controlled staging tests may enable audio to gather that evidence. This is an operator assertion, not a test result. |
| AUDIO_CONTROL_URL | Unset | Exact private supervisor origin, without credentials, path, query or fragment. HTTPS with mutual TLS is required except the explicitly enabled local loopback fixture below. Never use a public browser-facing route. |
| AUDIO_CONTROL_TOKEN_FILE | Unset | Clean absolute regular file with no group/other permissions, containing 64 hexadecimal characters encoding 32 random bytes. Required for enabled audio; no inline token or frontend value. |
| AUDIO_CONTROL_CA_FILE | Unset | Clean absolute protected file containing the trusted control-server CA. Required for remote HTTPS control; do not disable certificate verification. |
| AUDIO_CONTROL_CLIENT_CERT_FILE | Unset | Clean absolute protected file containing the application mutual-TLS certificate. Required for remote HTTPS control. |
| AUDIO_CONTROL_CLIENT_KEY_FILE | Unset | Clean absolute protected file containing the corresponding application private key. Required for remote HTTPS control; never include it in an archive. |
| AUDIO_RELAY_ADDRESSES | Unset | Comma-separated 1–8 approved public literal IP addresses. This is the exact SDP/candidate relay allowlist, not a hostname or CIDR range. Match the configured coturn public relay addresses. |
| AUDIO_ALLOW_LOOPBACK_HTTP | `false` | Exact `true`/`false`; development/test only. Allows a fixture supervisor at literal `127.0.0.1` or `::1` over HTTP. It never authorizes cleartext remote control or a staging/production exception. |

The application call cap and timing controls are fixed by the protocol: 25 simultaneous two-person calls, one outstanding request per interaction, 30-second ringing, 15-second decline cooldown, ten-minute credentials refreshed at five minutes, and a maximum 30-second renewable relay lease. Normal revocation must remove allocations within five seconds in the acceptance tests. Do not add environment overrides that silently weaken these limits.

Relay enforcement caps its internal lease at 24 seconds and also subtracts eight seconds from the application's transmitted deadline, reserving six seconds for cleanup and two seconds for cross-host clock skew. Use the earlier bound. Both hosts require synchronized, monitored clocks; the bounded skew allowance is an operating precondition, not a clock-synchronization service. A cancellation still present two seconds after its request stops coturn. See the runbook for confirmation and worst-case timing tests; the separate supervisor watchdog remains three seconds.

The loopback exception permits only an explicitly configured local HTTP fixture. An HTTPS control URL still requires all three TLS files even when the exception flag is true.

All base Compose stacks leave audio off. The optional `deploy/audio/compose.app.yml` overlay enables application audio settings and mounts the four control files read-only; merge it after the ordinary application deployment files only for the prepared environment. It adds no process, public port or additional host to the application stack. The dedicated relay has its own deployment. Existing safety flags and production review prerequisites must still be configured explicitly.

TURN configuration is a separate host concern described in `deploy/turn/README.md` and `docs/phase7-relay-runbook.md`. Keep the relay hostname DNS-only; expose UDP/TCP 3478, TLS/TCP 443 and the bounded 1,024-port UDP range 49152–50175. The private supervisor, coturn CLI and aggregate metrics must remain inaccessible publicly. Scope network access to the real application host or a protected tunnel. The app public origin and Caddy's HTTPS certificate are not substitutes for a trusted TURN certificate.

Revoked-credential tracking continues until each credential's original expiry. Restart must reconcile and clear old allocations before new leases are accepted. If the supervisor or its cancellation interface cannot establish trustworthy state, keep audio unavailable and retain text fallback. Report actual verification evidence before setting `AUDIO_SAFETY_VERIFIED=true`; no configuration setting certifies the 200-connected/25-call target.

## Phase 8 payment controls

Migration 7 and the financial ledger are cumulative schema requirements even with checkout/provider processing off. Existing paid rights cannot disappear merely because new purchases are disabled. Keep sandbox and production keys, references, datasets and ledger projections isolated. The payment worker uses the existing process/database; no additional listener, subscription or worker VM is required.

| Variable | Default | Constraint and purpose |
| --- | --- | --- |
| PAYMENTS_ENABLED | `false` | Exact `true`/`false`; enables configured provider processing and signed webhooks. Requires identity, safety and private administration. Does not independently authorize new checkout. |
| CHECKOUT_ENABLED | `false` | Exact `true`/`false`; requires `PAYMENTS_ENABLED=true`. Separate admission switch for creating/resuming hosted checkout while committed financial work can continue. |
| PAYMENT_ENVIRONMENT | `sandbox`, or `production` when APP_ENV is production | Only those two values. Startup rejects production payment mode outside production and sandbox mode inside production. Never promote sandbox data as proof of live money. |
| PAYMENT_MERCHANT_ID | `unconfigured` | Explicit configured merchant scope required when enabled, at most 128 characters; must pass provider reference validation. Account keys and responses must belong to this context. |
| CASHFREE_CLIENT_ID_FILE | Unset | Distinct clean absolute protected file for the provider client ID. No inline credential fallback. |
| CASHFREE_CLIENT_SECRET_FILE | Unset | Distinct clean absolute protected file for the current API/webhook signing secret; owner-only permissions. Never a frontend/Vite value. |
| CASHFREE_PREVIOUS_SECRET_FILE | Unset | Optional separate protected verification-only old secret during reviewed rotation. Requires the deadline below. |
| CASHFREE_PREVIOUS_SECRET_UNTIL | Unset | RFC3339 future instant no more than 24 hours ahead at startup. Required exactly when a previous secret file is provided; the verifier stops accepting it at that instant. |
| PAYMENT_MERCHANT_APPROVED | `false` | Required `true` for live integration after written underwriting accepts the actual service. It does not obtain approval. |
| PAYMENT_POLICY_APPROVED | `false` | Required `true` for live integration after actual tax/invoice, contact/privacy and refund policies are reviewed. It is not a legal determination. |
| PAYMENT_ANNUAL_APPROVED | `false` | Additional runtime annual-offer gate after unit-economics and later-refund approval. A reviewed enabled immutable database catalog version is also required. |

All four initial catalog proposals are disabled with pending tax review. Publish a new reviewed immutable plan version through the controlled migration/operator process; the runtime role cannot edit plan economics or enable itself. Local sandbox uses synthetic data and reviewed test-only plan fixtures, never a fake public capture endpoint. Provider request URLs and API version are pinned in the adapter; there is no arbitrary backend URL setting or way to use test keys in a production payment environment.

The clock guard compares wall-clock progress against monotonic elapsed time and latches on excessive drift. Keep host time synchronized and monitored; this check detects jumps relative to startup, not a uniformly wrong clock. Investigate and correct trusted time before resetting by controlled restart. Current-time entitlement checks and paid-matching invalidation must remain closed when clock health is uncertain.

The signed webhook route has its own bounded raw-body authentication before JSON parsing; ordinary account/payment mutations still require exact Origin, CSRF and current session. See `docs/phase8-payments.md` and `docs/phase8-acceptance.md` for financial worker, key-rotation, reconciliation, refund, deletion and live activation gates. Do not raise worker concurrency, database pool size or admission limits until the required combined workload demonstrates headroom.

## Phase 9 operations and recovery controls

Schema9 is cumulative even with `OPERATIONS_ENABLED=false` (the default). Phase9 adds bounded jobs in the existing Go process, PostgreSQL tables and a protected host observation file; no Redis, separate worker VM, paid dashboard or support email service. Merge `deploy/operations/compose.app.yml` only after the runbook is accepted.

| Variable | Purpose |
| --- | --- |
| OPERATIONS_ENABLED | Exact true/false; requires identity, safety and private administration. |
| OPERATIONS_KEYRING_FILE | Protected AES-256-GCM case keyring in the existing evidence-keyring format, with a distinct file/key and rotation history. |
| RETENTION_POLICY_FILE | Protected versioned JSON manifest. Deployed use requires actual approval and a matching independently installed immutable database policy. An application process cannot approve its own policy. |
| HOLD_JOURNAL_DIR | Dedicated API-owned0700 append-only hold/release journal, separate from the database and deletion journal directories. Restore and replay before identity admission. |
| OPERATIONS_OBSERVATION_FILE | Protected atomically replaced JSON observation. Measures host/relay resources, external availability, recoverable WAL/deletion/hold journal points and delivery drills. Never invent timestamps from local job success. |
| OPERATIONS_ALERT_PRIMARY_URL / OPERATIONS_ALERT_BACKUP_URL | Distinct approved HTTPS delivery endpoints; no query credentials, redirects, proxies or private-network destinations. Receiver envelopes contain only opaque event refs, fixed codes, severity and time. |
| OPERATIONS_ALERT_PRIMARY_TOKEN_FILE / OPERATIONS_ALERT_BACKUP_TOKEN_FILE | Separate owner-only credential files. Inline token variables are rejected. |
| OPERATIONS_COVERAGE_APPROVED / OPERATIONS_COVERAGE_REFERENCE | Required deployed assertion and evidence reference after real primary/backup coverage and delivery drills exist. These settings do not appoint or contact an operator. |

Use the template fields and installation instructions in `docs/phase9-operations.md`. Receiver failure must leave public case submission/status available while operations readiness fails. Account admission stays closed until deletion and hold journals replay. Destructive privacy jobs additionally require verified off-host recovery points covering the relevant records. Key, retention policy and observation directory mounts preserve protected host permissions. API runs as UID65532; keep secrets out of Compose values and archives.

The support boundary uses its own same-origin CSRF bootstrap and HttpOnly cookie so a complainant can use a saved status secret while identity recovery is unavailable. Status secrets and deletion receipts remain out of URLs, browser storage, request logs and notification payloads. Private operations routes are never mounted on the public listener.

Production requires already prepared independent journal directories; startup refuses missing paths instead of quietly creating a new empty recovery store. A path or recent timestamp cannot prove a complete remote inventory: restored journals must be checked against the verified off-host manifest before opening admission. Existing-database hold event count is checked against the complete replay stream.

Support rate limits use verified server-issued support cookies per visitor with independent global budgets, avoiding a shared Caddy IP bottleneck without trusting forwarded headers. Bootstrap/status have a shared300-request burst and20/second refill; regular requests have60/2 per visitor and300/20 globally. New case creation is10 burst then1/minute per visitor, globally30 burst then10/minute; exports are2 burst then1/5minutes per account and10 burst then2/minute globally. These bounded budgets require surge/abuse validation; configuration is not the200/25 performance proof.


## Phase 10 deployment admission and processing observations

| Variable | Default / requirement | Purpose |
| --- | --- | --- |
| MAINTENANCE_MODE | `false` in local/staging; production requires explicit `true` | Every production process starts paused. A restored database or replacement binary cannot inherit the previous process's open admission. |
| LAUNCH_STAGE | `validation` | `validation`, `cohort` or `public`; deployment validation binds this to the protected ingress stage. |
| LAUNCH_APPROVAL_FILE | None while closed | Absolute protected owner-only regular file produced by the release evidence verifier; symlink or writable parent chains are rejected. No inline approval boolean. |
| DEPLOYED_API_IMAGE | Exact immutable digest before opening | Must equal the permit's API image. The external deployment check must verify actual running images; an environment claim alone is not attestation. |
| DEPLOYMENT_MANIFEST_SHA256 | Reviewed manifest digest before opening | Must equal the permit's complete deployment binding. Follow the deployment verifier's projection; never create a self-referential hash. |

An owner with a current private MFA session opens `/operations/admission`. Every view and requested change rechecks the current owner role/session and commits its purpose audit. Opening checks live dependencies independently of the admission gate, then a protected permit bound to the binary's embedded source digest, API image, manifest, canonical origin, schema9 and exact 200-connected / 100-waiting / 25-call limits. An evidence reference is an opaque identifier, not approval by itself. The verifier and operator must review the effective environment and actual frontend/relay images against the manifest; the Go process cannot independently attest other containers.

A `purpose=validation` permit is accepted only for `LAUNCH_STAGE=validation`, lasts no more than two hours and requires the separately recorded prior authorization for controlled live-money checks. Its expiry automatically closes admission and ends interactions. A `purpose=launch` permit lasts no more than 24 hours for the **opening decision**; normal established operation does not require daily approval renewal. Full launch permits cannot be replaced by incomplete validation evidence. Validation ingress remains an authenticated restricted cohort, never public access.

The private drain action accepts 0–120 seconds, closes checkout admission immediately and serializes the live transition through the sole coordinator. It pauses waiting entries and cancels ringing calls/friend invitations, preserves active text and already accepted audio until the announced deadline, then ends remaining interactions and schedules terminal relay revocation. Repeating a drain cannot extend its deadline; reopening waits for the deadline and confirmed audio cleanup. End, Report, Block, public grievances, payment webhooks, owned payment verification and financial reconciliation retain their own healthy dependency paths. `/health/ready` reports503 while paused; `/health/live` remains available. The planned drain is a deliberate private action before ordinary SIGTERM, not a claim of zero downtime.

`server.draining` carries `{deadline: RFC3339 UTC}`; every paused session snapshot includes optional `maintenance:{deadline}` so reconnect/state synchronization restores the same announcement. New queue entries, friend invitation acceptance and new call consent are rejected by the server; client buttons are supplementary. Next still tears down its old interaction but cannot requeue during maintenance.

Private owner/operations-readonly users can download `/operations/metrics` through a CSRF-protected audited POST. The fixed JSON includes actual sample/process-start timestamps, Go heap/goroutines and three disjoint histograms with upper bounds `[1,5,10,25,50,100,250,300,1000,+Inf]` milliseconds. Overflow means an unknown finite percentile, never 1000ms. API timing covers the explicit ordinary-route allowlist, excluding hashing/provider requests, exports and WebSocket lifetimes. Message timing includes the accepted chat command's owner mailbox and processing. Match timing is `available_candidate_to_commit_upper_bound`: the later selected participant's queue command arrival through committed matching, including pending paid-use attribution. A later profile/authorization change can overcount; no-candidate waiting before the second person's arrival is excluded. Only the mandatory four-second rematch cooldown is subtracted, grounded in the recorded end and queue-processing times while retaining mailbox delay. No extra pair scan, identity labels or transcript retention is introduced. Counters reset with the process; the collector must compute interval deltas and reject missing/reset/overflow evidence. These measurements support, but do not themselves establish, the required six-hour real-media capacity tests.

The per-interaction accepted-send ledger is now bounded at16,384 receipts so the six-hour baseline's8,640 two-party sends at one send per person per five seconds does not hit the previous4,096 ceiling. Accepted IDs are never evicted and reinterpreted as new sends. At100 full ledgers the raw32-byte keys plus approximately48-byte receipt values are about125MiB, before map buckets/growth/GC. Ordinary content remains30 messages/64KiB. The actual Go/host memory envelope and25% headroom must be measured under mixed load; this arithmetic is not a capacity result.
