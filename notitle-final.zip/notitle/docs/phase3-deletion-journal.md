# Phase 3 deletion journal

The account deletion transaction first disables the account and revokes access.
Its tombstone is then written to a dedicated filesystem volume, separately from
the PostgreSQL data and ordinary database backup stream. A failed journal write
leaves deletion visibly pending; it must never turn a disabled account back on.
This is a local durability foundation. It does not establish off-host replication,
disk-loss recovery, approved retention periods or completion of the data purge.

The Linux journal requires a directory owned by the API's effective user with
mode `0700`. Its existing parents must be accessible; `Open` creates only a
missing final component. Directory components and record paths reject symlinks.
Records have mode `0600`; unexpected types, hard links, wrong ownership and
insecure permissions fail closed. An exclusive filesystem lock permits only one
process to own the directory. The documented Linux/Docker workflow is required;
non-Linux builds deliberately provide no weaker filesystem implementation.

Each version-1 record contains only the deletion UUID, account UUID, account
generation and UTC request time. Passwords, recovery codes, deletion receipts,
profiles and session secrets are absent. A record is staged privately, fully
written and fsynced, atomically renamed to its deletion UUID, then followed by a
directory fsync before success. Repeating the same tombstone finishes durability
if necessary; reusing its deletion UUID with different data is rejected. Records
are bounded to 2 KiB and use strict canonical JSON.

Startup must keep identity authentication unavailable until the whole journal
has replayed into PostgreSQL. Replay processes bounded batches of 64 entries;
callbacks must be idempotent and independent of ordering. Tombstones prevent a
database restore from reactivating an account whose deletion was already
acknowledged. Malformed live records or failed database application stop the
barrier. Crash staging files are never replayed as committed records; cleanup
uses a separate directory scan so deleting a staging file cannot skip a live
tombstone during application.

Do not clear, edit or rotate this volume as ordinary log maintenance. An empty
replacement volume cannot prove that historical tombstones were recovered.
Restore operators must verify independent journal continuity before reopening
identity access. Off-host encrypted journal backups, lost-volume detection,
restore exercises and legally approved tombstone retention remain release gates.

Meaningful source tests cover replay after reopen, exclusive ownership,
idempotency/conflicts, cancellation, multiple replay batches, concurrent writes,
malformed records, path/record symlinks, hard links, permissions and deterministic
file/directory fsync failures. They require the Linux Go runtime and are not a
substitute for host filesystem and power-loss recovery testing.
