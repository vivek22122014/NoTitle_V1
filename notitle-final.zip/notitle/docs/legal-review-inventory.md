# NoTitle Phase 2 legal review inventory

Prepared: 2026-10-09. Document version: 0.2.0-draft. Status: **unapproved; public launch blocked**.

This is an implementation and review inventory, not a legal opinion. The public routes contain meaningful draft copy for local/access-controlled previews. They must not be presented as an operative policy or a live support service. No officer, company identity, tax treatment, deadline or approval is invented. Responsible roles below are proposed responsibilities; a real named assignee and evidence of approval are still required.

## Publication controls

- `web/config/release.json` is the SEO/release configuration authority. Policy entries have route, version, owner, status, review date and approval-reference fields. Missing actual operator, grievance, tax and privacy values must fail a production build.
- Preview HTML is non-indexable. Public preview availability is not authorisation to publish draft legal information; staging additionally requires access control at deployment.
- `PolicyPage.svelte` shows each route's draft status, version and responsible role. Contact/officer values are displayed from approved release configuration only in production mode; drafts explain that verified details are outstanding.
- When a reviewed production configuration is supplied, the privacy page renders its actual statement, processor purposes/regions/safeguards, complete retention schedule, legal-hold workflow and request procedure. Refund copy renders the reviewed tax disclosure. Unresolved-review text remains restricted to preview mode. These data fields must agree with the implemented service and the reviewed policy body.
- An approved configuration value is not a substitute for reviewing the corresponding policy body. Review both in the same change. Do not mark approval merely to make a build pass.
- The release guard binds approval to the reviewed source/static/catalog digest in `release.approvals.contentSha256`. Generate the candidate with `npm run release:digest`, review the exact content, then record the approved digest with the real approval evidence. Changing reviewed content requires a new review; a checksum is not itself legal approval.
- The Phase 2 implementation has no complaint ingestion, protected case store, live reply channel, payment processing or account deletion. The pages say so. Do not remove those notices before the relevant workflows are implemented and verified.
- The release owner must perform a clean static rebuild after approvals; source changes do not revise already-built HTML.

## Route inventory

| Route | Draft version | Responsible review roles | Content and outstanding approval |
| --- | --- | --- | --- |
| `/privacy` | 0.2.0-draft | Business owner, privacy lead, appointed Indian counsel | Peer-visible fields; server-readable text; report evidence; audio/external recording limits; actual processors and purposes; cross-border processing; retention and rights request procedure. Approve exact promises against actual code. |
| `/terms` | 0.2.0-draft | Business owner and appointed Indian counsel | Adult-only eligibility, self-declaration, shared pool, tier boundaries, guest friendships, fixed-duration purchases, enforcement and complaint routes. Resolve operator identity, governing legal wording and consumer terms. |
| `/community-guidelines` | 0.2.0-draft | Safety lead and appointed Indian counsel | Consent, harassment, identity/privacy misuse, prohibited conduct, report/block access and proportionate enforcement. Approve reminders, notice versions and appeals. |
| `/refund-policy` | 0.2.0-draft | Business owner, billing lead, accountant and appointed Indian counsel | Proposed unused-within-24-hours rule; duplicate/undelivered access; service failure and statutory claims; individual purchase lots; provider limits; dispute treatment. The proposal is not an approved promise. |
| `/grievance` | 0.2.0-draft | Appointed Grievance Officer and Indian counsel | Publish actual officer and contact details; public no-login complaints, case-secret access, protected replies, category-specific deadlines, urgent escalation and appeal process. Officer assignment and operational workflow are missing. |
| `/account-deletion` | 0.2.0-draft | Privacy lead, engineering lead and appointed Indian counsel | Recent-auth request, immediate access revocation, relationship cleanup, purpose-specific retention, legal holds, backup restore deletion ledger and post-closure receipts. Workflow is not yet implemented. |
| `/contact` | 0.2.0-draft | Business owner and support lead | Actual legal operator identity, address and required incoming contact channels; protected support flow and service availability. No fake mailbox, working form or case reference is supplied. |

## Launch dependencies and evidence

| Decision | Evidence required before approval | Responsible role | Current status |
| --- | --- | --- | --- |
| Legal operator identity | Verified legal name, required address and contact details; authority to operate the service and publish those details | Business owner | Not supplied |
| Grievance ownership | Named and appointed officer, designation, verified contact/address, backup escalation coverage | Business owner / appointed officer | Not supplied |
| Applicable Indian rule set | Counsel's written assessment of classification, launch-date effective provisions and authoritative legal sources | Appointed Indian counsel | Not reviewed |
| Deadline schedule | Versioned categories, trigger/receipt time, effective date, legal source, due time, assigned owner and escalation; tests for urgent cases | Appointed officer / counsel / engineering | Not approved or implemented |
| Privacy and retention | Purpose-by-purpose matrix covering transient text, audio/traffic data, guests, reports, security logs, financial data, backups, rights and legal holds; exact legal effective dates | Privacy lead / counsel | Not approved |
| Processors and international processing | Actual vendors, service regions, purposes, data categories, retention, access terms and contractual safeguards | Business owner / privacy lead | Not finalised |
| Tax and invoicing | Accountant-approved classification, applicability, tax-inclusive consumer totals, invoice fields, record-retention duties | Accountant / business owner | Not supplied |
| Payment gateway | Merchant/product approval, required payment-only data, provider notification behaviour, refund limits, approved long-duration exceptions | Business owner / billing lead | Not approved |
| Refund promise | Approved unused definition and timing, usage flag, duplicates/undelivered access treatment, service-failure/statutory claims and consumer-facing wording | Business owner / counsel | Proposal only |
| Annual offer | Explicit economics decision plus an approved process for valid refunds beyond provider limits | Business owner / accountant / billing lead | Disabled pending review |
| Age handling | Review of self-attestation limits, suspected-underage restrictions and proportionate further assurance | Safety lead / counsel | Not approved |
| Support and appeals | Working no-login complaint route, secret-based status access independent of guest identity, in-app replies, retention and protected appeal workflow | Support lead / engineering | Future implementation |
| Incident handling | Applicable incident categories, actual reporting contacts, timing duties, time synchronisation and restricted security logging policy | Security lead / counsel | Future review and implementation |
| Rights and deletion | Verified authority checks, correction/export limitations, deletion ledger, hold review/release, post-closure financial access and restore rehearsal | Privacy lead / engineering | Future implementation |
| Final copy-to-code check | Signed review of rendered pages against deployed behaviour, processors, enabled catalog and dates; attach change/release identifier | Business owner / appointed reviewers | Not performed |

## Preserved product boundaries

- Anonymous **to peers** is qualified, not a claim of being untraceable. Display name/pseudonym, self-declared M / F / Other label, topic and optional Bio are peer-visible. Private account/profile/matching/payment details stay private.
- Gender declaration is required for every tier, with no default or undisclosed option. Matching is mutual. Professional preferences remain optional and very soft; they do not delay or exclude candidates.
- Ordinary text has no user history and a memory-only design baseline. Reports, safety evidence, financial records and applicable legal retention are separate purposes. Do not turn on undisclosed archival storage to resolve an unreviewed legal concern.
- Audio requires mutual acceptance. No product recording is planned; external recording cannot be ruled out. No video, attachment, transcript or offline-inbox feature is introduced.
- Guest friendships remain possible and temporary. Account-only persistence must not be confused with a requirement to register to add or contact a friend.
- No outgoing user-email provider or live support chat is introduced. The legally appropriate incoming/response channels still need counsel's approval; processor/bank notifications are separately disclosed.
- Purchases are one-time, fixed-duration and non-renewing. Public pricing, total-tax disclosure and checkout come from the same approved catalog. Annual availability requires explicit approval.

## Legal sources and dates

No statutory deadline is asserted by these draft pages. Do not copy a date or summary from this inventory as legal advice. The approved schedule must cite primary, current official notices/rules and their effective dates, including any commencement or corrigendum that changes applicability. Appointed counsel must reconcile the blueprint's cited IT Rules, CERT-In and DPDP references against the actual launch date and data flows. Retain that review as an auditable source document, not a generic `approved: true` flag.

The 24-hour unused-purchase window shown on the refund page is explicitly a **proposed commercial policy**, not a statement of a legal deadline. Final wording must preserve applicable statutory rights.

## Acceptance evidence

Phase 2 source review can establish that routes, notice metadata and guardrails exist. It cannot establish legal approval or the later operational workflows. Verify rendered draft labels and initial HTML, links, 320px reflow, keyboard navigation, 200% text scaling and production rejection of incomplete values. Record actual execution results in Phase 2's acceptance/status document; do not mark unrun browser or legal checks as passed.
