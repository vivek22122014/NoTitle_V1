# Phase 4 trusted authorization and saved preferences

`matchingauth.Service` joins identity, saved preferences, trusted entitlements and
safety state outside the single coordinator. Browser values never grant Premium,
choose an internal account ID or supply a restriction snapshot. The production
constructor wires `FreeEntitlements`; Premium cases are test fixtures until Phase
8. `NoModerationYet` explicitly marks the unfinished Phase 5 moderation boundary.
This source package is not ready for a public text beta without those controls.

The authorizer captures the coordinator's authorization fence before database
work, rechecks the current session by its stored verifier, obtains preferences
under the account/session guard, and returns a private snapshot. Attach and
refresh reject snapshots crossing an intervening lifecycle change. Snapshot
leases are at most 30 seconds and never extend an identity's absolute expiry.
Account/guest activity refresh cannot revive an already expired credential.
The readiness dependency covers both database readiness and deletion-journal
replay; guests also fail closed when this safety dependency is unavailable.

Successful account profile and preference responses wait for the coordinator's
update acknowledgment. Waiting entries reindex; active conversations retain the
original public peer projection, with edits taking effect at the next match.
Versions prevent delayed notifications from replacing newer state. A failed
notification revokes the live binding or invokes the global outage barrier and
returns an error. If both publication and live invalidation fail, an atomic sticky
coordinator latch blocks admission and matching until restart; a successful
database probe cannot clear it. Committed logout/recovery/deletion invalidation
failures use the same latch. Database work never runs in the coordinator loop.

## Owner API

`GET /api/v1/me/matching-preferences` returns `preferences`, `premium_active`,
optional `premium_expires_at`, and `requires_everyone_confirmation`.
`PATCH` submits the complete `preferences` object with its current `version`.
A stale write returns a conflict. Gender values are `everyone`, `male`, `female`
and `other`; this preference is separate from the required profile gender.

Professional preferences contain global `no_preference` and five categories:
`industry`, `profession`, `experience`, `interests`, and `topics`. A category has
`no_preference` and `choices`. Up to five distinct controlled values are allowed,
except interests which allow ten. Global No preference preserves saved category
choices. Selecting a category's No preference clears that category's choices.
General Talk disables professional influence without clearing saved data.

A Free or Guest request to enable a specific gender or active professional
selection fails with `PREMIUM_REQUIRED`. Expired saved preferences remain visible
and unchanged. A strict saved gender requires explicit Everyone consent for a new
search; there is no automatic broadening on expiry. Effective professional
ranking is computed by the trusted matching policy, never a client score.

Accounts use `notitle.matchmaking_preferences`; guest preferences stay in the
coordinator and expire with the guest. Account rows are lazily created with
version-one Everyone/No preference defaults. Migration `00003` changes readiness
to schema version 3. SQL validates vocabularies, array bounds, uniqueness and
NULL exclusion. Runtime credentials receive only SELECT/INSERT/UPDATE and the
immutable validation function's EXECUTE privilege; no schema ownership or DELETE.

## Verification status

Source tests cover pre-read fences, verifier refresh, revocation, expiry, trust
boundaries, fail-closed safety reads, strict-filter consent, version conflicts,
privacy copying and notification failure. Database integration tests cover
concurrent preference writes, deletion/revocation guards and storage constraints;
they run only against the disposable database configured by `scripts/db-check.sh`.
Required integration mode fails if credentials are missing. These Go and database
tests must actually pass in the prepared environment before acceptance; their
presence in source is not execution evidence.
