# Phase 3 API contract

The identity service is the shared contract in `server/internal/identity`. HTTP uses only `OwnerDTO`, `SessionDTO`, `PublicPeer` and `DeletionReceipt`, never a database or coordinator record. Account IDs, verifiers and session IDs are internal. A peer sees only display name/session pseudonym, gender, bio and topic. The owner may also see their own private username and professional choices.

Every API response is no-store. Mutating requests require the exact configured Origin. Once a cookie exists, mutations also require `X-CSRF-Token`; initial guest/login/registration/recovery use the anonymous CSRF bootstrap issued by transport. Cookies contain a freshly generated 256-bit secret, never a user ID. They are HttpOnly, SameSite=Lax, Path=/, no Domain; HTTPS uses `__Host-session` and Secure. Explicit localhost development may use a separate insecure development cookie. No browser storage is used.

## Service signatures

`New(Options) (*Service, error)` constructs the service. `Policies() PolicyVersions` returns the required versions. `StartGuest(ctx, GuestInput) (AuthResult,error)`, `Register(ctx, currentCookie, RegisterInput) (AuthResult,error)`, `Login(ctx,currentCookie,LoginInput) (AuthResult,error)`, and `Recover(ctx,currentCookie,RecoveryInput) (AuthResult,error)` create/rotate cookies. `AuthResult.CookieToken` is transport-only and must never enter JSON. Its `Session` is the response body, optionally accompanied by the one-time `RecoveryCode` and `HandoffState`.

`Authenticate(ctx,cookie,touch) (Principal,error)` resolves guests first and otherwise validates durable sessions. `Current(ctx,cookie) (SessionDTO,error)` returns the owner session and cookie-derived CSRF token. `UpdateProfile(ctx,Principal,Profile) (OwnerDTO,error)` accepts a complete merged profile with its expected `version`. HTTP PATCH preserves omitted fields and rejects explicitly blank required values; the database/coordinator atomically compares the supplied version and increments it. A stale edit returns a conflict. `Reauthenticate(ctx,Principal,ReauthenticateInput) (time.Time,error)` verifies the password and records recent authentication transactionally. `ChangePassword(ctx,Principal,PasswordInput)` and `RotateRecovery(ctx,Principal)` return `AuthResult` and revoke all prior sessions. Both require authentication within five minutes; rotate-recovery returns the replacement code once.

`Logout(ctx,Principal) error`, `LogoutAll(ctx,Principal) error`, `Delete(ctx,Principal,DeleteInput) (DeletionReceipt,error)`, and `DeletionStatus(ctx,receiptSecret) (DeletionReceipt,error)` handle session/account lifecycle. Deletion requires explicit confirmation and recent authentication; its job starts `awaiting_retention_review`. A receipt that says `tombstone_durable:false` represents disabled access with persistence pending, never completed erasure. `RetryTombstones(ctx,limit) error` retries bounded journal work without restoring access. `PruneSessions(ctx,limit) error` is a bounded maintenance hook.

## Body fields

Gender is explicitly `male`, `female` or `other`. Guest input is `{profile:{gender,bio,topic,professional:{profession,industry,experience,interests:[]}},consent:{adult_confirmed,policies:{terms,privacy,community}}}`. Guest display names are generated server-side. Registration adds `username`, `password` and a required `profile.display_name`; the existing guest gender must be explicitly confirmed. Profile updates require the current `version` and at least one supplied field. Login uses `username,password`; recovery uses `username,recovery_code,new_password`; reauthentication uses `password`; password change uses `new_password`; deletion uses `confirm:true`.

Session response: `{identity:{kind,username?,profile,expires_at,absolute_expires_at,reauthentication_until?},csrf_token}`. No recovery verifier or cookie is serialized. Controlled vocabulary and required policy versions are returned by transport's metadata endpoint from the service/package.

## Atomicity

All durable mutations check account status, account generation, matching unrevoked session and expiry inside the write transaction. Recovery compares and replaces its single-use verifier in the same locked transaction, increments generation and revokes all prior sessions. Guest registration prepares a short coordinator reservation, commits the account/session transaction and then rebinds the same participant slot. Known precommit failures release the reservation; uncertain database errors safely end the guest and tell the user to sign in. A stale match never gets resurrected. Phase 3 adds no real matching, friendships, websocket, media or payments.

Authoritative interface names and argument types are the Go source; this document supplies serialization and security intent.

## Canonical HTTP surface

All paths below are prefixed `/api/v1`. Query strings are rejected. Every mutation requires the configured `Origin`, `X-CSRF-Token` and an `application/json` object body, including `{}` for operations with no input fields. Unknown fields, duplicate keys, explicit `null`, malformed UTF-8, trailing JSON and bodies over 8 KiB are rejected. Arrays are accepted only for the bounded `interests` field. Unavailable future-phase routes remain 404.

| Method and path | Input | Success response |
| --- | --- | --- |
| `GET /auth/bootstrap` | None | 200: `{csrf_token,policies,vocabularies}`; an authenticated browser receives its current session token, otherwise a signed anonymous CSRF cookie is issued |
| `POST /guest/session` | Guest input | 201: session response; generated guest pseudonym and rotated cookie |
| `DELETE /guest/session` | `{}` | 200: `{status:"signed_out"}`; guest only |
| `POST /auth/register` | Registration input | 201: session response plus one-time `recovery_code` and `handoff_state` |
| `POST /auth/login` | `{username,password}` | 200: session response and fresh cookie |
| `POST /auth/recover` | `{username,recovery_code,new_password}` | 200: session response, replacement `recovery_code` and fresh cookie |
| `GET /me` | None | 200: session response, or 401 when absent/expired/revoked |
| `PATCH /me/profile` | `{version,display_name?,gender?,bio?,topic?}` | 200: `OwnerDTO` with the new `profile.version` |
| `PATCH /me/professional-profile` | `{version,profession?,industry?,experience?,interests?}` | 200: `OwnerDTO`; private professional attributes only |
| `POST /auth/reauthenticate` | `{password}` | 200: `{reauthentication_until}` |
| `POST /auth/change-password` | `{new_password}` | 200: session response with fresh cookie; all old sessions revoked |
| `POST /auth/recovery-code` | `{}` | 200: session response and replacement `recovery_code`; all old sessions revoked |
| `POST /auth/logout` | `{}` | 200: `{status:"signed_out"}`; guest or account current session |
| `POST /auth/logout-all` | `{}` | 200: `{status:"signed_out"}`; account only |
| `DELETE /me` | `{confirm:true}` | 202: `{receipt,access_disabled,tombstone_durable,state,requested_at}`; cookie cleared |
| `POST /account/deletion/status` | `{receipt}` | 200: deletion status without returning its bearer receipt again |

The session response is flattened: `{identity,csrf_token,recovery_code?,handoff_state?}`. Only registration, successful recovery and explicit recovery-code rotation disclose a recovery code. Cookie bearer tokens never enter JSON. Profile PATCH first checks the submitted version against the authenticated snapshot, then applies the separate transactional database/coordinator version check; this prevents both ordinary lost updates and a forged newer version from merging stale omitted fields. Guest pseudonyms cannot be edited.

Bootstrap vocabularies contain `professions`, `industries`, `experience`, `interests` and `topics`, each an array of `{value,label}`. `general_talk` is the default topic on guest creation/registration; an explicitly empty topic in PATCH is invalid. Interests allow zero to ten distinct supported values; `[]` clears them. For deletion-status checks after cookie revocation, obtain another anonymous bootstrap first. Keep the scoped receipt in memory or save it explicitly outside this application; never put it in a URL or browser storage.

## Transport safety and temporary limits

Anonymous CSRF cookies are signed with a process-generated 256-bit key, expire after 30 minutes and use a separate derived header token. A restart invalidates them. They do not authorize authenticated writes. Authenticated CSRF is bound to the rotated session credential. Duplicate authentication/CSRF cookie names are rejected. Neither tokens nor credential bodies enter access logs; identity routes use a finite route-label allowlist.

Cookie defaults are `Secure; HttpOnly; SameSite=Lax; Path=/`, no Domain, using the `__Host-` prefix. Only an explicit development/test option with an HTTP localhost/loopback origin permits `notitle_dev_session` and `notitle_dev_csrf`; there is no insecure deployed fallback. The handler's startup readiness callback blocks identity operations with 503 until schema and tombstone-replay checks complete.

Before hashing, a process-wide token bucket permits a burst of 12 attempts and refills at 30 attempts/minute. A normalized private-username bucket permits five attempts, refilling one/minute; source-address buckets permit 20 and refill 60/minute. The domain separately caps concurrent Argon2 work. These temporary conservative budgets need adjustment from measured signup/login traffic; they do not set the number of concurrent users. General identity requests permit a burst of 200 and refill 600/minute, while guest entry permits a burst of 200 and refill 300/minute. Limits use at most 4,096 keyed ephemeral buckets, expire idle entries after ten minutes, and fail closed when full.

The source address is `RemoteAddr` only. Forwarded headers are deliberately not trusted: behind Caddy these source limits may represent the proxy, with username and global budgets supplying the principal brute-force controls. An audited trusted-proxy/edge configuration can refine network throttling later. Shared addresses never receive a permanent ban.

All errors use the existing safe `{error:{code,message,request_id}}` envelope. Public codes include `invalid_input`, `authentication_required`, `invalid_credentials`, `request_not_allowed`, `identity_unavailable`, `stale_identity`, `reauthentication_required`, `temporarily_unavailable`, `rate_limited`, `json_required` and `registration_requires_login`. Unknown backend errors never expose their error string. A 429 includes `Retry-After: 60`.
