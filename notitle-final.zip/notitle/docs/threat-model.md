# NoTitle threat model — cumulative through Phase 8

This is the security inventory for blueprint V3.2. Initial sections preserve the foundation history; the phase extensions record later source controls. Runtime verification and deployment gates are separate from implementation claims. Payments require sandbox and live financial acceptance; audio source controls require relay/device acceptance, and administration remains private.

## Boundaries and assets

| Boundary | Assets and trust rule |
| --- | --- |
| Browser to Caddy | Public pages and the application shell are untrusted clients. TLS and browser headers do not confer business authority. |
| Caddy to Go | Same-origin API path, bounded requests and generated request IDs. Proxy headers are not identity or authorization. |
| Go to PostgreSQL | Runtime credentials have no schema ownership. Readiness checks the required schema marker. Database errors stay out of client responses and logs. |
| Coordinator | One goroutine owns its bounded in-memory state. No database or provider work runs in this loop. Process restart discards this state. |
| Build and delivery | Dependency manifests, real lockfiles, source changes and image references require review. The release template cannot regenerate missing locks. |
| Operators and backups | Development secrets are disposable and isolated. Production secret provisioning, backup credentials, host hardening and recovery must pass later release gates. |

## Initial abuse cases and controls

| Threat | Phase 1 control and verification |
| --- | --- |
| Credentials in invalid configuration or connection errors | Generic configuration/database errors; tests inject synthetic secrets and verify they are absent. Raw URLs, panic payloads and request bodies must not be logged. |
| Path, query or header content copied into access logs | Log route templates or a fixed unmatched label, method, status, duration and generated request ID. Never treat a client request ID as trusted log text. |
| Slow or oversized HTTP traffic | Header/body limits, request timeouts and finite database pools; reject invalid limit configuration. Later WebSocket limits must be enforced after upgrade too. |
| Reaching an uninitialized or disconnected database | Separate live and ready endpoints; connectivity and schema failures return not-ready without internal details. |
| Accidental schema modification by runtime process | Bootstrap/migration and runtime credentials are separate. Exercise denied DDL and schema access in the database gate. |
| Duplicate live-state owners or unbounded queues | One application replica, one coordinator loop, bounded queues/state and explicit shutdown. No horizontal scaling without a coordination redesign. |
| Production secrets in frontend/static output | All secret values remain server/deploy inputs; only explicitly public site configuration may enter the static bundle. |
| DOM injection or misleading prototype functionality | Svelte text escaping, restrictive CSP, no third-party analytics and no simulated real users, messages or payment success. |
| Supply-chain change | Exact direct dependency pins; generated npm integrity and Go checksums; CI lock validation and vulnerability scans. Missing lockfiles block acceptance. |
| Exposing PostgreSQL or management interfaces | Release Compose publishes only the web entry point; database and API use private networks. No Docker socket, privileged app container or public Caddy admin endpoint. |

## Controls intentionally scheduled for later phases

Phase 3 supplies session verifiers, recovery codes, password hashing, account and object authorization.
Phase 4 supplies authenticated WebSocket envelopes, Origin checks, epochs and actual matchmaking.
Before any state-changing authenticated endpoint, implement CSRF/Origin protections and rate limits.
Phases 5–7 supply Report/Block, moderation and relay enforcement. Phase 8 supplies merchant-approved money handling. Phases 9–10 close legal, retention, recovery, deployment and operating coverage gates.

Do not expose this foundation as the complete public application. Keep the 200-connected/25-call target as a later measured load gate, not a performance claim about this skeleton.


## Phase 3 controls and remaining gates

- Credential stuffing is limited before hashing using bounded keyed RAM buckets; Argon2id admits at most two jobs. Shared proxy/NAT source buckets are deliberately coarse and no untrusted forwarded IP is accepted. Username and global budgets remain effective behind Caddy.
- Session fixation is addressed with newly generated bearer secrets at authentication boundaries. Hash verifiers only are stored. Exact Origin plus anonymous/authenticated CSRF tokens protect mutations, including login and recovery. Secure cookie names are reserved for HTTPS; local HTTP uses separate loopback-only names.
- Recovery, credential changes and deletion recheck account/session generation under a common account-row lock. Stale request snapshots cannot revive access or overwrite a newer profile. Independent coordinator handoff tests cover deterministic rollback, ambiguous commits and cancellation.
- Peer privacy uses an explicit four-field DTO. Professional interests are deeply copied at the coordinator mailbox boundary to preserve actor ownership. Raw IDs, private usernames, credentials and premium/payment attributes are not peer fields.
- Deletion acknowledges access revocation separately from independent-journal durability. Atomic fsync writes and restart replay prevent ordinary database restoration from reviving tombstoned accounts when the retained journal is supplied. A lost/replaced empty journal cannot prove continuity; protected off-host copies and an operator restore gate remain mandatory before launch.

The new Go, PostgreSQL and browser tests are source until actually executed. Run the complete acceptance suite, security scans, target-host Argon2 benchmarks, mobile device checks and restore/disk-failure drills before deployment. No test-list or configuration should be treated as proof of security or production readiness.

## Phase 5 abuse cases and controls

| Threat | Implemented source control | Required verification or remaining boundary |
| --- | --- | --- |
| Text active content, malformed Unicode or misleading directional controls | Strict scalar/character/frame validation; escaped text-only rendering; no automatic links or embeds | XSS/Unicode/byte boundary cases in real frontend and private triage; never infer safety from a visual mock |
| Cross-conversation replay, spoofed speaker or duplicate send | Server attribution/sequence, current generation+epoch and bounded stable send-ID ledger | Retry, reconnect, stale-frame and dedupe-ceiling tests; restart gives no exactly-once promise |
| Floods, slow readers and unbounded retained content | Per-sender rate, 8-KiB frames, 30-message/64-KiB interaction buffer, bounded outboxes/drafts/handles | Combined 200-participant churn and safety workload; measure complete process/host memory |
| Fabricated transcript or report-versus-Next race | Coordinator freezes eligible data before purge; Submit selects only authorized server sequences | Race/failure tests including peer departure, draft expiry, logout, deletion and registration |
| Block bypass or stale authorization after storage work | Immediate local enforcement, reciprocal hard exclusion, trusted guards/fences, leased promotion/unblock and fail-closed publication | Guest-to-account transitions, simultaneous upgrades/unblock, delayed completion and crash/restart tests |
| False report success or duplicate cases after retry | Report/evidence/applicable durable block share a transaction; submission digest and unique storage key | Known rollback and uncertain commit paths; client must show unconfirmed failures and grievance fallback |
| Database/backup theft reveals submitted evidence | AES-256-GCM evidence with authenticated metadata; separate keyring and case-scoped mappings | Tamper/key-rotation/restore exercises; protect key backups; runtime itself can decrypt authorized evidence |
| Staff privilege escalation or public admin exposure | Independent private listener, operator identities, MFA, scoped roles, Origin/CSRF and short sessions | External network isolation, replay/concurrent login tests and action-transaction role/session guards |
| Unattributed staff browsing or mutable moderation history | Purpose-required evidence view, audit-before-render, append-only action/audit grants | Audit outage must prevent evidence delivery; notes/reasons remain restricted personal data |
| Report brigading, mistaken restriction or inferred proof | No report-count automatic ban; operator decisions with reasons; statements distinct from server text | Trained review and real appeal/grievance coverage required; metadata or unrecorded audio may not prove an allegation |
| Content survives process memory through diagnostics | Content-free logs, no transcript browser storage, core-dump prohibition and no unencrypted swap | Inspect host/container settings, logs, crash/tracing configuration and source/archive contents |
| Retention timestamps mistaken for deletion enforcement | Explicit case retention input, per-record deadlines and hold foundations; runtime cannot erase evidence history arbitrarily | Phase 9 reviewed purge/hold jobs, policy/effective-date review and backup retention remain incomplete launch gates |

The single-owner architecture deliberately avoids cross-replica races at MVP cost. It still requires transaction/owner fencing and tested crash boundaries; one process is not a substitute for durability. The private triage UI does not establish monitored coverage, appoint a backup operator or implement the complete legal deadline/appeal/export workflow. Keep deployed text/safety disabled until the applicable source, runtime and operating gates are accepted.


## Phase 6 abuse cases and controls

| Threat | Source control | Required verification or boundary |
| --- | --- | --- |
| Unilateral relationship or fabricated peer | Requests are current-participant scoped; owner records two affirmative consents; normalized pair is unique | Every guest/account tier combination, reciprocal requests and duplicate acceptance; no arbitrary account/username lookup |
| Refusal exposed as a personal rejection | Decline clears the pending prompt without a rejection event/history | Inspect both peers' UI/event streams; no explicit rejection announcement or stored reason |
| Enumerating friends or presence by guessed handle | Opaque relationship references plus authenticated endpoint authorization and accepted/unblocked filtering | Cross-account reference substitution, removed handles, disabled sessions and unaccepted requests reveal no presence |
| Guest link outlives the guest or gets imported into another person | Typed endpoints, reverse-index cleanup, TTL and explicit registration-only handoff | Cookie loss, logout, guest expiry, restart and unrelated-account login; no dead guest entries or fingerprint-based recovery |
| Remove/Block/Delete loses a race with insertion or promotion | Ordered transaction locks and captured durable account friendship revisions; immediate owner invalidation and guarded compensation | Interleave consent, both registrations, persistence, removal and crash at each boundary; old work cannot recreate consent. An account-wide fence conflict may conservatively invalidate unrelated unpublished consent; require fresh consent rather than refreshing the revision. |
| Registration promotion assumes a revision or waits on obsolete cookies | Newly registered endpoints capture an authoritative revision only through fresh authenticated authorization after safety handoff; existing-account consent revisions stay frozen | Closing before capture leaves pending work until later authorization. After capture, test promotion with an offline/logged-out account and credential rotation: active account, revision and safety checks remain authoritative without treating an old cookie as continuing consent. |
| A second active interaction or surprise interruption | Invitation acceptance uses the same owner and allocator as random matching; both endpoints must be available | Simultaneous random match, two invite accepts, reconnect, takeover and busy recipient; at most one interaction per participant |
| Invitation spam or offline inbox creation | Fixed global/per-identity bounds, current relationship scope and 30-second expiry in RAM | Flood/rate/expiry tests, unavailable recipients and restart; no persisted pending invitations or notification queue |
| Feature flag bypasses safety or pretends media is ready | Friends require safety; durable blocks/restrictions stay authoritative; audio intent remains unavailable | Disabled-feature combinations, stale clients and crafted audio invites cannot open text without safety or start media |
| Additional state exhausts the single owner | Configured per-identity relationship admission and fixed collection bounds; database work outside owner | Measure full 200-participant workload with list refresh, presence churn, invites, safety and registration promotion; counts alone are not capacity proof |

A friend relationship is consent to receive an online invitation, not advance consent to join an interaction or start audio. Every recontact still requires acceptance. A server restart intentionally loses guests, temporary links and pending invitations; durable registered friendships remain, with fresh safety checks before use.

## Phase 7 abuse cases and controls

| Threat | Source/design control | Required verification or boundary |
| --- | --- | --- |
| Microphone starts without the person's consent | Explicit local Call/Accept action gates capture; incoming signaling alone never captures audio | Real browser permission, denial, late permission resolution, refresh/reconnect, background/resume and invitation races; stale permission completion must stop newly granted tracks |
| Call glare, repeated ringing or stale signal changes a successor | One owner, accepted call/interaction epoch, assigned offerer, one pending request, 30-second ring and 15-second decline cooldown | Simultaneous requests, duplicate accept/decline, wrong offerer, old SDP/ICE, Next and late callbacks; exactly one accepted call |
| Peer IP exposure hidden inside SDP or a separate ICE message | Browser relay-only policy plus full server SDP/candidate validation and approved public relay addresses | Inspect delivered SDP including every media section, embedded candidate, connection address and related address; malformed/unknown attributes cannot provide a direct-routing escape |
| Video/data channel or codec expansion bypasses audio policy | Audio-only SDP and Opus policy, bounded explicitly typed signaling | Test video/application sections, unsupported RTP payloads, malformed/duplicate attributes, oversized frames and candidate floods before browser application |
| Stolen temporary credential creates allocations after End | Call-specific endpoint usernames, expiry, revoked-credential tracking and repeated cancellation | Replay credentials immediately and repeatedly after End/Next/Block/Delete; newly created allocations must be removed within the measured target through credential expiry |
| Old allocation continues despite credential refresh or revocation | Allocation-aware cancellation and a separate maximum 30-second application lease | Test old/new credentials and allocation overlaps during long calls and ICE restarts; refusing a refresh alone must not be treated as shutdown |
| Application or supervisor crash leaves peers talking | Renewable private leases; startup reconciliation; local relay watchdog | Kill/hang each component, interrupt private control and restart out of order; measure last permitted media and prove no lease resurrection |
| Transit delay, clock skew or asynchronous cancellation extends the orphan deadline | Earlier of a 24-second local cap and the transmitted app deadline minus eight seconds; monotonic local timing, six-second cleanup reserve and two-second skew allowance | Maintain synchronized host clocks, test skew in both directions and delayed inventory/cancellation, and confirm actual removal; a still-present allocation two seconds after cancellation must stop coturn. The skew allowance is not arbitrary clock-error detection. |
| TURN used as a network scanner or unbounded bandwidth proxy | Private/loopback/link-local/metadata/multicast destination denial, authenticated allocations and bounded ports/quotas | IPv4/IPv6 destination tests, forged/expired credentials, quota exhaustion and sustained abuse on the actual pinned image/firewall |
| Control-plane compromise grants arbitrary relay or host access | Authenticated protected control path with narrow call lease actions; private CLI/metrics and no general shell/host API | Verify external reachability, wrong credentials/certificates, redirect behavior, malformed CLI output, bounded polling and cancellation failure |
| Mobile interruption silently restores audio or leaves a live track | Call teardown on disconnect and guarded async browser media lifecycle; text reconnect remains separate | iOS/Android network switching, screen lock/backgrounding, tab takeover, device removal, permission prompt after End and autoplay failure |
| Media or network metadata becomes an unintended archive | No recording/transcription; signaling and call control in bounded RAM; aggregate metrics and redacted operational events | Inspect browser storage, SQL, logs, crash/core settings, coturn configuration and packet captures used for testing; do not retain test captures containing real-user data |
| Voice allegations presented as verified audio evidence | Existing reporting distinguishes user statements and permitted server metadata/selected text | Operator UI must say unrecorded audio cannot be replayed; metadata alone does not prove the allegation |
| Declared call cap mistaken for measured capacity | Separate 25-call admission, allocation quotas and 1,024-port budget | Run 200 connected participants including 25 calls, text, reconnect/ICE churn and safety actions; record actual allocation and network measurements |

TURN is a media relay, not an anonymity guarantee: application/relay operators still handle network connections, and a participant may recognize or record the other person's voice. DTLS-SRTP does not authenticate a person's claimed profession, gender or real-world identity. Keep these limits in product and policy copy. The remaining payment, retention, legal review, recovery and staffed-operation gates are unchanged.

## Phase 8 financial abuse and failure cases

| Threat | Source boundary | Required verification |
| --- | --- | --- |
| Browser forges price, callback success or Premium role | Immutable server catalog/order and verified provider capture transaction | Modified amount/currency/plan/version, callback flags and direct forged grant attempts never activate access |
| Duplicate/out-of-order provider delivery or competing workers grants twice | Durable inbox plus environment/payment uniqueness and one purchase lot | Replay signed raw bytes; race verify/webhook/reconciler; multiple failed/successful attempts and two genuine successes |
| Timeout creates second order or refund | Commit stable intent/key before external I/O; reconcile unknown result | Kill workers at each request/commit boundary and retry the same reference |
| Raw webhook accepted with attacker signature or parser ambiguity | Exact-byte HMAC, strict bounded headers/JSON and durable-ack ordering | Alter bytes, duplicate keys/headers, malformed timestamps, wrong/rotated key and durable inbox outage |
| Refund holds erase unrelated purchases or time is lost during pending state | Lot-specific holds, exact duration events and explicit compensation | Stacked lots, consumed original lot, simultaneous refund/purchase, unknown/failure/success and duplicate resolutions |
| Refund sum exceeds captured funds | Transactional original-capture and cumulative-reservation validation | Concurrent requests, external dashboard refunds, stale previews, negative money and reused provider refund IDs |
| Expired/refunded paid preference influences a fresh match | Current-time checks, durable-before-use accounting and invalidation fences | Every tier pairing, queued expiry, current-lot transition, publication loss, restart and Everyone consent |
| Stale/deleted identity is resurrected by a late financial event | Restricted retained references and active-account checks | Delete before intent/capture/refund, late success, tombstone replay and restored old entitlement |
| Staff financial or evidence privilege escalation | Separate private MFA roles and audited guarded transactions | Moderator financial denial, billing evidence denial, stolen/expired session, role change and audit outage |
| Provider contact/card/bank payload becomes a new personal-data archive | Hosted checkout and minimal allowlisted provider projections | Inspect logs, database, browser storage, backups and errors; verify transient phone handling and no raw inbox payload |
| Settlement/refund exceptions remain invisible | Five-minute unresolved work, daily reconciliation and restricted review queue | Late/paginated records, dashboard refunds, dispute deadlines, fee/net mismatch and monitored operator response |
| Payment I/O stalls every conversation | Bounded worker/client/pool limits and no I/O inside live owner | Provider outage during 200 connected/25 calls, hashing, backups, moderation and refund invalidation |

The provider is an external financial authority, not an account-identity authority. API authentication establishes the configured merchant context; exact association and amount still require validation. Operational reconciliation, legal/commercial review and controlled live settlement remain necessary even when local cryptographic and transaction tests pass.

## Phase 9 privacy and operations threats

| Threat | Implemented boundary / required operator control | Acceptance evidence |
| --- | --- | --- |
| Account closure destroys complaint access | Independent case capability and explicit protected case route | Delete/expire guest/account, retrieve with saved secret, reject wrong secret without enumeration |
| Support token proves someone else's identity or purchase | Case ownership is separate from self-authenticated privacy/payment ownership | Complaint alleging a username/order never grants account export, receipt or refund |
| Urgent case becomes ordinary on retry/reassignment | Original receipt and tightened deadlines, versioned category history and escalation | Reclassification, appeal and failed notification preserve clocks; monitored backup responds |
| Staff escalate roles or keep stolen old session | Offline owner-MFA lifecycle, expected generation and session revocation; fresh transactional guards | Role removal/disable/MFA reset racing evidence, export, refund and case action |
| Export URL/key leaks evidence | No public bearer URL; actor/session-bound one-use permit; AES-GCM file and separate key | Replay, expired/revoked session, tamper, audit failure and offline-copy lifecycle |
| Purge bypasses legal hold or fakes approval/age | Immutable reviewed DB policy, independent hold journal, common lock and DB-clock validation | Runtime cannot publish policy; future caller clock, purge/hold races and stale manifest rejected |
| Restored database revives deleted/refunded identity | Retained deletion/hold journal replay and financial reconciliation before access | Old restore with newer cancellation, hold/release, refund and missing/corrupt journal |
| Monitoring leaks identities or hides a missing measurement | Fixed-label private aggregates and fresh protected observation schema | No account/case/phone/gender/SDP labels; zero vs unavailable; cardinality/resource bounds |
| Alert receiver becomes SSRF or data exfiltration path | Reviewed HTTPS endpoint, public-address validation, no redirect, token file and minimal envelope | DNS rebinding, private/link-local/reserved targets, timeout and unapproved URL denied |
| Entire VM outage disables its own alarm | Independent public probe and monitored primary/backup fallback | Shut down app host, prove external notification and backup recovery |
| Log/backup retention becomes indefinite or silently deletes recovery chain | Purpose-specific bounded lifecycle, independent journals, database-aware WAL expiry | India-region integrity/lifecycle checks, legal hold, repository restore and off-host exact-record proof |

Remaining production evidence includes actual staff appointments, legal/tax approvals, least-privilege cloud policy, encryption/key recovery, device/browser acceptance, external delivery drills and both six-hour 200-connected/25-call workloads. No source test proves those external facts.
