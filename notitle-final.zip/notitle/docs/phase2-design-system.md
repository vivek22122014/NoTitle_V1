# Phase 2 design system and review guide

The shared implementation starts with a single-column phone layout and adds columns when content needs them. Navy/charcoal/slate text, one teal accent, system fonts, bounded reading widths, flexible grids and safe-area padding avoid a fixed desktop canvas. Native mobile navigation and FAQ disclosure work without JavaScript. Focus, reduced motion and 44 CSS px touch targets are explicit.

## Surface map

| Surface | Implementation and purpose |
| --- | --- |
| Public home | Workplace topics, product purpose, Start a Conversation, preview status, Premium and safety information |
| How It Works | Guest/account participation, self-declared labels, mutual choices, temporary conversations and friendships |
| Premium | Optional hard gender preference and very soft professional preferences; no renewal or guaranteed match; no unavailable price advertising |
| Safety | Report/Block, consent, qualified identity claims and respectful conduct |
| Seven policy/contact pages | Versioned draft content, responsible roles and actual approved values only after release validation |
| Application shells | Known routes display truthful unavailable states; no fake registration, purchases, history or support cases |
| Development preview | Inspectable entry, search, conversation, safety, call, friend and preference states; labelled simulation |

## Interaction preview

Start Vite through the normal bootstrap and open `/design-preview`. Use its controls to inspect scenarios. All state is local memory; there is no network business request, microphone permission prompt, real counterpart, recording or browser persistence.

- Entry requires explicit adult/rules acknowledgement and one gender selection with no preselection. Topic includes General Talk.
- Search designs cover loading, capacity/busy, expiry and failure. They show no invented number of online participants.
- Conversation demonstrates a text composer and reachable call/Next/More/Report controls. Explicit Next/End clears the local draft/transcript; resizing does not.
- Native dialogs cover report/block and confirmation with focus return. A separate focus scope supports the full conversation preview.
- Audio illustrates invitation, acceptance, permission-denied, mute and end states without calling browser media APIs.
- Friends illustrate Available/Busy/Offline and temporary guest connections without last-seen claims.
- Preferences put gender first. Professional choices stay collapsed with No preference defaults; category reset and global scoring opt-out retain the finalized semantics.
- Account/settings/payment state inventory records future screen requirements without implementing backend authority.

## Mobile keyboard and accessibility

`visibleViewport` uses VisualViewport height/offset with window resize/orientation fallback. It updates visible-height variables and keeps focused controls in view. The conversation layout supports scrollable content with reachable controls. This is an implementation strategy, not proof of behavior with a physical keyboard.

Browser tests cover the ten blueprint widths, portrait/landscape reflow, text scaling, navigation, focus, simulated keyboard-height changes and dialog transitions. Complete manual checks on Android Chrome, iOS Safari, desktop Chrome/Edge/Firefox/Safari as applicable, and representative screen readers. Record failures and actual devices; do not equate Chromium emulation with all-browser support.

## Performance and maintenance

Public pages are static HTML; no WebRTC or checkout SDK is loaded. Fonts and images are local; the share image has explicit dimensions and is metadata-only. No paid UI, font, analytics or hosting dependency is introduced.

Keep design tokens and shared components authoritative. Future functional screens can reuse the visual components, but must implement server validation, safety authorization and lifecycle rules independently of the development simulation. The design preview must remain excluded from production routing/indexing.
