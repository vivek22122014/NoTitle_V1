# Phase 10 release evidence record — fill with actual results

Copy this template into the protected release evidence workspace for each candidate. This unfilled template grants no approval. Use `not_run`, `blocked`, `failed` or `passed`; reserve `not_applicable` for a specifically justified reviewed requirement, never the mandatory 200/25, mobile/desktop, safety, privacy or money gates of full V1.

These are human record labels. The machine evidence schema uses `pending`, `failed` or `passed` for each gate; keep not-run/blocked work `pending` there and explain the blocker in its referenced record. Do not add an unsupported status to force a validator to accept missing work.

## Candidate and responsibility

| Field | Actual value / protected evidence reference |
| --- | --- |
| Candidate identifier and creation UTC | Unrecorded |
| Source commit or cumulative source archive SHA-256 | Unrecorded |
| Authentic lock and dependency inventory identities | Unrecorded |
| API, web, migration, PostgreSQL and relay image digests | Unrecorded |
| Effective redacted configuration digest and schema compatibility range | Unrecorded |
| Isolated acceptance origin/manifest/images and reviewed static-web-only differences | Unrecorded |
| Public origin, artifact release mode and reviewed legal-content digest | Unrecorded |
| Policy/deadline/notice versions and approval references | Unrecorded |
| App / relay hardware, region, OS, kernel and container runtime | Unrecorded |
| Primary and backup engineering / safety / grievance / privacy / billing / recovery assignments | Unassigned |
| Test start/end UTC, operator and independent reviewer | Unrecorded |
| Target scope: full V1 / explicitly limited controlled stage | Unrecorded |

Never include passwords, MFA seeds/codes, keys, cloud tokens, session/recovery/support codes, gateway contact data or personal case content. Store necessary identity/contact details only in the approved private roster; reference its revision here.

## Executed verification

| Gate | Status | Exact command / procedure and environment | Evidence digest/reference | Actual result / remaining defect |
| --- | --- | --- | --- | --- |
| Source checks | not_run | Unrecorded | Unrecorded | No result |
| Go formatting/vet/build/race/fuzz | not_run | Unrecorded | Unrecorded | No result |
| Real PostgreSQL integration, least privilege, disposable up/down/up | not_run | Unrecorded | Unrecorded | No result |
| Svelte checks/lint/build + static boundary | not_run | Unrecorded | Unrecorded | No result |
| Browser journey, accessibility and SEO | not_run | Unrecorded | Unrecorded | No result |
| Security behaviors and dependency/container scans | not_run | Unrecorded | Unrecorded | No result |
| Matching/text/friend lifecycle and races | not_run | Unrecorded | Unrecorded | No result |
| Voice enforcement, replay, failure and timing | not_run | Unrecorded | Unrecorded | No result |
| Sandbox capture/refund/dispute/reconciliation | not_run | Unrecorded | Unrecorded | No result |
| Cases, MFA/audits, privacy/hold/retention boundaries | not_run | Unrecorded | Unrecorded | No result |
| Six-hour workload A with real media | not_run | Unrecorded | Unrecorded | No result |
| Six-hour workload B with real media | not_run | Unrecorded | Unrecorded | No result |
| 400-offered overload and 200/100/25 admission | not_run | Unrecorded | Unrecorded | No result |
| Dense 200×100 offline-friend workload | not_run | Unrecorded | Unrecorded | No result |
| Physical mobile and desktop matrix | not_run | Unrecorded | Unrecorded | No result |
| Independent off-host restore and old-DB journal replay | not_run | Unrecorded | Unrecorded | No result |
| Maintenance and schema-compatible rollback | not_run | Unrecorded | Unrecorded | No result |
| Backup operator / lost-host / urgent alert drills | not_run | Unrecorded | Unrecorded | No result |

For automated runs record start/end UTC, tool versions, full command, exit code, duration, fixture identity, skipped-test count and sanitized output. Explain every skip. For manual checks record procedure, expected/observed behavior, device/network and witness. Evidence files need immutable SHA-256 identities and storage/access/retention owners; a path alone is insufficient.

## Load measurements

Use separate rows for A and B; retain time series rather than averaging away drops below the target. The measurement interval begins only after 200 connected and 25 established bidirectional calls are reached. Include 100 waiting for A. A client-media harness report must state whether generated or microphone media was used and whether real TURN path/network evidence exists.

| Measurement | A actual | B actual | Acceptance threshold |
| --- | --- | --- | --- |
| Qualifying plateau seconds | Unmeasured | Unmeasured | ≥21,600 each |
| Connected / waiting / established calls | Unmeasured | Unmeasured | A 200/100/25; B 200/0/25 |
| API server p95 ms | Unmeasured | Unmeasured | <300 |
| Message server p95 ms | Unmeasured | Unmeasured | <100 |
| Available-candidate match p95 ms | Unmeasured | Unmeasured | <1,000 |
| Supported-network call success; attempts/failures | Unmeasured | Unmeasured | ≥95% |
| Call setup p95 ms | Unmeasured | Unmeasured | <10,000 |
| Minimum whole-host available memory; post-GC trend | Unmeasured | Unmeasured | ≥25% headroom; stable trend |
| API/DB/host/relay CPU, RSS, owner lag, pool wait | Unmeasured | Unmeasured | Reviewed bounded limits |
| Durable job queue depth/oldest age at start/end/peak | Unmeasured | Unmeasured | No accumulating backlog |
| Relay allocations/ports, egress, packet loss | Unmeasured | Unmeasured | Reviewed bounded limits |
| Revoke/orphan maximum elapsed seconds | Unmeasured | Unmeasured | ≤5 / ≤30 |
| Offered/completed text and ACK rate, rejected/lost safety events | Unmeasured | Unmeasured | Reviewed rate; no safety loss |

Attach separate overload and dense-friendship results. Record every interruption, fixture failure, error-budget disposition and whether the complete scenario was rerun. Never combine several shorter runs into a claimed uninterrupted six-hour run.

## Physical browser record

| Device/model | OS/browser version | Network pair | Dimensions/accessibility | Journey references | Status and defects |
| --- | --- | --- | --- | --- | --- |
| Android phone | Unrecorded | Unrecorded | Unrecorded | Unrecorded | not_run |
| iPhone | Unrecorded | Unrecorded | Unrecorded | Unrecorded | not_run |
| Desktop Chrome | Unrecorded | Unrecorded | Unrecorded | Unrecorded | not_run |
| Desktop Edge | Unrecorded | Unrecorded | Unrecorded | Unrecorded | not_run |
| Desktop Firefox | Unrecorded | Unrecorded | Unrecorded | Unrecorded | not_run |
| Desktop Safari on supported Apple OS | Unrecorded | Unrecorded | Unrecorded | Unrecorded | not_run |

Include denial/incoming audio, software keyboard, app switch/screen lock, rotation, Wi-Fi/cellular transition and checkout return. Emulators and browser engines are labelled separately from physical devices.

## Recovery, incident and rollback drill

Record incident/discovery UTC; external detection/delivery/human-ack timestamps; primary/backup ownership; restored full/WAL identifiers and actual last recoverable point; newer deletion/hold journal inventory/integrity; independent key access; restored-session invalidation; safety/ledger/provider reconciliation; missing/corrupt-journal fail-closed check; readiness and reopening UTC. Calculate actual RPO and staffed RTO. Target ≤15min and ≤4h; record ≤24h contingency separately, not as a four-hour pass.

For code rollback record from/to image digests, shared schema compatibility, drain/termination and relay cancellation times, preservation of both independent journals, continued webhook/case handling where available, rollback duration and final smoke results. State explicitly that no stale database restore was used to undo the deployment. Backup operator must execute at least one drill independently using available recovery keys and approved access.

## External approvals and controlled live validation

| Decision | Actual approver/date | Immutable private reference | Status |
| --- | --- | --- | --- |
| Actual operator/domain/brand/contact | Unassigned | Unrecorded | blocked |
| Counsel classification/duties/dates/age/retention/notices/appeals | Unassigned | Unrecorded | blocked |
| Grievance officer and monitored primary/backup coverage | Unassigned | Unrecorded | blocked |
| Provider acceptance of complete actual business model | Unassigned | Unrecorded | blocked |
| Accountant tax/invoice/fee/refund/record-retention assessment | Unassigned | Unrecorded | blocked |
| Refund offers, annual economics/later-refund route and reserve | Unassigned | Unrecorded | blocked |
| Explicit limited live capture/refund/settlement authorization | Unassigned | Unrecorded | blocked |

Only after the final authorization: record agreed maximum amount, authorised operator, provider environment, opaque purchase/refund references and exact paise reconciliation. Verify capture, webhook inbox, single grant, receipt, originating-lot refund, provider processing, actual settlement/fees and supported credit status. Do not equate sandbox success, webhook delivery or a refund HTTP response with live settlement/bank credit. Keep full provider records restricted.

For the production evidence-collection stage, record the validation-purpose permit digest, exact configuration/ingress binding, issue/expiry UTC (≤2h), all pre-live gate results, prior bounded live-money authorization and private owner-MFA opening audit. Only `production_smoke`/`live_money` may be pending. Record automatic expiry/drain and any separately reviewed renewal. Validation is not public launch or full-V1 acceptance; keep those gate statuses pending until actual smoke and settlement/credit evidence arrives. The final launch permit is produced from a new complete check, followed by its own deliberate owner action.

## Defects, cost and owner decision

Every unresolved defect has severity, impact, owner, deadline, mitigation and disposition evidence. Critical safety/security/privacy/money-integrity failures cannot be waived into full-V1 acceptance. Material source, image, policy or configuration changes invalidate affected evidence and require retest.

Record actual monthly host/storage/request/transfer/domain/tax forecast in INR, rate assumptions, measured media minutes and storage growth, configured budget alerts and cash reserve. Compare with the blueprint's ₹4,100/month / ₹49,200/year planning envelope; these historical planning figures are not a provider quote or inclusive staffing budget. Assign moderation, on-call, legal/accountant and merchant costs separately. Confirm all temporary staging/load resources are stopped after evidence collection.

Owner decision: **NO-GO until completed**. Record actual decision time, exact candidate/configuration, accepted scope, linked gate report, unresolved noncritical issues, launch operator and backup. Supervised-cohort start/stop times and full operating-cycle review remain separate evidence before broader acquisition. A tool may validate a record but cannot sign for the business owner, counsel, provider or actual operator.
