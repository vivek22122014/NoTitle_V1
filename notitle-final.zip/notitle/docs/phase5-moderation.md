# Phase 5 private moderation

This is the minimum report triage surface from blueprint V3.2. It is a private HTTP listener, separate from the public application. It reviews submitted reports and deliberately has no live-chat browser. Full grievance, appeal, billing, export, retention automation and audit-search workflows remain Phase 9 work. Source delivery does not establish production readiness or monitored coverage.

## Access and identities

Bind the listener to loopback, or to an internal container interface published only on host loopback. Remote access must pass through an authenticated VPN or access gateway. Do not add `/admin` to the public Caddy route map. Use a dedicated HTTPS operations hostname so the host-only operator cookie is separate from the public application host. Configure the exact operations origin; the handler rejects mismatched Host and POST Origin. HTTP is allowed only for the explicit localhost development setting.

An operator supplies their separate username/password and authenticator code together. Argon2id uses the same bounded hasher instance as public identity. Before hashing, a bounded global limiter and independent source/name limiters apply. The server never trusts forwarded source headers. Cookie credentials are random 256-bit values; only SHA-256 verifiers are stored. Cookies are host-only, HttpOnly, Secure and SameSite=Strict, using an independent `__Host-notitle_admin` name. Local HTTP uses an explicitly separate development cookie name. Forms require CSRF, POST writes require the exact origin, and responses use no-store, no-referrer, noindex and a restrictive CSP. No third-party script, font or analytics provider is needed.

TOTP uses RFC 6238 with 30-second steps, six digits and HMAC-SHA1. At most one adjacent step in each direction is accepted. PostgreSQL atomically advances a per-operator counter when creating the session; a consumed code cannot authenticate twice, including concurrent requests. MFA secrets use AES-256-GCM with operator-specific associated data and a separate 32-byte mounted MFA key. Passwords, session tokens, codes and decrypted MFA secrets never enter application logs. Maintain host clock synchronization. The implementation's algorithm is tested against the [RFC 6238 Appendix B vectors](https://www.rfc-editor.org/rfc/rfc6238.html#appendix-B).

Sessions expire after 15 minutes without operator activity or four hours absolute. Up to five sessions are retained per operator. Every request rechecks the operator's enabled state and generation; action transactions also recheck the current session, generation and role. Offline disabling or credential/role replacement must increment generation and revoke sessions. No public bootstrap operator or default password exists.

## Role scope

| Role | Phase 5 case list and evidence | Note, suspend, unsuspend, resolve |
| --- | --- | --- |
| Owner | Yes | Yes |
| Moderator | Yes | Yes |
| Grievance officer | Yes | Yes |
| Billing operator | No | No |
| Read-only operations | No | No |

Multiple operator accounts and scoped role combinations are supported. Appoint and train a backup operator before real-user testing; the software does not invent or assign an actual person. Billing and read-only roles have an honest landing page, without general case content. No payment details are present in the moderation UI. Legal-hold persistence is a safety foundation; this minimal UI does not expose hold administration or evidence exports.

## Provisioning

Apply migrations 4 and 5 with the dedicated migration role. Runtime database credentials cannot create operators, alter their roles/password/MFA, modify audit records or run migrations. Keep the independent MFA key outside ordinary PostgreSQL backups; protect a recoverable offline copy under the operator key-recovery procedure. Loss of the key prevents existing operators from authenticating. Do not share it with the report-evidence key.

Run the `adminctl` binary built from `server/cmd/adminctl` on the protected host. It accepts paths, never raw secrets on the command line:

```bash
adminctl \
  --input-file /private/operator-input.json \
  --database-url-file /private/migration-database-url \
  --mfa-key-file /private/admin-mfa-key \
  --enrollment-file /private/new-operator-enrollment.txt
```

The input JSON has `username`, `password` and `roles` fields. Choose a distinct operator username (4–64 lowercase letters, digits, underscore, hyphen or period), a generated 12–128-character password and the minimum role set. Create this JSON with a protected editor/password-manager workflow, not a shell command containing the password. Input files must be regular private files with no group/other permissions. The MFA key contains base64 for exactly 32 random bytes. The database URL file must identify `notitle_migrate`, and is never mounted in the runtime API container.

The enrollment output is created exclusively with mode 0600 and includes the authenticator secret and an `otpauth` URI. Import it offline into the appointed operator's authenticator, verify login, then securely remove the input and enrollment files according to the protected-host procedure. Never upload either file to source control, support chats, ordinary backups or the source archive. If a database commit response is lost, the enrollment is preserved because the operation may have committed; inspect the operator record before retrying. There is no remote password reset or MFA recovery bypass. Recovery currently requires an authorized offline migration-role operation and an audit record; a self-service operator lifecycle is later work.

For the container-only local workflow, first build the runtime image with `docker build -f server/Dockerfile -t notitle-admin-provision:local .`. Use a separate temporary operator directory outside the source tree, owned by UID65532 with mode0700, containing the private input JSON and a mode0600 copy of the migration DSN. Never add the migration DSN to the long-running API service. After local bootstrap has prepared its private keys and database network, the one-off invocation is:

```bash
docker run --rm --read-only --user 65532:65532 \
  --network notitle-local_default --cap-drop ALL \
  --security-opt no-new-privileges:true --ulimit core=0 \
  --mount type=bind,src=/protected/admin-provision,dst=/private \
  --mount type=volume,src=notitle-local_safety_keys,dst=/keys,readonly \
  --entrypoint /adminctl notitle-admin-provision:local \
  --input-file /private/operator-input.json \
  --database-url-file /private/migration-database-url \
  --mfa-key-file /keys/admin_mfa_key \
  --enrollment-file /private/new-operator-enrollment.txt
```

Replace the protected host path and, if customized, the Compose project network/volume names. The output path must not already exist. This temporary process can reach the private database bridge; no PostgreSQL host port is needed. Stop and remove the private enrollment material after verified MFA setup. For a deployed environment use its reviewed API image, private database network and protected mounted keys, never local credentials.

## Triage workflow

1. Sign in through the private gateway with password and MFA. Open the worklist of up to 100 reports, ordered by severity and due time. Due times are initial operational targets, not an assertion that the full statutory rules have been implemented.
2. Open a case and enter a work purpose. The server loads only the submitted evidence, requires a successful audit commit before rendering it, and escapes all text through Go `html/template`. There is no active HTML, Markdown, automatic link or transcript export.
3. Keep user statements distinct from server-attributed selected messages. Case speaker references do not disclose public account identifiers. A metadata-only report may have no transcript; unrecorded audio cannot be replayed. Report volume alone must never determine a ban.
4. Record a note, a bounded suspension (1–720 hours), removal of a suspension, or resolution with a meaningful reason. The submitted version must match the current case. Action history and successful action audit append in the same transaction. Correction creates a new action; it does not edit history. Resolve does not silently remove a suspension. Safety publication immediately invalidates affected live state or fails closed.
5. If the action response is ambiguous, reopen the case and inspect its latest version/history before retrying. If audit, database or safety publication fails, treat the operation as incomplete until verified. Do not promise a reporter successful submission or enforcement without confirmation.

Every sensitive view records operator, action, case reference, work reason, timestamp and result. Failed/denied privileged requests have content-free operational outcomes; raw message text never enters ordinary application logging. Operator notes/reasons are restricted personal data. The runtime role has no audit UPDATE/DELETE privilege. Evidence content is not sent when its audit cannot commit.

Registration can leave a `pending_safety_handoffs` fence if the process fails before a guest's safety state is durably rebound. Such accounts remain closed to interaction access after restart. Do not delete a fence merely because it is old or to make login appear successful: that could discard a block or restriction. This minimal triage UI does not implement orphaned-handoff recovery. Keep the fence until an authorized private review can establish a safe, audited recovery procedure; no automatic expiry or blind SQL clearing is supplied.

## Verification and release gates

Authored Go tests cover RFC vectors, accepted/rejected clock steps, replay, ciphertext tampering and operator binding, role separation, XSS escaping, audit failure, Origin/CSRF/version controls, login rate checks before hashing, and secure cookie attributes. PostgreSQL integration must prove atomic replay protection, expiry/revocation, action guards and least-privilege grants against the migrated disposable database. Compilation and these Go tests must run on the pinned toolchain; test source is not passing evidence.

Before real-user testing, verify mobile widths and keyboard access, actual gateway/TLS isolation, founder and backup MFA access, an end-to-end report review/suspension and a failed-database/audit scenario. Establish monitored report and grievance coverage, operator training, escalation ownership and the real appeal route. Public release remains disabled until those operational and later phase gates are satisfied.

This phase adds no paid authentication, moderation, messaging or admin hosting subscription. It uses the existing Go process and PostgreSQL, with encrypted keys and a private listener. Costs still include the existing host, backups and the actual operator's time; a free software component does not provide human moderation coverage.
