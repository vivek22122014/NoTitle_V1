# Final deployment, payment and launch guide

This guide applies to the cumulative Phase 10 source and **database schema 9**. It describes work an authorized operator must perform; it is not evidence that the application has been deployed or approved. The delivered source lacks authentic `server/go.sum` and `web/package-lock.json` until bootstrap generates them. Go/PostgreSQL/Svelte/Caddy/coturn runtime execution, physical-device testing, cloud recovery, payment settlement and200-connected/25-call capacity must still be proved. Read `PHASE10_STATUS.md` for executed checks.

Use the companion final setup/testing guide for local development. The essential starting commands, from the extracted `notitle` directory on Linux or WSL2, are:

```bash
./scripts/bootstrap.sh prepare
./scripts/verify.sh
```

Bootstrap needs Docker Engine, Compose 2.30+, approved registry/package access and Bash. Verification also needs Python 3.11+. Release/evidence tools need Node 24. Review authentic lockfiles, dependency changes and formatter output before freezing source. Bootstrap's `prepare` mode creates local development material only and starts no application; never copy those local credentials into staging or production. A failed or unavailable command remains a blocker.

## 1. Decide who operates each boundary

Appoint the real business owner, engineering/release owner, primary and backup operations/grievance staff, counsel and accountant. Preserve the finalized guest/account roles, one shared matching pool, friends, audio and all four Premium offers. The final target remains at least200 connected participants, including 25 simultaneous two-person calls; small cohort size is a rollout control, not a reduced capacity target.

The starting topology is unchanged:

| Place | Runs here | Initial budget |
| --- | --- | --- |
| Bangalore app VM | Caddy/static frontend, one Go API/coordinator/workers, PostgreSQL | 2 vCPU/4 GiB; container ceilings 192/768/1280 MiB respectively |
| Separate Bangalore relay VM | coturn, private supervisor and watchdog | 1 vCPU/1 GiB; relay container 768 MiB |
| S3 Mumbai | Encrypted DB/WAL, independent journals, required security archive | Reviewed retention and measured storage/transfer budget |
| Cloudflare Free | Website DNS/proxy and strict origin TLS | No TURN HTTP proxying |
| Temporary acceptance hosts/browser generator | Isolated load, recovery and browser tests | Stop unused acceptance resources after preserving evidence |

No Redis, second application owner, production Node server, outgoing user-email provider, paid dashboard or permanent staging subscription is required. Container limits are proposed budgets, not a benchmark result. Review the actual INR compute/storage/transfer/payment/staffing budget before purchasing services.

## 2. Freeze reviewed product, policy and source

Complete actual values in `web/config/release.json` and `web/config/plans.json`, following `docs/legal-review-inventory.md` and `docs/seo-release-controls.md`. Review real operator/contact/grievance details, jurisdiction/retention/privacy text, prices, tax, invoices, refund terms and annual-plan economics. Do not turn draft flags into approvals without the corresponding review.

After dependencies are installed, this displays the content digest for the legal review record:

```bash
cd web
npm run release:digest
cd ..
```

Record the digest through the documented inventory-review fields, then run verification again. Review genuine dependency locks and any formatter/source changes before freezing the release. The bootstrap directory contains `deploy/dev/.env` and other local material; `sourceDigest` intentionally rejects real environment/credential files. Export a **new** clean release source tree without deleting or changing the active development tree. The following block preserves source dotfiles (including CI/config), genuine lockfiles and executable modes, excludes the inventory's generated directories and forbidden credential filenames, and additionally omits known local secret/build/editor outputs. Evidence and other private outputs must already be outside the source tree; filename filtering does not prove that a file is safe to publish.

Run once from the reviewed development tree; it refuses an existing export and rejects symlinks or special files in retained source:

```bash
python3 - <<'PYEXPORT'
from pathlib import Path
import os
import re
import shutil
import stat

source = Path.cwd().resolve()
target = source.parent / "notitle-release-source"
excluded = {
    ".git", ".local", "node_modules", ".svelte-kit", "build", "dist",
    "coverage", "test-results", "playwright-report", "__pycache__",
    "secrets", ".vscode", ".idea", "tmp",
}
local_backend = {
    "server/bin", "server/notitle", "server/notitle-api",
    "server/adminctl", "server/coverage.out",
}
credential_names = {".npmrc", ".netrc", ".pypirc", "id_rsa", "id_ed25519", "credentials"}

def omit(name, relative):
    environment = (name == ".env" or name.startswith(".env.") or name.endswith(".env"))
    return (
        name in excluded or name in credential_names
        or re.search(r"\.(pem|key|p12|pfx)$", name, re.IGNORECASE) is not None
        or (environment and not name.endswith(".example"))
        or relative in local_backend
        or (relative.startswith("server/") and name.endswith(".test"))
        or name in {".DS_Store", "Thumbs.db"} or name.endswith(".log")
    )

def copy_directory(current, destination):
    for entry in sorted(os.scandir(current), key=lambda item: item.name):
        relative = Path(entry.path).relative_to(source).as_posix()
        if omit(entry.name, relative):
            continue
        metadata = entry.stat(follow_symlinks=False)
        if stat.S_ISLNK(metadata.st_mode):
            raise SystemExit("Source symlink rejected; discard the incomplete export")
        output = destination / entry.name
        if stat.S_ISDIR(metadata.st_mode):
            output.mkdir(mode=stat.S_IMODE(metadata.st_mode))
            copy_directory(Path(entry.path), output)
            shutil.copystat(entry.path, output, follow_symlinks=False)
        elif stat.S_ISREG(metadata.st_mode):
            shutil.copy2(entry.path, output, follow_symlinks=False)
        else:
            raise SystemExit("Special source file rejected; discard the incomplete export")

target.mkdir(mode=0o700, exist_ok=False)
copy_directory(source, target)
print("Created clean release source; review it before building")
PYEXPORT
cd ../notitle-release-source
node scripts/audit.mjs --release
mkdir -p ../release-evidence
chmod 0700 ../release-evidence
node scripts/launch-evidence.mjs init --source . \
  --out ../release-evidence/evidence.json
```

Review the exported inventory and run the real release secret scan before publication. Use this clean directory for every following `--source .`, build, host copy and evidence command. Keep outputs outside it. Do not rerun local bootstrap inside the frozen release copy; that would recreate rejected local credentials. If a source fix or new lock is needed, return to development, verify it and create a fresh export/output set.

`init` creates pending evidence; it never claims that a gate passed. Read `release.source_sha256` from that file for the reviewed build input. Changing source after this step requires a new digest/build/evidence set. Do not hand-edit an old hash to conceal a change.

## 3. Build and publish immutable candidates

Read `docs/phase10-build.md`. Prepare an external protected build JSON with exactly these fields:

```json
{
  "schema_version": "notitle-build-v1",
  "source_sha256": "ACTUAL_SOURCE_DIGEST",
  "version": "REVIEWED_RELEASE_VERSION",
  "commit": null,
  "release_mode": "production",
  "origin": "https://ACTUAL_CANONICAL_HOSTNAME",
  "checkout_enabled": true,
  "base_images": {
    "go": "ACTUAL_REVIEWED_REGISTRY_REFERENCE_WITH_SHA256",
    "node": "ACTUAL_REVIEWED_REGISTRY_REFERENCE_WITH_SHA256",
    "caddy": "ACTUAL_REVIEWED_REGISTRY_REFERENCE_WITH_SHA256",
    "migration": "ACTUAL_REVIEWED_REGISTRY_REFERENCE_WITH_SHA256",
    "turn": "ACTUAL_REVIEWED_REGISTRY_REFERENCE_WITH_SHA256",
    "postgres": "ACTUAL_REVIEWED_BACKUP_CAPABLE_POSTGRES_REFERENCE_WITH_SHA256"
  },
  "tags": {
    "api": "REGISTRY_NAMESPACE/notitle-api:RELEASE",
    "web": "REGISTRY_NAMESPACE/notitle-web:RELEASE",
    "migrate": "REGISTRY_NAMESPACE/notitle-migrate:RELEASE",
    "turn": "REGISTRY_NAMESPACE/notitle-turn:RELEASE"
  }
}
```

Every uppercase marker above must be replaced with a real reviewed value; the example is intentionally rejected unchanged. `commit:null` is correct for an archive without an actual Git commit. A commit, image digest or checksum must never be invented. The PostgreSQL reference must identify the reviewed image that actually contains the tested backup tooling if using pgBackRest; the vanilla image does not acquire that tooling from a config file.

Plan first, then build into a different new output directory:

```bash
node scripts/release-build.mjs --source . \
  --config ../release-evidence/build-production.json \
  --output ../release-evidence/build-plan-production
node scripts/release-build.mjs --source . \
  --config ../release-evidence/build-production.json \
  --output ../release-evidence/build-result-production --execute
```

These commands build locally only. They do not publish images or deploy. Run the approved dependency/image/secret scans and keep their actual outputs. Local image IDs are not registry manifest digests.

After release approval, an operator authenticates to the approved registry interactively and pushes the four actual tags. Example invocation shape:

```bash
docker login ACTUAL_REGISTRY_HOST
docker push ACTUAL_API_TAG
docker push ACTUAL_WEB_TAG
docker push ACTUAL_MIGRATION_TAG
docker push ACTUAL_TURN_TAG
```

Do not place registry passwords in flags. Obtain the actual repository manifest digest from the registry/push result, verify it through the registry inspection/pull workflow and record the exact `repository@sha256:...` references in external `images.json`, with keys `api`, `web`, `migrate`, `postgres`, `turn`. Retain the previous release images. No build occurs on the production host.

Build the acceptance frontend with `release_mode:"staging"`, the real isolated `staging.`/`load.` HTTPS origin, sandbox checkout and a distinct web tag, using `--web-only`. Reuse the **exact same API, migration, PostgreSQL and TURN images**. Record the reviewed web-only canonical origin/release mode/sandbox differences; rebuilding a different backend invalidates the prior capacity evidence.

```bash
node scripts/release-build.mjs --source . \
  --config ../release-evidence/build-acceptance.json \
  --output ../release-evidence/build-result-acceptance-web --execute --web-only
```

## 4. Prepare the two hosts, DNS and network controls

Install a supported Docker Engine/Compose release using its official instructions, apply host security updates and time synchronization, configure operator SSH keys and recovery-console access, and record the exact versions. Copy the frozen source to a root-controlled release directory such as `/opt/notitle/releases/RELEASE`; do not modify that copy during deployment. Keep environment files, keys and evidence outside it.

Set the public canonical website DNS record to the app VM through Cloudflare. Configure its reviewed alternate-host redirect, DNSSEC/CAA and **Full(strict)** TLS. Keep IPv6 unpublished until both firewall and connectivity tests pass. TURN uses a separate **DNS-only** hostname pointing to the relay VM. TURN TLS443 is not HTTPS and must not use the ordinary Cloudflare web proxy.

Production app provider firewall: deny unsolicited inbound traffic; allow TCP 443 only from the reviewed current Cloudflare ranges, SSH only from approved operator/VPN sources, and the private administrative gateway only through its approved access path. Public API8080, PostgreSQL5432 and admin9090 must be unreachable externally. Docker's published-port rules can bypass UFW-only assumptions; verify denial from a separate authorized network.

Relay firewall: public UDP/TCP 3478, TCP 443 and UDP 49152–50175; private TCP 9443 only from the app VM's private address; CLI5766 stays loopback. Do not expose a metrics/admin/Docker socket. Test the real allocation and cancellation paths before enabling audio.

Provision `ORIGIN_TLS_DIRECTORY` with:

- `origin-cert.pem` and `origin-key.pem`: correct canonical SAN and valid chain, using a publicly trusted certificate or Cloudflare Origin CA.
- `origin-pull-ca.pem`: the app's own CA for **zone-level** Authenticated Origin Pulls. Upload the corresponding leaf client certificate/key to the correct Cloudflare zone and enforce it at Caddy.
- `cohort-password-hash`: a unique bcrypt hash produced interactively with `caddy hash-password`, when using validation/cohort ingress. It is not the app/operator password.
- `cloudflare-proxies`: the reviewed current Cloudflare CIDRs, one per line, when using source-restricted validation.

Set `ORIGIN_AUTH_SCOPE=zone` only after verifying that setup. The shared global AOP certificate proves Cloudflare-network origin, not this app's zone, and does not meet this deployment contract. Official availability checked 2026-10-09 includes zone-level AOP on Free; no paid Custom Origin Trust Store or custom edge-certificate service is needed. Follow the cited sources in `phase10-deployment.md`; verify actual account capability and handshake results.

Acceptance has a different TLS path: use its own **DNS-only** `staging.` or `load.` hostname and isolated app VM, with inbound TCP 443 reachable for Caddy's public TLS-ALPN certificate challenge and HTTPS tests. Keep port 80 unpublished; confirm the chosen CA issues/renews through TLS-ALPN on 443, and permit the required outbound DNS/ACME traffic. Do not put this host behind the production Cloudflare-only firewall or reuse a Cloudflare Origin CA certificate. The staging entrypoint leaves its TLS snippet empty, so Caddy obtains public TLS automatically; it does not use production AOP files. Keep its own protected, empty `ORIGIN_TLS_DIRECTORY` for the inherited read-only mount, plus the separate protected staging bcrypt file. The supplied acceptance validator permits this layout; actual issuance, renewal, authentication and external denial tests remain required. Staging Basic Auth protects browser/API traffic, with only the exact signed Cashfree webhook route exempt; `noindex` is additional indexing control, not access control. Use no production data or credentials there.

The separate `ADMIN_ORIGIN` must be an HTTPS operations hostname reachable only through the authenticated VPN/access gateway. Its proxy goes to host-loopback9090 and preserves the exact Host/Origin; it is never added to public Caddy. Provision and test this gateway under the host access policy. The application supplies no public `/admin` shortcut or default operator.

## 5. Provision independent secrets and directories

Create protected directories through the host's secret-management workflow. API-owned secrets/journals use numeric UID/GID 65532 and private directory 0700/file 0400 or0600. PostgreSQL password files must be readable by its actual container UID; inspect the selected PostgreSQL image's `postgres` user instead of assuming a UID. Caddy's protected files must be readable by its container user. Ordinary Compose bind mounts preserve host ownership; a YAML `uid` or `mode` is not a reliable owner-remapping mechanism.

| Host path example | Contents/use | Separation |
| --- | --- | --- |
| `/etc/notitle/database` | Three independent administrator/migration/runtime passwords | Never reuse local credentials |
| `/etc/notitle/api-secrets` | Runtime DSN, evidence keyring, independent MFA key | No migration/admin DSN in long-running API |
| `/etc/notitle/migration` | Migration DSN | Mounted only in migration/approved one-off operator process |
| `/etc/notitle/operations` | `case_keyring`, approved `retention-policy.json`, `primary_token`, `backup_token` | Distinct from report evidence/MFA/payment keys |
| `/etc/notitle/payments` | `client_id`, `client_secret`, optional bounded-overlap `previous_secret` | Separate sandbox and live directories |
| `/etc/notitle/audio-client` | Relay bearer, control CA, client certificate/key | App-to-relay control only |
| `/etc/notitle/origin` | Origin/AOP material and cohort hash | Caddy only |
| `/etc/notitle/launch` | Later: checked `approval.json` | API read-only mount; directory exists before permit |
| `/var/lib/notitle-holds` | Durable hold/release journal | Separate from database and deletion journal |
| `/var/lib/notitle-observe/published` | Atomic `current.json` observations | Protected collector output; API read-only |
| Relay: `/etc/notitle-relay` | Relay bearer, control CA/cert/key, public TURN cert/key | Read-only to relay; never in source |

The `deletion_tombstones` named volume is separate from `postgres_data`; its first creation is seeded from the runtime image with UID 65532/mode 0700. Preserve both independent journals across every database restore. Never use `docker compose down -v` or blanket volume pruning on production.

Generate each encryption key from independent32-byte cryptographic randomness, without printing it. Evidence/case keyrings contain `active_key_id` plus a `keys` map of key IDs to base64 keys. MFA contains base64 for one separate32-byte key. Keep old authorized decryption keys while required records/backups still need them. The relay-control token is64 hex characters from32 random bytes; provision the same token to the two intended control endpoints, never to a browser.

Create the three database passwords independently. The initial PostgreSQL entrypoint creates `notitle_bootstrap`, `notitle_migrate` and `notitle_app`; migrations and runtime use their respective roles. Runtime and migration DSN files point to private host `postgres`, database `notitle`, with URL-escaped credentials. Same-host private-bridge examples use `sslmode=disable`; a moved/off-host database requires verified TLS (`sslmode=verify-full`). Never pass raw DSNs/passwords on the command line or shell-source the environment file.

## 6. Fill the protected environment files

Use an operator-controlled protected editor. The environment file contains image references, flags and **paths**, never inline passwords/API keys. Required values include:

| Area | Variables |
| --- | --- |
| Images/domain | `APP_DOMAIN`, `NOTITLE_API_IMAGE`, `NOTITLE_WEB_IMAGE`, `NOTITLE_MIGRATION_IMAGE`, `NOTITLE_POSTGRES_IMAGE` |
| Database files | `POSTGRES_ADMIN_PASSWORD_FILE`, `POSTGRES_MIGRATION_PASSWORD_FILE`, `POSTGRES_RUNTIME_PASSWORD_FILE`, `MIGRATION_DATABASE_URL_FILE`, `RUNTIME_DATABASE_URL_FILE` |
| Identity/safety | `IDENTITY_ENABLED`, `REALTIME_ENABLED`, `SAFETY_ENABLED`, `ADMIN_ENABLED`, `FRIENDS_ENABLED`, `TERMS_VERSION`, `PRIVACY_VERSION`, `COMMUNITY_VERSION`, `CASE_RETENTION_DAYS`, `CASE_RETENTION_POLICY_VERSION`, `MODERATION_COVERAGE_CONFIRMED`, `ADMIN_ORIGIN`, `EVIDENCE_KEYRING_FILE`, `ADMIN_MFA_KEY_FILE` |
| Origin/launch | `ORIGIN_TLS_DIRECTORY`, `ORIGIN_AUTH_SCOPE`, `LAUNCH_APPROVAL_DIRECTORY`, `LAUNCH_STAGE`, `NOTITLE_LAUNCH_STAGE`, later `DEPLOYMENT_MANIFEST_SHA256`, `COHORT_USERNAME`, validation-only `VALIDATION_SOURCE_CIDRS` |
| Operations | `OPERATIONS_SECRET_DIRECTORY`, `HOLD_JOURNAL_DIRECTORY`, `OPERATIONS_OBSERVATION_DIRECTORY`, `OPERATIONS_COVERAGE_APPROVED`, `OPERATIONS_COVERAGE_REFERENCE`, `OPERATIONS_ALERT_PRIMARY_URL`, `OPERATIONS_ALERT_BACKUP_URL` |
| Audio | `AUDIO_SAFETY_VERIFIED`, `AUDIO_CONTROL_URL`, `AUDIO_CONTROL_TOKEN_FILE`, `AUDIO_CONTROL_CA_FILE`, `AUDIO_CONTROL_CLIENT_CERT_FILE`, `AUDIO_CONTROL_CLIENT_KEY_FILE`, `AUDIO_RELAY_ADDRESSES` |
| Payments | `PAYMENT_SECRET_DIRECTORY`, `PAYMENT_ENVIRONMENT`, `PAYMENT_MERCHANT_ID`, `PAYMENT_MERCHANT_APPROVED`, `PAYMENT_POLICY_APPROVED`, `PAYMENT_ANNUAL_APPROVED`, `CHECKOUT_ENABLED` |
| Acceptance only | Distinct origin/images/paths plus `STAGING_USERNAME`, `STAGING_PASSWORD_HASH_FILE`; `PAYMENT_ENVIRONMENT=sandbox` |
| Relay host | `NOTITLE_TURN_IMAGE`, `TURN_HOSTNAME`, `TURN_PUBLIC_IP`, `TURN_RELAY_IP`, `RELAY_CONTROL_ADDR`, `RELAY_SECRETS_DIR` |

Do not set approval flags from this table alone. Audio/operations/payments are enabled by their overlays only after their prerequisites exist. `FRIENDS_PER_IDENTITY` defaults 100. The base template always passes `MAINTENANCE_MODE=true`. Start with API `LAUNCH_STAGE=validation`, Caddy `NOTITLE_LAUNCH_STAGE=maintenance`, no approval file, and no fabricated manifest digest. The initial protected directory may be empty; startup is possible while admission stays closed.

## 7. Define consistent Compose commands

On the app host, from the frozen source directory, use these Bash functions. The initial base command deliberately excludes optional services that have not been configured. All later full candidate commands use the same ordered overlays:

```bash
base_app() {
  docker compose --project-name notitle --env-file /etc/notitle/production.env \
    -f deploy/production/compose.yml "$@"
}
app() {
  docker compose --project-name notitle --env-file /etc/notitle/production.env \
    -f deploy/production/compose.yml \
    -f deploy/audio/compose.app.yml \
    -f deploy/payments/compose.app.yml \
    -f deploy/operations/compose.app.yml "$@"
}
```

On the separate relay host, from its same frozen source:

```bash
relay() {
  docker compose --project-name notitle-relay --env-file /etc/notitle-relay/relay.env \
    -f deploy/turn/compose.yml "$@"
}
```

A temporary acceptance app uses a distinct host/data/environment/project. Never point this function at production volumes or credentials:

```bash
acceptance() {
  docker compose --project-name notitle-acceptance --env-file /etc/notitle/acceptance.env \
    -f deploy/production/compose.yml -f deploy/staging/compose.yml \
    -f deploy/audio/compose.app.yml -f deploy/payments/compose.app.yml \
    -f deploy/operations/compose.app.yml "$@"
}
```

If adding a reviewed backup overlay, append that same file to **every** command/manifest for the affected environment, as described below. Do not switch project names, silently omit overlays or shell-source environment files between migration and startup.

## 8. Initialize the closed foundation and operators

After verifying the actual images/secrets/host controls, the operator runs:

```bash
base_app config --quiet
base_app --profile ops pull
base_app up -d --wait postgres
base_app --profile ops run --rm migrate up
base_app --profile ops run --rm migrate status
```

The cumulative migration must be9. Do not start the API between migrations8 and9. An existing database is not reinitialized by changing `POSTGRES_*` variables; role/password rotation needs an explicit reviewed database change and matching secret update.

Provision real operators using the API image's `/adminctl`, connecting to the private Compose database network. Create an external private operator directory owned by UID 65532 containing the owner `operator-input.json` (`username`, generated password, minimum `roles`), migration DSN and a protected MFA-key copy; do not paste secret values into a command. Set `NOTITLE_API_IMAGE` in the shell only to the already reviewed public digest string, not by sourcing the environment file.

```bash
docker run --rm --read-only --user 65532:65532 \
  --network notitle_database --cap-drop ALL \
  --security-opt no-new-privileges:true --ulimit core=0 \
  --mount type=bind,src=/protected/admin-provision,dst=/private \
  --entrypoint /adminctl "$NOTITLE_API_IMAGE" \
  --action provision \
  --input-file /private/operator-input.json \
  --database-url-file /private/migration-database-url \
  --mfa-key-file /private/admin-mfa-key \
  --enrollment-file /private/new-owner-enrollment.txt
```

Import the enrollment privately into that operator's authenticator; verify sign-in and remove temporary secret input/enrollment under the protected procedure. Provision a separate trained backup and scoped moderator/grievance/billing/observer accounts as needed. Never reuse an owner password or share MFA. On a lost response, inspect the actual record before retrying; the transaction may have committed.

Install the already reviewed retention manifest through the same one-off image and network, with fresh owner credentials/TOTP in a private `policy-approval.json` file:

```bash
docker run --rm --read-only --user 65532:65532 \
  --network notitle_database --cap-drop ALL \
  --security-opt no-new-privileges:true --ulimit core=0 \
  --mount type=bind,src=/protected/admin-provision,dst=/private \
  --entrypoint /adminctl "$NOTITLE_API_IMAGE" \
  --action install-retention-policy \
  --policy-file /private/retention-policy.json \
  --input-file /private/policy-approval.json \
  --database-url-file /private/migration-database-url \
  --mfa-key-file /private/admin-mfa-key
```

The mounted runtime `retention-policy.json` must have the same approved canonical contents/version. Publish actual legal deadline rules and quarterly notice text through reviewed, hashed, transaction-scoped data SQL under `notitle_migrate`, preserving immutable versions and original receipt clocks. See `server/internal/operations/README.md` for column contracts. Publish the reviewed immutable price/tax plan versions similarly. The delivery's examples are unapproved/disabled and intentionally cannot satisfy launch.

For a reviewed data-only SQL file, prepare a private PostgreSQL password file (`pgpass`) for the migration role through the protected secret workflow. Keep it 0600/UID 65532, outside source; its contents never appear in command arguments. The SQL file must contain only the approved data changes, without its own transaction-control statements. Run it on the existing private network using the reviewed PostgreSQL image:

```bash
docker run --rm --read-only --user 65532:65532 \
  --network notitle_database --cap-drop ALL \
  --security-opt no-new-privileges:true --ulimit core=0 \
  --mount type=bind,src=/protected/data-publication,dst=/private,readonly \
  -e PGPASSFILE=/private/pgpass \
  --entrypoint psql "$NOTITLE_POSTGRES_IMAGE" \
  --host postgres --username notitle_migrate --dbname notitle \
  --no-psqlrc --set ON_ERROR_STOP=1 --single-transaction \
  --file /private/reviewed-data-publication.sql
```

Set `NOTITLE_POSTGRES_IMAGE` only to the reviewed public digest string. Preserve the SQL digest, approval, execution result and non-sensitive postcheck in the release record. Do not use this path to issue unreviewed financial adjustments or clear safety/deletion fences.

This is data publication at schema 9. If you choose to package it as a new Goose schema migration, first update the source/readiness/launch schema binding and rerun acceptance; do not apply migration 10 while claiming the unchanged schema 9 release. Never grant migration privileges to the runtime role or edit old immutable plan/policy content.

With reviewed identity/safety settings and private administration configured, start the base API/web closed:

```bash
base_app up -d --no-deps --scale api=1 api
base_app up -d --no-deps web
```

Verify the private operator login. `/health/live` can return200; `/health/ready` deliberately returns503 while admissions are closed. Do not use `up --wait api` as a launch/approval mechanism or weaken readiness to turn its health indicator green.

## 9. Make backups and monitoring real

The supplied backup files are templates. They do not install pgBackRest, mount its configuration, schedule backups or prove recovery. Before full operations, create and scan the approved backup-capable PostgreSQL image, configure its least-privilege repository credentials, and rehearse backup/restore on the exact image. Record it as the actual `postgres` digest before acceptance.

For this Compose layout, pgBackRest's database path is `/var/lib/postgresql/18/docker`, not a generic older PGDATA path. Its database user must be the reviewed backup role; the cluster's initial administrator is `notitle_bootstrap`, not automatically a role named `postgres`. Have the DBA review the required PostgreSQL backup permissions and peer/socket authentication; do not silently substitute an all-powerful runtime user.

Create an operator-reviewed external Compose overlay at `/etc/notitle/backup.compose.yml` that mounts only the required protected pgBackRest/archive configuration into PostgreSQL, keeps credentials out of API/web/relay and adds the tested WAL settings from `deploy/operations/postgresql-backup.conf.example`. Preserve existing command settings (`max_connections`, shared buffers, SCRAM) when replacing the Compose `command` list. This file is an operator-created, reviewed prerequisite; the repository does not supply a ready-to-run backup overlay. It must add no extra service, exposed port or API feature. Its absolute bind paths must use `create_host_path: false`. Configuration examples are not installed host paths.

Redefine both production functions with this same final overlay. The `base_app` function still excludes audio/payments/operations, so backup commands do not interpolate their unset configuration or prematurely enable them:

```bash
base_app() {
  docker compose --project-name notitle --env-file /etc/notitle/production.env \
    -f deploy/production/compose.yml \
    -f /etc/notitle/backup.compose.yml "$@"
}
app() {
  docker compose --project-name notitle --env-file /etc/notitle/production.env \
    -f deploy/production/compose.yml \
    -f deploy/audio/compose.app.yml \
    -f deploy/payments/compose.app.yml \
    -f deploy/operations/compose.app.yml \
    -f /etc/notitle/backup.compose.yml "$@"
}
```

Keep these functions for every subsequent production command and manifest. The isolated acceptance environment needs its own separately reviewed backup overlay and paths, appended last to `acceptance`; never mount production backup credentials there.

While the foundation remains closed, stop its sole API before changing/restarting PostgreSQL, activate the reviewed backup layout and run the installed tool:

```bash
base_app config --quiet
base_app stop api
base_app up -d --wait postgres
base_app exec -T --user postgres postgres pgbackrest --stanza=notitle stanza-create
base_app exec -T --user postgres postgres pgbackrest --stanza=notitle check
base_app exec -T --user postgres postgres pgbackrest --stanza=notitle --type=full backup
base_app exec -T --user postgres postgres pgbackrest --stanza=notitle info
base_app up -d --no-deps --scale api=1 api
base_app up -d --no-deps web
```

Here `--user postgres` is the **container operating-system user**, separate from `pg1-user` in the backup configuration. Confirm it exists in the approved image. Schedule weekly full/daily differential backups plus continuous WAL using reviewed host timers. Keep the preceding full and all WAL required for a30-day restore window; do not apply a blanket30-day S3 lifecycle that truncates the chain. Verify recovery/decryption credentials are available to the backup operator outside both hosts.

Independently archive deletion/hold journal records and approved content-free security logs using `deploy/operations/README.md`, the `operations-archive.py` utility and reviewed S3 IAM/Object Lock/lifecycle configuration. Security retention, financial obligations and journal replay have distinct purposes. Test exact remote integrity and restore; local encryption/upload success alone is not a recoverable-point measurement.

Configure the protected observation collector, real external HTTPS probe and actual monitored primary/backup receivers. The external probe must detect loss of the entire app host and notify a human without relying on that host. Supply real WAL/deletion/hold recovery timestamps and relay/clock/transfer evidence to the collector. Do not copy the draft observation JSON as passing evidence. Review `deploy/operations/notitle-observe.service` and `deploy/operations/notitle-observe.timer` paths, ownership and runtime budget before installation. Adapt `ExecStart` to the frozen release path and `--disk-path` to the actual host filesystem containing the PostgreSQL volume; the example paths are not an installation command.

Leave the production API on the closed base configuration throughout the next preparation and isolated-acceptance steps. Do not run `app` yet: its overlays require approved audio safety, live merchant/policy settings and operations evidence. Full production activation occurs in section 13 after those prerequisites pass; it adds no extra API replica or monitoring VM.

## 10. Prepare the separate relay

Provision publicly trusted TURN hostname TLS, private control server certificate/CA and the app's client-auth certificate. The client/server SAN and extended-key usages must match the private URL; the control token must match both endpoints. Never disable certificate verification or use the local HTTP exception in staging/production.

On the relay host:

```bash
relay config --quiet
relay pull
relay up -d
relay ps
```

At this point the production relay is a closed standby: its controller must fail closed without the matching app synchronization, and no production audio admission is enabled. Prove supervisor synchronization, normal allocation cancellation within 5 seconds, orphan cleanup within 30 seconds, fail-closed watchdog behavior and old-credential replay rejection against the exact same coturn image on the isolated acceptance relay in section 12. Test public UDP 3478 and TURN-over-TLS443 from separate networks and real devices there. A running container does not prove these gates. Keep `AUDIO_SAFETY_VERIFIED=false` in production until the actual proof is recorded; do not start its audio overlay with this flag false. Production counterpart connectivity/synchronization is checked after closed activation, before any controlled opening.

## 11. Configure Cashfree and approved catalog

Complete written merchant acceptance of the **actual** service: pseudonymous guests, random text/audio, mutual friends and paid preferences. Do not relabel features to pass underwriting. Obtain reviewed tax/invoice/refund treatment, annual economics and a valid late-refund route. NoTitle registration remains phone/email-free; a genuine provider-required checkout phone is transient, separately disclosed and never shown to peers.

Use a separate Cashfree sandbox merchant configuration/keys for acceptance. Place `client_id`/`client_secret` in the protected sandbox directory; production uses independently provisioned live files. Backend `PAYMENT_ENVIRONMENT` is `sandbox` for staging and `production` for production. The web build's checkout environment must match. Cashfree browser success never grants Premium; only server-verified captured payment does.

Register the exact webhook URL:

```text
https://ACTUAL_HOSTNAME/api/v1/webhooks/cashfree
```

The exact staging webhook bypasses staging Basic Auth so the provider can deliver; the server still verifies signature and commits the durable inbox before acknowledgement. Trailing/nested variants are not exempt. Keep return/status pages protected and verify the provider's allowed domain/return configuration against the application's `/payment/status` flow. Do not add a browser token or status secret to a URL.

Publish reviewed new immutable plan versions with the agreed totals/durations:₹99/72 hours,₹199/168 hours,₹499/720 hours and₹1499/8760 hours. The seeded version 1 rows contain `pending_review` tax and remain disabled; changing their immutable price/tax fields fails. Use new versions with actual approved tax treatment. Annual availability additionally needs the database annual approval and `PAYMENT_ANNUAL_APPROVED=true` after the real review. Public/checkout catalog and server snapshots must agree.

After approvals and sandbox configuration, `PAYMENTS_ENABLED=true` comes from the overlay; `CHECKOUT_ENABLED` remains a separate switch. Once purchases exist, keep processing/webhooks/refunds/reconciliation enabled even when stopping new checkout. Never switch the entire payment processor off merely to close sales.

Run the full sandbox capture/duplicate/out-of-order/retry/lost-return/refund/ledger/deletion/reconciliation matrix in `docs/phase8-acceptance.md`. A refund request is not proof of bank credit; settlement needs provider/bank evidence. Do not perform a live purchase/refund from setup instructions alone. The later validation window needs prior explicit authorization with actual purchase/refund/spend limits.

## 12. Prove acceptance on isolated infrastructure

On the distinct acceptance hosts, first complete the real sandbox, legal/operator/retention, private administration, observation and backup prerequisites needed by the full acceptance overlays. Configure its DNS-only public TLS path from section 4 and place its separately reviewed backup overlay at `/etc/notitle/acceptance-backup.compose.yml` on that host. Use the exact shared backend/relay images, acceptance frontend, separate sandbox keys, data volumes, journal directories and private credentials. Start its database and migrations before its API; provision its operators and approved data using its own database network and private files, following section 8. With its own relay already prepared, redefine the acceptance command to include its own backup overlay and run:

```bash
acceptance() {
  docker compose --project-name notitle-acceptance --env-file /etc/notitle/acceptance.env \
    -f deploy/production/compose.yml -f deploy/staging/compose.yml \
    -f deploy/audio/compose.app.yml -f deploy/payments/compose.app.yml \
    -f deploy/operations/compose.app.yml \
    -f /etc/notitle/acceptance-backup.compose.yml "$@"
}
acceptance config --quiet
acceptance --profile ops pull
acceptance up -d --wait postgres
acceptance --profile ops run --rm migrate up
acceptance --profile ops run --rm migrate status
```

Complete the isolated operator/data/retention provisioning at schema 9, then:

```bash
acceptance up -d --no-deps --scale api=1 api
acceptance up -d --no-deps web
```

Staging can exercise the audio proof before production `AUDIO_SAFETY_VERIFIED` is approved; it does not waive production safety gates. Stage administration still requires private access and MFA. Open staging admission only through the authorized private owner workflow after readiness passes; staging does not require a production launch permit. Confirm HTTPS/Basic Auth and the exact signed-webhook exception before using designated test accounts.

Run all tests in `docs/phase1-acceptance.md` through `docs/phase10-acceptance.md`, plus real-device workflows. Desktop: Chrome/Edge/Firefox/Safari on supported systems. Phones first: physical Android Chrome/iPhone Safari,320–430px, rotation, keyboard, screen lock/app switching, microphone denial, cellular/Wi-Fi transitions and checkout return. Check accessibility, SEO, noindex and secret-free logs/browser storage.

Follow `docs/phase10-capacity.md` and `deploy/load/README.md` for independently authorized, bounded synthetic load and collectors. The supplied runner command shape is:

```bash
node scripts/load-soak.mjs \
  /protected/load-permit.json /protected/load-fixtures.json \
  /protected/load-observation.json /protected/new-report-a.json A 21600
```

Repeat with a distinct permit/report/window for `B 21600`; run the specified `overload` scenario separately. The source runner needs real source/image-bound synthetic fixtures, observed workload counters, authenticated private aggregate snapshots, an original captured baseline and actual relayed media. The example JSON files are not usable approvals. Running it on production or real users is forbidden by its contract. Record both six-hour200-connected/25-call cases,100-waiting variant,400-offered overload, dense friends and the required concurrent payment/moderation/backup work. Short tests do not pass capacity.

Rehearse an isolated old-database restore, newer deletion/hold replay, session revocation, safety and money reconciliation, lost host, full disk, receiver failure and backup-operator recovery. Record measured RPO≤ 15 minutes and staffed RTO≤ 4 hours;24 hours is the disclosed contingency, not an achieved result.

## 13. Activate the complete closed candidate and render evidence

Continue only after the isolated acceptance has passed and its actual audio enforcement/device/capacity results, merchant/tax/legal approvals, recovery tests and staffing/delivery records exist. Fill and review every production audio/payment/operations variable and protected file from sections 5–11. Only now set `AUDIO_SAFETY_VERIFIED=true` and the other approved production prerequisite flags from that real evidence. Use the approved live merchant configuration and reviewed immutable catalog; final live-money proof will be collected only inside the later authorized validation window.

Keep `MAINTENANCE_MODE=true`, API `LAUNCH_STAGE=validation` and Caddy `NOTITLE_LAUNCH_STAGE=maintenance`. Render and pull the complete stack, stop the still-closed base API and confirm zero old owners before starting its replacement. The `app` function below includes the reviewed backup overlay from section 9:

```bash
app config --quiet
app --profile ops pull
base_app stop api
base_app ps
app up -d --no-deps --scale api=1 api
app up -d --no-deps web
```

Check actual image digests, schema 9, protected file access, private owner login, relay synchronization, collectors and live dependency health while admission remains closed. A503 readiness response is expected while closed. Do not manufacture a permit to complete startup.

Next prepare the source-restricted validation ingress: set Caddy `NOTITLE_LAUNCH_STAGE=validation`, the protected cohort credentials and the authorized `VALIDATION_SOURCE_CIDRS`; API stage remains `validation`. Render the candidate configuration below and bind the resulting manifest before restarting that single closed API and Caddy with the bound settings. Section 14 performs that restart and verifies denied access before any owner opens admission. The maintenance bootstrap configuration is not the final validation manifest.

Keep full resolved Compose JSON private; it contains operational configuration. From each real host, render the exact deployed files without editing output. Use the same source image and environment choices as the actual candidate:

```bash
umask 077
app config --format json > /protected/app-compose.json
relay config --format json > /protected/relay-compose.json
```

Those two commands run on their respective hosts. Bring the sanitized review inputs through the controlled evidence workflow. `deploy-config --check-files` must inspect the exact referenced files: run in the trusted host context where both reviewed path sets are available, or use protected review mounts of the exact files and retain separate actual-host ownership/readability checks. Do not copy keys into source or make them world-readable to satisfy the validator.

```bash
node scripts/deploy-config.mjs validate --purpose production --source . \
  --config /protected/app-compose.json --relay-config /protected/relay-compose.json \
  --check-files --out /protected/deployment-manifest.json
```

Generate the isolated acceptance manifest similarly with `--purpose acceptance` and the acceptance app/relay config inputs. Record its actual origin/images/hash in `release.acceptance`. The source digest must match both manifests and the built API. Keep the explicit web-only build-difference review. To check only the production app template without exposing full config:

```bash
./scripts/production-config.sh --env-file /etc/notitle/production.env \
  --project-name notitle --overlay audio --overlay payments --overlay operations
```

This wrapper is shape-only; it lacks host secret inspection and does not produce launch evidence by itself. If the deployment uses an additional reviewed backup overlay, render/validate the full config directly; the wrapper only supports the three listed optional overlays.

Hash the exact manifest bytes, record that value in the evidence and set `DEPLOYMENT_MANIFEST_SHA256` in the protected app environment. Re-render to confirm every other setting is unchanged. The validator excludes only this self-referential environment field from its canonical preimage. Setting a digest does not establish that the actual host matches; the operator verifies running images, mounts and effective settings.

Attach real artifacts and approvals following `deploy/launch/README.md` and `docs/phase10-evidence-template.md`. Hashes prove byte consistency, not report truth or a signer's authority. Missing, failed, expired or fabricated approvals never become passes through a flag.

## 14. Conduct the bounded production validation

This separate phase resolves the bootstrapping issue: final live payment and production smoke cannot be proved before any controlled production interaction. All pre-live gates and named role approvals must already pass. Only genuinely pending `live_money` and `production_smoke` may be deferred, with prior documented bounded live authorization. No safety, recovery, merchant, legal, staffing, device or200/25 capacity gate is waived.

Use the validation configuration/manifest prepared in section 13: API `LAUNCH_STAGE=validation`, Caddy `NOTITLE_LAUNCH_STAGE=validation`, protected cohort credentials and `VALIDATION_SOURCE_CIDRS` for the specifically authorized testers. After setting the exact `DEPLOYMENT_MANIFEST_SHA256` and verifying the re-render, activate these settings while the existing API is still closed:

```bash
app stop api
app ps
app up -d --no-deps --scale api=1 api
app up -d --no-deps web
```

Confirm zero old owners before starting the replacement. Caddy requires both the password and verified source allowlist; source headers are trusted only from the reviewed Cloudflare ranges under zone AOP. Test denial from outside the allowlist and wrong credentials first; the backend remains closed without a valid permit and named-owner action. Ensure the host's effective settings match the exact reviewed validation manifest.

After updating actual evidence, run on the protected release workstation:

```bash
node scripts/launch-evidence.mjs check --purpose validation --source . \
  --evidence ../release-evidence/evidence.json
node scripts/deploy-plan.mjs --purpose validation --source . \
  --evidence ../release-evidence/evidence.json \
  --manifest ../release-evidence/deployment-manifest.json \
  --out ../release-evidence/validation-plan.json
node scripts/launch-evidence.mjs permit --purpose validation --source . \
  --evidence ../release-evidence/evidence.json \
  --out ../release-evidence/validation-permit.json \
  --evidence-ref controlled_validation_01
```

All output paths must be new. A check exit1 means blocked; exit2 means malformed/inaccessible. No command deploys, opens admission, sends messages or moves money. The validation permit is at most two hours and can expire sooner with its underlying authorization/evidence.

Transfer the reviewed permit to the app host through the protected channel. Install it atomically into the already mounted directory as a regular UID 65532-owned0400 file, without changing its contents:

```bash
sudo install -o 65532 -g 65532 -m 0400 \
  /protected/validation-permit.json /etc/notitle/launch/approval.json.new
sudo mv -T /etc/notitle/launch/approval.json.new /etc/notitle/launch/approval.json
```

The example assumes `LAUNCH_APPROVAL_DIRECTORY=/etc/notitle/launch`. Verify the destination, ownership and source hash before replacement. The API checks its source/API image/origin/schema/manifest binding and current readiness. An actual named owner signs into the private MFA interface and deliberately opens admission with the permit's evidence reference. Do not bypass CSRF by scripting an unauthenticated POST.

Perform only the specifically authorized production two-browser/report/block/cross-network audio/payment capture/refund/settlement checks, using designated accounts. Preserve real provider and bank results. The validation window auto-drains when it expires; if bank settlement takes longer, leave new admission closed and await the actual result. Do not refresh timestamps or invent settlement to obtain launch approval.

## 15. Open the supervised cohort, then broader access

After all full-V1 gates pass, prepare a new manifest with API/Caddy stages both `cohort`, protected cohort credentials and the same tested immutable images. Drain/restart through the next section before changing stage. Update the manifest/evidence bindings and request the full permit:

```bash
node scripts/launch-evidence.mjs check --purpose launch --source . \
  --evidence ../release-evidence/evidence.json
node scripts/deploy-plan.mjs --purpose launch --source . \
  --evidence ../release-evidence/evidence.json \
  --manifest ../release-evidence/deployment-manifest.json \
  --out ../release-evidence/cohort-plan.json
node scripts/launch-evidence.mjs permit --purpose launch --source . \
  --evidence ../release-evidence/evidence.json \
  --out ../release-evidence/cohort-permit.json \
  --evidence-ref supervised_cohort_01
```

Install the checked permit using the same protected atomic method. A named owner deliberately opens the private backend admission control. Launch-permit expiry limits future opening authorization; it does not force a daily shutdown of an already approved service.

Supervise a full operating cycle with urgent-case human coverage, backup acknowledgement, payments/refunds, archive/recoverable points, latency/resource/cost checks and no unresolved critical/high defects. Record `rollout.cohort_observation`. Only then can a newly reviewed `public` API/Caddy stage and a new bound launch permit authorize broader acquisition. Re-drain, update the exact manifest/env, restart one owner, verify and reopen deliberately. Never label a feature-disabled or unbenchmarked cohort as complete V1.

## 16. Drain, replace and roll back safely

Prefetch the reviewed images with `app --profile ops pull` before the window, while the existing owner continues operating. In the private owner-MFA interface at `ADMIN_ORIGIN/operations/admission`, select **Drain**, enter a reason and a deadline≤ 120 seconds. Drain takes no evidence reference; the reference is for **Open**. Existing users receive the restart deadline. New queue/friend/call/checkout admissions stop, while support/reports/provider callbacks and existing financial obligations keep working where dependencies allow.

Wait for the deadline and confirm interactions ended and TURN cleanup is complete. If relay revocation is uncertain, keep audio closed and execute its fail-closed recovery procedure. Do not restart Caddy first: its restart breaks WebSockets immediately and would skip the promised grace period.

With maintenance ingress selected and the reviewed environment ready:

```bash
app stop api
app ps
app --profile ops run --rm migrate up
app up -d --no-deps --scale api=1 api
app up -d --no-deps web
```

Before starting the replacement, verify **zero** old application owners across all projects/processes. `app ps` is one check, not proof that no unrelated process exists. Never start a second API against the same database, perform a rolling overlap or use `down -v`. Keep ordinary webhooks retryable during the brief API outage and reconcile afterward. Every new production API starts closed and requires a current permit/private owner action.

For failure rollback: drain/close, stop the candidate, restore the recorded schema-compatible API+web digest references, keep maintenance enabled, start one owner and verify journals/safety/financial work. Do not run a production DOWN migration or restore an old database to undo code. If the old binary is incompatible with schema 9, roll forward a reviewed fix. Keep payment processing active where possible; stop only new checkout rather than abandoning pending capture/refund work.

A disaster restore is separate: verified base+WAL, all independent newer deletion/hold records, retained keys, restored-session revocation, safety/payment reconciliation and tested readiness before reopening. Missing/corrupt journals block opening. Preserve evidence and measure actual recovery timing.

## 17. Daily maintenance and certificate renewal

Daily: urgent/overdue cases, delivered/human-acknowledged alerts, captured-but-ungranted payments, refunds/disputes, failed/dead-letter jobs, privacy/hold work, external availability, current recoverable DB/WAL/journal points, disk and relay transfer. An unknown metric is not zero.

Weekly: reconcile provider capture/refund/fee/settlement reports, inspect trends, sample restores and review coverage. Monthly: patch supported components through the same candidate/acceptance/deploy workflow, review access/secrets/TLS/domain expiry, measured costs and retention outcomes. Quarterly and after backup changes: full isolated restore and independent backup-operator incident drill.

Alert on certificate expiry at 30/14/7 days. For origin/control/TURN renewal, validate SAN/chain/key pairing, stage protected replacement material and rehearse rollback. TURN requires an orderly call drain and container restart, allocation destruction, new supervisor synchronization and fresh browser consent; replacing a file is not proof of reload. Caddy's admin API is disabled, so changing its runtime config/certificates requires a drained restart. Never weaken TLS or re-enable the shared global CA to hide a renewal failure.

Investigate around140 connected users/18 calls, sustained CPU65–70%, post-GC RAM75%, owner lag100ms, disk70% or less than 30 days forecast headroom. Diagnose/measure before purchasing additional capacity. Scale the demonstrated bottleneck vertically first; introducing multiple matchmaking owners requires a separate ownership/coordination design and fresh privacy/security/capacity acceptance.

The source package makes these workflows reviewable. Actual production readiness exists only when the operators complete and record the checks above.
