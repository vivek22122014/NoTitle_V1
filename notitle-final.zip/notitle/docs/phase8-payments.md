# Phase 8 payments and financial operations

This implementation extends the existing single Go application and PostgreSQL database. The browser uses Cashfree hosted checkout; only verified server-side payment state and a committed ledger transaction activate Premium. No separate worker host, Redis, subscription billing, outgoing user-email service or card-data store is introduced. Source implementation does not establish merchant acceptance, live settlement, approved tax treatment or financial runtime acceptance. Start with `PHASE8_STATUS.md` and `docs/phase8-acceptance.md` for the current evidence boundary.

## Business contract

NoTitle is an India-first adult workplace conversation service with pseudonymous guests, shared random matching, ordinary text, mutual friends and relay-only two-person audio. Premium adds the finalized matching controls; basic conversation, audio and friendship remain available to Guest and Free users. All tiers share one matching pool, and both directional gender preferences remain strict. Provider underwriting must explicitly accept this actual product, including paid gender preferences. Do not hide, rename or remove features to obtain approval.

| Versioned proposal | Consumer total | Exact continuous duration | Public prerequisite |
| --- | ---: | ---: | --- |
| Three day | ₹99 | 259,200 seconds / 72 hours | Approved common checkout, tax and refund policy |
| Seven day | ₹199 | 604,800 seconds / 168 hours | Approved common checkout, tax and refund policy |
| Thirty day | ₹499 | 2,592,000 seconds / 720 hours | Approved common checkout, tax and refund policy |
| Annual | ₹1,499 | 31,536,000 seconds / 8,760 hours | Common gates plus unit economics and a valid later-refund process |

No plan auto-renews or creates a debit mandate. Duration runs continuously, including offline, and additional purchases append time. Use integer paise and exact seconds, not binary floating-point price arithmetic or calendar months. The server catalog supplies enabled plan versions, immutable order snapshots and the public purchase display. A later price, name or enablement change cannot rewrite an earlier purchase. Tax-inclusive consumer totals are the proposed policy; actual classification, invoice values and any output-tax split require accountant approval before live checkout.

Registration remains phone/email-free. A genuine gateway-required payment contact is collected only in the reviewed checkout flow, disclosed before submission, never invented and never exposed to peers. Optional email remains omitted. NoTitle does not send user emails; provider/bank communications are separate. Confirm the merchant's approved contact/notification arrangement in sandbox and with underwriting before live activation.

## Durable boundaries

```mermaid
flowchart TD
  Browser["Authenticated checkout"] --> Intent["Immutable purchase intent"]
  Intent --> Provider["Cashfree hosted payment"]
  Provider --> Verify["Server fetch and validate"]
  Hook["Signed durable inbox"] --> Verify
  Jobs["Reconciliation jobs"] --> Verify
  Verify --> Ledger["One capture grant transaction"]
  Ledger --> Owner["Entitlement invalidation"]
  Ledger --> Receipt["Self-owned receipt"]
```

The account plus idempotency key identifies a purchase intent. The intent is committed before external order creation, which uses the stable merchant reference. Return usable checkout configuration only after its association is saved. A provider timeout leaves an unknown outcome to reconcile using that same reference; do not generate a replacement order blindly.

A purchase can have several payment attempts. Confirm order/payment state using the server's authenticated Cashfree adapter, checking exact environment, merchant, order references, currency, paise and original duration snapshot. Only `SUCCESS` is a capture. Browser callbacks and webhook claims are notification inputs; the common transaction validates the trusted fetched result and grants at most one lot. A later failed attempt cannot undo a valid capture. Two genuine captures for one purchase grant once and create a restricted duplicate-payment obligation.

Authenticated `GET /api/v1/me/receipts` returns the latest 100 captured purchases. `GET /api/v1/me/receipts/{purchaseRef}` provides the same self-owned receipt directly by its stable reference, including older purchases outside that list. Receipts preserve the original plan total and separately show total verified `captured_paise` and processed `refunded_paise`; an unexpected duplicate capture must not be hidden by displaying only one plan price. These are owner-only financial records with no checkout session, phone, merchant credentials or peer access. Refund status is available through the self-owned purchase refund endpoint; provider processed does not mean independently confirmed bank credit.

Webhook verification uses the exact raw request bytes and documented timestamp input before parsing. The adapter pins API `2026-01-01` and follows Cashfree's documented HMAC-SHA256/base64 verification, using constant-time comparison. Requests are bounded at 256 KiB. Legitimate provider retries can retain an old timestamp, so delivery age alone is not rejected; the signed timestamp must parse correctly and cannot be more than five minutes in the future. Merchant/environment-scoped delivery fingerprints plus payment/refund/grant uniqueness make replay harmless. A bounded, expiring previous-secret overlap supports rotation. Record only the allowlisted event projection and delivery fingerprint in the inbox, never raw customer/card/bank payloads. The actual HTTP/inbox path must pass the forged-signature and durable-ack tests.

Commit the verified event before acknowledging it. A database/inbox error returns a retryable failure. Background work has finite leases, retry budgets, bounded batches and restricted exceptions for review. External provider calls never occur inside the live coordinator. The ordinary API read/write timeouts, worker HTTP deadlines and database pool must be tested together; repeated provider stalls cannot consume every realtime authorization connection.

## Duration accounting and matching

Under the account ledger lock, consume elapsed UTC time from the oldest available lot and checkpoint before applying a grant, hold, release or revoke. Each lot preserves its originating capture, granted, consumed, held and revoked seconds. Expiry is a projection of remaining available duration, not the sole source of truth. Ordered grant/adjustment events support audit and projection rebuild. Clock rollback cannot grant time; large wall-clock drift must stop trusted matching until resolved.

For example, an older seven-day lot with two days left plus a fresh thirty-day lot gives 32 days. Refunding the untouched thirty-day purchase removes only its 30 days. Refunding a fully consumed old purchase cannot subtract from the newer one. Held duration is unavailable but does not tick down; definitive refund failure restores precisely those seconds starting at resolution time.

Queue join and match commit check current time directly. An expiry worker alone is insufficient. Specific filters pause after expiry, refund or an applicable dispute hold; saved preferences remain private and unchanged until an explicit Continue with everyone choice. Everyone searches can continue without paid professional influence. Durable-before-use accounting attributes paid matching control use to the active FIFO lot; a future stacked lot is not marked used merely because the account owns it. All Guest/Free/Premium pair combinations retain mutual compatibility rules.

The minimal usage flag records an affirmative eligible search request with effective paid controls, not proof that a match completed. Merely viewing settings, saving preferences or staying idle is not paid-search use; an Everyone override and General Talk alone do not add paid professional use. Canceling after the worker has committed that flag can leave the current lot marked used even though the stale match acknowledgement is discarded. This conservative proposed policy classification must be disclosed/reviewed before live checkout; it does not automatically reject service-failure or statutory refund claims.

Capture, hold, release and revoke changes produce durable ordered ledger events and require acknowledged owner publication. Expiry derives from those durable lots/checkpoints and is checked directly by the owner; routine expiry reads do not append periodic events. In the single-process implementation, an owner fence starts before a financial transaction; uncertain publication is retained in bounded process recovery state until a fresh ledger projection can be acknowledged. A restart discards the old live owner and admits participants only with fresh durable authorization. There is no separate message broker or claim of a cross-process durable delivery service. Keep affected paid matching paused while publication is uncertain; a subsequent generic healthy database probe must not remove the fence. An existing conversation is not a fresh paid match and follows the existing safety/audio lifecycle. No receipt, badge or browser preference grants authority.

## Refund and dispute operator procedure

Use the existing private administration listener through the approved protected access path. Separate operator identities, MFA, short sessions and server role checks remain required. Billing staff receive financial views/actions, not general report evidence; moderators do not receive financial data. Sensitive views and actions are audited with purpose, actor, reference, time and outcome.

1. Find the original internal purchase and verified capture through an authorized financial view. Verify the requester using the approved ownership process; a payment screenshot or phone number is not account proof. Check whether another operator, provider dashboard or earlier unknown request already initiated a refund.
2. Preview captured paise, cumulative pending/processed refunds, refundable balance, plan snapshot, remaining lot seconds, paid-use flag, purchase age and entitlement treatment. The proposed unused-within-24-hours policy still permits review of service-failure and statutory claims. Approved rights and policy control; do not turn a local boolean into legal judgment.
3. Record a reason and stable idempotency key. Full refunds hold only the originating lot's remaining seconds before external I/O. Partial compensation defaults to money-only; any reduction requires an explicit seconds preview and authorized selection. A stale preview must be refreshed rather than silently rebased.
4. Submit through the provider using the same reference. Timeout means pending/unknown, not failed. Reconcile before retrying; never create a second refund with a new key to make an ambiguous request disappear.
5. Confirm provider status and exact payment, amount and refund association. Processed full refund revokes only held unused seconds. Definitive failure releases the held seconds from resolution time and records the compensation. Duplicate events cannot repeat either adjustment.
6. Tell the user whether the refund is initiated or provider processed. Actual bank credit can occur later and must not be fabricated. Use the original instrument when supported. Annual service can outlast Cashfree's documented refund window; approved later claims need the separately reviewed, ownership-checked and audited procedure with duplicate-payment protection.
7. Treat a dispute as a separate case with a response deadline. Apply only approved access treatment to the disputed lot and keep the financial history. A complainant is not automatically a safety offender. Preserve response evidence through authorized financial scope, never unrestricted conversation browsing.

No real refund or transfer is authorized by running source tests or reading this runbook. Controlled live validation must be deliberately approved and recorded by the owner after underwriting.

## Reconciliation, outages and recovery

Run stuck/unknown purchase reconciliation at least every five minutes. A known successful payment not granted within five minutes needs monitored escalation. Daily automated comparison covers captures, grants, refunds, disputes, gateway fees/taxes and settlements, including refunds initiated from the provider dashboard. Pagination, late entries and repeated periods must remain idempotent. Weekly operator review is the minimum routine cadence; investigate exceptions immediately. Name primary and backup billing operators and a monitored alert channel before live use; an unread database table is not operational coverage.

Investigate an exception by the stable internal/provider references and immutable snapshot, never by guessing an account from amount, contact data or a screenshot. Unknown-order funds and late captures for disabled/deleted accounts are financial obligations for restricted review; they must not recreate identities. Receipts, ledger and retained references follow approved financial retention. Raw webhook payloads are unnecessary evidence for routine reconciliation and are not stored.

During a provider outage, disable new checkout admission if needed while preserving existing entitlement, authenticated receipts and durable jobs. Do not mark an unknown outcome failed, discard signed inbox work or issue replacement provider requests. Monitor oldest pending age and retry/dead-letter counts. If ledger/clock/invalidation state becomes uncertain, pause affected paid matching and keep safety/identity controls authoritative. Known clock failure also makes webhook ingestion retryable, preventing a bad application timestamp from scheduling financial work far into the future. This webhook readiness check remains independent of ordinary identity/deletion replay, so an identity outage alone need not lose durable provider notifications.

Before an application deploy, drain admission and leave durable payment work recoverable; one API instance remains the design. After restart, resume bounded jobs and reconciliation. Roll back only schema-compatible code. Never use an older database to undo application code because it can erase captures and deletion events.

For database recovery, keep traffic closed, restore the reviewed backup/WAL point, reapply the independent deletion/hold journal, rotate/revoke restored sessions, rebuild entitlement projections and reconcile captures/refunds after the restored point. Deleted identities and refunded access must remain disabled. Verify recovery with synthetic sandbox records before reopening; a copied database alone is not financial recovery.

## Low-cost deployment and assumptions

Payments reuse the existing app VM, database, static frontend, private operator listener and PostgreSQL jobs. No permanent staging, additional database, queue, email provider, paid immediate settlement or billing subscription is required. Current provider/hosting contracts still require verification when purchasing or activating services.

The following reproduce the blueprint's assumptions, not current quotations: ₹97/USD, 18% hosting tax, USD24 app VM, USD6 relay, USD2 backup/log allowance and ₹1,500 annual domain. The full infrastructure baseline is **₹3,787.72/month or ₹45,452.64/year**; adding ₹250/month reserve gives **₹4,037.72/month or ₹48,452.64/year**, rounded funding target **₹4,100/month or ₹49,200/year**. Phase 8 adds ₹0 fixed service subscription under the assumption that measured workloads fit those hosts. Payment fees, staffing, tax liabilities, refund principal, chargebacks, excess usage and temporary staging remain additional.

Using the blueprint's ordinary domestic Cashfree planning rate of 1.95% plus 18% tax on that fee gives an illustrative 2.301% deduction. This is an assumption for budgeting, not a guaranteed live merchant rate or a tax decision.

| Monthly collected amount | Illustrative gateway deduction | Annual deduction at same monthly volume |
| --- | ---: | ---: |
| ₹0 | ₹0 | ₹0 |
| ₹10,000 | ₹230.10 | ₹2,761.20 |
| ₹50,000 | ₹1,150.50 | ₹13,806.00 |
| ₹1,00,000 | ₹2,301.00 | ₹27,612.00 |

Budget original processing fees conservatively as potentially non-refundable. Keep a separate refund/liquidity reserve appropriate to outstanding obligations; the infrastructure contingency is not that reserve. Annual receipts provide cash upfront while service/refund obligations continue. Do not enable the annual offer solely because its upfront amount covers a hosting bill.

Retain the full-V1 minimum of **200 connected users with 25 simultaneous two-person calls**. Payment workers must be included in both six-hour mixed workloads, together with refunds, expiration/invalidation, backups, hashing and safety traffic. Measure database pool wait, queue latency, oldest payment work, CPU/RSS and projection freshness. Optimize bounded queries and worker concurrency first; vertically resize when measured headroom requires it. Adding replicas without a live-state ownership design is unsafe.

## Provider references and live acceptance

Official references for integration review: [Cashfree API overview](https://www.cashfree.com/docs/api-reference/payments/latest/overview), [Create Order](https://www.cashfree.com/docs/api-reference/payments/latest/orders/create-order), [Webhook signature verification](https://www.cashfree.com/docs/api-reference/payments/latest/webhooks/signature-verification), [Cashfree merchant terms](https://www.cashfree.com/tnc/). Provider URLs and behavior can change; validate the pinned API and exact merchant configuration in sandbox, then complete the deliberately authorized live capture/refund/settlement gate. A public provider list is not written acceptance of NoTitle's business.
