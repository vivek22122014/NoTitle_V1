# Phase 9 legal response and commencement register

Version: `in-operations-2026-10-10-draft`. Sources checked: **10 October 2026 (Asia/Kolkata)**. Status: engineering review; **not counsel approval**. Applicable entity/intermediary classification, appointed officers, financial retention and actual publication notices remain release evidence. Recheck this register at launch and before each future commencement. A policy hash binds approved content; changing it requires another review.

## Current category rules

The February amendment is effective **20 February 2026**, although issued on 10 February. The corrected official consolidation incorporates the 26 February corrigendum. Counsel must validate the complaint/order trigger, not only its label. [L1–L3]

| Rule | Trigger | Maximum interval | Responsible role |
| --- | --- | --- | --- |
| IT 3(2)(a)(i) acknowledgement | Original grievance receipt | 24 hours | Grievance Officer |
| IT 3(2)(a)(i) general resolution | Original grievance receipt | Seven days | Grievance Officer |
| IT 3(2)(a) specified removal proviso | Qualifying removal complaint; stated exclusions apply | 36 hours | Grievance Officer |
| IT 3(2)(b) | Qualifying intimate-content/impersonation complaint | Two hours for reasonable practicable removal/disabling measures | Urgent on-call |
| IT 3(1)(d) | Valid court order or qualifying authorised governmental intimation | Three hours | Owner/counsel and urgent on-call |
| IT 3(1)(g)/(h) | Applicable removed information / registration cancellation | 180-day preservation; longer valid directions can apply | Privacy owner |
| IT 3(1)(c) | User rule-consequence reminder | At least every three months | Policy owner |
| IT 3A | Grievance Officer decision / qualifying non-resolution | External GAC appeal pathway; stated 30-day filing period | Grievance Officer |

The internal appeal does not replace or delay external statutory remedies. Do not treat all allegations as a valid takedown order or make unavailable live content reappear for review. Preserve available scoped material and explain the actual action.

CERT-In directions separately require reporting Annexure I incidents within six hours of notice, 180 days of secure ICT logs within India, traceable clock synchronisation and a designated contact. Classify against the official incident list and FAQ; ordinary application errors are not automatically reportable. An initial report must not wait for completed forensic investigation. [L4–L5]

## Upcoming DPDP commencement

The Act notification G.S.R.843(E) and Rules G.S.R.846(E) use publication-based phases. The Gazette issue is dated 13 November 2025; the electronic publication identifiers and MeitY index show 14 November. The December corrigendum corrects the Rules' publication wording. **Do not silently assume an exact future legal date from a secondary summary.** The signed legal register must record the authoritative publication basis and calculated date. Until resolved, the engineering readiness deadlines below use the earlier possible date. [L6–L8]

| Group | Statutory formula | Conservative engineering readiness | Required disposition |
| --- | --- | --- | --- |
| Rules 1,2,17–21; initial Act machinery provisions | On publication | Already published | Confirm actual applicability |
| Rule 4; Act 6(9),27(1)(d) | Publication + one year | **13 November 2026** | Counsel records exact commencement; scope consent-manager duties correctly |
| Rules 3,5–16,22,23; remaining notified substantive Act provisions | Publication + eighteen months | **13 May 2027** | Close privacy/security/rights/retention design before this date |

Rules 6(1)(e) and 8(3) contain one-year personal-data/log provisions. Mapping them to transient text, relay traffic, guest records and deletion requires a purpose-specific legal decision. They cannot be assumed to mean security logs only. No hidden transcript or audio archive is enabled by this phase. If the approved interpretation requires a different retention path, revise notices, implementation and cost before that mode can launch. [L7]

S.O.5458(E), published in October 2026, makes editorial corrections concerning disability wording and data audits. It does not change the commencement groups above. The March/April 2026 IT consultation drafts are not treated as enacted rules in this register. [L9–L10]

## Engineering controls and approval record

Preserve receipt timestamps across retries, assignments and reclassification. Triage immediately; use the earliest applicable due time. Acknowledgement, action, resolution and notification delivery are separate records. Notification retries never restart a statutory clock. A category correction records the former category, source, actor and reason; shortening a deadline is immediate. Relaxing an urgent category requires authorised review.

The shipping policy is draft. Approving a matrix requires actual operator/Grievance Officer and primary/backup names, monitored contact and shifts, counsel identity/reference/date, applicable source and effective date for every rule, retention minima/maxima/triggers, current processor inventory, financial accountant approval and approved response/remedy copy. A generic true/false switch cannot substitute for this evidence. Empty/expired policy data fails readiness for the affected operations; it must not result in indefinite silent retention.

Quarterly reminders use in-app delivery, current version and acknowledgement where applicable. New/returning guests receive the current notice without creating a persistent guest profile. Separately review the annual policy-information obligation in IT 3(1)(f) and material-change notices; the quarterly consequence notice must not be assumed to cover every distinct notice duty. Adult self-attestation is not age verification. Suspected underage access follows the safety workflow and counsel-reviewed proportionate assurance, without casually collecting government identity documents.

## Primary sources

- [L1: MeitY February amendment, G.S.R.120(E)](https://www.meity.gov.in/static/uploads/2026/02/f55fe52418b03f58b0669f6a8bc03b6d.pdf).
- [L2: MIB official corrected IT Rules consolidation, including G.S.R.148(E)](https://www.mib.gov.in/sites/default/files/2026-05/it-rules-2021-2.pdf).
- [L3: MeitY IT Rules and corrigenda index](https://www.meity.gov.in/documents/act-and-policies/information-technology-intermediary-guidelines-and-digital-media-ethics-code-rules-2021-it-rules-2021-IjM5QjMtQWa).
- [L4: CERT-In directions, 28 April 2022](https://www.cert-in.org.in/PDF/CERT-In_Directions_70B_28.04.2022.pdf).
- [L5: CERT-In directions and official FAQ index](https://www.cert-in.org.in/Directions70B.jsp).
- [L6: DPDP Act commencement notification, G.S.R.843(E)](https://www.meity.gov.in/static/uploads/2025/11/c56ceae6c383460ca69577428d36828b.pdf).
- [L7: DPDP Rules 2025, G.S.R.846(E)](https://www.meity.gov.in/static/uploads/2025/11/53450e6e5dc0bfa85ebd78686cadad39.pdf).
- [L8: December corrigendum, G.S.R.892(E)](https://www.meity.gov.in/static/uploads/2025/12/3c7ebbae0e5456f493f486e6845df86b.pdf).
- [L9: DPDP Removal of Difficulties Order, S.O.5458(E)](https://www.meity.gov.in/static/uploads/2026/10/daf495a7b5798a3dfa72a944b51fc176.pdf).
- [L10: MeitY consultation index identifying proposed IT amendments as drafts](https://www.meity.gov.in/documents/act-and-policies/draft-amendments-to-the-it-rules-2021-in-relation-to-strengthening-intermediary-compliance-with-clarifications-advisories-and-directions-issued-by-the-ministry-and-digital-media-oversight-AjM2YjMtQWa).

Technical archive references: [pgBackRest configuration](https://pgbackrest.org/configuration.html), [S3 Object Lock](https://docs.aws.amazon.com/AmazonS3/latest/userguide/object-lock.html), [age project](https://github.com/FiloSottile/age). These explain tooling behavior, not Indian legal approval.
