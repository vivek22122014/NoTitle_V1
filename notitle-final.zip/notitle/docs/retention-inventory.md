# Retention inventory

The phase extensions below are cumulative through Phase 8 and supersede earlier future-feature implementation columns.

## Phase 8 additions

| Data | Location / access | Lifecycle and recovery treatment |
| --- | --- | --- |
| Immutable plan versions and purchase snapshots | PostgreSQL; public catalog exposes enabled offer terms only; order is account/billing scoped | Price, currency, duration and tax treatment are immutable after publication/purchase. Publication toggles do not rewrite past orders. Retain financial evidence under the approved policy. |
| Orders, attempts and original capture associations | Restricted PostgreSQL; self-owned status/receipts and audited billing views | One purchase may have several attempts. Preserve success and unique environment/provider IDs. Deletion disables identity but cannot cascade away financial obligations or reactivate an account after a late capture. |
| Checkout session reference | Restricted purchase working state; returned only for authorized checkout | Treat as a sensitive temporary token, not a log/analytics field or ordinary receipt attribute. Keep out of browser persistence, archives and public caches. Apply approved expiry/minimization with provider reconciliation intact. |
| Required payment-only phone | Transient request memory forwarded to approved hosted-payment provider | Genuine disclosed payment contact only; no identity-profile column, raw inbox payload, ordinary log or peer projection. Provider retention/communications are separate processor disclosures. No optional email is invented or supplied. |
| Premium account projection and lots | PostgreSQL; trusted matching/account/billing scopes | Continuous FIFO accounting preserves origin, available/consumed/held/revoked seconds and minimal paid-controls-use flag. No peer identity, conversation ID, transcript or usage history is required for the flag. Expiry is rebuildable. |
| Duration adjustments and financial audit | Append-only restricted PostgreSQL | Ordered grant/consume/hold/restore/revoke/checkpoint events and guarded operator audit support corrections and rebuild. Runtime cannot arbitrarily UPDATE/DELETE history. Financial retention/purge approval remains required. |
| Refund/dispute/reconciliation records | Restricted PostgreSQL; audited billing roles | Stable request/provider references, paise, treatment, response deadlines and outcomes. Distinguish pending/provider processed from bank credit. Preserve unresolved obligations and applicable holds through account deletion and restore. |
| Verified webhook inbox | PostgreSQL minimal allowlisted projection | Store fingerprint, event kind, environment and financial references after signature verification; do not persist raw JSON, phone/email, signature headers or card/bank data. Business-level idempotency remains authoritative. |
| Leased payment jobs and restricted review cases | PostgreSQL; bounded workers/private billing | Recover expired leases; retain failed/unknown/duplicate/deleted-account exceptions until audited resolution. Defined operational/financial retention must cover completed jobs without deleting needed dedupe or ledger evidence. |
| Provider keys and webhook rotation secret | Protected owner-only server files and separately recoverable secret backups | No frontend values, source archives or database rows. Sandbox/live separation; previous verification secret has a finite expiry. Rotate through reviewed provider/application procedure. |

This financial extension does not implement the final Phase 9 legal retention/purge matrix. Do not invent a universal accounting period or delete financial references with ordinary profile data. Preserve required financial history in restricted pseudonymous references when approved erasure runs, and document purpose, legal basis, hold treatment and backup expiry. Restore must replay independent deletion tombstones and reconcile captures/refunds after the restored point before opening access.

The blueprint promises no user-accessible conversation history. This does not mean no security, payment or legally required records. This inventory is an engineering starting point, not a legal determination.

| Data | Implemented in Phase 1 | Store and purpose | Required lifecycle |
| --- | --- | --- | --- |
| Migration versions and foundation marker | Yes | PostgreSQL schema control; no user information | Keep while the deployment/schema exists. Reversible exercise uses a disposable local database. |
| Request IDs and operational events | Yes | Structured standard output with restricted operational fields | No message text, raw URLs/query strings, credentials, cookies or IPs in general access logs. Local container logs rotate; production retention is configured before launch. |
| Coordinator state | Skeleton only | Bounded process memory | Discard on shutdown; do not persist or simulate guest identities in Phase 1. |
| Development secrets | Yes, generated locally | Ignored files used by the local database and services | Unique to this checkout. Rotate/recreate deliberately; do not ship in the source archive. |
| Ordinary text and report drafts | No; later phases | Bounded RAM only under the approved baseline | 64 KiB/30-message interaction buffer; approved report-draft TTL and explicit end cleanup. No browser transcript cache. |
| Submitted report evidence | No; later phases | Restricted durable evidence, only when submitted | Apply the reviewed retention/deletion schedule and legal holds. |
| Accounts and friendships | No; later phases | PostgreSQL for registered identities/durable relationships; guest links remain ephemeral | Implement the finalized deletion, guest TTL and mutual-consent rules without forcing registration. |
| Payments and entitlements | No; later phases | Durable orders, attempts, immutable offers and entitlement/refund records | Financial retention and deletion pseudonymization require accountant/counsel approval. No card storage. |
| India security/ICT records | No dedicated archive yet | Restricted India-region security store | Blueprint requires 180-day applicable window; legal classification and production configuration remain launch gates. Do not mistake small local log rotation for compliance. |
| Recovery data and deletion/hold journals | No operational backup service yet | Encrypted India-region recovery storage | Blueprint target: 30-day database recovery data, 15-minute RPO and 4-hour staffed RTO, demonstrated before launch. |

Before adding a table, log field, cookie or storage key, record its purpose, access role, retention period, deletion behavior and backup treatment here. The privacy policy must match actual behavior. A future legal requirement that changes ordinary-content retention requires explicit architectural and notice review.


## Phase 3 additions (supersede the earlier implementation column)

| Data | Location / access | Lifecycle and backup treatment |
| --- | --- | --- |
| Guest profile, consent and secret verifier | Coordinator memory only | 30-minute idle / 24-hour absolute TTL; explicit end or process restart removes it. No guest SQL row or browser storage. |
| Account/password/recovery verifier | PostgreSQL; runtime read/create/update, no account DELETE | Password Argon2id and recovery verifier only; deletion disables immediately. Full purge waits for reviewed retention rules. Never back up raw recovery codes. |
| Public/private profile, controlled unique interests and version | PostgreSQL; self API only for private attributes | Whole state is version guarded; peer projection excludes private fields. Included in encrypted recovery backups until approved erasure schedule. |
| Consent events | PostgreSQL; runtime SELECT/INSERT only | Adult flag and exact policy versions with acceptance time, without DOB or raw IP. Retention and erasure approval pending. |
| Account session verifier | PostgreSQL; bounded ten live sessions/account | Seven days idle / thirty days absolute, explicit revocation and bounded pruning. No bearer cookie stored. |
| Deletion job and receipt verifier | PostgreSQL; no runtime DELETE | Disabled access with durability status; initial state awaiting_retention_review. Receipt secret shown only to requesting client. |
| Independent deletion tombstone | Dedicated 0700 volume, 0600 records, API only | Minimal internal account/deletion reference, generation and request time. Never roll back with the database; replay before identity access. Off-host encrypted replication/retention remain launch gates. |
| CSRF/bootstrap and rate limits | HttpOnly cookies plus process secret / bounded RAM buckets | No browser local/session storage. Bootstrap expires; process restart invalidates anonymous CSRF state. No raw source IP in access logs. |

No legal retention period is invented by this phase. Do not execute a permanent purge until the report/payment/security retention and hold decisions are approved. Deletion notice must accurately distinguish immediate access loss, pending durability and future erasure.

## Phase 4 additions

| Data | Location / access | Lifecycle and backup treatment |
| --- | --- | --- |
| Account matching preferences | PostgreSQL, owner-only GET/PATCH; runtime SELECT/INSERT/UPDATE | Versioned private choices; included in the same encrypted recovery/deletion review as profiles. No public peer projection. |
| Guest matching preferences | Coordinator memory | Guest expiry, deletion and restart remove them; no SQL or browser persistence. |
| One-use ticket verifier | Bounded transport memory | 60-second expiry or first consume; at most 400 total, two per session. Raw tickets exist only for delivery and browser RAM. |
| Connection/resume proof | Coordinator and browser RAM | Rotate on reconnect; discard on interaction expiry, teardown or process restart. Never log or cache in browser storage. |
| Waiting and interaction control state | One coordinator | At most 200 retained participants/100 waiting; matched disconnect grace 25 seconds. No text payload or history implemented. |
| Command dedupe and outbound events | Bounded per connection | 128 dedupe entries and 32 owner outbound events; replaced/closed connection purges its state. |
| Recent-pair controls | Bounded coordinator memory | Four-second hard cooldown, five-minute TTL, capped records; no durable browsing history. |

Registered preferences do not contain payment authority. The trusted entitlement snapshot and restriction versions stay server-private. Safety failure events use fixed log labels, not identities or submitted content.

## Phase 5 additions

This section supersedes the earlier “not implemented” entries for text, submitted safety material and minimum moderation. No ordinary-chat database table, persistent guest account, browser transcript cache, audio recording or device fingerprint is introduced.

| Data | Location / access | Implemented lifecycle and remaining retention work |
| --- | --- | --- |
| Ordinary text and sender receipts | Coordinator RAM and connected browser RAM | At most 30 recent messages/64 KiB per interaction; up to 16,384 content-free dedupe receipts in that epoch. Normal end, Next, Block, logout/deletion and reconnect expiry remove interaction content; process restart loses it. Purge queued ended-epoch text as well as the interaction buffer. |
| Report Begin snapshot | Bounded coordinator RAM; requester only | Hard two-minute expiry; at most 64 global drafts and two per identity, each within the normal buffer limit. Peer departure does not destroy a still-valid draft. Successful submission clears the frozen message snapshot; only a bounded receipt/digest supports same-request retry until expiry. |
| Ended-interaction reference | Coordinator RAM; opaque self-owned handle | Ten-minute hard expiry, at most 2,000 references; only participant/timing reference metadata, no transcript. Restart loses the reference; grievance route is the fallback. |
| Temporary blocks and restriction/promotion leases | Coordinator RAM, private safety owner | Guest-dependent references expire with the relevant guest or restart. Identity upgrades rebind the same slots; applicable account blocks/restrictions are durably finalized through guarded handoff/promotion work. Uncertain writes remain conservatively blocked. |
| Registered blocks and account safety state | PostgreSQL; self-owned block API and trusted matching authorization | Blocks persist across restart until authorized removal; either direction excludes contact. Restrictions expire at their explicit deadline or audited removal. Account deletion/retention handling remains subject to the approved erasure policy. |
| Pending registration safety fence | PostgreSQL account reference and creation time; trusted handoff worker | Created with the account transaction; cleared only with the authoritative block/restriction finalization. Orphaned fences after restart keep realtime unavailable pending private operator reconciliation; they do not automatically expire into unrestricted access. No transcript or guest profile is stored in this fence. |
| Report case and case-scoped subject mappings | Restricted PostgreSQL records | Category, initial severity/deadline, state/version, idempotency digests, `retention_until` and the applicable retention-policy version; case-specific speaker references. Guest mappings use random case-scoped tags, not a persistent guest profile or cross-case identifier. |
| Selected evidence, user allegation and interaction metadata | AES-256-GCM encrypted PostgreSQL evidence; authorized audited operator views | Only selected server messages are stored. Allegations and metadata have distinct types. Each record has a collection purpose, collection time, key ID, authenticated metadata including the retention-policy version, and retention deadline. Keys stay outside the database. |
| Moderation actions, notes and legal-hold foundations | Restricted PostgreSQL; append-only actions, guarded case updates | Immutable action records preserve corrections rather than erasing history. Notes/reasons are personal data. Hold tables exist; full approval/review/release and automated hold-aware purge are later work. |
| Operator identity, MFA and session verifier | Separate PostgreSQL admin tables; private listener | Encrypted TOTP secret with a separate MFA key; password/session verifiers only. Sessions expire after 15-minute idle/four-hour absolute limits; up to five retained per operator. Offline provisioning/lifecycle is authorized separately. |
| Sensitive-access and action audit | Restricted PostgreSQL; runtime SELECT/INSERT only | Actor, action, purpose/reason, scoped case reference, time and result; no ordinary-chat body. Every sensitive view must commit its audit before returning evidence. Approved audit retention and purge remain later scope. |
| Evidence and MFA keys | Protected host/secret mounts with independently recoverable backups | Never commit or place in source archives. Retain old evidence decrypt keys while data or recovery backups still require them; MFA key recovery is separate. Database-only restoration cannot recover missing keys. |

`CASE_RETENTION_DAYS` is explicit for deployed safety and writes case/evidence deadlines; the local default of 30 days is for synthetic testing. `CASE_RETENTION_POLICY_VERSION` identifies the operator's reviewed setting. Neither value establishes the applicable law or performs deletion. **Phase 5 has no automatic case/evidence purge worker.** Runtime grants deliberately exclude arbitrary evidence/action/audit deletion; Phase 9 must implement the reviewed retention/hold workflow and an appropriately scoped worker before public launch. Do not describe expired timestamps as already-erased records or leave production retention unenforced indefinitely.

Review operator notes, audit, encrypted evidence, case mappings, legal holds, pending deletion and all backup copies together. Restore drills must retain the independent deletion journal and required keys, and must not revive disabled access or lose durable safety restrictions. Disable core dumps and unencrypted swap; diagnostic tooling must not quietly create an alternate conversation archive. The approved privacy notice must state that ordinary text is server-readable and that deliberate report evidence is retained under its separate purpose and schedule.


## Phase 6 additions

This section supersedes earlier future-tense entries for friendships. It does not add ordinary conversation history, a public directory or an offline inbox.

| Data | Location / access | Lifecycle and backup treatment |
| --- | --- | --- |
| Stay Connected prompt and terminal suppression marker | Coordinator RAM; current interaction endpoints only | Acceptance, decline and withdrawal end the actionable prompt. A bounded terminal marker can remain until interaction end to prevent repeated prompts or refusal probing; the sender receives no explicit rejection. Reciprocal affirmative requests create one relationship. No durable request or rejection history. |
| Accepted guest-dependent relationship | Bounded coordinator RAM with normalized pair, two consent times, endpoint generations and reverse indexes | Survives conversation changes/refresh only while the original guest identity remains valid. Remove, Block, guest end/expiry or process restart purges both endpoint indexes and invalidates handles. Friends do not refresh guest TTL. |
| Durable account friendship | PostgreSQL; authenticated endpoints and trusted owner hydration only | Survives logout and server restart. Removed by authorized Remove, Block or account deletion; included in encrypted database recovery copies subject to the approved backup schedule and deletion replay. No private username is a public relationship handle. |
| Account friendship revision | PostgreSQL account field; guarded relationship/safety/deletion transactions | Monotonic stale-write fence, not relationship history. Remove, Block and deletion invalidate work captured under an older revision, including work delayed across a crash. The account-wide fence can invalidate unrelated unpublished consent; it does not remove unrelated durable friendships. Never rebase failed work onto a newer revision. |
| Guest-registration friendship promotion | Bounded owner mutation/lease state | Preserve consent while rebinding the same identity. Each newly registered endpoint waits for its first fresh authenticated authorization after safety handoff to capture a real revision; an already-account endpoint retains its consent revision. Closing before capture leaves the link pending until later authorization. After capture, active accounts may promote while offline/logged out, subject to revisions and safety. The link is not restart-durable until persistence succeeds. No transcript or guest profile is written to a retry queue. |
| Friend presence | Derived from current coordinator authorization and connection state | Exposed only to accepted, unblocked friends; no presence history, last-seen archive or offline notification service. The underlying guest lifetime still applies. |
| Online invitation | Coordinator RAM, opaque relationship and invitation handles | 30-second hard expiry; cleared on rejection/acceptance, disconnect/unavailability, removal, block, deletion or restart. No offline delivery or durable invitation table. |
| Browser friendship projection | Browser RAM and escaped UI | No local/session storage for friend lists, requests, invitations or presence. Clear stale views on identity change, invalidation and session end. |

Friendship backups retain only registered relationships. A database restore must replay the independent deletion journal and preserve safety constraints before friendship hydration; restoring a backup is not permission to revive deleted access. Account-level revisions reject delayed writes against the live database but are not, by themselves, an off-host backup reconciliation policy. Test the reviewed recovery procedure rather than treating revision numbers as a recovery guarantee.

## Phase 7 additions

Audio does not add an ordinary conversation archive. The media path forwards encrypted packets; it provides no recording or transcription service. Do not enable coturn diagnostic dumps, browser recording APIs, session replay, media packet capture or content-bearing crash reports in ordinary operation.

| Data | Location / access | Lifecycle and backup treatment |
| --- | --- | --- |
| Call consent, state and offer ownership | Bounded coordinator RAM, current interaction endpoints only | One outstanding request; ringing expires at 30 seconds. End, relevant interaction termination, authorization loss and restart end the call. A 15-second decline cooldown is a short control bound, not a durable rejection history. |
| Audio SDP and ICE | Transient browser/transport RAM under current accepted call and epoch | Validate before forwarding; no SQL, browser persistence, ordinary log, telemetry or backup copy. Clear ended call state and discard delayed signal frames. |
| Microphone stream and peer connection | Browser memory and native media engine | Created only after explicit Call/Accept and permission. Stop tracks and close the connection on local end, disconnect, invalidation or destruction; a delayed permission result must not revive a stopped call. No MediaRecorder, transcription or saved media. |
| TURN credentials | Browser RAM and trusted call service/supervisor RAM | Random call-specific endpoint usernames; ten-minute credential expiry, refresh at five minutes for a still-authorized accepted call. Never expose the shared signing secret or persist credentials in browser storage/logs. |
| Private call lease | Relay supervisor RAM with application-instance binding | Maximum 30-second renewable lease. Expiry, explicit revoke or lost trusted owner causes allocation cancellation. Restart begins untrusted and requires reconciliation before admitting work. No durable ordinary-call ledger. |
| Revoked username/allocation tracking | Bounded private supervisor RAM | Continue detecting and cancelling allocations created with revoked credentials until those credentials expire. Startup reconciliation clears pre-existing allocations; an empty RAM set after restart is not proof that old credentials are safe. |
| TURN allocation/control counters | Current relay state and authenticated private `/v1/metrics` | Active calls, revocation records, allocations, cancellation requests, control failures, last scan time and readiness; no usernames, peer addresses, call references, SDP or content labels. No persistent counter archive is created by the source. |
| Relay traffic/egress measurements | Aggregate host/provider counters and controlled acceptance measurements | Egress and timing are measured separately; the private control counters do not claim billed-byte or audio-quality measurement. Any historical aggregate retention belongs to the reviewed operations policy; no new public analytics provider. |
| TURN signing secret and CLI password | Supervisor RAM and mode0600 configuration in private relay tmpfs | Generated afresh on each relay-container boot; no durable backup. Restart destroys allocations and rotates these secrets so old credentials cannot authenticate. Never copy the generated file into diagnostics or source. |
| Private control token and TLS keys | Protected relay/application secret inputs | Outside source, frontend bundles and ordinary database backup. Rotate with controlled call teardown; protect required control/certificate recovery separately. They are distinct from the ephemeral TURN signing secret. |
| Latest accepted-call reference/timing | Existing bounded interaction, Report Begin snapshot and ended-reference RAM | Server-derived latest accepted call reference plus requested/accepted/ended times; no list of past calls, credential, SDP or media. A new pending/declined request does not replace the latest accepted call. Earlier accepted-call metadata cannot be retrieved once replaced. Report Begin freezes the available metadata with its existing two-minute draft; ended metadata follows the ten-minute ended-reference deadline. Ordinary interaction/restart cleanup still applies. |
| Submitted voice-related report | Existing encrypted `interaction_metadata` evidence, audited private case view | The latest accepted call reference/timing, user allegation and any selected related server-held text follow the existing submitted-report policy. Metadata is server-derived and stored only with a submitted case; no new call-history table or audio recording exists. The moderator receives a sanitized case projection after its access audit commits and cannot replay unrecorded audio. |

The application intentionally loses ordinary live-call state on restart. A database restore cannot reconstruct or resume a call. Recovery must prevent old allocations and credentials from regaining authorization; restoring a secret is not restoring call consent. Disable core dumps and unencrypted swap on both application and relay hosts. Temporary diagnostics require a reviewed scope and deletion plan and must not create a hidden production archive.

Retain only necessary aggregate resource/security evidence for the approved operating policy. Applicable security-log obligations do not justify adding ordinary media, raw SDP/ICE, credentials or unrestricted user traffic to logs. The blueprint's India-region security archive, deletion journal, case retention and Phase 9 purge/hold obligations remain separate launch requirements.

## Phase 9 operations and purpose-specific erasure

This section supersedes earlier statements that automated erasure/holds/support are future phases. The source adds guarded workflows; actual production approval and cloud lifecycle evidence remain required. Ordinary text/audio/guest lifecycle promises are unchanged.

| Data | Location and permitted access | Lifecycle |
| --- | --- | --- |
| Submitted grievance/privacy/appeal case | Restricted PostgreSQL case metadata; account owner or independent status capability | Original receipt, category/deadline policy and version history persist; human responses never expose internal notes. A case does not prove account/payment identity. |
| Submitted case subject/messages/notes | Purpose-bound encrypted rows; scoped audited operators, complainant-safe projection | Close-based approved cases rule and active holds; bounded worker clears expired ciphertext with purge audit. No attachments or ordinary transcript capture is added. |
| Case secret/submission verifiers | Hashes and minimal encrypted dedupe fingerprint in restricted records | Raw secret exists only in delivery/browser memory and optional user-chosen file. Preserve retry/status access; never place secret in URL/log/telemetry. |
| Legal deadline rules and in-app notice copy | Versioned reviewed DB rows, runtime read-only | Source/effective/review dates and approval are mandatory for deployed operation. New content/version requires review; no API role can publish legal policy. |
| Account notice delivery | Version, delivery/acknowledgement and next due in PostgreSQL | Approved quarterly reminder/account retention schedule. Guests receive current notice in RAM with no persistent guest notice history. |
| Notification work | Durable bounded attempts, lease, delivery/dead-letter/acknowledgement state | Fixed codes and opaque event references only outside restricted console. Notification failure never resets case receipt/deadline. Retain under the reviewed audit/case purpose, not forever by accident. |
| Hold history/projection | Fsynced independent hold journal plus append-only events/current DB projection | Reason, approver, review date and release event required. Missing replay stops purge; active holds survive review date until authorised release, while overdue review alerts. |
| Approved retention manifest | Protected host file plus immutable DB version/digest installed by the authorised migration-role workflow | Runtime only reads. Explicit finite min/max/trigger/source/effective/review dates cover registration, cases, financial, security logs, backups and metrics; storage region and legal/financial approvals required. |
| Deletion ordinary scrub | Restricted worker through narrow audited DB entrypoint | Immediate access disabled first. Approved scrub removes sessions/profiles/preferences/interests/friendships/blocks and invalidates credential material, preserving a closed inert account reference and required restricted records. It does not claim every record/backup erased. |
| Restricted registration | Purpose-specific restricted record, runtime SELECT only | Reviewed cancellation-triggered statutory preservation; contains minimum registration/cancellation facts without biography, professional data, password/recovery material or conversation. Purge after its approved bound absent holds. |
| Financial records | Existing restricted attempts/orders/lots/adjustments/refunds/disputes/reconciliation | Account deletion leaves obligations intact. Final-activity-triggered financial erasure requires approved schedule plus explicit authorised operator job and no open obligations/holds. No financial DELETE is granted to ordinary runtime SQL. |
| Self export | Allowlisted response following current account/recent authentication | Own profile, consent and purchases only; no peers/reporter identities/verifiers/evidence. Response is no-store. Larger/exceptional requests follow restricted privacy case verification. |
| Closed-account receipt | Saved independent deletion receipt proves original account; exact purchase lookup | Required retained receipt can be obtained without reactivating account. Complaint token, screenshot or amount cannot substitute for this proof. |
| Evidence export | Two-minute, one-use, operator/session-bound encrypted RAM bundle; key shown separately | RAM bounded and cleared on expiry/logout/shutdown. A downloaded copy follows case purpose/hold/expiry and approved offline access; expiry cannot remotely erase saved files. |
| Operational metrics | Fixed global hourly PostgreSQL aggregates plus current bounded RAM counters | Initial 13-month bound, adjusted only through reviewed metrics policy; no user/demographic dimensions. Missing measurements are unavailable, not zero. |
| Security archive / recovery | Client-encrypted approved log segments, base+WAL and separate journal copies in India object storage | Security rolling minimum 180 days subject to current applicable law; independently reviewed finite maxima/holds. Database recovery window initially 30 days plus required earlier base/WAL chain. Purpose lifecycles must not delete independent journals. |

The reviewed security-log rule also bounds SQL administrator audit retention. Its narrow database expiry entrypoint rechecks the current approved policy, actual clock and relevant active holds; runtime credentials still have no generic audit DELETE privilege. Expiry records a content-free purge audit. An archive lifecycle does not silently erase or extend unrelated SQL records.

The reference source templates schedule security current-version expiration after 181 days and noncurrent-version removal one day later, subject to day-boundary rounding and provider processing. Monitor actual removal and approve the resulting maximum; a lifecycle timestamp is not proof of erasure. This setting is not applied to journals or financial data. A 30-day recovery window may require an older weekly full backup. Document the resulting maximum retained age and restore re-erasure procedure accurately.

Purge audit records remain minimal and restricted. Account references, reasons and case/payment references are still sensitive pseudonymous data, not automatically anonymous. The legal review must govern retained linkage/audit metadata as well as ciphertext. An active hold may extend a normal maximum, but needs periodic authorised review. No unset field permits indefinite retention.

Source sealing does not upload any user data or prove off-host durability. Do not acknowledge complete recoverable erasure until the exact independent deletion record is verified off-host. See deploy/operations/README.md and phase9-legal-matrix.md for legal/effective-date and recovery gates.
