# Final environment, secrets and provisioning reference

This reference describes the cumulative Phase 1–10 source, **database schema 9**, and the supplied deployment templates. It inventories **73 application environment settings**, **70 distinct host Compose interpolation variables**, **four public frontend build controls**, one Vite development proxy setting, and the separate relay/build/test controls. A name can appear in more than one inventory because a host path and its container path have different meanings.

The application is a mobile-first, desktop-compatible adult conversation service with guest/account identities, shared matching, ephemeral text, reports/blocks, mutual connections, online friend invitations, relay-only audio, prepaid Premium and protected operations. This reference changes no business rule, matching rule, role, plan, retention approval or workflow. Keep one authoritative API process. The required baseline remains **200 connected users, at most 100 waiting, and 25 concurrent two-person calls**, with overlapping connected subsets; it is an acceptance target, not a demonstrated result or an environment-tunable downgrade.

No production credentials, certificates, merchant approval, policy approval, launch permit or passing runtime evidence are included. Authentic dependency locks, the Go/Docker/PostgreSQL/browser suites, real relay tests, both six-hour capacity workloads, backup restoration and authorized live-money acceptance must be completed on the release infrastructure. Read [PHASE10_STATUS.md](../PHASE10_STATUS.md), [configuration.md](configuration.md), [phase10-deployment.md](phase10-deployment.md), [phase10-acceptance.md](phase10-acceptance.md) and the relevant feature runbooks alongside this file.

## 1. Which configuration belongs where

| Layer | Where supplied | Meaning and restart behavior |
| --- | --- | --- |
| Application settings | Explicit `environment:` in Compose, or the direct Go process environment | Parsed by `server/internal/config`. Changing a host `.env` alone does not pass an unlisted setting through Compose. Recreate the API to apply startup changes; perform the documented drain first. |
| Host Compose inputs | Protected operator file passed with `docker compose --env-file /protected/release.env` | Image references, public values and absolute **host** file/directory paths. Compose interpolates these before containers exist. Do not put secret contents in this file. |
| Container file settings | `DATABASE_URL_FILE`, key paths, policy path and other API `_FILE` settings | Paths visible **inside** the container. Host paths and container paths need not match. The tables below distinguish them. |
| Public frontend controls | Docker `--build-arg` / build-process environment | Embedded in the static artifact and CSP. They are public, never secret. Runtime Caddy variables cannot change the bundle; rebuild when these change. |
| Public legal and commercial content | `web/config/release.json`, `web/config/plans.json`, reviewed public page source | Actual operator/grievance details, policy versions, approved disclosure/tax decisions and the four fixed plans. These are reviewed content, not secret environment variables. Production checks bind the content digest. |
| Durable policy/catalog versions | Reviewed data-publication SQL under migration-role authority; offline `adminctl` policy install | Publish new immutable approved rows while preserving schema 9. Runtime credentials cannot publish approvals, rewrite immutable prices, or grant themselves policy authority. An actual schema migration beyond 9 requires coordinated code/evidence updates. |
| Host operations | Protected observer inputs, pgBackRest config, archive credentials, systemd units and firewall/provider settings | Separate from the application. No cloud archive/backup credentials or host shell are mounted into the API. |

Use the same project name, protected environment file and ordered Compose files for every operation. Relative Compose paths resolve from the first file: use absolute host paths for operator inputs. `DATABASE_URL_FILE=/run/secrets/runtime_database_url` in the API is populated from host `RUNTIME_DATABASE_URL_FILE`; they are deliberately different names.

All application environment values are strings. In the following tables, **bool** means lowercase `true` or `false`; most flags trim surrounding whitespace, but use exact values everywhere. **Duration** means a positive Go duration such as `5s`, `1m` or `30m`, not an unqualified number. **Path** means an absolute clean container path in a deployed configuration. “None” means no supplied default. “Local” means `development` or `test`; “deployed” means `staging` or `production`. A disabled feature can skip parsing its dependent fields; that is not proof those fields are valid for later enablement.

## 2. Application variables: all 73 settings

### Base service and database: 20

| Variable | Type / loader default | When required, accepted bounds and purpose |
| --- | --- | --- |
| `APP_ENV` | enum / `development` | `development`, `test`, `staging`, `production`. Determines secure origins, defaults and provider environment. Base production Compose fixes `production`; staging overlay changes it to `staging`. |
| `PUBLIC_ORIGIN` | origin / `http://localhost:5173` | No credentials, path, query or fragment. HTTPS in deployed environments. Must match frontend build origin and Caddy host. Production Compose derives it from `APP_DOMAIN`. |
| `LOG_LEVEL` | enum / `debug` in development; `info` otherwise | `debug`, `info`, `warn`, `error`. Supplied Compose uses `info`. Logs must still exclude content and credentials. |
| `HTTP_ADDR` | host:port / `:8080` | Numeric port 1–65535. Production exposes this only on the Docker edge network, never a host public port. |
| `DATABASE_URL` | **secret value** / none | Development/test alternative only. PostgreSQL URI with user, host and database; mutually exclusive with `_FILE`. Forbidden in staging/production. Prefer files locally too. |
| `DATABASE_URL_FILE` | secret **path** / none | Required deployed. Regular, nonempty file, at most 64 KiB, containing one PostgreSQL URI. Runtime uses `notitle_app`; migrations use their separate role/file. Production host mapping is `RUNTIME_DATABASE_URL_FILE`. |
| `DB_MAX_CONNS` | integer / `8` | 1–20. Planning baseline 8 against PostgreSQL `max_connections=40`; raising this is not a capacity solution. |
| `DB_MIN_CONNS` | integer / `0` | 0 through `DB_MAX_CONNS`. |
| `HTTP_READ_HEADER_TIMEOUT` | duration / `5s` | Maximum `1m`; must not exceed read timeout. |
| `HTTP_READ_TIMEOUT` | duration / `15s` | Maximum `2m`. |
| `HTTP_WRITE_TIMEOUT` | duration / `15s` | Maximum `2m`; must exceed DB readiness timeout. |
| `HTTP_IDLE_TIMEOUT` | duration / `1m` | Maximum `5m`. |
| `HTTP_SHUTDOWN_TIMEOUT` | duration / `15s` | Maximum `1m`; this transport shutdown timeout does not replace the separate maximum 120-second admission drain. |
| `DB_MAX_CONN_LIFETIME` | duration / `30m` | Maximum `24h`. |
| `DB_MAX_CONN_IDLE_TIME` | duration / `5m` | Maximum `1h`. |
| `DB_HEALTHCHECK_PERIOD` | duration / `1m` | Maximum `5m`. |
| `DB_CONNECT_TIMEOUT` | duration / `10s` | Maximum `1m`. |
| `DB_READINESS_TIMEOUT` | duration / `1s` | Maximum `5s`; strictly shorter than HTTP write timeout. |
| `HTTP_MAX_HEADER_BYTES` | bytes / `16384` | 1024–1048576; route-specific limits still apply. |
| `HTTP_MAX_BODY_BYTES` | bytes / `65536` | 1024–1048576; not a transcript, upload or unlimited WebSocket allowance. |

The supplied single-host bridge uses SCRAM passwords and no published database port. A same-host bridge DSN can use the reviewed `sslmode=disable` setting; any database moved across hosts requires certificate-verified TLS and an updated deployment review. URI-encode password characters when provisioning DSNs; never concatenate arbitrary secret text into shell commands. Initial-role passwords are consumed when PostgreSQL initializes an empty volume: changing a password file later does not rotate the existing database role.

### Identity and shared realtime: 6

| Variable | Type / loader default | When required, accepted bounds and purpose |
| --- | --- | --- |
| `IDENTITY_ENABLED` | bool / local `true`, deployed `false` | Gates guest/account foundation. Production base explicitly defaults off. |
| `DELETION_TOMBSTONE_DIR` | directory path / `/var/lib/notitle/tombstones` | Required with identity; independent durable directory, API UID/GID 65532, mode 0700. Deployed journal must exist and replay successfully. Preserve independently of PostgreSQL restore. |
| `TERMS_VERSION` | policy ID / local `draft-phase3-v1`; deployed none | Required with identity; 1–64 ASCII letters/digits/dot/underscore/hyphen, starting alphanumeric. Deployed value must not start with `draft` and must match reviewed public terms. |
| `PRIVACY_VERSION` | policy ID / local `draft-phase3-v1`; deployed none | Same validation; reviewed public privacy version. |
| `COMMUNITY_VERSION` | policy ID / local `draft-phase3-v1`; deployed none | Same validation; reviewed community-rules version. |
| `REALTIME_ENABLED` | bool / local on if identity on; deployed `false` | Requires identity. One shared in-process matching owner, same-origin `/ws`; no Redis or extra realtime service. |

### Safety, private administration and friends: 11

| Variable | Type / loader default | When required, accepted bounds and purpose |
| --- | --- | --- |
| `SAFETY_ENABLED` | bool / local on if realtime on; deployed `false` | Requires realtime. Deployed safety also requires private admin and actual moderation coverage. |
| `ADMIN_ENABLED` | bool / local on if safety on; deployed `false` | Requires safety; separate private listener. No default administrator is created. |
| `EVIDENCE_KEYRING_FILE` | secret path / `/run/secrets/evidence_keyring` | Required with safety. Selected-report evidence AES-256 keyring; separate from MFA and operations-case keys. |
| `CASE_RETENTION_DAYS` | integer / local `30` | 1–3650. Must be explicitly set for deployed safety after retention review. Existing evidence obligations/minima persist; Phase 9 closure-based policy is separately approved. |
| `CASE_RETENTION_POLICY_VERSION` | policy ID / `draft-phase5-local` | Deployed safety requires a reviewed, valid non-draft policy ID; this setting is not the complete Phase 9 manifest. |
| `MODERATION_COVERAGE_CONFIRMED` | assertion / unset | Deployed safety requires the exact string `true` after real primary/backup coverage exists. Does not appoint staff. |
| `ADMIN_ADDR` | host:port / `127.0.0.1:9090` | Required with admin. Compose uses `:9090` **inside** the container but publishes only host `127.0.0.1:ADMIN_PORT`. Must differ from public listener. |
| `ADMIN_ORIGIN` | origin / local `http://localhost:9090`; deployed none | Required with admin. Deployed HTTPS on a distinct hostname for cookie isolation, behind the operator VPN/access gateway. Never route through public Caddy. |
| `ADMIN_MFA_KEY_FILE` | secret path / `/run/secrets/admin_mfa_key` | Required with admin; one independent base64-encoded 32-byte key. Must differ from evidence key path. |
| `FRIENDS_ENABLED` | bool / local on if safety on; deployed `false` | Requires safety. Same matching owner and durable account friendships; guest connections remain temporary. |
| `FRIENDS_PER_IDENTITY` | integer / `100` | 1–100, parsed even when friends are disabled. Lowering restricts new admissions; it does not delete committed relationships. |

### Audio control: 9

| Variable | Type / loader default | When required, accepted bounds and purpose |
| --- | --- | --- |
| `AUDIO_ENABLED` | bool / `false` | Requires safety, healthy authenticated relay synchronization and later runtime readiness. Supplied audio overlay sets `true`; base stacks keep it off. |
| `AUDIO_SAFETY_VERIFIED` | bool / `false` | Production enabled audio requires actual relay/device/revocation/capacity acceptance before `true`. No test is executed by the flag. |
| `AUDIO_ALLOW_LOOPBACK_HTTP` | bool / `false` | Fixture only: development/test and literal `127.0.0.1` or `::1`. Forbidden for deployed enabled audio. Supplied overlay fixes `false`. |
| `AUDIO_CONTROL_URL` | private origin / none | Required with audio. HTTPS, no credentials/path/query/fragment. Certificate SAN must match this private DNS name or IP; port normally 9443. Independent of public TURN address. |
| `AUDIO_CONTROL_TOKEN_FILE` | secret path / none | Required with audio; 64 hexadecimal characters encoding 32 random bytes. Must agree with relay token. |
| `AUDIO_CONTROL_CA_FILE` | certificate path / none | Required for HTTPS audio control; trusted private server CA in PEM. |
| `AUDIO_CONTROL_CLIENT_CERT_FILE` | certificate path / none | Required for HTTPS; PEM app client certificate with clientAuth usage. |
| `AUDIO_CONTROL_CLIENT_KEY_FILE` | private-key path / none | Required for HTTPS; PEM key for app client certificate, protected owner-only file; distinct from other control files. |
| `AUDIO_RELAY_ADDRESSES` | comma-separated public IPs / none | Required with audio. 1–8 distinct approved literal IPv4/IPv6 addresses; no DNS names/CIDRs/private ranges. Exact SDP/ICE relay allowlist. Supplied supervisor deployment uses one public IPv4. |

### Payment processing and checkout: 11

| Variable | Type / loader default | When required, accepted bounds and purpose |
| --- | --- | --- |
| `PAYMENTS_ENABLED` | bool / `false` | Requires identity, safety and private admin. Enables signed webhook/worker processing. Keep processing enabled for existing financial obligations. |
| `CHECKOUT_ENABLED` | bool / `false` | Requires payments. Separate switch for new/resumed checkout; maintenance also closes purchase admission without discarding committed obligations. |
| `PAYMENT_MERCHANT_APPROVED` | bool / `false` | Production processing requires `true` only after written acceptance of the actual product by the merchant provider. |
| `PAYMENT_POLICY_APPROVED` | bool / `false` | Production processing requires actual tax, receipt, contact and refund review. |
| `PAYMENT_ANNUAL_APPROVED` | bool / `false` | Additional annual economics/later-refund gate. Does not enable the immutable database catalog or public offer by itself. |
| `PAYMENT_ENVIRONMENT` | enum / `sandbox`, except production `production` | Must be `production` exactly when `APP_ENV=production`; otherwise `sandbox`. Cross-environment values fail configuration even if payments are disabled. |
| `PAYMENT_MERCHANT_ID` | scoped ID / `unconfigured` | Enabled payments require the actual identifier, at most 128 characters, without whitespace, slash or backslash. Not a browser credential. |
| `CASHFREE_CLIENT_ID_FILE` | secret path / none | Required with payments; private raw provider identifier file, separate from client secret. |
| `CASHFREE_CLIENT_SECRET_FILE` | secret path / none | Required with payments; private raw provider secret file. |
| `CASHFREE_PREVIOUS_SECRET_FILE` | secret path / none | Optional distinct previous verification secret, only for bounded rotation; must accompany deadline. Host overlay input has the different name `CASHFREE_PREVIOUS_SECRET_CONTAINER_FILE`. |
| `CASHFREE_PREVIOUS_SECRET_UNTIL` | RFC3339 instant / none | Required iff previous secret is present. Future, no more than 24 hours from process start; previous verification stops at the deadline. Remove both settings and retired file after overlap. |

The inline names `CASHFREE_CLIENT_ID`, `CASHFREE_CLIENT_SECRET` and `CASHFREE_PREVIOUS_SECRET` are forbidden credential alternatives, not valid substitutes. The backend has one implemented provider: Cashfree hosted checkout. A browser redirect, SDK callback, source flag or database expiry edit cannot grant Premium. Plans remain the finalized INR prepaid offers: 72 hours ₹99, 168 hours ₹199, 720 hours ₹499 and 8760 hours ₹1499, with no automatic renewal; annual activation has separate gates. All consumer totals/tax treatment require the actual reviewed catalog and disclosures.

### Operations, privacy and observations: 11

| Variable | Type / loader default | When required, accepted bounds and purpose |
| --- | --- | --- |
| `OPERATIONS_ENABLED` | bool / `false` | Requires identity, safety and private admin. Overlay sets `true` only when reviewed controls are provisioned. |
| `OPERATIONS_COVERAGE_APPROVED` | bool / `false` | Deployed operations require reviewed primary/backup coverage and delivery drills, not just a truthy setting. |
| `OPERATIONS_KEYRING_FILE` | secret path / none | Required with operations. Separate AES-256 operations-case keyring; must not share evidence/MFA key material. |
| `RETENTION_POLICY_FILE` | protected JSON path / none | Required with operations. Exact approved current manifest also installed immutably in the database; draft example does not establish readiness. |
| `HOLD_JOURNAL_DIR` | durable directory path / none | Required with operations. Independent owner-only journal, separate from deletion journal and PostgreSQL data, retained across restores. |
| `OPERATIONS_OBSERVATION_FILE` | protected JSON path / none | Required deployed; local optional. Fresh trusted measured observation, atomically published through a directory bind. Missing/stale evidence does not become healthy by rewriting a timestamp. |
| `OPERATIONS_ALERT_PRIMARY_TOKEN_FILE` | secret path / none | Required with primary URL; deployed operations require both channels. Private raw token; separate from backup token. |
| `OPERATIONS_ALERT_BACKUP_TOKEN_FILE` | secret path / none | Required with backup URL; distinct credential and destination. |
| `OPERATIONS_ALERT_PRIMARY_URL` | HTTPS URL / none | Deployed required. Exact approved public DNS receiver, port 443, at most 1024 characters; path allowed, no credentials/query/fragment. Runtime DNS/dial checks reject private/metadata destinations. |
| `OPERATIONS_ALERT_BACKUP_URL` | HTTPS URL / none | Same restrictions; must differ from primary. Delivery receipt is not human acknowledgement. |
| `OPERATIONS_COVERAGE_REFERENCE` | evidence reference / none | Deployed required: 5–200 characters, no CR/LF/NUL. References actual roster/drills; avoid contact details in environment. |

The inline names `OPERATIONS_ALERT_PRIMARY_TOKEN` and `OPERATIONS_ALERT_BACKUP_TOKEN` are rejected. These receivers notify appointed operators; they do not introduce an outgoing user-email service. Keep the separately published incoming legal/grievance contact monitored.

### Startup maintenance and release admission: 5

| Variable | Type / loader default | When required, accepted bounds and purpose |
| --- | --- | --- |
| `MAINTENANCE_MODE` | bool / `false` in loader | **Production requires explicit `true` at every process start**. Production base fixes `true`; staging overlay inherits it even though standalone staging loader default is false. An owner action opens the running owner after checks. |
| `LAUNCH_STAGE` | enum / `validation` | `validation`, `cohort`, `public`. Must agree with deployment manifest and ingress stage. `maintenance` is a Caddy stage, not an API `LAUNCH_STAGE` value. |
| `LAUNCH_APPROVAL_FILE` | protected JSON path / none | Not needed to boot closed; required for production owner opening. Base maps `/var/lib/notitle/launch/approval.json` from `LAUNCH_APPROVAL_DIRECTORY`. Never create a permissive fixture. |
| `DEPLOYED_API_IMAGE` | OCI digest reference / none | Production opening compares exact API image reference to permit. Base derives it from `NOTITLE_API_IMAGE`; actual running digest must also be verified by operator. |
| `DEPLOYMENT_MANIFEST_SHA256` | 64 lowercase hex / none | Exact reviewed deployment manifest digest. Validator excludes this environment claim from its canonical Compose preimage only, avoiding self-reference. Changes to other effective settings require new evidence binding. |

Production opening requires private owner MFA, current readiness and the protected source/image/origin/schema/manifest-bound permit. Validation permits are at most two hours, require the source-restricted authenticated validation stage and all pre-live gates, and automatically drain on expiry. They separately require prior bounded live-money authorization; they never authorize arbitrary payments. Full launch permits are at most 24 hours and require all gates. Their expiry limits a later opening action; it does not impose daily reapproval or terminate a healthy already-approved service. A new process always starts closed.

Private `POST /operations/admission` accepts the documented CSRF-protected `open` or `drain` action; use the private operator UI rather than embedding session cookies in scripts. Drain is serialized by the matching owner for at most 120 seconds. It pauses new search/invites/call consent/purchases while accepted text/audio can finish; at deadline it ends interactions and revokes audio. Support/privacy, reports/blocks/end controls, signed provider callbacks and committed billing work remain available when their dependencies are healthy. The admission gate is independent of Caddy ingress. See [phase10-deployment.md](phase10-deployment.md) for stage changes and orderly replacement of the single owner.

## 3. Host Compose interpolation: all 70 distinct names

These are names read by `${...}` in the supplied Compose files, not an instruction to export every value into every container. Blank required fields cause interpolation/startup rejection. Paths in this table are **host paths** unless explicitly marked container path. `production` below means `deploy/production/compose.yml`; optional overlay names refer to `deploy/<name>/compose.app.yml`.

| Host variable | Default / requirement | Consumer or mapping |
| --- | --- | --- |
| `APP_DOMAIN` | Required production/staging | Actual DNS hostname, no scheme/path; becomes Caddy `APP_ADDRESS` and API/web `PUBLIC_ORIGIN=https://...`. |
| `NOTITLE_POSTGRES_IMAGE` | Required | Reviewed PostgreSQL 18.6 compatible `registry/path@sha256:...`; backup-capable image must be deliberately built/verified. |
| `NOTITLE_API_IMAGE` | Required | Reviewed API digest; also sets `DEPLOYED_API_IMAGE`. |
| `NOTITLE_WEB_IMAGE` | Required | Reviewed Caddy/static digest built for exact mode/origin. |
| `NOTITLE_MIGRATION_IMAGE` | Required | Reviewed dedicated migration image digest. |
| `NOTITLE_TURN_IMAGE` | Required on relay host | Reviewed coturn/supervisor digest; relay Compose never builds in production. |
| `POSTGRES_ADMIN_PASSWORD_FILE` | Required file | Mounted as PostgreSQL `/run/secrets/postgres_admin_password`. |
| `POSTGRES_MIGRATION_PASSWORD_FILE` | Required file | Mounted as `/run/secrets/postgres_migration_password`; initializes `notitle_migrate`. |
| `POSTGRES_RUNTIME_PASSWORD_FILE` | Required file | Mounted as `/run/secrets/postgres_runtime_password`; initializes `notitle_app`. |
| `MIGRATION_DATABASE_URL_FILE` | Required file | Migrator `/run/secrets/migration_database_url`; never mount into the ordinary API. |
| `RUNTIME_DATABASE_URL_FILE` | Required file | API `/run/secrets/runtime_database_url`. |
| `EVIDENCE_KEYRING_FILE` | Required file in production template even while feature off | API `/run/secrets/evidence_keyring`; host path must be readable as mounted by UID 65532. |
| `ADMIN_MFA_KEY_FILE` | Required file in production template even while feature off | API `/run/secrets/admin_mfa_key`; independent key. |
| `LAUNCH_APPROVAL_DIRECTORY` | Required protected directory | Read-only API `/var/lib/notitle/launch`. Directory can initially contain no permit. |
| `ORIGIN_TLS_DIRECTORY` | Required protected directory | Read-only Caddy `/run/notitle-origin`, containing origin PKI and stage-specific files below. |
| `ORIGIN_AUTH_SCOPE` | Empty default; production requires `zone` | Assertion of verified zone-specific authenticated origin pulls. |
| `LAUNCH_STAGE` | `validation` | API stage; matches reviewed effective deployment. |
| `NOTITLE_LAUNCH_STAGE` | `maintenance` | Production Caddy `maintenance`, `validation`, `cohort`, `public`. Validation additionally restricts source CIDRs and Basic Auth. |
| `DEPLOYMENT_MANIFEST_SHA256` | Empty until actual manifest exists | Forwarded to API; needed for production opening. |
| `COHORT_USERNAME` | Empty; required validation/cohort | 1–64 ASCII letters/digits/underscore/hyphen. Password hash is a file, not this variable. |
| `VALIDATION_SOURCE_CIDRS` | Empty; required validation ingress | Whitespace-separated actual operator source CIDRs; verifier allows 1–32, IPv4 /24–/32 or IPv6 /64–/128. No unrestricted ranges. |
| `ADMIN_PORT` | `9090` | Host-loopback published private admin port in dev/production. |
| `ADMIN_ORIGIN` | Empty; required enabled deployed admin | Actual separate private HTTPS origin. |
| `IDENTITY_ENABLED` | `false` | Production API feature flag. |
| `REALTIME_ENABLED` | `false` | Production API feature flag. |
| `SAFETY_ENABLED` | `false` | Production API feature flag. |
| `ADMIN_ENABLED` | `false` | Production API feature flag. |
| `FRIENDS_ENABLED` | `false` | Production API feature flag. |
| `FRIENDS_PER_IDENTITY` | `100` | Forwarded API bound. |
| `TERMS_VERSION` | Empty; required enabled identity | Reviewed version ID, not policy prose. |
| `PRIVACY_VERSION` | Empty; required enabled identity | Reviewed version ID. |
| `COMMUNITY_VERSION` | Empty; required enabled identity | Reviewed version ID. |
| `CASE_RETENTION_DAYS` | Empty; required enabled safety | Reviewed integer. |
| `CASE_RETENTION_POLICY_VERSION` | Empty; required enabled safety | Reviewed non-draft version. |
| `MODERATION_COVERAGE_CONFIRMED` | `false` | Required `true` only after real coverage. |
| `AUDIO_SAFETY_VERIFIED` | `false` in audio overlay | Production acceptance assertion. |
| `AUDIO_CONTROL_URL` | Required audio overlay | Private HTTPS supervisor origin. |
| `AUDIO_RELAY_ADDRESSES` | Required audio overlay | Comma-separated approved public literals. |
| `AUDIO_CONTROL_TOKEN_FILE` | Required host file in audio overlay | API `/run/secrets/audio_control_token`. |
| `AUDIO_CONTROL_CA_FILE` | Required host file in audio overlay | API `/run/secrets/audio_control_ca`. |
| `AUDIO_CONTROL_CLIENT_CERT_FILE` | Required host file in audio overlay | API `/run/secrets/audio_control_client_cert`. |
| `AUDIO_CONTROL_CLIENT_KEY_FILE` | Required host file in audio overlay | API `/run/secrets/audio_control_client_key`. |
| `PAYMENT_SECRET_DIRECTORY` | Required payment overlay directory | API read-only `/var/lib/notitle/payment-keys`. |
| `CHECKOUT_ENABLED` | `false` in payment overlay | New checkout admission only; overlay fixes payment processing on. |
| `PAYMENT_ENVIRONMENT` | Required payment overlay | `sandbox` or `production`, matching `APP_ENV`. |
| `PAYMENT_MERCHANT_ID` | Required payment overlay | Actual merchant scope. |
| `PAYMENT_MERCHANT_APPROVED` | `false` | Forwarded payment assertion. |
| `PAYMENT_POLICY_APPROVED` | `false` | Forwarded payment assertion. |
| `PAYMENT_ANNUAL_APPROVED` | `false` | Forwarded independent annual assertion. |
| `CASHFREE_PREVIOUS_SECRET_CONTAINER_FILE` | Empty | **Container path**, normally `/var/lib/notitle/payment-keys/previous_secret`, not a host file path. Maps to API `CASHFREE_PREVIOUS_SECRET_FILE`. |
| `CASHFREE_PREVIOUS_SECRET_UNTIL` | Empty | Matching bounded rotation deadline. |
| `OPERATIONS_SECRET_DIRECTORY` | Required operations overlay directory | API read-only `/var/lib/notitle/operations-keys`. |
| `HOLD_JOURNAL_DIRECTORY` | Required operations overlay directory | API writable `/var/lib/notitle/holds`; host UID 65532 and mode 0700. |
| `OPERATIONS_OBSERVATION_DIRECTORY` | Required operations overlay directory | API read-only `/var/lib/notitle/observations`; collector publishes `current.json` atomically. |
| `OPERATIONS_COVERAGE_APPROVED` | `false` | Forwarded actual coverage assertion. |
| `OPERATIONS_COVERAGE_REFERENCE` | Required operations overlay | Reviewed roster/drill reference. |
| `OPERATIONS_ALERT_PRIMARY_URL` | Required operations overlay | Approved primary receiver URL. |
| `OPERATIONS_ALERT_BACKUP_URL` | Required operations overlay | Distinct approved backup receiver URL. |
| `STAGING_USERNAME` | Required staging overlay | 1–64 simple ASCII username for staging ingress. |
| `STAGING_PASSWORD_HASH_FILE` | Required staging host file | Caddy `/run/secrets/staging_password_hash`; one bcrypt hash. |
| `TURN_HOSTNAME` | Required relay Compose | DNS-only public TURN hostname covered by publicly trusted certificate. |
| `TURN_PUBLIC_IP` | Required relay Compose | Actual global-unicast public IPv4. |
| `TURN_RELAY_IP` | Required relay Compose | Actual host-interface IPv4; can equal public IP without NAT. |
| `RELAY_CONTROL_ADDR` | Required relay Compose | Private host IPv4 and port 9443; restrict inbound to app private IP. |
| `RELAY_SECRETS_DIR` | Required relay directory | Relay read-only `/run/secrets`. |
| `DEV_WEB_PORT` | `5173` | Fast-development host-loopback web port. |
| `DEV_PUBLIC_ORIGIN` | `http://localhost:5173` | Dev API origin; change together with dev web port. |
| `STATIC_WEB_PORT` | `8080` | Static local-preview host-loopback web port. |
| `STATIC_PUBLIC_ORIGIN` | `http://localhost:8080` | Static-preview API origin; change with static port. |
| `ADMIN_PUBLIC_ORIGIN` | `http://localhost:9090` | Development mapping to API `ADMIN_ORIGIN`; change with private dev port. |

The base template fixes `AUDIO_ENABLED`, `PAYMENTS_ENABLED`, `CHECKOUT_ENABLED` and `OPERATIONS_ENABLED` to `false`; setting a host environment value with one of those names does not override a literal YAML value. Apply the reviewed audio/payments/operations overlays. They add controls to the existing API, not extra application services. A reviewed explicit Compose override is needed for other application knobs absent from the interpolation list; include the resulting effective configuration in the deployment manifest.

PostgreSQL container constants are `POSTGRES_DB=notitle`, `POSTGRES_USER=notitle_bootstrap`, `PGDATA=/var/lib/postgresql/18/docker`, `TZ=UTC`, `PGTZ=UTC`, `POSTGRES_INITDB_ARGS=--auth-host=scram-sha-256`. Its script receives file paths via `POSTGRES_PASSWORD_FILE`, `POSTGRES_MIGRATION_PASSWORD_FILE` and `POSTGRES_APP_PASSWORD_FILE`; the last maps from host `POSTGRES_RUNTIME_PASSWORD_FILE`. Database data mounts at `/var/lib/postgresql`. These are container implementation settings, not additional host substitutions.

## 4. Frontend, image-build and relay process controls

### Public frontend build: four controls, plus one development proxy

| Variable | Default | Use |
| --- | --- | --- |
| `PUBLIC_RELEASE_MODE` | `preview` | `preview`, `staging`, `production`; production requires complete reviewed content and matching digest. |
| `PUBLIC_SITE_ORIGIN` | Empty | Preview can omit it. Staging/production require actual normalized HTTPS DNS origin with no port/path/query/credentials; reserved/example/local/IP hosts are rejected. |
| `PUBLIC_CHECKOUT_SDK_ENABLED` | `false` | Exact bool. `true` adds the controlled Cashfree SDK/CSP origins at build time. Backend checkout still requires independent permission/readiness. |
| `PUBLIC_CHECKOUT_ENVIRONMENT` | Docker build default `sandbox`; explicitly required by loader when SDK enabled | `sandbox` or `production`; production build with enabled SDK requires `production`. Processing-only builds can omit SDK. |
| `VITE_API_TARGET` | `http://127.0.0.1:8080` | Development proxy only; fast Compose sets `http://api:8080`. Production uses Caddy same-origin API/WebSocket proxy, not an exposed cross-origin backend URL. |

Frontend runtime inputs consumed by the Caddy entrypoint are `NOTITLE_DEPLOYMENT_MODE` (default `preview`), `APP_ADDRESS`, `PUBLIC_ORIGIN`, `NOTITLE_LAUNCH_STAGE`, `ORIGIN_AUTH_SCOPE`, `COHORT_USERNAME`, `VALIDATION_SOURCE_CIDRS`, `STAGING_USERNAME`, `STAGING_PASSWORD_HASH_FILE`. Compose maps them above. `NOTITLE_DEPLOYMENT_MODE` must equal the artifact marker; preview is allowed only on `APP_ADDRESS=:8080`. Hosted modes require origin/hostname equality. `NODE_ENV` is set by the frontend toolchain and influences production CSP; it is not a feature-approval variable.

### Other Docker build arguments: nine

| Argument | Development default | Release requirement |
| --- | --- | --- |
| `GO_BUILD_IMAGE` | `golang:1.27.2-bookworm` | Reviewed immutable Go toolchain image digest, used by API/migrate/relay builds. |
| `NODE_BUILD_IMAGE` | `node:24.19.0-bookworm-slim` | Reviewed immutable Node image digest. |
| `CADDY_RUNTIME_IMAGE` | `caddy:2.11.7-alpine` | Reviewed immutable Caddy runtime digest. |
| `MIGRATION_RUNTIME_IMAGE` | `debian:13-slim` | Reviewed immutable migration runtime digest; goose version in Dockerfile is 3.28.0. |
| `TURN_RUNTIME_IMAGE` | `coturn/coturn:4.18.0-r0` | Reviewed immutable relay runtime digest; supervisor checks coturn 4.18.0. |
| `VERSION` | `dev` | Actual release identifier. |
| `COMMIT` | `unknown` | Actual commit when git-backed; release builder uses `archive` for a source archive with `commit: null`. Never invent a commit. |
| `BUILD_TIME` | `unknown` | Actual build timestamp emitted by release workflow. |
| `SOURCE_SHA256` | `unverified` | Actual canonical source digest; production admission compares embedded value to permit. Default cannot open production. |

Use [scripts/release-build.mjs](../scripts/release-build.mjs) and the reviewed input workflow in [START_HERE.md](../START_HERE.md) and [FINAL_DEPLOYMENT_GUIDE.md](FINAL_DEPLOYMENT_GUIDE.md). Its plan/build commands neither push registry images nor approve launch. Registry manifest digests differ from Docker local image configuration IDs. `GOTOOLCHAIN=local` is fixed in Go build stages and `GOCACHE=/tmp/go-cache` in development/testing. No custom `GOMEMLIMIT`/`GOMAXPROCS` override is supplied; any later runtime tuning must be benchmarked and included in the reviewed effective deployment.

### Relay supervisor: nine recognized process variables

| Variable | Process default | Supplied production behavior |
| --- | --- | --- |
| `TURN_HOSTNAME` | None | Required DNS-only hostname. |
| `TURN_PUBLIC_IP` | None | Required public IPv4. |
| `TURN_RELAY_IP` | None | Required interface IPv4. |
| `RELAY_CONTROL_ADDR` | `0.0.0.0:9443` in direct process | Compose requires explicit private IPv4:9443; never rely on the broad process fallback. |
| `RELAY_CONTROL_TOKEN_FILE` | `/run/secrets/relay-control-token` | Fixed mounted file unless deliberate reviewed override. |
| `RELAY_CONTROL_CA_FILE` | `/run/secrets/control-ca.pem` | CA verifying application client certificates. |
| `RELAY_CONTROL_CERT_FILE` | `/run/secrets/control-cert.pem` | Private-control server certificate with serverAuth and matching SAN. |
| `RELAY_CONTROL_KEY_FILE` | `/run/secrets/control-key.pem` | Private-control server key, owner-only. |
| `RELAY_ALLOW_LOOPBACK_HTTP` | False unless exactly `true` | Local fixture only, literal loopback bind. Not present in production Compose; never enable it on a deployed relay. |

Public TURN PEM paths are fixed to `/run/secrets/turn-cert.pem` and `/run/secrets/turn-key.pem`, not environment variables. The supervisor is PID 1 and owns coturn plus its watchdog; do not run it as a separately orphanable process. Runtime TURN authentication material is generated and rotated on every boot; do not provision a long-lived static TURN REST secret. See [phase7-relay-runbook.md](phase7-relay-runbook.md).

## 5. Secret and protected-file formats

For deployed validation, use ordinary files with mode **0400 or 0600**, protected directories with mode **0700**, no symlink path components and no group/world-writable parents. API and relay images run as numeric UID/GID **65532:65532**. Files they read must be owned/readable accordingly; PostgreSQL files must be readable by the actual user of the reviewed PostgreSQL image. Separate per-service host directories are simpler than weakening modes. Confirm actual mounted ownership/readability; file-backed Compose secrets do not remap host permissions simply because a YAML `uid` or `mode` was written.

Local bootstrap uses a special development-only arrangement: 0700 host parent, 0444 input files, then a one-shot `key-init` container copies evidence/MFA keys into UID 65532-owned 0400 files in a private named volume. **Do not copy that input-file mode into production.** The deployment verifier enforces owner-only files even where a lower-level reader would accept a looser mode. A runtime file reader accepting a file does not establish a reviewed deployment boundary.

| File / directory | Exact content or format | Ownership, mounting and lifecycle |
| --- | --- | --- |
| Three PostgreSQL password files | Independent nonempty passwords; local helper uses 32 random bytes encoded as 64 hex characters | Separate bootstrap/migration/runtime credentials. Provision for actual PostgreSQL image user; do not reuse local values. Use protected single-line values; coordinate role and client rotation. |
| Runtime DSN | One URI for `notitle_app`, private host `postgres:5432`, database `notitle` | API read-only file at `/run/secrets/runtime_database_url`; no migration/superuser authority. |
| Migration DSN | One URI for `notitle_migrate`, same intended private database | Migrator/offline CLI only. Offline admin reader requires a private file and caps DSN input at 8 KiB; normal API reader caps 64 KiB. |
| `evidence_keyring` | JSON `{"active_key_id":"<key-id>","keys":{"<key-id>":"<base64-32-random-bytes>"}}`; 1–16 keys; ID matches `[A-Za-z0-9_-]{1,48}`; at most 16 KiB | Independent report-evidence AES-GCM keys. Placeholders illustrate shape only. Keep old read keys while any retained evidence/approved backup needs them. |
| `admin_mfa_key` | One standard base64 encoding of an independent random 32-byte key | Encrypts operator TOTP seeds; separate from case keys and operator TOTP secret. API file, offline CLI and protected recovery copy must agree. |
| Audio `audio_control_token` / relay `relay-control-token` | Same 64 hexadecimal characters encoding 32 random bytes | Independent bearer secret, owner-only, at most 4096-byte file on reader; not a TURN user password. |
| App audio CA/client certificate/key | PEM CA; clientAuth certificate and matching private key | Four distinct app audio files including bearer. Private CA issuer key belongs in separate PKI custody, never API/relay runtime. |
| Relay `control-ca.pem`, `control-cert.pem`, `control-key.pem` | PEM client-trust CA; serverAuth certificate and matching key with private URL SAN | Read-only relay secret directory; private control limited to app host and authenticated by both mTLS and bearer. |
| Relay `turn-cert.pem`, `turn-key.pem` | Publicly trusted PEM certificate chain and matching private key for `TURN_HOSTNAME` | Certificate renewal requires drain, relay restart, synchronization and transport/revocation verification. |
| Payment directory `client_id`, `client_secret`, optional `previous_secret` | Raw trimmed provider value, nonempty, at most 1024 bytes; no internal newline or NUL | UID 65532 directory 0700, files 0400/0600; directory bind read-only. Retired secret permitted only through bounded overlap. |
| Operations directory `case_keyring` | Same AES-256 keyring JSON format as evidence, with independently generated material | UID 65532; separate from report/MFA keys. Retain historical read keys under the approved policy. |
| Operations `primary_token`, `backup_token` | Separate raw receiver tokens, 32–1024 bytes, no internal newline or NUL | Protected files read by API, not inline URL query credentials or public variables. Follow actual receiver credential format. |
| Operations `retention-policy.json` | Reviewed manifest matching `server/internal/privacy` schema and exact installed digest | Contains actual approval/reference/review dates, Indian storage region, purpose/trigger/min/max/legal-source rules. Draft file is intentionally unapproved. Do not invent approval dates to pass readiness. |
| Deletion and hold journal directories | Application-managed durable append/atomic records | UID 65532, 0700, writable only for the owning API; distinct from each other and PostgreSQL. Independent encrypted off-host inventory must survive every restorable DB point. Never empty to bypass replay failure. |
| Observer `current.json` | Fresh measured JSON documented in [observability.md](observability.md) | Atomic file replacement, 0600, directory bind. Observer host identity uses API numeric UID 65532 for this narrow published path. Inputs/credentials stay outside mount. |
| Launch `approval.json` | Strict permit JSON produced by `launch-evidence.mjs permit`; schema version 1, database schema 9, fixed 200/100/25 limits, exact source/image/origin/manifest/evidence binding | Owner-only regular file up to 16 KiB; output starts at mode 0400. Install for API UID 65532 into mounted protected directory only after actual evidence passes. |
| Origin `origin-cert.pem`, `origin-key.pem`, `origin-pull-ca.pem` | Origin server certificate/key for canonical host plus app-specific zone AOP client-trust CA | Caddy protected directory; actual Cloudflare zone configuration and provider firewall remain independently verified. Do not use a global shared AOP CA as app-specific identity. |
| Origin `cohort-password-hash`; staging hash file | One 60-character bcrypt hash, `$2a$`, `$2b$` or `$2y$` form | Generate through the reviewed Caddy password-hash workflow using protected input, not a password shell argument. Required for validation/cohort or staging respectively. No shipped default login. |
| Origin `cloudflare-proxies` | Reviewed current Cloudflare proxy CIDRs, whitespace/newline separated | Required validation ingress. Source headers are trusted only through this list; distinct from `VALIDATION_SOURCE_CIDRS` operator allowlist. |
| Operator input / MFA enrollment | Private JSON input; newly created enrollment text includes TOTP secret/URI | Temporary 0600 operator-owned files outside source. Verify actual enrollment then remove according to protected workflow; never include in delivery/ordinary DB backups. |
| Backup/archive recovery material | pgBackRest repository/cipher secrets; scoped host writer credentials; independent age recovery key | Separate from API and source; recovery key outside writer host. Public age recipient is not a private key. Encrypted archive/restore tests remain required. |

Public certificates, approved policies and CIDRs are not cryptographic secrets, but their integrity and narrow mounted ownership are still protected by the deployment verifier. Do not co-locate unrelated provider credentials in a parent directory mounted into a service.

## 6. Provisioning workflow and exact repository commands

All paths below are illustrative **operator-owned paths outside source**; provision actual directories and values deliberately. None of the commands provides a production approval. Do not paste placeholder values into production.

1. **Local initialization only.** From the project root, `./scripts/bootstrap.sh` runs the documented local bootstrap and dependency preparation. The narrower `node scripts/init-local.mjs` exclusively creates/preserves local development files and prints no secret values. Dev Compose runs `node /setup/prepare-private-keys.mjs` in its `key-init` service before API startup. That helper is intentionally a container-local file copier with fixed paths, not a general production secret generator. See [deploy/README.md](../deploy/README.md).

2. **Production secret provisioning.** Use the approved protected secret workflow to generate independent random encryption keys/database passwords, import actual provider credentials, and issue certificate pairs with the proper usages/SANs. There is no bundled production key/PKI/merchant-provisioning command. Prepare scoped directories with UID/read permissions appropriate to each consumer, record recovery ownership, test restoration and confirm reads inside the reviewed containers. Do not put values in process arguments, logs, public JSON, build args or shell history.

3. **Initialize schema 9 and private operator access.** Use the dedicated migration image/role for all migrations before starting this cumulative API. Provision the founder/backup offline using the shipped `/adminctl` binary (or the separately built same-source binary), not a public endpoint:

   ```bash
   adminctl -action provision \
     -input-file /private/operator-input.json \
     -database-url-file /private/migration-dsn \
     -mfa-key-file /private/admin-key \
     -enrollment-file /private/new-operator-enrollment.txt
   ```

   Input has exactly `username`, `password`, `roles`; obtain the actual password through protected input rather than a shell argument. Allowed roles are `owner`, `moderator`, `grievance_officer`, `billing_operator`, `operations_readonly`, with no duplicates. Assign only reviewed duties. Enrollment output must not exist and is not printed. A lost commit response can be ambiguous: preserve enrollment and inspect current state before retrying. [Phase 9 operations](phase9-operations.md) documents `-action manage` with target, expected generation, action/reason and fresh authorizer credentials; reset-MFA also requires a new exclusive enrollment path.

4. **Install actual retention policy.** Copy the reviewed manifest to its protected runtime location and immutably install the same document with fresh owner authorization:

   ```bash
   adminctl -action install-retention-policy \
     -policy-file /private/retention.json \
     -input-file /private/policy-approval.json \
     -database-url-file /private/migration-dsn \
     -mfa-key-file /private/admin-key
   ```

   Approval input fields are `authorizer_username`, `authorizer_password`, `authorizer_code`, `reason`. This command validates/records already-reviewed policy; it does not create legal approval or enable purging. Publish counsel-approved deadline rules/notices through reviewed data-publication SQL under migration-role authority as described in [server/internal/operations/README.md](../server/internal/operations/README.md), keeping schema 9. A new schema migration requires coordinated code and acceptance updates. The policy, public disclosures and actual backup/log retention must agree.

5. **Prepare isolated acceptance and payment settings.** Use staging/sandbox with a separate project, database, credentials, journals and origin. Never copy financial rows between sandbox/production. Build the staging frontend with matching origin and optional sandbox SDK. Expose only the exact signed Cashfree webhook path through staging authentication exemption; all browser routes remain protected. Production Cashfree environment, written merchant/policy approval, catalog/tax publication and separately authorized live purchase/refund/settlement evidence are distinct gates. See [deploy/payments/README.md](../deploy/payments/README.md) and [phase8-acceptance.md](phase8-acceptance.md).

6. **Prepare real operations observations and recovery.** Install the reviewed [observer service/timer](../deploy/operations/notitle-observe.service), scoped external probe, verified recovery/clock/relay inputs and receivers. `scripts/operations-observe.py` takes `--evidence`, `--state`, `--output`, `--disk-path`; the template command targets `/var/lib/notitle-observe` with published `current.json`. First baseline returns exit 2, not a healthy sample. Test independent external notification even when the app VM is down. Adapt pgBackRest paths to the actual PostgreSQL 18 mount; configuration alone does not install the backup tool. Follow [deploy/operations/README.md](../deploy/operations/README.md) for sealing, verified off-host transfer, retention and restoration.

7. **Validate the effective deployment privately.** The wrapper validates shape and prints a sanitized result, without deployment:

   ```bash
   ./scripts/production-config.sh --env-file /protected/release.env \
     --overlay audio --overlay payments --overlay operations
   ```

   For evidence, render actual app/relay JSON into protected files, never public logs, then run the host-file validator:

   ```bash
   node scripts/deploy-config.mjs validate --purpose production --source . \
     --config /protected/app-compose.json \
     --relay-config /protected/relay-compose.json --check-files \
     --out /protected/deployment-manifest.json
   ```

   Use `--purpose acceptance` for the isolated staging/sandbox configuration. Exact rendering commands and the self-hash exclusion are in [phase10-deployment.md](phase10-deployment.md). Checks require actual referenced files; static validation does not prove effective firewall, certificate trust, container readability or live owner count.

8. **Create pending evidence, then prove the gates.** Initialize only a pending record:

   ```bash
   node scripts/launch-evidence.mjs init --source . \
     --out /protected/launch-evidence.json
   node scripts/launch-evidence.mjs check --source . \
     --evidence /protected/launch-evidence.json --purpose validation
   ```

   Fill actual immutable images/origin/manifest and measured artifacts using [deploy/launch/README.md](../deploy/launch/README.md); no checker manufactures missing tests or business approval. Capacity collectors require real API/message/matching histograms and host/load evidence, not manually invented percentile fields. A bounded validation permit can be created only after pre-live gates and specific authorization pass:

   ```bash
   node scripts/launch-evidence.mjs permit --source . \
     --evidence /protected/launch-evidence.json --purpose validation \
     --evidence-ref reviewed_validation_01 \
     --out /protected/new-validation-approval.json
   ```

   The reference is an opaque identifier tied to the actual record, not an approval by naming it. Output must be new and outside source. After every full gate passes, repeat with `--purpose launch`, a real reference and a new output file. Install the resulting exact file with reviewed ownership into `LAUNCH_APPROVAL_DIRECTORY/approval.json`, then deliberately open through private owner MFA. Directory mounting permits atomic replacement; never edit a permit to extend dates or change scope. Full cohort/public stage changes need fresh manifest-bound permits. No command above performs a money operation or public opening.

## 7. Test-only environment and configuration checks

| Test setting | Use and restriction |
| --- | --- |
| `TEST_DATABASE_URL_FILE` | Disposable runtime-role PostgreSQL fixture DSN. Preferred over inline alternative; set by dev checks Compose. |
| `TEST_DATABASE_URL` | Local test-only inline alternative supported by several packages; avoid secret environment values and use `_FILE` for the full suite. Never point at production. |
| `TEST_ADMIN_MIGRATION_URL_FILE` | Disposable migration-role fixture DSN required by admin/operations/privacy/billing tests. |
| `TEST_ADMIN_MIGRATION_URL` | Inline fallback in some test packages only; not uniformly supported, so use the file setting. |
| `REQUIRE_DATABASE_INTEGRATION` | Exact `1` makes missing DB fixtures fail instead of skipping. Supplied DB check container sets it. |
| `PLAYWRIGHT_BASE_URL` | Explicit existing test server; otherwise Playwright starts its configured local web server. Use isolated test hosts. |
| `CI` | Frontend test-runner controls for forbid-only, retries/reporting/workers; not an application mode or launch approval. |

Internal subprocess fixture names such as `NOTITLE_WATCHDOG_TEST_MODE`, `NOTITLE_TEST_PARENT_PID` and `NOTITLE_TEST_RELAY_PID` are generated by Go tests and must not be used as runtime settings. Load permits, fixtures, background-job evidence and output paths are CLI/file inputs documented in [deploy/load/README.md](../deploy/load/README.md); they are not public environment overrides of the capacity limits.

Before release, compare the actual app-variable subset against [configuration.schema.json](configuration.schema.json), then run the runtime configuration/tests: the JSON schema does not validate file contents, actual filesystem ownership, remote reachability, full cross-field behavior or evidence freshness. Never apply `additionalProperties:false` to the entire process environment, which also contains ordinary OS/toolchain variables.

## 8. Integration cautions and unresolved release work

- **Modes differ intentionally.** Loader `MAINTENANCE_MODE` defaults false locally/staging; the cumulative production-based staging Compose still supplies true. Production always requires true. API `LAUNCH_STAGE` and Caddy `NOTITLE_LAUNCH_STAGE` are separate controls; Caddy opening cannot bypass API admission.
- **Permissions differ intentionally between local and deployed setup.** Local bootstrap's 0444 input mount pattern is not a production recipe. Owner-only production files and actual service-user reads are required by the current verifier.
- **Explicit paths prevent accidental aliasing.** Keep evidence/MFA/operations key files distinct and set their paths explicitly; likewise keep deletion/hold directories distinct. Reusing an encryption key across differently named files is also prohibited operationally and cannot be established from path validation alone.
- **All cumulative migrations are required.** Use schema 9 even where historical phase instructions refer to earlier migrations. Run no destructive DOWN migration or volume deletion against retained production data.
- **Backups need actual integration.** The stock PostgreSQL image does not install pgBackRest merely because a template exists. Align `pg1-path` with actual `PGDATA=/var/lib/postgresql/18/docker`, preserve required WAL chains and independent journals, then prove restore. Template paths/retention dates are not recovery evidence.
- **Neither base Compose nor an env file is full-V1 approval.** Base features stay off; overlays, real policy/catalog publication, staffed coverage, source-bound artifacts and acceptance are all necessary. Current source delivery must remain marked pending until authentic locks and runtime/deployment evidence exist.
- **No extra service is implied by missing values.** Keep static frontend, one Go owner, PostgreSQL and the separate relay. Receiver/backup/monitor arrangements must be reviewed within the approved budget; do not add user-email SaaS, hosted realtime, Redis, subscriptions or an extra permanent staging host simply to fill a variable.

Source of truth for this inventory is `server/internal/config/*.go`, `docs/configuration.schema.json`, `server/cmd/relay-supervisor/main_linux.go`, the Dockerfiles, `web/src/lib/config` / `web/scripts/release-config.mjs`, `deploy/app/entrypoint.sh` and the supplied Compose files. Reconcile this reference when those sources change; an environment value never supersedes their authorization or business rules.
