# Phase 1 acceptance

Implementation and acceptance are different states. This checklist is a release gate, not a claim that checks passed. Current evidence is in `PART1_STATUS.md`.

## Reproducible setup

- A clean checkout on Linux/WSL2 with Docker Compose v2.30+ starts with `./scripts/bootstrap.sh` on localhost:5173 without host Go/Node/PostgreSQL.
- `./scripts/bootstrap.sh static` serves through Caddy on localhost:8080.
- Pinned tools generate genuine Go/npm locks. Review and commit both, module graph updates and formatter changes. Repeated bootstrap preserves secrets.
- `./scripts/verify.sh` exits zero. CI runs verification without generating missing locks or skipping required database tests.

## Backend and database

- Invalid environment, origin, secret-source, timeout, pool and byte-limit configuration fails safely.
- Liveness returns 200 when PostgreSQL is unavailable; readiness returns 503. Missing schema and elevated runtime roles also fail readiness.
- Correctly migrated PostgreSQL permits readiness200. Runtime login cannot create schema, temporary tables or roles, or write the foundation marker.
- Migration up/down/up passes on a disposable database, never retained developer or production data.
- IDs, error envelopes, panic handling, body limits and log redaction tests pass. Untrusted paths and queries never enter normal logs.
- Go formatting, vet, build and race tests pass, including coordinator ownership, cancellation, bounded mailbox and immutable limits.
- SIGTERM drains HTTP, stops the coordinator and closes resources within the grace period. Clean startup/shutdown leaves no test secrets in tracked files.

## Frontend and routing

- Svelte/type checks, lint/format, unit tests, static build and Playwright pass.
- Public HTML works without JavaScript. The unavailable `/chat` shell supports direct navigation/reload with noindex/no-store.
- Widths 320,375,430,768,1440,1920 CSS px: no horizontal overflow, keyboard navigation and 44 CSS px control targets.
- Safe areas, reduced motion and mobile viewport sizing are implemented. Real Android Chrome/iOS Safari testing is a later launch gate; Chromium emulation alone does not establish compatibility.
- API stays same-origin; unknown routes return 404. CSP allows the generated bootstrap without broad production unsafe-inline scripts.
- Built frontend and Caddy interoperate without published source maps, tracking or browser-stored credentials.

## Release controls

- No committed real secrets. Production requires external secrets, approved image references, HTTPS, and no host PostgreSQL/API port.
- Application containers drop capabilities and prevent privilege escalation. Database responsibilities have separate roles.
- Dependency scans pass or receive a documented, specific security disposition. Approve immutable image digests and scan images before deployment.
- Configuration/API contracts, threat model, retention, versions and reproduction commands are reviewed together.

## Preserved later gates

Phase 1 does not certify authentication, payments, media, moderation, backup recovery, legal retention or business-load availability. Full V1 must demonstrate at least 200 simultaneous connected participants, including 50 people in25 concurrent two-person calls and up to 100 waiting users, while preserving all finalized matching and role rules. These are overlapping subsets, not additional users.
