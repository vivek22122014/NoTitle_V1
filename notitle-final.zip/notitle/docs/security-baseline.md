# Security baseline

This is the cumulative engineering baseline through Phase 9, not evidence that runtime or production acceptance passed. Earlier sections record the foundation; phase extensions supersede their future-feature wording. The threat model tracks remaining obligations.

## Secrets and configuration

- Never commit real credentials. The initializer creates random secrets under ignored `.local/secrets` and preserves existing values.
- Staging/production require `DATABASE_URL_FILE`; inline credentials are rejected. Never log configuration containing secrets.
- Compose secrets are read-only host-file mounts, not an encrypted vault. Protect their host directory and backups. Runtime UIDs must be able to read mounted files without exposing the host parent directory.
- Production images and secret paths are explicit; development credentials are never a fallback.

## HTTP and browser

- HTTPS in production; same-origin API, no permissive CORS. Cookie-authenticated mutations enforce CSRF and exact Origin validation.
- Bound headers, body size, timeouts and handler work. Return safe errors with server-generated IDs.
- Render user input as text. Never put credentials in browser storage, URLs or WebSocket queries.
- Svelte generates the static HTML hash CSP; Caddy adds frame-ancestor protection. Review any widening with its feature.
- No third-party analytics, ad pixels or public browser source maps.

## Logs and database

- Log allowlisted operational fields with fixed route labels. Exclude raw paths, queries, ordinary conversations, cookies, tokens, IPs and DSNs.
- Keep PostgreSQL private. Separate initialization, migration and runtime roles. Runtime cannot create schema, temporary objects or roles.
- Parameterize queries. New durable tables need explicit constraints, indexes, grants and retention purpose. No ordinary-message tables.
- Source/support archives exclude secrets, database volumes and logs.

## Containers and dependencies

- API runs non-root with a read-only root filesystem and dropped capabilities. No privileged containers or Docker socket mounts.
- PostgreSQL's official initialization entrypoint has different filesystem/privilege needs; do not describe it as an immutable non-root service.
- Exact versions, genuine locks and verified downloads are mandatory. Release checks fail on missing locks instead of resolving a new graph.
- Approve immutable image digests and scan images before deployment. Keep CI permissions minimal and apply vulnerability updates.

Backups/restore, host firewall, patching, incident procedures and feature security remain launch gates. A Compose template cannot establish them alone.

## Phase 4 transport and ownership

The ticket endpoint applies cookie, exact-Origin and CSRF checks. `/ws` also validates exact Origin, forbids query strings, binds the one-use ticket to the current cookie session and explicit takeover choice, and rechecks live authorization. Admission, authentication work, frames, writes, owner mailboxes and dedupe are bounded. Cookie secrets, tickets and resume proofs never enter URLs or persistent browser storage.

Each command checks generation and interaction epoch against one owner. Replacing a socket cannot make its delayed callback affect the new socket. External authorization is fenced against concurrent identity/profile/preference mutations. Post-commit revocation uses priority owner publication; if publication and invalidation fail, an independent fail-closed latch prevents further matching until restart. Readiness fails too. Investigate the fixed failure event and coordinator health before restarting; do not bypass the latch.

HTTP shutdown alone does not drain upgraded connections. The runtime explicitly closes and waits for WebSockets before cancelling the owner. Compression and unimplemented event types stay disabled. Public Premium fixtures are forbidden; Phase 8 replaces the earlier Free-only production source with the trusted durable ledger.

## Phase 5 text and safety

- Text requires trusted server safety capability for both participants. Every send checks current ownership, connection generation, interaction epoch, authorization, availability and bilateral restrictions. Disabling the text/report feature does not disable durable safety checks on realtime authorization. Client send IDs are idempotent only within their live interaction; acceptance is neither durable storage nor proof of human reading.
- Validate UTF-8, escaped UTF-16 scalar pairs, code-point/byte limits and control characters without silently rewriting text. Account for JSON expansion before accepting a message. Render text through Svelte interpolation or Go `html/template`; never use user content as executable HTML, Markdown or automatic links.
- Ordinary chat lives only in bounded interaction RAM and browser RAM. End/Next/Block and expiry purge it; pending report snapshots have their own hard expiry. Disable core dumps and unencrypted swap for content-handling processes. Crash reporting, tracing, screenshots and debug middleware must not collect message or evidence bodies.
- Report Begin freezes only coordinator-held eligible messages. Submit accepts selected sequences and a separate allegation; it rejects arbitrary transcripts, speakers and target IDs. Report & Block imposes a local block before database work. Idempotent durable submission, immutable action history and guarded owner publication prevent false success, duplicate cases and stale authorization.
- Persist submitted evidence under AES-256-GCM with random nonces and metadata-bound associated data. Keep evidence keys outside the database and distinct from MFA keys. Protect current/retired keys and recovery copies for the approved retention window. Encryption at rest does not make server-readable text end-to-end encrypted.
- Runtime SQL grants permit report state changes, block management and append-only evidence/actions/audit; they do not permit arbitrary evidence/action/audit deletion or operator provisioning. Retention timestamps and legal-hold tables are foundations, not a completed purge or hold-management service.

## Private moderation and operating gates

Private administration is a separate listener and dedicated origin, inaccessible through the public Caddy route map. Deployed operations must use a different hostname from the public application; changing only the port does not isolate host cookies. Local development may use distinct localhost ports and explicitly separate cookie names. Bind or publish only to loopback and require an authenticated VPN/access gateway for remote use. Startup address validation cannot prove firewall or gateway isolation; verify it from an external network. No operator is hard-coded, automatically enrolled or granted a default password.

Operators use separate accounts, Argon2id passwords, replay-protected TOTP, host-only secure cookies, exact Origin/CSRF checks and short sessions. Owner, moderator and grievance-officer roles may review cases and apply the implemented actions. Billing and read-only operations roles do not receive general evidence access. Role/session/generation checks apply to every action transaction; hiding a control is insufficient. Evidence is rendered only after its access audit commits. The surface exposes submitted cases, never current live conversations.

Appoint trained primary and backup operators and establish monitored report/grievance coverage before real-user testing. Configuration flags record these assertions; they do not supply staff, legal review or a working external contact. Execute Go/database/browser/security checks, prove gateway isolation and evidence/audit failure behavior, and complete reviewed retention/purge, restore and incident gates before public release. Source tests and these controls have no implied passing runtime result.


## Phase 6 consent, relationships and presence

- Stay Connected requires two current participants and two affirmative consents. Clients supply interaction/request/relationship scope, never an arbitrary target account or private username. Reciprocal requests are idempotent; decline and withdrawal do not disclose a rejection reason or create a durable request inbox.
- Opaque handles limit exposure but never replace authorization. Every list, removal, presence and invitation path must prove the requesting identity is the relevant endpoint and recheck blocks, restrictions, session validity, generation and current ownership. Presence is visible only through an accepted, unblocked relationship.
- Temporary guest relationships have endpoint indexes and strict cleanup. Guest expiry, end and restart remove both sides; a relationship does not extend guest TTL. Registration preserves the same person's consent and identity binding, while login to a different account imports nothing. Never introduce persistent browser identity fingerprints to recover guest links.
- Durable relationships use a unique normalized account pair. Persistence locks endpoints in a stable order and rechecks account friendship revisions captured by the owner. Remove, Block and deletion advance these revisions, so a stale insertion or promotion cannot restore a removed relationship. Because the fence is account-wide, an unrelated Remove or Block can invalidate unpublished consent involving that account; already durable friendships are unaffected. Require fresh mutual consent after this conflict, never a blind revision refresh. Failed owner publication requires exact guarded compensation or a fail-closed state; never clear uncertainty by assuming success.
- A newly registered endpoint has no guessed initial revision. Capture it only from the first fresh authenticated authorization after the safety handoff; closing before that leaves the accepted link pending until a later valid authorization. Keep an already-account endpoint's consent revision frozen. Once revisions are captured, retained-consent promotion checks active accounts, those revisions and safety without requiring both originating cookies or old credential generations to remain current. Logout or credential rotation alone does not revoke a friendship; fresh account-account consent and all new contact still require current session authorization.
- Invitations are memory-only, bounded and expire after 30 seconds. Both sides must be online and available at acceptance. The existing single owner allocates the resulting interaction atomically; a friend invitation cannot interrupt a busy conversation or bypass the shared interaction capacity. Audio remains unavailable until the media phase passes its own gates.
- Remove immediately stops friend presence/invites and ends a friend interaction. Block additionally enforces reciprocal exclusion from random matching and future contact. Unblock does not re-create consent. Deletion and independent tombstone replay must remove relationships before restoring access after database recovery.

Run the Phase 6 race, stale-write, restart, privacy and mobile acceptance matrix in `docs/phase6-acceptance.md`. Authored checks do not establish that those gates passed. Existing trained moderation, grievance coverage, retention and recovery requirements continue to apply to friend interactions.

## Phase 7 audio consent and privacy

- Call or Accept must be an explicit action by the person whose microphone is requested. Incoming signaling, friendship, page load, reconnect and background tab events are not consent. Permission denial, absent devices and autoplay restrictions have clear UI states with text fallback. Mute affects the local outgoing audio track; End stops tracks and closes the peer connection.
- The server controls call identity, interaction epoch, offer ownership, state transitions and capacity. A server-issued negotiation counter also rejects delayed signaling/connected acknowledgements after credential refresh. It rejects stale, cross-call and wrong-owner signaling. One outstanding request, bounded ringing and decline cooldown limit prompt pressure; neither a client state flag nor TURN credentials authorize a second call.
- Use audio-only DTLS-SRTP through relay-only ICE with Opus. Validate every SDP section, connection address, embedded candidate and separate candidate; permit only the configured public relay addresses. Reject video, data channels, direct host/server-reflexive paths and unsafe addresses rather than trusting `iceTransportPolicy` alone. Do not place raw SDP, ICE, audio samples, device labels or network identifiers in logs or analytics.
- No recording, transcription, voice cloning, voiceprints or persistent ordinary-call history is introduced. Normal TURN forwarding does not decrypt DTLS-SRTP media. This does not prevent a participant recording or recognizing a voice, or make ordinary server-readable text end-to-end encrypted. Do not promise that a voice report contains replayable audio.

## Phase 7 relay enforcement and deployment

- Issue temporary TURN credentials only for an accepted, authorized call. Each endpoint receives its own random call-specific username. The ten-minute expiry and five-minute refresh cadence are separate from the maximum 30-second private application lease. Keep shared authentication keys, private control credentials and certificate keys outside source, browser configuration and ordinary logs.
- Authentication and encryption protect the app-to-supervisor control path. Restrict that path to the application host or a protected tunnel; coturn CLI and supervisor/metrics listeners must not be publicly reachable. Deny redirects and arbitrary destinations in control clients. Never expose host-management authority, a Docker socket or arbitrary shell execution through the supervisor.
- Bound calls, allocations, credentials, work queues and polling. The 25-call target requires at least 200 allocations at four per participant plus measured headroom; enforce the 1,024-port range and its matching firewall rules. Deny private, loopback, link-local, metadata and multicast destinations for IPv4 and IPv6. Verify actual firewall/coturn behavior rather than assuming a generated configuration is effective.
- End/Next/Block, deletion, logout, loss of authorization and removal of an active friend interaction stop credential issuance and request allocation cancellation. Continue rejecting and cancelling allocations recreated with a revoked credential until its original expiry. One successful cancellation or refusing a refresh is insufficient. If state or cancellation becomes uncertain, fail closed rather than leave an unverifiable active call.
- Supervisor restart begins from an empty trusted lease state, cancels existing allocations and requires state resynchronization before accepting new leases. Application failure permits no renewal beyond the current 30-second lease. Internal deadlines reserve six seconds for cleanup plus two seconds of bounded cross-host skew; synchronized and monitored host clocks remain required. An allocation still present two seconds after cancellation causes relay shutdown. The separate three-second watchdog stops forwarding when enforcement stalls. Stopping only the web API does not reliably stop media.
- Keep deployed audio disabled until measured cancellation is at most five seconds and application-orphan teardown meets the 30-second lease deadline. Execute credential replay, supervisor/application failure, restrictive-network and real mobile/desktop device tests. Certificate provisioning, a staging host and a test checklist do not exist merely because their templates exist.

The operational procedure and evidence to collect are in `docs/phase7-relay-runbook.md`. Public audio activation remains an acceptance decision; source delivery alone does not complete the full-V1 audio or capacity requirement.

## Phase 8 financial trust boundaries

- Treat the browser and callback parameters as untrusted. Server-owned enabled plan versions, exact integer paise, immutable original snapshots, authenticated provider fetches and the transaction's unique grant control paid access. Keep one purchase distinct from its multiple payment attempts. A failed attempt cannot demote an earlier verified success.
- The raw Cashfree webhook route is the narrow exception to browser Origin/CSRF checks: it authenticates provider signature before parsing, bounds headers/body, commits a minimal durable inbox and returns retryable failure if ingestion fails. It is not a cookie-authorized mutation endpoint. Normal purchase/verify actions retain exact Origin, CSRF and session/account transaction guards.
- Pin provider API behavior and exact HTTPS hosts; refuse redirects, arbitrary API origins and unbounded responses. External requests have finite deadlines. Secrets use protected files, sandbox/live separation and bounded previous-key rotation; no API key, signature, raw payload or payment session enters logs, analytics or source archives.
- Hosted checkout keeps card/bank credentials outside NoTitle. Payment-only contact is genuine, disclosed, transient in the application and never a registration requirement or peer attribute. A receipt or phone number does not prove account ownership. Return only owner-authorized payment DTOs with no-store and noindex.
- Serialize financial changes and reserve cumulative pending/processed refunds against validated capture money. Full holds/revokes target the original lot; partial duration treatment is explicit in seconds. Preserve consumed time and append-only corrections. Unknown provider outcomes remain pending until reconciled; do not retry with new economic identities.
- Billing views/actions require the private MFA listener and billing/owner role, with audit before disclosure/action. Moderators cannot browse money and billing staff cannot browse ordinary moderation evidence. Recheck operator session/generation/role in action transactions; hiding a navigation item is insufficient.
- Paid-control use must be durably attributed to the current FIFO lot before matching. Entitlement changes use durable invalidation and owner fences; queue join and match commit check time directly. Clock drift, uncertain ledger state and failed publication pause affected matching rather than retaining stale paid authority.
- Deleted-account late captures/refunds are retained financial obligations, never permission to reactivate identity. Restore the independent deletion journal and financial reconciliation before reopening traffic. Never reverse retained financial migrations or restore an older database merely to roll back code.

Run `docs/phase8-acceptance.md` against real PostgreSQL and the approved gateway sandbox, then perform the separately authorized live capture/refund/settlement gate. Merchant, tax, policy, retention and monitored operator approval remain real release inputs; their configuration flags cannot create evidence.

## Phase 9 operational boundaries

Public support is independent of an account session. A random case reference plus 256-bit status secret authorises only that case; it is not proof of the claimed account or purchase. Keep the secret in the request body and transient browser memory, never a URL, general log, analytics label or ordinary browser persistence. Use strict same-origin/CSRF checks, bounded encrypted submissions, rate limits and generic failed-lookups. Human operator replies exclude internal notes and other-person evidence. Availability failures must remain honest; a displayed form does not establish monitored support.

Private staff retain separate MFA, short-lived sessions and role-specific access. Owner/grievance roles may perform the scoped evidence export; billing cannot browse safety material. Export permits bind actor, generation and current session, are one-use/two-minute and hold only bounded encrypted data in RAM. The key is separately displayed once after audited preparation. Every download requires another fresh guarded audit. A two-minute download expiry cannot revoke an already saved/decrypted file: approved purpose/retention and offline key protection follow the copy.

Offline lifecycle management requires migration credentials plus fresh owner password/MFA and expected target generation. Changing roles, disable/enable or MFA reset increments generation and revokes existing sessions. Never place owner credentials or replacement enrollment in process arguments/logs. Preserve at least one active owner and independently trained backup. Source templates cannot appoint them.

Retention policy publication is separated from runtime: the API reads an approved immutable policy row matching the protected manifest digest; the normal runtime role cannot insert approval or modify a deadline/catalog/notice policy. Narrow SECURITY DEFINER erasure functions use a fixed pg_catalog search path and owner, explicitly restricted EXECUTE, current-time checks, deletion/hold/account locks and audit. They never grant arbitrary DELETE over financial/evidence tables. Hold changes first reach the fsynced independent journal, then a versioned DB projection. Missing/corrupt replay or stale approval fails closed for destructive work.

Security archives are client-encrypted under an independently recoverable key and stored in the reviewed India region. Separate purpose lifecycles protect journal recovery beyond database rollback. Confidentiality, integrity, remote inventory and recoverable WAL age must be tested with the actual provider. Restrict collectors and archive credentials separately from the application, and keep source diagnostics from becoming a transcript archive. The low-cost templates in deploy/operations introduce no paid telemetry or new application owner.

Host observations and notification endpoints are trusted, protected configuration. Reject malformed/stale observations; never replace unavailable with zero. The outbound receiver pins an exact HTTPS endpoint, forbids redirects and private/reserved DNS destinations, uses bounded requests and carries no case contents. Delivery and human acknowledgement are different states. An independent monitor must detect a vanished application host and reach the primary/backup even while the in-app queue is offline.
