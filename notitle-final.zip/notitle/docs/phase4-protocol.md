# Phase 4 realtime protocol

This is protocol version 1. Phase 4 provides identity-authenticated connection control, the shared matching pool and reconnect. Message, friend, report and audio events are rejected until their later phases. A successful match is not a claim that those features are enabled.

## Establishment and trust

`POST /api/v1/realtime/ticket` submits `{takeover:false}` using the existing valid cookie, exact Origin and CSRF checks. Its response is `{ticket, expires_at, protocol_version: 1}`. Explicit takeover submits `true`, bound to the ticket and required to match the first frame. Tickets contain at least 256 bits of randomness, are one-use, expire after 60 seconds and remain in browser memory only. A WebSocket connects to same-origin `/ws` without query parameters or credentials in its URL. The first text frame must authenticate within five seconds. Origin checks and bounded handshake admission happen before allocating a participant.

```json
{"v":1,"id":"random-command-id","type":"session.authenticate","generation":0,"payload":{"ticket":"single-use-secret-from-ticket-response","takeover":false}}
```

Every envelope requires `v`, `id`, `type`, `generation` and an object `payload`. Client event IDs use 1–64 ASCII letters, digits, hyphens or underscores. Unsupported versions, duplicate keys, unknown fields, malformed UTF-8, null scalar values, trailing JSON and frames over 8 KiB are rejected. Compression is disabled. No client-selected peer or account identifier is accepted.

Authentication snapshots are private server records: identity/session generation, profile and preference versions, trusted entitlement/expiry, safety version and validity deadline. The authorization service obtains an actor fence before rechecking the current session and reading external state. The actor rejects publication if that fence changed during external work. Database calls never execute in the coordinator loop. Public serialization of authorization and queue records is explicitly rejected.

## Client commands

| Type | Payload | Required interaction reference | Effect |
| --- | --- | --- | --- |
| `session.authenticate` | `{ticket,takeover,resume?}` | None; envelope generation is 0 | Authenticate before other commands |
| `queue.join` | `{}` or `{continue_with_everyone:true}` | None | Start an explicit search; optional Everyone override applies only to this search |
| `queue.leave` | `{}` | None | Leave waiting and return to idle |
| `match.next` | `{}` | `interaction_id` and `epoch` | End this interaction and queue only the initiator |
| `match.end` | `{}` | `interaction_id` and `epoch` | End this interaction and return both participants to idle |
| `heartbeat` | `{}` | None | Confirm authorized connection activity; server sends `pong` |
| `state.sync` | `{}` | None | Return the authoritative current state |

After authentication, `generation` must equal the server-issued connection generation. Old connection commands and callbacks cannot affect a replacement. Next and End must also name the current opaque interaction ID and epoch; stale references fail with `STALE_EPOCH`. A bounded per-connection dedupe collection prevents a duplicate event ID from applying an action twice. Each accepted command receives `command.ack` correlated by `reply_to`; failure receives `error`. The transport never invents a second state transition after an actor error.

Saved strict gender preferences never silently relax after Premium expiry. The expired queue pauses and shows the reason. Only a new user action with `continue_with_everyone:true` authorizes an Everyone search while retaining saved selections. Queue.join never accepts client Premium, gender, professional or safety claims. Owner preferences use the REST API, not socket payloads.

## Server events and state

Server envelopes use `{v,id,type,generation,interaction_id?,epoch?,reply_to?,payload}`. Event IDs and interaction IDs are server-generated opaque values. The actor is the sole producer of a connection's bounded outgoing event stream.

`session.ready` and `session.state` carry this state object:

```json
{"state":"IDLE","server_instance":"opaque-instance","resume_token":"opaque-resume-secret","generation":1,"heartbeat_seconds":20,"reconnect_seconds":25}
```

State is `IDLE`, `WAITING` or `MATCHED` for an attached browser. The internal actor also uses `OFFLINE` and `RESERVED`. A waiting state includes `queued_at`. A matched state includes `interaction: {id,epoch,peer,own_topic,peer_connected,reconnect_until?}`. The peer object contains only `display_name`, self-declared `gender`, optional `bio` and selected `topic`. The current participant's topic is separate so differing topics are presented honestly. Raw identity IDs, usernames, professional selections, roles and peer Premium state are absent.

State changes may additionally use `queue.joined`, `queue.paused`, `match.found`, `match.ended`, `peer.disconnected`, `peer.reconnected`, `session.replaced`, `session.closed`, `service.unavailable` and `premium.expired`. Queue, match and peer notifications carry the authoritative state snapshot. Terminal/availability notices carry a fixed reason. These notifications do not authorize client-invented state. `repeat_advisory` offers Keep searching/Pause after repeated skips, without excluding a pair longer than the published cooldown.

Errors have payload `{code,message,retryable}`. Stable codes include `INVALID_EVENT`, `UNSUPPORTED_VERSION`, `STALE_GENERATION`, `STALE_EPOCH`, `AUTHENTICATION_REQUIRED`, `TAKEOVER_REQUIRED`, `PREMIUM_REQUIRED`, `GENDER_REQUIRED`, `NOT_AVAILABLE`, `BLOCKED`, `RATE_LIMITED` and `CAPACITY_REACHED`. Messages never echo submitted tokens or internal errors.

## Disconnect, resume and takeover

Heartbeat runs every 20 seconds; a connection with no qualifying activity is dead after 45 seconds. Waiting entries are removed immediately on detected disconnect. Established interactions retain bounded control state for 25 seconds. The peer sees disconnect status; sending remains unavailable. No Phase 4 transcript exists or is reconstructed.

The browser retains the latest resume token, instance, generation and interaction reference only in memory. A reconnect authenticates using a fresh ticket and payload `resume: {token,server_instance,generation,interaction_id?,epoch?}`. Resume and takeover are mutually exclusive. The actor verifies the same valid identity, resume secret, server instance and interaction epoch before restoring anything. Successful reattachment rotates the connection generation and resume proof. Missing proof or another browser cannot silently take over an existing slot. Explicit takeover ends the prior interaction before activating the new connection.

Reconnect uses bounded exponential backoff with jitter. It does not silently rejoin a queue, repeat Next or reinterpret an ended interaction. After grace expiry or server restart, the client receives an honest ended/idle state; guests must re-enter when their memory identity was lost. Audio is not active in this phase and will require fresh consent after signaling loss in Phase 7.

## Shared matching policy

Every tier uses one waiting collection and the same allocator. Hard checks include both valid required genders, both directional gender preferences, online/available status, identity validity, blocks/restrictions and the four-second immediate repeat cooldown. Specific gender requires trusted active Premium at reservation and commit. Free/Guest requests for paid choices fail explicitly. Unknown optional professional values never make a pair ineligible.

The oldest waiting participant with a feasible partner is the anchor. All compatible candidates are considered. Candidate score is uncapped waiting seconds minus recent-pair penalty plus topic/professional bonuses. A common non-General topic contributes at most 0.5; five professional categories contribute at most 0.1 per Premium direction, averaged across both directions, for at most 0.5 overall. Category choices use OR; interests contribute `0.1 × matched preferred interests / preferred interests`, capped at 0.1. Disabled/empty categories, global No preference and non-Premium directions contribute zero. If either person chooses General Talk, professional influence is zero for that pair.

Both bonuses are multiplied by `max(0, 1 - max(anchor_wait,candidate_wait)/5)`. They vanish after either participant waits five seconds. Final ties favor greater candidate waiting age, then a server random tie value. Paid status supplies no queue priority. Matching never waits for professional overlap.

Recent-pair records forbid only the first four seconds after an interaction ends. Afterward the penalty is `60 × exp(-(seconds_since_end - 4)/10)` and the record expires after five minutes. An otherwise valid sole candidate can match immediately when the four seconds finish. Matching runs on relevant state changes and a 100 ms timer. The actor reserves both slots, increments the epoch, rechecks current hard rules and commits once. Limits remain 200 connected participants, 100 waiting participants and a reserved full-V1 capacity of 25 simultaneous two-person calls; these are acceptance targets, not measured results.

## Owner preference contract

`GET/PATCH /api/v1/me/matching-preferences` returns `{preferences,premium_active,premium_expires_at?,requires_everyone_confirmation}`. PATCH submits the full versioned preferences object with CSRF and optimistic version protection:

```json
{"version":1,"gender":"everyone","professional":{"no_preference":true,"industry":{"no_preference":true,"choices":[]},"profession":{"no_preference":true,"choices":[]},"experience":{"no_preference":true,"choices":[]},"interests":{"no_preference":true,"choices":[]},"topics":{"no_preference":true,"choices":[]}}}
```

Gender is `everyone`, `male`, `female` or `other`, independent of declared gender. Categories permit five controlled choices each, except interests permit ten. Global No preference and General Talk do not erase saved choices; selecting a category's No preference clears that category's choices on save. Guest choices remain in memory. Account choices persist privately. Entitlements are Free in the deployed Phase 4 implementation; Premium behavior is available only through trusted Go test fixtures, with no public debug switch or checkout activation.

Synthetic interoperable client frames and expected stable errors are recorded in `server/internal/realtime/testdata/protocol-v1.json`. These are test examples, not live tickets or recorded user activity. The Go fixture test and protocol fuzz target must run in the full verification environment.

## Safety publication failure

Committed profile/preference or session-revocation changes must be delivered to the owner before their HTTP mutation reports success. Emergency invalidation receives an independent bounded deadline. If both notification and invalidation fail, the coordinator's independent atomic fail-closed latch closes live state and prevents new matching/admission. Ordinary dependency health recovery cannot clear it; process restart is required after investigation. The durable identity/session state is then re-read before any new binding.

A valid rotating in-memory resume proof can also replace a half-open old transport after a network change. The actor closes that old writer and advances generation without ending the interaction. A browser with only the session cookie still needs explicit takeover; replaying the consumed resume proof fails. Route changes within the same application retain the controller in RAM so guest registration can finish the same authorized handoff; a full page reload does not retain those secrets.
