# Phase 2 acceptance — product design, public pages and SEO

The implementation targets blueprint V3.2, Phase 2. Current execution evidence is in `PHASE2_STATUS.md`. A checklist or test file is not proof that a browser/build check ran.

## Public product and information architecture

Prerender all eleven routes: `/`, `/how-it-works`, `/premium`, `/safety`, `/privacy`, `/terms`, `/community-guidelines`, `/refund-policy`, `/grievance`, `/account-deletion` and `/contact`. Each has meaningful initial HTML, a unique title/description, one primary heading and working internal links. Public pages must work without JavaScript.

Use the shared navy, charcoal and slate design with one accent, system fonts, workplace topics and the primary CTA **Start a Conversation**. Do not use people cards, romantic imagery, gender-targeted marketing, fake activity counts or unavailable prices. Guest/Free/Premium share one population; audio and mutual friendships remain available to every tier in the finalized product. Required gender is self-declared; paid preferences never guarantee or verify a person.

The current application routes display honest unavailable shells. The separate `/design-preview` development route demonstrates planned interactions with explicit simulated-state labelling. It has no backend authority, real participants, microphone permission request, payment action or persistence.

## Phone experience first

- Widths 320,360,375,390,430 CSS px first; then 768,1024,1280,1440,1920 and intermediate widths. No page-level horizontal scrolling or clipped controls.
- Portrait/landscape, resize, 200 percent text scaling and reflow at 320 CSS px. Pinch zoom stays enabled. Native keyboard/screen-reader checks remain required on real mobile devices.
- Primary controls have 44×44 CSS px targets, visible focus and descriptive labels. Native public navigation works without JavaScript; Escape restores focus when JavaScript is active.
- Dialog/sheet close and submit controls remain reachable within the visible viewport. The design prototype uses VisualViewport events with a resize fallback; physical Android/iOS keyboard behavior must still be verified.
- Composer, Send, call and Report/Block controls stay reachable while typing. Rotation/resize preserves the current draft; explicit End/Next clears transcript and draft. Nothing enters browser storage or analytics.
- Empty, loading, busy, permission-denied, expired and failure states are inspectable. Screen-reader status updates avoid repeated announcements; reduced-motion preference is honored.

## Search and routing controls

- Public metadata and canonical URLs are present in initial HTML for approved production builds. Canonicals use exactly the approved HTTPS origin.
- Truthful WebSite, Organization and BreadcrumbList data uses real operator values and safe JSON serialization. No fabricated rating, user-count, offer or organization data.
- Open Graph includes the original 1200×630 share card and dimensions. The logo and social card are local assets.
- Only indexable public pages enter the production sitemap. Preview/staging sitemaps contain no indexable entries. Robots rules do not hide app pages from crawlers that need to see noindex.
- `/chat`, `/register`, `/login`, `/recovery`, `/profile`, `/settings`, `/friends`, `/payment/status` use noindex in both response headers and the fallback document. No-store is applied. This does not replace future authentication.
- Unknown paths return a real 404, including direct internal build-marker/fallback access. Known trailing-slash variants redirect to the canonical route.
- Staging requires access control and noindex. Production startup refuses a preview/staging artifact or a mismatched canonical origin.

## Policy release gate

Each policy/contact page has a version and review responsibility. Draft owners are roles, not fabricated officer appointments. Real operator contacts, Grievance Officer details, tax treatment, processor/retention inventory and named approvals must be supplied before publication. Review binds the actual content/configuration digest; changing approved copy or public legal values invalidates it.

Proposed refund terms remain explicitly draft until reviewed. Never turn a template into legal approval, publish placeholder contact information or create fake complaint references. The protected public complaint backend and business account/payment/deletion actions remain later implementation phases.

## Verification commands and performance

`./scripts/phase2-source-check.sh` runs dependency-free source/contract tests with host Node 24. It does not compile Svelte or prove browser compatibility. `./scripts/verify.sh` is the full Docker-based suite after authentic dependency locks have been prepared. Frontend `npm run test:e2e` checks the built site; `npm run test:design` checks the development-only interaction preview.

Before accepting Phase 2, complete Svelte/type/lint/build checks, generated HTML/CSP verification, all route/browser tests, keyboard/focus and screen-reader review, mobile-first visual QA and desktop parity. Record actual devices, browsers, tested dimensions, failures and results. Physical keyboard behavior cannot be certified by viewport resizing alone.

Keep WebRTC and checkout code off public landing pages. No production Node server, web-font subscription, analytics provider or extra hosting service is introduced. Before launch, measure lab performance; field targets when sufficient data exists are p75 LCP≤2.5s, INP≤200ms and CLS≤0.1. No ranking or performance result is implied by configuration.

The full-V1 minimum remains 200 connected participants including 25 concurrent two-person calls. Phase 2 makes no capacity benchmark claim and does not relax any finalized matching rule.
