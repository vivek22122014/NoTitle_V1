# Phase 4 delivery status

Baseline: NoTitle implementation blueprint V3.2. Date: 9 October 2026.

**Source implementation delivered; runtime acceptance pending.** This is the cumulative Phase 1–4 source, not a deployed or production-certified service. Earlier phase status files remain historical records.

## Implemented

- Cookie-authenticated, CSRF-protected one-use ticket issuance; exact-Origin `/ws`, bounded authentication, first-frame timeout and strict protocol parsing.
- One authoritative waiting pool, strict mutual gender matching, trusted entitlement/safety boundaries, bounded fading professional/topic ranking and recent-pair protection.
- Atomic pairing, generation/epoch validation, command dedupe, Next/End, explicit takeover, heartbeat, bounded slow-consumer handling and 25-second reconnect.
- Owner-private saved preferences with migration 3, optimistic version protection, guest memory preferences and explicit Everyone consent after strict entitlement expiry.
- Profile snapshots, stable guest/account slot handoff, identity revocation and a sticky fail-closed barrier for failed safety publication.
- Mobile-first live chat controls and preference editing, RAM-only secrets, reconnect/expiry/capacity feedback and desktop parity.
- Existing Caddy/Go/PostgreSQL deployment extended without an extra service; realtime defaults off in deployed environments. Explicit WebSocket shutdown and dependency outage supervision are wired.
- Protocol/OpenAPI, acceptance, deployment, security and retention documentation; Go policy/lifecycle/race/integration test sources, browser test sources and real WebSocket smoke scripts.

## Evidence collected in this workspace

| Check | Result and limit |
| --- | --- |
| Dependency-free source audit and Node tests | **65 passed, 0 failed, 0 skipped**: 62 frontend tests, including 20 realtime tests, plus 3 static deployment tests. Output is in `docs/phase4-source-check.txt`. |
| JSON and shell syntax | Parsed seven JSON files, syntax-checked eighteen shell scripts; all passed. |
| YAML | Parsed eight YAML files; passed. This is not Docker Compose runtime validation. |
| OpenAPI | JSON and all local schema references validated. |
| TypeScript/Svelte script parsing | 61 TypeScript files/Svelte script sections parsed; this does not establish Svelte compilation, types, HTML accessibility or browser rendering. |
| Raw WebSocket smoke helper | Node syntax and a synthetic local loopback handshake/fragmentation/pong/close exercise passed. This is not the Go server smoke test. |
| `./scripts/verify.sh` | Attempted; stopped because Docker/Compose is unavailable. |
| `node scripts/audit.mjs --release` | Attempted; correctly fails because genuine `server/go.sum` and `web/package-lock.json` are absent. |
| Go, PostgreSQL and browser runtime | Not executed. Go, Docker, PostgreSQL client/server and installed Svelte/Playwright dependencies are unavailable here. Ten new mocked browser tests are authored but unexecuted. No compile/race/build/load result is claimed. |

## Review fixes included

Independent source review addressed old-connection generation reuse, late detach/command ownership, lost terminal events, expired Everyone searches incorrectly pausing, shared authorization-fence refresh races, publication fallback using an expired context, and unsafe reopening after failed revocation. Review also checked peer data minimization, queue fairness, guest upgrade continuity and End during a peer's reconnect grace. Authored tests remain subject to actual execution in the required toolchain.

## Required next verification

Run `./scripts/bootstrap.sh prepare`, review generated authentic locks/formatting, then run `./scripts/verify.sh` in the supported Docker environment. Resolve any compiler, race, integration, vulnerability or browser failure before deployment. Run the additional fuzz, physical mobile/device, restart/outage/restore and load matrix in `docs/phase4-acceptance.md`.

The owner enforces **200 retained realtime participant slots and 100 waiting slots**. These are admission bounds, not proven performance. Benchmark real cookie/ticket/session renewal and database work at 200 users: background authorization alone is approximately 20 checks/second, with additional checks for commands and heartbeats. Eight authorization workers bound concurrent work; measure latency and rejection rates before accepting the current host budget.

The full-V1 requirement of **25 simultaneous two-person calls within the 200 connected users** is preserved. Audio is a later phase and is neither implemented nor load-tested here. Text delivery, report/block user workflows, friendships, payments, production moderation and final erasure/operational backup work remain later gates. Trusted paid fixtures are test-only; production authorization remains Free. No public deployment, paid account or recurring subscription was created.

Phase 4's incremental service subscription cost is **₹0/month / ₹0/year**, conditional on measured headroom in the existing host. This excludes baseline hosting/backups/network charges. See the preserved blueprint for the full operating-cost model; this phase does not replace it with unverified provider quotes.
