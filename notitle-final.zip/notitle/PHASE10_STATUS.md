# Phase 10 source delivery

Date: 2026-10-09 UTC / 2026-10-10 IST. Baseline: finalized NoTitle blueprint V3.2 and cumulative Phase 9 source. This package contains Phases 1–10; earlier status files are historical.

**Hardening, deployment controls and launch tooling are implemented in source. Full runtime acceptance and public launch remain pending.** No infrastructure, domain, merchant setting, operator account, external notification, live purchase or refund was created. No load traffic was sent to a target. The application remains mobile-first with desktop feature parity and the **200-connected / 25 simultaneous two-person call** minimum. Those capacity figures are acceptance requirements, not measured results.

## Included

- Private owner/MFA admission control with durable audit, immediate closure of new queue/invitation/call/checkout admission and a drain deadline of at most 120 seconds. Existing text/audio can finish during the announced window; remaining interactions terminate and relay cleanup starts at the deadline. Support, safety actions, provider callbacks and committed financial obligations retain their existing health/authorization checks.
- Production starts paused. Opening checks current runtime readiness and a protected source/image/schema/manifest-bound permit. Controlled production validation is separately scoped and expires within two hours with automatic drain. Ordinary final launch permits authorize an opening action; their expiry does not impose a daily service restart. Full launch requires all acceptance gates and supervised-cohort review before wider public ingress.
- Mobile bfcache/page suspension recovery, immediate visibility/offline reconciliation, expiry checks after delayed microphone permission and authoritative checkout verification after browser return. Maintenance is visible and blocks new actions while preserving End/report escape controls.
- Preview-only notices are separated from neutral production copy across application/public pages. Safety links to the implemented support workflow; build mode does not assert that runtime features are open or approved.
- Three desktop browser engines and Android/iPhone emulation in the authored CI path. Physical Android Chrome/iPhone Safari and actual desktop Chrome/Edge/Firefox/Safari remain separately required. Compiled frontend CSP and artifact markers bind canonical mode and checkout environment so mismatched builds fail preparation.
- Immutable candidate build plans with authentic-lock prerequisites, exact source fingerprints, digest-pinned build/runtime images and bounded local execution. Archive provenance uses the source fingerprint without inventing a Git commit. Plans do not push images, deploy services or grant launch approval.
- Production and isolated-acceptance configuration validators, sanitized manifests, closed-by-default deployment definitions, origin TLS/authentication, private administration, memory budgets, independent journals and protected approval files. Reviewed source CIDRs plus authenticated ingress restrict live validation. Single-owner replacement and schema-compatible rollback preserve the database and deletion/hold journals.
- Strict launch evidence checking: real artifact hashes, fresh results, named reviews, all finalized feature gates, source/image/manifest binding, physical-device records, recovery/operator drills, INR budgets and prior live-money authorization. Staging may use a different static web build for its origin and sandbox checkout; API/migration/PostgreSQL/TURN images must match production. Missing, stale, changed, failed or incomplete evidence blocks the relevant permit. This checker cannot authenticate a human signature or independently prove an attached test occurred.
- A bounded Playwright load runner for both six-hour 200/25 workloads and 400-offered overload. Synthetic microphone audio traverses the actual WebRTC controller and real TURN; sampled RTP progress, text acceptance/delivery/acknowledgement, server timing, host headroom and background work are required. Protected observation adapters preserve measurement scope and reject absent or stale inputs. Unit fixtures never masquerade as benchmark reports.
- Fixed private server timing aggregates, maintenance/authorization regressions, dependency/source checks, and launch/build/deployment/load contract tests. Ordinary chat remains RAM-only, voice is not recorded, and no new application replica, broker, database service or paid monitoring subscription is introduced.

## Executed validation

| Check | Actual result |
| --- | --- |
| `./scripts/phase10-source-check.sh` | **211 JavaScript tests passed**, zero failures/skips; **12 Python fixture tests passed**. Full output: `docs/phase10-source-check.txt`. |
| Source credential/direct-version audit | Passed. This bounded pattern scan is not a comprehensive security assessment. |
| Shell/config syntax | 24 shell scripts passed `bash -n`; 19 JSON and 12 YAML files parsed. This is not Docker, Caddy or systemd runtime validation. |
| Public API specification | 49 paths, 54 unique operations and 333 resolving local references. Private operations remain outside the public listener. |
| Actual source/evidence CLI | Repository fingerprint succeeded, including Svelte bracketed routes. `init` created a pending record; `check` correctly returned exit1 / blocked with no cohort eligibility. No permit or approval was generated. |
| Baseline preservation | All 525 Phase 9 source files retained; changes are cumulative. |
| `node scripts/audit.mjs --release` | Correctly fails for missing authentic Go/npm locks. No lockfiles were fabricated. |
| `./scripts/verify.sh` | Blocked: Docker/Compose is unavailable. |
| Backend/runtime | 25 additional Go regressions are authored, not executed. A delimiter/literal scan across 261 Go files found no imbalance; it cannot establish compilation, formatting, types, races or SQL behavior. |

These checks exercise local JavaScript/Python fixtures and static boundaries only. Go compilation/race/fuzz, real PostgreSQL/migrations, Docker/Compose/Caddy startup, Svelte compilation, Playwright/browser execution, real relay media, physical devices, recovery and live settlement remain unexecuted. Archive encryption fixtures substitute a fake executable; they do not establish real encryption-provider or restore acceptance.

The current workspace provides Node 24 and Python 3.11, but not Go/gofmt, Docker/Compose, PostgreSQL tools or the installed Svelte/Vite dependency tree. Approved Go/npm metadata requests returned HTTP 403. Authentic `server/go.sum` and `web/package-lock.json` remain absent; no checksums or lockfiles were fabricated. Release checks intentionally fail until authentic dependencies are generated, reviewed and tested on an equipped host.

## Gaps resolved

1. Maintenance readiness no longer prevents Caddy/support startup. The deployment starts web after the API process starts, while readiness remains closed for admission. Private opening checks prerequisites without requiring the gate being opened to already be green.
2. Production smoke/live settlement no longer create a circular launch prerequisite. A separate short-lived restricted validation permit requires all pre-live gates and explicit bounded transaction authorization. Genuine completed results remain intact while settlement finishes; no gate is marked passed merely to open testing.
3. Isolated load evidence is bound to an explicit acceptance deployment, not falsely described as traffic on the production origin. Only reviewed static origin/payment-mode differences are allowed; backend/relay/database image differences invalidate the mapping.
4. Source and deployment fingerprints account for generated-output and self-reference boundaries. Evidence/build outputs stay outside source; a manifest excludes only its own final digest environment field from the Compose preimage. Docker local configuration IDs are never substituted for registry manifest digests.
5. Load validation now checks text progress and server sample progression as well as connected counts/audio. Missing text delivery, frozen RTP, old observations, growing backlog, insufficient headroom or shorter runs fail acceptance. Client RTT and a coordinator probe cannot replace server processing measurements.
6. Mobile navigation and checkout-return recovery avoid stale controllers and unresolved browser SDK promises. Delayed microphone permission cannot restore expired consent or leave a late track running.
7. A long conversation no longer exhausts the old 4,096-entry receipt ledger during the specified mixed workload. The bounded limit is 16,384 accepted send IDs per interaction; existing IDs are never forgotten and retried as new messages. Ordinary text remains limited to 30 messages / 64 KiB. The raw receipt key/value payload at 100 fully populated interactions is approximately 125 MiB before map/GC overhead, so actual memory acceptance remains mandatory.
8. Private privacy operations now honor the underlying trusted-clock/deletion-readiness check before hold, release or export work. The new regression coverage is authored; Go/database execution is still pending.

## Required completion sequence

1. On an isolated equipped host, run `./scripts/bootstrap.sh prepare`, review genuine locks/formatting and execute `./scripts/verify.sh`. Resolve every compile, race, fuzz, SQL, migration, role, Svelte, browser, dependency and image-scan failure. CI has no deployment or registry-push permission.
2. Complete reviewed legal/operator/tax/privacy/merchant information, actual staffing and Phase 9 retention/notification/recovery gates. Configuration assertions do not supply these approvals or appoint people.
3. Build and scan immutable candidates using `docs/phase10-build.md`. Validate exact ordered Compose overlays and both app/relay manifests. Provision actual domain, certificates, private controls and recoverable off-host backups through the approved operator process. Initial admission stays closed.
4. Run full V1 acceptance on isolated production-like infrastructure: both six-hour workloads, overload, dense friends, security/race tests, real device/browser/network matrix, restore and drain/rollback drills. Preserve actual source/image-bound reports. If the planned 4 GiB host misses headroom or latency, optimize or resize and repeat the affected gates; do not lower the 200/25 requirement.
5. Obtain explicit live transaction authorization, all pre-live approvals and a restricted production-validation permit. Perform real production smoke and bounded authorized capture/refund/bank/settlement checks. Retain the underlying evidence without private customer data in shareable reports.
6. Validate complete final evidence, install the matching short-lived launch permit and let the named owner open a supervised cohort through private MFA. Observe a full operating cycle, financial reconciliation, staffing, capacity and cost before separately approving broader ingress. No tooling step automatically publishes the application.

Detailed instructions: `docs/phase10-acceptance.md`, `docs/phase10-build.md`, `docs/phase10-deployment.md`, `docs/phase10-capacity.md`, `docs/phase10-browser.md`, `docs/phase10-launch.md` and `docs/phase10-evidence-template.md`.

## Cost and capacity assumptions

Phase 10 introduces **₹0 fixed software subscription/month or year**. The retained blueprint planning budget is approximately **₹4,100/month / ₹49,200/year**, plus transaction fees and the blueprint's stated exclusions. Storage/transfer, host growth and human/legal work still cost money. This is an inherited planning figure, not a newly verified provider quote. Temporary acceptance infrastructure, browser generators, test devices and authorized live transaction costs also need a budget; existing workstation capacity may cover some of them.

The initial topology remains one Go owner/static Caddy/PostgreSQL app host and one separate TURN host. Planned app limits are PostgreSQL 1,280 MiB, Go 768 MiB and Caddy 192 MiB on a 4 GiB host; operating-system cache, backup work and real traffic still require measured headroom. A 200/25 test must retain at least 25% host memory availability and at least 1 GiB. Ordinary API p95 must stay below 300 ms, text processing below 100 ms, compatible matching below 1 s and call setup below 10 s with at least 95% success on supported networks. Review growth around 140 connections / 18 calls and the existing resource/backlog thresholds. No capacity, price or availability guarantee is implied by these templates.
