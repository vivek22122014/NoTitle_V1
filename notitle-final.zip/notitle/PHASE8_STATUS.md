# Phase 8 source delivery

Date: 2026-10-09. Baseline: NoTitle V1 implementation blueprint V3.2 and cumulative Phase 7 source. This package contains Phases 1–8; earlier status files describe historical deliveries.

**Implemented in source; financial runtime and production acceptance remain pending.** No merchant account, production credentials, public deployment, payment, refund or transfer was created. The minimum remains **200 connected participants including 25 simultaneous two-person calls**, with mobile-first layouts and desktop feature parity. That capacity has not been benchmarked.

## Included

- Account-only Cashfree hosted checkout for immutable versioned plans, integer-paise order snapshots and stable idempotency references. Intent commits before external work; a lost/unknown response recovers the same purchase. Genuine payment-only phone contact stays transient; registration remains phone/email-free.
- Shared server verification for browser return, signed webhooks and reconciliation. Browser/SDK success never grants access. Provider order, customer reference, environment, merchant, currency, amount, captured payment and refund associations are validated. Multiple attempts are retained; duplicate captures grant once and create financial review obligations.
- A raw-signature-verified, bounded, minimal webhook inbox with durable acknowledgement, finite leased jobs, retry/review handling, five-minute reconciliation scheduling, daily paginated comparison and catch-up watermarks. Provider requests run outside transactions and the realtime owner. Processing and new checkout admission have separate switches.
- Account-locked FIFO duration lots and append-only adjustment history. Additional purchases stack exact continuous hours, including offline. Rebuild and parity-check routines preserve consumption, holds, restores, revocations and the originating capture. Routine authorization reads project elapsed time without appending periodic consumption events.
- Coordinator mutation fences and acknowledged publication. Paid matching waits for durable usage against the active lot; expiry is checked at queue admission and match commit. Specific preferences pause on lost eligibility and require explicit Everyone consent. Existing conversations and all previous matching/safety/audio rules are preserved.
- Private MFA billing roles, audited financial views and signed refund previews. Full refunds hold only the originating lot's unused time; definitive failure restores it from resolution time. Partial refunds default to money-only; an exact duration reduction needs an explicit reviewed preview. Dashboard refunds, disputes, late/deleted-account captures and reconciliation exceptions enter restricted review.
- Mobile-first `/account/premium`, checkout/return recovery, original receipts, historical reference lookup, refund tracking and owner-only Premium updates. No payment contact, session token or financial state is placed in browser persistence. SDK loading and exact CSP origins are gated separately at build time.
- Schema 7 migration, immutable snapshot/least-privilege barriers, retained financial records, protected credential overlay, clock-step readiness latch, OpenAPI, threat/retention updates, operations/acceptance runbooks, source regressions and disposable default-off smoke checks. Staging exempts only the exact signed webhook path from its browser password.

## Executed evidence

| Check | Actual outcome |
| --- | --- |
| `./scripts/phase8-source-check.sh` | **128 passed, 0 failed, 0 skipped:** 125 frontend Node tests and 3 deployment/source tests. Output: `docs/phase8-source-check.txt`. |
| Source credential-pattern/direct-version audit | Passed. This is a limited source scan, not a comprehensive security audit. |
| TypeScript/Svelte script syntax | 88 executable script sections parsed after type stripping. No import resolution, typecheck or Svelte markup compilation claim. |
| Shell/JSON/YAML syntax | 22 shell scripts passed `bash -n`; 7 JSON and 11 YAML files parsed. Docker Compose/Caddy runtime behavior remains unverified. |
| Public OpenAPI | 37 paths, 41 unique operations and 207 resolving local references. Private billing routes are not mounted publicly. |
| `./scripts/verify.sh` | Stopped: Docker/Compose is unavailable. |
| `node scripts/audit.mjs --release` | Failed as intended: authentic `web/package-lock.json` and `server/go.sum` remain absent. No locks were fabricated. |
| Go/PostgreSQL/browser/provider execution | Not run. Go, gofmt, Docker and psql are unavailable; the project frontend dependencies and browsers are not installed. No sandbox or live financial result is claimed. |

New Go tests and a ledger conservation fuzz target are authored for transactional grants, concurrency/idempotency, refunds/disputes, replay, provider/webhook boundaries, private/public authorization, coordinator publication and schema privileges. Twelve payment browser cases cover mobile/desktop UI and mocked SDK behavior. These are unexecuted test sources, not passing acceptance evidence.

## Activation and operating limits

1. On a supported isolated Docker host, run `./scripts/bootstrap.sh prepare`, generate authentic locks, review formatter changes and run `./scripts/verify.sh`. Resolve every compiler, race, database, migration, dependency, Svelte and browser failure. Migration reversal is for disposable fixtures only; retained financial records must not be rolled back.
2. Review `deploy/payments/README.md` and `docs/phase8-payments.md`. Provision protected Cashfree files and separate sandbox data, publish reviewed catalog versions through the migration/operator role, and execute `docs/phase8-acceptance.md`. All four seeded plans start disabled with pending tax treatment. Default builds load no checkout SDK.
3. Record merchant underwriting for the actual guest/random text/audio/friendship/paid-preference product, approved tax/invoice/privacy/refund/contact policies, named billing operators, monitored exception handling and an explicitly authorized live capture→receipt→refund→settlement check. Booleans do not establish these approvals. Annual sales additionally require approved economics and a workable later-refund procedure.
4. Exercise real mobile and desktop checkout, callback loss, provider outages, duplicate captures, refund uncertainty, deleted-account events, dashboard refunds/disputes, restore/reconciliation and projection rebuild. The process-local clock guard detects wall-clock steps; it cannot establish absolute NTP accuracy. Monitor host clock health independently.
5. Run both six-hour 200-connected/25-call mixed workloads with actual relay media plus payments, refunds, hashing, moderation, reconnects and backups. Measure database wait, worker backlog, matching latency, CPU/RSS and memory headroom. Configured limits and mocked tests are not performance proof.

`PAYMENTS_ENABLED=false` and `CHECKOUT_ENABLED=false` remain in both base stacks. Once obligations exist, keep processing configured and stop new purchases with `CHECKOUT_ENABLED=false`; existing entitlement/receipt reads remain available. Keep the same merchant/environment when changing admission. Unknown payment/refund outcomes retain their stable references and reconcile before retry. Bank-credit timing is never fabricated.

The adjustment ledger is the durable source of entitlement revisions. Within this single process, publication recovery uses a bounded in-memory fence retry; after restart no old owner survives and every participant obtains fresh ledger authorization. There is no separate broker or distributed outbox delivery claim. Known success without a grant produces a review obligation after five minutes; operators must monitor it. Automatic financial review does not itself contact or compensate a customer.

Phase 8 adds **₹0 fixed service subscription** if measured demand fits the already planned app/database host. The retained blueprint planning target is approximately **₹4,100/month or ₹49,200/year** including its infrastructure reserve, plus transaction fees, staffing, refund liquidity, chargebacks, tax liabilities and excess usage. These are existing budget assumptions, not newly verified provider quotations. Detailed INR scenarios and exclusions are in the payments runbook.

One gap in prior documentation was resolved: block management is under `/chat` → **Manage your blocks**, not a nonexistent `/blocks` page. The existing business features, roles and workflows are retained; no extra queue host, Redis, subscription billing, outgoing email service or permanent staging expense was introduced.
