import { defineConfig, devices } from '@playwright/test';
import base from './playwright.config';

// Synthetic routed API/transport fixtures exercise rendered UI in three engines.
// These projects are not physical Android/iPhone or branded Safari/Edge evidence.
export default defineConfig({
  ...base,
  use: { ...base.use, trace: 'off', screenshot: 'off', video: 'off' },
  projects: [
    { name: 'chromium-desktop-fixtures', use: { ...devices['Desktop Chrome'] } },
    { name: 'firefox-desktop-fixtures', use: { ...devices['Desktop Firefox'] } },
    { name: 'webkit-desktop-fixtures', use: { ...devices['Desktop Safari'] } },
    { name: 'chromium-android-emulation', use: { ...devices['Pixel 7'] } },
    { name: 'webkit-iphone-emulation', use: { ...devices['iPhone 13'] } }
  ]
});
