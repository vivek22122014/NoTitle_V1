import { defineConfig, devices } from '@playwright/test';
export default defineConfig({
  testDir: './tests', testMatch: '**/payments.preview.ts', fullyParallel: true,
  forbidOnly: Boolean(process.env.CI), retries: process.env.CI ? 1 : 0,
  workers: process.env.CI ? 1 : undefined, reporter: process.env.CI ? 'github' : 'list',
  use: { baseURL: 'http://127.0.0.1:5175', trace: 'off' },
  projects: [{ name: 'chromium-payments-fixtures', use: { ...devices['Desktop Chrome'] } }],
  webServer: {
    command: 'npm run dev -- --host 127.0.0.1 --port 5175 --strictPort', url: 'http://127.0.0.1:5175/premium',
    env: { PUBLIC_CHECKOUT_SDK_ENABLED: 'true', PUBLIC_CHECKOUT_ENVIRONMENT: 'sandbox', PUBLIC_RELEASE_MODE: 'preview' },
    reuseExistingServer: false, timeout: 30000
  }
});
