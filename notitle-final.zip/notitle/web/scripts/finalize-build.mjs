import { readFile, writeFile, stat, readdir } from 'node:fs/promises';
import { gzipSync, brotliCompressSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { readRelease } from './release-config.mjs';
import { verifyBuildCSP } from './build-csp.mjs';
import { publicPaths, appPaths } from '../src/lib/config/routes.mjs';
import { hashStructuredData, verifyPublicHtml, attribute, metaContent } from './seo-html.mjs';

const root = new URL('../build/', import.meta.url);
const { marker } = await readRelease();
const titles = new Set();
const descriptions = new Set();

async function writeCompressed(name, html) {
  await writeFile(new URL(name, root), html);
  await writeFile(new URL(name + '.gz', root), gzipSync(html));
  await writeFile(new URL(name + '.br', root), brotliCompressSync(html));
}

for (const path of publicPaths) {
  const name = path === '/' ? 'index.html' : path.slice(1) + '.html';
  const html = hashStructuredData(await readFile(new URL(name, root), 'utf8'));
  verifyBuildCSP(html, process.env);
  const metadata = verifyPublicHtml(html, path, marker);
  if (titles.has(metadata.title) || descriptions.has(metadata.description)) throw new Error('Public titles and descriptions must be unique');
  titles.add(metadata.title);
  descriptions.add(metadata.description);
  for (const match of html.matchAll(/<a\b[^>]*>/giu)) {
    const href = attribute(match[0], 'href');
    if (!href.startsWith('/') || href.startsWith('//')) continue;
    const target = new URL(href, 'https://routing.invalid').pathname;
    if (!publicPaths.includes(target) && !appPaths.includes(target)) throw new Error(path + ': unsupported internal link ' + target);
  }
  await writeCompressed(name, html);
}

let shell = await readFile(new URL('app.html', root), 'utf8');
if (!metaContent(shell, 'robots')) shell = shell.replace('</head>', '<meta name="robots" content="noindex, nofollow" /></head>');
if (!metaContent(shell, 'robots').includes('noindex')) throw new Error('App fallback must be noindex');
shell = hashStructuredData(shell);
const compiledCheckout = verifyBuildCSP(shell, process.env);
if (JSON.stringify(compiledCheckout) !== JSON.stringify(marker.checkout)) throw new Error('Compiled checkout differs from release marker');
await writeCompressed('app.html', shell);

const sitemap = await readFile(new URL('sitemap.xml', root), 'utf8');
const locations = [...sitemap.matchAll(/<loc>([^<]+)<\/loc>/gu)].map((match) => match[1]);
const expected = marker.mode === 'production' ? publicPaths.map((path) => marker.origin + path) : [];
if (JSON.stringify([...locations].sort()) !== JSON.stringify(expected.sort())) throw new Error('Sitemap must contain exactly the indexable public URLs');
const robots = await readFile(new URL('robots.txt', root), 'utf8');
if (/Disallow:\s*\//iu.test(robots)) throw new Error('Crawlers must be able to see noindex directives');
if (marker.mode === 'production' && !robots.includes('Sitemap: ' + marker.origin + '/sitemap.xml')) throw new Error('Production robots.txt must refer to the canonical sitemap');

// A small static error document works without JavaScript and keeps HTTP status404.
const style = 'html{color-scheme:dark;font-family:system-ui,sans-serif;background:#101a25;color:#edf3f8}body{margin:0}main{max-width:42rem;margin:auto;padding:clamp(2rem,8vw,6rem) 1.25rem}h1{font-size:clamp(2rem,7vw,3.5rem);line-height:1.15}p{line-height:1.7;color:#cad4df}a{display:inline-flex;min-height:44px;align-items:center;color:#84dfcd}a:focus-visible{outline:3px solid #84dfcd;outline-offset:5px}';
const styleHash = createHash('sha256').update(style).digest('base64');
await writeCompressed('404.html', `<!doctype html><html lang="en-IN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta http-equiv="content-security-policy" content="default-src 'none'; style-src 'sha256-${styleHash}'; base-uri 'none'; form-action 'none'"><title>Page Not Found | NoTitle</title><style>${style}</style></head><body><main><p>NoTitle · 404</p><h1>This page isn’t here.</h1><p>Check the address or return to NoTitle. No conversation or account action has been started.</p><a href="/">Return to the homepage</a></main></body></html>`);
await writeFile(new URL('notitle-build.json', root), JSON.stringify(marker, null, 2) + '\n');
await stat(new URL('_app/', root));
await stat(new URL('social-card.png', root));

async function rejectSourceMaps(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const child = new URL(entry.name + (entry.isDirectory() ? '/' : ''), directory);
    if (entry.isDirectory()) await rejectSourceMaps(child);
    else if (entry.name.endsWith('.map')) throw new Error('Public source maps are forbidden in this build');
  }
}
await rejectSourceMaps(root);
console.log(`Verified ${publicPaths.length} public documents, metadata, JSON-LD CSP, links, sitemap, noindex fallback and real 404 for ${marker.mode}.`);
