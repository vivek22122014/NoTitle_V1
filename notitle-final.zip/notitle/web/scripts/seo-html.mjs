import { createHash } from 'node:crypto';

/** @param {string} value */
export function escapeAttribute(value) {
  return value.replaceAll('&', '&amp;').replaceAll('"', '&quot;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
}
/** @param {string} value */
export function decodeAttribute(value) {
  return value.replaceAll('&quot;', '"').replaceAll('&#39;', "'").replaceAll('&apos;', "'").replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&amp;', '&');
}
/** @param {string} tag @param {string} name */
export function attribute(tag, name) {
  return decodeAttribute(new RegExp(String.raw`\b${name}\s*=\s*(["'])(.*?)\1`, 'iu').exec(tag)?.[2] || '');
}
/** @param {string} html @param {string} name */
export function metaContent(html, name) {
  const tag = [...html.matchAll(/<meta\b[^>]*>/giu)].find((match) => attribute(match[0], 'name') === name || attribute(match[0], 'property') === name);
  return tag ? attribute(tag[0], 'content') : '';
}
/**
 * Svelte hashes its own bootstrap. Raw JSON-LD inserted with @html may not be
 * included; add hashes for JSON-LD only, never bless arbitrary executable code.
 * @param {string} html
 */
export function hashStructuredData(html) {
  const policyTag = [...html.matchAll(/<meta\b[^>]*>/giu)].find((match) => attribute(match[0], 'http-equiv').toLowerCase() === 'content-security-policy')?.[0];
  if (!policyTag) throw new Error('Svelte-generated CSP is missing');
  let policy = attribute(policyTag, 'content');
  if (!/script-src[^;]*sha256-/u.test(policy) || policy.includes("'unsafe-inline'") || policy.includes("'unsafe-eval'")) throw new Error('A hashed, restricted script CSP is required');
  for (const match of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/giu)) {
    if (attribute('<script ' + match[1] + '>', 'type') !== 'application/ld+json') continue;
    JSON.parse(match[2]);
    const hash = "'sha256-" + createHash('sha256').update(match[2]).digest('base64') + "'";
    if (!policy.includes(hash)) policy = policy.replace(/(script-src\s+[^;]+)/u, '$1 ' + hash);
  }
  return html.replace(policyTag, '<meta http-equiv="content-security-policy" content="' + escapeAttribute(policy) + '">');
}

/** @param {string} html @param {string} path @param {{mode:string,origin:string|null}} marker */
export function verifyPublicHtml(html, path, marker) {
  const issues = [];
  const title = /<title>([^<]+)<\/title>/iu.exec(html)?.[1] || '';
  const description = metaContent(html, 'description');
  if (!title || !description) issues.push('Route metadata is missing');
  if ([...html.matchAll(/<title\b/giu)].length !== 1) issues.push('Exactly one title is required');
  if ([...html.matchAll(/<h1\b/giu)].length !== 1) issues.push('Exactly one prerendered heading is required');
  if (metaContent(html, 'og:title') !== decodeAttribute(title) || metaContent(html, 'og:description') !== description) issues.push('Open Graph metadata must match the route');
  const canonicalTags = [...html.matchAll(/<link\b[^>]*>/giu)].filter((match) => attribute(match[0], 'rel') === 'canonical');
  const robots = metaContent(html, 'robots');
  if (marker.mode === 'production') {
    if (canonicalTags.length !== 1 || attribute(canonicalTags[0][0], 'href') !== marker.origin + path) issues.push('Canonical does not match the approved route');
    if (robots !== 'index, follow') issues.push('Approved public route must be indexable');
    const graphs = [...html.matchAll(/<script\b[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/giu)].map((match) => JSON.parse(match[1]));
    const types = graphs.flatMap((graph) => graph['@graph']?.map((node) => node['@type']) || []);
    for (const type of path === '/' ? ['WebSite', 'Organization'] : ['WebSite', 'Organization', 'BreadcrumbList']) if (!types.includes(type)) issues.push('Missing truthful structured data: ' + type);
  } else {
    if (canonicalTags.length || metaContent(html, 'og:url')) issues.push('Unapproved builds must not declare production canonicals');
    if (!robots.split(/[,\s]+/u).includes('noindex')) issues.push('Preview and staging must be noindex');
  }
  if (issues.length) throw new Error(path + ': ' + issues.join('; '));
  return { title, description };
}

