// Test-only loopback server for generated output. Production uses Caddy.
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { appPaths, publicPaths } from '../src/lib/config/routes.mjs';

const defaultRoot = path.resolve(fileURLToPath(new URL('../build/', import.meta.url)));
const assetPaths = new Set(['/favicon.svg', '/logo.svg', '/social-card.png', '/robots.txt', '/sitemap.xml']);
const knownPaths = new Set([...publicPaths, ...appPaths]);
const types = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.json': 'application/json',
  '.png': 'image/png', '.webp': 'image/webp', '.woff2': 'font/woff2',
  '.xml': 'application/xml; charset=utf-8', '.txt': 'text/plain; charset=utf-8'
};

export function createBuiltServer({ root = defaultRoot } = {}) {
  root = path.resolve(root);
  return createServer(async (req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Security-Policy', "frame-ancestors 'none'");
    res.setHeader('X-Robots-Tag', 'noindex, nofollow');
    res.setHeader('Cache-Control', 'no-store');

    async function notFound() {
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      let html;
      try { html = await readFile(path.join(root, '404.html')); }
      catch { html = '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="robots" content="noindex"><title>Page not found | NoTitle</title><h1>Page not found</h1><a href="/">Return home</a></html>'; }
      res.writeHead(404);
      res.end(req.method === 'HEAD' ? undefined : html);
    }

    let pathname;
    try { pathname = decodeURIComponent(new URL(req.url ?? '/', 'http://127.0.0.1').pathname); }
    catch { res.writeHead(400).end(); return; }
    if (pathname.includes('\\') || pathname.includes('\0') || pathname.split('/').some((part) => part === '.' || part === '..')) {
      await notFound(); return;
    }
    if (!['GET', 'HEAD'].includes(req.method ?? '')) {
      res.writeHead(405, { Allow: 'GET, HEAD' }).end(); return;
    }
    if (pathname !== '/' && pathname.endsWith('/') && knownPaths.has(pathname.slice(0, -1))) {
      res.writeHead(308, { Location: pathname.slice(0, -1) }).end(); return;
    }
    let relative;
    if (pathname === '/') relative = 'index.html';
    else if (publicPaths.includes(pathname)) relative = pathname.slice(1) + '.html';
    else if (appPaths.includes(pathname)) relative = 'app.html';
    else if (assetPaths.has(pathname) || (pathname.startsWith('/_app/') && Object.hasOwn(types, path.extname(pathname)) && path.extname(pathname) !== '.html')) relative = pathname.slice(1);
    else { await notFound(); return; }
    const filename = path.resolve(root, relative);
    if (!filename.startsWith(root + path.sep)) { await notFound(); return; }
    try {
      const body = await readFile(filename);
      res.setHeader('Content-Type', types[path.extname(filename)] ?? 'application/octet-stream');
      res.setHeader('Cache-Control', pathname.startsWith('/_app/immutable/') ? 'public, max-age=31536000, immutable' : appPaths.includes(pathname) ? 'no-store' : 'no-cache');
      res.writeHead(200);
      res.end(req.method === 'HEAD' ? undefined : body);
    } catch { await notFound(); }
  });
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  createBuiltServer().listen(4173, '127.0.0.1');
}
