import { readFile, readdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { resolve, relative, sep } from 'node:path';
import { httpsOrigin, releaseMode, releaseIssues } from '../src/lib/config/release-policy.mjs';
import { paymentSources } from '../src/lib/config/payment-csp.mjs';

export const webRoot = fileURLToPath(new URL('../', import.meta.url));

export async function contentDigest(root = webRoot) {
  const paths = [];
  async function visit(directory) {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const path = resolve(directory, entry.name);
      if (entry.isSymbolicLink()) throw new Error('Release content cannot contain symbolic links');
      if (entry.isDirectory()) await visit(path);
      else if (entry.isFile()) paths.push(path);
    }
  }
  await visit(resolve(root, 'src'));
  await visit(resolve(root, 'static'));
  paths.push(resolve(root, 'config/plans.json'));
  const hash = createHash('sha256');
  for (const path of paths.sort()) {
    const bytes = await readFile(path);
    hash.update(relative(root, path).split(sep).join('/') + '\0' + bytes.length + '\0');
    hash.update(bytes);
  }
  // Bind every public legal value and review record. Exclude only the digest
  // itself to avoid a circular hash; contact/tax changes require fresh approval.
  const inventory = JSON.parse(await readFile(resolve(root, 'config/release.json'), 'utf8'));
  if (inventory.approvals) delete inventory.approvals.contentSha256;
  hash.update('config/release.json\0' + JSON.stringify(inventory));
  return hash.digest('hex');
}

export async function readRelease(environment = process.env) {
  const mode = releaseMode(environment.PUBLIC_RELEASE_MODE);
  const payment = paymentSources(environment);
  const origin = httpsOrigin(environment.PUBLIC_SITE_ORIGIN, mode !== 'preview');
  const releaseBytes = await readFile(resolve(webRoot, 'config/release.json'), 'utf8');
  const catalogBytes = await readFile(resolve(webRoot, 'config/plans.json'), 'utf8');
  const release = JSON.parse(releaseBytes);
  const catalog = JSON.parse(catalogBytes);
  const issues = releaseIssues(release, catalog, { mode, origin });
  const contentSha256 = await contentDigest();
  if (mode === 'production' && release.approvals?.contentSha256 !== contentSha256) issues.push('Reviewed public source digest does not match current content; review and approve this revision');
  if (issues.length) throw new Error('Release rejected:\n- ' + issues.join('\n- '));
  return { release, catalog, marker: {
    schemaVersion: 2, mode, origin, legalApproved: mode === 'production', contentSha256,
    checkout: { enabled: payment.enabled, environment: payment.environment },
    inventorySha256: createHash('sha256').update(releaseBytes).update('\0').update(catalogBytes).digest('hex')
  } };
}
