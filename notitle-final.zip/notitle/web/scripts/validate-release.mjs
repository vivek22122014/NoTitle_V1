import { contentDigest, readRelease } from './release-config.mjs';

try {
  if (process.argv.includes('--digest')) console.log(await contentDigest());
  else {
    const environment = process.argv.includes('--production') ? { ...process.env, PUBLIC_RELEASE_MODE: 'production' } : process.env;
    const { marker } = await readRelease(environment);
    console.log(`Release configuration accepted for ${marker.mode}. This is not legal approval or a launch certification.`);
  }
} catch (error) {
  console.error(error instanceof Error ? error.message : 'Release validation failed');
  process.exitCode = 1;
}
