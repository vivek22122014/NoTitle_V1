import { attribute } from './seo-html.mjs';
import { paymentSources } from '../src/lib/config/payment-csp.mjs';
import { realtimeConnectSources } from '../src/lib/config/realtime-csp.mjs';

/** Verify compiled output against the exact build controls, including the
 * production checkout candidate. This does not contact the payment provider.
 * @param {string} html
 * @param {Record<string, string | undefined>} environment
 */
export function verifyBuildCSP(html, environment) {
  const tags = [...html.matchAll(/<meta\b[^>]*>/giu)].filter((match) => attribute(match[0], 'http-equiv').toLowerCase() === 'content-security-policy');
  if (tags.length !== 1) throw new Error('Exactly one compiled document CSP is required');
  /** @type {Map<string, string[]>} */
  const directives = new Map();
  for (const part of attribute(tags[0][0], 'content').split(';')) {
    const [name, ...values] = part.trim().split(/\s+/u);
    if (!name) continue;
    if (directives.has(name)) throw new Error('Duplicate compiled CSP directive');
    directives.set(name, values);
  }
  const payment = paymentSources(environment);
  const script = directives.get('script-src');
  const scriptBase = ["'self'", ...payment.script];
  if (!script || !script.some((value) => /^'sha256-[A-Za-z0-9+/]{43}='$/.test(value)) || !scriptBase.every((value) => script.includes(value)) || script.some((value) => !scriptBase.includes(value) && !/^'sha256-[A-Za-z0-9+/]{43}='$/.test(value))) throw new Error('Compiled script CSP differs from checkout build controls');
  // Extra script directives could override the verified script-src boundary.
  if (directives.has('script-src-elem') || directives.has('script-src-attr')) throw new Error('Unexpected compiled script CSP override');
  const connect = directives.get('connect-src') ?? [];
  const expected = [...realtimeConnectSources(environment).map((value) => value === 'self' ? "'self'" : value), ...payment.connect];
  if (new Set(connect).size !== connect.length || connect.length !== expected.length || expected.some((value) => !connect.includes(value))) throw new Error('Compiled connect CSP differs from checkout/realtime build controls');
  if (JSON.stringify(directives.get('frame-src')) !== JSON.stringify(["'none'"]) || JSON.stringify(directives.get('form-action')) !== JSON.stringify(["'self'"])) throw new Error('Compiled checkout must retain full-page navigation boundaries');
  for (const match of html.matchAll(/<script\b[^>]*>/giu)) {
    const src = attribute(match[0], 'src');
    if (src && (!src.startsWith('/') || src.startsWith('//'))) throw new Error('Compiled document must not preload an external payment SDK');
  }
  return { enabled: payment.enabled, environment: payment.environment };
}
