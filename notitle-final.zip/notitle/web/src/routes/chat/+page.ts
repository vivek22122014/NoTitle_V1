// Only the explicit application route allowlist receives app.html at the edge.
// Identity requests start after hydration; no private data enters static HTML.
export const prerender = false;
export const ssr = false;
