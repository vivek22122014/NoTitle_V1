<script lang="ts">
  import Seo from '$lib/components/Seo.svelte';
  import IdentityScreen from '$lib/identity/IdentityScreen.svelte';
</script>

<Seo path="/chat" />
<IdentityScreen mode="guest" />
