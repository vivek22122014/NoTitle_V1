<script lang="ts">
  import '../app.css';
  import { onMount } from 'svelte';
  import AudioPlayer from '$lib/audio/AudioPlayer.svelte';
  import InvitationBar from '$lib/friends/InvitationBar.svelte';
  import ConnectionBar from '$lib/realtime/ConnectionBar.svelte';
  import MaintenanceBar from '$lib/realtime/MaintenanceBar.svelte';
  import { currentRealtime, resetRealtime } from '$lib/realtime/session';
  onMount(() => {
    const suspend = () => currentRealtime()?.suspendPage();
    const resume = () => { if (document.visibilityState === 'visible') currentRealtime()?.resumePage(); };
    const offline = () => currentRealtime()?.interruptNetwork();
    window.addEventListener('pagehide', suspend);
    document.addEventListener('freeze', suspend);
    window.addEventListener('pageshow', resume);
    window.addEventListener('online', resume);
    window.addEventListener('offline', offline);
    document.addEventListener('resume', resume);
    document.addEventListener('visibilitychange', resume);
    return () => {
      window.removeEventListener('pagehide', suspend); document.removeEventListener('freeze', suspend);
      window.removeEventListener('pageshow', resume); window.removeEventListener('online', resume); window.removeEventListener('offline', offline);
      document.removeEventListener('resume', resume); document.removeEventListener('visibilitychange', resume); resetRealtime();
    };
  });
  import AppFooter from '$lib/components/AppFooter.svelte';
  import AppHeader from '$lib/components/AppHeader.svelte';
</script>

<div class="page-shell">
  <a class="skip-link" href="#main-content">Skip to content</a>
  <AppHeader />
  <main id="main-content" tabindex="-1">
    <MaintenanceBar />
    <ConnectionBar />
    <InvitationBar />
    <AudioPlayer />
    <slot />
  </main>
  <AppFooter />
</div>
