<script lang="ts">
  import { page } from '$app/stores';
  import Button from '$lib/components/Button.svelte';
</script>

<svelte:head>
  <title>{$page.status === 404 ? 'Page not found' : 'Unable to load page'} | NoTitle</title>
  <meta name="robots" content="noindex, nofollow" />
</svelte:head>

<section class="error-page content-width">
  <p class="code">{$page.status}</p>
  <h1>{$page.status === 404 ? 'This page isn’t here.' : 'We couldn’t load this page.'}</h1>
  <p>{$page.status === 404 ? 'Check the address or head back to NoTitle.' : 'Please try again in a moment.'}</p>
  <Button href="/">Return home</Button>
</section>

<style>
  .error-page { min-height: 60dvh; display: grid; align-content: center; justify-items: start; padding-block: 3rem; }
  .code { margin: 0; color: var(--accent-strong); font-weight: 800; }
  h1 { margin: 0.35rem 0 0.75rem; font-size: clamp(2rem, 8vw, 3.5rem); line-height: 1.1; }
  p:not(.code) { max-width: 38rem; color: var(--text-secondary); }
</style>
