<script lang="ts">
  import SupportAvailability from '$lib/support/SupportAvailability.svelte';
  import PolicyPage from '$lib/components/PolicyPage.svelte';
  import Seo from '$lib/components/Seo.svelte';
  import { release, site } from '$lib/config/site';
  const contents = [
    { id: 'availability', label: 'Support availability' },
    { id: 'operator', label: 'Operator details' },
    { id: 'routes', label: 'Find the right information' },
    { id: 'prepare', label: 'What to include in a request' }
  ];
</script>

<Seo path="/contact" />
<PolicyPage path="/contact" title="Contact" introduction="Support should be easy to find and clear about what happens next." {contents}>
  <section id="availability">
    <h2>Support availability</h2>
    <SupportAvailability />
    <p>The support workflow provides protected cases and in-app replies when the monitored service is enabled, including public access for people without an account. Normal registration, recovery and support will not require an email address. NoTitle will not add an outgoing application-email service; a payment gateway or bank may have its own required notifications.</p>
  </section>
  <section id="operator">
    <h2>Operator details</h2>
    {#if site.production}
      <p><strong>{release.operator.legalName}</strong></p>
      <address>{release.operator.address}</address>
      <p><a href={`mailto:${release.operator.email}`}>{release.operator.email}</a></p>
      {#if release.operator.phone}<p>{release.operator.phone}</p>{/if}
    {:else}
      <p>The business owner must supply the verified legal operator name, address and required contact information before publication. Those details have not been provided, so this draft does not show a fabricated business identity or email address.</p>
    {/if}
    <p>Formal grievance handling has a separate responsible officer and review process. See <a href="/grievance">Grievances and appeals</a>.</p>
  </section>
  <section id="routes">
    <h2>Find the right information</h2>
    <ul>
      <li><a href="/safety">Safety guidance</a> — how the planned conversation controls will help you leave, report or block.</li>
      <li><a href="/grievance">Grievances and appeals</a> — the planned formal complaint and decision-review process.</li>
      <li><a href="/privacy">Privacy</a> — what peers see and the information the service handles.</li>
      <li><a href="/account-deletion">Account deletion</a> — access disablement, request status and retention limits.</li>
      <li><a href="/refund-policy">Refund policy</a> — the proposal awaiting approval before purchases open.</li>
    </ul>
  </section>
  <section id="prepare">
    <h2>What to include in a request</h2>
    <p>Describe the issue, what happened and any relevant reference you already have. Do not share passwords, recovery codes, full card details or another person’s private information. Use only the information necessary for that type of request. A submission is not verified account ownership.</p>
    <p>After a real complaint submission, save its private status secret securely so you can return to protected replies. Use the <a href="/support">support form</a> to check current availability, or <a href="/support/case">open a saved case</a>. Reading this page does not submit a concern.</p>
  </section>
</PolicyPage>
