<script lang="ts">
  import PolicyPage from '$lib/components/PolicyPage.svelte';
  import Seo from '$lib/components/Seo.svelte';
  import { release, site } from '$lib/config/site';
  const retentionLabels: Record<string, string> = {
    ordinary_text: 'Ordinary text', report_draft: 'Report drafts', audio: 'Audio and relay traffic',
    guest_state: 'Guest state', pending_invitations: 'Pending invitations', recent_pairs: 'Recent-pair state',
    accounts_and_friends: 'Accounts and friendships', registration_and_removed_content: 'Registration and removed-content records',
    case_evidence: 'Case evidence', security_logs: 'Security logs', financial_records: 'Financial records',
    backups: 'Backups', aggregate_metrics: 'Aggregated metrics'
  };
  const contents = [
    { id: 'visibility', label: 'What other people see' },
    { id: 'information', label: 'Information the service handles' },
    { id: 'conversation-data', label: 'Conversations, audio and reports' },
    { id: 'retention', label: 'Retention and service providers' },
    { id: 'choices', label: 'Your choices and requests' }
  ];
</script>

<Seo path="/privacy" />
<PolicyPage path="/privacy" title="Privacy" introduction="Anonymous to the people you meet. That is a limited promise, and the details matter." {contents}>
  {#if site.production}
    <section aria-labelledby="approved-notice-heading">
      <h2 id="approved-notice-heading">Approved privacy notice</h2>
      <p>{release.privacy.statement}</p>
      <p>Reviewed {release.privacy.reviewedAt}. Retention version: {release.privacy.retentionVersion}.</p>
    </section>
  {/if}
  <section id="visibility">
    <h2>What other people see</h2>
    <p>The planned conversation screen shows your display name or session pseudonym, your selected topic, an optional Bio and a required, self-declared <strong>M / F / Other</strong> gender label. You will choose Male, Female or Other / Non-binary before entering, with no preselected answer. No proof of gender is requested.</p>
    <p>Your private username, account identifier, professional profile, matching preferences, Premium status and payment details are not intended to be visible to conversation partners. Professional details and gender are self-declared, not verified qualifications or identity checks.</p>
    <p>Other people may recognise something you share, take screenshots or record outside NoTitle. Avoid identifying yourself, colleagues, clients or your employer when you do not intend to disclose that information.</p>
  </section>
  <section id="information">
    <h2>Information the service handles</h2>
    <ul>
      <li><strong>Guest choices:</strong> temporary identity, required gender, topic, optional professional details and the state needed for matching and safety.</li>
      <li><strong>Accounts:</strong> a private username, password verifier, recovery-code verifier, pseudonym, optional Bio and profile, preferences, sessions and accepted account friendships. Normal registration will not require a phone number, email address, date of birth, employer or identity document.</li>
      <li><strong>Safety and support:</strong> reports you choose to submit, relevant available evidence, blocks, case replies and the information needed to assess and audit a decision.</li>
      <li><strong>Payments:</strong> purchase references, amounts, entitlement and refund records. Cashfree checkout requires a genuine payment-only mobile number when enabled. NoTitle passes it to the provider without saving it in the profile, payment ledger or browser storage. No optional email is requested. Card and bank credentials are entered on the provider’s hosted page, not into NoTitle. Peers never receive payment details. Cashfree or your bank may send their own payment messages.</li>
      <li><strong>Service operation:</strong> network, connection and security information. Pseudonyms do not make a visitor untraceable to the service or its infrastructure providers.</li>
    </ul>
  </section>
  <section id="conversation-data">
    <h2>Conversations, audio and reports</h2>
    <p>The intended ordinary text path is a server-readable relay with a bounded memory buffer. There is no user-visible conversation history or offline inbox. The design does not put ordinary transcripts into browser storage, analytics or database backups.</p>
    <p>A report you begin can temporarily preserve available text evidence so that switching conversations does not erase the material you are reporting. Submitting a report may retain the relevant subset for restricted review. If the relevant text has already expired, the reporting flow must explain that evidence is unavailable.</p>
    <p>When audio is enabled by the service, a call starts only after both people accept and allow microphone access. The product has no audio-recording feature. This does not prevent another person from recording externally. The service and relay infrastructure handle connection information needed to operate the call.</p>
    <p><strong>No user history does not mean no lawful retention.</strong> Any required retention that changes these notices must be explained and implemented before that processing starts.</p>
    {#if !site.production}<p>Retention requirements for transient text, traffic information, reports and account records still require legal review before launch.</p>{/if}
  </section>
  <section id="retention">
    <h2>Retention and service providers</h2>
    <p>Retention must be specific to its purpose: temporary interaction state, restricted report evidence, security records, financial records and recovery backups have different needs. Account deletion cannot automatically erase records that must be retained for an applicable legal obligation, dispute or authorised hold.</p>
    <p>India-region core hosting is not a promise that every processor handles all information only in India.</p>
    {#if site.production}
      <h3>Service providers</h3>
      {#each release.privacy.processors as processor}
        <article class="disclosure-card">
          <h4>{processor.name}</h4>
          <dl>
            <div><dt>Purpose</dt><dd>{processor.purpose}</dd></div>
            <div><dt>Processing region</dt><dd>{processor.region}</dd></div>
            <div><dt>International processing</dt><dd>{processor.internationalProcessing}</dd></div>
            <div><dt>Safeguards</dt><dd>{processor.safeguards}</dd></div>
          </dl>
        </article>
      {/each}
      <h3>Retention schedule · {release.privacy.retentionVersion}</h3>
      {#each release.privacy.retention as item}
        <article class="disclosure-card">
          <h4>{retentionLabels[item.dataClass] ?? item.dataClass}</h4>
          <dl>
            <div><dt>Retention and lifecycle</dt><dd>{item.lifecycle}</dd></div>
            <div><dt>Purpose</dt><dd>{item.reason}</dd></div>
            <div><dt>Applicable basis</dt><dd>{item.legalSource}</dd></div>
            <div><dt>Effective date</dt><dd>{item.effectiveDate}</dd></div>
            <div><dt>Responsible owner</dt><dd>{item.owner}</dd></div>
            <div><dt>Deletion method</dt><dd>{item.deletionMethod}</dd></div>
          </dl>
        </article>
      {/each}
      <h3>Legal holds</h3>
      <p>{release.privacy.legalHoldWorkflow}</p>
    {:else}
      <p>The final notice must identify the actual hosting, edge, backup, relay and payment processors, their purposes and any international processing.</p>
      <p>The approved retention periods, applicable legal sources, processor list, safeguards and request procedure are not yet finalised. They must be completed before this draft becomes a published privacy notice.</p>
    {/if}
  </section>
  <section id="choices">
    <h2>Your choices and requests</h2>
    <p>Account controls include profile correction, blocked-person management, session controls and account deletion. <a href="/account/privacy">Privacy controls</a> offer a current account export after fresh password confirmation. Privacy and grievance requests use protected case access when support is enabled; an account or email address is not required merely to raise a complaint.</p>
    <p>Information supplied in an export or case response must not reveal another participant’s private profile, the identity of a reporter or unrestricted case evidence. A review of the requester’s authority may be necessary.</p>
    {#if site.production}<p>{release.privacy.requestProcedure}</p>{/if}
    <p>Use <a href="/support">public privacy requests</a> for access, correction, deletion enquiries or required receipts after closure. The service checks authority before disclosing protected data. Review the <a href="/account-deletion">deletion process</a> and <a href="/grievance">grievance process</a>; draft policies remain subject to launch approval.</p>
  </section>
</PolicyPage>

<style>
  .disclosure-card { padding: 1.25rem; margin-block: 1rem; border: 1px solid var(--border); border-radius: var(--radius-md); background: var(--surface); }
  h4 { margin: 0 0 1rem; font-size: 1.05rem; }
  dl { margin: 0; display: grid; gap: 1rem; }
  dl div { min-width: 0; }
  dt { font-weight: 650; font-size: 0.85rem; }
  dd { margin: 0.25rem 0 0; color: var(--text-secondary); }
</style>
