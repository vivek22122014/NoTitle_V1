<script lang="ts">
  import PolicyPage from '$lib/components/PolicyPage.svelte';
  import Seo from '$lib/components/Seo.svelte';
  const contents = [
    { id: 'respect', label: 'Respect the person' },
    { id: 'privacy', label: 'Protect privacy and confidence' },
    { id: 'safe-topics', label: 'Keep the space safe' },
    { id: 'control', label: 'Leave, report and block' }
  ];
</script>

<Seo path="/community-guidelines" />
<PolicyPage path="/community-guidelines" title="Community Guidelines" introduction="Bring your perspective. Give the other person room to have theirs." {contents}>
  <section id="respect">
    <h2>Respect the person</h2>
    <p>Disagree with ideas without attacking people. Do not harass, threaten, humiliate, discriminate or use hateful language against an individual or group. Repeated unwanted contact and attempts to get around a block are not acceptable.</p>
    <p>NoTitle is for adults aged 18 and over. Do not misrepresent your age, impersonate someone else or claim verified expertise that you do not have. Gender and professional details are self-declared; do not pressure someone to prove their identity.</p>
    <p>Audio requires a separate invitation and acceptance. Declining a call or ending a conversation needs no explanation. Consent to one conversation does not imply consent to another.</p>
  </section>
  <section id="privacy">
    <h2>Protect privacy and confidence</h2>
    <p>Discuss situations without naming colleagues, customers or other people who have not agreed to be identified. Do not share contact details, personal records, credentials, confidential documents, trade secrets or other information you are not entitled to disclose.</p>
    <p>Do not expose another participant, pressure them to move to another service or record or redistribute a private conversation without appropriate permission. The product cannot prevent external recording or screenshots, so choose what you share carefully.</p>
  </section>
  <section id="safe-topics">
    <h2>Keep the space safe</h2>
    <ul>
      <li>No sexual exploitation, intimate-content abuse or content involving the exploitation of children.</li>
      <li>No threats of violence, encouragement of self-harm or instructions intended to harm another person.</li>
      <li>No scams, requests for money under false pretences, malicious links, spam or deceptive recruitment.</li>
      <li>No unlawful activity or deliberate attempts to disrupt or exploit the service.</li>
    </ul>
    <p>Workplace culture, office politics, career choices, hiring and industry experiences can be sensitive. Share experiences thoughtfully and avoid presenting unverified allegations about identifiable people as established facts.</p>
  </section>
  <section id="control">
    <h2>Leave, report and block</h2>
    <p>The planned conversation controls include Next, End, Report and Block. Safety actions will be available to every tier without opening checkout or requiring registration. You do not have to stay in a conversation to explain your discomfort.</p>
    <p>When reporting is available, describe the behaviour accurately and submit only relevant information. Reports may retain the relevant available evidence for restricted review. A report is not a guarantee of a particular enforcement outcome.</p>
    <p>Human review, proportionate restrictions and an appeal route are required before public conversations open. Read the <a href="/safety">safety guidance</a> and <a href="/grievance">planned grievance process</a>. Enabled controlled conversations include text reporting and blocking. Public release still requires approved, monitored moderation and grievance coverage.</p>
  </section>
</PolicyPage>
