<script lang="ts">
  import SupportAvailability from '$lib/support/SupportAvailability.svelte';
  import PolicyPage from '$lib/components/PolicyPage.svelte';
  import Seo from '$lib/components/Seo.svelte';
  import { release, site } from '$lib/config/site';
  const contents = [
    { id: 'status', label: 'Current availability and officer details' },
    { id: 'raise-concern', label: 'Complaint process' },
    { id: 'case-access', label: 'Replies and protected case access' },
    { id: 'appeal', label: 'Review, urgency and appeals' }
  ];
</script>

<Seo path="/grievance" />
<PolicyPage path="/grievance" title="Grievances and appeals" introduction="A clear way to raise a concern, follow its progress and ask for a decision to be reviewed." {contents}>
  <section id="status">
    <h2>Current availability and officer details</h2>
    <SupportAvailability /><p>An enabled conversation service also has a separate Report control; only its successful submission receipt confirms that a safety report was created. Source implementation does not establish monitored coverage or legal approval.</p>
    {#if site.production}
      <h3>Grievance Officer</h3>
      <p>{release.grievance.name} · {release.grievance.designation}</p>
      <address>{release.grievance.address}</address>
      <p><a href={`mailto:${release.grievance.email}`}>{release.grievance.email}</a></p>
    {:else}
      <p>The operator must appoint a Grievance Officer and publish verified name, designation, address and contact details before release. This draft does not invent an officer or a contact address.</p>
    {/if}
  </section>
  <section id="raise-concern">
    <h2>Complaint process</h2>
    <p>When support is enabled, the <a href="/support">public complaint form</a> works without logging in. It covers safety decisions, privacy concerns, payment issues and formal grievances, with an appropriate route for urgent matters. You do not need to buy Premium or supply an email address simply to raise a complaint.</p>
    <p>You will be asked for the kind of concern, a description and relevant references you already have. Share only what is necessary. Do not post another person’s credentials, private documents or unnecessary personal details.</p>
    <p>The service must preserve the original receipt time and route the issue according to its category. Relevant evidence may have expired; a case can still record what was reported and what action was possible.</p>
  </section>
  <section id="case-access">
    <h2>Replies and protected case access</h2>
    <p>Prepare and save private access codes before sending. A successful submission returns a case reference and confirms durable receipt. The original submission reference plus the saved status secret can check an uncertain result. The secret is needed to view protected updates and replies, so it must be saved securely and kept out of public conversations. A reference alone must not reveal a case.</p>
    <p>Case access remains separate from a temporary guest session. Cases submitted from the account support screen are also linked to that account. Replies and appeals appear on protected case pages; there is no live support chat or outgoing application-email service.</p>
    <p>Open a saved case at <a href="/support/case">Protected case access</a> by entering both codes. They are never included in the address bar or saved automatically in browser storage. Keep any downloaded plain-text access file private. Protected access ends when a closed case is removed under the reviewed retention schedule; it is not an indefinite record. A receipt is distinct from a human acknowledgement or resolution.</p>
  </section>
  <section id="appeal">
    <h2>Review, urgency and appeals</h2>
    <p>A case response should explain the decision to the extent it can without exposing another participant’s private information or compromising safety. Use Reply or appeal on the protected case to ask for review. The response should identify the decision and the permitted review route; it must not identify another reporter.</p>
    <p>Applicable response deadlines differ by issue and legal trigger. The appointed reviewer must approve a current deadline and escalation schedule before launch. This draft does not substitute a single general response estimate for urgent obligations.</p>
    <p>NoTitle is not an emergency service. If someone is in immediate danger, seek appropriate local emergency assistance. Read the <a href="/safety">safety guidance</a> for the planned in-conversation controls.</p>
  </section>
</PolicyPage>
