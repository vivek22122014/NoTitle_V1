<script lang="ts">
  import PolicyPage from '$lib/components/PolicyPage.svelte';
  import Seo from '$lib/components/Seo.svelte';
  import { site } from '$lib/config/site';
  const contents = [
    { id: 'request', label: 'Account-deletion request' },
    { id: 'effects', label: 'What deletion changes' },
    { id: 'records', label: 'Records that may need to remain' },
    { id: 'guest', label: 'Guests and other privacy requests' }
  ];
</script>

<Seo path="/account-deletion" />
<PolicyPage path="/account-deletion" title="Account deletion" introduction="The intended steps for closing an account, ending access and understanding any records that must remain." {contents}>
  <section id="request">
    <h2>Account-deletion request</h2>
    <p>The account foundation includes a deletion request in <a href="/settings">Settings</a>. It requires recent password confirmation and explicit consent. When the account service confirms the request, access is disabled immediately and every account session is revoked.</p>
    <p>The response distinguishes a pending independent deletion record from a saved record. Keep the private status receipt to check the request after signing out. The status identifies ordinary-data removal separately from retained records. Removal follows the approved retention schedule and lawful holds; a disabled account is not proof that every copy is erased. Public launch remains closed.</p>
    <p>Before confirming, you should be shown the effects on access, friendships, Premium time and access to receipts or open cases. A deletion request is not automatically a refund request; applicable payment and consumer rights must remain available.</p>
  </section>
  <section id="effects">
    <h2>What deletion changes</h2>
    <ul>
      <li>Revoke the account’s sessions and stop new access using its credentials.</li>
      <li>Remove the participant from waiting and end active interactions through the normal safety-aware cleanup.</li>
      <li>Remove the public profile and applicable account relationships, with reciprocal friendship cleanup.</li>
      <li>Delete or de-identify account data according to the approved retention schedule, while separating any records with a valid retention obligation.</li>
    </ul>
    <p>An export or closure response must not reveal another participant’s private profile, reporter identity or restricted report evidence. Deletion also cannot remove screenshots or recordings made by another person outside the product.</p>
  </section>
  <section id="records">
    <h2>Records that may need to remain</h2>
    <p>Financial records, necessary security records, submitted case evidence and information subject to an applicable legal obligation or authorised hold may require restricted retention. The approved notice must explain the purpose and retention period for each category.</p>
    <p>Backups have a separate recovery window. A restore procedure must reapply deletion records so that restoring a backup does not silently reactivate a deleted account. At <a href="/account/privacy">Privacy controls</a>, a saved private deletion-status receipt together with the original purchase reference can retrieve a retained required receipt. This does not restore the account. A public support case secret or screenshot cannot replace the deletion proof.</p>
    {#if site.production}
      <p>The <a href="/privacy#retention">approved retention schedule</a> explains the applicable periods, purposes and deletion methods. Closing an account does not mean immediate erasure of every copy or indefinite retention of everything.</p>
    {:else}
      <p>The final periods and legal grounds are awaiting review. This draft does not promise immediate erasure of every copy or indefinite retention of everything.</p>
    {/if}
  </section>
  <section id="guest">
    <h2>Guests and other privacy requests</h2>
    <p>A guest has a temporary identity rather than a durable account. Guest state and friendships involving that guest end when the guest identity ends or expires. This is different from an account-deletion workflow and does not erase separately submitted reports or required safety records.</p>
    <p>Access, correction and other privacy requests use the <a href="/support">protected support process</a> when enabled, including a route for people who cannot sign in. Read <a href="/privacy">Privacy</a> and the <a href="/grievance">grievance process</a>.</p>
  </section>
</PolicyPage>
