<script lang="ts">
  import Button from '$lib/components/Button.svelte';
  import Seo from '$lib/components/Seo.svelte';
  import PlanCards from '$lib/payments/PlanCards.svelte';

  const tiers = [
    {
      name: 'Guest',
      description: 'A temporary identity. No registration.',
      features: [
        'Text and mutually accepted audio',
        'All discussion topics, including General Talk',
        'Everyone as the effective gender preference',
        'Optional temporary professional profile',
        'Mutual friends for the lifetime of the guest identity',
        'Next, End, Report and Block'
      ]
    },
    {
      name: 'Free account',
      description: 'A returning identity, without a purchase.',
      features: [
        'Everything in Guest',
        'Saved account and optional professional profile',
        'Everyone as the effective gender preference',
        'Saved friendships when both people have accounts',
        'Guest friendships remain temporary',
        'No saved chat history or offline inbox'
      ]
    },
    {
      name: 'Premium',
      description: 'Optional preferences, for a fixed duration.',
      features: [
        'Everything in Free',
        'Gender preference: Everyone or one specific option',
        'Optional, very light professional preferences',
        'No preference is the professional default',
        'The same matching pool and safety controls',
        'A one-time purchase with no automatic renewal'
      ]
    }
  ];
</script>

<Seo path="/premium" />

<section class="page-intro content-width" aria-labelledby="premium-page-title">
  <p class="eyebrow">Premium</p>
  <h1 id="premium-page-title">More choice.<br />The same shared space.</h1>
  <p class="page-lead">
    Premium is designed to give you more say in matching. Good conversation, accepted audio,
    friends and safety stay part of the free experience.
  </p>
  <PlanCards />
</section>

<section class="section section-muted" aria-labelledby="comparison-title">
  <div class="content-width">
    <div class="section-heading">
      <p class="eyebrow">Guest, Free and Premium</p>
      <h2 id="comparison-title">One pool. Three ways to take part.</h2>
      <p>Free can match Premium, and Premium can match Free. Capacity and safety limits apply equally to everyone.</p>
    </div>
    <div class="tier-grid">
      {#each tiers as tier}
        <article class="tier-card" class:premium-tier={tier.name === 'Premium'}>
          <p class="tier-label">{tier.name === 'Premium' ? 'Optional fixed-duration purchase' : 'Free access when enabled'}</p>
          <h3>{tier.name}</h3>
          <p class="tier-description">{tier.description}</p>
          <ul>
            {#each tier.features as feature}
              <li>{feature}</li>
            {/each}
          </ul>
        </article>
      {/each}
    </div>
    <p class="comparison-note">Every participant must explicitly choose Male, Female or Other / Non-binary. Gender and professional details are self-declared; a paid preference does not verify them.</p>
  </div>
</section>

<section class="section" aria-labelledby="preferences-title">
  <div class="content-width preferences-grid">
    <div class="section-heading">
      <p class="eyebrow">How preferences work</p>
      <h2 id="preferences-title">Clear boundaries, without complicated searching.</h2>
      <p>Your choices have different jobs. Gender is a matching constraint. Professional relevance is only a small tie-break.</p>
    </div>
    <div class="preference-list">
      <article>
        <span class="preference-number" aria-hidden="true">01</span>
        <h3>Gender preference is always respected</h3>
        <p>Premium can choose Everyone, Male, Female or Other / Non-binary. Both people’s effective preferences must be satisfied before a match. Blocks still apply.</p>
      </article>
      <article>
        <span class="preference-number" aria-hidden="true">02</span>
        <h3>Professional choices stay very light</h3>
        <p>Optional professional preferences only slightly influence an available match. They are never an eligibility filter, never override gender preference and do not add waiting time.</p>
      </article>
      <article>
        <span class="preference-number" aria-hidden="true">03</span>
        <h3>No preference means no professional scoring</h3>
        <p>Professional preferences start at No preference. Each category can be cleared, and the global option pauses professional scoring while keeping saved choices. General Talk also switches professional scoring off.</p>
      </article>
    </div>
  </div>
</section>

<section class="section section-muted" aria-labelledby="expectations-title">
  <div class="reading-width">
    <p class="eyebrow">Know what you’re choosing</p>
    <h2 class="section-title" id="expectations-title">Preference is not a promise of a match.</h2>
    <ul class="expectations">
      <li>A narrower gender preference can mean a longer wait or no available match. Premium does not guarantee a person, profession or waiting time.</li>
      <li>Premium never bypasses blocks, safety restrictions, consent or capacity limits.</li>
      <li>A guest must register before purchasing. Normal registration does not require a phone or email; any genuine payment-only data requirement will be disclosed at checkout.</li>
      <li>Purchases are for a fixed duration and never renew automatically. Before payment, the exact duration, total INR amount and tax treatment must be shown.</li>
      <li>If Premium expires while you are waiting with a specific gender preference, searching pauses. You choose whether to renew or explicitly continue with Everyone.</li>
    </ul>
    <div class="page-actions">
      <a class="text-link" href="/refund-policy">Read the refund policy <span aria-hidden="true">→</span></a>
      <a class="text-link" href="/how-it-works">How conversations work <span aria-hidden="true">→</span></a>
    </div>
    <div class="closing">
      <Button href="/chat">Start a Conversation</Button>
      <p>Opens your identity and conversation space. Text and safety tools depend on service availability; audio and checkout depend on service availability.</p>
    </div>
  </div>
</section>

<style>
  .tier-grid {
    display: grid;
    gap: 1rem;
  }

  .tier-card {
    min-width: 0;
    padding: 1.5rem;
    border: 1px solid var(--border-strong);
    border-radius: var(--radius-lg);
    background: var(--background);
  }

  .tier-card.premium-tier {
    border-color: var(--accent);
    background: var(--surface-accent);
  }

  .tier-label {
    min-height: 2.5em;
    margin: 0 0 1rem;
    color: var(--text-secondary);
    font-size: 0.75rem;
    font-weight: 650;
  }

  .tier-card h3 {
    margin: 0 0 0.65rem;
    font-size: 1.5rem;
    line-height: 1.25;
    letter-spacing: -0.025em;
  }

  .tier-description {
    margin: 0 0 1.5rem;
    color: var(--text-secondary);
    font-size: 0.9375rem;
  }

  .tier-card ul {
    display: grid;
    gap: 0.9rem;
    margin: 0;
    padding: 1.25rem 0 0;
    border-top: 1px solid var(--border-strong);
    list-style: none;
  }

  .tier-card li {
    position: relative;
    padding-left: 1.1rem;
    font-size: 0.875rem;
  }

  .tier-card li::before {
    content: '·';
    position: absolute;
    left: 0;
    color: var(--accent);
    font-weight: 800;
  }

  .comparison-note {
    max-width: 53rem;
    margin: 1.5rem 0 0;
    color: var(--text-secondary);
    font-size: 0.875rem;
  }

  .preferences-grid {
    display: grid;
    gap: 1rem;
  }

  .preference-list article {
    position: relative;
    padding: 1.5rem 0 1.5rem 2.75rem;
    border-bottom: 1px solid var(--border);
  }

  .preference-list article:first-child {
    padding-top: 0;
  }

  .preference-number {
    position: absolute;
    top: 1.65rem;
    left: 0;
    color: var(--accent-strong);
    font-size: 0.875rem;
    font-weight: 700;
  }

  .preference-list article:first-child .preference-number {
    top: 0.15rem;
  }

  .preference-list h3 {
    margin: 0 0 0.75rem;
    font-size: 1.125rem;
    line-height: 1.4;
  }

  .preference-list p {
    margin: 0;
    color: var(--text-secondary);
  }

  .expectations {
    display: grid;
    gap: 1rem;
    padding-left: 1.25rem;
    margin-block: 1.5rem 2rem;
    color: var(--text-secondary);
  }

  .expectations li {
    padding-left: 0.25rem;
  }

  .closing {
    margin-top: 2rem;
  }

  .closing p {
    margin: 0.75rem 0 0;
    color: var(--text-secondary);
    font-size: 0.8125rem;
  }

  @media (min-width: 52rem) {
    .tier-grid {
      grid-template-columns: repeat(3, minmax(0, 1fr));
    }

    .preferences-grid {
      grid-template-columns: minmax(0, 0.85fr) minmax(0, 1.15fr);
      gap: 4rem;
    }
  }
</style>
