<script lang="ts">
  import type { PageData } from './$types';
  import Button from '$lib/components/Button.svelte';
  import Seo from '$lib/components/Seo.svelte';
  import PremiumScreen from '$lib/payments/PremiumScreen.svelte';
  import SupportScreen from '$lib/support/SupportScreen.svelte';
  import PrivacyScreen from '$lib/privacy/PrivacyScreen.svelte';
  import FriendsScreen from '$lib/friends/FriendsScreen.svelte';
  import IdentityScreen from '$lib/identity/IdentityScreen.svelte';
  import type { Mode } from '$lib/identity/model';

  export let data: PageData;
</script>

<Seo path={data.path} />

{#if ['register', 'login', 'recovery', 'profile', 'settings'].includes(data.screen)}
  {#key data.screen}<IdentityScreen mode={data.screen as Mode} />{/key}
{:else if data.screen === 'account/premium' || data.screen === 'payment/status'}
  <PremiumScreen statusMode={data.screen === 'payment/status'} />
{:else if ['support', 'support/case', 'account/support'].includes(data.screen)}
  {#key data.screen}<SupportScreen accountMode={data.screen === 'account/support'} statusMode={data.screen === 'support/case'} />{/key}
{:else if data.screen === 'account/privacy'}
  <PrivacyScreen />
{:else if data.screen === 'friends'}
  <FriendsScreen />
{:else}
<section class="unavailable content-width" aria-labelledby="screen-title">
  <p class="eyebrow">Currently unavailable</p>
  <h1 id="screen-title">{data.title}</h1>
  <p>{data.description}</p>
  <div class="actions">
    <Button href="/">Back to NoTitle</Button>
    <Button href="/how-it-works" variant="secondary">How NoTitle works</Button>
  </div>
</section>
{/if}

<style>
  .unavailable { min-height: 60dvh; padding-block: clamp(3rem, 8vw, 6rem); }
  .eyebrow { color: var(--accent-strong); font-size: 0.8rem; font-weight: 700; }
  h1 { font-size: clamp(2rem, 6vw, 3.5rem); letter-spacing: -0.04em; line-height: 1.15; }
  p:not(.eyebrow) { max-width: 38rem; color: var(--text-secondary); }
  .actions { display: flex; flex-wrap: wrap; gap: 0.75rem; margin-top: 1.75rem; }
</style>
