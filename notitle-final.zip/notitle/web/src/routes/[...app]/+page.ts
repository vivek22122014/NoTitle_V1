import { error } from '@sveltejs/kit';
import type { PageLoad } from './$types';

export const prerender = false;
export const ssr = false;

const screens: Record<string, { title: string; description: string }> = {
  register: {
    title: 'Create an account',
    description: 'Create a private username and password account without a phone number or email.'
  },
  login: {
    title: 'Welcome back',
    description: 'Sign in with your private username and password.'
  },
  recovery: {
    title: 'Account recovery',
    description: 'Recover your account using its private username and saved recovery code.'
  },
  profile: {
    title: 'Your profile',
    description: 'Edit your public display name and Bio and your optional private professional details.'
  },
  settings: {
    title: 'Your settings',
    description: 'Manage sessions, credentials and your account deletion request.'
  },
  friends: {
    title: 'Stay connected',
    description: 'Manage mutual connections and accepted online invitations as a guest or account member.'
  },
  support: { title: 'Support and privacy requests', description: 'Submit a concern and save private access codes without an account or email.' },
  'support/case': { title: 'Open a protected case', description: 'Enter saved private case codes to read responses and reply.' },
  'account/support': { title: 'Your support cases', description: 'Review your own support cases and appeal decisions.' },
  'account/privacy': { title: 'Privacy controls', description: 'Access your information, correct your profile and retrieve required receipts after closure.' },
  'account/premium': { title: 'Your Premium', description: 'Your account balance, enabled plans, purchase status and payment receipts.' },
  'payment/status': {
    title: 'Payment status',
    description: 'Check payment confirmation, committed Premium access and refund status for your account.'
  }
};

export const load: PageLoad = ({ params }) => {
  const name = params.app;
  if (!Object.hasOwn(screens, name)) error(404, 'Page not found');
  return { ...screens[name], path: `/${name}`, screen: name };
};
