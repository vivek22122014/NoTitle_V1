<script lang="ts">
  import Button from '$lib/components/Button.svelte';
  import Seo from '$lib/components/Seo.svelte';
  import { site } from '$lib/config/site';

  const topics = [
    { title: 'Workplace culture', prompt: 'What makes a team feel like a team?' },
    { title: 'Office politics', prompt: 'How do you handle the unwritten rules?' },
    { title: 'Career crossroads', prompt: 'Stay, switch, or try something new?' },
    { title: 'Managers and leadership', prompt: 'What does good support look like?' },
    { title: 'Salaries and hiring', prompt: 'What do you wish you had asked?' },
    { title: 'General Talk', prompt: 'Start wherever your day takes you.' }
  ];
</script>

<Seo path="/" />

<section class="hero">
  <div class="content-width hero-grid">
    <div class="hero-copy">
      <p class="eyebrow">A different kind of work conversation</p>
      <h1>Talk about work.<br /><span>Leave the title behind.</span></h1>
      <p class="lead">Some things are easier to say outside the meeting room.</p>
      <p class="supporting">
        A space for adults to share perspectives on workplace culture, careers and everything in
        between. One person at a time, without introducing your job title.
      </p>
      <div class="page-actions">
        <Button href="/chat">Start a Conversation <span aria-hidden="true">↗</span></Button>
        <a class="text-link" href="/how-it-works">How it works <span aria-hidden="true">→</span></a>
      </div>
      {#if !site.production}<p class="availability">Controlled product preview. Public conversations are not open yet.</p>{/if}
      <ul class="hero-notes" aria-label={site.production ? 'Conversation experience' : 'Planned conversation experience'}>
        <li>For adults 18+</li>
        <li>Text and accepted audio</li>
        <li>Guest access</li>
      </ul>
    </div>

    <aside class="perspective-card" aria-labelledby="perspective-title">
      <div class="card-kicker"><span class="small-mark" aria-hidden="true">N</span><span>Room for perspective</span></div>
      <p class="prompt-label">A thought to start with</p>
      <h2 id="perspective-title">What would you say if the job title <span>didn’t matter?</span></h2>
      <div class="card-rule"></div>
      <p>Bring a question.<br />Leave with another point of view.</p>
      <p class="card-caption">A conversation idea, not a live chat.</p>
    </aside>
  </div>
</section>

<section id="topics" class="section section-muted" aria-labelledby="topics-title">
  <div class="content-width">
    <div class="section-heading">
      <p class="eyebrow">What’s on your mind?</p>
      <h2 id="topics-title">The things that don’t fit on a work calendar.</h2>
      <p>Bring your experience, a question, or a little curiosity. These are conversation starters.</p>
    </div>
    <ul class="topic-grid">
      {#each topics as topic, index}
        <li>
          <span class="topic-number" aria-hidden="true">0{index + 1}</span>
          <h3>{topic.title}</h3>
          <p>{topic.prompt}</p>
        </li>
      {/each}
    </ul>
  </div>
</section>

<section id="how-it-works" class="section" aria-labelledby="how-title">
  <div class="content-width">
    <div class="section-heading">
      <p class="eyebrow">The experience we’re building</p>
      <h2 id="how-title">Less introduction.<br />More conversation.</h2>
      <p>There’s no public feed to perform for. Just a little room to exchange perspectives.</p>
    </div>
    <ol class="steps-grid">
      <li>
        <span class="step-number" aria-hidden="true">01</span>
        <h3>Choose a starting point</h3>
        <p>Join as a guest or use an account. Confirm you’re 18+, accept the rules, declare your gender and choose a topic.</p>
      </li>
      <li>
        <span class="step-number" aria-hidden="true">02</span>
        <h3>Meet one person at a time</h3>
        <p>Start with text. Switch to audio only if you both agree. You can always continue without a microphone.</p>
      </li>
      <li>
        <span class="step-number" aria-hidden="true">03</span>
        <h3>Decide what comes next</h3>
        <p>End or move on whenever you need to. Stay connected as friends only with mutual consent, including as a guest.</p>
      </li>
    </ol>
    <a class="text-link section-link" href="/how-it-works">Explore the full experience <span aria-hidden="true">→</span></a>
  </div>
</section>

<section class="section section-muted" aria-labelledby="premium-title">
  <div class="content-width split-section">
    <div>
      <p class="eyebrow">Premium, when you want more choice</p>
      <h2 class="section-title" id="premium-title">The conversation stays open to everyone.</h2>
    </div>
    <div class="section-copy">
      <p>Text, mutually accepted audio, safety controls and friends do not require Premium. Availability depends on which features the service enables. Everyone shares one matching pool.</p>
      <p>Premium adds a gender preference and optional, very light professional preferences. It never guarantees a match or verifies anyone’s details.</p>
      <p class="small-copy">Fixed-duration purchases. No automatic renewal. See Premium for current plan availability.</p>
      <a class="text-link" href="/premium">Understand Premium <span aria-hidden="true">→</span></a>
    </div>
  </div>
</section>

<section id="privacy" class="section" aria-labelledby="privacy-title">
  <div class="content-width split-section">
    <div>
      <p class="eyebrow">A little space. Clear boundaries.</p>
      <h2 class="section-title" id="privacy-title">Anonymous to the people you meet.</h2>
    </div>
    <div class="section-copy">
      <p>Use a pseudonym. Keep your employer and personal details to yourself. Gender and professional details are self-declared, not verified.</p>
      <p>Privacy has limits: NoTitle relays readable text, service providers handle network information, and another person could take a screenshot or record externally.</p>
      <p>Ordinary chat is designed without saved history. Reports and legally required records are handled separately under reviewed policies.</p>
      <div class="page-actions">
        <a class="text-link" href="/safety">Read about safety <span aria-hidden="true">→</span></a>
        <a class="text-link" href="/privacy">Privacy details <span aria-hidden="true">→</span></a>
      </div>
    </div>
  </div>
</section>

<style>
  .hero {
    padding-block: clamp(2.75rem, 7vw, 6.5rem);
  }

  .hero-grid {
    display: grid;
    align-items: center;
    gap: 2.5rem;
  }

  .hero-copy {
    max-width: 43rem;
  }

  h1 {
    margin: 0 0 1.5rem;
    font-size: clamp(2.35rem, 1.5rem + 3.3vw, 4.65rem);
    line-height: 1.1;
    letter-spacing: -0.05em;
    text-wrap: balance;
  }

  h1 span {
    color: var(--accent-strong);
  }

  .lead {
    max-width: 28rem;
    margin: 0 0 1rem;
    font-size: 1.2rem;
    line-height: 1.55;
  }

  .supporting {
    max-width: 35rem;
    margin: 0 0 1.75rem;
    color: var(--text-secondary);
  }

  .availability {
    margin: 0.8rem 0 0;
    color: var(--text-secondary);
    font-size: 0.8125rem;
  }

  .hero-notes {
    display: flex;
    flex-wrap: wrap;
    gap: 0.4rem 1.2rem;
    margin: 1.75rem 0 0;
    padding: 1.25rem 0 0;
    border-top: 1px solid var(--border);
    color: var(--text-secondary);
    font-size: 0.75rem;
    list-style: none;
  }

  .hero-notes li::before {
    content: '·';
    padding-right: 0.45rem;
    color: var(--accent);
    font-weight: 800;
  }

  .perspective-card {
    padding: clamp(1.5rem, 3vw, 2.5rem);
    border-radius: 1.5rem;
    background: var(--navy);
    color: #e5edf2;
  }

  .card-kicker {
    display: flex;
    align-items: center;
    gap: 0.7rem;
    color: #d7e4eb;
    font-size: 0.75rem;
    font-weight: 600;
  }

  .small-mark {
    display: grid;
    flex: 0 0 1.8rem;
    place-items: center;
    width: 1.8rem;
    height: 1.8rem;
    border: 1px solid #708799;
    border-radius: 50%;
  }

  .prompt-label {
    margin: 2.75rem 0 0.8rem;
    color: #c0d1dc;
    font-size: 0.75rem;
  }

  .perspective-card h2 {
    max-width: 13ch;
    margin: 0;
    color: white;
    font-size: clamp(2rem, 1.4rem + 1.3vw, 2.8rem);
    font-weight: 550;
    line-height: 1.2;
    letter-spacing: -0.035em;
  }

  .perspective-card h2 span {
    color: #a3ded0;
  }

  .card-rule {
    width: 3rem;
    height: 1px;
    margin-block: 1.75rem;
    background: #708799;
  }

  .perspective-card > p:not(.prompt-label) {
    margin: 0;
    color: #d7e4eb;
    font-size: 0.875rem;
  }

  .perspective-card > p.card-caption {
    margin-top: 2.75rem;
    color: #c0d1dc;
    font-size: 0.75rem;
  }

  .topic-grid {
    display: grid;
    gap: 0 1.5rem;
    margin: 0;
    padding: 0;
    list-style: none;
  }

  .topic-grid li {
    position: relative;
    padding: 1.5rem 0 1.5rem 2.25rem;
    border-top: 1px solid var(--border);
  }

  .topic-number {
    position: absolute;
    top: 1.7rem;
    left: 0;
    color: var(--accent-strong);
    font-size: 0.75rem;
    font-weight: 650;
  }

  .topic-grid h3,
  .steps-grid h3 {
    margin: 0 0 0.5rem;
    font-size: 1.0625rem;
    font-weight: 700;
    line-height: 1.4;
  }

  .topic-grid p,
  .steps-grid p {
    margin: 0;
    color: var(--text-secondary);
    font-size: 0.9375rem;
  }

  .steps-grid {
    display: grid;
    gap: 2rem;
    margin: 0;
    padding: 0;
    list-style: none;
  }

  .steps-grid li {
    padding-top: 1.25rem;
    border-top: 1px solid var(--border-strong);
  }

  .step-number {
    display: block;
    margin-bottom: 1.5rem;
    color: var(--accent-strong);
    font-size: 0.875rem;
    font-weight: 700;
  }

  .section-link {
    margin-top: 1.5rem;
  }

  .split-section {
    display: grid;
    gap: 1.5rem;
  }

  .section-copy p {
    margin: 0 0 1rem;
    color: var(--text-secondary);
  }

  .section-copy .small-copy {
    padding-left: 1rem;
    border-left: 2px solid var(--accent);
    font-size: 0.875rem;
  }

  @media (min-width: 40rem) {
    .topic-grid {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
  }

  @media (min-width: 52rem) {
    .hero-grid {
      grid-template-columns: minmax(0, 1.35fr) minmax(0, 0.85fr);
      gap: 3rem;
    }

    .steps-grid {
      grid-template-columns: repeat(3, minmax(0, 1fr));
    }

    .split-section {
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 4rem;
    }
  }

  @media (min-width: 64rem) {
    .topic-grid {
      grid-template-columns: repeat(3, minmax(0, 1fr));
    }
  }
</style>
