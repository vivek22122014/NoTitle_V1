<script lang="ts">
  import InteractionPreview from '$lib/design/InteractionPreview.svelte';
</script>

<svelte:head>
  <title>Interaction design preview | NoTitle</title>
  <meta name="robots" content="noindex, nofollow" />
</svelte:head>

<InteractionPreview />
