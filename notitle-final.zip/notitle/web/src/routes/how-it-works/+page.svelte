<script lang="ts">
  import Button from '$lib/components/Button.svelte';
  import Seo from '$lib/components/Seo.svelte';
  import { site } from '$lib/config/site';
</script>

<Seo path="/how-it-works" />

<section class="page-intro content-width" aria-labelledby="how-page-title">
  <p class="eyebrow">How NoTitle works</p>
  <h1 id="how-page-title">Bring a perspective.<br />Make room for another.</h1>
  <p class="page-lead">
    One-to-one conversations about work, at your pace. Start with a topic, meet someone new,
    and choose how much you want to share.
  </p>
  {#if !site.production}<span class="preview-label">Planned experience · Public conversations are not open yet</span>{/if}
</section>

<section class="section section-muted" aria-labelledby="journey-title">
  <div class="content-width journey">
    <div class="section-heading">
      <p class="eyebrow">From first hello to next time</p>
      <h2 id="journey-title">A few clear steps.</h2>
      <p>The same experience on your phone or desktop. No registration is required for guest conversations.</p>
    </div>
    <ol class="journey-list">
      <li>
        <span class="journey-number" aria-hidden="true">01</span>
        <div>
          <h3>Enter on your terms</h3>
          <p>Confirm you are 18 or older, read the privacy notice and accept the community rules. Choose Male, Female or Other / Non-binary; there is no preselected answer. Professional details are optional.</p>
          <p class="detail">The person you meet sees your pseudonym, self-declared M / F / Other label, chosen topic and optional Bio. Your private username and professional profile stay out of that view.</p>
        </div>
      </li>
      <li>
        <span class="journey-number" aria-hidden="true">02</span>
        <div>
          <h3>Choose a topic and join the queue</h3>
          <p>Talk about careers, workplace culture or another work topic. Choose General Talk to keep things open. Guest, Free and Premium participants share one matching pool.</p>
          <p class="detail">A match must respect both people’s effective gender preferences and blocks. Waiting depends on who is available. You can cancel; there is no guaranteed match or advertised wait time.</p>
        </div>
      </li>
      <li>
        <span class="journey-number" aria-hidden="true">03</span>
        <div>
          <h3>Start with text. Choose audio together.</h3>
          <p>Use plain text and emoji. Either person can invite the other to an audio call; it starts only after acceptance and microphone permission. Text remains available if you decline audio.</p>
          <p class="detail">There is no video, file sharing, product recording, offline inbox or saved conversation history. One active conversation or call per identity keeps the interaction clear.</p>
        </div>
      </li>
      <li>
        <span class="journey-number" aria-hidden="true">04</span>
        <div>
          <h3>Move on, or stay connected</h3>
          <p>Use Next or End when you want to leave. Report and Block remain accessible to every tier. Add a friend only when you both agree; guests can add and invite friends too.</p>
          <p class="detail">A friendship involving a guest lasts only while that guest identity lasts. A friendship between two accounts can be saved. Reconnecting always needs a fresh invitation while both people are online.</p>
        </div>
      </li>
    </ol>
  </div>
</section>

<section class="section" aria-labelledby="choices-title">
  <div class="content-width">
    <div class="section-heading">
      <p class="eyebrow">The choices are yours</p>
      <h2 id="choices-title">No need to turn a conversation into a commitment.</h2>
    </div>
    <div class="card-grid">
      <article class="info-card">
        <h3>Start as a guest</h3>
        <p>Use a temporary identity. Guest friends are temporary too; you do not have to register to make or contact them.</p>
      </article>
      <article class="info-card">
        <h3>Keep an account</h3>
        <p>A private username, password and recovery code support returning access. Normal registration needs no phone, email, employer or identity document.</p>
      </article>
      <article class="info-card">
        <h3>Add Premium choice</h3>
        <p>Optional fixed-duration Premium adds matching preferences. Text, accepted audio, friends and safety are available without it.</p>
      </article>
    </div>
    <div class="page-actions choices-links">
      <a class="text-link" href="/premium">Compare Guest, Free and Premium <span aria-hidden="true">→</span></a>
      <a class="text-link" href="/safety">Understand the safety controls <span aria-hidden="true">→</span></a>
    </div>
  </div>
</section>

<section class="section section-muted" aria-labelledby="before-title">
  <div class="reading-width">
    <p class="eyebrow">Before you join</p>
    <h2 class="section-title" id="before-title">A little context goes a long way.</h2>
    <div class="questions">
      <details>
        <summary>Are the people I meet verified professionals?</summary>
        <p>No. Gender and professional details are self-declared. NoTitle is a place to exchange experiences, not proof of someone’s identity, employment or expertise.</p>
      </details>
      <details>
        <summary>What does “anonymous” mean here?</summary>
        <p>Anonymous to the people you meet: you use a pseudonym instead of a required real name. NoTitle and its service providers still handle network and security information. Text is relayed by the server, and another person could capture it. Reports and lawful disclosures have separate privacy limits.</p>
        <a class="text-link" href="/privacy">Read the privacy details</a>
      </details>
      <details>
        <summary>Can I return to a conversation later?</summary>
        <p>There is no chat history or offline inbox. Ending a conversation clears ordinary conversation content under the reviewed retention policy. Mutually accepted friends can send a new invitation when both are online.</p>
      </details>
      <details>
        <summary>Does Premium put me in a separate pool?</summary>
        <p>No. Everyone shares one pool. Guest and Free accounts use Everyone as their effective gender preference. Premium can select Everyone or one specific gender option, and both people’s preferences must agree.</p>
      </details>
    </div>
    <div class="closing">
      <Button href="/chat">Start a Conversation</Button>
      <p>Opens your conversation space. You choose when to join the live queue.</p>
    </div>
  </div>
</section>

<style>
  .journey {
    display: grid;
    gap: 1rem;
  }

  .journey-list {
    margin: 0;
    padding: 0;
    list-style: none;
  }

  .journey-list li {
    display: grid;
    grid-template-columns: 2rem minmax(0, 1fr);
    gap: 0.75rem;
    padding-block: 1.75rem;
    border-top: 1px solid var(--border);
  }

  .journey-list li:first-child {
    padding-top: 0;
    border-top: 0;
  }

  .journey-number {
    padding-top: 0.15rem;
    color: var(--accent-strong);
    font-size: 0.875rem;
    font-weight: 700;
  }

  .journey-list h3 {
    margin: 0 0 0.8rem;
    font-size: 1.25rem;
    line-height: 1.35;
    letter-spacing: -0.02em;
  }

  .journey-list p {
    margin: 0 0 0.75rem;
    color: var(--text-secondary);
  }

  .journey-list .detail {
    margin-bottom: 0;
    font-size: 0.875rem;
  }

  .choices-links {
    margin-top: 1.5rem;
  }

  .questions {
    margin-top: 2rem;
  }

  .questions details {
    border-bottom: 1px solid var(--border-strong);
  }

  .questions details:first-child {
    border-top: 1px solid var(--border-strong);
  }

  .questions summary {
    min-height: 2.75rem;
    padding-block: 1.1rem;
    font-weight: 650;
    line-height: 1.5;
    cursor: pointer;
  }

  .questions p {
    margin: 0 0 1rem;
    color: var(--text-secondary);
  }

  .questions a {
    margin-bottom: 0.75rem;
  }

  .closing {
    margin-top: 2.5rem;
  }

  .closing p {
    margin: 0.75rem 0 0;
    color: var(--text-secondary);
    font-size: 0.8125rem;
  }

  @media (min-width: 56rem) {
    .journey {
      grid-template-columns: minmax(0, 0.8fr) minmax(0, 1.2fr);
      gap: 4rem;
    }

    .journey-list li {
      grid-template-columns: 2.25rem minmax(0, 1fr);
      gap: 1rem;
    }
  }
</style>
