<script lang="ts">
  import type { RealtimeClient } from '../realtime/client';
  import type { LiveState } from '../realtime/model';
  import { connectionLabel } from './model';
  export let realtime: RealtimeClient | null;
  export let live: LiveState;
  $: snapshot = live.snapshot;
  $: request = snapshot?.friend_request;
  $: connected = Boolean(snapshot?.interaction?.friend_ref || live.connectedFriend);
  $: available = live.status === 'connected' && !live.pending && !live.friendPending && snapshot?.interaction?.peer_connected;
</script>

{#if snapshot?.friends_enabled && snapshot.interaction}
  <section class="connection" aria-labelledby="stay-connected-title">
    <div><h3 id="stay-connected-title">Stay connected</h3><p>Keep in touch only when both of you agree. No account is required.</p></div>
    {#if connected}
      <p class="notice">You are connected. {live.connectedFriend ? connectionLabel(live.connectedFriend) + '.' : 'Open your friends list to check whether this connection is saved or temporary.'}</p>
      <a href="/friends">Open friends</a>
    {:else if request?.direction === 'incoming'}
      <p class="notice">{snapshot.interaction.peer.display_name} would like to stay connected.</p>
      <div class="actions"><button class="primary" disabled={!available} on:click={() => realtime?.friendCommand('friend.accept', { request_ref: request?.request_ref })}>Accept connection</button><button disabled={!available} on:click={() => realtime?.friendCommand('friend.decline', { request_ref: request?.request_ref })}>Not now</button></div>
      <p>Your choice is private. They are not notified of a rejection.</p>
    {:else if request?.direction === 'outgoing'}
      <p class="notice">Request sent. A connection is created only if you both agree.</p>
      <button disabled={!available} on:click={() => realtime?.friendCommand('friend.withdraw', { request_ref: request?.request_ref })}>Withdraw request</button>
    {:else}
      <button class="primary" disabled={!available} on:click={() => realtime?.friendCommand('friend.request')}>Stay Connected</button>
    {/if}
    <p>Guest connections last while both identities remain valid. End or Next keeps accepted connections; ending a guest session or a server restart clears its temporary connections.</p>
    {#if live.friendNotice}<p class="notice" role="status">{live.friendNotice}</p>{/if}
  </section>
{/if}

<style>
  .connection { display: grid; gap: 0.75rem; border-top: 1px solid var(--border); padding-top: 1rem; min-width: 0; }
  h3, p { margin: 0; overflow-wrap: anywhere; }
  h3 { font-size: 1.125rem; margin-bottom: 0.35rem; }
  p { color: var(--text-secondary); font-size: 0.875rem; }
  .notice { color: var(--text-primary); }
  .actions { display: flex; gap: 0.5rem; flex-wrap: wrap; }
  button, a { display: inline-flex; align-items: center; justify-content: center; min-height: 2.875rem; min-width: 2.75rem; padding: 0.65rem 0.8rem; border: 1px solid var(--border-strong); border-radius: var(--radius-md); color: var(--text-primary); background: var(--surface); font: inherit; font-weight: 650; cursor: pointer; text-decoration: none; }
  button:disabled { opacity: 0.6; cursor: not-allowed; }
  .primary { background: var(--accent-strong); color: white; border-color: var(--accent-strong); }
</style>
