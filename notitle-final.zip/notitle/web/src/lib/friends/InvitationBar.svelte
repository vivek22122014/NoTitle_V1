<script lang="ts">
  import { onMount } from 'svelte';
  import { currentRealtime, subscribeRealtime } from '../realtime/session';
  import { initialState } from '../realtime/model';
  import { invitationSeconds } from './model';
  let live = initialState();
  let now = Date.now();
  $: invitation = live.snapshot?.friend_invitations.find((item) => Date.parse(item.expires_at) > now);
  $: available = live.status === 'connected' && !live.friendPending;
  $: idle = live.snapshot?.state === 'IDLE';
  onMount(() => {
    const unsubscribe = subscribeRealtime((state) => { live = state; now = Date.now(); });
    const timer = setInterval(() => { now = Date.now(); }, 1000);
    const refresh = () => { now = Date.now(); };
    document.addEventListener('visibilitychange', refresh);
    return () => { unsubscribe(); clearInterval(timer); document.removeEventListener('visibilitychange', refresh); };
  });
</script>

{#if invitation && live.status === 'connected'}
  <aside class="invitation-bar" aria-label="Friend invitation">
    <div>
      <p role="status">{invitation.direction === 'incoming' ? `${invitation.display_name} invites you to ${invitation.kind === 'text' ? 'a text conversation' : 'an audio conversation'}.` : `${invitation.kind === 'audio' ? 'Audio' : 'Text'} invitation sent to ${invitation.display_name}.`}</p>
      <p class="help">Expires in {invitationSeconds(invitation, now)} seconds. No offline invitation is saved.</p>
      {#if !idle && invitation.direction === 'incoming'}<p class="help">Your current conversation or search stays active. Finish it before accepting.</p>{/if}
      {#if invitation.kind === 'audio'}<p class="help">{live.snapshot?.audio_enabled ? 'Accepting authorizes microphone access for this call. Your browser may ask for permission.' : 'Audio is unavailable on this server.'}</p>{/if}
    </div>
    {#if invitation.direction === 'incoming'}<div class="actions"><button disabled={!available || !idle || Boolean(live.snapshot?.maintenance) || (invitation.kind === 'audio' && !live.snapshot?.audio_enabled)} on:click={() => currentRealtime()?.friendCommand('friend.accept_invite', { invitation_ref: invitation?.invitation_ref })}>Accept invitation</button><button disabled={!available} on:click={() => currentRealtime()?.friendCommand('friend.decline_invite', { invitation_ref: invitation?.invitation_ref })}>Decline invitation</button></div>{/if}
  </aside>
{/if}

<style>
  .invitation-bar { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 0.75rem 1rem; padding: 1rem max(1rem, env(safe-area-inset-left)); border-bottom: 1px solid var(--border); background: var(--surface-accent); }
  .invitation-bar > div { min-width: 0; }
  p { margin: 0; overflow-wrap: anywhere; }
  .help { margin-top: 0.35rem; font-size: 0.85rem; color: var(--text-secondary); }
  .actions { display: flex; flex-wrap: wrap; gap: 0.5rem; }
  button { min-height: 2.875rem; min-width: 2.75rem; padding: 0.65rem 0.8rem; border: 1px solid var(--border-strong); border-radius: var(--radius-md); background: var(--surface); color: var(--text-primary); font: inherit; font-weight: 650; cursor: pointer; }
  button:disabled { opacity: 0.6; cursor: not-allowed; }
</style>
