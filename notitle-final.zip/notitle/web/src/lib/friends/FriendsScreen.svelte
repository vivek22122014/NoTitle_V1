<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import { ApiError } from '../api/client';
  import { IdentityClient } from '../identity/client';
  import type { Owner } from '../identity/model';
  import { minutesRemaining } from '../identity/model';
  import { acquireRealtime, subscribeRealtime, resetRealtime } from '../realtime/session';
  import type { RealtimeClient } from '../realtime/client';
  import { initialState } from '../realtime/model';
  import Dialog from '../components/Dialog.svelte';
  import { connectionLabel } from './model';
  import type { Friend } from './model';

  const client = new IdentityClient();
  let identity: Owner | null = null;
  let realtime: RealtimeClient | null = null;
  let live = initialState();
  let friends: Friend[] = [];
  let initializing = true;
  let loading = false;
  let busy = false;
  let error = '';
  let notice = '';
  let takeoverConfirmed = false;
  let selection: { friend: Friend; action: 'remove' | 'block' } | null = null;
  let alive = true;
  let refreshAgain = false;
  let refreshTimer: ReturnType<typeof setTimeout> | undefined;
  let observedRevision = -1;
  let now = Date.now();
  $: available = live.status === 'connected' && live.snapshot?.friends_enabled === true;
  $: idle = live.snapshot?.state === 'IDLE' && !live.snapshot?.maintenance;
  $: invitationPending = Boolean(live.snapshot?.friend_invitations.some((item) => Date.parse(item.expires_at) > now));
  $: remaining = identity ? minutesRemaining(identity, now) : 0;

  function showError(value: unknown): void {
    error = value instanceof ApiError ? value.message : 'Your connections could not be loaded. Please try again.';
    if (value instanceof ApiError && value.status === 401) { identity = null; friends = []; resetRealtime(); }
  }
  async function load(): Promise<void> {
    if (!identity || !alive) return;
    if (loading) { refreshAgain = true; return; }
    loading = true; error = '';
    try { const result = await client.friends(); if (alive) friends = result; }
    catch (value) { if (alive) { friends = []; showError(value); } }
    finally {
      if (alive) {
        loading = false;
        if (refreshAgain) { refreshAgain = false; scheduleRefresh(); }
      }
    }
  }
  function scheduleRefresh(): void {
    if (!identity || refreshTimer !== undefined) return;
    refreshTimer = setTimeout(() => { refreshTimer = undefined; void load(); }, 150);
  }
  async function initialize(): Promise<void> {
    initializing = true; error = '';
    try {
      const session = await client.current();
      if (!alive) return;
      identity = session?.identity ?? null;
      if (!identity) { resetRealtime(); return; }
      realtime = acquireRealtime(identity.kind === 'guest');
      await load();
    } catch (value) { if (alive) showError(value); }
    finally { if (alive) initializing = false; }
  }
  async function checkSession(): Promise<void> {
    await initialize();
    if (alive && identity && ['expired', 'replaced', 'restart'].includes(live.status)) realtime?.startFresh();
  }
  function invite(friend: Friend, kind: 'text' | 'audio' = 'text'): void {
    if (friend.presence !== 'online' || !available || !idle || invitationPending || busy) return;
    const sent = realtime?.friendCommand('friend.invite', { friend_ref: friend.ref, kind });
    if (!sent) notice = 'The invitation could not be sent. Check your connection and try again.';
  }
  async function confirmAction(): Promise<void> {
    const selected = selection; if (!selected || busy) return;
    busy = true; error = ''; notice = '';
    if (live.snapshot?.interaction?.friend_ref === selected.friend.ref) realtime?.clearConversationText();
    try {
      if (selected.action === 'block') await client.block({ friend_ref: selected.friend.ref });
      else await client.removeFriend(selected.friend.ref);
      if (!alive) return;
      selection = null;
      notice = selected.action === 'block' ? 'Block applied. Your connection is removed. Unblocking does not restore it.' : 'Connection removed. Any active friend conversation has ended.';
      await load();
    } catch (value) {
      if (alive) {
        await load();
        showError(value);
        if (selected.action === 'block') error = 'Storage confirmation failed. A local block may already apply. Check your blocks in the conversation space. ' + error;
      }
    } finally { if (alive) busy = false; }
  }
  onMount(() => {
    const unsubscribe = subscribeRealtime((state) => {
      live = state;
      if (state.friendsRevision !== observedRevision) { observedRevision = state.friendsRevision; scheduleRefresh(); }
      if (['expired', 'restart', 'replaced'].includes(state.status)) { friends = []; selection = null; }
    });
    const timer = setInterval(() => { now = Date.now(); }, 1000);
    void initialize();
    return () => { unsubscribe(); clearInterval(timer); clearTimeout(refreshTimer); };
  });
  onDestroy(() => { alive = false; client.dispose(); friends = []; selection = null; });
</script>

<section class="friends-page content-width" aria-labelledby="friends-title">
  <header class="heading"><p class="eyebrow">Mutual connections</p><h1 id="friends-title">People you chose to keep</h1><p>Both people agree before a connection appears here. Guest and account members can connect and invite each other.</p></header>
  <nav class="space-nav" aria-label="Your space"><a href="/chat">Conversation space</a><a href="/profile">Your profile</a><a href="/settings">Settings</a></nav>
  {#if error && !identity}<p class="error" role="alert">{error}</p>{/if}
  {#if initializing}<p role="status">Loading your connections…</p>
  {:else if !identity}
    <div class="card panel"><h2>Use your current identity</h2><p>Start as a guest or sign in to see your own connections. No account is required to make friends.</p><div class="actions"><a class="primary" href="/chat">Start as a guest</a><a href="/login">Sign in</a></div></div>
  {:else}
    <section class="card panel" aria-labelledby="friend-availability-title">
      <h2 id="friend-availability-title">Your availability</h2>
      {#if live.status === 'takeover'}
        <p>Another tab or session owns your connection. Moving it here ends its active conversation.</p><label class="check"><input type="checkbox" bind:checked={takeoverConfirmed} /><span>I want to replace my other connection.</span></label><button disabled={!takeoverConfirmed} on:click={() => { if (takeoverConfirmed) { takeoverConfirmed = false; void realtime?.connect(true); } }}>Move connection here</button>
      {:else if ['expired', 'replaced', 'restart'].includes(live.status)}
        <p>{live.message}</p><button on:click={checkSession}>Check my session</button>
      {:else if live.status === 'connected'}
        <p>{live.snapshot?.maintenance ? 'Maintenance is scheduled. New invitations are paused; you can still manage your connections.' : !live.snapshot?.friends_enabled ? 'Friend features are unavailable on this server.' : idle ? 'You are online and available for an invitation.' : 'You are busy. Your current conversation or search stays active.'}</p>
        {#if !idle}<a href="/chat">Return to your conversation</a>{/if}
      {:else}
        <p>{live.status === 'reconnecting' ? 'Reconnecting. Invitations are paused.' : 'Connect to receive invitations. This does not start a search or interrupt another tab.'}</p><button class="primary" disabled={['connecting', 'reconnecting'].includes(live.status)} on:click={() => realtime?.connect()}>{live.status === 'connecting' ? 'Connecting…' : 'Connect for invitations'}</button>
      {/if}
      <p class="help">Presence is visible only to accepted, unblocked friends. Invitations last 30 seconds, require acceptance and are never saved for an offline person. {live.snapshot?.audio_enabled ? 'An audio invitation authorizes microphone access for that call after your friend accepts.' : 'Audio is unavailable on this server.'}</p>
    </section>
    {#if identity.kind === 'guest'}<aside class="temporary"><h2>Your guest connections are temporary</h2><p>They survive End, Next, refresh and brief disconnections while this guest identity is valid. Ending either guest identity, losing its cookie or a server restart makes its links unavailable. Simply having friends does not extend your guest session.</p><p>Create an account only if you want to preserve your identity. A connection is saved only after both people become accounts and the server confirms saving.</p><a href="/register">Optional: create an account</a>{#if remaining <= 5}<p role="status">Your guest session may expire in about {remaining} minute{remaining === 1 ? '' : 's'} without authorized activity. Temporary links expire with it.</p>{/if}</aside>{/if}
    <section class="card panel" aria-labelledby="friend-list-title">
      <div class="list-heading"><h2 id="friend-list-title">Your friends <span>({friends.length})</span></h2><button disabled={loading || busy} on:click={load}>{loading ? 'Refreshing…' : 'Refresh friends'}</button></div>
      {#if error}<p class="error" role="alert">{error}</p>{/if}
      {#if notice || live.friendNotice}<p class="notice" role="status">{notice || live.friendNotice}</p>{/if}
      {#if !friends.length && !loading && !error}<div class="empty"><h3>No connections yet</h3><p>In a conversation, choose Stay Connected. Your partner can accept without registering. A new identity cannot recover a guest’s old links.</p><a href="/chat">Open conversation space</a></div>{/if}
      <ul>{#each friends as friend (friend.ref)}<li>
        <div class="friend-info"><h3>{friend.display_name}</h3><p class="presence">{live.status !== 'connected' ? 'Connect to check availability' : friend.presence === 'online' ? 'Online · available' : friend.presence === 'busy' ? 'Busy' : 'Offline'}</p><p class="help">{connectionLabel(friend)}</p>{#if friend.pending}<p class="help">Mutual consent is preserved. This link is not durable yet; the service retries saving it.</p>{/if}</div>
        <div class="actions"><button class="primary" disabled={!available || !idle || friend.presence !== 'online' || invitationPending || live.friendPending || busy} on:click={() => invite(friend)}>Invite to text<span class="sr-only"> with {friend.display_name}</span></button>{#if live.snapshot?.audio_enabled}<button disabled={!available || !idle || friend.presence !== 'online' || invitationPending || live.friendPending || busy} on:click={() => invite(friend, 'audio')}>Invite to audio<span class="sr-only"> with {friend.display_name}</span></button>{/if}<button disabled={busy} on:click={() => { selection = { friend, action: 'remove' }; }}>Remove<span class="sr-only"> {friend.display_name}</span></button><button class="danger" disabled={busy} on:click={() => { selection = { friend, action: 'block' }; }}>Block<span class="sr-only"> {friend.display_name}</span></button></div>
      </li>{/each}</ul>
      <p class="help">Remove ends an active friend conversation. Block also prevents matching and invitations between these identities. Unblock never restores a connection. Temporary guest blocks cannot identify someone returning as a new guest.</p>
    </section>
  {/if}
</section>

<Dialog id="friend-action" open={Boolean(selection)} title={selection?.action === 'block' ? 'Block this connection?' : 'Remove this connection?'} on:close={() => { if (!busy) selection = null; }}>
  {#if selection}<p>{selection.friend.display_name}</p><p>{selection.action === 'block' ? 'This removes your connection and prevents matching and invitations between these identities.' : 'This removes the mutual connection and ends any active friend conversation. A future connection will need mutual consent again.'}</p>{#if error}<p class="error" role="alert">{error}</p>{/if}{/if}<button slot="actions" disabled={busy} on:click={() => { selection = null; }}>Cancel</button><button slot="actions" class="danger" disabled={busy} on:click={confirmAction}>{busy ? 'Applying…' : selection?.action === 'block' ? 'Block connection' : 'Remove connection'}</button>
</Dialog>

<style>
  .friends-page { max-width: 64rem; padding-block: 2rem 4rem; display: grid; gap: 1.25rem; }
  .heading { max-width: 43rem; }
  h1 { font-size: clamp(2rem, 6vw, 3.3rem); line-height: 1.12; letter-spacing: -0.04em; margin: 0 0 1rem; }
  h2 { font-size: 1.2rem; margin: 0; }
  h3 { font-size: 1.05rem; margin: 0; overflow-wrap: anywhere; }
  p { margin: 0; color: var(--text-secondary); overflow-wrap: anywhere; }
  .eyebrow { margin-bottom: 0.75rem; }
  .space-nav, .actions, .list-heading { display: flex; flex-wrap: wrap; gap: 0.5rem; }
  .list-heading { align-items: center; justify-content: space-between; }
  .list-heading span { color: var(--text-secondary); font-weight: 400; }
  .panel, .temporary, .empty { display: grid; gap: 0.875rem; min-width: 0; padding: clamp(1rem, 3vw, 1.5rem); }
  .temporary { background: var(--surface-subtle); border-radius: var(--radius-md); border: 1px solid var(--border); }
  .temporary h2 { font-size: 1rem; }
  .temporary p, .help { font-size: 0.85rem; }
  .notice { background: var(--surface-accent); padding: 0.875rem; border-radius: var(--radius-md); color: var(--text-primary); }
  .error, .danger { color: var(--danger); }
  a, button { display: inline-flex; align-items: center; justify-content: center; min-height: 2.875rem; min-width: 2.75rem; padding: 0.65rem 0.8rem; border: 1px solid var(--border-strong); border-radius: var(--radius-md); background: var(--surface); color: var(--text-primary); font: inherit; font-weight: 650; text-decoration: none; cursor: pointer; }
  button:disabled { opacity: 0.6; cursor: not-allowed; }
  .primary { color: white; background: var(--accent-strong); border-color: var(--accent-strong); }
  .danger { color: var(--danger); }
  ul { margin: 0; padding: 0; list-style: none; }
  li { display: grid; gap: 0.85rem; padding-block: 1rem; border-top: 1px solid var(--border); min-width: 0; }
  .friend-info { display: grid; gap: 0.35rem; min-width: 0; }
  .presence { font-size: 0.875rem; }
  .check { display: flex; gap: 0.65rem; align-items: flex-start; min-height: 2.75rem; }
  .check input { width: 1.125rem; height: 1.125rem; margin-top: 0.2rem; flex-shrink: 0; }
  @media (min-width: 48rem) { li { grid-template-columns: minmax(0, 1fr) auto; align-items: center; gap: 1.5rem; } li .actions { justify-content: flex-end; max-width: 23rem; } }
</style>
