/** Owner-only projections. Relationship handles never expose an identity ID. */
export type Presence = 'online' | 'busy' | 'offline';
export interface Friend { ref: string; display_name: string; created_at: string; durable: boolean; pending: boolean; presence: Presence }
export interface FriendRequest { request_ref: string; direction: 'incoming' | 'outgoing' }
export interface FriendInvitation { invitation_ref: string; friend_ref: string; kind: 'text' | 'audio'; expires_at: string; display_name: string; direction: 'incoming' | 'outgoing' }
export const friendRef = (value: unknown): value is string => typeof value === 'string' && /^[A-Za-z0-9_-]{16,128}$/u.test(value);
const record = (value: unknown): value is Record<string, unknown> => Boolean(value) && typeof value === 'object' && !Array.isArray(value);
const date = (value: unknown): value is string => typeof value === 'string' && value.length <= 64 && Number.isFinite(Date.parse(value));
const name = (value: unknown): value is string => typeof value === 'string' && value.length > 0 && Array.from(value).length <= 128;
export function parseFriend(value: unknown): Friend | null {
  if (!record(value) || !friendRef(value.ref) || !name(value.display_name) || !date(value.created_at) || typeof value.durable !== 'boolean' || typeof value.pending !== 'boolean' || (value.durable && value.pending) || !['online', 'busy', 'offline'].includes(String(value.presence))) return null;
  return { ref: value.ref, display_name: value.display_name, created_at: value.created_at, durable: value.durable, pending: value.pending, presence: value.presence as Presence };
}
export function parseFriends(value: unknown): Friend[] {
  if (!record(value) || !Array.isArray(value.friends) || value.friends.length > 100) throw new Error('Invalid friends response');
  const result = value.friends.map(parseFriend);
  if (result.some((item) => !item) || new Set(result.map((item) => item?.ref)).size !== result.length) throw new Error('Invalid friends response');
  return result as Friend[];
}
export function parseFriendRequest(value: unknown): FriendRequest | null {
  if (!record(value) || !friendRef(value.request_ref) || !['incoming', 'outgoing'].includes(String(value.direction))) return null;
  return { request_ref: value.request_ref, direction: value.direction as FriendRequest['direction'] };
}
export function parseInvitation(value: unknown): FriendInvitation | null {
  if (!record(value) || !friendRef(value.invitation_ref) || !friendRef(value.friend_ref) || !name(value.display_name) || !date(value.expires_at) || !['text', 'audio'].includes(String(value.kind)) || !['incoming', 'outgoing'].includes(String(value.direction))) return null;
  return { invitation_ref: value.invitation_ref, friend_ref: value.friend_ref, kind: value.kind as FriendInvitation['kind'], expires_at: value.expires_at, display_name: value.display_name, direction: value.direction as FriendInvitation['direction'] };
}
export function connectionLabel(friend: Friend): string {
  return friend.durable ? 'Saved to your account' : friend.pending ? 'Temporary · saving to accounts is pending' : 'Temporary guest connection';
}
export function invitationSeconds(invitation: FriendInvitation, now: number): number {
  return Math.min(30, Math.max(0, Math.ceil((Date.parse(invitation.expires_at) - now) / 1000)));
}
