<script lang="ts">
  import DesignDialog from './DesignDialog.svelte';
  export let conversationActive = false;
  type FriendState = 'Available' | 'Busy' | 'Offline';
  let availability: FriendState = 'Available';
  let visible = true;
  let invitation: 'none' | 'pending' | 'expired' = 'none';
  let notice = '';
  let removeOpen = false;
  let inviteKind = '';

  function invite(kind: string) {
    if (conversationActive) { notice = 'End the current conversation first. One identity can have only one active interaction.'; return; }
    inviteKind = kind;
    invitation = 'pending';
    notice = `${kind} invitation preview. A fresh acceptance is required; no invitation was sent.`;
  }
</script>

<section aria-labelledby="friends-title" class="friends card">
  <p class="eyebrow">Simulated friend states</p><h2 id="friends-title">Stay connected, on your terms.</h2>
  <p>Available to Guest, Free and Premium. These are labeled sample states, not real people or online counts.</p>
  <label for="friend-availability">Preview availability</label>
  <select id="friend-availability" bind:value={availability} on:change={() => { invitation = 'none'; notice = ''; }}><option>Available</option><option>Busy</option><option>Offline</option></select>
  {#if visible}
    <article class="friend">
      <div><h3>Sample accepted friend</h3><p>{availability} · <strong>Temporary</strong></p></div>
      <p>This guest link lasts only while both guest identities remain active. If either guest identity ends or expires, the link disappears. There is no last-seen history or offline inbox.</p>
      <div class="actions">
        <button type="button" disabled={availability !== 'Available' || invitation === 'pending'} on:click={() => invite('Text')}>Invite</button>
        <button type="button" disabled={availability !== 'Available' || invitation === 'pending'} on:click={() => invite('Audio')}>Call</button>
        <button type="button" aria-haspopup="dialog" on:click={() => removeOpen = true}>Remove</button>
      </div>
      {#if availability !== 'Available'}<p>{availability === 'Busy' ? 'This friend is in another interaction. Try again when they become available.' : 'Both people must be online. No invitation is queued for later.'}</p>{/if}
      {#if invitation === 'pending'}<div class="actions"><button type="button" on:click={() => { invitation = 'none'; notice = `${inviteKind} acceptance preview. No real conversation or audio was started.`; }}>Simulate acceptance</button><button type="button" on:click={() => { invitation = 'expired'; notice = 'Invitation expired. A new invitation and acceptance are required.'; }}>Simulate expiry</button></div>{/if}
      {#if invitation === 'expired'}<p>Expired invitation · no active interaction.</p>{/if}
    </article>
  {:else}
    <div class="empty"><h3>No friends yet</h3><p>Use Stay Connected during a conversation. A link is added only after both people agree.</p><button type="button" on:click={() => { visible = true; notice = ''; }}>Restore sample friend</button></div>
  {/if}
  <p role="status" aria-live="polite" aria-atomic="true">{notice}</p>
</section>

<DesignDialog id="preview-remove" bind:open={removeOpen} title="Remove this friend?">
  <p>Removing a friend ends this link. It does not block the person. Use Block for safety concerns.</p>
  <div class="actions"><button type="button" on:click={() => removeOpen = false}>Keep friend</button><button type="button" on:click={() => { removeOpen = false; visible = false; invitation = 'none'; notice = 'Sample friend removed from this page only.'; }}>Remove sample friend</button></div>
</DesignDialog>

<style>
  .friends { padding: 1.25rem; }
  .eyebrow { color: var(--accent-strong); font-size: 0.8rem; font-weight: 650; }
  h2 { line-height: 1.25; }
  p { color: var(--text-secondary); }
  .friend, .empty { padding: 1rem; margin-top: 1rem; border: 1px solid var(--border); border-radius: var(--radius-md); }
  .friend h3 { margin: 0; font-size: 1rem; }
  .friend p { font-size: 0.9rem; }
  label { display: block; margin-bottom: 0.4rem; }
  select, button { min-height: 44px; min-width: 44px; padding: 0.5rem 0.75rem; border: 1px solid var(--border-strong); border-radius: var(--radius-sm); background: var(--surface); color: var(--text-primary); }
  select { max-width: 100%; width: 100%; }
  .actions { display: flex; flex-wrap: wrap; gap: 0.5rem; }
  button { cursor: pointer; }
  button:disabled { opacity: 0.6; cursor: not-allowed; }
</style>
