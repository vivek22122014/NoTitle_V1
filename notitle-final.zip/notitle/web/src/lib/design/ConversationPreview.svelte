<script lang="ts">
  import { tick } from 'svelte';
  import DesignDialog from './DesignDialog.svelte';
  import { transition, type PreviewState, type PreviewEvent, type Topic } from './state';
  import { visibleViewport } from './viewport';
  import { focusScope } from './focus-scope';

  export let state: PreviewState;
  export let topic: Topic;
  let focused = false;
  let composer: HTMLTextAreaElement;
  let reportTrigger: HTMLButtonElement;
  let moreOpen = false;
  let reportOpen = false;
  let friendOpen = false;
  let confirmAction: 'next' | 'end' | 'block' | null = null;
  let confirmOpen = false;
  let reportReason = '';
  let reportError = '';
  let notice = '';
  let requestSent = false;
  let friendAccepted = false;

  function send(event: PreviewEvent) { state = transition(state, event); }
  async function confirm(action: 'next' | 'end' | 'block') {
    confirmAction = action;
    moreOpen = false;
    await tick();
    confirmOpen = true;
  }
  function finish() {
    state = transition(state, { type: confirmAction === 'next' ? 'next' : 'end' });
    confirmOpen = false;
  }
  async function focusConversation() {
    focused = true;
    await tick();
    composer?.focus();
  }
  async function openReport() {
    moreOpen = false;
    await tick();
    reportOpen = true;
    reportError = '';
  }
  function previewReport() {
    if (!reportReason) { reportError = 'Choose a reason to preview the report confirmation.'; return; }
    reportOpen = false;
    reportReason = '';
    notice = 'Report confirmation preview. No report was submitted and no evidence was stored.';
  }
</script>

<section class:focused class="conversation card" use:visibleViewport use:focusScope={{ active: focused, onexit: () => focused = false }} role={focused ? 'dialog' : 'region'} aria-modal={focused ? true : undefined} aria-label="Simulated conversation">
  <header class="conversation-header">
    <div>
      <p class="eyebrow">Simulated conversation</p>
      <h2>Sample participant <span class="gender">F</span></h2>
      <p class="secondary">{topic} · Gender is self-declared</p>
    </div>
    <button type="button" aria-pressed={focused} on:click={() => focused ? (focused = false) : focusConversation()}>{focused ? 'Exit focus view' : 'Focus chat'}</button>
  </header>

  <div class="status" role="status" aria-live="polite" aria-atomic="true">
    {#if state.connection === 'reconnecting'}
      Reconnecting preview. Your text is kept on this page. Report and Block remain reachable.
    {:else if state.connection === 'failed'}
      Connection failed preview. Your unsent text is kept. Retry or end the conversation.
    {:else}
      Layout preview only. No one is connected; messages stay in this page’s memory.
    {/if}
    {#if state.connection !== 'connected'}<button type="button" on:click={() => send({ type: 'connection', value: 'connected' })}>Simulate retry</button>{/if}
  </div>

  <div class="transcript" role="log" aria-label="Local preview messages" aria-live="polite" aria-relevant="additions">
    {#if state.messages.length === 0}
      <div class="empty-conversation"><h3>A thought is a good place to start.</h3><p>Try the composer to inspect wrapping and keyboard behavior. No message is sent.</p></div>
    {/if}
    {#each state.messages as message, index (`${index}-${message}`)}
      <p class="message"><span class="sr-only">Your local preview: </span>{message}</p>
    {/each}
  </div>

  {#if state.audio !== 'idle'}
    <section class="audio-panel" aria-label="Simulated audio controls">
      <p role="status" aria-live="polite">
        {#if state.audio === 'incoming'}Sample incoming audio invitation. Text remains available.
        {:else if state.audio === 'outgoing'}Audio invitation preview. Waiting for mutual acceptance.
        {:else if state.audio === 'permission'}Microphone permission preview. This demo never requests microphone access.
        {:else if state.audio === 'connecting'}Connecting audio preview. Text remains available.
        {:else if state.audio === 'denied'}Microphone access denied preview. You can keep using text or retry after changing browser permissions.
        {:else if state.audio === 'failed'}Audio connection failed preview. Text remains available.
        {:else}Audio connected preview · {state.muted ? 'Muted' : 'Microphone on (simulated)'}. No media is captured.
        {/if}
      </p>
      <div class="actions">
        {#if state.audio === 'incoming'}
          <button type="button" on:click={() => send({ type: 'audio', value: 'permission' })}>Accept</button>
          <button type="button" on:click={() => send({ type: 'audio', value: 'idle' })}>Decline</button>
        {:else if state.audio === 'outgoing'}
          <button type="button" on:click={() => send({ type: 'audio', value: 'permission' })}>Simulate acceptance</button>
        {:else if state.audio === 'permission'}
          <button type="button" on:click={() => send({ type: 'audio', value: 'connecting' })}>Simulate permission granted</button>
          <button type="button" on:click={() => send({ type: 'audio', value: 'denied' })}>Simulate permission denied</button>
        {:else if state.audio === 'connecting'}
          <button type="button" on:click={() => send({ type: 'audio', value: 'connected' })}>Simulate connected</button>
          <button type="button" on:click={() => send({ type: 'audio', value: 'failed' })}>Simulate failure</button>
        {:else if state.audio === 'connected'}
          <button type="button" aria-pressed={state.muted} on:click={() => send({ type: 'mute' })}>{state.muted ? 'Unmute' : 'Mute'}</button>
        {:else}
          <button type="button" on:click={() => send({ type: 'audio', value: 'permission' })}>Retry audio preview</button>
        {/if}
        {#if state.audio !== 'incoming'}<button type="button" on:click={() => send({ type: 'audio', value: 'idle' })}>End audio</button>{/if}
      </div>
    </section>
  {/if}

  <div class="conversation-tools" aria-label="Conversation actions">
    <button type="button" disabled={state.audio !== 'idle' || state.connection !== 'connected'} on:click={() => send({ type: 'audio', value: 'outgoing' })}>Call</button>
    <button type="button" on:click={() => confirm('next')}>Next</button>
    <button type="button" aria-haspopup="dialog" on:click={() => moreOpen = true}>More</button>
    <button type="button" class="safety" bind:this={reportTrigger} aria-haspopup="dialog" on:click={openReport}>Report &amp; Block</button>
  </div>
  <form class="composer" on:submit|preventDefault={() => send({ type: 'send' })}>
    <label for="preview-message">Message <span>(local preview only)</span></label>
    <div class="compose-row">
      <textarea id="preview-message" bind:this={composer} value={state.draft} on:input={(event) => send({ type: 'draft', value: event.currentTarget.value })} on:focus={() => focused = true} rows="2" maxlength="1000" placeholder="Try a thought. Nothing will be sent." aria-describedby="preview-message-note"></textarea>
      <button class="primary" type="submit" disabled={!state.draft.trim() || state.connection !== 'connected'}>Send</button>
    </div>
    <p id="preview-message-note">Plain text and emoji. End or Next clears this preview. No saved history.</p>
    {#if notice}<p role="status">{notice}</p>{/if}
  </form>
</section>

<DesignDialog id="preview-more" bind:open={moreOpen} title="Conversation options">
  <div class="dialog-options">
    <button type="button" on:click={async () => { moreOpen = false; await tick(); friendOpen = true; }}>Stay Connected</button>
    <button type="button" on:click={openReport}>Report &amp; Block</button>
    <button type="button" on:click={() => confirm('block')}>Block</button>
    <button type="button" on:click={() => confirm('end')}>End conversation</button>
  </div>
  <p>Safety actions are available to every tier. Registration and payment are not required.</p>
</DesignDialog>

<DesignDialog id="preview-report" bind:open={reportOpen} title="Report & Block" on:close={() => { if (!confirmOpen && !friendOpen && !moreOpen) reportTrigger?.focus(); }}>
  <p>Design preview: no report is submitted. In the product, opening a report reserves available evidence briefly so you can finish safely.</p>
  <form on:submit|preventDefault={previewReport}>
    <label for="preview-report-reason">Reason</label>
    <select id="preview-report-reason" bind:value={reportReason} aria-invalid={Boolean(reportError)} aria-describedby={reportError ? 'preview-report-error' : undefined}>
      <option value="">Choose a reason</option><option>Harassment or abuse</option><option>Suspected underage participant</option><option>Personal information shared</option><option>Other safety concern</option>
    </select>
    {#if reportError}<p class="error" id="preview-report-error" role="alert">{reportError}</p>{/if}
    <p>No account, payment or contact details are needed to report.</p>
    <div class="actions"><button class="primary" type="submit">Preview report confirmation</button><button type="button" on:click={() => { reportOpen = false; confirm('block'); }}>Block and end preview</button></div>
  </form>
</DesignDialog>

<DesignDialog id="preview-friend" bind:open={friendOpen} title="Stay Connected">
  <p>Friendships require acceptance from both people. Guests can send and accept requests.</p>
  {#if friendAccepted}<p role="status">Sample friend accepted · Temporary. This link lasts only while both guest identities remain active.</p>
  {:else if requestSent}<p role="status">Request sent preview. The other person has not accepted.</p><button type="button" on:click={() => friendAccepted = true}>Simulate mutual acceptance</button>
  {:else}<button type="button" on:click={() => requestSent = true}>Preview friend request</button>{/if}
  <p>No actual friendship is created or stored.</p>
</DesignDialog>

<DesignDialog id="preview-confirm" bind:open={confirmOpen} title={confirmAction === 'next' ? 'Start another search?' : confirmAction === 'block' ? 'Block and end?' : 'End this conversation?'}>
  <p>This clears the local messages and unsent text and ends the audio preview. {confirmAction === 'next' ? 'The preview will return to searching.' : 'There is no saved transcript.'}</p>
  {#if confirmAction === 'block'}<p>In the product, blocking also removes friend links and prevents further contact according to the safety policy. This prototype does not record a block.</p>{/if}
  <div class="actions"><button type="button" on:click={() => confirmOpen = false}>Keep conversation</button><button class="primary" type="button" on:click={finish}>{confirmAction === 'next' ? 'Clear and search' : 'Clear and end'}</button></div>
</DesignDialog>

<style>
  .conversation { display: flex; flex-direction: column; height: min(48rem, var(--visible-height, 100dvh)); min-height: 24rem; overflow: auto; background: var(--surface); }
  .conversation.focused { padding-inline: env(safe-area-inset-left) env(safe-area-inset-right); padding-top: env(safe-area-inset-top); position: fixed; z-index: 80; inset-inline: 0; top: var(--visible-top, 0); height: var(--visible-height, 100dvh); min-height: 0; max-width: 58rem; margin-inline: auto; border-radius: 0; overscroll-behavior: contain; }
  .conversation-header { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 0.5rem; padding: 0.8rem 1rem; border-bottom: 1px solid var(--border); }
  h2 { margin: 0; font-size: 1.05rem; }
  .eyebrow { margin: 0; color: var(--accent-strong); font-size: 0.75rem; font-weight: 700; }
  .secondary { margin: 0; font-size: 0.8rem; color: var(--text-secondary); }
  .gender { display: inline-grid; place-items: center; width: 1.7rem; height: 1.7rem; margin-left: 0.25rem; border-radius: 50%; background: var(--surface-subtle); font-size: 0.75rem; }
  .status { padding: 0.6rem 1rem; font-size: 0.8rem; background: var(--surface-subtle); color: var(--text-secondary); }
  .status button { margin-top: 0.5rem; }
  .transcript { flex: 1 0 6rem; min-height: 6rem; overflow: auto; overscroll-behavior: contain; padding: 1rem; }
  .empty-conversation { padding-block: 1rem; text-align: center; color: var(--text-secondary); }
  h3 { font-size: 1.1rem; color: var(--text-primary); }
  .empty-conversation p { max-width: 30rem; margin-inline: auto; }
  .message { width: fit-content; max-width: 90%; margin-left: auto; border-radius: 1rem 1rem 0.2rem 1rem; padding: 0.6rem 0.85rem; background: var(--surface-subtle); white-space: pre-wrap; overflow-wrap: anywhere; }
  .conversation-tools { display: flex; flex-wrap: wrap; gap: 0.5rem; padding: 0.6rem 1rem; border-top: 1px solid var(--border); }
  button, select, textarea { min-height: 44px; border: 1px solid var(--border-strong); border-radius: var(--radius-sm); background: var(--surface); color: var(--text-primary); font: inherit; }
  button { min-width: 44px; padding: 0.5rem 0.75rem; cursor: pointer; }
  button:disabled { cursor: not-allowed; opacity: 0.6; }
  .primary { background: var(--accent-strong); color: white; border-color: var(--accent-strong); }
  .safety { margin-left: auto; color: var(--danger-strong); }
  .composer { padding: 0.6rem 1rem max(0.75rem, env(safe-area-inset-bottom)); background: var(--surface); }
  .composer label { display: block; font-size: 0.85rem; font-weight: 600; }
  label span { font-weight: 400; color: var(--text-secondary); }
  .compose-row { display: flex; align-items: stretch; gap: 0.5rem; margin-top: 0.35rem; }
  textarea { width: 100%; min-width: 0; resize: vertical; padding: 0.5rem; font-size: 1rem; }
  .composer p { margin: 0.35rem 0 0; font-size: 0.75rem; color: var(--text-secondary); }
  .audio-panel { padding: 0.6rem 1rem; border-top: 1px solid var(--border); background: var(--surface-subtle); }
  .audio-panel p { font-size: 0.85rem; margin: 0 0 0.5rem; }
  .actions, .dialog-options { display: flex; flex-wrap: wrap; gap: 0.6rem; }
  .dialog-options { flex-direction: column; }
  select { display: block; max-width: 100%; width: 100%; margin-top: 0.4rem; padding: 0.5rem; }
  .error { color: var(--danger-strong); }
  @media (max-height: 34rem) { .focused .conversation-header { padding-block: 0.4rem; } .focused .status { padding-block: 0.3rem; } .focused .transcript { flex-basis: 4rem; min-height: 4rem; } }
  @media (max-width: 24rem) { .safety { margin-left: 0; } .conversation-tools { padding-inline: 0.6rem; } }
</style>
