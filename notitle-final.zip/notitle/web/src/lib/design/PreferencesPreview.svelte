<script lang="ts">
  let tier = 'guest';
  let genderPreference = 'everyone';
  let noPreference = true;
  let industries: string[] = [];
  let roles: string[] = [];
  $: if (tier !== 'premium') genderPreference = 'everyone';
</script>

<section class="preferences" aria-labelledby="preferences-title">
  <h3 id="preferences-title">Matching preferences preview</h3>
  <p>These controls illustrate the rules only; they never start or rank a match.</p>
  <label for="preview-tier">Preview tier</label>
  <select id="preview-tier" bind:value={tier}><option value="guest">Guest</option><option value="free">Free account</option><option value="premium">Premium account</option></select>
  <label for="preview-gender-preference">Gender preference</label>
  <select id="preview-gender-preference" bind:value={genderPreference} disabled={tier !== 'premium'} aria-describedby="gender-preference-help"><option value="everyone">Everyone</option><option value="male">Male</option><option value="female">Female</option><option value="other">Other / Non-binary</option></select>
  <p id="gender-preference-help">Guest and Free use Everyone. Premium can choose one option. Both people’s gender preferences must be satisfied. Gender labels are self-declared, not verified.</p>
  <details>
    <summary>Professional preferences <span>Optional · No preference by default</span></summary>
    <p>Gender preference is always respected. Professional choices only slightly influence an available match and do not add waiting time. General Talk disables professional scoring.</p>
    <label class="choice"><input type="checkbox" bind:checked={noPreference} disabled={tier !== 'premium'} /> No preference — turn off professional scoring</label>
    <p>Your selections below remain available if you turn scoring back on. The sample categories are for layout review only.</p>
    <fieldset disabled={tier !== 'premium' || noPreference}>
      <legend>Industry</legend>
      <label class="choice"><input type="checkbox" checked={industries.length === 0} on:change={() => industries = []} /> No preference</label>
      <label class="choice"><input type="checkbox" bind:group={industries} value="Sample industry A" /> Sample industry A</label>
      <label class="choice"><input type="checkbox" bind:group={industries} value="Sample industry B" /> Sample industry B</label>
    </fieldset>
    <fieldset disabled={tier !== 'premium' || noPreference}>
      <legend>Role</legend>
      <label class="choice"><input type="checkbox" checked={roles.length === 0} on:change={() => roles = []} /> No preference</label>
      <label class="choice"><input type="checkbox" bind:group={roles} value="Sample role A" /> Sample role A</label>
      <label class="choice"><input type="checkbox" bind:group={roles} value="Sample role B" /> Sample role B</label>
    </fieldset>
    <p>Multiple selections within a category mean OR. No preference clears that category’s selections.</p>
  </details>
</section>

<style>
  h3 { margin-bottom: 0.5rem; }
  p { color: var(--text-secondary); font-size: 0.9rem; }
  label:not(.choice) { display: block; margin-top: 1rem; font-weight: 600; }
  select { display: block; min-height: 44px; width: 100%; padding: 0.5rem; border: 1px solid var(--border-strong); border-radius: var(--radius-sm); background: var(--surface); color: var(--text-primary); }
  details { margin-top: 1rem; border-top: 1px solid var(--border); }
  summary { min-height: 44px; padding-block: 0.75rem; cursor: pointer; }
  summary span { display: block; color: var(--text-secondary); font-size: 0.8rem; }
  fieldset { margin-block: 1rem; min-width: 0; border: 1px solid var(--border-strong); border-radius: var(--radius-sm); }
  .choice { display: flex; align-items: center; gap: 0.6rem; min-height: 44px; padding: 0.4rem; }
  input { flex: 0 0 auto; width: 1.15rem; height: 1.15rem; }
  :disabled { opacity: 0.65; }
</style>
