/** VisualViewport is a keyboard enhancement; window resize is the fallback. */
export type ViewportInput = { height: number; offsetTop: number };
export function viewportMetrics(viewport: ViewportInput | null, fallbackHeight: number): ViewportInput {
  return {
    height: viewport && Number.isFinite(viewport.height) && viewport.height > 0 ? viewport.height : (Number.isFinite(fallbackHeight) && fallbackHeight > 0 ? fallbackHeight : 1),
    offsetTop: viewport && Number.isFinite(viewport.offsetTop) && viewport.offsetTop > 0 ? viewport.offsetTop : 0
  };
}

export function visibleViewport(node: HTMLElement) {
  const viewport = window.visualViewport;
  let frame = 0;
  function update() {
    const current = viewportMetrics(viewport, window.innerHeight);
    node.style.setProperty('--visible-height', `${current.height}px`);
    node.style.setProperty('--visible-top', `${current.offsetTop}px`);
    const focused = document.activeElement;
    if (focused instanceof HTMLElement && node.contains(focused)) focused.scrollIntoView({ block: 'nearest' });
  }
  function schedule() {
    window.cancelAnimationFrame(frame);
    frame = window.requestAnimationFrame(update);
  }
  update();
  viewport?.addEventListener('resize', schedule);
  viewport?.addEventListener('scroll', schedule);
  window.addEventListener('resize', schedule);
  window.addEventListener('orientationchange', schedule);
  return {
    destroy() {
      window.cancelAnimationFrame(frame);
      viewport?.removeEventListener('resize', schedule);
      viewport?.removeEventListener('scroll', schedule);
      window.removeEventListener('resize', schedule);
      window.removeEventListener('orientationchange', schedule);
      node.style.removeProperty('--visible-height');
      node.style.removeProperty('--visible-top');
    }
  };
}
