/** Keeps the optional focused chat view operable with a keyboard. Native dialogs retain their own modal focus. */
export function focusScope(node: HTMLElement, options: { active: boolean; onexit: () => void }) {
  let saved: { element: HTMLElement; inert: boolean }[] = [];
  let active = false;
  let onexit = options.onexit;
  function keydown(event: KeyboardEvent) {
    if (event.key === 'Escape') { event.preventDefault(); onexit(); return; }
    if (event.key !== 'Tab') return;
    const controls = [...node.querySelectorAll<HTMLElement>('button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), a[href], [tabindex="0"]')].filter((element) => element.getClientRects().length > 0);
    const first = controls[0];
    const last = controls.at(-1);
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
  }
  function restore() {
    for (const item of saved) item.element.inert = item.inert;
    saved = [];
    node.removeEventListener('keydown', keydown);
    active = false;
  }
  function update(next: typeof options) {
    onexit = next.onexit;
    if (next.active === active) return;
    if (!next.active) { restore(); return; }
    active = true;
    let branch: HTMLElement | null = node;
    while (branch?.parentElement && branch !== document.body) {
      for (const sibling of branch.parentElement.children) {
        // showModal() supplies modality for the separate safety dialogs.
        if (sibling !== branch && sibling instanceof HTMLElement && sibling.tagName !== 'DIALOG') {
          saved.push({ element: sibling, inert: sibling.inert });
          sibling.inert = true;
        }
      }
      branch = branch.parentElement;
    }
    node.addEventListener('keydown', keydown);
  }
  update(options);
  return { update, destroy: restore };
}
