/** Phase 2 interaction specification. No network, timers or browser storage. */
export const topics = ['General Talk', 'Workplace culture', 'Office politics', 'Career growth', 'Managers', 'Salaries', 'Hiring', 'Industry experiences'] as const;
export type Topic = (typeof topics)[number];
export type Gender = '' | 'male' | 'female' | 'other';
export type QueueState = 'waiting' | 'busy' | 'expired' | 'failure';
export type AudioState = 'idle' | 'outgoing' | 'incoming' | 'permission' | 'connecting' | 'connected' | 'denied' | 'failed';
export type EntryChoices = { adult: boolean; rules: boolean; gender: Gender; topic: Topic; profession: string };
export type PreviewState = {
  stage: 'entry' | 'searching' | 'conversation' | 'ended';
  queue: QueueState;
  connection: 'connected' | 'reconnecting' | 'failed';
  audio: AudioState;
  muted: boolean;
  draft: string;
  messages: string[];
};
export type PreviewEvent =
  | { type: 'start'; choices: EntryChoices }
  | { type: 'queue'; value: QueueState }
  | { type: 'match' }
  | { type: 'cancel' }
  | { type: 'draft'; value: string }
  | { type: 'send' }
  | { type: 'connection'; value: PreviewState['connection'] }
  | { type: 'audio'; value: AudioState }
  | { type: 'mute' }
  | { type: 'next' }
  | { type: 'end' }
  | { type: 'reset' };

export function initialChoices(): EntryChoices {
  return { adult: false, rules: false, gender: '', topic: 'General Talk', profession: '' };
}

export function entryErrors(choices: EntryChoices): string[] {
  return [
    ...(!choices.adult ? ['Confirm that you are at least 18 years old.'] : []),
    ...(!choices.rules ? ['Accept the community rules to continue.'] : []),
    ...(!['male', 'female', 'other'].includes(choices.gender) ? ['Choose your self-declared gender.'] : []),
    ...(!topics.includes(choices.topic) ? ['Choose a discussion topic.'] : [])
  ];
}

export function initialPreview(): PreviewState {
  return { stage: 'entry', queue: 'waiting', connection: 'connected', audio: 'idle', muted: false, draft: '', messages: [] };
}

export function transition(state: PreviewState, event: PreviewEvent): PreviewState {
  switch (event.type) {
    case 'reset': return initialPreview();
    case 'start':
      return state.stage === 'entry' && entryErrors(event.choices).length === 0
        ? { ...initialPreview(), stage: 'searching' } : state;
    case 'queue': return state.stage === 'searching' ? { ...state, queue: event.value } : state;
    case 'match': return state.stage === 'searching' && state.queue === 'waiting'
      ? { ...initialPreview(), stage: 'conversation' } : state;
    case 'cancel': return state.stage === 'searching' ? initialPreview() : state;
    case 'draft': return state.stage === 'conversation' ? { ...state, draft: event.value.slice(0, 1000) } : state;
    case 'send':
      return state.stage === 'conversation' && state.connection === 'connected' && state.draft.trim()
        ? { ...state, messages: [...state.messages, state.draft.trim()].slice(-20), draft: '' } : state;
    case 'connection': return state.stage === 'conversation' ? { ...state, connection: event.value } : state;
    case 'audio': return state.stage === 'conversation'
      ? { ...state, audio: event.value, muted: event.value === 'connected' ? state.muted : false } : state;
    case 'mute': return state.audio === 'connected' ? { ...state, muted: !state.muted } : state;
    case 'next': return state.stage === 'conversation' ? { ...initialPreview(), stage: 'searching' } : state;
    case 'end': return { ...initialPreview(), stage: 'ended' };
  }
}

export const queueCopy: Record<QueueState, { title: string; description: string }> = {
  waiting: { title: 'Looking for a conversation', description: 'Waiting for someone whose choices are compatible. There is no guaranteed match or wait time.' },
  busy: { title: 'The conversation space is at capacity', description: 'Please try again later. Your choices stay here while this preview remains open.' },
  expired: { title: 'Your search is paused', description: 'The search expired. Review your choices, then choose to search again.' },
  failure: { title: 'Connection interrupted', description: 'Your choices have been kept. You can retry or cancel the search.' }
};
