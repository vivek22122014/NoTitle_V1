<script lang="ts">
  import { createEventDispatcher } from 'svelte';
  import { visibleViewport } from './viewport';

  export let open = false;
  export let title: string;
  export let id: string;
  let dialog: HTMLDialogElement;
  const dispatch = createEventDispatcher<{ close: void }>();

  $: if (dialog) {
    if (open && !dialog.open) dialog.showModal();
    if (!open && dialog.open) dialog.close();
  }

  function close() {
    open = false;
    dialog?.close();
    dispatch('close');
  }
</script>

<dialog bind:this={dialog} use:visibleViewport aria-labelledby={`${id}-title`} on:close={close}>
  <header>
    <h2 id={`${id}-title`}>{title}</h2>
    <button type="button" on:click={close} aria-label={`Close ${title}`}>Close</button>
  </header>
  <div class="body"><slot /></div>
</dialog>

<style>
  dialog {
    position: fixed;
    inset-block-start: calc(var(--visible-top, 0px) + 0.5rem);
    inset-block-end: auto;
    width: min(36rem, calc(100% - 1rem));
    max-height: calc(var(--visible-height, 100dvh) - 1rem);
    margin-block: 0;
    padding: 0;
    overflow: auto;
    overscroll-behavior: contain;
    border: 1px solid var(--border-strong);
    border-radius: var(--radius-lg);
    background: var(--surface);
    color: var(--text-primary);
  }
  dialog::backdrop { background: rgb(15 23 42 / 0.55); }
  header { position: sticky; top: 0; display: flex; align-items: start; justify-content: space-between; gap: 0.75rem; padding: 1rem; border-bottom: 1px solid var(--border); background: var(--surface); }
  h2 { margin: 0; font-size: 1.15rem; }
  button { min-width: 44px; min-height: 44px; padding: 0.5rem 0.75rem; border: 1px solid var(--border-strong); border-radius: var(--radius-sm); background: var(--surface); color: var(--text-primary); cursor: pointer; }
  .body { padding: 1rem; padding-bottom: max(1rem, env(safe-area-inset-bottom)); }
</style>
