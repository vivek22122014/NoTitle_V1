<script lang="ts">
  import { tick } from 'svelte';
  import ConversationPreview from './ConversationPreview.svelte';
  import FriendsPreview from './FriendsPreview.svelte';
  import PreferencesPreview from './PreferencesPreview.svelte';
  import { initialChoices, initialPreview, entryErrors, transition, topics, queueCopy, type PreviewEvent, type QueueState } from './state';

  let state = initialPreview();
  let choices = initialChoices();
  let errors: string[] = [];
  let errorSummary: HTMLDivElement;
  let view: 'conversation' | 'friends' | 'account' = 'conversation';
  let accountScreen = 'Register';
  let accountState = 'Empty';
  const accountCopy: Record<string, string> = {
    Register: 'Private username, password and recovery code; public Display Name. Required 18+ attestation, rules and gender selection. No mandatory phone, email, employer, date of birth or identity document.',
    Login: 'Private username and password. Use a generic failure message and preserve the username on retry. Never disclose whether an account exists.',
    Recovery: 'Username and recovery code. No email-reset dependency. Replace the recovery code after a successful recovery and invalidate prior sessions.',
    Profile: 'Public Display Name and optional Bio are separate from private professional details. Required gender is self-declared and visible as M / F / Other.',
    Settings: 'Password change, replacement recovery code, logout-all, blocked list, privacy rights request and account deletion require their appropriate confirmation and recent-authentication flows.',
    Payment: 'Pending, processing, confirmed, failed and expired checkout states. Only a server-verified payment can activate Premium. No payment is initiated in this design preview.',
    Receipt: 'An in-account receipt shows the actual INR price, tax treatment, purchase reference, duration and entitlement. No fabricated receipt or email is generated here.'
  };
  function send(event: PreviewEvent) { state = transition(state, event); }
  async function start() {
    errors = entryErrors(choices);
    if (errors.length) { await tick(); errorSummary?.focus(); return; }
    send({ type: 'start', choices });
  }
  function reset() { state = initialPreview(); choices = initialChoices(); errors = []; }
</script>

<section class="design-preview content-width" aria-labelledby="preview-title">
  <header class="preview-header">
    <p class="eyebrow">Development only</p><h1 id="preview-title">Design preview · simulated states</h1>
    <p>Inspect the mobile-first interaction design. Nothing here connects people, sends a message, requests a microphone, submits a report or takes a payment. Please use sample text only.</p>
    <p class="notice">Data lives only in this page’s memory and disappears on reload. This route is unavailable in production.</p>
  </header>
  <nav class="view-switch" aria-label="Preview screen">
    <button type="button" aria-pressed={view === 'conversation'} on:click={() => view = 'conversation'}>Conversation flow</button>
    <button type="button" aria-pressed={view === 'friends'} on:click={() => view = 'friends'}>Friends</button>
    <button type="button" aria-pressed={view === 'account'} on:click={() => view = 'account'}>Account states</button>
  </nav>

  {#if view === 'conversation'}
    <div class="flow-grid">
      <div class="flow-main">
        {#if state.stage === 'entry'}
          <section class="entry card" aria-labelledby="entry-title">
            <p class="eyebrow">Entry preview</p><h2 id="entry-title">What would you like to talk about?</h2>
            <p>People you meet see a pseudonym, your self-declared gender label and the chosen topic. Private professional details and matching preferences are not shown.</p>
            <form on:submit|preventDefault={start} novalidate>
              {#if errors.length}<div class="error-summary" role="alert" tabindex="-1" bind:this={errorSummary}><h3>Check your choices</h3><ul>{#each errors as error}<li>{error}</li>{/each}</ul></div>{/if}
              <label class="choice"><input type="checkbox" bind:checked={choices.adult} required /> I confirm I am at least 18 years old.</label>
              <label class="choice"><input type="checkbox" bind:checked={choices.rules} required /> I accept the community rules.</label>
              <p class="fine-print">Read the <a href="/community-guidelines" target="_blank" rel="noopener noreferrer">community guidelines (new tab)</a> and <a href="/privacy" target="_blank" rel="noopener noreferrer">privacy notice (new tab)</a>. Age attestation and gender are self-declared, not identity verification.</p>
              <fieldset>
                <legend>Your gender <span>Required · no default selection</span></legend>
                <label class="choice"><input type="radio" name="preview-gender" bind:group={choices.gender} value="male" required /> Male <span class="label-note">Shown as M</span></label>
                <label class="choice"><input type="radio" name="preview-gender" bind:group={choices.gender} value="female" /> Female <span class="label-note">Shown as F</span></label>
                <label class="choice"><input type="radio" name="preview-gender" bind:group={choices.gender} value="other" /> Other / Non-binary <span class="label-note">Shown as Other</span></label>
              </fieldset>
              <fieldset><legend>Discussion topic</legend><div class="topics">{#each topics as topic}<label class="choice"><input type="radio" name="preview-topic" bind:group={choices.topic} value={topic} /> {topic}</label>{/each}</div></fieldset>
              <details><summary>Professional profile <span>Optional and private</span></summary><label for="preview-profession">Sample professional detail</label><input id="preview-profession" type="text" bind:value={choices.profession} maxlength="120" autocomplete="off" placeholder="Optional preview text" /><p class="fine-print">No employer, email or identity proof is required. General Talk opts out of professional scoring.</p></details>
              <button class="primary" type="submit">Start preview search</button>
            </form>
          </section>
        {:else if state.stage === 'searching'}
          <section class="queue card" aria-labelledby="queue-title">
            <p class="eyebrow">Searching preview</p>
            <div role="status" aria-live="polite" aria-atomic="true"><h2 id="queue-title">{queueCopy[state.queue].title}</h2><p>{queueCopy[state.queue].description}</p></div>
            <dl><div><dt>Topic</dt><dd>{choices.topic}</dd></div><div><dt>Your gender</dt><dd>{choices.gender === 'male' ? 'M' : choices.gender === 'female' ? 'F' : 'Other'} · self-declared</dd></div><div><dt>Effective preference</dt><dd>Everyone · Guest preview</dd></div></dl>
            <p>No live queue or online count is used. These state changes are manual simulations.</p>
            <div class="actions">{#if state.queue === 'waiting'}<button class="primary" type="button" on:click={() => send({ type: 'match' })}>Simulate compatible match</button>{:else}<button class="primary" type="button" on:click={() => send({ type: 'queue', value: 'waiting' })}>Search again in preview</button>{/if}<button type="button" on:click={() => send({ type: 'cancel' })}>Cancel search</button></div>
            <label for="queue-state">Inspect searching state</label><select id="queue-state" value={state.queue} on:change={(event) => send({ type: 'queue', value: event.currentTarget.value as QueueState })}><option value="waiting">Loading / waiting</option><option value="busy">At capacity</option><option value="expired">Expired / paused</option><option value="failure">Connection error</option></select>
          </section>
        {:else if state.stage === 'conversation'}
          <ConversationPreview bind:state topic={choices.topic} />
          <section class="simulator-controls" aria-label="Simulation controls"><h3>Inspect connection and audio states</h3><div class="actions"><button type="button" on:click={() => send({ type: 'connection', value: 'reconnecting' })}>Simulate reconnecting</button><button type="button" on:click={() => send({ type: 'connection', value: 'failed' })}>Simulate connection failure</button><button type="button" on:click={() => send({ type: 'audio', value: 'incoming' })}>Simulate incoming call</button></div><p>Use Focus chat, then inspect the composer with a real mobile keyboard. Escape or Exit focus view restores the surrounding preview.</p></section>
        {:else}
          <section class="queue card"><p class="eyebrow">Ended state</p><h2>Conversation ended.</h2><p>The local messages, unsent draft and audio state have been cleared. No transcript was saved.</p><button class="primary" type="button" on:click={reset}>Start a fresh preview</button></section>
        {/if}
      </div>
      <aside class="preview-aside card" aria-label="Interaction rules"><h2>Same product, every screen.</h2><p>One responsive flow for phone, tablet and desktop. Safety and friends remain available to every tier.</p><PreferencesPreview /></aside>
    </div>
  {:else if view === 'friends'}
    <FriendsPreview conversationActive={state.stage === 'conversation'} />
  {:else}
    <section class="account-states card" aria-labelledby="account-title"><p class="eyebrow">Presentational state inventory</p><h2 id="account-title">Account, settings and payment states</h2><p>These are design contracts. This isolated preview does not invoke authentication, security operations, checkout or receipts. The application routes require enabled services. Do not enter real credentials.</p><label for="account-screen">Screen</label><select id="account-screen" bind:value={accountScreen}>{#each Object.keys(accountCopy) as screen}<option>{screen}</option>{/each}</select><label for="account-state">UI state</label><select id="account-state" bind:value={accountState}><option>Empty</option><option>Loading</option><option>Busy</option><option>Permission denied</option><option>Expired</option><option>Failure</option></select><div class="state-card" role="status"><h3>{accountScreen} · {accountState}</h3><p>{accountCopy[accountScreen]}</p><p>{accountState === 'Empty' ? 'Explain what is required, with visible labels and no preselected consent.' : accountState === 'Loading' ? 'Announce progress once; prevent duplicate submission and preserve safe non-secret input.' : accountState === 'Busy' ? 'Explain temporary unavailability and provide a retry path without inventing a queue position.' : accountState === 'Permission denied' ? 'Explain the action needed and preserve access to safety and public support routes.' : accountState === 'Expired' ? 'Stop the previous attempt and ask for an explicit new action. Expired Premium preferences are never silently widened.' : 'Show a safe actionable error. Do not infer payment success or disclose account existence.'}</p></div></section>
  {/if}
</section>

<style>
  .design-preview { padding-block: 2rem 4rem; }
  .preview-header { max-width: 46rem; }
  h1 { margin: 0.5rem 0 1rem; font-size: clamp(1.7rem, 4vw, 2.7rem); line-height: 1.15; letter-spacing: -0.035em; }
  h2 { font-size: 1.35rem; line-height: 1.3; }
  h3 { font-size: 1rem; }
  p { color: var(--text-secondary); }
  .eyebrow { color: var(--accent-strong); font-weight: 700; font-size: 0.8rem; }
  .notice { border-left: 3px solid var(--accent); padding: 0.5rem 1rem; background: var(--surface-subtle); font-size: 0.9rem; }
  .view-switch, .actions { display: flex; flex-wrap: wrap; gap: 0.6rem; }
  .view-switch { margin-block: 1.5rem; }
  button, select, input[type='text'] { min-height: 44px; min-width: 44px; padding: 0.5rem 0.75rem; border: 1px solid var(--border-strong); border-radius: var(--radius-sm); background: var(--surface); color: var(--text-primary); }
  button { cursor: pointer; }
  button[aria-pressed='true'], .primary { background: var(--accent-strong); color: white; border-color: var(--accent-strong); }
  .flow-grid { display: grid; gap: 1rem; align-items: start; }
  .flow-main { min-width: 0; }
  .entry, .queue, .preview-aside, .account-states { padding: clamp(1rem, 4vw, 1.5rem); }
  .choice { display: flex; align-items: center; min-height: 44px; gap: 0.65rem; padding: 0.5rem 0; }
  .choice input { flex: 0 0 auto; width: 1.1rem; height: 1.1rem; accent-color: var(--accent-strong); }
  .label-note { margin-left: auto; font-size: 0.8rem; color: var(--text-secondary); }
  fieldset { min-width: 0; margin: 1.25rem 0; border: 1px solid var(--border-strong); border-radius: var(--radius-sm); }
  legend { font-weight: 650; padding-inline: 0.25rem; }
  legend span, summary span { display: block; font-size: 0.8rem; font-weight: 400; color: var(--text-secondary); }
  .fine-print { font-size: 0.8rem; }
  details { margin-block: 1rem; }
  summary { min-height: 44px; padding-block: 0.5rem; cursor: pointer; }
  select, input[type='text'] { display: block; width: 100%; max-width: 100%; }
  label:not(.choice) { display: block; margin-top: 1rem; margin-bottom: 0.4rem; font-weight: 600; }
  .error-summary { padding: 0.75rem; margin-bottom: 1rem; border: 2px solid var(--danger-strong); border-radius: var(--radius-sm); }
  .error-summary h3 { margin-top: 0; }
  .error-summary ul { padding-left: 1.2rem; }
  dl { padding: 0.75rem; background: var(--surface-subtle); border-radius: var(--radius-sm); }
  dl div { margin-block: 0.5rem; }
  dt { font-size: 0.8rem; color: var(--text-secondary); }
  dd { margin: 0; }
  .simulator-controls { padding-block: 0.5rem; }
  .simulator-controls p { font-size: 0.85rem; }
  .state-card { padding: 1rem; margin-top: 1rem; border: 1px solid var(--border); border-radius: var(--radius-sm); }
  @media (min-width: 64rem) { .flow-grid { grid-template-columns: minmax(0, 1.8fr) minmax(17rem, 1fr); } }
</style>
