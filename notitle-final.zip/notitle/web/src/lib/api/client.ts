/** The public Go error contract. Backend internals are never included. */
export interface ApiErrorEnvelope {
  error: { code: string; message: string; request_id: string };
}

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly requestId: string | null;

  constructor(message: string, status: number, code: string, requestId: string | null = null) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.requestId = requestId;
  }
}

export type ApiRequestOptions = Omit<RequestInit, 'credentials' | 'redirect'> & {
  timeoutMs?: number;
};

function isApiPath(path: string): boolean {
  if (!path.startsWith('/api/') || /[\\\u0000-\u0020\u007f]/u.test(path) || /%2f|%5c/iu.test(path)) return false;
  try {
    const parsed = new URL(path, 'https://notitle.invalid');
    return parsed.origin === 'https://notitle.invalid' && parsed.pathname.startsWith('/api/') && !parsed.pathname.includes('//') && !parsed.hash;
  } catch {
    return false;
  }
}

function requestId(value: unknown): string | null {
  return typeof value === 'string' && /^[a-f0-9]{32}$/u.test(value) ? value : null;
}

function parseError(value: unknown): ApiErrorEnvelope['error'] | null {
  if (!value || typeof value !== 'object' || !('error' in value)) return null;
  const error = value.error;
  if (!error || typeof error !== 'object' || !('code' in error) || !('message' in error)) return null;
  if (typeof error.code !== 'string' || !/^[a-z0-9_]{1,64}$/u.test(error.code)) return null;
  if (typeof error.message !== 'string' || error.message.length > 500) return null;
  return { code: error.code, message: error.message, request_id: 'request_id' in error && typeof error.request_id === 'string' ? error.request_id : '' };
}

/** Same-origin JSON only. Callers must explicitly provide CSRF headers for future writes. */
export async function apiFetch<T>(path: string, options: ApiRequestOptions = {}): Promise<T> {
  if (!isApiPath(path)) throw new Error('apiFetch only accepts same-origin /api/ paths');
  const { timeoutMs = 10_000, signal: callerSignal, ...requestOptions } = options;
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0 || timeoutMs > 60_000) throw new Error('Invalid API timeout');
  if (callerSignal?.aborted) throw new ApiError('Request cancelled.', 0, 'request_aborted');

  const controller = new AbortController();
  let timedOut = false;
  const timeout = globalThis.setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);
  const abortFromCaller = () => controller.abort();
  callerSignal?.addEventListener('abort', abortFromCaller, { once: true });

  try {
    const headers = new Headers(requestOptions.headers);
    headers.set('Accept', 'application/json');
    const response = await fetch(path, {
      ...requestOptions,
      headers,
      credentials: 'same-origin',
      redirect: 'error',
      cache: 'no-store',
      signal: controller.signal
    });
    const id = requestId(response.headers.get('x-request-id'));
    const isJson = (response.headers.get('content-type') ?? '').toLowerCase().includes('application/json');
    if (!response.ok) {
      let error: ApiErrorEnvelope['error'] | null = null;
      if (isJson) {
        try { error = parseError(await response.json()); } catch { /* Generic safe error below. */ }
      }
      throw new ApiError(error?.message ?? 'The request could not be completed.', response.status, error?.code ?? 'request_failed', id ?? requestId(error?.request_id));
    }
    if (response.status === 204) return undefined as T;
    if (!isJson) throw new ApiError('The service returned an unexpected response.', response.status, 'invalid_response', id);
    try {
      return (await response.json()) as T;
    } catch {
      throw new ApiError('The service returned an unexpected response.', response.status, 'invalid_response', id);
    }
  } catch (error) {
    if (timedOut) throw new ApiError('The request took too long. Please try again.', 0, 'request_timeout');
    if (callerSignal?.aborted) throw new ApiError('Request cancelled.', 0, 'request_aborted');
    if (error instanceof ApiError) throw error;
    throw new ApiError('Unable to connect. Please try again.', 0, 'network_error');
  } finally {
    globalThis.clearTimeout(timeout);
    callerSignal?.removeEventListener('abort', abortFromCaller);
  }
}
