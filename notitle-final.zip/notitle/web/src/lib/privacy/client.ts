import { apiFetch, ApiError } from '../api/client.ts';
import { parseExport } from './model.ts';
import { record } from '../support/model.ts';
import { parseReceipt, purchaseRef } from '../payments/model.ts';
export class PrivacyClient {
  private abort = new AbortController();
  private csrf = '';
  setCSRF(value: string): void { this.csrf = value; }
  async bootstrap(): Promise<void> { const data = await apiFetch<{ csrf_token: string }>('/api/v1/support/bootstrap', { signal: this.abort.signal }); if (typeof data.csrf_token !== 'string' || !data.csrf_token) throw new Error('Security check unavailable'); this.csrf = data.csrf_token; }
  private write(path: string, body: unknown) { if (!this.csrf) throw new ApiError('Reload the security check before continuing.', 0, 'csrf_required'); return apiFetch(path, { method: 'POST', signal: this.abort.signal, headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': this.csrf }, body: JSON.stringify(body) }); }
  export() { return this.write('/api/v1/privacy/export', {}).then(parseExport); }
  closedReceipt(receipt: string, purchase_ref: string) { if (!/^[A-Za-z0-9_-]{43}$/u.test(receipt) || !purchaseRef(purchase_ref)) throw new Error('Check the saved deletion receipt and purchase reference.'); return this.write('/api/v1/privacy/closed-receipt', { deletion_receipt: receipt, purchase_ref }).then((value) => { const r = record(value); if (r.environment !== 'sandbox' && r.environment !== 'production') throw new Error('Invalid receipt environment'); return { receipt: parseReceipt(r.receipt), environment: r.environment as 'sandbox' | 'production' }; }); }
  dispose(): void { this.csrf = ''; this.abort.abort(); }
}
