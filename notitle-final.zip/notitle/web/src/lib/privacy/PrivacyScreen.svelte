<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import Alert from '$lib/components/Alert.svelte';
  import { IdentityClient } from '$lib/identity/client';
  import { ApiError } from '$lib/api/client';
  import { PrivacyClient } from './client';
  import { downloadPrivate } from '$lib/support/model';
  import type { PrivacyExport } from './model';
  import type { Receipt } from '$lib/payments/model';
  import '$lib/support/support.css';
  const identity = new IdentityClient(); const client = new PrivacyClient();
  let loading = true; let account = false; let busy = false; let error = ''; let notice = ''; let password = ''; let alive = true;
  let data: PrivacyExport | null = null; let deletionReceipt = ''; let purchaseRef = ''; let receipt: Receipt | null = null; let receiptEnvironment = '';
  const money = (amount: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(amount / 100);
  async function initialize() { loading = true; error = ''; try { await client.bootstrap(); const session = await identity.current(); account = session?.identity.kind === 'account'; } catch (cause) { fail(cause); } finally { if (alive) loading = false; } }
  function fail(cause: unknown) { if (!alive) return; if (cause instanceof ApiError && cause.status === 401) { data = null; account = false; } error = cause instanceof ApiError ? cause.message : 'The request could not be completed safely. Check your details and retry.'; }
  async function prepareExport() {
    if (busy) return; busy = true; error = ''; data = null; notice = '';
    try { await identity.reauthenticate(password); password = ''; const result = await client.export(); if (!alive) return; data = result; notice = 'Your current export is ready in this screen. Choose Download to save a private copy.'; }
    catch (cause) { fail(cause); } finally { password = ''; if (alive) busy = false; }
  }
  async function findReceipt() {
    if (busy) return; busy = true; error = ''; receipt = null;
    try { const result = await client.closedReceipt(deletionReceipt.trim(), purchaseRef.trim()); if (alive) { receipt = result.receipt; receiptEnvironment = result.environment; } }
    catch (cause) { fail(cause); } finally { deletionReceipt = ''; if (alive) busy = false; }
  }
  function clear() { data = null; receipt = null; deletionReceipt = ''; purchaseRef = ''; password = ''; notice = 'Private details cleared from this screen.'; }
  onMount(() => { void initialize(); });
  onDestroy(() => { alive = false; identity.dispose(); client.dispose(); clear(); });
</script>
<svelte:window on:pagehide={clear} />
<section class="support-page content-width" aria-labelledby="privacy-controls-title">
  <header><p class="eyebrow">NoTitle · Your information</p><h1 id="privacy-controls-title">Privacy controls</h1><p>Access your own information, correct your profile and manage account closure.</p></header>
  <div class="support-layout"><div class="support-stack">
    {#if error}<Alert variant="danger" title="Request not completed">{error}</Alert><button disabled={busy} on:click={initialize}>Reload session and security check</button>{/if}{#if notice}<Alert>{notice}</Alert>{/if}
    {#if loading}<p role="status">Checking your session…</p>{:else}
      {#if account}
        <form class="support-panel" on:submit|preventDefault={prepareExport} aria-busy={busy}><h2>Access your account information</h2><p>Confirm your password to prepare an export of your profile, consent records and purchase summary. The server requires a current account session and fresh password confirmation.</p><label for="privacy-password">Current password<input id="privacy-password" type="password" autocomplete="current-password" bind:value={password} maxlength={256} required disabled={busy} /></label><button type="submit" disabled={busy}>{busy ? 'Preparing…' : 'Confirm password and prepare export'}</button><p class="help">This is a snapshot of the included fields, not a conversation archive. Other participants’ private profiles, reporters, restricted evidence, operator notes and security credentials are excluded. Use a privacy case for additional access questions.</p></form>
        {#if data}<section class="support-panel"><h2>Your export is ready</h2><p>Prepared {new Date(data.exported_at).toLocaleString()}. It includes {data.consents.length} consent records and {data.purchases.length} purchase summaries.</p><button on:click={() => data && downloadPrivate('notitle-private-account-export.json', JSON.stringify(data, null, 2), 'application/json')}>Download private account export</button><p class="help">The JSON file contains personal information. Save it only to a trusted device. It is not automatically saved to this browser and disappears from this screen on reload.</p><button on:click={clear}>Clear prepared export</button></section>{/if}
        <section class="support-panel"><h2>Correction and deletion</h2><p>Update your public and private profile directly. Account deletion immediately disables access after confirmation; removal of retained data follows the reviewed schedule and lawful holds. A support enquiry is separate from the immediate deletion control.</p><div class="actions"><a class="action" href="/profile">Correct your profile</a><a class="action" href="/settings">Settings and deletion</a><a class="action" href="/account/support">Open a privacy request</a></div><p>Before closure, save required receipts, private support case codes and your deletion-status receipt. Deletion does not automatically request a refund.</p></section>
      {:else}<section class="support-panel"><h2>Account access requires sign-in</h2><p>You can submit a public privacy request without an account or email. We may need appropriate authority verification before releasing protected information.</p><div class="actions"><a class="action" href="/login">Sign in</a><a class="action" href="/support">Public privacy request</a></div></section>{/if}
      <form class="support-panel" on:submit|preventDefault={findReceipt} aria-busy={busy}><h2>Required receipt after account closure</h2><p>Use the private deletion-status receipt saved when you closed the account and the original purchase reference. A support case secret, username or payment screenshot cannot replace this proof. Receipt retrieval is available only while the required financial record is lawfully retained.</p><label for="closed-deletion-receipt">Saved private deletion-status receipt<input id="closed-deletion-receipt" type="password" autocomplete="off" autocapitalize="none" spellcheck="false" bind:value={deletionReceipt} maxlength={128} required disabled={busy} /></label><label for="closed-purchase-reference">Original purchase reference<input id="closed-purchase-reference" autocomplete="off" autocapitalize="none" spellcheck="false" bind:value={purchaseRef} maxlength={128} required disabled={busy} /></label><button type="submit" disabled={busy}>Retrieve required receipt</button><p class="help">If you no longer have these codes, submit a <a href="/support">receipt request</a>. Submitting a claim does not prove ownership or guarantee disclosure.</p></form>
      {#if receipt}<section class="support-panel"><h2>Closed-account purchase receipt</h2><p>{receiptEnvironment === 'sandbox' ? 'Sandbox test receipt — not a live payment.' : 'Production payment receipt.'}</p><dl><div><dt>Purchase reference</dt><dd>{receipt.purchase_ref}</dd></div><div><dt>Original plan</dt><dd>{receipt.plan.name}</dd></div><div><dt>Original price</dt><dd>{money(receipt.plan.amount_paise)}</dd></div><div><dt>Total captured / confirmed refunds</dt><dd>{money(receipt.captured_paise)} / {money(receipt.refunded_paise)}</dd></div></dl><button on:click={() => receipt && downloadPrivate('notitle-private-purchase-receipt.json', JSON.stringify({ receipt, environment: receiptEnvironment }, null, 2), 'application/json')}>Download private purchase receipt</button><button on:click={clear}>Clear receipt details</button></section>{/if}
    {/if}
  </div><aside class="support-stack"><nav class="support-panel" aria-label="Privacy navigation"><h2>Help and rights</h2><a href="/privacy">Privacy notice</a><a href="/account-deletion">Deletion and retention</a><a href="/support">Public privacy request</a><a href="/support/case">Open a saved case</a><a href="/account/support">Account cases</a><a href="/account/premium">Purchases and receipts</a></nav><section class="support-panel"><h2>Privacy limits</h2><p>No ordinary chat archive or audio recording is available for export. Submitted reports and grievances have separate restricted handling. A record retained for a valid obligation may remain after account access is disabled.</p><p>Do not send government identifiers, another person’s private documents, passwords or recovery codes to support.</p></section></aside></div>
</section>
