<script lang="ts">
  import { onMount } from 'svelte';
  import { page } from '$app/stores';
  import { currentRealtime, subscribeRealtime } from './session';
  import { controlsAvailable, initialState } from './model';
  let live = initialState();
  $: interaction = live.snapshot?.interaction;
  $: waiting = live.snapshot?.state === 'WAITING';
  onMount(() => subscribeRealtime((state) => { live = state; }));
</script>

{#if $page.url.pathname !== '/chat' && (interaction || waiting || live.status === 'reconnecting')}
  <aside class="connection-bar" aria-label="Ongoing connection">
    <p>{live.status === 'reconnecting' ? 'Your live connection is reconnecting.' : interaction ? interaction.kind === 'friend' ? 'Your friend conversation is still active in this tab.' : 'Your match is still active in this tab.' : 'Your search is still active in this tab.'} You can return at any time.</p>
    <div><a href="/chat">Return to your match</a><button disabled={!controlsAvailable(live)} on:click={() => currentRealtime()?.command(interaction ? 'match.end' : 'queue.leave')}>{interaction ? 'End match' : 'Cancel search'}</button></div>
  </aside>
{/if}

<style>
  .connection-bar { display: flex; flex-wrap: wrap; gap: 0.75rem 1rem; justify-content: space-between; align-items: center; padding: 0.75rem max(1rem, env(safe-area-inset-left)); background: var(--surface-accent); border-bottom: 1px solid var(--border); }
  p { margin: 0; max-width: 45rem; color: var(--text-primary); }
  div { display: flex; flex-wrap: wrap; gap: 0.75rem; }
  a, button { display: inline-flex; min-height: 2.75rem; min-width: 2.75rem; align-items: center; justify-content: center; padding: 0.6rem 0.8rem; border: 1px solid var(--border-strong); border-radius: var(--radius-md); color: var(--text-primary); background: var(--surface); text-decoration: none; cursor: pointer; font-weight: 650; }
  button:disabled { opacity: 0.6; cursor: not-allowed; }
</style>
