import { AudioController } from '../audio/controller.ts';
import { parseCall } from '../audio/model.ts';
import type { AudioRuntime } from '../audio/controller.ts';
import { friendRef, parseFriend, parseFriendRequest, parseInvitation } from '../friends/model.ts';
import { ApiError } from '../api/client.ts';
import { errorMessage, initialState, parseEnvelope, parseMaintenance, parseSnapshot, resumeFor, retryDelay, socketURL, statusMessage } from './model.ts';
import { textProblem, trimTranscript } from './text.ts';
import type { ChatMessage } from './text.ts';
import type { Envelope, LiveState, Resume, Ticket } from './model.ts';

type Timer = ReturnType<typeof setTimeout>;
interface Runtime {
  origin: string;
  open(url: string): WebSocket;
  now(): number;
  random(): number;
  id(): string;
  later(fn: () => void, ms: number): Timer;
  cancel(timer: Timer): void;
}
export type FriendCommand = 'friend.request' | 'friend.accept' | 'friend.decline' | 'friend.withdraw' | 'friend.invite' | 'friend.accept_invite' | 'friend.decline_invite';
export type Command = 'queue.join' | 'queue.leave' | 'match.next' | 'match.end' | 'state.sync';
/** One owner per browser application lifetime. Tickets, resume credentials and snapshots
 * are RAM-only. There is deliberately no generic offline command queue. */
export class RealtimeClient {
  state = initialState();
  readonly audio: AudioController;
  remoteAudioStream: MediaStream | null = null;
  private audioCommands = new Map<string, string>();
  private socket: WebSocket | null = null;
  private stopped = false;
  private disposed = false;
  private pageSuspended = false;
  private handoffPending = false;
  private resumedAsIdle = false;
  private opening = false;
  private serial = 0;
  private retry = 0;
  private disconnectedAt = 0;
  private lastFrameAt = 0;
  private lastPingAt = 0;
  private resume: Resume | undefined;
  private intent: { continue_with_everyone?: true } | null = null;
  private pendingID = '';
  private friendPendingID = '';
  private friendPendingType: FriendCommand | null = null;
  private friendPendingTimer: Timer | undefined;
  private highestEpoch = 0;
  private endedInteraction = '';
  private timers = new Set<Timer>();
  private pendingTimer: Timer | undefined;
  private heartbeatTimer: Timer | undefined;
  private reconnectDeadline: Timer | undefined;
  private runtime: Runtime;
  private chatTimers = new Map<string, Timer>();
  private renderedSequences = new Set<number>();
  private clearedChatEpoch = '';
  private chatCommands = new Map<string, string>();

  private ticket: (takeover: boolean) => Promise<Ticket>;
  private changed: (state: LiveState) => void;
  private guest: boolean;
  constructor(ticket: (takeover: boolean) => Promise<Ticket>, changed: (state: LiveState) => void, guest: boolean, runtime?: Partial<Runtime>, audioRuntime?: Partial<AudioRuntime>) {
    this.ticket = ticket; this.changed = changed; this.guest = guest;
    this.runtime = {
      origin: runtime?.origin ?? globalThis.location?.origin ?? '',
      open: runtime?.open ?? ((url) => new WebSocket(url)),
      now: runtime?.now ?? Date.now,
      random: runtime?.random ?? Math.random,
      id: runtime?.id ?? (() => crypto.randomUUID()),
      later: runtime?.later ?? ((fn, ms) => setTimeout(fn, ms)),
      cancel: runtime?.cancel ?? ((timer) => clearTimeout(timer))
    };
    this.audio = new AudioController((type, payload) => {
      if (this.state.snapshot?.maintenance && ['call.request', 'call.accept'].includes(type)) return false;
      if (this.handoffPending || this.state.status !== 'connected' || !this.state.snapshot?.audio_enabled || !this.state.snapshot.interaction) return false;
      const id = this.send(type, payload, true);
      if (!id) return false;
      this.audioCommands.set(id, type);
      if (this.audioCommands.size > 128) this.audioCommands.delete(this.audioCommands.keys().next().value!);
      return true;
    }, (audio) => this.emit({ audio }), { now: this.runtime.now, later: this.runtime.later, cancel: this.runtime.cancel, ...audioRuntime, remote: (stream) => { this.remoteAudioStream = stream; audioRuntime?.remote?.(stream); this.emit({}); } });
  }
  private emit(patch: Partial<LiveState>): void {
    if ('snapshot' in patch) {
      const before = this.state.snapshot?.interaction;
      const after = patch.snapshot?.interaction;
      if (before && (!after || after.id !== before.id || after.epoch !== before.epoch)) {
        this.clearChat(); this.clearFriendPending(); patch = { ...patch, messages: [], draft: '', textError: '', textPaused: false, connectedFriend: null, friendPending: false, friendNotice: '' }; 
      }
    }
    if (patch.status && patch.status !== 'connected') {
      this.clearFriendPending(); patch.friendPending = false;
      // Offline state must never advertise actionable presence or invitations.
      if ('snapshot' in patch && !patch.snapshot) { patch.connectedFriend = null; patch.friendNotice = ''; patch.friendsRevision = this.state.friendsRevision + 1; }
    }
    this.state = { ...this.state, ...patch };
    if ('snapshot' in patch || 'status' in patch) {
      const snapshot = this.state.snapshot, interaction = snapshot?.interaction;
      this.audio.update({ connected: this.state.status === 'connected', admission: !snapshot?.maintenance, enabled: snapshot?.audio_enabled === true, key: interaction ? `${snapshot!.generation}:${interaction.id}:${interaction.epoch}` : '', peerConnected: interaction?.peer_connected === true, friendRef: interaction?.friend_ref, call: snapshot?.call });
    }
    this.changed(this.state);
  }
  private clearChat(): void {
    for (const timer of this.chatTimers.values()) this.clear(timer);
    this.chatTimers.clear(); this.renderedSequences.clear(); this.chatCommands.clear();
  }
  private uncertain(): void {
    this.clearChat();
    this.emit({ messages: this.state.messages.map((item) => item.status === 'sending' ? { ...item, status: 'uncertain' } : item) });
  }
  setDraft(draft: string): void {
    // A draft is local RAM, bounded independently of the wire validation.
    if (draft.length > 12_000) return;
    this.emit({ draft, textError: '' });
  }
  clearConversationText(): void {
    this.audio.stop();
    const active = this.state.snapshot?.interaction;
    if (active) this.clearedChatEpoch = active.id + ':' + active.epoch;
    this.clearChat(); this.emit({ messages: [], draft: '', textError: '', textPaused: true });
  }
  sendText(): boolean {
    const problem = textProblem(this.state.draft);
    if (problem) { this.emit({ textError: problem }); return false; }
    if (!this.state.snapshot?.text_enabled || this.state.textPaused || this.handoffPending || this.state.status !== 'connected' || this.state.pending || !this.state.snapshot?.interaction?.peer_connected) return false;
    const sendID = this.runtime.id();
    const message: ChatMessage = { send_id: sendID, text: this.state.draft, speaker: 'self', status: 'sending' };
    const id = this.send('chat.send', { client_send_id: sendID, text: message.text }, true);
    if (!id) { this.emit({ textError: 'The message was not sent. Check your connection.' }); return false; }
    this.chatCommands.set(id, sendID);
    this.emit({ draft: '', textError: '', messages: trimTranscript([...this.state.messages, message]) });
    for (const [command, pending] of this.chatCommands) if (!this.state.messages.some((item) => item.send_id === pending)) this.chatCommands.delete(command);
    // No content is held by a timer closure. Never automatically resend.
    for (const [pending, timer] of this.chatTimers) if (!this.state.messages.some((item) => item.send_id === pending)) { this.clear(timer); this.chatTimers.delete(pending); }
    this.chatTimers.set(sendID, this.later(() => {
      this.chatTimers.delete(sendID);
      this.emit({ messages: this.state.messages.map((item) => item.send_id === sendID && item.status === 'sending' ? { ...item, status: 'uncertain' } : item) });
    }, 8_000));
    return true;
  }
  /** Called after the UI has rendered an eligible peer message. This is not a read receipt. */
  rendered(sequence: number): void {
    if (this.state.status !== 'connected' || !this.state.snapshot?.interaction?.peer_connected || this.renderedSequences.has(sequence)) return;
    if (!this.state.messages.some((item) => item.sequence === sequence && item.speaker === 'peer')) return;
    if (this.send('chat.delivery_ack', { server_sequence: sequence }, true)) {
      this.renderedSequences.add(sequence);
      const retained = new Set(this.state.messages.map((item) => item.sequence));
      for (const saved of this.renderedSequences) if (!retained.has(saved)) this.renderedSequences.delete(saved);
    }
  }
  private receiveChat(event: Envelope): void {
    const interaction = this.state.snapshot?.interaction;
    if (!interaction || event.generation !== this.state.snapshot?.generation || this.clearedChatEpoch === interaction.id + ':' + interaction.epoch || this.state.status !== 'connected' || event.interaction_id !== interaction.id || event.epoch !== interaction.epoch) return;
    const payload = event.payload as Record<string, unknown>;
    if (!Number.isSafeInteger(payload.server_sequence) || Number(payload.server_sequence) <= 0 || typeof payload.client_send_id !== 'string' || payload.client_send_id.length > 128) return;
    const sequence = Number(payload.server_sequence), sendID = payload.client_send_id;
    if (event.type === 'chat.ack') {
      if (!['accepted', 'delivered'].includes(String(payload.status))) return;
      this.clear(this.chatTimers.get(sendID)); this.chatTimers.delete(sendID);
      for (const [command, pending] of this.chatCommands) if (pending === sendID) this.chatCommands.delete(command);
      this.emit({ messages: this.state.messages.map((item) => item.speaker === 'self' && item.send_id === sendID ? { ...item, sequence, status: payload.status === 'delivered' || item.status === 'rendered' ? 'rendered' : 'accepted' } : item) });
      return;
    }
    if (typeof payload.text !== 'string' || textProblem(payload.text) || !['self', 'peer'].includes(String(payload.sender)) || typeof payload.sent_at !== 'string' || !Number.isFinite(Date.parse(payload.sent_at))) return;
    const speaker = payload.sender as 'self' | 'peer';
    if (speaker === 'self') {
      this.clear(this.chatTimers.get(sendID)); this.chatTimers.delete(sendID);
      for (const [command, pending] of this.chatCommands) if (pending === sendID) this.chatCommands.delete(command);
    }
    const previous = this.state.messages.find((item) => item.sequence === sequence || (item.speaker === 'self' && speaker === 'self' && item.send_id === sendID));
    const item: ChatMessage = { sequence, send_id: sendID, text: payload.text, speaker, created_at: payload.sent_at, status: payload.delivered === true || previous?.status === 'rendered' ? 'rendered' : 'accepted' };
    const messages = this.state.messages.filter((other) => other !== previous);
    messages.push(item);
    messages.sort((a, b) => (a.sequence ?? Number.MAX_SAFE_INTEGER) - (b.sequence ?? Number.MAX_SAFE_INTEGER));
    this.emit({ messages: trimTranscript(messages) });
  }
  private later(fn: () => void, ms: number): Timer {
    const timer = this.runtime.later(() => { this.timers.delete(timer); fn(); }, ms);
    this.timers.add(timer); return timer;
  }
  private clear(timer: Timer | undefined): void { if (timer !== undefined) { this.runtime.cancel(timer); this.timers.delete(timer); } }
  private clearPending(): void { this.pendingID = ''; this.clear(this.pendingTimer); this.pendingTimer = undefined; }
  private closeSocket(): void {
    this.audio.stop('Audio stopped. A new call needs acceptance.', false); this.audioCommands.clear();
    const old = this.socket; this.socket = null; this.serial++;
    this.clear(this.heartbeatTimer); this.heartbeatTimer = undefined;
    if (old && old.readyState < 2) old.close(1000, 'Connection ended');
  }
  private send(type: string, payload: unknown = {}, interaction = false): string | null {
    if (!this.socket || this.socket.readyState !== 1) return null;
    if (this.socket.bufferedAmount > 16_384) { this.socket.close(1008, 'Connection congested'); return null; }
    const id = this.runtime.id();
    const active = this.state.snapshot?.interaction;
    this.socket.send(JSON.stringify({ v: 1, id, type, generation: this.state.snapshot?.generation ?? 0, ...(interaction && active ? { interaction_id: active.id, epoch: active.epoch } : {}), payload }));
    return id;
  }
  async connect(takeover = false): Promise<void> {
    if (this.disposed || this.pageSuspended || this.handoffPending || this.opening || this.socket || this.state.status === 'connected') return;
    this.stopped = false;
    if (takeover) { this.resume = undefined; this.intent = null; }
    if (this.state.status !== 'reconnecting') { this.retry = 0; this.disconnectedAt = 0; }
    this.opening = true;
    const serial = ++this.serial;
    this.emit({ status: this.resume ? 'reconnecting' : 'connecting', pending: false, message: this.resume ? 'Connection interrupted. Trying to reconnect…' : 'Opening a secure connection…' });
    try {
      const ticket = await this.ticket(takeover);
      if (this.disposed || this.stopped || serial !== this.serial) return;
      if (ticket.protocol_version !== 1 || !ticket.ticket || !Number.isFinite(Date.parse(ticket.expires_at)) || Date.parse(ticket.expires_at) <= this.runtime.now()) throw new Error('Invalid ticket');
      const socket = this.runtime.open(socketURL(this.runtime.origin));
      this.socket = socket;
      const active = () => !this.disposed && !this.stopped && serial === this.serial && this.socket === socket;
      const timeout = this.later(() => { if (active() && this.state.status !== 'connected') socket.close(1000, 'Connection timed out'); }, 10_000);
      socket.addEventListener('open', () => {
        if (!active()) return;
        socket.send(JSON.stringify({ v: 1, id: this.runtime.id(), type: 'session.authenticate', generation: 0, payload: { ticket: ticket.ticket, takeover, ...(this.resume ? { resume: this.resume } : {}) } }));
      });
      socket.addEventListener('message', (message) => {
        if (!active()) return;
        const event = parseEnvelope(message.data);
        if (!event) { this.fail('UNSUPPORTED_VERSION'); return; }
        this.lastFrameAt = this.runtime.now();
        this.receive(event);
        if (this.state.status === 'connected') this.clear(timeout);
      });
      socket.addEventListener('close', (event) => {
        this.clear(timeout);
        if (!active()) return;
        if (this.handoffPending) { this.pauseHandoff(); return; }
        if (event.code === 1008 && event.reason === 'SESSION_CLOSED') { this.fail('SESSION_CLOSED'); return; }
        this.socket = null;
        this.clear(this.heartbeatTimer); this.heartbeatTimer = undefined;
        this.reconnect();
      });
      socket.addEventListener('error', () => { if (active() && socket.readyState < 2) socket.close(); });
    } catch (error) {
      if (this.disposed || this.stopped || serial !== this.serial) return;
      if (error instanceof ApiError && [401, 403].includes(error.status)) this.fail(error.status === 401 ? 'AUTHENTICATION_REQUIRED' : 'NOT_AVAILABLE');
      else if (error instanceof ApiError && error.code === 'takeover_required') this.fail('TAKEOVER_REQUIRED');
      else this.reconnect();
    } finally { if (serial === this.serial) this.opening = false; }
  }
  private clearFriendPending(): void { this.friendPendingID = ''; this.friendPendingType = null; this.clear(this.friendPendingTimer); this.friendPendingTimer = undefined; }
  private receiveFriend(event: Envelope): void {
    const snapshot = this.state.snapshot;
    if (this.state.status !== 'connected' || !snapshot?.friends_enabled || event.generation !== snapshot.generation) return;
    const payload = event.payload as Record<string, unknown>;
    const interaction = snapshot.interaction;
    const scoped = Boolean(interaction && event.interaction_id === interaction.id && event.epoch === interaction.epoch);
    if (event.type === 'friend.request.sent' || event.type === 'friend.request.received') {
      const request = parseFriendRequest(payload);
      if (!request || !scoped) return;
      this.clearFriendPending();
      this.emit({ snapshot: { ...snapshot, friend_request: request }, friendPending: false, friendNotice: '' }); return;
    }
    if (event.type === 'friend.request.closed') {
      if (!friendRef(payload.request_ref) || !scoped || payload.request_ref !== snapshot.friend_request?.request_ref) return;
      // The sender sees no rejection signal. Keep its neutral sent state until
      // withdrawal, mutual acceptance or the conversation ends.
      if (snapshot.friend_request.direction === 'incoming') this.emit({ snapshot: { ...snapshot, friend_request: undefined } });
      return;
    }
    if (event.type === 'friend.created' || event.type === 'friend.persisted') {
      const friend = parseFriend(payload.friend); if (!friend) return;
      const currentFriend = scoped && (event.type === 'friend.created' || interaction?.friend_ref === friend.ref || this.state.connectedFriend?.ref === friend.ref);
      if (currentFriend) this.clearFriendPending();
      this.emit({ friendsRevision: this.state.friendsRevision + 1, ...(currentFriend ? { friendPending: false } : {}), ...(currentFriend ? { connectedFriend: friend, snapshot: { ...snapshot, friend_request: undefined } } : {}), friendNotice: friend.durable ? 'Your mutual connection is saved to your accounts.' : friend.pending ? 'You are connected. Saving to your accounts is pending; this link is still temporary.' : 'You are now connected. This guest connection is temporary.' }); return;
    }
    if (event.type === 'friend.invitation.sent' || event.type === 'friend.invitation.incoming') {
      const invitation = parseInvitation(payload);
      if (!invitation || Date.parse(invitation.expires_at) <= this.runtime.now()) return;
      this.clearFriendPending();
      this.emit({ snapshot: { ...snapshot, friend_invitations: [invitation] }, friendPending: false, friendNotice: invitation.direction === 'outgoing' ? 'Invitation sent. Your friend has 30 seconds to accept.' : '' }); return;
    }
    if (event.type === 'friend.invitation.closed') {
      if (!friendRef(payload.invitation_ref) || !snapshot.friend_invitations.some((item) => item.invitation_ref === payload.invitation_ref)) return;
      this.clearFriendPending(); this.emit({ snapshot: { ...snapshot, friend_invitations: [] }, friendPending: false, friendNotice: 'The invitation ended. Nothing was queued for later.' }); return;
    }
    if (event.type === 'friends.changed') { this.emit({ friendsRevision: this.state.friendsRevision + 1 }); return; }
    if (event.type === 'friend.removed' || event.type === 'friend.expired') {
      if (!friendRef(payload.friend_ref)) return;
      this.emit({ friendsRevision: this.state.friendsRevision + 1, ...(this.state.connectedFriend?.ref === payload.friend_ref ? { connectedFriend: null } : {}), snapshot: { ...snapshot, friend_invitations: snapshot.friend_invitations.filter((item) => item.friend_ref !== payload.friend_ref) }, friendNotice: event.type === 'friend.expired' ? 'A temporary connection ended. It is no longer in your friends list.' : 'A connection was removed. Unblocking will not restore it.' }); return;
    }
    if (event.type === 'friend.presence' && friendRef(payload.friend_ref) && ['online', 'busy', 'offline'].includes(String(payload.presence))) this.emit({ friendsRevision: this.state.friendsRevision + 1 });
  }
  friendCommand(type: FriendCommand, payload: Record<string, unknown> = {}): boolean {
    const snapshot = this.state.snapshot;
    if (snapshot?.maintenance && ['friend.invite', 'friend.accept_invite'].includes(type)) return false;
    if (this.handoffPending || this.state.status !== 'connected' || !snapshot?.friends_enabled || this.state.friendPending || this.state.pending) return false;
    const current = ['friend.request', 'friend.accept', 'friend.decline', 'friend.withdraw'].includes(type);
    if (current && (!snapshot.interaction || !snapshot.interaction.peer_connected)) return false;
    if (type === 'friend.request' && (this.state.connectedFriend || snapshot.interaction?.friend_ref)) return false;
    if (['friend.accept', 'friend.decline', 'friend.withdraw'].includes(type) && (!friendRef(payload.request_ref) || payload.request_ref !== snapshot.friend_request?.request_ref)) return false;
    if (type === 'friend.invite' && (snapshot.state !== 'IDLE' || snapshot.friend_invitations.length || !friendRef(payload.friend_ref) || (payload.kind !== 'text' && !(payload.kind === 'audio' && snapshot.audio_enabled)))) return false;
    if (type === 'friend.accept_invite' || type === 'friend.decline_invite') {
      const invitation = snapshot.friend_invitations.find((item) => item.invitation_ref === payload.invitation_ref && item.direction === 'incoming');
      if (!invitation || Date.parse(invitation.expires_at) <= this.runtime.now() || (type === 'friend.accept_invite' && (snapshot.state !== 'IDLE' || (invitation.kind !== 'text' && !(invitation.kind === 'audio' && snapshot.audio_enabled))))) return false;
    }
    const id = this.send(type, payload, current); if (!id) return false;
    if (type === 'friend.invite' && payload.kind === 'audio') this.audio.authorizeFriend(String(payload.friend_ref), this.runtime.now() + 30000);
    if (type === 'friend.accept_invite') {
      const invitation = snapshot.friend_invitations.find((item) => item.invitation_ref === payload.invitation_ref);
      if (invitation?.kind === 'audio') this.audio.authorizeFriend(invitation.friend_ref, Date.parse(invitation.expires_at));
    }
    this.friendPendingID = id; this.friendPendingType = type; this.emit({ friendPending: true, friendNotice: '' });
    this.friendPendingTimer = this.later(() => { this.clearFriendPending(); this.emit({ friendPending: false, friendNotice: 'That friend action has not been confirmed. Refreshing state; it will not be replayed.' }); this.send('state.sync'); }, 8000);
    return true;
  }
  private receiveAudio(event: Envelope): void {
    const snapshot = this.state.snapshot, interaction = snapshot?.interaction;
    if (this.state.status !== 'connected' || !snapshot?.audio_enabled || !interaction || !interaction.peer_connected || event.generation !== snapshot.generation || event.interaction_id !== interaction.id || event.epoch !== interaction.epoch) return;
    const payload = event.payload as Record<string, unknown>;
    if (event.type === 'call.state') {
      const call = parseCall(payload); if (call) this.emit({ snapshot: { ...snapshot, call } });
    } else if (event.type === 'call.ended' && (payload.call_ref === this.state.audio.call?.call_ref || payload.call_ref === snapshot.call?.call_ref)) {
      this.audio.stop('Audio ended. You can continue in text.', false);
      this.emit({ snapshot: { ...snapshot, call: undefined } });
    } else if (event.type === 'call.credentials' && typeof payload.call_ref === 'string') this.audio.credentialsReceived(payload.call_ref, Number(payload.negotiation), payload.credentials);
    else if (event.type.startsWith('webrtc.')) this.audio.signal(event.type, payload);
  }
  private receive(event: Envelope): void {
    if (event.type !== 'session.ready' && event.generation !== 0 && event.generation !== this.state.snapshot?.generation) return;
    if (event.type === 'server.draining') {
      const maintenance = parseMaintenance(event.payload), snapshot = this.state.snapshot;
      if (maintenance && snapshot && event.generation === snapshot.generation && this.state.status === 'connected') {
        this.intent = null;
        this.emit({ snapshot: { ...snapshot, maintenance } });
      }
      return;
    }
    if (event.type.startsWith('call.') || event.type.startsWith('webrtc.')) { this.receiveAudio(event); return; }
    if (event.type === 'command.ack' && event.reply_to && this.audioCommands.has(event.reply_to)) { this.audioCommands.delete(event.reply_to); return; }
    if (event.type.startsWith('friend.') || event.type === 'friends.changed') { this.receiveFriend(event); return; }
    if (event.type === 'command.ack' && event.reply_to === this.friendPendingID) {
      const clearRequest = this.friendPendingType === 'friend.withdraw' || this.friendPendingType === 'friend.decline';
      this.clearFriendPending(); this.emit({ friendPending: false, ...(clearRequest && this.state.snapshot ? { snapshot: { ...this.state.snapshot, friend_request: undefined } } : {}) }); return;
    }
    if (event.type === 'chat.message' || event.type === 'chat.ack') { this.receiveChat(event); return; }
    if (event.type === 'error') {
      const payload = event.payload as { code?: string; retryable?: boolean };
      const code = typeof payload.code === 'string' ? payload.code : 'NOT_AVAILABLE';
      if (event.reply_to && this.audioCommands.has(event.reply_to) && !['AUTHENTICATION_REQUIRED', 'STALE_GENERATION', 'SERVER_RESTARTED', 'WRONG_INSTANCE'].includes(code)) {
        const type = this.audioCommands.get(event.reply_to); this.audioCommands.delete(event.reply_to);
        if (type !== 'call.end' && type !== 'call.decline') this.audio.commandRejected(code);
        return;
      }
      if (event.reply_to && event.reply_to === this.friendPendingID && !['AUTHENTICATION_REQUIRED', 'STALE_GENERATION', 'SERVER_RESTARTED', 'WRONG_INSTANCE'].includes(code)) {
        this.audio.cancelFriendConsent(); this.clearFriendPending(); this.emit({ friendPending: false, friendNotice: code === 'NOT_AVAILABLE' ? 'This friend action is unavailable. Your current conversation stays unchanged.' : errorMessage(code, this.guest) }); return;
      }
      const rejectedSend = event.reply_to ? this.chatCommands.get(event.reply_to) : undefined;
      if (rejectedSend && !['AUTHENTICATION_REQUIRED', 'STALE_GENERATION', 'SERVER_RESTARTED', 'WRONG_INSTANCE'].includes(code)) {
        this.clear(this.chatTimers.get(rejectedSend)); this.chatTimers.delete(rejectedSend); this.chatCommands.delete(event.reply_to!);
        this.emit({ messages: this.state.messages.map((item) => item.send_id === rejectedSend && item.speaker === 'self' ? { ...item, status: 'failed' } : item), textError: errorMessage(code, this.guest) });
        return;
      }
      this.clearPending();
      // A rejected send is never silently retried; the server may not identify
      // acceptance after transport loss, so retain an honest uncertain state.
      this.uncertain();
      if (this.handoffPending && ['AUTHENTICATION_REQUIRED', 'NOT_AVAILABLE', 'RATE_LIMITED'].includes(code)) { this.pauseHandoff(); return; }
      if (this.state.status !== 'connected' && payload.retryable === true && ['RATE_LIMITED', 'NOT_AVAILABLE'].includes(code)) {
        // A fresh account cookie can precede completion of its safety handoff.
        // Retry only establishment with the same RAM resume proof and bounded
        // grace budget. Never replay queue, text or interaction commands.
        this.closeSocket(); this.reconnect(); return;
      }
      if (['TAKEOVER_REQUIRED', 'STALE_GENERATION', 'AUTHENTICATION_REQUIRED', 'SERVER_RESTARTED', 'WRONG_INSTANCE', 'UNSUPPORTED_VERSION'].includes(code)) this.fail(code);
      else if (code === 'STALE_EPOCH' && this.state.status !== 'connected' && this.resume) this.resumeEnded();
      else if (code === 'STALE_EPOCH' && this.state.status !== 'connected') this.fail('WRONG_INSTANCE');
      else if (code === 'STALE_EPOCH') {
        this.resume = undefined;
        if (this.state.snapshot?.interaction) this.endedInteraction = this.state.snapshot.interaction.id;
        this.emit({ snapshot: this.state.snapshot ? { ...this.state.snapshot, state: 'IDLE', interaction: undefined } : null, pending: false, message: errorMessage(code, this.guest) });
        this.send('state.sync');
      } else if (this.state.status !== 'connected') this.fail(code);
      else this.emit({ pending: false, snapshot: code === 'PREMIUM_REQUIRED' && this.state.snapshot ? { ...this.state.snapshot, reason: 'PREMIUM_REQUIRED' } : this.state.snapshot, message: errorMessage(code, this.guest) });
      return;
    }
    if (event.type === 'service.unavailable') { this.fail('NOT_AVAILABLE'); return; }
    if (event.type === 'identity.changed' && this.handoffPending) { this.pauseHandoff(); return; }
    if (event.type === 'session.closed') {
      if (this.handoffPending) { this.pauseHandoff(); return; }
      const reason = (event.payload as { reason?: string }).reason;
      this.fail(reason === 'server_restart' ? 'SERVER_RESTARTED' : ['session_ended', 'authorization_expired'].includes(reason ?? '') ? 'AUTHENTICATION_REQUIRED' : 'SESSION_CLOSED'); return;
    }
    if (event.type === 'session.replaced') { this.fail('STALE_GENERATION'); return; }
    const snapshot = parseSnapshot(event.payload);
    if (snapshot) {
      if (snapshot.generation !== event.generation) return;
      if (event.type === 'session.ready') {
        if (this.state.status === 'connected') return;
        if (this.resume && snapshot.server_instance !== this.resume.server_instance) { this.fail('WRONG_INSTANCE'); return; }
      } else {
        if (this.state.status !== 'connected' || snapshot.generation !== this.state.snapshot?.generation || snapshot.server_instance !== this.state.snapshot?.server_instance) return;
        if (snapshot.interaction && this.state.snapshot?.interaction && snapshot.interaction.epoch < this.state.snapshot.interaction.epoch) return;
      }
      if (snapshot.interaction && (snapshot.interaction.epoch < this.highestEpoch || snapshot.interaction.id === this.endedInteraction)) return;
      if (this.state.snapshot?.interaction && !snapshot.interaction) this.endedInteraction = this.state.snapshot.interaction.id;
      if (snapshot.interaction && snapshot.interaction.id + ':' + snapshot.interaction.epoch !== this.clearedChatEpoch) this.state = { ...this.state, textPaused: false };
      if (snapshot.interaction) this.highestEpoch = Math.max(this.highestEpoch, snapshot.interaction.epoch);
      this.resume = resumeFor(snapshot);
      if (event.type === 'session.ready' || event.type === 'peer.reconnected') this.renderedSequences.clear();
      this.clearPending();
      this.clear(this.reconnectDeadline); this.reconnectDeadline = undefined;
      this.retry = 0; this.disconnectedAt = 0;
      this.emit({ status: 'connected', snapshot, pending: false, ...(event.type === 'session.ready' ? { friendsRevision: this.state.friendsRevision + 1 } : {}), ...(snapshot.ended_report_ref && snapshot.ended_report_expires_at ? { endedReport: { ref: snapshot.ended_report_ref, expires_at: snapshot.ended_report_expires_at } } : {}), message: this.resumedAsIdle && snapshot.state === 'IDLE' ? 'The previous live connection ended. You are connected and idle; choose when to search again.' : statusMessage(snapshot) });
      this.resumedAsIdle = false;
      if (!this.heartbeatTimer) this.watchHeartbeat();
      if (event.type === 'session.ready' && this.intent && snapshot.state === 'IDLE') {
        const intent = this.intent; this.intent = null;
        this.command('queue.join', intent);
      } else if (event.type === 'session.ready') this.intent = null;
    } else if (event.type === 'command.ack' && event.reply_to === this.pendingID) {
      this.clearPending(); this.emit({ pending: false });
    }
  }
  private resumeEnded(): void {
    // Idle/waiting slots are deliberately discarded on disconnect, and a peer
    // may end a match during grace. Reauthenticate once without the old proof;
    // no queue or interaction action crosses into the new connection.
    this.closeSocket(); this.clearPending(); this.resume = undefined; this.intent = null;
    this.highestEpoch = 0; this.endedInteraction = ''; this.opening = false; this.stopped = false;
    this.resumedAsIdle = true;
    this.emit({ status: 'reconnecting', snapshot: null, pending: false, message: 'The previous live connection ended. Reconnecting without joining a queue…' });
    void this.connect();
  }
  private watchHeartbeat(): void {
    this.lastPingAt = this.runtime.now();
    const check = () => {
      if (this.state.status !== 'connected' || !this.socket) return;
      const now = this.runtime.now();
      if (now - this.lastFrameAt >= 45_000) { this.socket.close(1000, 'Connection timed out'); return; }
      if (now - this.lastPingAt >= 20_000) { this.send('heartbeat'); this.lastPingAt = now; }
      this.heartbeatTimer = this.later(check, 1_000);
    };
    this.heartbeatTimer = this.later(check, 1_000);
  }
  private reconnect(): void {
    if (this.disposed || this.pageSuspended || this.stopped) return;
    if (this.handoffPending) { this.pauseHandoff(); return; }
    this.opening = false; this.intent = null; this.clearPending(); this.uncertain();
    if (!this.disconnectedAt) {
      this.disconnectedAt = this.runtime.now();
      this.reconnectDeadline = this.later(() => this.stopRetries(), this.resume?.interaction_id ? 25_000 : 60_000);
    }
    const budget = this.resume?.interaction_id ? 25_000 : 60_000;
    if (this.retry >= 6 || this.runtime.now() - this.disconnectedAt >= budget) {
      this.stopRetries(); return;
    }
    this.emit({ status: 'reconnecting', pending: false, message: this.resume?.interaction_id ? 'Connection interrupted. Actions are paused while reconnecting, for up to 25 seconds.' : 'Connection interrupted. Your waiting entry was removed. Reconnecting…' });
    const delay = retryDelay(this.retry++, this.runtime.random());
    this.later(() => { if (!this.stopped && !this.disposed) void this.connect(); }, delay);
  }
  private stopRetries(): void {
    this.stopped = true; this.opening = false; this.intent = null; this.clearPending(); this.closeSocket();
    for (const timer of this.timers) this.runtime.cancel(timer);
    this.timers.clear(); this.reconnectDeadline = undefined; this.resume = undefined;
    this.emit({ status: 'error', snapshot: null, pending: false, message: 'Automatic reconnect stopped. Your waiting entry was removed. Try connecting again; an expired match cannot be restored.' });
  }
  private fail(code: string): void {
    this.stopped = true; this.opening = false; this.intent = null; this.clearPending(); this.closeSocket();
    for (const timer of this.timers) this.runtime.cancel(timer);
    this.timers.clear(); this.reconnectDeadline = undefined;
    this.resume = undefined;
    const status = code === 'TAKEOVER_REQUIRED' ? 'takeover' : code === 'STALE_GENERATION' ? 'replaced' : code === 'AUTHENTICATION_REQUIRED' ? 'expired' : ['SERVER_RESTARTED', 'WRONG_INSTANCE'].includes(code) ? 'restart' : 'error';
    this.emit({ status, snapshot: null, pending: false, endedReport: null, message: errorMessage(code, this.guest) });
  }
  find(continueEveryone = false): void {
    if (this.state.snapshot?.maintenance || this.pageSuspended) return;
    const payload = continueEveryone ? { continue_with_everyone: true as const } : {};
    if (this.state.status === 'connected') this.command('queue.join', payload);
    else { this.intent = payload; void this.connect(); }
  }
  command(type: Command, payload: unknown = {}): boolean {
    if (this.state.snapshot?.maintenance && ['queue.join', 'match.next'].includes(type)) return false;
    if (this.handoffPending || this.state.status !== 'connected' || this.state.pending) return false;
    const interaction = type === 'match.next' || type === 'match.end';
    if (interaction && !this.state.snapshot?.interaction) return false;
    const id = this.send(type, payload, interaction);
    if (!id) return false;
    if (type === 'state.sync') return true;
    if (interaction) this.clearConversationText();
    this.pendingID = id; this.emit({ pending: true });
    this.pendingTimer = this.later(() => {
      this.clearPending();
      this.emit({ pending: false, message: 'The action has not been confirmed. Refreshing the current state; it will not be replayed.' });
      this.send('state.sync');
    }, 8_000);
    return true;
  }
  /** Keep the mounted owner usable after bfcache restoration, without keeping
   * media or retry timers alive while the document is frozen. */
  suspendPage(): void {
    if (this.disposed || this.pageSuspended) return;
    this.pageSuspended = true;
    const wasLive = Boolean(this.socket || this.opening || this.resume);
    this.closeSocket(); this.opening = false; this.intent = null; this.clearPending(); this.uncertain();
    for (const timer of this.timers) this.runtime.cancel(timer);
    this.timers.clear(); this.reconnectDeadline = undefined;
    if (wasLive) {
      if (!this.disconnectedAt) this.disconnectedAt = this.runtime.now();
      this.emit({ status: 'reconnecting', pending: false, message: 'This page was suspended. Audio stopped. Checking the text connection when you return…' });
    }
  }
  resumePage(): void {
    if (this.disposed) return;
    if (this.pageSuspended) {
      this.pageSuspended = false;
      if (this.state.status !== 'reconnecting' || this.handoffPending) return;
      const remaining = (this.resume?.interaction_id ? 25_000 : 60_000) - (this.runtime.now() - this.disconnectedAt);
      if (remaining <= 0) { this.stopRetries(); return; }
      this.reconnectDeadline = this.later(() => this.stopRetries(), remaining);
      this.reconnect(); return;
    }
    // Mobile browsers may throttle heartbeat timers while hidden. Recheck wall
    // time on visibility/pageshow before presenting an old connection as live.
    if (this.state.status === 'connected' && this.socket) {
      if (this.runtime.now() - this.lastFrameAt >= 45_000) { this.interruptNetwork(); return; }
      this.send('heartbeat'); this.send('state.sync'); this.lastPingAt = this.runtime.now();
    }
  }
  interruptNetwork(): void {
    if (this.disposed || this.pageSuspended || this.stopped || (!this.socket && !this.opening)) return;
    this.closeSocket(); this.reconnect();
  }
  setGuest(guest: boolean): void { this.guest = guest; }
  beginHandoff(): void {
    if (this.disposed || !this.resume) return;
    this.audio.stop('Audio stopped while your identity changes. A new call needs acceptance.');
    this.handoffPending = true;
    this.emit({ pending: true, message: 'Saving your account. Your live connection stays in this tab while the identity changes.' });
  }
  private pauseHandoff(): void {
    this.closeSocket(); this.opening = false; this.intent = null; this.clearPending();
    // Preserve the proof only until the registration response resolves. Never
    // authenticate with a half-rotated cookie while the HTTP mutation is pending.
    this.emit({ status: 'reconnecting', pending: true, message: 'Your identity is changing. Waiting for account confirmation before reconnecting…' });
  }
  finishHandoff(preserved: boolean): void {
    this.handoffPending = false; this.guest = false;
    if (!preserved || !this.resume) { this.closeSocket(); this.resume = undefined; this.emit(initialState()); return; }
    this.closeSocket(); this.opening = false; this.stopped = false; this.clearPending();
    this.emit({ status: 'reconnecting', pending: false });
    void this.connect();
  }
  abortHandoff(safeToResume: boolean): void {
    this.handoffPending = false;
    if (!safeToResume) { this.fail('SESSION_CLOSED'); return; }
    if (this.socket?.readyState === 1) { this.emit({ pending: false, message: this.state.snapshot ? statusMessage(this.state.snapshot) : 'Account creation was not completed.' }); return; }
    this.stopped = false; this.opening = false; this.emit({ status: 'reconnecting', pending: false }); void this.connect();
  }
  startFresh(): void { this.clearChat(); this.emit({ messages: [], draft: '', textError: '', endedReport: null }); this.highestEpoch = 0; this.endedInteraction = ''; this.resume = undefined; this.intent = null; this.closeSocket(); this.emit({ snapshot: null, status: 'offline' }); void this.connect(); }
  dispose(): void {
    this.audio.dispose();
    this.clearChat();
    this.disposed = true; this.handoffPending = false; this.stopped = true; this.opening = false; this.intent = null; this.resume = undefined;
    this.closeSocket();
    for (const timer of this.timers) this.runtime.cancel(timer);
    this.timers.clear(); this.state = initialState();
  }
}
