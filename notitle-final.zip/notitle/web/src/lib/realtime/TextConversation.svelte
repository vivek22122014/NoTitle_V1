<script lang="ts">
  import { afterUpdate } from 'svelte';
  import type { RealtimeClient } from './client';
  import type { LiveState } from './model';
  import { messageStatus, textBytes, textPoints, textProblem } from './text';
  export let realtime: RealtimeClient | null;
  export let live: LiveState;
  $: canSend = live.status === 'connected' && !live.pending && !live.textPaused && live.snapshot?.text_enabled && live.snapshot?.interaction?.peer_connected;
  $: problem = live.draft ? textProblem(live.draft) : null;
  afterUpdate(() => {
    // This callback runs after Svelte updates the actual message DOM. Receiving
    // a network frame alone never qualifies as a recipient rendering ACK.
    for (const message of live.messages) if (message.speaker === 'peer' && message.sequence) realtime?.rendered(message.sequence);
  });
  function submit(event: SubmitEvent): void { event.preventDefault(); realtime?.sendText(); }
</script>

<section class="text-conversation" aria-labelledby="messages-title">
  <h3 id="messages-title">Conversation</h3>
  <p class="privacy">Text is protected in transit and readable by NoTitle’s server. It is not end-to-end encrypted.</p>
  <ol class="messages" aria-label="Conversation messages" aria-live="polite" aria-relevant="additions">
    {#each live.messages as message (message.speaker + ':' + message.send_id)}
      <li class:self={message.speaker === 'self'}>
        <span class="speaker">{message.speaker === 'self' ? 'You' : 'Partner'}</span>
        <p class="body">{message.text}</p>
        <span class="delivery">{messageStatus(message)}</span>
      </li>
    {:else}
      <li class="empty">Say hello when you’re ready. Keep identifying or confidential information private.</li>
    {/each}
  </ol>
  <form on:submit={submit} class="composer">
    <label for="chat-message">Message</label>
    <textarea id="chat-message" value={live.draft} on:input={(event) => realtime?.setDraft(event.currentTarget.value)} rows="3" maxlength="12000" disabled={!canSend} autocomplete="off" spellcheck="true" aria-describedby="message-count message-lifecycle" />
    <div class="composer-actions"><small id="message-count">{textPoints(live.draft)} / 2,000 characters · {textBytes(live.draft)} / 6,144 bytes</small><button class="primary" type="submit" disabled={!canSend || !live.draft || Boolean(problem)}>Send</button></div>
    {#if live.textError || problem}<p class="error" role="status">{live.textError || problem}</p>{/if}
    {#if !canSend}<p class="help">Sending is paused. Your partner must be connected to receive a message.</p>{/if}
  </form>
  <p id="message-lifecycle" class="help">Only the latest 30 messages or 64 KiB are kept in memory. Next and End clear the conversation. Accepted means the server received it; rendered means the other device displayed it, not that a person read it. Uncertain messages are not automatically resent.</p>
</section>

<style>
  .text-conversation { display: grid; gap: 0.75rem; min-width: 0; border-top: 1px solid var(--border); padding-top: 1rem; }
  h3, p { margin: 0; }
  h3 { font-size: 1.1rem; }
  .privacy, .help, small { color: var(--text-secondary); font-size: 0.8rem; }
  .messages { display: grid; align-content: start; gap: 0.75rem; list-style: none; padding: 0.5rem 0; margin: 0; max-height: min(45dvh, 28rem); min-height: 6rem; overflow-y: auto; overscroll-behavior: contain; }
  li { justify-self: start; min-width: 0; max-width: 90%; padding: 0.7rem 0.85rem; border: 1px solid var(--border); border-radius: 0.85rem; background: var(--surface-subtle); }
  li.self { justify-self: end; background: var(--surface-accent); }
  .speaker, .delivery { display: block; font-size: 0.75rem; color: var(--text-secondary); }
  .speaker { font-weight: 700; margin-bottom: 0.3rem; }
  .delivery { margin-top: 0.35rem; }
  .body { white-space: pre-wrap; overflow-wrap: anywhere; unicode-bidi: plaintext; line-height: 1.5; }
  li.empty { max-width: 100%; border: 0; color: var(--text-secondary); font-size: 0.9rem; background: transparent; }
  .composer { display: grid; gap: 0.5rem; min-width: 0; padding-bottom: env(safe-area-inset-bottom); }
  label { font-weight: 650; }
  textarea { width: 100%; min-width: 0; min-height: 5rem; max-height: 12rem; resize: vertical; padding: 0.7rem; border: 1px solid var(--border-strong); border-radius: var(--radius-md); color: var(--text-primary); background: var(--surface); font: inherit; }
  .composer-actions { display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; }
  button { min-width: 4.5rem; min-height: 2.875rem; border-radius: var(--radius-md); border: 1px solid var(--accent); background: var(--accent); color: white; padding: 0.65rem 1rem; font-weight: 700; cursor: pointer; }
  button:disabled { opacity: 0.6; cursor: not-allowed; }
  .error { color: var(--danger); font-size: 0.85rem; }
</style>
