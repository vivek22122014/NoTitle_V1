<script lang="ts">
  import { onMount } from 'svelte';
  import { site } from '$lib/config/site';
  import type { IdentityClient } from '../identity/client';
  import type { Bootstrap, Owner } from '../identity/model';
  import { genderLabels, label } from '../identity/model';
  import type { RealtimeClient } from './client';
  import { acquireRealtime, subscribeRealtime } from './session';
  import { controlsAvailable, initialState } from './model';
  import type { PreferenceView } from './model';
  import Preferences from './Preferences.svelte';
  import TextConversation from './TextConversation.svelte';
  import SafetyPanel from '../safety/SafetyPanel.svelte';
  import CallControls from '../audio/CallControls.svelte';
  import StayConnected from '../friends/StayConnected.svelte';

  export let client: IdentityClient;
  export let identity: Owner;
  export let metadata: Bootstrap;
  let live = initialState();
  let preferences: PreferenceView | null = null;
  let takeoverConfirmed = false;
  let hideAdvisory = false;
  let realtime: RealtimeClient | null = null;
  $: snapshot = live.snapshot;
  $: interaction = snapshot?.interaction;
  $: available = controlsAvailable(live);
  $: working = ['connecting', 'reconnecting'].includes(live.status) || live.pending;
  $: paused = preferences?.requires_everyone_confirmation || snapshot?.requires_everyone_confirmation || snapshot?.reason === 'premium_changed' || snapshot?.reason === 'premium_expired' || snapshot?.reason === 'PREMIUM_EXPIRED' || snapshot?.reason === 'PREMIUM_REQUIRED';
  $: topicName = (value: string) => metadata.vocabularies.topics.find((item) => item.value === value)?.label ?? label(value);
  function takeOver(): void { if (takeoverConfirmed) { takeoverConfirmed = false; void realtime?.connect(true); } }
  onMount(() => {
    realtime = acquireRealtime(identity.kind === 'guest');
    return subscribeRealtime((state) => {
      live = state;
      if (preferences && typeof state.snapshot?.premium_active === 'boolean') preferences = { ...preferences, premium_active: state.snapshot.premium_active, premium_expires_at: state.snapshot.premium_expires_at, requires_everyone_confirmation: state.snapshot.requires_everyone_confirmation === true };
      if (preferences && state.snapshot?.reason?.startsWith('premium_expired')) preferences = { ...preferences, premium_active: false, requires_everyone_confirmation: preferences.preferences.gender !== 'everyone' };
    });
  });
</script>

<section class="chat card" aria-labelledby="matching-title">
  <header class="chat-header">
    <div><p class="eyebrow">One shared pool</p><h2 id="matching-title">{interaction ? interaction.kind === 'friend' ? 'Your friend conversation' : 'Your match' : 'Find a conversation partner'}</h2></div>
    <span class="connection"><span class:online={live.status === 'connected'} class="dot" aria-hidden="true"></span>{live.status === 'connected' ? 'Connected' : live.status === 'reconnecting' ? 'Reconnecting' : 'Not connected'}</span>
  </header>
  {#if !preferences}<p class="help">Matching preferences must load before searching. Open Matching preferences below to retry if they are unavailable.</p>{/if}
  <p class="status" role="status" aria-live="polite" aria-atomic="true">{live.message}</p>

  {#if live.status === 'takeover'}
    <section class="takeover" aria-labelledby="takeover-title">
      <h3 id="takeover-title">Move your connection here?</h3>
      <p>This ends the active connection and match in your other tab or session. Opening a second tab never moves it automatically.</p>
      <label class="check"><input type="checkbox" bind:checked={takeoverConfirmed} /><span>I want to replace my other connection.</span></label>
      <button class="primary" disabled={!takeoverConfirmed} on:click={takeOver}>Move connection here</button>
    </section>
  {:else if live.status === 'expired'}
    <div class="actions"><a class="primary" href={identity.kind === 'guest' ? '/chat' : '/login'}>{identity.kind === 'guest' ? 'Start a new guest session' : 'Sign in again'}</a></div>
  {:else if live.status === 'replaced'}
    <p>Your other connection is active. You can leave this page or reconnect and explicitly choose to move it here.</p><button class="secondary" on:click={() => realtime?.startFresh()}>Check connection</button>
  {:else if live.status === 'restart'}
    <button class="primary" on:click={() => realtime?.startFresh()}>Connect again</button>
  {:else}
    {#if interaction}
      <article class="peer" aria-label="Your matched partner">
        <div class="avatar" aria-hidden="true">{Array.from(interaction.peer.display_name)[0]}</div>
        <h3>{interaction.peer.display_name}</h3>
        <p class="gender">{genderLabels[interaction.peer.gender]} · Self-declared</p>
        {#if interaction.peer.bio}<p class="bio">{interaction.peer.bio}</p>{/if}
        <dl class="topics"><div><dt>Your topic</dt><dd>{topicName(interaction.own_topic)}</dd></div><div><dt>Their topic</dt><dd>{topicName(interaction.peer.topic)}</dd></div></dl>
        {#if interaction.own_topic !== interaction.peer.topic}<p class="help">You selected different topics. Topic similarity never delays an otherwise compatible match.</p>{/if}
      </article>
      {#if snapshot?.text_enabled}<TextConversation {realtime} {live} />{/if}
      {#if snapshot?.audio_enabled}<CallControls {realtime} {live} />{/if}
      <StayConnected {realtime} {live} />
      <div class="actions fixed-actions"><button class="secondary" disabled={!available || Boolean(snapshot?.maintenance)} on:click={() => realtime?.command('match.next')}>Next match</button><button class="danger" disabled={!available} on:click={() => realtime?.command('match.end')}>End match</button></div>
      <p class="help">Next ends this match and starts a new search for you. Your partner returns to idle.</p>
    {:else if snapshot?.state === 'WAITING' || snapshot?.state === 'RESERVED'}
      <div class="waiting"><span class="search-mark" aria-hidden="true">↔</span><h3>{snapshot.state === 'WAITING' ? 'Finding a compatible person' : 'Checking your match'}</h3><p>No separate guest or paid pools. No automatic change to your gender preference.</p></div>
      <button class="secondary" disabled={!available} on:click={() => realtime?.command('queue.leave')}>Cancel search</button>
    {:else}
      <div class="waiting"><span class="search-mark" aria-hidden="true">↔</span><h3>A little space for a work conversation</h3><p>You choose when to search and when to leave. Your private username and professional details stay private.</p></div>
      {#if snapshot?.maintenance}
        <p class="help">New conversations are paused for maintenance. You can still use support and account settings.</p>
      {:else if paused}
        <p class="expiry-note">Your specific gender search is paused. Saved preferences are preserved. <a href="/account/premium">Review Premium and renewal availability</a>.</p>
        <button class="primary" disabled={working || !preferences} on:click={() => realtime?.find(true)}>Continue with Everyone</button>
      {:else if live.status === 'error'}
        <button class="primary" on:click={() => realtime?.startFresh()}>Retry connection</button>
      {:else}
        <button class="primary" disabled={working || !preferences} on:click={() => realtime?.find()}>{working ? 'Connecting…' : 'Find a match'}</button>
      {/if}
    {/if}
    {#if snapshot?.repeat_advisory && !hideAdvisory}
      <aside class="repeat"><h3>You may meet the same person again</h3><p>A small available pool can lead to repeat matches. You can keep searching or take a break.</p><div class="actions"><button class="secondary" on:click={() => { hideAdvisory = true; }}>Keep searching</button><button class="secondary" disabled={!available} on:click={() => { if (interaction) realtime?.command('match.end'); else realtime?.command('queue.leave'); }}>Pause</button></div></aside>
    {/if}
  {/if}
  <a class="friends-link" href="/friends">Your friends and invitations</a>
  <SafetyPanel {client} {realtime} {live} />
  <p class="scope">{#if !site.production}Controlled test release. {/if}{snapshot?.text_enabled ? "Text, reporting and blocking are enabled for this connection." : "Text and report actions are unavailable until the service enables safety coverage."} {snapshot?.friends_enabled ? 'Mutual connections and accepted text invitations are enabled.' : 'Friend features are unavailable on this server.'} {snapshot?.audio_enabled ? 'Audio is enabled with mutual consent and a private relay. Your microphone starts only after Call or Accept and permission.' : 'Audio is unavailable on this server. No microphone is accessed.'} Do not share sensitive information.</p>
</section>
<Preferences {client} {metadata} locked={working} premiumActive={snapshot?.premium_active ?? preferences?.premium_active ?? false} premiumUpdating={snapshot?.reason === 'premium_update_pending'} changed={(view) => { preferences = view; }} />

<style>
  .friends-link { display: inline-flex; align-items: center; min-height: 2.75rem; padding-block: 0.65rem; font-weight: 650; }
  .chat { display: grid; gap: 1rem; padding: clamp(1rem, 3vw, 1.75rem); }
  .chat-header { display: flex; flex-wrap: wrap; align-items: start; justify-content: space-between; gap: 1rem; }
  .eyebrow { margin-bottom: 0.3rem; }
  h2 { margin: 0; font-size: clamp(1.25rem, 3vw, 1.5rem); line-height: 1.35; }
  h3 { margin: 0; font-size: 1.125rem; }
  p { margin: 0; color: var(--text-secondary); }
  .connection { display: inline-flex; gap: 0.4rem; align-items: center; font-size: 0.8rem; color: var(--text-secondary); }
  .dot { width: 0.5rem; height: 0.5rem; border-radius: 50%; background: var(--text-muted); }
  .dot.online { background: var(--success); }
  .status { border-left: 3px solid var(--accent); padding: 0.65rem 0.9rem; background: var(--surface-subtle); border-radius: 0 var(--radius-sm) var(--radius-sm) 0; }
  .waiting, .peer { display: grid; justify-items: center; gap: 0.75rem; text-align: center; padding: 1.5rem 0.25rem; }
  .waiting p, .bio { max-width: 32rem; }
  .search-mark, .avatar { width: 3.5rem; height: 3.5rem; display: grid; place-items: center; background: var(--surface-accent); color: var(--accent-strong); border-radius: 1rem; font-size: 1.8rem; }
  .avatar { border-radius: 50%; text-transform: uppercase; }
  .gender, .help { font-size: 0.85rem; }
  .topics { width: 100%; display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 12rem), 1fr)); gap: 0.75rem; margin: 0.5rem 0; }
  .topics div { border: 1px solid var(--border); border-radius: var(--radius-md); padding: 0.75rem; }
  dt { font-size: 0.8rem; color: var(--text-secondary); }
  dd { margin: 0; font-weight: 650; }
  .actions { display: flex; flex-wrap: wrap; gap: 0.75rem; }
  .fixed-actions { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); }
  button, a.primary { display: inline-flex; min-height: 2.875rem; min-width: 2.75rem; align-items: center; justify-content: center; padding: 0.75rem 1rem; border: 1px solid var(--border-strong); border-radius: var(--radius-md); font-weight: 700; text-decoration: none; cursor: pointer; line-height: 1.35; background: var(--surface); color: var(--text-primary); }
  button:disabled { cursor: not-allowed; opacity: 0.6; }
  .primary, a.primary { background: var(--accent); border-color: var(--accent); color: white; }
  .danger { background: var(--surface); color: var(--danger); border-color: #efb9b9; }
  .scope { border-top: 1px solid var(--border); padding-top: 1rem; font-size: 0.8rem; }
  .takeover, .repeat { display: grid; gap: 0.8rem; padding: 1rem; border: 1px solid var(--border-strong); border-radius: var(--radius-md); }
  .check { display: flex; align-items: flex-start; gap: 0.6rem; min-height: 2.75rem; padding-block: 0.5rem; }
  .check input { flex-shrink: 0; margin-top: 0.3rem; width: 1.1rem; height: 1.1rem; accent-color: var(--accent); }
  .expiry-note { color: var(--warning); }
</style>
