import { initialAudio, parseCall } from '../audio/model.ts';
import type { AudioState, CallView } from '../audio/model.ts';
import { parseFriendRequest, parseInvitation, friendRef } from '../friends/model.ts';
import type { Friend, FriendRequest, FriendInvitation } from '../friends/model.ts';
import type { ChatMessage } from './text.ts';
import type { Gender } from '../identity/model.ts';

export interface Category { no_preference: boolean; choices: string[] }
export interface ProfessionalChoices {
  no_preference: boolean;
  industry: Category; profession: Category; experience: Category; interests: Category; topics: Category;
}
export interface Preferences { version: number; gender: 'everyone' | Gender; professional: ProfessionalChoices }
export interface PreferenceView { preferences: Preferences; premium_active: boolean; premium_expires_at?: string; requires_everyone_confirmation?: boolean }
export interface Ticket { ticket: string; expires_at: string; protocol_version: number }
export interface Peer { display_name: string; gender: Gender; bio: string; topic: string }
export interface Interaction { kind: 'random' | 'friend'; friend_ref?: string; id: string; epoch: number; peer: Peer; own_topic: string; peer_connected: boolean; reconnect_until?: string }
export interface Resume { token: string; server_instance: string; generation: number; interaction_id?: string; epoch?: number }
export interface Maintenance { deadline: string }
export interface Snapshot {
  maintenance?: Maintenance;
  state: 'OFFLINE' | 'IDLE' | 'WAITING' | 'RESERVED' | 'MATCHED';
  premium_active?: boolean; premium_expires_at?: string; requires_everyone_confirmation?: boolean;
  server_instance: string; resume_token: string; generation: number;
  interaction?: Interaction; queued_at?: string; reason?: string; repeat_advisory?: boolean;
  audio_enabled: boolean; call?: CallView; text_enabled: boolean; friends_enabled: boolean; friend_request?: FriendRequest; friend_invitations: FriendInvitation[];
  heartbeat_seconds: number; reconnect_seconds: number; ended_report_ref?: string; ended_report_expires_at?: string;
}
export interface Envelope { v: 1; id: string; type: string; generation: number; interaction_id?: string; epoch?: number; reply_to?: string; payload: unknown }
export type ConnectionStatus = 'offline' | 'connecting' | 'connected' | 'reconnecting' | 'takeover' | 'replaced' | 'expired' | 'restart' | 'error';
export interface EndedReport { ref: string; expires_at: string }
export interface LiveState { audio: AudioState; status: ConnectionStatus; snapshot: Snapshot | null; message: string; pending: boolean; messages: ChatMessage[]; draft: string; textError: string; textPaused: boolean; endedReport: EndedReport | null; friendsRevision: number; friendNotice: string; friendPending: boolean; connectedFriend: Friend | null }
export const initialState = (): LiveState => ({ audio: initialAudio(), status: 'offline', snapshot: null, message: 'Ready when you are. You have not joined the shared pool.', pending: false, messages: [], draft: '', textError: '', textPaused: false, endedReport: null, friendsRevision: 0, friendNotice: '', friendPending: false, connectedFriend: null });
export const categories = ['industry', 'profession', 'experience', 'interests', 'topics'] as const;
export type CategoryName = typeof categories[number];
export function emptyPreferences(): Preferences {
  const empty = (): Category => ({ no_preference: true, choices: [] });
  return { version: 0, gender: 'everyone', professional: { no_preference: true, industry: empty(), profession: empty(), experience: empty(), interests: empty(), topics: empty() } };
}
/** Retry only transport establishment. Queue joins and Next/End are never replayed. */
export function retryDelay(attempt: number, random = Math.random()): number {
  const base = Math.min(8_000, 500 * 2 ** Math.min(5, Math.max(0, attempt)));
  return Math.round(base * (0.75 + Math.min(1, Math.max(0, random)) * 0.5));
}
export function socketURL(origin: string): string {
  const url = new URL(origin);
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.pathname !== '/' || url.search || url.hash) throw new Error('Invalid realtime origin');
  if (url.protocol === 'http:' && !['localhost', '127.0.0.1', '[::1]'].includes(url.hostname)) throw new Error('Realtime requires HTTPS');
  url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
  url.pathname = '/ws';
  return url.toString();
}
const record = (value: unknown): value is Record<string, unknown> => Boolean(value) && typeof value === 'object' && !Array.isArray(value);
const text = (value: unknown, maximum = 256): value is string => typeof value === 'string' && value.length <= maximum;
const positive = (value: unknown): value is number => Number.isSafeInteger(value) && Number(value) > 0;
export function parseEnvelope(raw: unknown): Envelope | null {
  if (typeof raw !== 'string') return null;
  const bytes = new TextEncoder().encode(raw).length;
  if (bytes > 65536) return null;
  try {
    const value: unknown = JSON.parse(raw);
    if (!record(value) || value.v !== 1 || !text(value.id, 128) || !value.id || !text(value.type, 64) || !Number.isSafeInteger(value.generation) || Number(value.generation) < 0 || !record(value.payload)) return null;
    if (bytes > 8192 && !['webrtc.offer', 'webrtc.answer'].includes(value.type)) return null;
    return value as unknown as Envelope;
  } catch { return null; }
}
export function parseMaintenance(value: unknown): Maintenance | null {
  if (!record(value) || !text(value.deadline, 64) || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?Z$/u.test(value.deadline) || !Number.isFinite(Date.parse(value.deadline))) return null;
  return { deadline: value.deadline };
}
/** Explicit projection: unknown/private fields are not retained in UI state. */
export function parseSnapshot(value: unknown): Snapshot | null {
  if (!record(value) || !['OFFLINE', 'IDLE', 'WAITING', 'RESERVED', 'MATCHED'].includes(String(value.state)) || !text(value.server_instance, 128) || !value.server_instance || !text(value.resume_token, 128) || !value.resume_token || !positive(value.generation)) return null;
  const maintenance = value.maintenance === undefined ? undefined : parseMaintenance(value.maintenance);
  if (value.maintenance !== undefined && !maintenance) return null;
  let interaction: Interaction | undefined;
  if (value.interaction !== undefined) {
    const item = value.interaction;
    if (!record(item) || !text(item.id, 128) || !item.id || !positive(item.epoch) || !record(item.peer) || !text(item.own_topic, 64) || typeof item.peer_connected !== 'boolean') return null;
    const peer = item.peer;
    if (!text(peer.display_name, 128) || !['male', 'female', 'other'].includes(String(peer.gender)) || !text(peer.bio, 1024) || !text(peer.topic, 64)) return null;
    if (item.reconnect_until !== undefined && (!text(item.reconnect_until, 64) || !Number.isFinite(Date.parse(item.reconnect_until)))) return null;
    if (item.kind !== undefined && !['random', 'friend'].includes(String(item.kind))) return null;
    if ((item.kind === 'friend' || item.friend_ref !== undefined) && !friendRef(item.friend_ref)) return null;
    interaction = { kind: item.kind === 'friend' ? 'friend' : 'random', ...(friendRef(item.friend_ref) ? { friend_ref: item.friend_ref } : {}), id: item.id, epoch: item.epoch, peer: { display_name: peer.display_name, gender: peer.gender as Gender, bio: peer.bio, topic: peer.topic }, own_topic: item.own_topic, peer_connected: item.peer_connected, ...(typeof item.reconnect_until === 'string' ? { reconnect_until: item.reconnect_until } : {}) };
  }
  if ((value.state === 'MATCHED') !== Boolean(interaction)) return null;
  if ((value.premium_active !== undefined && typeof value.premium_active !== 'boolean') || (value.requires_everyone_confirmation !== undefined && typeof value.requires_everyone_confirmation !== 'boolean') || (value.premium_expires_at !== undefined && (!text(value.premium_expires_at, 64) || !Number.isFinite(Date.parse(value.premium_expires_at))))) return null;
  const friend_request = value.friend_request === undefined ? undefined : parseFriendRequest(value.friend_request);
  const invitations = value.friend_invitations ?? [];
  if ((value.friend_request !== undefined && !friend_request) || !Array.isArray(invitations) || invitations.length > 1) return null;
  const friend_invitations = invitations.map(parseInvitation);
  if (friend_invitations.some((item) => !item)) return null;
  const call = value.call === undefined ? undefined : parseCall(value.call);
  if (value.call !== undefined && (!call || !interaction || value.audio_enabled !== true)) return null;
  return { ...(maintenance ? { maintenance } : {}), ...(typeof value.premium_active === 'boolean' ? { premium_active: value.premium_active } : {}), ...(typeof value.requires_everyone_confirmation === 'boolean' ? { requires_everyone_confirmation: value.requires_everyone_confirmation } : {}), ...(typeof value.premium_expires_at === 'string' ? { premium_expires_at: value.premium_expires_at } : {}), audio_enabled: value.audio_enabled === true, ...(call ? { call } : {}), text_enabled: value.text_enabled === true, friends_enabled: value.friends_enabled === true, ...(friend_request ? { friend_request } : {}), friend_invitations: friend_invitations as FriendInvitation[], state: value.state as Snapshot['state'], server_instance: value.server_instance, resume_token: value.resume_token, generation: value.generation, ...(interaction ? { interaction } : {}), ...(text(value.reason, 128) ? { reason: value.reason } : {}), ...(text(value.queued_at, 64) ? { queued_at: value.queued_at } : {}), ...(text(value.ended_report_ref, 128) && value.ended_report_ref && text(value.ended_report_expires_at, 64) && Number.isFinite(Date.parse(value.ended_report_expires_at)) ? { ended_report_ref: value.ended_report_ref, ended_report_expires_at: value.ended_report_expires_at } : {}), repeat_advisory: value.repeat_advisory === true, heartbeat_seconds: 20, reconnect_seconds: 25 };
}
export function resumeFor(snapshot: Snapshot): Resume {
  return { token: snapshot.resume_token, server_instance: snapshot.server_instance, generation: snapshot.generation, ...(snapshot.interaction ? { interaction_id: snapshot.interaction.id, epoch: snapshot.interaction.epoch } : {}) };
}
export function controlsAvailable(state: LiveState): boolean {
  return state.status === 'connected' && !state.pending;
}
export function statusMessage(snapshot: Snapshot): string {
  if (snapshot.reason === 'premium_update_pending') return 'Your Premium balance is being updated. Paid preferences are paused while the server confirms access; an existing conversation can continue.';
  if (snapshot.reason === 'premium_changed_everyone_continues') return 'Premium access changed. Your Everyone search continues without professional ranking. Saved preferences remain unchanged.';
  if (snapshot.reason === 'premium_expired_everyone_continues') return 'Premium ended. Your Everyone search continues without professional ranking. Saved preferences remain unchanged.';
  if (snapshot.interaction) return snapshot.interaction.peer_connected ? snapshot.interaction.kind === 'friend' ? 'Your friend accepted. Your conversation is ready.' : 'Matched. Your connection is ready.' : 'Your partner disconnected. Reconnect is available for up to 25 seconds. You can still end or leave this match.';
  if (snapshot.reason === 'premium_changed' || snapshot.reason === 'premium_expired' || snapshot.reason === 'PREMIUM_EXPIRED' || snapshot.reason === 'PREMIUM_REQUIRED') return 'Your specific gender search is paused because Premium is inactive or changed. Your saved preferences are unchanged.';
  if (snapshot.state === 'WAITING') return 'Searching the shared pool. A compatible person may not be available yet.';
  if (snapshot.state === 'RESERVED') return 'Checking this match…';
  return 'You are connected. Choose Find a match to enter the shared pool.';
}
export function errorMessage(code: string, guest: boolean): string {
  const messages: Record<string, string> = {
    SESSION_CLOSED: 'The service closed this connection. It may have expired, moved or become unavailable. Check your session before reconnecting.',
    TAKEOVER_REQUIRED: 'Another tab or session owns your connection. Confirm before moving it here.',
    STALE_GENERATION: 'Your connection moved to another tab or session.',
    STALE_EPOCH: 'This match has ended. An old action was not applied to a different match.',
    AUTHENTICATION_REQUIRED: guest ? 'Your guest session ended or the server restarted. Start a new guest session.' : 'Your session expired or was revoked. Sign in again.',
    SERVER_RESTARTED: 'The server restarted. Live matches ended. Connect again to start fresh.',
    WRONG_INSTANCE: 'The previous live connection is no longer available. Its match may have expired or the server changed. Connect again to start fresh.',
    PREMIUM_REQUIRED: 'That preference requires active Premium. Your gender preference was not relaxed.',
    GENDER_REQUIRED: 'Choose Male, Female or Other in your profile before searching.',
    CAPACITY_REACHED: 'The service is at capacity. Your search has not started. Please try again shortly.',
    RATE_LIMITED: 'Please wait before trying again.',
    INVALID_TEXT: 'The message was not accepted. Check its length and unsupported control characters.',
    NOT_AVAILABLE: 'Realtime is temporarily unavailable. No new match has been confirmed.',
    BLOCKED: 'This interaction is no longer available.',
    UNSUPPORTED_VERSION: 'Refresh the page to use the current connection version.'
  };
  return messages[code] ?? 'The connection could not complete this action. Please try again.';
}
