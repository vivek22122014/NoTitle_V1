<script lang="ts">
  import { onMount } from 'svelte';
  import { subscribeRealtime } from './session';
  import { initialState } from './model';
  let live = initialState();
  $: maintenance = live.snapshot?.maintenance;
  $: deadline = maintenance ? new Date(maintenance.deadline).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', timeZoneName: 'short' }) : '';
  onMount(() => subscribeRealtime((state) => { live = state; }));
</script>

{#if maintenance}
  <aside class="maintenance" role="status" aria-live="polite" aria-atomic="true">
    <p><strong>Scheduled maintenance.</strong> New matches, invitations and calls are paused. Existing conversations will close by <time datetime={maintenance.deadline}>{deadline}</time>. You can still end, report or block.</p>
    <a href="/support">Get support</a>
  </aside>
{/if}

<style>
  .maintenance { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 0.75rem 1rem; padding: 1rem max(1rem, env(safe-area-inset-right)) 1rem max(1rem, env(safe-area-inset-left)); background: var(--surface-subtle); border-bottom: 1px solid var(--border-strong); }
  p { margin: 0; max-width: 65ch; overflow-wrap: anywhere; }
  a { display: inline-flex; align-items: center; min-height: 2.75rem; min-width: 2.75rem; padding-block: 0.5rem; font-weight: 650; }
</style>
