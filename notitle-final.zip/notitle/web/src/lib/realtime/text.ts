/** Text is always rendered through Svelte interpolation, never HTML or Markdown. */
export const MAX_MESSAGE_POINTS = 2000;
export const MAX_MESSAGE_BYTES = 6 * 1024;
export const MAX_TRANSCRIPT_MESSAGES = 30;
export const MAX_TRANSCRIPT_BYTES = 64 * 1024;
const encoder = new TextEncoder();
export const textBytes = (value: string): number => encoder.encode(value).length;
export const textPoints = (value: string): number => Array.from(value).length;
export function textProblem(value: string): string | null {
  if (!value.trim()) return 'Write a message before sending.';
  if (textPoints(value) > MAX_MESSAGE_POINTS || textBytes(value) > MAX_MESSAGE_BYTES) return 'Keep messages within 2,000 characters and 6 KiB.';
  // Newlines, combining marks and emoji joiners are allowed. Reject malformed
  // UTF-16 and control/format characters instead of silently changing content.
  const points = Array.from(value);
  if (points.some((point) => (point.length === 1 && point.charCodeAt(0) >= 0xd800 && point.charCodeAt(0) <= 0xdfff) || (!['\n', '\u200c', '\u200d'].includes(point) && /[\p{Cc}\p{Cf}]/u.test(point)))) return 'Remove unsupported control or directionality characters before sending.';
  const wire = JSON.stringify(value).replace(/\u2028/gu, '\\u2028').replace(/\u2029/gu, '\\u2029');
  if (textBytes(wire) + 1 > 8192 - 1024) return 'This message needs too much encoded space. Please shorten it.';
  return null;
}
export type MessageStatus = 'sending' | 'uncertain' | 'accepted' | 'rendered' | 'failed';
export interface ChatMessage {
  send_id: string; sequence?: number; text: string; speaker: 'self' | 'peer'; status: MessageStatus; created_at?: string;
}
/** Same live interaction RAM only, with a shared byte/count budget for pending sends. */
export function trimTranscript(messages: ChatMessage[]): ChatMessage[] {
  const output: ChatMessage[] = [];
  let bytes = 0;
  for (let index = messages.length - 1; index >= 0; index--) {
    const message = messages[index];
    const size = textBytes(message.text);
    if (output.length >= MAX_TRANSCRIPT_MESSAGES || bytes + size > MAX_TRANSCRIPT_BYTES) break;
    output.unshift(message); bytes += size;
  }
  return output;
}
export function messageStatus(message: ChatMessage): string {
  if (message.speaker === 'peer') return 'Received';
  return ({ sending: 'Sending…', uncertain: 'Delivery uncertain — not resent', accepted: 'Accepted by server', rendered: 'Rendered on partner’s device', failed: 'Not accepted' })[message.status];
}
