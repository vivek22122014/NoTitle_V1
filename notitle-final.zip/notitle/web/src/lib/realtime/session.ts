import { ApiError } from '../api/client.ts';
import { IdentityClient } from '../identity/client.ts';
import { RealtimeClient } from './client.ts';
import { initialState } from './model.ts';
import type { LiveState } from './model.ts';

// Browser-module memory only. Navigation within the application retains one
// socket; reload/tab closure loses the proof and requires explicit ownership.
let active: RealtimeClient | null = null;
let identity: IdentityClient | null = null;
const listeners = new Set<(state: LiveState) => void>();
function publish(state: LiveState): void { for (const listener of listeners) listener(state); }
export function subscribeRealtime(listener: (state: LiveState) => void): () => void {
  listeners.add(listener); listener(active?.state ?? initialState());
  return () => listeners.delete(listener);
}
export function currentRealtime(): RealtimeClient | null { return active; }
export function acquireRealtime(guest: boolean): RealtimeClient {
  if (active) { active.setGuest(guest); return active; }
  const api = new IdentityClient(); identity = api;
  const client: RealtimeClient = new RealtimeClient(async (takeover) => {
    // Account mutations rotate cookies and CSRF. The controller owns its client
    // independently of route components and reauthenticates before each ticket.
    const session = await api.current();
    if (!session) throw new ApiError('Your session has ended.', 401, 'authentication_required');
    client.setGuest(session.identity.kind === 'guest');
    return api.realtimeTicket(takeover);
  }, publish, guest);
  active = client; publish(client.state); return client;
}
export function resetRealtime(): void {
  active?.dispose(); active = null; identity?.dispose(); identity = null;
  publish(initialState());
}
