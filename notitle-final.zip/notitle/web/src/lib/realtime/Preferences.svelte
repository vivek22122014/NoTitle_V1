<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import type { Bootstrap } from '../identity/model';
  import { ApiError } from '../api/client';
  import type { IdentityClient } from '../identity/client';
  import { categories, emptyPreferences } from './model';
  import type { CategoryName, PreferenceView, Preferences } from './model';

  export let client: IdentityClient;
  export let metadata: Bootstrap;
  export let locked = false;
  export let premiumActive = false;
  export let premiumUpdating = false;
  export let changed: (view: PreferenceView) => void = () => {};
  let view: PreferenceView | null = null;
  let draft: Preferences = emptyPreferences();
  let loading = true;
  let saving = false;
  let message = '';
  let alive = true;
  let mounted = false;
  let lastPremium = false;
  $: if (mounted && lastPremium !== premiumActive) { lastPremium = premiumActive; void load(); }
  const labels: Record<CategoryName, string> = { industry: 'Industry', profession: 'Profession', experience: 'Experience', interests: 'Interests', topics: 'Discussion topics' };
  $: vocabularies = { industry: metadata.vocabularies.industries, profession: metadata.vocabularies.professions, experience: metadata.vocabularies.experience, interests: metadata.vocabularies.interests, topics: metadata.vocabularies.topics };
  $: enabled = view?.premium_active === true && premiumActive;
  $: requiresConfirmation = !premiumUpdating && (view?.requires_everyone_confirmation || (!enabled && view?.preferences.gender !== 'everyone'));
  $: disabled = loading || saving || locked;
  async function load(): Promise<void> {
    loading = true; message = '';
    try {
      const result = await client.matchingPreferences();
      if (!alive) return;
      view = result; draft = structuredClone(result.preferences); changed(result);
    } catch (error) { if (alive) message = error instanceof ApiError ? error.message : 'Preferences could not be loaded.'; }
    finally { if (alive) loading = false; }
  }
  function categoryNone(key: CategoryName, value: boolean): void {
    draft = { ...draft, professional: { ...draft.professional, [key]: { no_preference: value, choices: value ? [] : draft.professional[key].choices } } };
  }
  function toggle(key: CategoryName, choice: string, checked: boolean): void {
    const current = draft.professional[key];
    const choices = checked ? [...current.choices, choice] : current.choices.filter((item) => item !== choice);
    if (choices.length > (key === 'interests' ? 10 : 5)) return;
    draft = { ...draft, professional: { ...draft.professional, [key]: { no_preference: false, choices } } };
  }
  async function save(): Promise<void> {
    if (!view || disabled) return;
    saving = true; message = '';
    try {
      const result = await client.saveMatchingPreferences(draft);
      if (!alive) return;
      view = result; draft = structuredClone(result.preferences); changed(result);
      message = 'Preferences saved. Active conversations keep their original profile and matching rules.';
    } catch (error) { if (alive) message = error instanceof ApiError ? error.message : 'Preferences were not confirmed. Reload before trying again.'; }
    finally { if (alive) saving = false; }
  }
  onMount(() => { lastPremium = premiumActive; mounted = true; void load(); });
  onDestroy(() => { alive = false; });
</script>

<details class="card preferences">
  <summary>Matching preferences</summary>
  <div class="content">
    {#if loading}<p role="status">Loading your saved preferences…</p>
    {:else if !view}<p role="alert">{message}</p><button on:click={load}>Retry preferences</button>
    {:else}
      <form on:submit|preventDefault={save} aria-busy={saving}>
        <label class="field" for="matching-gender">Gender preference
          <select id="matching-gender" bind:value={draft.gender} disabled={disabled || !enabled}>
            <option value="everyone">Everyone</option><option value="male">Male</option><option value="female">Female</option><option value="other">Other / Non-binary</option>
          </select>
        </label>
        <p class="help">Saved preference: {view.preferences.gender === 'everyone' ? 'Everyone' : view.preferences.gender === 'other' ? 'Other / Non-binary' : view.preferences.gender === 'male' ? 'Male' : 'Female'}. {requiresConfirmation ? 'A new search requires your explicit Everyone choice while this preference is inactive.' : enabled ? 'The server checks your active entitlement for each new match.' : 'Effective preference: Everyone.'}</p>
        <p class="help">Changes apply to your next match. An active match keeps its original profile and matching rules.</p>
        <p class="help">Both participants’ gender preferences must agree. Gender is self-declared, never verified.</p>
        {#if premiumUpdating}<p>Your balance is being confirmed. Paid preferences are temporarily inactive. An already queued search waits for the server result without changing its saved gender preference.</p>{:else if !enabled}<p>Everyone is available without Premium. Saved choices are retained. <a href="/account/premium">Check Premium availability and remaining time</a>.</p>{/if}
        {#if requiresConfirmation}<p class="paused">Your saved specific gender preference is inactive. Searching stays paused until you explicitly choose Continue with Everyone.</p>{/if}
        <details>
          <summary>Professional preferences <span>{draft.professional.no_preference ? '· No preference' : ''}</span></summary>
          <div class="professional">
            <label class="check"><input type="checkbox" bind:checked={draft.professional.no_preference} disabled={disabled || !enabled} /><span>No preference for professional matching</span></label>
            <p class="help">This switch preserves your saved choices. Professional choices only slightly influence an available match and never add waiting time. General Talk turns their influence off.</p>
            {#each categories as key}
              <fieldset disabled={disabled || !enabled || draft.professional.no_preference}>
                <legend>{labels[key]}</legend>
                <label class="check"><input type="checkbox" checked={draft.professional[key].no_preference} on:change={(event) => categoryNone(key, event.currentTarget.checked)} /><span>No preference for {labels[key].toLowerCase()}</span></label>
                <p class="help">Choose up to {key === 'interests' ? 10 : 5}. Any selected choice can contribute; none is required for a match.</p>
                <div class="choices">
                  {#each vocabularies[key].filter((choice) => choice.value) as choice}
                    <label class="check"><input type="checkbox" checked={draft.professional[key].choices.includes(choice.value)} disabled={draft.professional[key].no_preference || (draft.professional[key].choices.length >= (key === 'interests' ? 10 : 5) && !draft.professional[key].choices.includes(choice.value))} on:change={(event) => toggle(key, choice.value, event.currentTarget.checked)} /><span>{choice.label}</span></label>
                  {/each}
                </div>
              </fieldset>
            {/each}
          </div>
        </details>
        {#if message}<p role="status">{message}</p>{/if}
        <div class="actions"><button class="primary" disabled={disabled || !enabled}>Save preferences</button><button type="button" disabled={disabled} on:click={load}>Reload preferences</button></div>
      </form>
    {/if}
  </div>
</details>

<style>
  .preferences { padding: 0.35rem 1rem; }
  summary { min-height: 2.75rem; padding-block: 0.7rem; cursor: pointer; font-weight: 650; }
  summary span { font-weight: 400; color: var(--text-secondary); }
  .content { padding-bottom: 1rem; }
  form, .professional { display: grid; gap: 0.9rem; }
  p { margin: 0; color: var(--text-secondary); }
  .help { font-size: 0.85rem; }
  .field { display: grid; gap: 0.35rem; font-weight: 650; }
  select { width: 100%; min-width: 0; min-height: 2.875rem; padding: 0.65rem; border: 1px solid var(--border-strong); border-radius: var(--radius-md); background: var(--surface); color: var(--text-primary); }
  fieldset { padding: 0.75rem; border: 1px solid var(--border); border-radius: var(--radius-md); }
  legend { font-weight: 650; }
  .check { display: flex; align-items: flex-start; gap: 0.6rem; min-height: 2.75rem; padding: 0.55rem 0; cursor: pointer; }
  .check input { flex-shrink: 0; margin-top: 0.3rem; width: 1.1rem; height: 1.1rem; accent-color: var(--accent); }
  .choices { display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 12rem), 1fr)); }
  .actions { display: flex; flex-wrap: wrap; gap: 0.75rem; }
  button { min-height: 2.875rem; min-width: 2.75rem; padding: 0.7rem 1rem; border: 1px solid var(--border-strong); border-radius: var(--radius-md); background: var(--surface); color: var(--text-primary); cursor: pointer; font-weight: 650; }
  .primary { background: var(--accent); color: white; border-color: var(--accent); }
  button:disabled { cursor: not-allowed; opacity: 0.6; }
  .paused { border-left: 3px solid var(--warning); padding-left: 0.75rem; }
</style>
