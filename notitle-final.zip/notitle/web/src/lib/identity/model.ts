/** Explicit owner fields. Never use these private fields to construct a peer card. */
export type Gender = 'male' | 'female' | 'other';
export type Mode = 'guest' | 'register' | 'login' | 'recovery' | 'profile' | 'settings';
export interface ProfessionalProfile { profession: string; industry: string; experience: string; interests: string[] }
export interface Profile { version: number; display_name: string; gender: Gender; bio: string; topic: string; professional: ProfessionalProfile }
export interface Owner {
  kind: 'guest' | 'account';
  username?: string;
  profile: Profile;
  expires_at: string;
  absolute_expires_at: string;
  reauthentication_until?: string;
}
export interface Session { identity: Owner; csrf_token: string }
export interface AuthResponse extends Session { recovery_code?: string; handoff_state?: string }
export interface Policies { terms: string; privacy: string; community: string }
export interface Choice { value: string; label: string }
export interface Bootstrap {
  csrf_token: string;
  policies: Policies;
  vocabularies: { topics: Choice[]; professions: Choice[]; industries: Choice[]; experience: Choice[]; interests: Choice[] };
}
export interface DeletionReceipt {
  receipt?: string;
  access_disabled: boolean;
  tombstone_durable: boolean;
  state: string;
  requested_at: string;
}

export const genderLabels: Record<Gender, string> = { male: 'Male', female: 'Female', other: 'Other / Non-binary' };
export function isGender(value: string): value is Gender { return Object.hasOwn(genderLabels, value); }
export function emptyProfessional(): ProfessionalProfile { return { profession: '', industry: '', experience: '', interests: [] }; }
export function label(value: string): string { return value.replaceAll('_', ' ').replace(/\b\w/gu, (character) => character.toUpperCase()); }

/** Client hints supplement server validation. Passwords are never trimmed or normalized. */
export function passwordIssue(value: string): string | null {
  const length = Array.from(value).length;
  if (length < 12 || length > 128 || new TextEncoder().encode(value).length > 512 || value.includes('\0')) return 'Use a password of 12–128 characters (up to 512 bytes), without null characters.';
  return null;
}
export function usernameIssue(value: string): string | null {
  return /^[a-z0-9_-]{4,24}$/u.test(value.trim().toLowerCase()) ? null : 'Use 4–24 letters, numbers, underscores or hyphens. Usernames are saved in lowercase.';
}
export function profileIssue(displayName: string, bio: string, generatedName = false): string | null {
  const controls = /[\p{Cc}\u061c\u200b\u200e\u200f\u2028-\u202e\u2066-\u2069\ufeff]/u;
  if (!generatedName && (Array.from(displayName).length < 2 || Array.from(displayName).length > 24 || displayName.trim() !== displayName || controls.test(displayName))) return 'Use a public display name of 2–24 visible characters, without surrounding spaces or control characters.';
  if (Array.from(bio).length > 160 || controls.test(bio)) return 'Use a Bio of at most 160 characters, without line breaks or control characters.';
  return null;
}
export function minutesRemaining(owner: Owner, now: number): number {
  const expiry = Math.min(Date.parse(owner.expires_at), Date.parse(owner.absolute_expires_at));
  return Number.isFinite(expiry) ? Math.max(0, Math.ceil((expiry - now) / 60_000)) : 0;
}
export function deletionMessage(receipt: DeletionReceipt): string {
  if (!receipt.access_disabled) return 'The service has not confirmed that access is disabled. Check the request status.';
  if (!receipt.tombstone_durable) return 'Account access is disabled. The independent deletion record is still pending. Keep your status receipt and check again.';
  if (receipt.state === 'ordinary_erased_restricted_retained') return 'Account access is permanently disabled and ordinary account data has been removed. Required registration, financial, safety and case records remain restricted under the reviewed retention rules. This does not mean every retained record or backup has been erased.';
  return 'Account access is disabled and the independent deletion record is saved. Data removal awaits the approved retention review; erasure is not complete.';
}
