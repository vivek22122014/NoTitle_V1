<script lang="ts">
  import { genderLabels } from './model';
  export let value = '';
  export let disabled = false;
  export let locked = '';
</script>

<fieldset {disabled} aria-describedby="gender-visibility">
  <legend>Gender <span>(required)</span></legend>
  <p id="gender-visibility">People you meet see this self-declared label. It is not verified. Select one; there is no default.</p>
  <div class="choices">
    {#each Object.entries(genderLabels) as [code, label]}
      <label class:selected={value === code}>
        <input type="radio" name="gender" value={code} bind:group={value} required disabled={Boolean(locked) && locked !== code} />
        <span>{label}</span>
      </label>
    {/each}
  </div>
</fieldset>

<style>
  fieldset { margin: 0; padding: 0; border: 0; }
  legend { padding: 0; font-weight: 700; }
  legend span { font-weight: 400; color: var(--text-secondary); }
  p { margin: 0.3rem 0 0.75rem; font-size: 0.86rem; color: var(--text-secondary); }
  .choices { display: grid; gap: 0.5rem; }
  label { display: flex; align-items: center; gap: 0.7rem; min-height: 3rem; padding: 0.65rem 0.8rem; border: 1px solid var(--border-strong); border-radius: var(--radius-md); cursor: pointer; }
  label.selected { background: var(--surface-accent); border-color: var(--accent); }
  input { flex-shrink: 0; width: 1.1rem; height: 1.1rem; margin: 0; accent-color: var(--accent); }
  @media(min-width: 42rem) { .choices { grid-template-columns: 1fr 1fr 1.7fr; } }
</style>
