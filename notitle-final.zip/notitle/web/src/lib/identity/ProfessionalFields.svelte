<script lang="ts">
  import type { Bootstrap, ProfessionalProfile } from './model';
  export let value: ProfessionalProfile;
  export let vocabularies: Bootstrap['vocabularies'];
  export let disabled = false;
</script>

<fieldset {disabled}>
  <legend>Professional details <span>(optional, private)</span></legend>
  <p>Self-declared choices. These are not displayed to people you meet. Do not enter your employer or contact details.</p>
  <div class="fields">
    <label>Profession
      <select bind:value={value.profession}>
        {#each vocabularies.professions as choice}<option value={choice.value}>{choice.label}</option>{/each}
      </select>
    </label>
    <label>Industry
      <select bind:value={value.industry}>
        {#each vocabularies.industries as choice}<option value={choice.value}>{choice.label}</option>{/each}
      </select>
    </label>
    <label>Experience
      <select bind:value={value.experience}>
        {#each vocabularies.experience as choice}<option value={choice.value}>{choice.label}</option>{/each}
      </select>
    </label>
  </div>
  <fieldset class="interests">
    <legend>Interests <span>(optional, private)</span></legend>
    <div class="interest-options">
      {#each vocabularies.interests as choice}
        <label class="interest"><input type="checkbox" value={choice.value} bind:group={value.interests} /><span>{choice.label}</span></label>
      {/each}
    </div>
  </fieldset>
</fieldset>

<style>
  fieldset { padding: 0; margin: 0; border: 0; }
  legend { padding: 0; font-weight: 700; }
  legend span { font-weight: 400; color: var(--text-secondary); }
  p { margin: 0.3rem 0 0.8rem; color: var(--text-secondary); font-size: 0.86rem; }
  .fields { display: grid; gap: 0.8rem; }
  label { display: grid; gap: 0.35rem; font-size: 0.94rem; font-weight: 650; }
  select { width: 100%; min-width: 0; min-height: 2.875rem; padding: 0.6rem; border: 1px solid var(--border-strong); border-radius: var(--radius-md); color: var(--text-primary); background: var(--surface); }
  .interests { margin-top: 1rem; }
  .interest-options { display: grid; gap: 0.25rem; margin-top: 0.5rem; }
  .interest { display: flex; align-items: center; min-height: 2.75rem; gap: 0.65rem; font-weight: 400; cursor: pointer; }
  .interest input { width: 1.1rem; height: 1.1rem; flex-shrink: 0; accent-color: var(--accent); }
  @media(min-width: 42rem) { .fields { grid-template-columns: repeat(3, minmax(0, 1fr)); } }
</style>
