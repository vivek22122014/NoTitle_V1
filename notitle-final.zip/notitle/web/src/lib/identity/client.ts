import { clearPurchaseIntent } from '../payments/intent.ts';
import { parseFriends, friendRef } from '../friends/model.ts';
import type { Friend } from '../friends/model.ts';
import { parseDraft, parseBlocks, parseReceipt, validRef } from '../safety/model.ts';
import type { SafetyTarget, ReportDraft, ReportSubmission, ReportReceipt, BlockView } from '../safety/model.ts';
import { apiFetch, ApiError } from '../api/client.ts';
import type { Preferences, PreferenceView, Ticket } from '../realtime/model.ts';
import type { AuthResponse, Bootstrap, DeletionReceipt, ProfessionalProfile, Profile, Session } from './model.ts';

/** One instance per mounted screen. CSRF tokens live only in component memory. */
export class IdentityClient {
  private csrf = '';
  private abort = new AbortController();

  async bootstrap(): Promise<Bootstrap> {
    const data = await apiFetch<Bootstrap>('/api/v1/auth/bootstrap', { signal: this.abort.signal });
    this.csrf = data.csrf_token;
    return data;
  }
  async current(): Promise<Session | null> {
    try {
      const session = await apiFetch<Session>('/api/v1/me', { signal: this.abort.signal });
      this.csrf = session.csrf_token;
      return session;
    } catch (error) {
      if (error instanceof ApiError && error.status === 401) return null;
      throw error;
    }
  }
  private async mutate<T>(path: string, method: string, body: unknown): Promise<T> {
    if (!this.csrf) throw new ApiError('Reload the security check before trying again.', 0, 'csrf_required');
    return apiFetch<T>(`/api/v1${path}`, {
      method, signal: this.abort.signal,
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': this.csrf },
      body: JSON.stringify(body)
    });
  }
  async authenticate(path: '/guest/session' | '/auth/register' | '/auth/login' | '/auth/recover' | '/auth/change-password' | '/auth/recovery-code', body: unknown): Promise<AuthResponse> {
    const result = await this.mutate<AuthResponse>(path, 'POST', body);
    this.csrf = result.csrf_token;
    return result;
  }
  async beginReport(target: SafetyTarget, block = false): Promise<ReportDraft> { return parseDraft(await this.mutate('/reports/begin', 'POST', { ...target, ...(block ? { block: true } : {}) })); }
  async submitReport(submission: ReportSubmission): Promise<ReportReceipt> { return parseReceipt(await this.mutate('/reports', 'POST', submission)); }
  async blocks(): Promise<BlockView[]> { return parseBlocks(await apiFetch('/api/v1/blocks', { signal: this.abort.signal })); }
  async block(target: SafetyTarget | { friend_ref: string }): Promise<void> { await this.mutate('/blocks', 'POST', target); }
  async unblock(ref: string): Promise<void> {
    if (!validRef(ref)) throw new Error('Invalid block reference');
    await this.mutate('/blocks/' + encodeURIComponent(ref), 'DELETE', {});
  }
  async friends(): Promise<Friend[]> { return parseFriends(await apiFetch('/api/v1/friends', { signal: this.abort.signal })); }
  async removeFriend(ref: string): Promise<void> {
    if (!friendRef(ref)) throw new Error('Invalid friend reference');
    await this.mutate('/friends/' + encodeURIComponent(ref), 'DELETE', {});
  }
  realtimeTicket(takeover = false): Promise<Ticket> { return this.mutate('/realtime/ticket', 'POST', { takeover }); }
  matchingPreferences(): Promise<PreferenceView> { return apiFetch('/api/v1/me/matching-preferences', { signal: this.abort.signal }); }
  saveMatchingPreferences(preferences: Preferences): Promise<PreferenceView> { return this.mutate('/me/matching-preferences', 'PATCH', preferences); }
  profile(version: number, profile: Profile): Promise<Session['identity']> {
    const { display_name, gender, bio, topic } = profile;
    return this.mutate('/me/profile', 'PATCH', { version, display_name, gender, bio, topic });
  }
  professional(version: number, professional: ProfessionalProfile): Promise<Session['identity']> {
    return this.mutate('/me/professional-profile', 'PATCH', { version, ...professional });
  }
  reauthenticate(password: string): Promise<{ reauthentication_until: string }> {
    return this.mutate('/auth/reauthenticate', 'POST', { password });
  }
  async logout(kind: 'guest' | 'account', all = false): Promise<void> {
    await this.mutate(kind === 'guest' ? '/guest/session' : all ? '/auth/logout-all' : '/auth/logout', kind === 'guest' ? 'DELETE' : 'POST', {});
    this.csrf = ''; clearPurchaseIntent();
  }
  async delete(): Promise<DeletionReceipt> {
    const receipt = await this.mutate<DeletionReceipt>('/me', 'DELETE', { confirm: true });
    this.csrf = ''; clearPurchaseIntent();
    return receipt;
  }
  deletionStatus(receipt: string): Promise<DeletionReceipt> { return this.mutate('/account/deletion/status', 'POST', { receipt }); }
  dispose(): void { this.csrf = ''; this.abort.abort(); }
}
