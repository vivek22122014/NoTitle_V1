<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import { site } from '$lib/config/site';
  import RulesNotice from '$lib/support/RulesNotice.svelte';
  import Alert from '$lib/components/Alert.svelte';
  import ChatPanel from '$lib/realtime/ChatPanel.svelte';
  import { currentRealtime, resetRealtime } from '$lib/realtime/session';
  import TextField from '$lib/components/TextField.svelte';
  import { ApiError } from '$lib/api/client';
  import { IdentityClient } from './client';
  import GenderField from './GenderField.svelte';
  import ProfessionalFields from './ProfessionalFields.svelte';
  import { deletionMessage, emptyProfessional, genderLabels, isGender, minutesRemaining, passwordIssue, profileIssue, usernameIssue } from './model';
  import type { AuthResponse, Bootstrap, DeletionReceipt, Mode, Owner, Profile } from './model';

  export let mode: Mode;
  const titles: Record<Mode, string> = { guest: 'Your conversation space', register: 'Create an account', login: 'Welcome back', recovery: 'Recover your account', profile: 'Your profile', settings: 'Your settings' };
  const client = new IdentityClient();
  let metadata: Bootstrap | null = null;
  let identity: Owner | null = null;
  let loading = true;
  let busy = false;
  let error = '';
  let notice = '';
  let username = '';
  let password = '';
  let newPassword = '';
  let recoveryInput = '';
  let currentPassword = '';
  let gender = '';
  let displayName = '';
  let bio = '';
  let topic = 'general_talk';
  let professional = emptyProfessional();
  let adult = false;
  let accepted = false;
  let confirmGender = false;
  let recoveryCode = '';
  let savedRecovery = false;
  let deletionConfirmed = false;
  let deletion: DeletionReceipt | null = null;
  let receipt = '';
  let now = Date.now();
  let alive = true;

  $: remaining = identity ? minutesRemaining(identity, now) : 0;
  $: recent = identity?.kind === 'account' && Date.parse(identity.reauthentication_until ?? '') > now;
  $: protectedMode = mode === 'profile' || mode === 'settings';
  $: signedInForm = identity?.kind === 'account' && ['guest', 'register', 'login', 'recovery'].includes(mode);

  function fillProfile(owner: Owner): void {
    gender = owner.profile.gender;
    displayName = mode === 'register' && owner.kind === 'guest' ? '' : owner.profile.display_name;
    bio = owner.profile.bio;
    topic = owner.profile.topic;
    professional = { ...owner.profile.professional, interests: [...(owner.profile.professional.interests ?? [])] };
  }
  function clearCredentials(): void { password = ''; newPassword = ''; currentPassword = ''; recoveryInput = ''; }
  function displayError(value: unknown): void {
    if (!alive) return;
    error = value instanceof ApiError ? value.message : 'The request could not be completed. Please try again.';
    if (value instanceof ApiError && value.code === 'authentication_required') {
      identity = null;
      error = 'Your session ended or was revoked. Sign in again, or start a new guest session.';
    }
    if (value instanceof ApiError && (value.status === 409 || value.code === 'stale_identity')) error += ' Reload your profile before trying again.';
  }
  async function initialize(): Promise<void> {
    loading = true; error = '';
    try {
      metadata = await client.bootstrap();
      const session = await client.current();
      if (!alive) return;
      identity = session?.identity ?? null;
      if (!session) resetRealtime();
      if (identity) fillProfile(identity);
    } catch (value) { displayError(value); }
    finally { if (alive) loading = false; }
  }
  async function perform(work: () => Promise<void>): Promise<void> {
    if (busy || loading) return;
    busy = true; error = ''; notice = '';
    try { await work(); } catch (value) { displayError(value); }
    finally { clearCredentials(); if (alive) busy = false; }
  }
  function profile(): Profile {
    if (!isGender(gender)) throw new Error('Missing gender');
    return { version: identity?.profile.version ?? 0, display_name: displayName, gender, bio, topic, professional: { ...professional } };
  }
  function setAuth(result: AuthResponse): void {
    if (!alive) return;
    identity = result.identity;
    fillProfile(identity);
    recoveryCode = result.recovery_code ?? '';
    savedRecovery = false;
    notice = result.handoff_state === 'idle' ? 'Your account is ready. Your guest identity has ended.' : 'Your identity is ready. Open your conversation space when you want to find a match.';
  }
  async function submitEntry(): Promise<void> {
    if (!metadata) return;
    if (mode === 'register') username = username.trim().toLowerCase();
    const issue = (mode === 'register' ? usernameIssue(username) ?? passwordIssue(password) : null) ?? profileIssue(displayName, bio, mode === 'guest');
    if (issue) { error = issue; return; }
    if (!isGender(gender) || !adult || !accepted || (mode === 'register' && identity?.kind === 'guest' && !confirmGender)) {
      error = 'Select your gender, confirm you are 18 or over and accept the current policies.'; return;
    }
    await perform(async () => {
      const body = { profile: profile(), consent: { adult_confirmed: adult, policies: metadata!.policies } };
      const handoff = mode === 'register' && identity?.kind === 'guest' ? currentRealtime() : null;
      handoff?.beginHandoff();
      try {
        const result = await client.authenticate(mode === 'guest' ? '/guest/session' : '/auth/register', mode === 'guest' ? body : { ...body, username, password });
        if (handoff && result.handoff_state === 'preserved') handoff.finishHandoff(true);
        else resetRealtime();
        setAuth(result);
      } catch (failure) {
        handoff?.abortHandoff(failure instanceof ApiError && failure.status === 409);
        throw failure;
      }
    });
  }
  async function submitLogin(): Promise<void> {
    await perform(async () => { const result = await client.authenticate('/auth/login', { username, password }); resetRealtime(); setAuth(result); });
  }
  async function submitRecovery(): Promise<void> {
    const issue = passwordIssue(newPassword);
    if (issue) { error = issue; return; }
    await perform(async () => { const result = await client.authenticate('/auth/recover', { username, recovery_code: recoveryInput, new_password: newPassword }); resetRealtime(); setAuth(result); });
  }
  async function saveProfile(): Promise<void> {
    if (!identity) return;
    const issue = profileIssue(displayName, bio);
    if (issue) { error = issue; return; }
    await perform(async () => {
      identity = await client.profile(identity!.profile.version, profile());
      notice = 'Your public profile is saved.';
    });
  }
  async function saveProfessional(): Promise<void> {
    if (!identity) return;
    await perform(async () => { identity = await client.professional(identity!.profile.version, professional); notice = 'Your private professional details are saved.'; });
  }
  async function logout(all = false): Promise<void> {
    if (!identity) return;
    await perform(async () => {
      const guest = identity!.kind === 'guest';
      currentRealtime()?.audio.stop('Audio stopped while signing out.');
      await client.logout(identity!.kind, all);
      resetRealtime();
      identity = null; recoveryCode = ''; gender = ''; displayName = ''; bio = ''; topic = 'general_talk'; professional = emptyProfessional(); adult = false; accepted = false;
      metadata = await client.bootstrap();
      notice = guest ? 'Your guest session has ended. Its temporary identity is gone.' : all ? 'All account sessions have been signed out.' : 'You have signed out of this session.';
    });
  }
  async function reauthenticate(): Promise<void> {
    await perform(async () => {
      const result = await client.reauthenticate(currentPassword);
      if (identity) identity = { ...identity, reauthentication_until: result.reauthentication_until };
      now = Date.now(); notice = 'Password confirmed. Sensitive actions are available for five minutes.';
    });
  }
  async function changePassword(): Promise<void> {
    const issue = passwordIssue(newPassword);
    if (issue) { error = issue; return; }
    await perform(async () => {
      const result = await client.authenticate('/auth/change-password', { new_password: newPassword }); resetRealtime(); setAuth(result);
      notice = 'Password changed. All older sessions have been signed out.';
    });
  }
  async function rotateRecovery(): Promise<void> {
    await perform(async () => { const result = await client.authenticate('/auth/recovery-code', {}); resetRealtime(); setAuth(result); notice = 'Your previous recovery code no longer works. All older sessions have been signed out.'; });
  }
  async function deleteAccount(): Promise<void> {
    if (!deletionConfirmed) { error = 'Confirm that you understand the effects of deletion.'; return; }
    await perform(async () => {
      currentRealtime()?.audio.stop('Audio stopped for account deletion.');
      deletion = await client.delete();
      resetRealtime();
      receipt = deletion.receipt ?? '';
      identity = null; recoveryCode = ''; deletionConfirmed = false;
      metadata = await client.bootstrap();
    });
  }
  async function checkDeletion(): Promise<void> {
    await perform(async () => {
      metadata = await client.bootstrap();
      deletion = await client.deletionStatus(receipt.trim());
    });
  }
  onMount(() => {
    void initialize();
    const timer = window.setInterval(() => {
      now = Date.now();
      if (identity && mode !== 'guest' && minutesRemaining(identity, now) === 0) {
        identity = null; recoveryCode = ''; clearCredentials();
        notice = 'Your session has expired. Sign in again or start a new guest session. Temporary guest friendships expire with that identity.';
      }
    }, 15_000);
    return () => window.clearInterval(timer);
  });
  onDestroy(() => { alive = false; client.dispose(); clearCredentials(); recoveryCode = ''; receipt = ''; });
</script>

<section class="identity-page content-width" aria-labelledby="identity-title">
  <header class="identity-heading">
    <p class="eyebrow">NoTitle · Your space</p>
    <h1 id="identity-title">{titles[mode]}</h1>
    <p>Private access, a public pseudonym. No phone number or email required.</p>
  </header>
  <div class="identity-layout">
    <div class="identity-main">
      {#if metadata && (identity || mode === 'guest')}{#key identity?.kind ?? 'entry'}<RulesNotice account={identity?.kind === 'account'} />{/key}{/if}
      {#if error}<Alert variant="danger" title="Please check">{error}</Alert>{#if metadata}<button class="secondary" disabled={busy || loading} on:click={initialize}>Reload session and security check</button>{/if}{/if}
      {#if notice}<Alert>{notice}</Alert>{/if}
      {#if loading}<p role="status" class="card panel">Checking your session…</p>
      {:else if !metadata}
        <div class="card panel"><h2>Account service unavailable</h2><p>We could not reach the account service. No action has been confirmed.</p><button class="primary" on:click={initialize}>Retry connection</button></div>
      {:else}
        {#if recoveryCode}
          <section class="card panel recovery-panel" aria-labelledby="save-code-title">
            <h2 id="save-code-title" tabindex="-1">Save your recovery code now</h2>
            <p>This is the only time this code is shown. Keep it with your private username in a password manager or another safe place. Anyone with both can recover your account.</p>
            <label class="field-label" for="new-recovery-code">One-time display of your recovery code</label>
            <textarea id="new-recovery-code" class="secret-code" readonly value={recoveryCode} rows="3" spellcheck="false" autocomplete="off" />
            <p>If you lose both your password and this code, we cannot recover the account. No email, phone number or payment receipt can replace the code.</p>
            <label class="check"><input type="checkbox" bind:checked={savedRecovery} /><span>I have safely saved this recovery code.</span></label>
            <button class="primary" disabled={!savedRecovery} on:click={() => { recoveryCode = ''; notice = 'Recovery code hidden. Keep your saved copy safe.'; }}>I saved it — hide the code</button>
          </section>
        {:else if mode === 'guest' && identity}
          <p class="status-pill">{identity.kind === 'guest' ? 'Guest session ready' : 'Account session ready'}</p>
          <ChatPanel {client} {identity} {metadata} />
        {:else if signedInForm}
          <section class="card panel">
            <p class="status-pill">{identity?.kind === 'guest' ? 'Guest session ready' : 'Account session ready'}</p>
            <h2>Hello, {identity?.profile.display_name}</h2>
            <p>Your identity is ready. Visit your conversation space to find a match. Text and safety controls are available when enabled by the service. Mutual connections and audio calls are available when enabled by the service.</p>
            <div class="actions"><a class="primary" href="/chat">Find a match</a><a class="secondary" href="/profile">View your profile</a><a class="secondary" href="/settings">Session settings</a>{#if identity?.kind === 'guest'}<a class="secondary" href="/register">Create an account</a>{/if}</div>
          </section>
        {:else if mode === 'guest' || mode === 'register'}
          <form class="card panel" on:submit|preventDefault={submitEntry} aria-busy={busy}>
            <h2>{mode === 'guest' ? 'Continue as a guest' : 'Your private sign-in'}</h2>
            {#if mode === 'register'}
              <TextField id="username" label="Private username" bind:value={username} autocomplete="username" autocapitalize="none" spellcheck="false" maxlength={24} required help="4–24 lowercase letters, numbers, underscores or hyphens. People you meet never see it." disabled={busy} />
              <TextField id="password" label="Password" type="password" bind:value={password} autocomplete="new-password" minlength={12} maxlength={256} required help="12–128 characters. Password managers, spaces and paste are welcome." disabled={busy} />
              <TextField id="display-name" label="Public display name" bind:value={displayName} autocomplete="nickname" minlength={2} maxlength={48} required help="A pseudonym of 2–24 characters. Do not use identifying contact information." disabled={busy} />
              {#if identity?.kind === 'guest'}<p class="help">Your guest identity will move to the new account after registration succeeds. Confirm the gender you already selected.</p>{/if}
            {:else}<p>A temporary identity stays in server memory. It expires after 30 minutes of inactivity or 24 hours in total. Refreshing preserves a valid session cookie; losing it makes that identity inaccessible.</p>{/if}
            <GenderField bind:value={gender} disabled={busy} locked={mode === 'register' && identity?.kind === 'guest' ? identity.profile.gender : ''} />
            {#if mode === 'register' && identity?.kind === 'guest'}<label class="check"><input type="checkbox" required bind:checked={confirmGender} disabled={busy} /><span>I confirm my selected gender: {genderLabels[identity.profile.gender]}.</span></label>{/if}
            <label class="field-label" for="entry-topic">Workplace topic <span>(optional)</span><select id="entry-topic" bind:value={topic} disabled={busy}>{#each metadata.vocabularies.topics as choice}<option value={choice.value}>{choice.label}</option>{/each}</select></label>
            <details><summary>Optional profile details</summary><div class="optional-fields"><label class="field-label" for="entry-bio">Public Bio <span>(up to 160 characters)</span><textarea id="entry-bio" bind:value={bio} maxlength={320} rows="3" disabled={busy} /></label><ProfessionalFields bind:value={professional} vocabularies={metadata.vocabularies} disabled={busy} /></div></details>
            <div class="consents">
              <label class="check"><input type="checkbox" required bind:checked={adult} disabled={busy} /><span>I confirm that I am at least 18 years old.</span></label>
              <label class="check"><input type="checkbox" required bind:checked={accepted} disabled={busy} /><span>I accept the current policies linked below, including the rules and privacy notice.</span></label>
              <div class="policy-links"><a href="/terms" target="_blank" rel="noopener">Terms (new tab)</a><a href="/privacy" target="_blank" rel="noopener">Privacy (new tab)</a><a href="/community-guidelines" target="_blank" rel="noopener">Community Guidelines (new tab)</a></div>
              <p class="help">Policy versions: {metadata.policies.terms} · {metadata.policies.privacy} · {metadata.policies.community}.{#if !site.production} Preview policies await approval before launch.{/if}</p>
            </div>
            <button class="primary" type="submit" disabled={busy}>{busy ? 'Please wait…' : mode === 'guest' ? 'Create guest session' : 'Create account'}</button>
            <p class="help">Creating an identity does not join a queue. You choose when to find a match. Text and safety tools depend on service availability. Audio requires an enabled service and mutual acceptance.</p>
          </form>
        {:else if mode === 'login' || mode === 'recovery'}
          <form class="card panel" on:submit|preventDefault={mode === 'login' ? submitLogin : submitRecovery} aria-busy={busy}>
            <h2>{mode === 'login' ? 'Sign in privately' : 'Use your saved recovery code'}</h2>
            {#if identity?.kind === 'guest'}<Alert variant="warning">Signing in to an existing account ends this guest identity. It does not import the guest’s temporary links or history.</Alert>{/if}
            <TextField id="username" label="Private username" bind:value={username} autocomplete="username" autocapitalize="none" spellcheck="false" maxlength={24} required disabled={busy} />
            {#if mode === 'login'}<TextField id="password" label="Password" type="password" bind:value={password} autocomplete="current-password" maxlength={256} required disabled={busy} />
            {:else}
              <p>Recovery signs out every existing account session and replaces the used code. Save the replacement when it appears.</p>
              <TextField id="recovery-code" label="Saved recovery code" type="password" bind:value={recoveryInput} autocomplete="off" autocapitalize="none" spellcheck="false" maxlength={128} required disabled={busy} />
              <TextField id="new-password" label="New password" type="password" bind:value={newPassword} autocomplete="new-password" minlength={12} maxlength={256} required disabled={busy} help="12–128 characters. Password managers and paste are supported." />
            {/if}
            <button class="primary" type="submit" disabled={busy}>{busy ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Recover account'}</button>
            <p>{mode === 'login' ? 'Lost your password?' : 'Remember your password?'} <a class="inline-link" href={mode === 'login' ? '/recovery' : '/login'}>{mode === 'login' ? 'Use a recovery code' : 'Sign in'}</a></p>
            {#if mode === 'recovery'}<p class="help">If you lost both the password and recovery code, the account cannot be recovered. We do not use phone, email or payment receipts as ownership proof.</p>{/if}
          </form>
        {:else if protectedMode && !identity && !deletion}
          <div class="card panel"><h2>Sign in to continue</h2><p>No active session was found. A guest can edit their temporary profile while the guest session is valid.</p><div class="actions"><a class="primary" href="/login">Sign in</a><a class="secondary" href="/chat">Conversation space</a></div></div>
        {:else if mode === 'profile' && identity}
          <form class="card panel" on:submit|preventDefault={saveProfile} aria-busy={busy}>
            <h2>What people can see</h2>
            <p>Only your display name, self-declared gender, topic and optional Bio are part of your peer profile.</p>
            {#if identity.kind === 'guest'}<p class="help">Your guest display name is generated for this temporary session.</p>{/if}
            <TextField id="display-name" label="Public display name" bind:value={displayName} minlength={2} maxlength={48} required disabled={busy || identity.kind === 'guest'} />
            <GenderField bind:value={gender} disabled={busy} />
            <label class="field-label" for="profile-topic">Workplace topic<select id="profile-topic" bind:value={topic} disabled={busy}>{#each metadata.vocabularies.topics as choice}<option value={choice.value}>{choice.label}</option>{/each}</select></label>
            <label class="field-label" for="profile-bio">Public Bio <span>(optional, up to 160 characters)</span><textarea id="profile-bio" bind:value={bio} maxlength={320} rows="3" disabled={busy} /></label>
            <button class="primary" type="submit" disabled={busy}>{busy ? 'Saving…' : 'Save public profile'}</button>
            <button class="secondary" type="button" disabled={busy} on:click={initialize}>Reload saved profile</button>
          </form>
          <form class="card panel" on:submit|preventDefault={saveProfessional} aria-busy={busy}><ProfessionalFields bind:value={professional} vocabularies={metadata.vocabularies} disabled={busy} /><button class="secondary" type="submit" disabled={busy}>Save private details</button></form>
          {#if identity.username}<div class="card panel"><h2>Private account information</h2><p>Your private username: <strong>{identity.username}</strong></p><p>Only you can see this here. Your username, account status and professional details are excluded from peer profiles.</p></div>{/if}
        {:else if mode === 'settings' && identity}
          <section class="card panel"><h2>{identity.kind === 'guest' ? 'Temporary guest session' : 'Sessions and security'}</h2><p>{identity.kind === 'guest' ? 'Ending the guest session removes its temporary identity and guest links. Ending a match is a separate action.' : 'Sign out of this browser session or revoke every session for your account.'}</p><div class="actions"><button class="secondary" disabled={busy} on:click={() => logout()}>{identity.kind === 'guest' ? 'End guest session' : 'Sign out'}</button>{#if identity.kind === 'account'}<button class="secondary" disabled={busy} on:click={() => logout(true)}>Sign out all sessions</button>{/if}</div></section>
          {#if identity.kind === 'account'}
            <form class="card panel" on:submit|preventDefault={reauthenticate} aria-busy={busy}><h2>Confirm your password</h2><p>Changing credentials or deleting your account requires a password confirmation within the last five minutes.</p><TextField id="current-password" label="Current password" type="password" bind:value={currentPassword} autocomplete="current-password" maxlength={256} required disabled={busy} /><button class="secondary" type="submit" disabled={busy}>Confirm password</button>{#if recent}<p class="help" role="status">Password confirmation is current.</p>{/if}</form>
            <form class="card panel" on:submit|preventDefault={changePassword} aria-busy={busy}><h2>Change password</h2><TextField id="new-password" label="New password" type="password" bind:value={newPassword} autocomplete="new-password" minlength={12} maxlength={256} required disabled={busy || !recent} help="12–128 characters. Changing it signs out all older sessions." /><button class="primary" type="submit" disabled={busy || !recent}>Change password</button></form>
            <section class="card panel"><h2>Replace recovery code</h2><p>The previous code will stop working immediately and all older sessions will be signed out. The replacement is shown once.</p><button class="secondary" disabled={busy || !recent} on:click={rotateRecovery}>Replace recovery code</button></section>
            <form class="card panel danger-panel" on:submit|preventDefault={deleteAccount} aria-busy={busy}><h2>Request account deletion</h2><p>This immediately disables account access and revokes every session. The separate deletion record may remain pending if its storage is temporarily unavailable.</p><p>Data removal follows the approved retention schedule and any lawful holds. Erasure remains separately tracked and may be delayed by a reviewed retention rule or lawful hold; deletion does not issue refunds. This ends active matching, text conversations and connections. Selected report evidence may be retained separately for restricted review. Account friendships are removed when access is disabled. Deletion ends access to any remaining Premium. Before closure, save your required receipts and private support case codes. Save the deletion-status receipt shown after confirmation to retrieve required financial receipts at Privacy controls. Required payment records and pending refunds are retained under restricted financial references; later payment events never recreate your account.</p><a class="inline-link" href="/account-deletion" target="_blank" rel="noopener">Read the deletion notice (new tab)</a><label class="check"><input type="checkbox" required bind:checked={deletionConfirmed} disabled={busy || !recent} /><span>I understand that I will lose access and that erasure is a separate tracked process.</span></label><button class="danger" type="submit" disabled={busy || !recent || !deletionConfirmed}>Disable access and request deletion</button></form>
          {/if}
        {/if}
        {#if deletion}<section class="card panel" aria-labelledby="deletion-result"><h2 id="deletion-result">Deletion request status</h2><Alert variant={deletion.tombstone_durable ? 'info' : 'warning'}>{deletionMessage(deletion)}</Alert>{#if receipt}<p>Save the private status receipt below. It lets you check this request without signing in. It is not stored in this browser.</p><label class="field-label" for="deletion-receipt">Private status receipt<textarea id="deletion-receipt" class="secret-code" readonly value={receipt} rows="3" spellcheck="false" /></label>{/if}</section>{/if}
        {#if mode === 'settings' && !identity}<form class="card panel" on:submit|preventDefault={checkDeletion} aria-busy={busy}><h2>Check a deletion request</h2><TextField id="status-receipt" label="Private status receipt" bind:value={receipt} type="password" autocomplete="off" autocapitalize="none" spellcheck="false" required maxlength={128} disabled={busy} /><button class="secondary" type="submit" disabled={busy}>Check request status</button></form>{/if}
      {/if}
    </div>
    <aside class="identity-aside" aria-label="Account navigation and privacy">
      <nav class="card panel" aria-label="Account navigation"><h2>Your space</h2><a href="/chat" aria-current={mode === 'guest' ? 'page' : undefined}>Conversation space</a><a href="/register" aria-current={mode === 'register' ? 'page' : undefined}>Create an account</a><a href="/login" aria-current={mode === 'login' ? 'page' : undefined}>Sign in</a><a href="/friends">Your friends</a><a href="/profile" aria-current={mode === 'profile' ? 'page' : undefined}>Your profile</a><a href="/account/premium">Premium, purchases and receipts</a><a href="/account/support">Your support cases</a><a href="/account/privacy">Privacy controls and export</a><a href="/settings" aria-current={mode === 'settings' ? 'page' : undefined}>Settings and deletion</a></nav>
      {#if identity}<div class="card panel"><h2>{identity.kind === 'guest' ? 'Guest expiry' : 'Session expiry'}</h2><p>{identity.kind === 'guest' ? '30 minutes inactive; at most 24 hours.' : '7 days inactive; at most 30 days.'} Authorized activity can extend the idle deadline, never the maximum lifetime.</p>{#if identity.kind === 'guest' && mode !== 'guest' && remaining <= 5}<Alert variant="warning">This guest session expires in about {remaining} minute{remaining === 1 ? '' : 's'} without authorized activity. Its temporary links expire too.</Alert>{/if}</div>{/if}
      <div class="privacy-note"><h2>Anonymous to the people you meet</h2><p>Your private username stays private. Peers see a pseudonym, self-declared gender, topic and optional Bio. Avoid identifying information.</p><p>Matching, text, safety submissions and mutual connections are available when enabled{site.production ? '' : ' for controlled testing'}. Audio is available only when the service enables its relay. Premium checkout is available only for enabled, reviewed plans.</p><a class="inline-link" href="/privacy">Read the privacy notice</a></div>
    </aside>
  </div>
</section>

<style>
  .identity-page { padding-block: 2rem 4rem; max-width: 66rem; }
  .identity-heading { margin-bottom: 1.5rem; }
  h1 { font-size: clamp(2rem, 6vw, 3.3rem); line-height: 1.12; letter-spacing: -0.045em; margin: 0 0 1rem; }
  h2 { font-size: 1.2rem; line-height: 1.35; margin: 0; }
  p { margin: 0; color: var(--text-secondary); }
  .identity-layout, .identity-main, .identity-aside, .panel { display: grid; gap: 1rem; align-content: start; }
  .panel { padding: clamp(1rem, 3vw, 1.75rem); }
  .panel form { margin: 0; }
  .identity-main, .identity-aside { min-width: 0; }
  .field-label { display: grid; gap: 0.4rem; font-weight: 650; font-size: 0.94rem; }
  .field-label span { color: var(--text-secondary); font-weight: 400; }
  textarea, select { width: 100%; min-width: 0; min-height: 2.875rem; padding: 0.7rem 0.8rem; border: 1px solid var(--border-strong); border-radius: var(--radius-md); color: var(--text-primary); background: var(--surface); }
  textarea { resize: vertical; }
  .secret-code { font-family: ui-monospace, monospace; word-break: break-all; background: var(--surface-subtle); }
  .check { display: flex; align-items: flex-start; gap: 0.75rem; min-height: 2.75rem; padding-block: 0.45rem; cursor: pointer; }
  .check input { flex-shrink: 0; width: 1.15rem; height: 1.15rem; margin: 0.25rem 0 0; accent-color: var(--accent); }
  button, .primary, .secondary, .danger { display: inline-flex; min-width: 2.75rem; min-height: 2.875rem; align-items: center; justify-content: center; padding: 0.75rem 1rem; border: 1px solid transparent; border-radius: var(--radius-md); font-weight: 700; text-decoration: none; cursor: pointer; text-align: center; line-height: 1.3; }
  .primary { background: var(--accent); color: white; }
  .secondary { background: var(--surface); border-color: var(--border-strong); color: var(--text-primary); }
  .danger { background: var(--danger); color: white; }
  button:disabled { opacity: 0.55; cursor: not-allowed; }
  .actions { display: flex; flex-wrap: wrap; gap: 0.75rem; }
  .help { color: var(--text-secondary); font-size: 0.85rem; }
  .policy-links { display: flex; flex-wrap: wrap; gap: 0.2rem 0.75rem; }
  .policy-links a, .inline-link, nav a { display: inline-flex; min-width: 2.75rem; min-height: 2.75rem; align-items: center; padding-block: 0.5rem; }
  nav a { padding: 0.5rem 0.75rem; border-radius: var(--radius-sm); text-decoration: none; }
  nav a[aria-current='page'] { background: var(--surface-accent); font-weight: 700; text-decoration: underline; }
  nav.panel { gap: 0.25rem; }
  nav h2 { padding: 0 0.75rem 0.5rem; }
  .privacy-note { display: grid; gap: 0.75rem; padding: 0.5rem 1rem; font-size: 0.9rem; }
  .privacy-note h2 { font-size: 1rem; }
  .status-pill { width: fit-content; color: var(--accent-strong); background: var(--surface-accent); border-radius: 2rem; font-size: 0.8rem; font-weight: 650; padding: 0.3rem 0.75rem; }
  .recovery-panel { border-color: var(--accent); border-width: 2px; }
  .danger-panel { border-color: #efb9b9; }
  summary { min-height: 2.75rem; padding-block: 0.5rem; cursor: pointer; font-weight: 650; }
  .optional-fields { display: grid; gap: 1rem; margin-top: 1rem; }
  @media(min-width: 56rem) { .identity-layout { grid-template-columns: minmax(0, 2fr) minmax(15rem, 1fr); gap: 1.5rem; } }
</style>
