<script lang="ts">
  import { onMount } from 'svelte';
  import { PaymentClient } from './client';
  import { duration, money } from './model';
  import type { Catalog } from './model';
  import catalog from '../../../config/plans.json';
  import { release, checkoutBuild } from '../config/site';
  // Meaningful reviewed initial HTML; interactive selection always rechecks the
  // server's enabled immutable catalog before an account creates an order.
  let current: Catalog | null = null;
  let failed = false;
  const initial = release.commercial.salesEnabled ? catalog.plans.filter((plan) => plan.enabled) : [];
  onMount(() => {
    const client = new PaymentClient(); let alive = true;
    void client.catalog().then((value) => { if (alive) current = value; }).catch(() => { if (alive) failed = true; });
    return () => { alive = false; client.dispose(); };
  });
</script>

<div class="plan-section" aria-label="Premium purchase availability">
  {#if failed}
    <div class="notice"><strong>Plan availability could not be checked.</strong><p>No payment was started. Try again from your account.</p></div>
  {:else if current?.checkout_enabled && checkoutBuild.enabled && checkoutBuild.environment === current.environment && current.plans.length}
    {#if current.environment === 'sandbox'}<p class="notice"><strong>Test checkout only.</strong> These plans do not accept real payments.</p>{/if}
    <div class="plans">{#each current.plans as plan}<article class="card"><h2>{plan.name}</h2><p class="price">{money(plan.amount_paise)}</p><p>{duration(plan.duration_seconds)} of continuous access</p><p class="small">{plan.tax_treatment}. Total includes applicable tax. No automatic renewal.</p><a class="choose" href="/account/premium">Review in your account</a></article>{/each}</div>
  {:else if !current && initial.length}
    <div class="plans">{#each initial as plan}<article class="card"><h2>{plan.name}</h2><p class="price">{money(plan.totalPricePaise)}</p><p>{plan.durationLabel} of continuous access</p><p class="small">{release.tax.disclosure}. Total includes applicable tax. No automatic renewal.</p><a class="choose" href="/account/premium">Check current availability</a></article>{/each}</div>
  {:else}
    <div class="notice"><strong>Premium is not on sale.</strong><p>Checkout opens only for enabled, reviewed plans. No payment is requested while checkout is closed.</p></div>
  {/if}
  <p class="small">Additional purchases append time to your remaining Premium. Time runs continuously, including while offline. Your private account keeps payment status and receipts.</p>
  <a class="choose" href="/account/premium">Your Premium, orders and receipts</a>
</div>

<style>
  .plan-section { margin-top: 1.5rem; display: grid; gap: 1rem; }
  .plans { display: grid; gap: 1rem; grid-template-columns: repeat(auto-fit, minmax(min(100%, 15rem), 1fr)); }
  article { min-width: 0; padding: 1.25rem; display: grid; gap: 0.65rem; }
  h2 { font-size: 1.1rem; margin: 0; } p { margin: 0; color: var(--text-secondary); }
  .price { font-weight: 750; font-size: 1.8rem; color: var(--text-primary); }
  .small { font-size: 0.875rem; }.choose { display: inline-flex; min-height: 2.75rem; align-items: center; font-weight: 650; }
  .notice p { margin-top: 0.5rem; }
</style>
