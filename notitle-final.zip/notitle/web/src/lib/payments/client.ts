import { apiFetch, ApiError } from '../api/client.ts';
import { parseCatalog, parseEntitlement, parseOrder, parseOrders, parseReceipt, parseReceipts, parseRefunds, purchaseRef } from './model.ts';
export class PaymentClient {
  private abort = new AbortController();
  private csrf: string;
  constructor(csrf = '') { this.csrf = csrf; }
  catalog() { return apiFetch('/api/v1/premium/plans', { signal: this.abort.signal }).then(parseCatalog); }
  entitlement() { return apiFetch('/api/v1/me/premium', { signal: this.abort.signal }).then(parseEntitlement); }
  orders() { return apiFetch('/api/v1/me/orders', { signal: this.abort.signal }).then(parseOrders); }
  receipts() { return apiFetch('/api/v1/me/receipts', { signal: this.abort.signal }).then(parseReceipts); }
  receipt(ref: string) { this.path(ref); return apiFetch('/api/v1/me/receipts/' + encodeURIComponent(ref), { signal: this.abort.signal }).then(parseReceipt); }
  order(ref: string) { return apiFetch(this.path(ref), { signal: this.abort.signal }).then(parseOrder); }
  refunds(ref: string) { return apiFetch(this.path(ref) + '/refunds', { signal: this.abort.signal }).then(parseRefunds); }
  private path(ref: string): string { if (!purchaseRef(ref)) throw new Error('Invalid purchase reference'); return '/api/v1/payments/' + encodeURIComponent(ref); }
  private write(path: string, body: unknown) {
    if (!this.csrf) throw new ApiError('Sign in again before continuing.', 401, 'csrf_required');
    return apiFetch(path, { method: 'POST', signal: this.abort.signal, headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': this.csrf }, body: JSON.stringify(body), timeoutMs: 20000 });
  }
  create(input: { plan_id: string; plan_version: number; idempotency_key: string; customer_phone: string }) { return this.write('/api/v1/payments/orders', input).then(parseOrder); }
  checkout(ref: string, phone: string) { this.path(ref); return this.write('/api/v1/payments/checkout', { purchase_ref: ref, customer_phone: phone }).then(parseOrder); }
  verify(ref: string) { this.path(ref); return this.write('/api/v1/payments/verify', { purchase_ref: ref }).then(parseOrder); }
  dispose(): void { this.csrf = ''; this.abort.abort(); }
}
