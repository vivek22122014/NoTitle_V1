<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import { IdentityClient } from '../identity/client';
  import type { Session } from '../identity/model';
  import { ApiError } from '../api/client';
  import { PaymentClient } from './client';
  import { duration, money, orderLabel, pendingOrder, phoneIssue, purchaseRef, refundLabel, refundDuration } from './model';
  import type { Catalog, Entitlement, Order, Plan, Receipt, Refund } from './model';
  import { intentFor } from './intent';
  import { checkoutBuild } from '../config/site';
  import type { PurchaseIntent } from './intent';
  export let statusMode = false;
  const identity = new IdentityClient();
  let checkoutAbort = new AbortController();
  let checkoutPending = false, checkoutVersion = 0;
  let client: PaymentClient | null = null, intent: PurchaseIntent | null = null;
  let session: Session | null = null, catalog: Catalog | null = null, entitlement: Entitlement | null = null;
  let orders: Order[] = [], receipts: Receipt[] = [], refunds: Refund[] = [];
  let detailReceipt: Receipt | null = null, lookupRef = '';
  let selected: Plan | null = null, order: Order | null = null;
  let phone = '', confirmed = false, loading = true, busy = false, alive = true, unknown = false;
  let error = '', notice = '', pollTimer: ReturnType<typeof setTimeout> | undefined, polls = 0;
  $: account = session?.identity.kind === 'account';
  $: unresolved = orders.some(pendingOrder) || !!intent?.pending;
  $: checkoutAvailable = !!catalog?.checkout_enabled && checkoutBuild.enabled && checkoutBuild.environment === catalog.environment;
  $: canChoose = account && checkoutAvailable && !busy && !unknown && !unresolved;
  $: title = statusMode ? 'Payment status' : 'Your Premium';
  const when = (value: string): string => new Date(value).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' });
  function message(value: unknown): string {
    if (value instanceof ApiError && value.status === 401) {
      stopPolling(); session = null; orders = []; receipts = []; refunds = []; order = null; entitlement = null; selected = null; phone = ''; detailReceipt = null; lookupRef = ''; intent?.clear();
    }
    return value instanceof ApiError ? value.message : value instanceof Error ? value.message : 'Payment information could not be loaded.';
  }
  function stopPolling(): void { if (pollTimer) clearTimeout(pollTimer); pollTimer = undefined; }
  async function refresh(): Promise<void> {
    if (!client || !account) return;
    const [nextEntitlement, nextOrders, nextReceipts] = await Promise.all([client.entitlement(), client.orders(), client.receipts()]);
    if (!alive) return;
    entitlement = nextEntitlement; orders = nextOrders; receipts = nextReceipts;
  }
  function schedulePoll(): void {
    stopPolling();
    if (!order || !['intent', 'processing', 'checkout_ready'].includes(order.status) || polls >= 7) return;
    const delay = [2000, 3000, 5000, 8000, 13000, 20000, 30000][polls++];
    pollTimer = setTimeout(() => { if (document.visibilityState === 'visible') void readOrder(false); }, delay);
  }
  async function readOrder(verify = false): Promise<void> {
    if (!client || !order || busy) return;
    busy = true; error = '';
    try {
      const value = verify ? await client.verify(order.purchase_ref) : await client.order(order.purchase_ref);
      if (!alive) return;
      order = value; if (intent?.reference === value.purchase_ref) intent.confirm(value);
      refunds = await client.refunds(value.purchase_ref);
      detailReceipt = value.paid_at ? await client.receipt(value.purchase_ref) : null;
      await refresh();
      if (alive) schedulePoll();
    } catch (reason) { if (alive) error = message(reason); }
    finally { if (alive) busy = false; }
  }
  async function viewOrder(value: Order): Promise<void> { stopPolling(); order = value; selected = null; phone = ''; confirmed = false; refunds = []; detailReceipt = null; polls = 0; await readOrder(true); }
  async function lookup(): Promise<void> {
    if (!client || !account || busy) return;
    const ref = lookupRef.trim();
    if (!purchaseRef(ref)) { error = 'Enter the complete purchase reference from your payment record.'; return; }
    busy = true; error = '';
    try { const value = await client.order(ref); if (alive) { busy = false; await viewOrder(value); } }
    catch (reason) { if (alive) error = message(reason); }
    finally { if (alive) busy = false; }
  }
  async function initialize(): Promise<void> {
    loading = true; error = '';
    try {
      session = await identity.current();
      if (!alive || session?.identity.kind !== 'account') return;
      intent = intentFor(session.identity.username ?? '');
      client = new PaymentClient(session.csrf_token);
      catalog = await client.catalog(); await refresh();
      if (!alive) return;
      const url = new URL(window.location.href), ref = url.searchParams.get('purchase_ref');
      // Financial references are not credentials, but remove the callback query
      // promptly and never interpret SDK flags, payment IDs or arbitrary URLs.
      if (url.search || url.hash) history.replaceState(history.state, '', url.pathname);
      if (ref && purchaseRef(ref)) order = await client.order(ref);
      else if (intent.reference) order = await client.order(intent.reference);
      else if (statusMode) order = orders.find(pendingOrder) ?? orders[0] ?? null;
      unknown = !!intent.pending && !intent.reference;
      if (order) { polls = 0; await readOrder(true); }
    } catch (reason) { if (alive) error = message(reason); }
    finally { if (alive) loading = false; }
  }
  function choose(plan: Plan): void {
    if (!canChoose) return;
    if (intent && !intent.pending) intent.newPurchase();
    selected = plan; order = null; phone = ''; confirmed = false; error = ''; notice = ''; refunds = [];
  }
  async function prepare(retry = false): Promise<void> {
    if (!client || !intent || !account || busy || (!retry && (!selected || !confirmed))) return;
    if (catalog?.phone_required && (!retry || phone)) { const issue = phoneIssue(phone); if (issue) { error = issue; return; } }
    const input = retry ? intent.request() : intent.select(selected!);
    const paymentPhone = phone; phone = ''; busy = true; error = ''; unknown = true;
    try {
      const value = await client.create({ ...input, customer_phone: paymentPhone });
      if (!alive) return;
      intent.confirm(value); order = value; unknown = false; selected = null; confirmed = false; polls = 0;
      notice = 'Your order is saved. Review it, then choose when to open Cashfree.';
      await refresh(); schedulePoll();
    } catch (reason) { if (alive) { error = message(reason); notice = 'Order creation was not confirmed. Retry the same purchase or reload its status; do not create another payment.'; } }
    finally { if (alive) busy = false; }
  }
  async function resumeCheckout(): Promise<void> {
    if (!client || !order || busy || !confirmed) return;
    if (catalog?.phone_required) { const issue = phoneIssue(phone); if (issue) { error = issue; return; } }
    const paymentPhone = phone; phone = ''; busy = true; error = '';
    try { const value = await client.checkout(order.purchase_ref, paymentPhone); if (alive) { order = value; confirmed = false; await refresh(); } }
    catch (reason) { if (alive) error = message(reason); }
    finally { if (alive) busy = false; }
  }
  async function launch(): Promise<void> {
    if (!client || !order || order.status !== 'checkout_ready' || busy || !checkoutAvailable) return;
    stopPolling(); busy = true; error = ''; checkoutPending = true;
    checkoutAbort.abort(); checkoutAbort = new AbortController();
    const version = ++checkoutVersion, signal = checkoutAbort.signal;
    try {
      const current = await client.order(order.purchase_ref); if (!alive || version !== checkoutVersion) return; order = current;
      const { launchCheckout } = await import('./checkout');
      await launchCheckout(current, signal);
      if (alive && version === checkoutVersion) notice = 'Payment processing. Only a confirmed server status activates Premium.';
    } catch (reason) { if (alive && version === checkoutVersion) error = message(reason); }
    finally { if (alive && version === checkoutVersion) { checkoutPending = false; busy = false; polls = 0; void readOrder(true); } }
  }
  function leavePage(): void {
    phone = ''; checkoutAbort.abort();
    if (checkoutPending) {
      // A same-tab hosted checkout can leave an unresolved SDK promise in the
      // bfcache. Reopening this document must permit server verification.
      checkoutVersion++; checkoutPending = false; busy = false;
      notice = 'Checkout was interrupted or left this page. Check the saved purchase status before trying again.';
    }
  }
  function focus(): void { if (!loading && !busy && account && document.visibilityState === 'visible') { if (order) { polls = 0; void readOrder(true); } else void refresh().catch((reason) => { if (alive) error = message(reason); }); } }
  onMount(() => { void initialize(); });
  onDestroy(() => { alive = false; phone = ''; checkoutAbort.abort(); stopPolling(); client?.dispose(); identity.dispose(); });
</script>

<svelte:window on:focus={focus} on:pageshow={focus} on:pagehide={leavePage} />
<svelte:document on:visibilitychange={focus} />
<section class="premium-screen content-width" aria-labelledby="billing-title">
  <p class="eyebrow">Your private account</p><h1 id="billing-title">{title}</h1>
  <p class="intro">One-time purchases. No automatic renewal. Payment details and Premium status are never shown to conversation partners.</p>
  {#if loading}<p role="status">Loading your payment information…</p>
  {:else if !account}<section class="card"><h2>{session ? 'An account keeps your purchase safe' : 'Sign in to view your purchases'}</h2><p>Guests can use free conversations and accepted audio when enabled. Create an account before buying Premium; ordinary registration needs no phone or email.</p><div class="actions"><a class="primary" href="/login">Sign in</a><a href="/register">Create an account</a><a href="/chat">Continue without Premium</a></div></section>
  {:else}
    {#if entitlement}<section class="card balance" aria-labelledby="balance-title"><h2 id="balance-title">{entitlement.premium_active ? 'Premium active' : 'Free account'}</h2><p>{entitlement.premium_active ? duration(entitlement.remaining_seconds) + ' remaining at the last server update.' : 'Paid preferences are inactive. Your saved choices are preserved.'}</p>{#if entitlement.premium_active && entitlement.expires_at}<p>Current expiry: <strong>{when(entitlement.expires_at)}</strong></p>{/if}<p class="small">Time runs continuously, even offline. New purchases append duration. A refund affects only its own unused time unless a different treatment is explicitly approved.</p><div class="actions"><a href="/chat">Conversation and preferences</a><button disabled={busy} on:click={() => { void refresh().catch((reason) => { error = message(reason); }); }}>Refresh balance and orders</button></div></section>{/if}
    {#if catalog?.environment === 'sandbox'}<p class="notice"><strong>Test checkout.</strong> This environment does not accept real payments.</p>{/if}
    {#if unknown}<section class="card"><h2>Confirming your existing purchase</h2><p>No new purchase will be created by this retry. The same request reference is kept in memory until its outcome is known.</p>{#if catalog?.phone_required}<label for="retry-phone">Payment-only mobile number (enter again only if requested)<input id="retry-phone" type="tel" inputmode="numeric" autocomplete="off" bind:value={phone} maxlength="10" disabled={busy} /></label><p class="small">Cashfree may need the number again if order creation never reached it. NoTitle does not save it in your profile or browser storage.</p>{/if}<button class="primary" disabled={busy} on:click={() => prepare(true)}>Retry the same purchase</button></section>{/if}
    {#if order}<section class="card" aria-labelledby="order-title"><h2 id="order-title">{orderLabel(order.status)}</h2><p class="reference">Purchase reference: {order.purchase_ref}</p><p><strong>{order.plan.name} · {money(order.plan.amount_paise)}</strong> · {duration(order.plan.duration_seconds)}</p><p class="small">{order.plan.tax_treatment}. Total includes applicable tax; no automatic renewal. This order keeps the price and duration you confirmed.</p>
      {#if order.status === 'paid'}<p class="notice">The server has confirmed this payment. Your current usable time, including refunds or expiry, is shown in the account balance.</p>
      {:else if order.status === 'financial_review'}<p>Payment needs financial review. Do not pay again for this order. A browser or bank message alone does not confirm usable Premium.</p>
      {:else if order.status === 'expired'}<p>Checkout expired. A late payment is still reconciled against this reference; check with support if your bank shows a debit.</p>
      {:else}<p>Payment processing remains pending until the server confirms captured funds and commits access. Closing or returning from Cashfree is not confirmation.</p>{/if}
      <div class="actions">{#if order.status === 'checkout_ready' && checkoutAvailable}<button class="primary" disabled={busy} on:click={launch}>Continue to Cashfree</button>{/if}<button disabled={busy} on:click={() => { polls = 0; void readOrder(true); }}>Check payment status</button></div>
      {#if ['intent', 'processing'].includes(order.status) && checkoutAvailable}<details><summary>Resume this same checkout</summary><form on:submit|preventDefault={resumeCheckout}><p>If checkout was interrupted before the provider confirmed the order, enter the payment contact again. The server checks the same purchase before attempting checkout.</p>{#if catalog?.phone_required}<label for="resume-phone">Payment-only mobile number<input id="resume-phone" type="tel" inputmode="numeric" autocomplete="off" bind:value={phone} maxlength="10" pattern="[6-9][0-9]{9}" required disabled={busy} /></label><p class="small">Passed to Cashfree for this payment; never saved in your NoTitle profile or shown to peers. Cashfree or your bank may send payment messages. NoTitle sends no user email.</p>{/if}<label class="check"><input type="checkbox" bind:checked={confirmed} required disabled={busy} /><span>Resume only purchase {order.purchase_ref} for {money(order.plan.amount_paise)}.</span></label><button disabled={busy || !confirmed}>Resume existing order</button></form></details>{/if}
      {#if detailReceipt}<section aria-labelledby="selected-receipt-title"><h3 id="selected-receipt-title">Selected purchase receipt</h3><p>{when(detailReceipt.paid_at)} · {detailReceipt.plan.name}</p><p>Total captured: {money(detailReceipt.captured_paise)}. Confirmed refunds: {money(detailReceipt.refunded_paise)}.</p><p class="small">Plan duration: {duration(detailReceipt.plan.duration_seconds)}. Tax included in one plan purchase: {money(detailReceipt.plan.tax_paise)}. {detailReceipt.plan.tax_treatment}.</p><p class="reference">{detailReceipt.purchase_ref}</p></section>{/if}
      {#if refunds.length}<h3>Refund status</h3>{#each refunds as refund}<article class="refund"><strong>{money(refund.amount_paise)}</strong><p>{refundLabel(refund.status)}</p><p class="small">Reference: {refund.refund_ref}. {refundDuration(refund)}</p></article>{/each}{/if}
      <p class="small">For payment or refund help, keep this purchase reference and use <a href="/account/support">your protected account support cases</a>. <a href="/refund-policy">Refund eligibility and review</a>. No support request is submitted by this page.</p>
    </section>{/if}
    <section aria-labelledby="plans-title"><h2 id="plans-title">{entitlement?.premium_active ? 'Add more time' : 'Choose Premium'}</h2>
      {#if !checkoutAvailable || !catalog?.plans.length}<p class="notice">Premium checkout is currently closed. Existing payment records remain available.</p>
      {:else}<p>Gender preference is respected by both people. Professional choices are only a small tie-break. Preferences never guarantee a match or verify self-declared details.</p>{#if unresolved}<p class="notice">Resolve your pending purchase below before starting another one.</p>{/if}<div class="plans">{#each catalog?.plans ?? [] as plan}<article class="card"><h3>{plan.name}</h3><p class="price">{money(plan.amount_paise)}</p><p>{duration(plan.duration_seconds)} continuous access</p><p class="small">{plan.tax_treatment}. Total includes applicable tax. No automatic renewal.</p><button disabled={!canChoose} on:click={() => choose(plan)}>Choose {plan.name}</button></article>{/each}</div>{/if}
    </section>
    {#if selected}<form class="card" on:submit|preventDefault={() => prepare()} aria-busy={busy}><h2>Review {selected.name}</h2><p><strong>Total: {money(selected.amount_paise)}</strong> for {duration(selected.duration_seconds)}. {selected.tax_treatment}. No extra NoTitle charge. No automatic renewal.</p><p>Time begins when the server activates access, or appends to your existing balance. Narrower gender choices can mean a longer wait or no match.</p>{#if catalog?.phone_required}<label for="payment-phone">Payment-only mobile number<input id="payment-phone" type="tel" inputmode="numeric" autocomplete="off" bind:value={phone} maxlength="10" pattern="[6-9][0-9]{9}" required disabled={busy} /></label><p class="small">Cashfree requires your genuine mobile number for payment. It is passed to Cashfree, never stored in your NoTitle profile or shown to peers. No email is requested. Cashfree or your bank may send payment messages; NoTitle sends no user email.</p>{/if}<label class="check"><input type="checkbox" required bind:checked={confirmed} disabled={busy} /><span>I confirm the total, duration and <a href="/refund-policy" target="_blank" rel="noopener">refund policy (new tab)</a>.</span></label><button class="primary" disabled={busy || !confirmed}>Create this order</button></form>{/if}
    <section class="card" aria-labelledby="purchases-title"><h2 id="purchases-title">Your recent purchases</h2>{#if !orders.length}<p>No purchases were found for this account.</p>{:else}<ul class="records">{#each orders as item}<li><div><strong>{item.plan.name} · {money(item.plan.amount_paise)}</strong><p>{orderLabel(item.status)} · {when(item.created_at)}</p><p class="reference">{item.purchase_ref}</p></div><button disabled={busy} on:click={() => viewOrder(item)}>View purchase</button></li>{/each}</ul>{/if}</section>
    <form class="card" on:submit|preventDefault={lookup} aria-busy={busy}><h2>Find an older purchase</h2><p>The lists show your latest 100 records. Enter a saved purchase reference to view an older order, its receipt and refund status.</p><label for="purchase-lookup">Purchase reference<input id="purchase-lookup" type="text" bind:value={lookupRef} autocomplete="off" autocapitalize="none" spellcheck="false" minlength="16" maxlength="128" required disabled={busy} /></label><button disabled={busy}>Find purchase and receipt</button></form>
    <section class="card" aria-labelledby="receipts-title"><h2 id="receipts-title">Payment receipts</h2><p class="small">These account records confirm payments and refunds. Any required tax invoice follows the operator’s reviewed invoicing process.</p>{#if !receipts.length}<p>No confirmed-payment receipts are available yet.</p>{:else}<ul class="records">{#each receipts as receipt}<li><div><strong>{receipt.plan.name} · {money(receipt.plan.amount_paise)}</strong><p>{when(receipt.paid_at)} · {duration(receipt.plan.duration_seconds)}</p><p class="reference">{receipt.purchase_ref}</p><p class="small">Total captured: {money(receipt.captured_paise)}. Tax included in one plan purchase: {money(receipt.plan.tax_paise)}. {receipt.plan.tax_treatment}. Confirmed refunds: {money(receipt.refunded_paise)}.</p></div></li>{/each}</ul>{/if}</section>
  {/if}
  {#if notice}<p role="status" class="notice">{notice}</p>{/if}{#if error}<p role="alert" class="error">{error}</p>{/if}
  <nav class="actions" aria-label="Account navigation"><a href="/account/premium">Premium and receipts</a><a href="/settings">Settings</a><a href="/chat">Conversation space</a></nav>
</section>

<style>
  .premium-screen { display: grid; gap: 1.5rem; padding-block: 2rem 4rem; max-width: 70rem; } h1 { font-size: clamp(2rem,6vw,3rem); margin: 0; letter-spacing: -0.035em; } h2 { margin: 0 0 0.75rem; font-size: 1.3rem; } h3 { margin: 0; font-size: 1.1rem; } p { margin: 0; color: var(--text-secondary); overflow-wrap: anywhere; } .intro { max-width: 48rem; } .card, form { display: grid; gap: 0.85rem; min-width: 0; } .card { padding: clamp(1rem,3vw,1.5rem); } .balance { border-color: var(--accent); } .small, .reference { font-size: 0.85rem; } .reference { overflow-wrap: anywhere; font-family: ui-monospace, monospace; } .price { font-size: 1.75rem; font-weight: 750; color: var(--text-primary); } .plans { display: grid; gap: 1rem; grid-template-columns: repeat(auto-fit,minmax(min(100%,14rem),1fr)); margin-top: 1rem; } .actions { display: flex; gap: 0.75rem; flex-wrap: wrap; align-items: center; } button, .actions a, summary { min-height: 2.75rem; min-width: 2.75rem; display: inline-flex; align-items: center; padding: 0.65rem 0.8rem; } button { border: 1px solid var(--border-strong); border-radius: var(--radius-md); background: var(--surface); color: var(--text-primary); font: inherit; font-weight: 650; cursor: pointer; } button.primary, a.primary { background: var(--accent); color: white; border-color: var(--accent); border-radius: var(--radius-md); } button:disabled { opacity: 0.55; cursor: not-allowed; } label { display: grid; gap: 0.4rem; font-weight: 650; } input[type='tel'], input[type='text'] { width: 100%; min-width: 0; min-height: 3rem; padding: 0.75rem; font: inherit; color: var(--text-primary); background: var(--background); border: 1px solid var(--border-strong); border-radius: var(--radius-md); } .check { display: flex; align-items: start; min-height: 2.75rem; padding-block: 0.5rem; gap: 0.65rem; font-weight: 400; } .check input { flex-shrink: 0; width: 1.15rem; height: 1.15rem; margin-top: 0.25rem; } .records { list-style: none; margin: 0; padding: 0; } .records li { display: flex; gap: 1rem; justify-content: space-between; align-items: start; flex-wrap: wrap; padding-block: 1rem; border-bottom: 1px solid var(--border); } .records li > div { flex: 1 1 14rem; min-width: 0; display: grid; gap: 0.4rem; } summary { cursor: pointer; font-weight: 650; } details form { margin-block: 1rem; } .refund { border-left: 3px solid var(--accent); padding-left: 1rem; display: grid; gap: 0.4rem; } .error { border: 1px solid var(--danger); border-radius: var(--radius-md); padding: 1rem; }
</style>
