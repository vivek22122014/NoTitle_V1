import type { Order } from './model.ts';
const source = 'https://sdk.cashfree.com/js/v3/cashfree.js';
type SDK = (options: { mode: 'sandbox' | 'production' }) => { checkout(options: { paymentSessionId: string; redirectTarget: '_self' }): Promise<unknown> };
declare global { interface Window { Cashfree?: SDK } }
let loading: Promise<SDK> | null = null;
/** Called only by the explicit Continue to Cashfree action. No SDK success grants access. */
async function sdk(): Promise<SDK> {
  if (window.Cashfree) return window.Cashfree;
  if (!loading) loading = new Promise<SDK>((resolve, reject) => {
    const script = document.createElement('script'); script.src = source; script.async = true; script.referrerPolicy = 'no-referrer';
    const timer = window.setTimeout(() => { script.remove(); loading = null; reject(new Error('The payment page could not load. Your existing order is preserved.')); }, 15000);
    script.onload = () => { window.clearTimeout(timer); if (window.Cashfree) resolve(window.Cashfree); else { loading = null; reject(new Error('The payment page could not load.')); } };
    script.onerror = () => { window.clearTimeout(timer); script.remove(); loading = null; reject(new Error('The payment page could not load. Your existing order is preserved.')); };
    document.head.append(script);
  });
  return loading;
}
export async function launchCheckout(order: Order, signal?: AbortSignal): Promise<void> {
  if (order.status !== 'checkout_ready' || !order.payment_session_id || !['sandbox', 'production'].includes(order.environment)) throw new Error('Check this order before opening checkout.');
  if (signal?.aborted) throw new Error('Checkout was cancelled before opening the payment page.');
  const factory = await sdk();
  if (signal?.aborted) throw new Error('Checkout was cancelled before opening the payment page.');
  await factory({ mode: order.environment }).checkout({ paymentSessionId: order.payment_session_id, redirectTarget: '_self' });
  // The browser result is deliberately ignored; only the authenticated server
  // status and committed ledger can describe payment/entitlement success.
}
