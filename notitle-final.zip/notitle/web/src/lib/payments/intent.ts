import type { Plan, Order } from './model.ts';
/** Memory-only, one unresolved intent. An uncertain response never creates a new key. */
export class PurchaseIntent {
  private key = '';
  private plan: { id: string; version: number } | null = null;
  private order: Order | null = null;
  private random: () => string;
  constructor(random: () => string = () => crypto.randomUUID()) { this.random = random; }
  get pending(): boolean { return !!this.key && !this.order || !!this.order && !['paid', 'expired'].includes(this.order.status); }
  get reference(): string | null { return this.order?.purchase_ref ?? null; }
  select(plan: Plan): { plan_id: string; plan_version: number; idempotency_key: string } {
    if (this.key && this.plan && (this.plan.id !== plan.id || this.plan.version !== plan.version)) throw new Error('Resolve the existing purchase before choosing a different plan.');
    if (!this.key) { this.key = this.random(); this.plan = { id: plan.id, version: plan.version }; }
    return this.request();
  }
  request(): { plan_id: string; plan_version: number; idempotency_key: string } {
    if (!this.key || !this.plan) throw new Error('Choose a plan first.');
    return { plan_id: this.plan.id, plan_version: this.plan.version, idempotency_key: this.key };
  }
  confirm(order: Order): void {
    if (this.plan && (order.plan.id !== this.plan.id || order.plan.version !== this.plan.version)) throw new Error('The returned order does not match this purchase.');
    if (this.order && this.order.purchase_ref !== order.purchase_ref) throw new Error('The purchase reference changed unexpectedly.');
    this.order = order;
  }
  newPurchase(): void {
    if (this.pending) throw new Error('The previous purchase is unresolved. Check its status first.');
    this.clear();
  }
  clear(): void { this.key = ''; this.plan = null; this.order = null; }
}
let owner = '';
let current = new PurchaseIntent();
export function intentFor(privateUsername: string): PurchaseIntent {
  if (owner !== privateUsername) { current.clear(); current = new PurchaseIntent(); owner = privateUsername; }
  return current;
}
export function clearPurchaseIntent(): void { current.clear(); owner = ''; }
