/** Owner-only projections. Never retain provider/customer records or card data. */
export interface Plan { id: string; version: number; name: string; amount_paise: number; currency: 'INR'; duration_seconds: number; tax_treatment: string; tax_paise: number; enabled: boolean }
export interface Catalog { plans: Plan[]; checkout_enabled: boolean; environment: 'sandbox' | 'production'; catalog_version: string; phone_required: boolean }
export interface Entitlement { premium_active: boolean; expires_at?: string; remaining_seconds: number; version: number }
export type OrderStatus = 'intent' | 'checkout_ready' | 'processing' | 'paid' | 'financial_review' | 'expired';
export interface Order { purchase_ref: string; status: OrderStatus; plan: Plan; created_at: string; paid_at?: string; payment_session_id?: string; environment: 'sandbox' | 'production' }
export interface Receipt { purchase_ref: string; plan: Plan; paid_at: string; status: string; captured_paise: number; refunded_paise: number }
export interface Refund { refund_ref: string; purchase_ref: string; amount_paise: number; treatment: string; held_seconds: number; status: string; created_at: string; processed_at?: string }
const record = (value: unknown): value is Record<string, unknown> => !!value && typeof value === 'object' && !Array.isArray(value);
const text = (value: unknown, limit = 160): value is string => typeof value === 'string' && value.length > 0 && value.length <= limit && !/[\u0000-\u001f\u007f]/u.test(value);
const integer = (value: unknown, min = 0): value is number => Number.isSafeInteger(value) && Number(value) >= min;
const date = (value: unknown): value is string => text(value, 64) && Number.isFinite(Date.parse(value));
export const purchaseRef = (value: unknown): value is string => typeof value === 'string' && /^[A-Za-z0-9_-]{16,128}$/u.test(value);
function invalid(): never { throw new Error('Payment information could not be verified. Refresh your account.'); }
export function parsePlan(value: unknown): Plan {
  if (!record(value) || !text(value.id, 48) || !integer(value.version, 1) || !text(value.name, 80) || !integer(value.amount_paise, 1) || value.currency !== 'INR' || !integer(value.duration_seconds, 1) || !text(value.tax_treatment, 1000) || !integer(value.tax_paise) || value.tax_paise > value.amount_paise || typeof value.enabled !== 'boolean') invalid();
  return { id: value.id, version: value.version, name: value.name, amount_paise: value.amount_paise, currency: 'INR', duration_seconds: value.duration_seconds, tax_treatment: value.tax_treatment, tax_paise: value.tax_paise, enabled: value.enabled };
}
export function parseCatalog(value: unknown): Catalog {
  if (!record(value) || !Array.isArray(value.plans) || value.plans.length > 4 || typeof value.checkout_enabled !== 'boolean' || !['sandbox', 'production'].includes(String(value.environment)) || !text(value.catalog_version, 128) || typeof value.phone_required !== 'boolean') invalid();
  const plans = value.plans.map(parsePlan);
  if (new Set(plans.map((plan) => plan.id)).size !== plans.length || plans.some((plan) => !plan.enabled)) invalid();
  return { plans, checkout_enabled: value.checkout_enabled, environment: value.environment as Catalog['environment'], catalog_version: value.catalog_version, phone_required: value.phone_required };
}
export function parseEntitlement(value: unknown): Entitlement {
  if (!record(value) || typeof value.premium_active !== 'boolean' || !integer(value.remaining_seconds) || !integer(value.version) || (value.expires_at !== undefined && !date(value.expires_at)) || (value.premium_active && (!date(value.expires_at) || value.remaining_seconds <= 0))) invalid();
  return { premium_active: value.premium_active, remaining_seconds: value.remaining_seconds, version: value.version, ...(date(value.expires_at) ? { expires_at: value.expires_at } : {}) };
}
export function parseOrder(value: unknown): Order {
  if (!record(value) || !purchaseRef(value.purchase_ref) || !['intent', 'checkout_ready', 'processing', 'paid', 'financial_review', 'expired'].includes(String(value.status)) || !date(value.created_at) || !['sandbox', 'production'].includes(String(value.environment)) || (value.paid_at !== undefined && !date(value.paid_at)) || (value.payment_session_id !== undefined && !text(value.payment_session_id, 2048))) invalid();
  return { purchase_ref: value.purchase_ref, status: value.status as OrderStatus, plan: parsePlan(value.plan), created_at: value.created_at, environment: value.environment as Order['environment'], ...(date(value.paid_at) ? { paid_at: value.paid_at } : {}), ...(text(value.payment_session_id, 2048) ? { payment_session_id: value.payment_session_id } : {}) };
}
export function parseOrders(value: unknown): Order[] {
  if (!record(value) || !Array.isArray(value.orders) || value.orders.length > 100) invalid();
  return value.orders.map(parseOrder);
}
export function parseReceipt(item: unknown): Receipt {
  if (!record(item) || !purchaseRef(item.purchase_ref) || !date(item.paid_at) || !text(item.status, 64) || !integer(item.captured_paise, 1) || !integer(item.refunded_paise) || item.refunded_paise > item.captured_paise) invalid();
  const plan = parsePlan(item.plan);
  return { purchase_ref: item.purchase_ref, plan, paid_at: item.paid_at, status: item.status, captured_paise: item.captured_paise, refunded_paise: item.refunded_paise };
}
export function parseReceipts(value: unknown): Receipt[] {
  if (!record(value) || !Array.isArray(value.receipts) || value.receipts.length > 100) invalid();
  return value.receipts.map(parseReceipt);
}
export function parseRefunds(value: unknown): Refund[] {
  if (!record(value) || !Array.isArray(value.refunds) || value.refunds.length > 100) invalid();
  return value.refunds.map((item: unknown) => {
    if (!record(item) || !purchaseRef(item.refund_ref) || !purchaseRef(item.purchase_ref) || !integer(item.amount_paise, 1) || !integer(item.held_seconds) || !text(item.treatment, 64) || !text(item.status, 64) || !date(item.created_at) || (item.processed_at !== undefined && !date(item.processed_at))) invalid();
    return { refund_ref: item.refund_ref, purchase_ref: item.purchase_ref, amount_paise: item.amount_paise, treatment: item.treatment, held_seconds: item.held_seconds, status: item.status, created_at: item.created_at, ...(date(item.processed_at) ? { processed_at: item.processed_at } : {}) };
  });
}
export const money = (paise: number): string => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(paise / 100);
export function duration(seconds: number): string {
  const hours = Math.floor(seconds / 3600), minutes = Math.floor((seconds % 3600) / 60);
  return hours ? `${hours.toLocaleString('en-IN')} hours${minutes ? ` ${minutes} minutes` : ''}` : minutes ? `${minutes} minutes` : `${Math.max(0, Math.floor(seconds))} seconds`;
}
export const pendingOrder = (order: Order): boolean => ['intent', 'checkout_ready', 'processing', 'financial_review'].includes(order.status);
export const orderLabel = (status: OrderStatus): string => ({ intent: 'Order confirmation pending', checkout_ready: 'Ready for checkout', processing: 'Payment processing', paid: 'Payment confirmed', financial_review: 'Financial review pending', expired: 'Checkout expired' })[status];
export function refundLabel(status: string): string {
  if (['processed', 'success'].includes(status.toLowerCase())) return 'Provider processed — bank credit may take longer';
  if (['failed', 'cancelled'].includes(status.toLowerCase())) return 'Refund failed — any held unused time is restored on confirmation';
  return 'Refund initiated or under review — bank credit is not confirmed';
}
export function refundDuration(refund: Refund): string {
  if (!refund.held_seconds) return 'No unused duration was held for this refund.';
  if (['processed', 'success'].includes(refund.status.toLowerCase())) return 'Historical hold: ' + duration(refund.held_seconds) + '. Your current balance reflects the confirmed refund.';
  if (['failed', 'cancelled'].includes(refund.status.toLowerCase())) return duration(refund.held_seconds) + ' of held unused time restored on the server resolution.';
  return duration(refund.held_seconds) + ' held from this purchase while the refund remains unresolved.';
}
export function phoneIssue(value: string): string | null { return /^[6-9]\d{9}$/u.test(value) ? null : 'Enter your genuine 10-digit Indian mobile number for the payment provider.'; }
