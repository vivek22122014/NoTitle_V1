<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import { SupportClient } from './client';
  const client = new SupportClient(); let state: 'checking' | 'available' | 'unavailable' = 'checking'; let alive = true;
  onMount(() => { void client.availability().then((available) => { if (alive) state = available ? 'available' : 'unavailable'; }).catch(() => { if (alive) state = 'unavailable'; }); });
  onDestroy(() => { alive = false; client.dispose(); });
</script>
<div class="support-availability">
  {#if state === 'available'}<p><strong>Protected support submissions are available.</strong> Submit a concern without an account or email, save its private access codes and return for replies. This is not live support chat or an emergency service.</p><p><a href="/support">Raise a concern</a> · <a href="/support/case">Open a saved case</a> · <a href="/account/support">Your account cases</a></p>
  {:else if state === 'checking'}<p>Support availability must be checked with the service. <a href="/support">Open the support page</a> to check or use your saved case codes. A page preview does not confirm submission.</p>
  {:else}<p><strong>Support submissions are currently unavailable.</strong> No concern is submitted by reading this page. Check the published operator contacts below and <a href="/support">check support availability</a> again. Existing cases may remain accessible through <a href="/support/case">saved case codes</a>.</p>{/if}
</div>
