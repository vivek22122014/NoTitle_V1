<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import Alert from '$lib/components/Alert.svelte';
  import { IdentityClient } from '$lib/identity/client';
  import { ApiError } from '$lib/api/client';
  import { SupportClient } from './client';
  import { PendingSubmission, downloadPrivate, randomToken, receiptText, submissionIssue, messageIssue } from './model';
  import type { CaseDetail, Credential, Kind, Category, Submission, Summary } from './model';
  import './support.css';
  export let accountMode = false;
  export let statusMode = false;
  const client = new SupportClient(); const identity = new IdentityClient(); const intent = new PendingSubmission();
  let alive = true; let loading = true; let available = false; let account = false; let busy = false; let error = ''; let notice = '';
  let kind: Kind = 'grievance'; let category: Category = 'general'; let subject = ''; let message = '';
  let prepared: Submission | null = null; let saved = false; let sent = false;
  let credential: Credential = { case_ref: '', status_secret: '' }; let caseRef = ''; let statusSecret = '';
  let current: CaseDetail | null = null; let cases: Summary[] = []; let reply = ''; let appeal = false;
  let pendingReply: { submission_id: string; message: string; appeal: boolean } | null = null;
  const time = (value: string) => new Date(value).toLocaleString();
  function fail(cause: unknown) { if (accountMode && cause instanceof ApiError && cause.status === 401) { current = null; cases = []; account = false; } error = cause instanceof ApiError ? cause.message : 'The request could not be completed safely. Retry with the same saved codes.'; }
  async function initialize() {
    loading = true; error = '';
    try { await client.bootstrap(); available = await client.availability(); if (accountMode) { const session = await identity.current(); account = session?.identity.kind === 'account'; if (account) cases = await client.cases(); } }
    catch (cause) { if (alive) fail(cause); } finally { if (alive) loading = false; }
  }
  function prepare() { error = ''; const issue = submissionIssue({ subject, message }); if (issue) { error = issue; return; } try { prepared = intent.select({ kind, category, subject, message }); credential = { case_ref: prepared.submission_id, status_secret: prepared.status_secret }; saved = false; } catch (cause) { fail(cause); } }
  async function send() {
    if (!prepared || !saved || busy) return; busy = true; error = ''; notice = '';
    try { const receipt = await client.submit(intent.request(), accountMode); if (!alive) return; credential = { case_ref: receipt.case.case_ref, status_secret: receipt.status_secret }; caseRef = credential.case_ref; statusSecret = credential.status_secret; sent = true; notice = 'Your case is saved. The received time is recorded; a human response is still pending.'; if (accountMode) cases = await client.cases(); current = accountMode ? await client.accountCase(caseRef) : await client.access(credential); }
    catch (cause) { if (alive) fail(cause); } finally { if (alive) busy = false; }
  }
  async function openCase(ref?: string) {
    if (busy) return; if (pendingReply) { error = 'Retry the unresolved reply before opening or refreshing a case.'; return; } busy = true; error = ''; notice = ''; current = null; reply = '';
    try { const result = accountMode ? await client.accountCase(ref ?? caseRef.trim()) : await client.access({ case_ref: caseRef.trim(), status_secret: statusSecret.trim() }); if (!alive) return; current = result; if (!accountMode) credential = { case_ref: result.case_ref, status_secret: statusSecret.trim() }; }
    catch (cause) { if (alive) fail(cause); } finally { if (alive) busy = false; }
  }
  async function sendReply() {
    if (!current || busy) return; if (current.state === 'resolved' && !appeal) { error = 'This case is resolved. Select appeal to ask for a review.'; return; } const issue = messageIssue(reply); if (issue) { error = issue; return; }
    if (pendingReply && (pendingReply.message !== reply || pendingReply.appeal !== appeal)) { error = 'Retry the original reply before editing it.'; return; }
    pendingReply ??= { submission_id: randomToken(), message: reply, appeal }; busy = true; error = '';
    try { const input = { case_ref: current.case_ref, ...pendingReply }; const result = accountMode ? await client.accountReply(input) : await client.reply({ ...input, status_secret: credential.status_secret }); if (!alive) return; current = result; reply = ''; appeal = false; pendingReply = null; notice = 'Your reply is saved. Return here for the response.'; }
    catch (cause) { if (alive) fail(cause); } finally { if (alive) busy = false; }
  }
  function forget() { current = null; caseRef = ''; statusSecret = ''; credential = { case_ref: '', status_secret: '' }; reply = ''; pendingReply = null; notice = 'Private case details cleared from this screen.'; }
  function nextCase() { if (!sent) return; intent.clear(); prepared = null; sent = false; saved = false; subject = ''; message = ''; forget(); }
  function leave() { forget(); intent.clear(); prepared = null; sent = false; saved = false; subject = ''; message = ''; }
  onMount(() => { void initialize(); });
  onDestroy(() => { alive = false; client.dispose(); identity.dispose(); intent.clear(); prepared = null; credential = { case_ref: '', status_secret: '' }; statusSecret = ''; current = null; message = ''; reply = ''; pendingReply = null; });
</script>

<svelte:window on:pagehide={leave} />
<section class="support-page content-width" aria-labelledby="support-title">
  <header><p class="eyebrow">NoTitle · Help and rights</p><h1 id="support-title">{accountMode ? 'Your support cases' : statusMode ? 'Open a protected case' : 'Support and privacy requests'}</h1><p>No purchase or email address is required. Replies appear in your protected case.</p></header>
  <div class="support-layout"><div class="support-stack">
    {#if error}<Alert variant="danger" title="Not confirmed">{error}</Alert>{/if}
    {#if notice}<Alert>{notice}</Alert>{/if}
    {#if loading}<p role="status">Checking support availability…</p>
    {:else if !available && !statusMode && !accountMode}<section class="support-panel"><h2>Support submissions are unavailable</h2><p>No complaint has been submitted. Review the <a href="/contact">published operator contacts</a> and <a href="/grievance">grievance information</a>. This application does not offer emergency assistance.</p><button on:click={initialize}>Check availability again</button></section>
    {:else if accountMode && !account}<section class="support-panel"><h2>Sign in for your account cases</h2><p>You can still raise a concern or open a saved case without an account.</p><div class="actions"><a class="action" href="/login">Sign in</a><a class="action" href="/support">Public support form</a><a class="action" href="/support/case">Use saved case codes</a></div></section>
    {:else}
      {#if !available}<Alert variant="warning">New support requests are unavailable. You can still try your saved case codes or account cases; existing access depends on service and retention availability.</Alert>{/if}
      {#if accountMode}
        <section class="support-panel"><h2>Cases linked to this account</h2>{#if cases.length === 0}<p>No linked cases were returned. Cases submitted through the public form use their saved codes.</p>{/if}{#each cases as item}<button disabled={busy} on:click={() => openCase(item.case_ref)}>{item.kind} · {item.state} · {time(item.received_at)}</button>{/each}<p class="help">The most recent cases appear here. Use an older reference below if needed.</p></section>
      {/if}
      {#if statusMode || accountMode}
        <form class="support-panel" on:submit|preventDefault={() => openCase()} aria-busy={busy}><h2>{accountMode ? 'Find an account case' : 'Enter your saved case codes'}</h2><label for="case-reference">Case reference or original submission reference<input id="case-reference" bind:value={caseRef} autocomplete="off" autocapitalize="none" spellcheck="false" maxlength={128} required disabled={busy} /></label>{#if !accountMode}<label for="case-secret">Private status secret<input id="case-secret" type="password" bind:value={statusSecret} autocomplete="off" autocapitalize="none" spellcheck="false" maxlength={43} required disabled={busy} /></label><p class="help">The reference alone cannot open a case. Codes are not put in the address bar or browser storage. Losing a guest session does not invalidate saved case codes. Case access lasts only while the case is retained under the reviewed retention schedule.</p>{/if}<button type="submit" disabled={busy}>Open case</button></form>
      {/if}
      {#if available && !statusMode && !prepared}
        <form class="support-panel" on:submit|preventDefault={prepare}><h2>Raise a concern</h2><p>{accountMode ? 'This case will be linked to your signed-in account.' : 'This public submission uses its own private codes. It will not be linked to your account, even if you are signed in.'}</p><label for="case-kind">Request type<select id="case-kind" bind:value={kind}><option value="grievance">Complaint or grievance</option><option value="appeal">Appeal a decision</option><option value="access">Privacy access request</option><option value="correction">Correction request</option><option value="deletion">Deletion enquiry</option><option value="receipt">Payment or closed-account receipt request</option></select></label><label for="case-category">Issue category<select id="case-category" bind:value={category}><option value="general">General concern</option><option value="removal">Content removal concern</option><option value="intimate">Intimate content or impersonation concern</option><option value="court_order">Court or government direction</option></select></label><p class="help">Describe the concern accurately. An operator reviews its legal category and urgency; selecting a category does not establish a valid legal direction.</p><label for="case-subject">Subject (1–160 characters)<input id="case-subject" bind:value={subject} maxlength={320} required /></label><label for="case-description">Description (5–4,000 characters)<textarea id="case-description" bind:value={message} rows="7" maxlength={8000} required /></label><p class="help">Include relevant case or purchase references. Do not send passwords, recovery codes, full card details or government identity documents. A case receipt or payment screenshot does not prove account ownership.</p>{#if kind === 'deletion'}<p>To disable your signed-in account immediately, use <a href="/settings">Settings and deletion</a>. This enquiry does not itself disable access.</p>{/if}<button type="submit">Prepare private case codes</button></form>
      {/if}
      {#if prepared}
        <section class="support-panel" aria-labelledby="save-case"><h2 id="save-case">{sent ? 'Save your case access' : 'Save your codes before sending'}</h2><p>Anyone with both codes can read and reply to this case. Save them securely. They are not saved in this browser. The original submission reference also works if a response is lost.</p><label for="saved-case-reference">{sent ? 'Case reference' : 'Original submission reference'}<input id="saved-case-reference" class="secret-code" readonly value={credential.case_ref} autocomplete="off" spellcheck="false" /></label><label for="saved-case-secret">Private status secret<textarea id="saved-case-secret" class="secret-code" readonly value={credential.status_secret} rows="2" autocomplete="off" spellcheck="false" /></label><button on:click={() => downloadPrivate('notitle-private-case-access.txt', receiptText(credential))}>Download private access file</button><p class="help">This creates a sensitive plain-text file on your device. Keep it out of shared folders and delete it when no longer needed.</p>{#if !sent}<label class="check"><input type="checkbox" bind:checked={saved} disabled={busy} /><span>I have saved both codes securely.</span></label><button type="submit" disabled={!saved || busy} on:click={send}>{busy ? 'Sending…' : 'Submit prepared request'}</button><p class="help">If confirmation is lost, retry this same prepared request or check its saved codes. Until a saved case is returned, submission is not confirmed.</p>{:else}<button disabled={busy} on:click={nextCase}>Clear this form and start another case</button>{/if}</section>
      {/if}
      {#if current}
        <section class="support-panel" aria-labelledby="case-title"><h2 id="case-title">{current.subject}</h2><dl><div><dt>Case reference</dt><dd>{current.case_ref}</dd></div><div><dt>Status</dt><dd>{current.state.replaceAll('_', ' ')}</dd></div><div><dt>Received</dt><dd>{time(current.received_at)}</dd></div><div><dt>Human acknowledgement</dt><dd>{current.acknowledged_at ? time(current.acknowledged_at) : 'Pending — due ' + time(current.acknowledge_due)}</dd></div><div><dt>Current resolution deadline</dt><dd>{time(current.resolution_due)}</dd></div></dl><p class="help">Deadlines follow the assigned policy and legal trigger. A stored receipt is not a human resolution. Return here to check updates; no outgoing application email is sent.</p>{#each current.messages as item}<article class="message"><p class="help">{item.author === 'operator' ? 'Support response' : 'Submitted message'} · {time(item.created_at)}{item.appeal ? ' · Appeal' : ''}</p><p>{item.text}</p></article>{/each}<form class="support-stack" on:submit|preventDefault={sendReply} aria-busy={busy}><label for="case-reply">Reply or appeal (5–4,000 characters)<textarea id="case-reply" bind:value={reply} rows="5" maxlength={8000} required disabled={busy || pendingReply !== null} /></label>{#if current.state === 'resolved'}<p>This case is resolved. Select appeal if you want its decision reviewed.</p>{/if}<label class="check"><input type="checkbox" bind:checked={appeal} disabled={busy || pendingReply !== null} /><span>Ask for review of a decision (appeal).</span></label><button type="submit" disabled={busy || (current.state === 'resolved' && !appeal)}>{pendingReply ? 'Retry the same reply' : 'Send reply'}</button></form><div class="actions"><button disabled={busy} on:click={() => openCase(current?.case_ref)}>Refresh case</button><button disabled={busy} on:click={forget}>Clear private details</button></div></section>
      {/if}
    {/if}
  </div><aside class="support-stack"><nav class="support-panel" aria-label="Support navigation"><h2>Help and rights</h2><a href="/support">Raise a concern</a><a href="/support/case">Open saved case</a><a href="/account/support">Your account cases</a><a href="/account/privacy">Privacy controls and export</a><a href="/grievance">Grievance process</a><a href="/settings">Settings and deletion</a></nav><section class="support-panel"><h2>Available evidence has limits</h2><p>Ordinary conversations have no saved chat history, and audio is not recorded. A complaint may contain your statement and references without a transcript. Support cannot replay unrecorded audio or recover expired ordinary text.</p><p>Use in-conversation Report to submit the available server-held evidence. This form does not accept an uploaded transcript as verified conversation evidence.</p><p>NoTitle is not an emergency service. If someone is in immediate danger, seek appropriate local emergency assistance.</p></section></aside></div>
</section>
