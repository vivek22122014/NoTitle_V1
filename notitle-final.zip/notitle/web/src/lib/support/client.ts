import { apiFetch, ApiError } from '../api/client.ts';
import { parseAvailability, parseCase, parseCases, parseNotice, parseReceipt, reference, secret } from './model.ts';
import type { Credential, Submission } from './model.ts';
export class SupportClient {
  private abort = new AbortController();
  private csrf = '';
  setCSRF(value: string): void { this.csrf = value; }
  async bootstrap(): Promise<void> { const result = await apiFetch<{ csrf_token: string }>('/api/v1/support/bootstrap', { signal: this.abort.signal }); if (typeof result.csrf_token !== 'string' || !result.csrf_token) throw new Error('Security check unavailable'); this.csrf = result.csrf_token; }
  availability() { return apiFetch('/api/v1/support/status', { signal: this.abort.signal }).then(parseAvailability); }
  private write(path: string, body: unknown) { if (!this.csrf) throw new ApiError('Reload the security check before continuing.', 0, 'csrf_required'); return apiFetch(path, { method: 'POST', signal: this.abort.signal, headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': this.csrf }, body: JSON.stringify(body) }); }
  submit(input: Submission, account = false) { return this.write(account ? '/api/v1/me/support/cases' : '/api/v1/support/cases', input).then((value) => { const receipt = parseReceipt(value); if (receipt.status_secret !== input.status_secret) throw new Error('The returned private code did not match the saved request.'); return receipt; }); }
  access(credential: Credential) { const checked = { case_ref: reference(credential.case_ref), status_secret: secret(credential.status_secret) }; return this.write('/api/v1/support/case/access', checked).then(parseCase); }
  reply(input: Credential & { submission_id: string; message: string; appeal: boolean }) { reference(input.case_ref); secret(input.status_secret); return this.write('/api/v1/support/case/reply', input).then(parseCase); }
  cases() { return apiFetch('/api/v1/me/support/cases', { signal: this.abort.signal }).then(parseCases); }
  accountCase(ref: string) { return this.write('/api/v1/me/support/case/access', { case_ref: reference(ref) }).then(parseCase); }
  accountReply(input: { case_ref: string; submission_id: string; message: string; appeal: boolean }) { reference(input.case_ref); return this.write('/api/v1/me/support/case/reply', input).then(parseCase); }
  notice() { return this.write('/api/v1/notices/current', {}).then(parseNotice); }
  acknowledge(version: string) { return this.write('/api/v1/notices/ack', { version }); }
  dispose(): void { this.csrf = ''; this.abort.abort(); }
}
