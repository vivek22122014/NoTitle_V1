<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import { SupportClient } from './client';
  import type { Notice } from './model';
  export let account = false;
  const client = new SupportClient(); let notice: Notice | null = null; let busy = false; let error = ''; let alive = true; let timer: ReturnType<typeof setInterval> | null = null;
  async function load() { try { await client.bootstrap(); const result = await client.notice(); if (alive) notice = result?.acknowledged_at ? null : result; } catch { /* Disabled service does not invent an approved notice. */ } }
  async function acknowledge() { if (!notice || busy) return; busy = true; error = ''; try { if (account) await client.acknowledge(notice.version); if (alive) notice = null; } catch { if (alive) error = 'Acknowledgement was not saved. Please try again.'; } finally { if (alive) busy = false; } }
  onMount(() => { void load(); if (account) timer = setInterval(() => { void load(); }, 60 * 60_000); }); onDestroy(() => { alive = false; if (timer) clearInterval(timer); client.dispose(); notice = null; });
</script>
{#if notice}<section class="rules-notice" aria-labelledby="rules-reminder"><h2 id="rules-reminder">Community rules reminder</h2><p>{notice.text}</p><p class="meta">Version {notice.version} · {account ? 'Delivered to your account. Next reminder due by ' + new Date(notice.next_due).toLocaleString() + '.' : 'This reminder and your dismissal remain temporary; no guest account is created to track them.'}</p><div><a href="/community-guidelines">Read Community Guidelines</a><a href="/grievance">Decision and appeal process</a></div>{#if error}<p role="alert">{error}</p>{/if}<button disabled={busy} on:click={acknowledge}>{busy ? 'Saving…' : 'I have read this reminder'}</button></section>{/if}
<style>
  .rules-notice { padding: 1rem; display: grid; gap: .75rem; border: 1px solid var(--border-strong); border-radius: var(--radius-md); background: var(--surface-subtle); overflow-wrap: anywhere; }
  h2 { font-size: 1.1rem; margin: 0; } p { margin: 0; white-space: pre-wrap; } .meta { font-size: .8rem; color: var(--text-secondary); }
  div { display: flex; flex-wrap: wrap; gap: .5rem 1rem; } a, button { min-height: 2.75rem; display: inline-flex; align-items: center; } button { justify-content: center; padding: .75rem; border: 1px solid var(--border-strong); border-radius: var(--radius-sm); background: var(--surface); color: var(--text-primary); cursor: pointer; }
</style>
