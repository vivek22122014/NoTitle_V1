/** Deliberately submitted support data only. Never import storage records. */
export const kinds = ['grievance', 'appeal', 'access', 'correction', 'deletion', 'receipt'] as const;
export type Kind = typeof kinds[number];
export const categories = ['general', 'removal', 'intimate', 'court_order'] as const;
export type Category = typeof categories[number];
export interface Credential { case_ref: string; status_secret: string }
export interface Summary { case_ref: string; kind: Kind; category: Category; state: string; severity: string; received_at: string; acknowledge_due: string; resolution_due: string; acknowledged_at?: string; closed_at?: string; version: number; policy_version: string }
export interface CaseMessage { message_ref: string; author: string; text: string; created_at: string; appeal: boolean }
export interface CaseDetail extends Summary { subject: string; messages: CaseMessage[] }
export interface Receipt { case: Summary; status_secret: string }
export interface Submission { submission_id: string; status_secret: string; kind: Kind; category: Category; subject: string; message: string }
export interface Notice { version: string; text: string; audience: string; delivered_at: string; acknowledged_at?: string; next_due: string }
export function record(value: unknown): Record<string, unknown> { if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Invalid service response'); return value as Record<string, unknown>; }
export function text(value: unknown, max: number, min = 0): string { if (typeof value !== 'string' || value.length < min || value.length > max || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(value)) throw new Error('Invalid service response'); return value; }
export function timestamp(value: unknown): string { const result = text(value, 40, 20); if (!/^\d{4}-\d{2}-\d{2}T/u.test(result) || !Number.isFinite(Date.parse(result))) throw new Error('Invalid service response'); return result; }
export function integer(value: unknown, min = 0): number { if (!Number.isSafeInteger(value) || Number(value) < min) throw new Error('Invalid service response'); return Number(value); }
export function boolean(value: unknown): boolean { if (typeof value !== 'boolean') throw new Error('Invalid service response'); return value; }
export function reference(value: unknown): string { const result = text(value, 128, 16); if (!/^[A-Za-z0-9_-]+$/u.test(result)) throw new Error('Invalid reference'); return result; }
export function secret(value: unknown): string { const result = text(value, 43, 43); if (!/^[A-Za-z0-9_-]{43}$/u.test(result)) throw new Error('Invalid private status secret'); return result; }
export function list<T>(value: unknown, parser: (item: unknown) => T, max = 100): T[] { if (!Array.isArray(value) || value.length > max) throw new Error('Invalid service response'); return value.map(parser); }
function token(value: unknown): string { const result = text(value, 64, 1); if (!/^[a-z0-9_-]+$/u.test(result)) throw new Error('Invalid service response'); return result; }
export function parseSummary(value: unknown): Summary {
  const r = record(value); if (!kinds.includes(r.kind as Kind) || !categories.includes(r.category as Category)) throw new Error('Invalid case type');
  return { case_ref: reference(r.case_ref), kind: r.kind as Kind, category: r.category as Category, state: token(r.state), severity: token(r.severity), received_at: timestamp(r.received_at), acknowledge_due: timestamp(r.acknowledge_due), resolution_due: timestamp(r.resolution_due), ...(r.acknowledged_at ? { acknowledged_at: timestamp(r.acknowledged_at) } : {}), ...(r.closed_at ? { closed_at: timestamp(r.closed_at) } : {}), version: integer(r.version, 1), policy_version: text(r.policy_version, 128, 1) };
}
export function parseCases(value: unknown): Summary[] { return list(record(value).cases, parseSummary); }
export function parseCase(value: unknown): CaseDetail { const r = record(value); return { ...parseSummary(r), subject: text(r.subject, 640) || 'Case content removed under the reviewed retention schedule', messages: list(r.messages, (item) => { const m = record(item); if (!['complainant', 'operator'].includes(String(m.author))) throw new Error('Invalid public case message'); return { message_ref: reference(m.message_ref), author: token(m.author), text: text(m.text, 16000, 1), created_at: timestamp(m.created_at), appeal: boolean(m.appeal) }; }, 200) }; }
export function parseReceipt(value: unknown): Receipt { const r = record(value); return { case: parseSummary(r.case), status_secret: secret(r.status_secret) }; }
export function parseAvailability(value: unknown): boolean { return boolean(record(value).available); }
export function parseNotice(value: unknown): Notice | null { const r = record(value); if (r.notice === null) return null; const n = record(r.notice); return { version: text(n.version, 128, 1), text: text(n.text, 8000, 1), audience: token(n.audience), delivered_at: timestamp(n.delivered_at), ...(n.acknowledged_at ? { acknowledged_at: timestamp(n.acknowledged_at) } : {}), next_due: timestamp(n.next_due) }; }
export function messageIssue(value: string): string | null { const size = Array.from(value).length; if (Array.from(value.trim()).length < 5 || size > 4000 || new TextEncoder().encode(value).length > 16000) return 'Use 5–4,000 characters for the description or reply.'; if (/[\u0000-\u0008\u000b-\u001f\u007f\u202a-\u202e\u2066-\u2069]/u.test(value)) return 'Remove control characters from your message.'; return null; }
export function submissionIssue(input: Pick<Submission, 'subject' | 'message'>): string | null { if (!input.subject.trim() || Array.from(input.subject).length > 160) return 'Use a subject of 1–160 characters.'; if (/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/u.test(input.subject)) return 'Use a plain-text subject without control characters.'; if (new TextEncoder().encode(JSON.stringify(input)).length + 320 > 16384) return 'Shorten the subject or description so the complete request fits the 16 KiB limit.'; return messageIssue(input.message); }
export function randomToken(): string { const bytes = new Uint8Array(32); globalThis.crypto.getRandomValues(bytes); return btoa(String.fromCharCode(...bytes)).replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', ''); }
/** Immutable retry state lives only in RAM; an unknown result never invents another submission. */
export class PendingSubmission {
  private value: Submission | null = null;
  select(input: Pick<Submission, 'kind' | 'category' | 'subject' | 'message'>): Submission { if (submissionIssue(input)) throw new Error(submissionIssue(input)!); if (!this.value) this.value = { ...input, submission_id: randomToken(), status_secret: randomToken() }; else if (['kind', 'category', 'subject', 'message'].some((key) => this.value![key as keyof Submission] !== input[key as keyof typeof input])) throw new Error('Retry the original request before editing it.'); return { ...this.value }; }
  request(): Submission { if (!this.value) throw new Error('No prepared request'); return { ...this.value }; }
  clear(): void { this.value = null; }
}
export function receiptText(credential: Credential): string { return 'NoTitle private support access\n\nCase reference: ' + reference(credential.case_ref) + '\nPrivate status secret: ' + secret(credential.status_secret) + '\n\nOpen /support/case on the original NoTitle website and enter these codes. Anyone with both can read this case and reply. Keep this file private. This does not prove account or payment ownership.\n'; }
/** Only call after an explicit user download action. No URL contains a secret. */
export function downloadPrivate(filename: string, content: string, mime = 'text/plain'): void { const url = URL.createObjectURL(new Blob([content], { type: mime })); const anchor = document.createElement('a'); anchor.href = url; anchor.download = filename; anchor.rel = 'noopener'; anchor.click(); globalThis.setTimeout(() => URL.revokeObjectURL(url), 1000); }
