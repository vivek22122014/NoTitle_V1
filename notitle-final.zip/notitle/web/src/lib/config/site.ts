import * as publicEnv from '$env/static/public';
import releaseInventory from '../../../config/release.json';
import catalog from '../../../config/plans.json';
import { httpsOrigin, releaseMode, releaseIssues } from './release-policy.mjs';
import type { ReleaseInventory } from './release-types';
import { paymentSources } from './payment-csp.mjs';

const env = publicEnv as Record<string, string>;
const mode = releaseMode(env.PUBLIC_RELEASE_MODE);
const configuredOrigin = httpsOrigin(env.PUBLIC_SITE_ORIGIN, mode !== 'preview');
const issues = releaseIssues(releaseInventory, catalog, { mode, origin: configuredOrigin });
if (issues.length) throw new Error(`Release configuration is incomplete: ${issues.join('; ')}`);

// All values in these files are public business information. Never put secrets here.
export const release = releaseInventory as ReleaseInventory;
export const checkoutBuild = paymentSources(env);
export const site = Object.freeze({
  name: 'NoTitle',
  tagline: 'Talk about work, without the hierarchy.',
  supportingLine: 'A little room for a different perspective.',
  origin: mode === 'production' ? configuredOrigin : null,
  deploymentOrigin: configuredOrigin,
  locale: 'en-IN',
  releaseMode: mode,
  production: mode === 'production',
  catalogVersion: catalog.version
});

