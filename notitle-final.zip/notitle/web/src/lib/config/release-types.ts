export interface ReviewRecord {
  reviewer: string | null;
  reviewedAt: string | null;
  approvalReference: string | null;
}

export interface ReleaseInventory {
  schemaVersion: number;
  status: 'draft' | 'approved';
  canonicalOrigin: string | null;
  operator: { legalName: string | null; address: string | null; email: string | null; phone: string | null };
  grievance: { name: string | null; designation: string | null; email: string | null; address: string | null };
  tax: ReviewRecord & { status: 'gst_registered' | 'not_required' | null; gstin: string | null; inclusiveConsumerTotals: boolean; disclosure: string | null };
  privacy: ReviewRecord & {
    statement: string | null;
    retentionVersion: string | null;
    requestProcedure: string | null;
    legalHoldWorkflow: string | null;
    processors: { name: string; purpose: string; region: string; internationalProcessing: string; safeguards: string }[];
    retention: { dataClass: string; lifecycle: string; reason: string; legalSource: string; effectiveDate: string; owner: string; deletionMethod: string }[];
  };
  policies: { path: string; version: string; status: 'draft' | 'approved'; owner: string; reviewedAt: string | null; approvalReference: string | null }[];
  approvals: { productOwner: string | null; legalReviewer: string | null; approvedAt: string | null; reference: string | null; contentSha256: string | null };
  commercial: { salesEnabled: boolean; paymentReadinessApproved: boolean; annualEconomicsApproved: boolean; annualRefundsApproved: boolean; merchantApprovalReference: string | null; testPaymentEvidence: string | null; livePaymentEvidence: string | null; reviewer: string | null; approvedAt: string | null; reference: string | null };
}
