<script lang="ts">
  import { site } from '$lib/config/site';

  const productLinks = [
    { href: '/how-it-works', label: 'How it works' },
    { href: '/premium', label: 'Premium' },
    { href: '/safety', label: 'Safety' }
  ];

  const policyLinks = [
    { href: '/privacy', label: 'Privacy' },
    { href: '/terms', label: 'Terms' },
    { href: '/community-guidelines', label: 'Community guidelines' },
    { href: '/refund-policy', label: 'Refund policy' }
  ];

  const supportLinks = [
    { href: '/support', label: 'Support and privacy requests' },
    { href: '/support/case', label: 'Open saved case' },
    { href: '/contact', label: 'Contact' },
    { href: '/grievance', label: 'Grievances and appeals' },
    { href: '/account-deletion', label: 'Account deletion' }
  ];
</script>

<footer class="site-footer">
  <div class="footer-inner content-width">
    <div class="footer-about">
      <a class="footer-brand" href="/" aria-label={site.name + ' home'}>{site.name}</a>
      <p>{site.tagline}</p>
      <p class="footer-note">For adults 18+. India-first.<br />Anonymous to the people you meet, with privacy limits.</p>
      {#if !site.production}<span class="preview-label">Product preview · Not open yet</span>{/if}
    </div>
    <nav aria-labelledby="footer-product">
      <h2 id="footer-product">Explore</h2>
      <ul>
        {#each productLinks as link}
          <li><a href={link.href}>{link.label}</a></li>
        {/each}
      </ul>
    </nav>
    <nav aria-labelledby="footer-policy">
      <h2 id="footer-policy">Policies</h2>
      <ul>
        {#each policyLinks as link}
          <li><a href={link.href}>{link.label}</a></li>
        {/each}
      </ul>
    </nav>
    <nav aria-labelledby="footer-support">
      <h2 id="footer-support">Help and rights</h2>
      <ul>
        {#each supportLinks as link}
          <li><a href={link.href}>{link.label}</a></li>
        {/each}
      </ul>
    </nav>
    <div class="footer-bottom">
      <p>No public feed. No video. One conversation at a time.</p>
      <a href="#main-content">Back to content <span aria-hidden="true">↑</span></a>
    </div>
  </div>
</footer>

<style>
  .site-footer {
    border-top: 1px solid var(--border);
    background: var(--surface);
  }

  .footer-inner {
    display: grid;
    gap: 2rem;
    padding-block: 3rem calc(1.5rem + env(safe-area-inset-bottom));
  }

  .footer-brand {
    display: inline-flex;
    align-items: center;
    min-height: 2.75rem;
    color: var(--text-primary);
    font-size: 1.25rem;
    font-weight: 800;
    letter-spacing: -0.03em;
    text-decoration: none;
  }

  .footer-about p {
    max-width: 20rem;
    margin: 0.35rem 0 1rem;
    color: var(--text-secondary);
    font-size: 0.875rem;
  }

  .footer-about .footer-note {
    font-size: 0.8125rem;
  }

  nav h2 {
    margin: 0 0 0.6rem;
    font-size: 0.8125rem;
    font-weight: 750;
  }

  nav ul {
    margin: 0;
    padding: 0;
    list-style: none;
  }

  nav a,
  .footer-bottom a {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    min-height: 2.75rem;
    min-width: 2.75rem;
    padding-block: 0.5rem;
    color: var(--text-secondary);
    font-size: 0.8125rem;
    text-decoration: none;
  }

  nav a:hover,
  .footer-bottom a:hover {
    color: var(--accent-strong);
    text-decoration: underline;
  }

  .footer-bottom {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    align-items: center;
    gap: 0.5rem 2rem;
    padding-top: 1rem;
    border-top: 1px solid var(--border);
    color: var(--text-muted);
    font-size: 0.75rem;
  }

  .footer-bottom p {
    margin: 0;
  }

  @media (min-width: 36rem) {
    .footer-inner {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .footer-bottom {
      grid-column: 1 / -1;
    }
  }

  @media (min-width: 64rem) {
    .footer-inner {
      grid-template-columns: minmax(0, 1.6fr) repeat(3, minmax(0, 1fr));
      gap: 2rem;
    }
  }
</style>
