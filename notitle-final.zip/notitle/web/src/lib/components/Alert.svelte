<script lang="ts">
  export let variant: 'info' | 'success' | 'warning' | 'danger' = 'info';
  export let title = '';
</script>

<div class:alert-info={variant === 'info'} class:alert-success={variant === 'success'} class:alert-warning={variant === 'warning'} class:alert-danger={variant === 'danger'} class="alert" role={variant === 'danger' ? 'alert' : 'status'}>
  {#if title}<strong>{title}</strong>{/if}
  <div class="content"><slot /></div>
</div>

<style>
  .alert {
    display: grid;
    gap: 0.25rem;
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    padding: 0.85rem 1rem;
    background: var(--surface-subtle);
    color: var(--text-primary);
  }

  .content :global(p) {
    margin: 0;
  }

  .alert-info {
    border-color: #bfdbfe;
    background: #eff6ff;
  }

  .alert-success {
    border-color: #bbf7d0;
    background: #f0fdf4;
  }

  .alert-warning {
    border-color: #fde68a;
    background: #fffbeb;
  }

  .alert-danger {
    border-color: #fecaca;
    background: #fef2f2;
  }
</style>
