<script lang="ts">
  import { classes } from '$lib/utils/classes';

  export let href: string | undefined = undefined;
  export let variant: 'primary' | 'secondary' | 'ghost' | 'danger' = 'primary';
  export let type: 'button' | 'submit' | 'reset' = 'button';
  export let disabled = false;
  export let fullWidth = false;
  export let ariaLabel: string | undefined = undefined;

  $: className = classes('button', `button--${variant}`, fullWidth && 'button--full');
</script>

{#if href}
  <a
    class={className}
    href={disabled ? undefined : href}
    aria-disabled={disabled ? 'true' : undefined}
    aria-label={ariaLabel}
    tabindex={disabled ? -1 : undefined}
    {...$$restProps}
  >
    <slot />
  </a>
{:else}
  <button
    class={className}
    {type}
    {disabled}
    aria-label={ariaLabel}
    {...$$restProps}
  >
    <slot />
  </button>
{/if}

<style>
  .button {
    min-height: 2.75rem;
    min-width: 2.75rem;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    border: 1px solid transparent;
    border-radius: var(--radius-md);
    padding: 0.7rem 1rem;
    font: inherit;
    font-weight: 700;
    line-height: 1.2;
    text-decoration: none;
    cursor: pointer;
    transition:
      background-color 120ms ease,
      border-color 120ms ease,
      color 120ms ease,
      transform 120ms ease;
    -webkit-tap-highlight-color: transparent;
  }

  .button:focus-visible {
    outline: 3px solid var(--focus-ring);
    outline-offset: 2px;
  }

  .button:active:not(:disabled):not([aria-disabled='true']) {
    transform: translateY(1px);
  }

  .button:disabled,
  .button[aria-disabled='true'] {
    cursor: not-allowed;
    opacity: 0.55;
  }

  .button--primary {
    background: var(--accent);
    color: white;
  }

  .button--primary:hover:not(:disabled):not([aria-disabled='true']) {
    background: var(--accent-strong);
  }

  .button--secondary {
    background: var(--surface);
    border-color: var(--border-strong);
    color: var(--text-primary);
  }

  .button--secondary:hover:not(:disabled):not([aria-disabled='true']) {
    background: var(--surface-subtle);
  }

  .button--ghost {
    background: transparent;
    color: var(--text-secondary);
  }

  .button--ghost:hover:not(:disabled):not([aria-disabled='true']) {
    background: var(--surface-subtle);
    color: var(--text-primary);
  }

  .button--danger {
    background: var(--danger);
    color: white;
  }

  .button--danger:hover:not(:disabled):not([aria-disabled='true']) {
    background: var(--danger-strong);
  }

  .button--full {
    width: 100%;
  }

  @media (prefers-reduced-motion: reduce) {
    .button {
      transition: none;
    }
  }
</style>
