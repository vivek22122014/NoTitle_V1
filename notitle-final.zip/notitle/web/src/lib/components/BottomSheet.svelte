<script lang="ts">
  import { createEventDispatcher } from 'svelte';

  export let id: string;
  export let open = false;
  export let title: string;

  let element: HTMLDialogElement;
  const dispatch = createEventDispatcher<{ close: void }>();

  $: if (element) {
    if (open && !element.open) element.showModal();
    if (!open && element.open) element.close();
  }

  function close() {
    open = false;
    if (element?.open) element.close();
    dispatch('close');
  }

  function handleCancel(event: Event) {
    event.preventDefault();
    close();
  }

  function handleBackdrop(event: MouseEvent) {
    if (event.target === element) close();
  }
</script>

<dialog bind:this={element} aria-labelledby={`${id}-title`} on:cancel={handleCancel} on:click={handleBackdrop}>
  <section class="sheet">
    <div class="handle" aria-hidden="true"></div>
    <header>
      <h2 id={`${id}-title`}>{title}</h2>
      <button type="button" aria-label="Close" on:click={close}>x</button>
    </header>
    <div class="content"><slot /></div>
  </section>
</dialog>

<style>
  dialog {
    width: 100%;
    max-width: none;
    height: 100%;
    max-height: none;
    margin: 0;
    border: 0;
    padding: 0;
    background: transparent;
  }

  dialog::backdrop {
    background: rgb(15 23 42 / 0.5);
  }

  .sheet {
    position: fixed;
    right: 0;
    bottom: 0;
    left: 0;
    max-height: min(80dvh, 40rem);
    overflow: auto;
    padding-bottom: env(safe-area-inset-bottom);
    border: 1px solid var(--border);
    border-bottom: 0;
    border-radius: 1.25rem 1.25rem 0 0;
    background: var(--surface);
    box-shadow: var(--shadow-lg);
  }

  .handle {
    width: 2.5rem;
    height: 0.25rem;
    margin: 0.55rem auto 0;
    border-radius: 999px;
    background: var(--border-strong);
  }

  header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 1rem;
    padding: 0.8rem 1rem;
    border-bottom: 1px solid var(--border);
  }

  h2 {
    margin: 0;
    font-size: 1.05rem;
  }

  button {
    width: 2.75rem;
    height: 2.75rem;
    border: 0;
    border-radius: var(--radius-md);
    background: transparent;
    color: var(--text-secondary);
    font: inherit;
    font-size: 1.25rem;
  }

  button:focus-visible {
    outline: 3px solid var(--focus-ring);
  }

  .content {
    padding: 1rem;
  }

  @media (min-width: 48rem) {
    .sheet {
      right: 1rem;
      bottom: 1rem;
      left: auto;
      width: min(28rem, calc(100vw - 2rem));
      border: 1px solid var(--border);
      border-radius: var(--radius-lg);
      padding-bottom: 0;
    }
  }
</style>
