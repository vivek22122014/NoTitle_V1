<script lang="ts">
  export let id: string;
  export let label: string;
  export let value = '';
  export let type: 'text' | 'password' | 'email' | 'search' = 'text';
  export let placeholder = '';
  export let autocomplete: string | undefined = undefined;
  export let help = '';
  export let error = '';
  export let maxlength: number | undefined = undefined;
  export let disabled = false;

  $: helpId = help ? `${id}-help` : undefined;
  $: errorId = error ? `${id}-error` : undefined;
  $: describedBy = [helpId, errorId].filter(Boolean).join(' ') || undefined;
</script>

<div class="field">
  <label for={id}>{label}</label>
  <input
    {id}
    {type}
    bind:value
    {placeholder}
    {autocomplete}
    {maxlength}
    {disabled}
    aria-invalid={error ? 'true' : undefined}
    aria-describedby={describedBy}
    {...$$restProps}
  />
  {#if help}
    <p id={helpId} class="help">{help}</p>
  {/if}
  {#if error}
    <p id={errorId} class="error" role="alert">{error}</p>
  {/if}
</div>

<style>
  .field {
    display: grid;
    gap: 0.45rem;
  }

  label {
    color: var(--text-primary);
    font-weight: 700;
    font-size: 0.94rem;
  }

  input {
    min-height: 2.875rem;
    width: 100%;
    border: 1px solid var(--border-strong);
    border-radius: var(--radius-md);
    background: var(--surface);
    color: var(--text-primary);
    padding: 0.72rem 0.8rem;
    font: inherit;
  }

  input::placeholder {
    color: var(--text-muted);
  }

  input:hover:not(:disabled) {
    border-color: var(--text-muted);
  }

  input:focus-visible {
    border-color: var(--accent);
    outline: 3px solid var(--focus-ring);
    outline-offset: 1px;
  }

  input[aria-invalid='true'] {
    border-color: var(--danger);
  }

  input:disabled {
    cursor: not-allowed;
    background: var(--surface-subtle);
    opacity: 0.7;
  }

  .help,
  .error {
    margin: 0;
    font-size: 0.84rem;
    line-height: 1.45;
  }

  .help {
    color: var(--text-secondary);
  }

  .error {
    color: var(--danger-strong);
  }
</style>
