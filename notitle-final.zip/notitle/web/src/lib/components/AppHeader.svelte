<script lang="ts">
  import { page } from '$app/stores';
  import { site } from '$lib/config/site';

  let menuOpen = false;
  let menuSummary: HTMLElement;

  const links = [
    { href: '/how-it-works', label: 'How it works' },
    { href: '/premium', label: 'Premium' },
    { href: '/safety', label: 'Safety' }
  ];

  function handleEscape(event: KeyboardEvent) {
    if (event.key === 'Escape' && menuOpen) {
      menuOpen = false;
      menuSummary?.focus();
    }
  }
</script>

<svelte:window on:keydown={handleEscape} />

<header class="site-header">
  <div class="header-inner content-width">
    <a class="brand" href="/" aria-label={site.name + ' home'}>
      <span class="brand-mark" aria-hidden="true">N</span>
      <span>{site.name}</span>
    </a>

    <nav class="desktop-navigation" aria-label="Primary navigation">
      {#each links as link}
        <a href={link.href} aria-current={$page.url.pathname === link.href ? 'page' : undefined}>
          {link.label}
        </a>
      {/each}
      <a class="navigation-cta" href="/chat">Start a Conversation</a>
    </nav>

    <details class="mobile-navigation" bind:open={menuOpen}>
      <summary bind:this={menuSummary} aria-controls="mobile-navigation-links">
        <span>{menuOpen ? 'Close' : 'Menu'}</span>
        <span class="menu-symbol" aria-hidden="true">{menuOpen ? '−' : '+'}</span>
      </summary>
      <nav id="mobile-navigation-links" aria-label="Primary navigation">
        {#each links as link}
          <a
            href={link.href}
            aria-current={$page.url.pathname === link.href ? 'page' : undefined}
            on:click={() => (menuOpen = false)}
          >
            {link.label}
          </a>
        {/each}
        <a class="navigation-cta" href="/chat" on:click={() => (menuOpen = false)}>
          Start a Conversation
        </a>
      </nav>
    </details>
  </div>
</header>

<style>
  .site-header {
    position: sticky;
    top: 0;
    z-index: 20;
    border-bottom: 1px solid var(--border);
    background: var(--background);
  }

  .header-inner {
    position: relative;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    gap: 1rem;
    min-height: 4.5rem;
    padding-block: max(0.5rem, env(safe-area-inset-top)) 0.5rem;
  }

  .brand {
    display: inline-flex;
    align-items: center;
    gap: 0.65rem;
    min-height: 2.75rem;
    color: var(--text-primary);
    text-decoration: none;
    font-size: 1.125rem;
    font-weight: 800;
    letter-spacing: -0.03em;
  }

  .brand-mark {
    display: grid;
    flex: 0 0 2rem;
    place-items: center;
    width: 2rem;
    height: 2rem;
    border: 1px solid var(--navy);
    border-radius: 0.6rem;
    background: var(--navy);
    color: white;
    font-size: 1rem;
  }

  .desktop-navigation {
    display: none;
  }

  .mobile-navigation summary {
    display: flex;
    align-items: center;
    gap: 0.7rem;
    min-width: 2.75rem;
    min-height: 2.75rem;
    padding: 0.5rem 0.8rem;
    border: 1px solid var(--border-strong);
    border-radius: var(--radius-sm);
    background: var(--surface);
    font-size: 0.875rem;
    font-weight: 650;
    list-style: none;
    cursor: pointer;
  }

  .mobile-navigation summary::-webkit-details-marker {
    display: none;
  }

  .menu-symbol {
    width: 0.9rem;
    text-align: center;
    font-size: 1.2rem;
    line-height: 1;
  }

  .mobile-navigation nav {
    position: absolute;
    top: calc(100% + 0.5rem);
    right: 0;
    left: 0;
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
    max-height: calc(100vh - 6rem);
    max-height: calc(100dvh - 6rem);
    overflow-y: auto;
    padding: 0.75rem;
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    background: var(--surface);
    box-shadow: var(--shadow-lg);
  }

  nav a {
    display: flex;
    align-items: center;
    min-height: 2.75rem;
    min-width: 2.75rem;
    padding: 0.55rem 0.75rem;
    border-radius: var(--radius-sm);
    color: var(--text-secondary);
    font-size: 0.875rem;
    font-weight: 650;
    text-decoration: none;
  }

  nav a:hover,
  nav a[aria-current='page'] {
    background: var(--surface-subtle);
    color: var(--text-primary);
  }

  nav a[aria-current='page'] {
    text-decoration: underline;
    text-decoration-thickness: 2px;
  }

  nav a.navigation-cta {
    justify-content: center;
    padding-inline: 1rem;
    background: var(--accent);
    color: white;
  }

  nav a.navigation-cta:hover {
    background: var(--accent-strong);
  }

  @media (min-width: 56rem) {
    .mobile-navigation {
      display: none;
    }

    .desktop-navigation {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: flex-end;
      gap: 0.25rem;
    }

    nav a.navigation-cta {
      margin-left: 0.75rem;
    }
  }
</style>
