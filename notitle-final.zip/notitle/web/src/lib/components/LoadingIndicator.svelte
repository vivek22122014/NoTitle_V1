<script lang="ts">
  export let label = 'Loading';
  export let size: 'sm' | 'md' | 'lg' = 'md';
</script>

<span class={`loader loader--${size}`} role="status" aria-label={label}>
  <span aria-hidden="true"></span>
</span>

<style>
  .loader {
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }

  .loader span {
    display: block;
    border: 2px solid var(--border-strong);
    border-top-color: var(--accent);
    border-radius: 999px;
    animation: spin 750ms linear infinite;
  }

  .loader--sm span {
    width: 1rem;
    height: 1rem;
  }

  .loader--md span {
    width: 1.5rem;
    height: 1.5rem;
  }

  .loader--lg span {
    width: 2rem;
    height: 2rem;
  }

  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .loader span {
      animation-duration: 1.6s;
    }
  }
</style>
