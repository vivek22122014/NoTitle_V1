<script lang="ts">
  import { createEventDispatcher } from 'svelte';

  export let id: string;
  export let open = false;
  export let title: string;
  export let description = '';

  let element: HTMLDialogElement;
  const dispatch = createEventDispatcher<{ close: void }>();

  $: if (element) {
    if (open && !element.open) element.showModal();
    if (!open && element.open) element.close();
  }

  function close() {
    open = false;
    if (element?.open) element.close();
    dispatch('close');
  }

  function handleCancel(event: Event) {
    event.preventDefault();
    close();
  }

  function handleBackdrop(event: MouseEvent) {
    if (event.target === element) close();
  }
</script>

<dialog
  bind:this={element}
  aria-labelledby={`${id}-title`}
  aria-describedby={description ? `${id}-description` : undefined}
  on:cancel={handleCancel}
  on:click={handleBackdrop}
  on:close={() => {
    if (open) {
      open = false;
      dispatch('close');
    }
  }}
>
  <section class="dialog-card">
    <header>
      <div>
        <h2 id={`${id}-title`}>{title}</h2>
        {#if description}<p id={`${id}-description`}>{description}</p>{/if}
      </div>
      <button class="close" type="button" aria-label="Close dialog" on:click={close}>x</button>
    </header>
    <div class="body"><slot /></div>
    <footer><slot name="actions" /></footer>
  </section>
</dialog>

<style>
  dialog {
    width: min(92vw, 30rem);
    max-height: min(86dvh, 44rem);
    border: 0;
    border-radius: var(--radius-lg);
    padding: 0;
    background: transparent;
    color: var(--text-primary);
  }

  dialog::backdrop {
    background: rgb(15 23 42 / 0.5);
    backdrop-filter: blur(2px);
  }

  .dialog-card {
    overflow: auto;
    max-height: min(86dvh, 44rem);
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-lg);
  }

  header,
  .body,
  footer {
    padding: 1rem;
  }

  header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 1rem;
    border-bottom: 1px solid var(--border);
  }

  h2,
  p {
    margin: 0;
  }

  h2 {
    font-size: 1.15rem;
  }

  p {
    margin-top: 0.25rem;
    color: var(--text-secondary);
    font-size: 0.9rem;
  }

  .close {
    width: 2.75rem;
    height: 2.75rem;
    border: 0;
    border-radius: var(--radius-md);
    background: transparent;
    color: var(--text-secondary);
    font: inherit;
    font-size: 1.25rem;
    cursor: pointer;
  }

  .close:hover {
    background: var(--surface-subtle);
  }

  .close:focus-visible {
    outline: 3px solid var(--focus-ring);
  }

  footer {
    display: flex;
    justify-content: flex-end;
    gap: 0.65rem;
    border-top: 1px solid var(--border);
  }

  footer:empty {
    display: none;
  }
</style>
