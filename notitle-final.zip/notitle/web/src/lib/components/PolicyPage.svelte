<script lang="ts">
  import { release, site } from '$lib/config/site';

  export let path: string;
  export let title: string;
  export let introduction: string;
  export let contents: { id: string; label: string }[] = [];

  $: policy = release.policies.find((entry) => entry.path === path);
  $: approved = site.production && policy?.status === 'approved';
</script>

<article class="policy-page reading-width">
  <header>
    <p class="eyebrow">NoTitle · {approved ? 'Policies and support' : 'Policy preview'}</p>
    <h1>{title}</h1>
    <p class="page-lead">{introduction}</p>
    <dl class="document-meta">
      <div><dt>Status</dt><dd>{approved ? 'Approved for publication' : 'Draft · not in force'}</dd></div>
      <div><dt>Version</dt><dd>{policy?.version ?? '0.2.0-draft'}</dd></div>
      <div><dt>Responsible role</dt><dd>{policy?.owner ?? 'Business owner and appointed legal reviewer'}</dd></div>
    </dl>
    {#if !approved}
      <aside class="draft-notice" aria-label="Draft policy notice">
        <strong>For review before launch.</strong>
        <p>This describes the proposed public service. Features may be enabled for controlled tests; that does not establish approval for public access, live purchases or support coverage. The responsible role is a review responsibility, not a confirmed officer appointment. Operator details and legal approval remain outstanding.</p>
      </aside>
    {/if}
  </header>

  {#if contents.length}
    <nav class="contents" aria-label={`On this page: ${title}`}>
      <p>On this page</p>
      <ul>
        {#each contents as section}
          <li><a href={`#${section.id}`}>{section.label}</a></li>
        {/each}
      </ul>
    </nav>
  {/if}

  <div class="policy-content"><slot /></div>

  <footer class="policy-footer">
    <p>Read alongside <a href="/privacy">Privacy</a>, <a href="/terms">Terms</a> and our <a href="/community-guidelines">Community Guidelines</a>.</p>
    <a class="text-link" href="/contact">Contact and support information <span aria-hidden="true">→</span></a>
  </footer>
</article>

<style>
  .policy-page { padding-block: clamp(2.5rem, 7vw, 5rem); }
  h1 { margin: 0 0 1.25rem; font-size: clamp(2rem, 6vw, 3.25rem); line-height: 1.1; letter-spacing: -0.04em; }
  .document-meta { display: grid; gap: 1rem; margin: 1.75rem 0; padding-block: 1.25rem; border-block: 1px solid var(--border-strong); }
  .document-meta div { min-width: 0; }
  dt { color: var(--text-secondary); font-size: 0.8rem; }
  dd { margin: 0.25rem 0 0; font-size: 0.9rem; font-weight: 600; }
  .draft-notice { padding: 1.25rem; border: 1px solid var(--border-strong); border-left: 3px solid var(--accent); border-radius: var(--radius-md); background: var(--surface-subtle); }
  .draft-notice p { margin: 0.5rem 0 0; color: var(--text-secondary); }
  .contents { margin-block: 2rem 2.5rem; }
  .contents p { margin: 0 0 0.5rem; font-weight: 700; }
  .contents ul { list-style: none; margin: 0; padding: 0; }
  .contents a { display: flex; align-items: center; min-height: 44px; padding-block: 0.5rem; text-underline-offset: 4px; }
  .policy-content :global(section + section) { margin-top: 2.5rem; }
  .policy-content :global(h2) { font-size: clamp(1.3rem, 4vw, 1.65rem); line-height: 1.3; letter-spacing: -0.025em; margin: 0 0 1rem; }
  .policy-content :global(h3) { font-size: 1.1rem; line-height: 1.4; margin-top: 1.5rem; }
  .policy-content :global(p), .policy-content :global(li) { color: var(--text-secondary); }
  .policy-content :global(ul), .policy-content :global(ol) { padding-left: 1.4rem; }
  .policy-content :global(li + li) { margin-top: 0.7rem; }
  .policy-content :global(a), .policy-footer a { display: inline-flex; align-items: center; min-height: 44px; text-underline-offset: 4px; }
  .policy-content :global(strong) { color: var(--text-primary); }
  .policy-content :global(address) { font-style: normal; white-space: pre-line; overflow-wrap: anywhere; }
  .policy-footer { margin-top: 3rem; padding-top: 1.25rem; border-top: 1px solid var(--border-strong); color: var(--text-secondary); }
  .policy-footer p { margin-top: 0; }
  @media (min-width: 40rem) { .document-meta { grid-template-columns: 1fr 1fr 2fr; } }
</style>
