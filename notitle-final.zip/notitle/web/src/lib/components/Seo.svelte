<script lang="ts">
  import { site, release } from '$lib/config/site';
  import { appPaths, publicMetadata } from '$lib/config/routes.mjs';
  import { safeJsonLd } from '$lib/config/release-policy.mjs';

  export let path: string;
  $: application = appPaths.includes(path);
  $: metadata = application
    ? { title: 'Your Space | NoTitle', description: 'NoTitle private account, guest access and conversation controls. Features depend on current service availability.', label: 'Application' }
    : publicMetadata(path);
  $: canonical = site.production && !application ? `${site.origin}${path}` : null;
  $: graph = canonical ? [
    { '@type': 'WebSite', '@id': `${site.origin}/#website`, name: site.name, url: `${site.origin}/`, inLanguage: site.locale },
    { '@type': 'Organization', '@id': `${site.origin}/#operator`, name: release.operator.legalName, url: `${site.origin}/`, email: release.operator.email, telephone: release.operator.phone, address: release.operator.address },
    ...(path === '/' ? [] : [{ '@type': 'BreadcrumbList', itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home', item: `${site.origin}/` },
      { '@type': 'ListItem', position: 2, name: metadata.label, item: canonical }
    ] }])
  ] : [];
</script>

<svelte:head>
  <title>{metadata.title}</title>
  <meta name="description" content={metadata.description} />
  <meta name="robots" content={site.production && !application ? 'index, follow' : 'noindex, nofollow'} />
  <meta property="og:type" content="website" />
  <meta property="og:site_name" content={site.name} />
  <meta property="og:locale" content="en_IN" />
  <meta property="og:title" content={metadata.title} />
  <meta property="og:description" content={metadata.description} />
  {#if canonical}
    <link rel="canonical" href={canonical} />
    <meta property="og:url" content={canonical} />
    <meta property="og:image" content={`${site.origin}/social-card.png`} />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />
    <meta property="og:image:alt" content="NoTitle. Talk about work, without the hierarchy." />
    <!-- Only safeJsonLd output is inserted; it escapes all HTML-significant characters. -->
    <!-- eslint-disable-next-line svelte/no-at-html-tags -->
    {@html `<script type="application/ld+json">${safeJsonLd({ '@context': 'https://schema.org', '@graph': graph })}</script>`}
  {/if}
</svelte:head>

