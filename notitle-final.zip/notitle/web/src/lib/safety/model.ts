import { textBytes, textProblem, MAX_TRANSCRIPT_BYTES } from '../realtime/text.ts';
export const reportCategories = [
  ['harassment', 'Harassment'], ['threats', 'Threats'], ['doxxing', 'Doxxing'], ['confidentiality', 'Confidentiality'],
  ['targeted_false_accusations', 'Targeted false accusations'], ['scams', 'Scams'], ['impersonation', 'Impersonation'],
  ['suspected_underage_access', 'Suspected underage access'], ['sexual_misconduct', 'Sexual misconduct'], ['spam', 'Spam'], ['other', 'Other']
] as const;
export type SafetyTarget = { generation: number; interaction_id: string; epoch: number } | { ended_ref: string };
export interface Evidence { server_sequence: number; speaker: 'self' | 'peer'; text: string; sent_at: string }
export interface ReportDraft { handle: string; expires_at: string; messages: Evidence[]; metadata_only: boolean; blocked: boolean }
export interface ReportSubmission { handle: string; submission_id: string; category: string; statement: string; selected_sequences: number[] }
export interface ReportReceipt { case_ref: string; submitted_at: string; blocked: boolean }
export interface BlockView { ref: string; display_name: string; created_at: string; durable: boolean; pending: boolean }
export const validRef = (value: unknown): value is string => typeof value === 'string' && /^[A-Za-z0-9_-]{16,128}$/u.test(value);
const object = (value: unknown): value is Record<string, unknown> => !!value && typeof value === 'object' && !Array.isArray(value);
const date = (value: unknown): value is string => typeof value === 'string' && value.length <= 64 && Number.isFinite(Date.parse(value));
/** Only server-attributed evidence is selectable; raw storage identities are discarded. */
export function parseDraft(value: unknown): ReportDraft {
  if (!object(value) || !validRef(value.handle) || !date(value.expires_at) || !Array.isArray(value.messages) || value.messages.length > 30 || typeof value.metadata_only !== 'boolean' || typeof value.blocked !== 'boolean') throw new Error('Invalid report response');
  let bytes = 0; const seen = new Set<number>();
  const messages: Evidence[] = value.messages.map((item: unknown) => {
    if (!object(item) || !Number.isSafeInteger(item.server_sequence) || Number(item.server_sequence) < 1 || seen.has(Number(item.server_sequence)) || !['self', 'peer'].includes(String(item.speaker)) || typeof item.text !== 'string' || textProblem(item.text) || !date(item.sent_at)) throw new Error('Invalid report evidence');
    bytes += textBytes(item.text); seen.add(Number(item.server_sequence));
    return { server_sequence: Number(item.server_sequence), speaker: item.speaker as 'self' | 'peer', text: item.text, sent_at: item.sent_at };
  });
  if (bytes > MAX_TRANSCRIPT_BYTES || (value.metadata_only && messages.length)) throw new Error('Invalid report evidence');
  return { handle: value.handle, expires_at: value.expires_at, messages, metadata_only: value.metadata_only, blocked: value.blocked };
}
export function parseBlocks(value: unknown): BlockView[] {
  if (!object(value) || !Array.isArray(value.blocks) || value.blocks.length > 100) throw new Error('Invalid block response');
  return value.blocks.map((item: unknown) => {
    if (!object(item) || !validRef(item.ref) || typeof item.display_name !== 'string' || item.display_name.length > 128 || !date(item.created_at) || typeof item.durable !== 'boolean' || typeof item.pending !== 'boolean') throw new Error('Invalid block response');
    return { ref: item.ref, display_name: item.display_name, created_at: item.created_at, durable: item.durable, pending: item.pending };
  });
}
export function parseReceipt(value: unknown): ReportReceipt {
  if (!object(value) || !validRef(value.case_ref) || !date(value.submitted_at) || typeof value.blocked !== 'boolean') throw new Error('Invalid report receipt');
  return { case_ref: value.case_ref, submitted_at: value.submitted_at, blocked: value.blocked };
}
