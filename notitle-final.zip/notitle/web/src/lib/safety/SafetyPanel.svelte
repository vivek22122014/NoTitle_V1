<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import { ApiError } from '../api/client';
  import type { IdentityClient } from '../identity/client';
  import type { RealtimeClient } from '../realtime/client';
  import type { LiveState } from '../realtime/model';
  import { textProblem } from '../realtime/text';
  import Dialog from '../components/Dialog.svelte';
  import { reportCategories } from './model';
  import type { BlockView, ReportDraft, ReportReceipt, ReportSubmission, SafetyTarget } from './model';
  export let client: IdentityClient;
  export let realtime: RealtimeClient | null;
  export let live: LiveState;
  let draft: ReportDraft | null = null;
  let receipt: ReportReceipt | null = null;
  let selected: number[] = [];
  let category = 'harassment';
  let statement = '';
  let submission: ReportSubmission | null = null;
  let blocks: BlockView[] = [];
  let blocksLoaded = false;
  let busy = false;
  let loadingBlocks = false;
  let open = false;
  let expired = false;
  let message = '';
  let now = Date.now();
  let serial = 0;
  let disposed = false;
  let expiryTimer: ReturnType<typeof setTimeout> | undefined;
  $: active = live.snapshot?.interaction;
  $: recent = live.endedReport && Date.parse(live.endedReport.expires_at) > now ? live.endedReport : null;
  $: enabled = live.snapshot?.text_enabled === true;
  $: if (['expired', 'replaced', 'restart'].includes(live.status) && (draft || receipt)) { closeForm(); receipt = null; }
  $: seconds = draft ? Math.max(0, Math.ceil((Date.parse(draft.expires_at) - now) / 1000)) : 0;
  $: statementProblem = statement ? textProblem(statement) : null;
  const safeMessage = (error: unknown): string => error instanceof ApiError ? error.message : 'The safety request could not be confirmed. Please retry or review grievance options.';
  function target(ended = false): SafetyTarget | null {
    if (!ended && active && live.snapshot) return { generation: live.snapshot.generation, interaction_id: active.id, epoch: active.epoch };
    return recent ? { ended_ref: recent.ref } : null;
  }
  function clearDraft(): void {
    clearTimeout(expiryTimer); expiryTimer = undefined;
    serial++; draft = null; selected = []; statement = ''; submission = null; expired = false; busy = false;
  }
  function closeForm(): void { open = false; clearDraft(); }
  function expire(): void {
    if (!draft || expired) return;
    draft = { ...draft, messages: [] }; selected = []; statement = ''; submission = null; expired = true;
    message = 'The two-minute report snapshot expired. Its text was cleared. Review grievance options if you still need help.';
  }
  async function loadBlocks(): Promise<void> {
    loadingBlocks = true;
    try { const response = await client.blocks(); if (!disposed) { blocks = response; blocksLoaded = true; } }
    catch (error) { if (!disposed) message = safeMessage(error); }
    finally { if (!disposed) loadingBlocks = false; }
  }
  async function begin(block: boolean, ended = false): Promise<void> {
    const reference = target(ended); if (!reference || busy) return;
    clearDraft(); receipt = null; message = ''; busy = true; open = true;
    const request = serial;
    if (block && !ended) realtime?.clearConversationText();
    try {
      const response = await client.beginReport(reference, block);
      if (disposed || request !== serial) return;
      draft = response; now = Date.now();
      if (Date.parse(response.expires_at) <= now) expire();
      else {
        expiryTimer = setTimeout(expire, Math.min(120000, Math.max(0, Date.parse(response.expires_at) - now)));
        message = response.blocked ? 'The interaction is blocked locally. Submit the report to confirm its storage.' : '';
      }
      if (response.blocked) void loadBlocks();
    } catch (error) {
      if (!disposed && request === serial) message = (block ? 'The block or report snapshot could not be confirmed. No report submission is confirmed. ' : '') + safeMessage(error);
    } finally { if (!disposed && request === serial) busy = false; }
  }
  async function submit(event: SubmitEvent): Promise<void> {
    event.preventDefault(); if (!draft || expired || busy || statementProblem) return;
    if (Date.parse(draft.expires_at) <= Date.now()) { expire(); return; }
    // Freeze the exact first submission. A retry never changes the payload or
    // submission ID, even after an uncertain response from the server.
    submission ??= { handle: draft.handle, submission_id: crypto.randomUUID(), category, statement, selected_sequences: [...selected].sort((a, b) => a - b) };
    busy = true; message = ''; const request = serial;
    try {
      const response = await client.submitReport(submission);
      if (disposed || request !== serial) return;
      receipt = response; clearDraft(); busy = false;
      message = 'Report submitted. Selected evidence and your separately labelled statement were received.';
      void loadBlocks();
    } catch (error) {
      if (disposed || request !== serial) return;
      if (error instanceof ApiError && error.code.toLowerCase() === 'report_expired') expire();
      else message = 'Report submission is not confirmed. ' + (draft.blocked ? 'The local block remains. ' : '') + safeMessage(error);
    } finally { if (!disposed && request === serial) busy = false; }
  }
  async function blockOnly(): Promise<void> {
    const reference = target(); if (!reference || busy) return;
    busy = true; message = ''; realtime?.clearConversationText();
    try {
      await client.block(reference);
      if (!disposed) { message = 'Block applied. This conversation is ended.'; await loadBlocks(); }
    } catch (error) { if (!disposed) message = 'Storage confirmation failed. A local block may already apply; check your block list. ' + safeMessage(error); }
    finally { if (!disposed) busy = false; }
  }
  async function unblock(ref: string): Promise<void> {
    if (busy) return; busy = true; message = '';
    try { await client.unblock(ref); if (!disposed) { message = 'Your block was removed. This does not restart a conversation.'; await loadBlocks(); } }
    catch (error) { if (!disposed) message = safeMessage(error); }
    finally { if (!disposed) busy = false; }
  }
  onMount(() => {
    const refreshExpiry = () => { now = Date.now(); if (draft && !receipt && Date.parse(draft.expires_at) <= now) expire(); };
    const timer = setInterval(refreshExpiry, 1000);
    document.addEventListener('visibilitychange', refreshExpiry);
    return () => { clearInterval(timer); document.removeEventListener('visibilitychange', refreshExpiry); };
  });
  onDestroy(() => { disposed = true; clearDraft(); blocks = []; receipt = null; });
</script>

<section class="safety" aria-labelledby="conversation-safety-title">
  <h3 id="conversation-safety-title">Your safety controls</h3>
  {#if enabled && active}
    <div class="actions"><button class="danger" disabled={busy} on:click={() => begin(true)}>Report &amp; Block</button><button disabled={busy} on:click={() => begin(false)}>Report</button><button disabled={busy} on:click={blockOnly}>Block partner</button></div>
    <p class="help">Report &amp; Block immediately stops this interaction and freezes eligible text for two minutes. Reporting is available while your partner reconnects.</p>
  {/if}
  {#if recent}<button disabled={busy} on:click={() => begin(false, true)}>Report recent conversation</button><p class="help">Available for ten minutes on this server. The ended conversation’s text has been cleared; this report contains a statement and reference metadata only.</p>{/if}
  {#if message && !open}<p class="notice" role="status">{message}</p>{/if}
  <details><summary>Manage your blocks</summary><div class="block-content">
    <p class="help">Account-to-account blocks persist. Blocks involving guests are temporary unless both become accounts in-session. A new guest session or different account may bypass an identity-based block. You can see only blocks you created.</p>
    <button disabled={loadingBlocks || busy} on:click={loadBlocks}>{loadingBlocks ? 'Loading…' : blocksLoaded ? 'Refresh blocks' : 'Load your blocks'}</button>
    {#if blocksLoaded && !blocks.length}<p>No blocks to show.</p>{/if}
    <ul>{#each blocks as block (block.ref)}<li><div><strong>{block.display_name || 'Previous partner'}</strong><p class="help">{block.pending ? 'Local block active; storage pending' : block.durable ? 'Saved to your account' : 'Temporary guest block'}</p></div><button disabled={busy} on:click={() => unblock(block.ref)}>Unblock<span class="sr-only"> {block.display_name || 'previous partner'}</span></button></li>{/each}</ul>
  </div></details>
  <a href="/grievance">Review grievance options</a>
  <p class="help">This controlled release has no public grievance submission service or guaranteed monitoring. Real-user use requires approved operator coverage.</p>
</section>

<Dialog id="safety-report" {open} title={receipt ? 'Report received' : 'Report a concern'} on:close={closeForm}>
  {#if message}<p class="notice" role="status">{message}</p>{/if}
  {#if receipt}
    <p>Case reference: <strong class="reference">{receipt.case_ref}</strong></p>
    <p class="help">A report is an allegation for review, not proof or an automatic ban. No audio recording exists.</p>
  {:else if draft && !expired}
    <p class="help">Snapshot expires in {seconds} seconds. Closing this form discards its contents here.</p>
    {#if draft.metadata_only}<p class="notice">Metadata-only report. No transcript is available after this conversation ended.</p>{/if}
    <form on:submit={submit} class="report-form">
      <label for="report-category">Category</label><select id="report-category" bind:value={category} disabled={busy || Boolean(submission)}>{#each reportCategories as item}<option value={item[0]}>{item[1]}</option>{/each}</select>
      {#if draft.messages.length}<fieldset disabled={busy || Boolean(submission)}><legend>Select relevant server-attributed messages</legend><div class="evidence">{#each draft.messages as item (item.server_sequence)}<label class="evidence-item"><input type="checkbox" value={item.server_sequence} bind:group={selected} /><span><strong>{item.speaker === 'self' ? 'You' : 'Partner'}</strong><span class="evidence-text">{item.text}</span></span></label>{/each}</div></fieldset>{:else}<p class="help">No eligible text is available. You can submit your statement.</p>{/if}
      <label for="report-statement">Your statement <span>(separate from server-attributed messages)</span></label><textarea id="report-statement" rows="4" bind:value={statement} maxlength="4000" autocomplete="off" disabled={busy || Boolean(submission)} placeholder="Describe what happened. Avoid unnecessary personal information." />
      <p class="help">Up to 2,000 characters and 6 KiB. Your statement is labelled as your account of events. Moderators cannot replay unrecorded audio.</p>
      {#if statementProblem}<p class="error">{statementProblem}</p>{/if}
      {#if submission}<p class="help">Retry uses the same submission ID and details to avoid duplicate reports. Fields are locked for this retry.</p>{/if}
      <button class="danger" type="submit" disabled={busy || Boolean(statementProblem)}>{busy ? 'Submitting…' : submission ? 'Retry same submission' : 'Submit report'}</button>
    </form>
  {:else if busy}<p>Preparing the safety request…</p>{/if}
  <p class="grievance"><a href="/support">Check support availability or submit a formal concern</a>. A complaint is confirmed only after its saved case receipt is returned. <a href="/grievance">Grievance process</a>.</p>
  <button slot="actions" on:click={closeForm}>Close</button>
</Dialog>

<style>
  .safety, .report-form, .block-content { display: grid; gap: 0.75rem; min-width: 0; }
  .safety { border-top: 1px solid var(--border); padding-top: 1rem; }
  h3, p { margin: 0; }
  h3 { font-size: 1.1rem; }
  .actions { display: flex; flex-wrap: wrap; gap: 0.5rem; }
  button, select, textarea { min-height: 2.875rem; min-width: 0; padding: 0.65rem 0.8rem; border: 1px solid var(--border-strong); border-radius: var(--radius-md); background: var(--surface); color: var(--text-primary); font: inherit; }
  button { cursor: pointer; font-weight: 650; min-width: 2.75rem; }
  button:disabled { opacity: 0.6; cursor: not-allowed; }
  .danger { color: var(--danger); border-color: #efb9b9; }
  .help, label span, .grievance { font-size: 0.8rem; color: var(--text-secondary); }
  .notice { padding: 0.75rem; border-radius: var(--radius-sm); background: var(--surface-subtle); margin-bottom: 0.75rem; }
  .report-form { margin-top: 0.75rem; }
  .report-form label { font-weight: 650; }
  select, textarea { width: 100%; }
  textarea { resize: vertical; }
  fieldset { min-width: 0; border: 1px solid var(--border); border-radius: var(--radius-md); padding: 0.5rem; }
  legend { font-size: 0.85rem; }
  .evidence { max-height: 14rem; overflow-y: auto; overscroll-behavior: contain; }
  .evidence-item { display: flex; align-items: flex-start; gap: 0.6rem; min-height: 2.75rem; padding: 0.75rem 0.25rem; }
  .evidence-item input { flex-shrink: 0; width: 1.125rem; height: 1.125rem; margin-top: 0.15rem; accent-color: var(--accent); }
  .evidence-item span { min-width: 0; }
  .evidence-text { display: block; white-space: pre-wrap; overflow-wrap: anywhere; unicode-bidi: plaintext; font-weight: 400; color: var(--text-primary); }
  .reference { overflow-wrap: anywhere; }
  .error { color: var(--danger); }
  summary { min-height: 2.75rem; padding-block: 0.6rem; cursor: pointer; font-weight: 650; }
  ul { list-style: none; margin: 0; padding: 0; }
  li { display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; padding: 0.75rem 0; border-top: 1px solid var(--border); }
  li div { min-width: 0; overflow-wrap: anywhere; }
  .grievance { margin-top: 1rem; }
</style>
