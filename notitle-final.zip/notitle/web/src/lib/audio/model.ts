export interface CallView {
  call_ref: string;
  state: 'REQUESTED' | 'RINGING' | 'ACCEPTED' | 'CONNECTING' | 'CONNECTED' | 'ENDED';
  direction: 'incoming' | 'outgoing';
  offer_owner: 'self' | 'peer';
  expires_at?: string;
}
export interface RelayCredentials {
  urls: string[]; username: string; credential: string;
  expires_at: string; refresh_at: string;
  relay_addresses: string[]; relay_min_port: number; relay_max_port: number;
}
export interface AudioState {
  phase: 'idle' | 'requesting' | 'ringing' | 'permission' | 'connecting' | 'connected' | 'ended' | 'error';
  call: CallView | null; muted: boolean; message: string; playbackBlocked: boolean;
}
export const initialAudio = (): AudioState => ({ phase: 'idle', call: null, muted: false, message: '', playbackBlocked: false });
const object = (value: unknown): value is Record<string, unknown> => Boolean(value) && typeof value === 'object' && !Array.isArray(value);
export const callRef = (value: unknown): value is string => typeof value === 'string' && /^[A-Za-z0-9_-]{16,128}$/u.test(value);
export function parseCall(value: unknown): CallView | null {
  if (!object(value) || !callRef(value.call_ref) || !['REQUESTED', 'RINGING', 'ACCEPTED', 'CONNECTING', 'CONNECTED', 'ENDED'].includes(String(value.state)) || !['incoming', 'outgoing'].includes(String(value.direction)) || !['self', 'peer'].includes(String(value.offer_owner))) return null;
  if (value.expires_at !== undefined && (typeof value.expires_at !== 'string' || !Number.isFinite(Date.parse(value.expires_at)))) return null;
  return { call_ref: value.call_ref, state: value.state as CallView['state'], direction: value.direction as CallView['direction'], offer_owner: value.offer_owner as CallView['offer_owner'], ...(typeof value.expires_at === 'string' ? { expires_at: value.expires_at } : {}) };
}
/** Only server-issued TURN configurations enter RTCPeerConnection. There is no
 * user supplied URL, STUN fallback, storage, or credential-bearing telemetry. */
export function parseCredentials(value: unknown, now: number): RelayCredentials | null {
  if (!object(value) || !Array.isArray(value.urls) || value.urls.length < 1 || value.urls.length > 6 || value.urls.some((url) => typeof url !== 'string' || !/^(turn:[a-zA-Z0-9.-]+:3478\?transport=(udp|tcp)|turns:[a-zA-Z0-9.-]+:443\?transport=tcp)$/u.test(url))) return null;
  if (typeof value.username !== 'string' || !/^[A-Za-z0-9:_-]{16,160}$/u.test(value.username) || typeof value.credential !== 'string' || value.credential.length < 16 || value.credential.length > 256) return null;
  if (typeof value.expires_at !== 'string' || typeof value.refresh_at !== 'string' || !Number.isFinite(Date.parse(value.expires_at)) || !Number.isFinite(Date.parse(value.refresh_at)) || Date.parse(value.expires_at) <= now || Date.parse(value.refresh_at) >= Date.parse(value.expires_at)) return null;
  if (!Array.isArray(value.relay_addresses) || !value.relay_addresses.length || value.relay_addresses.length > 16 || value.relay_addresses.some((item) => typeof item !== 'string' || !/^[0-9a-fA-F:.]{3,64}$/u.test(item))) return null;
  if (!Number.isInteger(value.relay_min_port) || !Number.isInteger(value.relay_max_port) || Number(value.relay_min_port) < 1024 || Number(value.relay_max_port) > 65535 || Number(value.relay_min_port) > Number(value.relay_max_port)) return null;
  return { urls: [...value.urls] as string[], username: value.username, credential: value.credential, expires_at: value.expires_at, refresh_at: value.refresh_at, relay_addresses: [...value.relay_addresses] as string[], relay_min_port: Number(value.relay_min_port), relay_max_port: Number(value.relay_max_port) };
}
export function microphoneMessage(error: unknown): string {
  const name = error && typeof error === 'object' && 'name' in error ? String(error.name) : '';
  if (name === 'NotAllowedError' || name === 'SecurityError') return 'Microphone permission was denied. You can continue in text or allow access in your browser and call again.';
  if (name === 'NotFoundError') return 'No microphone was found. Connect one or continue in text.';
  if (name === 'NotReadableError' || name === 'AbortError') return 'Your microphone is unavailable or in use. Close other apps or continue in text.';
  return 'Audio could not connect safely. Continue in text, or try a new call.';
}
