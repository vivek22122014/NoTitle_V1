<script lang="ts">
  import type { RealtimeClient } from '../realtime/client';
  import type { LiveState } from '../realtime/model';
  export let realtime: RealtimeClient | null;
  export let live: LiveState;
  $: audio = live.audio;
  $: call = audio.call;
  $: available = live.status === 'connected' && live.snapshot?.audio_enabled && live.snapshot.interaction?.peer_connected;
  $: incoming = call?.direction === 'incoming' && ['REQUESTED', 'RINGING'].includes(call.state);
  $: active = Boolean(call) || audio.phase === 'requesting';
</script>

<section class="audio-controls" aria-label="Audio call controls">
  <div class="title"><h3>Audio call</h3>{#if audio.phase === 'connected'}<span class="connected">{audio.muted ? 'Microphone muted' : 'Connected'}</span>{/if}</div>
  {#if audio.message}<p role="status" aria-live="polite">{audio.message}</p>{:else}<p>Choose Call to invite your partner. Both people must agree before audio connects.</p>{/if}
  <div class="actions">
    {#if incoming}
      <button class="primary" disabled={!available || Boolean(live.snapshot?.maintenance) || audio.phase === 'permission'} on:click={() => realtime?.audio.accept()}>Accept audio call</button>
      <button disabled={!available} on:click={() => realtime?.audio.decline()}>Decline audio call</button>
    {:else if active}
      {#if ['connecting', 'connected'].includes(audio.phase)}<button aria-pressed={audio.muted} on:click={() => realtime?.audio.toggleMute()}>{audio.muted ? 'Unmute microphone' : 'Mute microphone'}</button>{/if}
      <button class="danger" on:click={() => realtime?.audio.stop()}>End audio call</button>
    {:else}
      <button class="primary" disabled={!available || live.pending || Boolean(live.snapshot?.maintenance)} on:click={() => realtime?.audio.request()}>Call partner</button>
    {/if}
  </div>
  <p class="help">Audio is optional for guests and accounts. NoTitle does not record or transcribe calls. The other person could still record what they hear. Keep this page open; calls may stop when you switch apps or lock your screen. After a connection interruption, a new call needs fresh acceptance.</p>
</section>

<style>
  .audio-controls { display: grid; gap: 0.75rem; min-width: 0; padding: 1rem; border: 1px solid var(--border); border-radius: var(--radius-md); background: var(--surface-subtle); }
  .title, .actions { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 0.65rem; }
  .actions { justify-content: flex-start; }
  h3 { margin: 0; font-size: 1.1rem; } p { margin: 0; overflow-wrap: anywhere; color: var(--text-secondary); }
  .help, .connected { font-size: 0.8rem; } .connected { color: var(--success); font-weight: 650; }
  button { min-height: 2.875rem; min-width: 2.75rem; padding: 0.65rem 0.8rem; border: 1px solid var(--border-strong); border-radius: var(--radius-md); background: var(--surface); color: var(--text-primary); font: inherit; font-weight: 650; cursor: pointer; }
  .primary { color: white; background: var(--accent-strong); border-color: var(--accent-strong); } .danger { color: var(--danger); }
  button:disabled { opacity: 0.6; cursor: not-allowed; }
</style>
