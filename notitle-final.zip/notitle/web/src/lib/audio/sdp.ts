import type { RelayCredentials } from './model.ts';

/** Reject unexpected candidates before signaling or adding them to a browser.
 * Related address/port describe the user's network and are replaced locally. */
export function relayCandidate(candidate: string, policy: RelayCredentials, sanitize = false): string {
  if (candidate.length > 1024 || /[\r\n\u0000]/u.test(candidate)) throw new Error('Invalid relay candidate');
  const fields = candidate.trim().split(/\s+/u);
  if (!/^candidate:[A-Za-z0-9+/_.-]{1,32}$/u.test(fields[0]) || fields[1] !== '1' || fields[2]?.toLowerCase() !== 'udp' || !/^\d+$/u.test(fields[3]) || fields[6] !== 'typ' || fields[7] !== 'relay' || !policy.relay_addresses.includes(fields[4]) || !/^\d+$/u.test(fields[5]) || Number(fields[5]) < policy.relay_min_port || Number(fields[5]) > policy.relay_max_port || (fields.length - 8) % 2) throw new Error('Relay candidate required');
  const output = fields.slice(0, 8);
  const seen = new Set<string>();
  for (let index = 8; index < fields.length; index += 2) {
    const key = fields[index], value = fields[index + 1];
    if (seen.has(key) || !['raddr', 'rport', 'generation', 'ufrag', 'network-id', 'network-cost'].includes(key)) throw new Error('Unsupported candidate');
    seen.add(key);
    if (key === 'raddr') { if (!sanitize && !['0.0.0.0', '::'].includes(value)) throw new Error('Unsafe related address'); output.push(key, fields[4].includes(':') ? '::' : '0.0.0.0'); }
    else if (key === 'rport') { if (!sanitize && !['0', '9'].includes(value)) throw new Error('Unsafe related port'); output.push(key, '0'); }
    else if (key === 'ufrag') { if (!/^[A-Za-z0-9+/]{4,256}$/u.test(value)) throw new Error('Invalid ICE token'); output.push(key, value); }
    else if (!/^\d{1,10}$/u.test(value)) throw new Error('Invalid candidate extension');
    // Network-id/cost and generation are local hints, unnecessary on the wire.
  }
  if (seen.has('raddr') !== seen.has('rport')) throw new Error('Incomplete related address');
  return output.join(' ');
}
/** Sanitize all SDP address fields, including candidates embedded by browsers.
 * The backend independently parses and validates the complete SDP. */
export function relaySDP(sdp: string, policy: RelayCredentials, sanitize = false): string {
  if (!sdp || new TextEncoder().encode(sdp).length > 60000 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/u.test(sdp)) throw new Error('Invalid SDP');
  const lines = sdp.split(/\r?\n/u).filter(Boolean);
  const sections = lines.filter((line) => line.startsWith('m='));
  if (sections.length !== 1 || !/^m=audio \d+ UDP\/TLS\/RTP\/SAVPF(?: \d+)+$/u.test(sections[0]) || lines.filter((line) => line === 'a=mid:0').length !== 1 || !lines.includes('a=rtcp-mux') || !lines.includes('a=sendrecv') || !lines.some((line) => /^a=rtpmap:\d+ opus\/48000\/2$/iu.test(line)) || lines.some((line) => /^a=rtpmap:/u.test(line) && !/^a=rtpmap:\d+ opus\/48000\/2$/iu.test(line))) throw new Error('One Opus audio section required');
  return lines.map((line) => {
    if (line.startsWith('a=candidate:')) return 'a=' + relayCandidate(line.slice(2), policy, sanitize);
    if (line.startsWith('o=')) { if (!sanitize && !/^o=[^\s]+ \d+ \d+ IN IP[46] (0\.0\.0\.0|127\.0\.0\.1|::)$/u.test(line)) throw new Error('Unsafe origin'); const version = line.split(/\s+/u)[2]; if (!/^\d+$/u.test(version)) throw new Error('Invalid origin version'); return `o=- 0 ${version} IN IP4 127.0.0.1`; }
    if (line.startsWith('c=')) { if (!sanitize && !/^c=IN IP[46] (0\.0\.0\.0|127\.0\.0\.1|::)$/u.test(line)) throw new Error('Unsafe connection address'); return 'c=IN IP4 0.0.0.0'; }
    if (line.startsWith('a=rtcp:')) { if (!sanitize && !/^a=rtcp:(0|9)( IN IP[46] (0\.0\.0\.0|127\.0\.0\.1|::))?$/u.test(line)) throw new Error('Unsafe RTCP address'); return 'a=rtcp:9 IN IP4 0.0.0.0'; }
    if (/^a=(remote-candidates|ice-options):/u.test(line) && line.startsWith('a=remote-candidates:')) throw new Error('Unexpected network hint');
    return line;
  }).join('\r\n') + '\r\n';
}
