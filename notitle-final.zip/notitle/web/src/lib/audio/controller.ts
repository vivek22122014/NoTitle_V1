import { initialAudio, microphoneMessage, parseCredentials } from './model.ts';
import type { AudioState, CallView, RelayCredentials } from './model.ts';
import { relayCandidate, relaySDP } from './sdp.ts';

type Timer = ReturnType<typeof setTimeout>;
export interface AudioScope { admission?: boolean; connected: boolean; enabled: boolean; key: string; peerConnected: boolean; friendRef?: string; call?: CallView }
export interface AudioRuntime {
  now(): number;
  later(fn: () => void, ms: number): Timer;
  cancel(timer: Timer): void;
  microphone(): Promise<MediaStream>;
  peer(configuration: RTCConfiguration): RTCPeerConnection;
  opus(): RTCRtpCodec[];
  remote(stream: MediaStream | null): void;
}
type Signal = { type: string; payload: Record<string, unknown> };
/** One audio controller belongs to the realtime owner, not a route component.
 * No mount/reconnect/snapshot is microphone consent. Credentials and SDP live
 * only in this controller. Closing invalidates every outstanding async task. */
export class AudioController {
  state = initialAudio();
  private scope: AudioScope = { connected: false, enabled: false, key: '', peerConnected: false };
  private consent: { key?: string; friend?: string; call?: string; expires: number } | null = null;
  private ended = new Set<string>();
  private serial = 0;
  private pc: RTCPeerConnection | null = null;
  private stream: MediaStream | null = null;
  private remoteStream: MediaStream | null = null;
  private negotiation = 0;
  private cancelledRequestKey = '';
  private credentials: RelayCredentials | null = null;
  private signals: Signal[] = [];
  private outgoing: { payload: Record<string, unknown>; ufrag: string }[] = [];
  private localUfrag = '';
  private signalChain = Promise.resolve();
  private localReady = false;
  private remoteReady = false;
  private starting = false;
  private timer: Timer | undefined;
  private expiry: Timer | undefined;
  private consentTimer: Timer | undefined;
  private runtime: AudioRuntime;
  private send: (type: string, payload: Record<string, unknown>) => boolean;
  private changed: (state: AudioState) => void;
  constructor(send: (type: string, payload: Record<string, unknown>) => boolean, changed: (state: AudioState) => void, runtime: Partial<AudioRuntime> = {}) {
    this.send = send; this.changed = changed;
    this.runtime = {
      now: runtime.now ?? Date.now, later: runtime.later ?? ((fn, ms) => setTimeout(fn, ms)), cancel: runtime.cancel ?? clearTimeout,
      microphone: runtime.microphone ?? (() => navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true }, video: false })),
      peer: runtime.peer ?? ((configuration) => new RTCPeerConnection(configuration)),
      opus: runtime.opus ?? (() => RTCRtpReceiver.getCapabilities('audio')?.codecs.filter((codec) => codec.mimeType.toLowerCase() === 'audio/opus') ?? []),
      remote: runtime.remote ?? (() => {})
    };
  }
  private emit(patch: Partial<AudioState>): void { this.state = { ...this.state, ...patch }; this.changed(this.state); }
  private clear(timer: Timer | undefined): void { if (timer !== undefined) this.runtime.cancel(timer); }
  private remember(ref?: string): void { if (ref) { this.ended.add(ref); if (this.ended.size > 64) this.ended.delete(this.ended.values().next().value!); } }
  private release(): void {
    this.serial++; this.starting = false; this.clear(this.timer); this.timer = undefined; this.clear(this.expiry); this.expiry = undefined;
    this.clear(this.consentTimer); this.consentTimer = undefined;
    const pc = this.pc; this.pc = null;
    if (pc) { pc.onicecandidate = null; pc.onconnectionstatechange = null; pc.oniceconnectionstatechange = null; pc.ontrack = null; pc.close(); }
    if (this.stream) for (const track of this.stream.getTracks()) { track.onended = null; track.stop(); }
    if (this.remoteStream) for (const track of this.remoteStream.getTracks()) { track.onended = null; track.stop(); }
    this.stream = null; this.remoteStream = null; this.negotiation = 0; this.runtime.remote(null); this.credentials = null; this.signals = []; this.outgoing = [];
    this.localReady = false; this.localUfrag = ''; this.remoteReady = false; this.signalChain = Promise.resolve();
  }
  stop(message = 'Audio ended. You can continue in text.', notify = true): void {
    const ref = this.state.call?.call_ref;
    if (!ref && this.state.phase === 'requesting') this.cancelledRequestKey = this.scope.key;
    if (notify && ref && this.scope.connected) this.send('call.end', { call_ref: ref });
    this.remember(ref); this.release(); this.consent = null;
    this.emit({ phase: 'ended', call: null, muted: false, playbackBlocked: false, message });
  }
  dispose(): void { this.stop('Audio stopped.', true); }
  private fail(message: string): void { this.stop(message); this.emit({ phase: 'error' }); }
  private setConsent(consent: NonNullable<AudioController['consent']>): void {
    this.clear(this.consentTimer); this.consent = consent;
    this.consentTimer = this.runtime.later(() => {
      this.consentTimer = undefined;
      if (this.consent && !this.pc) this.stop('The call request expired. Start a new call when you are ready.');
    }, Math.max(0, consent.expires - this.runtime.now()));
  }
  request(): boolean {
    if (this.scope.admission === false || !this.scope.connected || !this.scope.enabled || !this.scope.peerConnected || !this.scope.key || this.state.call || this.state.phase === 'requesting') return false;
    this.cancelledRequestKey = '';
    this.setConsent({ key: this.scope.key, expires: this.runtime.now() + 45000 });
    if (!this.send('call.request', {})) { this.consent = null; this.clear(this.consentTimer); return false; }
    this.emit({ phase: 'requesting', message: 'Calling your partner. They have 30 seconds to accept.', muted: false }); return true;
  }
  accept(): boolean {
    const call = this.state.call;
    if (this.scope.admission === false || !call || call.direction !== 'incoming' || !['RINGING', 'REQUESTED'].includes(call.state) || !this.scope.connected || !this.scope.peerConnected || !this.scope.enabled) return false;
    this.setConsent({ key: this.scope.key, call: call.call_ref, expires: this.runtime.now() + 45000 });
    if (!this.send('call.accept', { call_ref: call.call_ref })) { this.consent = null; this.clear(this.consentTimer); return false; }
    this.emit({ phase: 'permission', message: 'Waiting for the secure relay. Your browser will then ask for microphone access.' }); return true;
  }
  decline(): void {
    if (this.state.call && this.scope.connected) this.send('call.decline', { call_ref: this.state.call.call_ref });
    this.stop('Call declined. You can continue in text.', false);
  }
  authorizeFriend(friend: string, expires: number): void { this.setConsent({ friend, expires: Math.min(expires, this.runtime.now() + 45000) }); }
  cancelFriendConsent(): void { if (this.consent?.friend && !this.state.call) { this.consent = null; this.clear(this.consentTimer); } }
  update(scope: AudioScope): void {
    const previousKey = this.scope.key; this.scope = scope;
    if (!scope.connected || !scope.enabled || (scope.key && !scope.peerConnected)) {
      if (this.state.call || this.pc || this.starting || this.consent) this.stop('Audio stopped when the connection changed. A new call needs acceptance.', false);
      return;
    }
    if (previousKey && previousKey !== scope.key) {
      const friendConsent = this.consent?.friend && this.consent.friend === scope.friendRef ? this.consent : null;
      if (this.state.call || this.pc || this.starting || this.consent) this.stop('The conversation changed. Audio stopped.', false);
      if (friendConsent) this.setConsent(friendConsent);
    }
    const call = scope.call;
    if (!call) {
      if (this.state.call) this.stop('Audio ended. You can continue in text.', false);
      return;
    }
    if (call.state === 'ENDED') { this.remember(call.call_ref); this.stop('Audio ended. You can continue in text.', false); return; }
    if (this.ended.has(call.call_ref)) return;
    if (this.cancelledRequestKey === scope.key && call.direction === 'outgoing') {
      this.cancelledRequestKey = ''; this.remember(call.call_ref); this.send('call.end', { call_ref: call.call_ref }); return;
    }
    const previousState = this.state.call?.state;
    if (this.state.call && this.state.call.call_ref !== call.call_ref) this.stop('The previous call ended.', false);
    this.emit({ call });
    if (['REQUESTED', 'RINGING'].includes(call.state)) {
      this.emit({ phase: 'ringing', message: call.direction === 'incoming' ? 'Your partner would like an audio call. Your microphone is off until you accept.' : 'Calling your partner. They have 30 seconds to accept.' });
      if (!this.timer) this.timer = this.runtime.later(() => this.stop('The call was not accepted in time. You can continue in text.'), Math.min(30000, Math.max(0, call.expires_at ? Date.parse(call.expires_at) - this.runtime.now() : 30000)));
    } else {
      if (previousState === 'REQUESTED' || previousState === 'RINGING') { this.clear(this.timer); this.timer = undefined; }
      if (!this.pc && !this.starting) this.emit({ phase: 'permission', message: 'Preparing the secure relay. No audio is sent before both people accept.' });
    }
  }
  credentialsReceived(ref: string, negotiation: number, value: unknown): void {
    const call = this.state.call;
    if (!Number.isSafeInteger(negotiation) || negotiation <= this.negotiation || !call || ref !== call.call_ref || !['ACCEPTED', 'CONNECTING', 'CONNECTED'].includes(call.state) || this.ended.has(ref) || !this.scope.connected || !this.scope.enabled) return;
    const consent = this.consent;
    if (!consent || (consent.call && consent.call !== ref) || (!this.pc && this.runtime.now() >= consent.expires) || (consent.key !== this.scope.key && (!consent.friend || consent.friend !== this.scope.friendRef))) { this.fail('This call needs a fresh Call or Accept action. Continue in text or call again.'); return; }
    const credentials = parseCredentials(value, this.runtime.now());
    if (!credentials) { this.fail('The audio relay is unavailable. Continue in text.'); return; }
    this.credentials = credentials; this.negotiation = negotiation;
    this.clear(this.expiry); this.expiry = this.runtime.later(() => this.fail('The audio authorization expired. Continue in text or start a new call.'), Date.parse(credentials.expires_at) - this.runtime.now());
    if (this.pc) {
      try {
        if (this.pc.signalingState !== 'stable') throw new Error('Negotiation incomplete');
        this.pc.setConfiguration(this.configuration(credentials));
        this.localReady = false; this.localUfrag = ''; this.remoteReady = false; this.outgoing = [];
        this.signals = this.signals.filter((item) => Number(item.payload.negotiation) >= negotiation);
        this.clear(this.timer); this.timer = this.runtime.later(() => this.fail('The audio relay renewal timed out. Continue in text.'), 30000);
        if (call.offer_owner === 'self') void this.makeOffer(ref, this.serial, negotiation, true);
        this.drainSignals();
      } catch { this.fail('The relay could not renew this call. Continue in text.'); }
      // Only this server-authorized same-call renewal may restart ICE.
      return;
    }
    if (!this.starting) void this.start(ref);
  }
  private configuration(credentials: RelayCredentials): RTCConfiguration {
    return { iceServers: [{ urls: [...credentials.urls], username: credentials.username, credential: credentials.credential }], iceTransportPolicy: 'relay', bundlePolicy: 'max-bundle', rtcpMuxPolicy: 'require', iceCandidatePoolSize: 0 };
  }
  private active(serial: number, ref: string): boolean { return serial === this.serial && this.state.call?.call_ref === ref && this.scope.connected && !this.ended.has(ref); }
  private async start(ref: string): Promise<void> {
    this.starting = true; const serial = this.serial;
    this.emit({ phase: 'permission', message: 'Allow microphone access to join the call. Text, Next and End remain available.' });
    try {
      const stream = await this.runtime.microphone();
      if (!this.active(serial, ref)) { for (const track of stream.getTracks()) track.stop(); return; }
      // Timer callbacks can be delayed by mobile suspension or a permission
      // dialog. Recheck absolute authorization before touching a peer transport.
      if (!this.consent || this.runtime.now() >= this.consent.expires || !this.credentials || this.runtime.now() >= Date.parse(this.credentials.expires_at)) {
        for (const track of stream.getTracks()) track.stop();
        this.fail('Microphone permission arrived after this call expired. Choose Call or Accept again.'); return;
      }
      if (stream.getVideoTracks().length || stream.getAudioTracks().length !== 1) { for (const track of stream.getTracks()) track.stop(); throw new Error('Audio-only capture required'); }
      this.stream = stream;
      for (const track of stream.getTracks()) track.onended = () => { if (this.active(serial, ref)) this.fail('Your microphone disconnected. Continue in text or start a new call.'); };
      this.clear(this.consentTimer); this.consentTimer = undefined;
      const credentials = this.credentials!;
      const pc = this.runtime.peer(this.configuration(credentials)); this.pc = pc;
      const transceiver = pc.addTransceiver(stream.getAudioTracks()[0], { direction: 'sendrecv', streams: [stream] });
      const opus = this.runtime.opus();
      if (!opus.length || typeof transceiver.setCodecPreferences !== 'function') throw new Error('Opus configuration unavailable');
      transceiver.setCodecPreferences(opus);
      pc.onicecandidate = (event) => {
        if (!this.active(serial, ref) || !event.candidate) return;
        try {
          const ufrag = event.candidate.usernameFragment ?? /(?:^| )ufrag ([A-Za-z0-9+/]+)(?: |$)/u.exec(event.candidate.candidate)?.[1];
          if (!ufrag || !/^[A-Za-z0-9+/]{4,256}$/u.test(ufrag)) throw new Error('ICE generation unavailable');
          if (this.localUfrag && ufrag !== this.localUfrag) return;
          if (event.candidate.sdpMid !== '0' || event.candidate.sdpMLineIndex !== 0) throw new Error('Unexpected media section');
          const payload = { call_ref: ref, negotiation: this.negotiation, candidate: relayCandidate(event.candidate.candidate, this.credentials!, true), sdp_mid: '0', sdp_mline_index: 0 };
          if (this.localReady) { if (!this.send('webrtc.ice', payload)) this.fail('Audio signaling was interrupted. Continue in text.'); }
          else if (this.outgoing.length < 64) this.outgoing.push({ payload, ufrag });
          else this.fail('The audio relay could not connect. Continue in text.');
        } catch { this.fail('The browser could not provide a private relay path. Continue in text.'); }
      };
      pc.ontrack = (event) => {
        if (!this.active(serial, ref)) { event.track.stop(); return; }
        if (event.track.kind !== 'audio') { event.track.stop(); this.fail('An unexpected media stream was rejected.'); return; }
        event.track.onended = () => { if (this.active(serial, ref)) this.stop('Your partner’s audio ended. You can continue in text.'); };
        this.remoteStream = event.streams[0] ?? new MediaStream([event.track]);
        this.runtime.remote(this.remoteStream);
      };
      const connected = () => {
        if (!this.active(serial, ref) || !this.remoteReady || !this.localReady || pc.connectionState !== 'connected') return;
        this.clear(this.timer); this.timer = undefined;
        if (!this.send('call.connected', { call_ref: ref, negotiation: this.negotiation })) { this.fail('Audio signaling was interrupted.'); return; }
        this.emit({ phase: 'connected', message: 'Audio connected. NoTitle does not record or transcribe your call.' });
      };
      pc.oniceconnectionstatechange = connected;
      pc.onconnectionstatechange = () => {
        if (!this.active(serial, ref)) return;
        if (pc.connectionState === 'connected') {
          connected();
        } else if (['disconnected', 'failed', 'closed'].includes(pc.connectionState)) this.fail('The audio connection ended. Continue in text or start a new accepted call.');
      };
      this.starting = false; this.emit({ phase: 'connecting', message: 'Connecting through the secure audio relay…' });
      this.timer = this.runtime.later(() => this.fail('Audio could not connect on this network. You can continue in text.'), 30000);
      if (this.state.call?.offer_owner === 'self') {
        await this.makeOffer(ref, serial, this.negotiation, false);
      }
      this.drainSignals();
    } catch (error) { if (this.active(serial, ref)) this.fail(microphoneMessage(error)); }
  }
  private async makeOffer(ref: string, serial: number, negotiation: number, restart: boolean): Promise<void> {
    try {
      const pc = this.pc!;
      const offer = await pc.createOffer({ iceRestart: restart }); if (!this.active(serial, ref) || this.negotiation !== negotiation) return;
      await pc.setLocalDescription(offer); if (!this.active(serial, ref) || this.negotiation !== negotiation) return;
      this.sendDescription('webrtc.offer', pc.localDescription!.sdp, ref);
    } catch { if (this.active(serial, ref) && this.negotiation === negotiation) this.fail('The audio relay could not connect. Continue in text.'); }
  }
  private sendDescription(type: string, sdp: string, ref: string): void {
    if (!this.send(type, { call_ref: ref, negotiation: this.negotiation, sdp: relaySDP(sdp, this.credentials!, true) })) throw new Error('Signaling unavailable');
    this.localUfrag = /^a=ice-ufrag:([A-Za-z0-9+/]{4,256})$/mu.exec(sdp.replace(/\r/gu, ''))?.[1] ?? '';
    if (!this.localUfrag) throw new Error('ICE generation unavailable');
    this.localReady = true;
    for (const { payload, ufrag } of this.outgoing) if (ufrag === this.localUfrag && !this.send('webrtc.ice', payload)) throw new Error('Signaling unavailable');
    this.outgoing = [];
  }
  signal(type: string, payload: Record<string, unknown>): void {
    if (!Number.isSafeInteger(payload.negotiation) || Number(payload.negotiation) < Math.max(1, this.negotiation) || Number(payload.negotiation) > this.negotiation + 1 || !this.state.call || payload.call_ref !== this.state.call.call_ref || !this.scope.connected || this.ended.has(this.state.call.call_ref)) return;
    if (!['webrtc.offer', 'webrtc.answer', 'webrtc.ice'].includes(type)) return;
    if (this.signals.length >= 64) { this.fail('Too many audio updates. Continue in text.'); return; }
    this.signals.push({ type, payload }); this.drainSignals();
  }
  private drainSignals(): void {
    if (!this.pc || !this.credentials || this.starting) return;
    const serial = this.serial, ref = this.state.call!.call_ref;
    this.signalChain = this.signalChain.then(async () => {
      while (this.signals.length && this.active(serial, ref)) {
        this.signals = this.signals.filter((item) => Number(item.payload.negotiation) >= this.negotiation);
        const pc = this.pc!, next = this.signals.find((item) => item.payload.negotiation === this.negotiation);
        if (!next) return;
        const negotiation = this.negotiation;
        // A bounded early ICE queue waits until a matching description arrives.
        const index = next.type === 'webrtc.ice' && !this.remoteReady ? this.signals.findIndex((item) => item.payload.negotiation === negotiation && item.type !== 'webrtc.ice') : this.signals.indexOf(next);
        if (index < 0) return;
        const { type, payload } = this.signals.splice(index, 1)[0];
        if (type === 'webrtc.ice') {
          if (payload.sdp_mid !== '0' || payload.sdp_mline_index !== 0 || typeof payload.candidate !== 'string') throw new Error('Invalid ICE');
          await pc.addIceCandidate({ candidate: relayCandidate(payload.candidate, this.credentials!), sdpMid: '0', sdpMLineIndex: 0 });
        } else {
          const offer = type === 'webrtc.offer';
          if (this.remoteReady || (offer ? this.state.call?.offer_owner !== 'peer' : this.state.call?.offer_owner !== 'self') || typeof payload.sdp !== 'string') throw new Error('Unexpected negotiation');
          await pc.setRemoteDescription({ type: offer ? 'offer' : 'answer', sdp: relaySDP(payload.sdp, this.credentials!) });
          if (!this.active(serial, ref) || this.negotiation !== negotiation) return;
          this.remoteReady = true;
          if (offer) {
            const answer = await pc.createAnswer(); if (!this.active(serial, ref) || this.negotiation !== negotiation) return;
            await pc.setLocalDescription(answer); if (!this.active(serial, ref) || this.negotiation !== negotiation) return;
            this.sendDescription('webrtc.answer', pc.localDescription!.sdp, ref);
          }
          if (pc.connectionState === 'connected' && this.localReady && this.remoteReady) {
            this.clear(this.timer); this.timer = undefined;
            if (!this.send('call.connected', { call_ref: ref, negotiation })) throw new Error('Signaling unavailable');
          }
        }
      }
    }).catch(() => { if (this.active(serial, ref)) this.fail('Audio negotiation was rejected. You can continue in text.'); });
  }
  toggleMute(): void {
    if (!this.stream) return;
    const muted = !this.state.muted; for (const track of this.stream.getAudioTracks()) track.enabled = !muted;
    this.emit({ muted });
  }
  playbackBlocked(blocked: boolean): void { this.emit({ playbackBlocked: blocked }); }
  commandRejected(code: string): void {
    this.fail(code === 'CAPACITY_REACHED' ? 'All audio slots are in use. Continue in text and try later.' : code === 'RATE_LIMITED' ? 'Please wait before starting another call. A declined call has a 15-second cooldown.' : 'The audio request was not accepted. Continue in text or try again.');
  }
}
