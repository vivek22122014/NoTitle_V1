<script lang="ts">
  import { onMount } from 'svelte';
  import { page } from '$app/stores';
  import { currentRealtime, subscribeRealtime } from '../realtime/session';
  import { initialState } from '../realtime/model';
  import CallControls from './CallControls.svelte';
  let live = initialState();
  let player: HTMLAudioElement;
  let stream: MediaStream | null = null;
  let attached: MediaStream | null = null;
  let serial = 0;
  async function play(): Promise<void> {
    const request = ++serial;
    if (!player || !stream) return;
    try { await player.play(); if (request === serial && stream) currentRealtime()?.audio.playbackBlocked(false); }
    catch { if (request === serial && stream) currentRealtime()?.audio.playbackBlocked(true); }
  }
  $: if (player && attached !== stream) {
    serial++; attached = stream; player.srcObject = stream;
    if (stream) void play(); else player.pause();
  }
  onMount(() => {
    const unsubscribe = subscribeRealtime((state) => { live = state; stream = currentRealtime()?.remoteAudioStream ?? null; });
    return () => { unsubscribe(); serial++; if (player) { player.pause(); player.srcObject = null; } };
  });
</script>

<audio bind:this={player} autoplay aria-label="Partner audio" />
{#if live.audio.playbackBlocked && stream}
  <aside class="playback" aria-label="Audio playback"><p>Your browser paused your partner’s audio. Tap to hear the call.</p><button on:click={play}>Play partner audio</button></aside>
{/if}
{#if $page.url.pathname !== '/chat' && live.snapshot?.audio_enabled && live.snapshot?.interaction && (live.audio.call || live.audio.phase === 'requesting')}
  <aside class="ongoing"><CallControls realtime={currentRealtime()} {live} /></aside>
{/if}

<style>
  audio { display: none; }
  .playback, .ongoing { padding: 0.75rem max(1rem, env(safe-area-inset-left)); }
  .playback { display: flex; flex-wrap: wrap; align-items: center; gap: 0.75rem; background: var(--surface-accent); }
  p { margin: 0; color: var(--text-primary); }
  button { min-height: 2.875rem; min-width: 2.75rem; padding: 0.65rem 0.8rem; border: 1px solid var(--border-strong); border-radius: var(--radius-md); background: var(--surface); color: var(--text-primary); font: inherit; font-weight: 650; cursor: pointer; }
</style>
