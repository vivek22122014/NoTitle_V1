# NoTitle — Phases 1–10

**Start with [START_HERE.md](START_HERE.md)** for the complete ZIP setup, local run/test sequence and links to the final environment, deployment and Cashfree guides. [FINAL_DELIVERY_STATUS.md](FINAL_DELIVERY_STATUS.md) is the latest handover record; earlier phase status files remain historical.

NoTitle is an India-first, mobile-first workplace conversation website for adults. This cumulative source package implements the foundation, public product/SEO, guest/account/profile/deletion identity layer, shared realtime matchmaking/reconnect, text, report/block, minimum private moderation, mutual connections, friend invitations, audio relay/call control, Premium checkout, the duration ledger refunds, full operations, privacy, observability and Phase 10 hardening/deployment controls from blueprint V3.2. Desktop and mobile use the same workflows.

**Status: source implementation delivered; full acceptance and public launch are pending.** Dependency-free tests ran here. Go, Docker, PostgreSQL, coturn, Svelte compilation, browser/device and Cashfree runtime checks remain pending. Production starts in maintenance; opening requires private owner authority and matching, current launch evidence. Audio, payments and full operations stay disabled in base templates until their configuration and acceptance gates are complete. See `PHASE10_STATUS.md` for current evidence; earlier phase records remain historical evidence.

## Start locally

Use Linux or Windows WSL2, Bash and Docker Engine/Desktop with Compose v2.30+. The full operations fixture checks also require Python 3.11+. The first setup requires approved access to image/package registries. Host Go and Node are not required for the container workflow. Keep the checkout on the WSL Linux filesystem.

From the extracted `notitle` directory:

```bash
./scripts/bootstrap.sh
```

Open **http://localhost:5173**. Bootstrap creates unique local secrets, generates authentic missing dependency locks, formats source and starts PostgreSQL, migrations, Go and Vite. Existing secrets are preserved. Review and commit generated `server/go.sum`, updated `server/go.mod`, `web/package-lock.json` and formatter changes.

Open **http://localhost:5173/design-preview** to inspect the interaction design. It is explicitly simulated and available only in development. It does not connect people, submit a complaint, charge money, access a microphone or persist conversations.

For Caddy and the built static site:

```bash
./scripts/bootstrap.sh static
```

Open **http://localhost:8080**. The design-preview URL returns 404 in this mode. No Node application server is used in production.

## What is implemented

| Area | Included |
| --- | --- |
| Foundation | Go lifecycle/configuration, safe errors/logs, request IDs, PostgreSQL role separation/migration, readiness and bounded coordinator |
| Public product | Home, How It Works, Premium, Safety; mobile-first navigation, tokens, typography, footer and original share image |
| Policy/contact | Privacy, Terms, Community Guidelines, Refund Policy, Grievance, Account Deletion and Contact, with draft ownership/version and production review gates |
| Interaction design | Entry, search, conversation, safety, audio, friends, preference and failure/expiry states in the development-only preview |
| SEO | Public prerendering, route metadata, canonical origin, Open Graph, safe structured data, sitemap, robots, app noindex and real 404 |
| Identity | Required gender/adult/policy consent, memory guests, private accounts, Argon2id, cookie/CSRF sessions, recovery, versioned public/private profiles and optional interests |
| Deletion foundation | Immediate access revocation, initial job/status receipt, separate fsynced journal and startup replay barrier |
| Realtime | Cookie-bound one-use tickets, shared matchmaking pool, strict mutual gender eligibility, soft relevance, Next/End, heartbeat, explicit takeover and 25-second reconnect |
| Matching preferences | Owner-private versioned choices; trusted entitlement interfaces and test fixtures; active conversation profile snapshots remain stable |
| Text and safety | Bounded RAM text, accepted/rendered receipts, frozen report drafts, encrypted selected evidence, reciprocal block barriers and durable account blocks |
| Minimum moderation | Separate private listener, operator accounts with MFA, scoped case review and audited actions; no live conversation browser |
| Connections | Mutual Stay Connected for guests and accounts, private decline, temporary guest links and durable account friendships |
| Friend invitations | Private availability, 30-second accepted text/audio invitations when enabled, shared interaction ownership, removal/block cancellation and no offline queue |
| Audio | Explicit consent, microphone errors, mute/end, Opus WebRTC through approved TURN relays, scoped SDP/ICE, credential refresh and a 25-call reservation limit |
| Relay enforcement | Separate coturn host template, private mutual-TLS control, renewable leases, terminal revocation/replay cleanup, independent watchdog and private aggregate metrics |
| Premium billing | Versioned Cashfree checkout, verified captures, FIFO duration ledger, private receipts, refund holds/restoration, scoped billing administration and reconciliation |
| Full operations | Protected public/account cases and appeals, reviewed deadline versions, primary/backup retries, private MFA roles, audit views and one-use encrypted evidence exports |
| Privacy | Self-data export, closed-account receipts, independently journaled holds, reviewed retention jobs and restricted deletion completion |
| Observability | Private bounded aggregates, financial/case/deletion/backup alerts and external-probe/delivery-drill gates |
| Launch controls | Bounded maintenance drain, restricted validation stage, source/image-bound evidence, immutable release planning, deployment/rollback plans and real-media capacity harness |
| Engineering | Dev/static/staging/production definitions, release-mode checks, dependency/source tests, browser checks and CI |

Account/guest/profile/settings routes use the Go API. `/chat` connects and pairs participants through `/ws` when realtime is enabled. With safety enabled, matched participants can exchange plain text, report selected server-held evidence and block peers. With friends enabled, mutually accepted connections appear at `/friends` and can invite each other while both are available. Audio additionally requires an enabled, synchronized relay and explicit call consent. `/account/premium` provides account purchase, receipt and refund workflows; checkout remains off until its separate approvals and runtime checks pass. Only enabled server catalog versions can be bought, and the ledger supplies trusted Premium authorization. `/support` accepts protected public cases independently of account availability when enabled; `/account/support` and `/account/privacy` provide account case, export and closed-receipt workflows. Actual staffed coverage, reviewed policies, recovery and runtime acceptance remain launch gates.

The full-V1 requirement remains **200 connected participants with 25 simultaneous two-person audio calls**. Calling/waiting participants are included within the connected total. These figures have not been benchmarked in these phases.

## Verify

After initial preparation:

```bash
./scripts/verify.sh
```

This executes the Docker-based acceptance suite, including Go/database checks, migration reversal on an isolated test volume, source/release tests, frontend/build/browser checks, security scans and Caddy smoke tests. Missing locks and failures stop verification. CI never generates missing locks or publishes/deploys images.

For source checks using host Node 24 and Python 3:

```bash
./scripts/phase10-source-check.sh
```

That command does not compile Svelte or establish browser, database or release acceptance.

Frontend commands after dependencies are installed:

```bash
cd web
npm run check
npm run lint
npm run test:unit
npm run test:e2e
npm run test:cross-browser
npm run test:design
npm run test:payments-ui
```

## Identity workflow

Start at `/chat` for a guest or `/register` for an account. Save the one-time recovery code. `/profile` edits public and private fields with version protection; `/settings` provides session revocation, reauthentication, password/code replacement and deletion requests. General Talk remains the default topic. Guests need no account, phone or email.

Deletion disables access immediately; it does not report completed erasure. The dedicated journal is separate from the PostgreSQL volume and replays before identity access after restart. Off-host recovery, legal retention approval and permanent erasure remain later launch gates. See `docs/phase3-deletion-journal.md`.

Identity defaults on locally, off in staging/production. Do not enable deployed identity before acceptance and reviewed policy versions. The implementation adds no email, Redis, managed auth or recurring service.

## Realtime workflow

In two independent browser contexts, enter as guests at `/chat`, choose Search, and verify both show the same interaction. Next ends that interaction for both people and searches again only for the initiator. End returns both to idle. A second live tab asks for explicit takeover, which terminates the old interaction. A brief network failure can resume an existing interaction within 25 seconds on the same server; disconnected waiting entries are removed immediately and never silently requeued.

`REALTIME_ENABLED` follows local identity availability by default and defaults off in staging/production. It requires identity to be enabled. All participants share one pool; profession never becomes an eligibility filter or waiting stage. The saved preference editor is at `/preferences`. See `docs/phase4-protocol.md`, `docs/phase4-authorization.md` and `docs/phase4-acceptance.md`.

## Phase 5 text and safety

`SAFETY_ENABLED` follows local realtime by default and stays off for deployed environments. The server advertises text availability; disabling the feature still enforces stored blocks, restrictions and unfinished safety handoffs during matchmaking. Ordinary text stays in browser/server RAM. Report Begin freezes eligible evidence for two minutes, so a peer leaving does not destroy a started report. Report & Block ends the interaction immediately; the UI confirms submission only after the case is committed. Block management is in `/chat` under **Manage your blocks**.

The private moderation listener is available locally at **http://localhost:9090**. There is no default operator. Provision separate accounts with `adminctl` and a private TOTP enrollment, following `docs/phase5-moderation.md`. Do not expose this listener through public Caddy. Local bootstrap prepares separate evidence/MFA keys in a private volume; preserve keys across restarts. Source delivery does not appoint or train moderators.

A guest registration briefly waits for an atomic safety handoff before new interaction authorization. A crash leaves an account safety fence until reviewed recovery; login/settings stay available, but restarting cannot erase carried restrictions or account blocks. See `docs/phase5-protocol.md` and the mandatory matrix in `docs/phase5-acceptance.md`.

## Phase 6 connections and invitations

`FRIENDS_ENABLED` follows local safety availability and defaults off in staging/production. It requires safety. `FRIENDS_PER_IDENTITY` defaults to 100 and can reduce new connection admission to 1–100; existing durable links remain accessible. Stay Connected requires two affirmative choices in the current conversation. A decline is private; the sender's pending indicator closes when that conversation ends or they withdraw.

Guest connections survive refresh and brief disconnect under the same identity but expire with either guest identity or the server process. Registering the same guest preserves accepted consent. Once both endpoints are accounts, the worker saves the relationship after safety handoff and fresh authorization of each newly registered endpoint; until commit the UI says saving. An existing account peer may stay offline. An unrelated account login does not import a guest's links. Concurrent removal/blocking can invalidate unpublished consent, requiring fresh mutual consent; existing committed friendships remain intact.

At `/friends`, an online, available friend may receive a 30-second text invitation. Acceptance uses the same interaction owner as random matching. Invitations never interrupt a busy conversation or wait offline. Remove ends a friend conversation and cancels invitations; Block also applies the reciprocal safety barrier. Unblocking does not restore a friendship. Ordinary text and guest friendships, requests, invitations and presence stay in RAM. Migration6 adds one durable friendship table and revision fences. See `docs/phase6-protocol.md` and `docs/phase6-acceptance.md`.

## Phase 7 audio relay and call control

Audio is free for guests and accounts when enabled. A Call or Accept action is required before microphone access; incoming invitations and reconnect never start it automatically. Requests ring for 30 seconds with a 15-second decline cooldown. Text remains available after microphone denial or call failure. Mute disables the local audio track; End call stops tracks and closes the peer connection while preserving the text conversation.

The server accepts only audio-only Opus SDP and approved relay candidates. Credentials are issued privately after mutual acceptance and a successful relay lease. They expire after ten minutes and refresh at five minutes; an authorized negotiation counter fences the corresponding ICE restart. Next, conversation End, Block, logout, deletion, authorization loss and signaling loss end audio. Text may reconnect within its existing grace window; audio needs fresh accepted consent.

The dedicated relay runs coturn under a supervisor and independent watchdog. Private mutual-TLS control renews call leases, verifies cancellation and removes allocations recreated using revoked credentials. Restart rotates the TURN secret and requires synchronization. The 25-call cap includes accepted/connecting calls and unresolved relay cleanup. Normal allocation removal within five seconds and orphan shutdown within 30 seconds are mandatory live acceptance targets, not results obtained here.

Both base Compose stacks set `AUDIO_ENABLED=false`. See `deploy/audio/README.md` for the optional application-control overlay and `deploy/turn/README.md` for the separate relay host. Production additionally requires the recorded `AUDIO_SAFETY_VERIFIED` assertion after acceptance; setting a boolean cannot prove those tests passed. No host, DNS entry or public certificate has been provisioned by this delivery.

No audio is recorded or transcribed. A submitted report can retain encrypted, server-derived timing for the last accepted call alongside selected text and the user's allegation; there is no ordinary call-history table. Start with `docs/phase7-protocol.md`, `docs/phase7-relay-runbook.md` and `docs/phase7-acceptance.md`.

## Phase 8 Premium checkout, ledger and refunds

Accounts can review versioned fixed-hour plans, start or resume Cashfree checkout, recover a purchase after a lost return, and view their own receipts and refund status at `/account/premium`. Guests cannot purchase. Phone contact is collected only for the gateway purchase and is not saved in the NoTitle account or ledger. Checkout callbacks and SDK success never grant Premium; server-fetched, validated captures pass through the shared transaction and coordinator.

PostgreSQL holds immutable purchase snapshots, multiple payment attempts, FIFO duration lots, append-only adjustments, signed-webhook projections and bounded background jobs. Purchases stack continuous elapsed time. Full refunds hold only their originating lot's unused seconds; confirmed failure restores them from resolution time. Partial compensation defaults to money-only. Private MFA billing operators preview exact money/time treatment before creating a durable refund request; duplicate captures, disputes and reconciliation exceptions remain auditable obligations.

Both base stacks keep `PAYMENTS_ENABLED=false` and `CHECKOUT_ENABLED=false`; all database plans start disabled pending reviewed tax treatment. See `deploy/payments/README.md` for protected credentials and the optional activation overlay. Processing can remain on with checkout admission off. Written merchant approval of the actual product, approved commercial policies, runtime/sandbox checks and an explicitly authorized live capture/refund/settlement check are required before activation. Annual sales additionally require approved economics and a valid later-refund procedure. No real merchant setup, payment, refund or deployment has been performed.

Phase 8 uses the existing Go process, PostgreSQL database and private operator listener; it adds no subscription service or worker host. The 200-connected/25-call target is preserved and remains unbenchmarked. Read `PHASE8_STATUS.md`, `docs/phase8-payments.md` and `docs/phase8-acceptance.md` for the evidence, operating assumptions and remaining gates.

## Release behavior

Default builds are `preview`: noindex, empty sitemap and honest unavailable features. Hosted `staging` requires HTTPS and access control. `production` requires the actual canonical domain and complete reviewed operator/grievance/tax/privacy information. Content and legal-value changes invalidate the recorded review digest. Runtime startup also checks the artifact mode and origin. These technical checks cannot supply legal approval or establish overall launch readiness.

No production domain, operator details, officer appointment, tax decision or privacy review has been invented. The supplied draft inventory intentionally blocks production. Read `docs/seo-release-controls.md`, `docs/legal-review-inventory.md` and `deploy/production/README.md` before planning publication.

## Project guide

- `web/`: SvelteKit public pages, account forms, development preview and SEO/build controls.
- `server/`: Go coordinator/identity/realtime, PostgreSQL transactions, deletion journal and SQL migrations.
- `deploy/`: container environments, Caddy, database roles and deployment fixtures.
- `scripts/`: preparation, verification and developer commands.
- `docs/`: architecture, contracts, configuration, policy review and acceptance criteria.

Read `AGENTS.md` before automated edits. Use `make help` for local commands. PostgreSQL has no published host port. Routine shutdown preserves its volume; destructive migration tests create their own disposable project.

Acceptance criteria: `docs/phase1-acceptance.md` through `docs/phase10-acceptance.md` (later phases supersede earlier unavailable-feature placeholders). Design review: `docs/phase2-design-system.md`. No public deployment or paid service has been created.

## Phase 9 full operations, privacy and observability

Read `PHASE9_STATUS.md`, `docs/phase9-operations.md`, `docs/phase9-legal-matrix.md` and `docs/phase9-acceptance.md`. Migrations8/9 add operational records and narrowly scoped retention functions; migration9 is required by cumulative readiness. The public support CSRF bootstrap works independently of account recovery, and saved case codes work after logout/deletion subject to the reviewed case-retention schedule. Ordinary chat remains RAM-only and audio is not recorded.

Use the optional `deploy/operations/compose.app.yml` with distinct protected case keys, installed retention policy, an independent hold journal and real host/recovery observations. Initial templates deliberately contain no approvals, roster, live endpoint or verified recovery timestamps. Review them and rehearse source-provided private operator workflows before enabling real-user operations. A green unit suite does not establish delivered notifications, correct cloud policy, restored data, staff availability or legal approval.

No new paid service or application replica is introduced. The existing Go API executes bounded outbox, retention and aggregate work. Off-host storage/transfer, existing host capacity and operator/legal work still cost money.

## Phase 10 hardening, deployment and launch

Start with `PHASE10_STATUS.md`, `docs/phase10-build.md`, `docs/phase10-deployment.md`, `docs/phase10-capacity.md`, `docs/phase10-browser.md` and `docs/phase10-launch.md`. The acceptance matrix and evidence tooling keep actual test artifacts, immutable source/images, named reviews and deployment settings together. Draft records fail closed; passing a JSON consistency check cannot attest authorship or replace the underlying tests.

Production always starts paused. A private owner can announce a drain of at most 120 seconds, closing new searches, invitations, calls and checkout while existing interactions finish; the deadline ends remaining interactions and starts relay revocation. Support, safety actions, provider callbacks and committed financial work retain their existing dependency checks. Deployment replaces the single owner only after drain and cleanup. Rollback uses schema-compatible images and never restores an old database to undo a code change.

Isolated acceptance uses the same API, migration, PostgreSQL and TURN images, with a separately reviewed staging web build and sandbox payments. A short-lived restricted production-validation stage permits explicitly authorized smoke/payment evidence behind access controls. Final full-V1 launch requires every gate, then a deliberately opened supervised cohort before broader public access. Real Android Chrome/iPhone Safari and desktop browser evidence remain mandatory; browser emulation is supplemental.

The two six-hour workloads preserve **200 connected participants and 25 simultaneous two-person calls**; overload offers 400 and checks the 201st participant, 101st waiter and 26th call. The harness uses synthetic microphone audio through actual WebRTC/TURN and independently observed server/host metrics. It has not run against a target in this delivery. Keep artifacts and private inputs outside the source tree; no secret, live customer data or test transcript belongs in an evidence archive.
