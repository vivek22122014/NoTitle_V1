# Security Policy

NoTitle is being built as a privacy-sensitive realtime service.

## Reporting a vulnerability

Do not open a public issue containing exploit details, credentials, personal data, or private user information.

Before public launch, replace this section with the dedicated production security contact and coordinated disclosure process.

## Repository rules

- Never commit credentials or private keys.
- Treat accidental secret commits as compromised even if later removed from Git history.
- Do not log user communication content.
- All new external input must have explicit validation and size/rate limits.
- All durable-data additions require a privacy/retention reason.
- Security-sensitive changes require tests.
