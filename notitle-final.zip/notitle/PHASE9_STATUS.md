# Phase 9 source delivery

Date: 2026-10-09 UTC / 2026-10-10 IST. Baseline: finalized NoTitle blueprint V3.2 and cumulative Phase 8 source. This package contains Phases 1–9; earlier status files are historical.

**Implemented in source; full runtime and production acceptance remain pending.** No public deployment, operator account, external notification, cloud resource, payment or refund was created. The application remains mobile-first with desktop feature parity and the **200-connected / 25 simultaneous two-person call** requirement. Capacity has not been benchmarked.

## Included

- Independent public support and saved case-code access, plus authenticated account cases, human replies and appeals. The browser generates the recovery secret before submission; unknown results reuse the original submission identity. Content is encrypted with a separate keyring, and only a secret verifier is stored. Secrets stay out of URLs, automatic browser persistence, logs and notification payloads. Existing case access remains available when new intake is paused.
- Versioned legal deadline and reminder rules with effective/publication/review dates. Retry, reassignment and appeals preserve original receipt time. Urgent cases receive immediate primary notification and timed backup escalation through leased, bounded retry workers. Delivery is distinct from human acknowledgement; failed/dead work remains visible. Approved quarterly notices persist account delivery/acknowledgement while guest reminder state stays in memory.
- Private MFA operator console for cases, appeals, financial exceptions, aggregate alerts, privacy holds/jobs and audit search. Sensitive output rechecks current role and session generation and records an audit. Operator role/disable/MFA changes revoke sessions. Evidence exports are encrypted, bounded, session-bound, single-use and expire after two minutes; an exported copy still requires controlled retention.
- Owner-MFA installation of an independently reviewed, immutable retention manifest. Runtime credentials cannot publish policy. Self-data exports exclude credentials, peers' private profiles, reporter identity and unrestricted evidence. Closed-account receipt access requires the saved deletion proof and matching purchase reference without reviving identity.
- Dedicated durable hold/release journal and replay barrier, current database/journal event-count comparison, purpose-specific holds, finite retention jobs, restricted registration preservation and financial retention. Ordinary deletion requires verified off-host deletion coverage; destructive work waits for recoverable hold records. Narrow database functions enforce approved policy, clock, age, state and hold checks. Legacy unjournaled hold writes are disabled; a documented conversion preserves existing barriers.
- Private fixed-label process, database, matching and relay aggregates; minimum-cohort suppression for matching history; alerts for capacity pressure, overdue cases/jobs, failed deletions, ungranted captures, clock health, recovery lag and delivery failure. Host sampling runs outside the application through the supplied bounded Linux collector; remote recovery/probe/drill timestamps must come from independently verified evidence.
- Migrations 8/9, schema-9 readiness, least-privilege and disposable rollback gates, protected optional deployment overlay, archive sealing fixtures, India security-log retention and backup/WAL templates, operator/legal review records and four incident/recovery runbooks. No new paid monitoring service, broker, worker VM or application replica is introduced.

Ordinary chat remains RAM-only and voice is not recorded. Existing tiers, matching eligibility, guest/account roles, safety, friendship, audio, payment and refund workflows remain intact.

## Executed evidence

| Check | Actual result |
| --- | --- |
| `./scripts/phase9-source-check.sh` | **142 JavaScript tests passed:** 139 web and 3 deployment/source tests; zero failures or skips. Also **12 Python fixture tests passed:** 6 archive boundaries and 6 collector boundaries. Output: `docs/phase9-source-check.txt`. |
| Source credential/direct-version audit | Passed. This limited pattern scan is not a comprehensive security assessment. |
| TypeScript/Svelte script syntax | 93 executable script sections parsed. No import resolution, typecheck or Svelte template/build claim. |
| Shell/config syntax | 23 shell scripts passed `bash -n`; 13 JSON and 12 YAML files parsed. Compose, systemd and Caddy runtime acceptance remains pending. |
| Public API specification | 49 paths, 54 unique operations and 331 resolving local references. Private operations are not mounted on the public listener. |
| Baseline preservation | All 440 Phase 8 files retained. Additions and modifications are cumulative; no source file was discarded. |
| `node scripts/audit.mjs --release` | Correctly fails because authentic `server/go.sum` and `web/package-lock.json` are absent. No lockfiles were fabricated. |
| `./scripts/verify.sh` | Blocked: Docker/Compose is unavailable. Go, gofmt and psql are also unavailable. |
| Backend/browser/runtime | New unit, HTTP, role, journal, purge and PostgreSQL tests are authored but unexecuted. Fifteen Phase 9 browser tests are authored but unexecuted. No notification, restore, encryption-provider, storage or load result is claimed. |

Archive fixture tests deliberately substitute a fake encryption executable. Collector tests validate file/schema/counter behavior, not live host, clock, relay or off-host provenance. Static and lexical checks cannot establish that Go compiles or the SQL executes.

## Gaps resolved in this phase

1. The staging browser-auth exception now matches the actual signed webhook route, `/api/v1/webhooks/cashfree`; the old template used the wrong path. No payment API route changed.
2. Support availability now reflects intake-policy readiness, while saved case status/replies remain independent of account recovery and alert receiver availability. The case notification worker is wired separately from aggregate alert delivery.
3. A readiness feedback loop was removed: the optional web overlay starts after the API process starts, and external availability evidence uses public liveness/static serving. External readiness failures are monitored separately without feeding their own prerequisite.
4. Reviewed retention controls use immutable policies and guarded database functions. Expiry incorporates existing per-record minima, closure/final-activity anchors and active holds. Hold release cannot silently bypass the independent journal.
5. Signed visitor-cookie limits prevent all users behind Caddy sharing one per-source support bucket; independent global budgets remain. A 200-visitor HTTP regression is authored, not an executed capacity test.
6. Fresh known host clock drift blocks authoritative identity/matching/payment admission. Recovery timestamps are checked for freshness and against the relevant records; local fsync alone is not off-host recovery proof.

## Required activation sequence

1. On an isolated supported host, run `./scripts/bootstrap.sh prepare`, generate authentic locks, review formatting/dependencies and run `./scripts/verify.sh`. Resolve compiler, race, SQL, migration/privilege, Svelte, browser and dependency failures. Reverse migrations only on disposable fixtures.
2. Review the legal matrix, actual operator/processor/contact inventory, retention manifest and financial schedule. Publish reviewed deadline/notice versions using `server/internal/operations/README.md`; install the matching retention manifest through the documented owner-MFA command. Draft templates confer no approval.
3. Prepare separate protected case keys, deletion/hold journals and observation directories. Test independent journal restoration and current-database event-count parity. An old database plus a missing journal requires verified off-host inventory recovery; a directory, counter or fresh timestamp alone cannot prove complete history.
4. Configure actual primary and backup operators and approved receivers. Test successful delivery, absence of primary, retries/dead letters and human acknowledgement with synthetic cases. Confirm the independent monitor can alert during total app-host loss. No outgoing user-email service is required.
5. Rehearse critical safety, failed payment, privacy and host-loss incidents. Verify real encryption/decryption, India storage, object retention, full+WAL integrity, exact journal inventory, deleted-account replay and active/released holds. Prove target RPO ≤15 minutes and staffed RTO ≤4 hours; these remain objectives until drilled.
6. Complete the Phase 9 acceptance matrix and both six-hour mixed workloads with **200 connected / 25 calls**, including the waiting-user variant, hashing, billing, moderation, privacy, backup and notification work. Measure latency and headroom before changing admission or host size. Review at roughly 140 connections/18 calls, sustained CPU65–70%, memory75%, owner lag100ms, disk70% or less than30 days' growth room.

`OPERATIONS_ENABLED=false` remains in base stacks. The optional overlay adds no always-on service; it requires actual private files and coverage evidence. Monitoring/policy settings cannot provision people, approve law or prove recovery. See `docs/phase9-operations.md`, `docs/phase9-acceptance.md`, `docs/phase9-legal-matrix.md`, `docs/observability.md` and `deploy/operations/README.md`.

Phase 9 adds **₹0 fixed software subscription/month or year** within existing measured host headroom. Storage, requests/transfer, staff/legal work and excess host usage still cost money. The retained blueprint planning budget is approximately **₹4,100/month / ₹49,200/year**, plus transaction fees and the stated exclusions; it is an existing assumption, not a newly verified provider quote. No capacity or cost guarantee is implied.
