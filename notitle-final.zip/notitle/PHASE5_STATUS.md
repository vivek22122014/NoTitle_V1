# Phase 5 source delivery

Date: 2026-10-09. Baseline: NoTitle V1 final implementation blueprint V3.2. This is the cumulative Phases1–5 source; historical phase status records remain unchanged.

**Implemented in source; runtime and production acceptance are pending.** No public deployment, payment activation, real operator provisioning or new paid service was performed.

## Included

- Escaped text/emoji with strict Unicode, frame and rate bounds; server sequence, acceptance and recipient-rendered delivery receipts; bounded per-epoch deduplication and same-interaction reconnect replay.
- Thirty messages/64KiB of ordinary interaction text in RAM. No ordinary chat SQL table, browser persistence or message logging. Next/End/logout/deletion and expired/replaced interactions clear eligible live content.
- Two-minute owner-frozen report drafts, selected server-attributed evidence and separate user statements. Report & Block freezes before clearing live text. Metadata-only ended references last ten minutes. Stable retries never claim submission before a durable case commit.
- Directed block ownership with reciprocal communication/matching prevention, durable account-account records, temporary guest barriers, block management and safe in-session promotion. An interrupted guest-account handoff remains durably fenced instead of losing carried safety state after restart.
- Encrypted case evidence, per-case subjects, versioned retention deadlines, restriction state, moderation actions and legal-hold foundations. Migrations4/5 preserve least privilege; readiness now requires schema5 and the verification gate checks20 durable tables.
- Private moderation listener and responsive server-rendered interface, separate operator accounts, shared bounded Argon2id hashing, encrypted TOTP MFA, replay protection, short secure sessions, role restrictions and audited evidence/action access. Offline provisioning CLI has no default password or public bootstrap endpoint.
- Mobile-first text/report/block controls with desktop parity. Retryable registration finalization preserves the existing reconnect proof. Existing matching eligibility, shared pool, free-tier authorization and capacity requirements remain intact.

## Executed evidence

| Check | Actual outcome |
| --- | --- |
| `./scripts/phase5-source-check.sh` | **80 passed, 0 failed, 0 skipped**:77 frontend unit tests plus3 deployment/source tests. Full output: `docs/phase5-source-check.txt`. |
| Source credential-pattern/direct-version audit | Passed; this is not a comprehensive security scan. |
| TypeScript/script syntax parsing |66 sections parsed after type stripping; no import resolution, Svelte compiler, type or browser claim. |
| Shell/JSON/YAML syntax |19 shell scripts passed syntax checks;7 JSON files and8 YAML files parsed. YAML parsing is not Docker Compose validation. |
| Public OpenAPI |24 paths,28 unique operation IDs; all local references resolve. Admin routes are excluded. |
| `./scripts/verify.sh` | Stopped because Docker/Compose is unavailable. |
| `node scripts/audit.mjs --release` | Correctly failed: authentic `web/package-lock.json` and `server/go.sum` are still missing. |
| Go/PostgreSQL/browser execution | Not run: Go, gofmt, Docker and psql are unavailable; required dependencies are not installed. |

Authored, unexecuted tests cover strict text/Unicode, receipt races, transcript purge, report/Next and report/block lifecycle, durable retry/unblock, guest promotion, pending handoff crash fences, encryption/AAD, moderation ordering, operator MFA/RBAC/audit and real database least privilege. A real HTTP/WS safety smoke and SQL/log ordinary-text canary are wired into the isolated full-stack gate. Test files are not passing evidence.

## Remaining acceptance and operating limits

On the supported Docker host, run `./scripts/bootstrap.sh prepare`, review genuine locks and formatting, then `./scripts/verify.sh`. Resolve every compiler, race, database, vulnerability, Svelte and browser failure. Complete `docs/phase5-acceptance.md`, including real mobile devices, restart/outage, encrypted restore and operator drills.

Private founder/backup operators, MFA enrollment, a protected gateway, actual monitored report/grievance coverage and reviewed retention must exist before real-user testing. Configuration assertions do not appoint or train people. The public grievance contact is still draft/unavailable until real details and later workflows are supplied. The full grievance/appeal, retention erasure/legal-hold automation and orphaned safety-handoff recovery workflows remain later work; do not blindly clear an orphan's fence or infer completed deletion from an account-access revocation.

Text delivery uses the existing30s authorization lease with10s renewal, plus actor ownership/epoch/peer/safety checks. Stored safety remains enforced even when text/report UI is disabled. Report/database failure never guarantees durable blocking; temporary local protection requires the existing process/identity. Lost or expired RAM reports cannot be reconstructed after restart.

The configured minimum remains **200 connected participants and25 simultaneous two-person calls** for full V1. This phase does not implement audio or establish measured capacity. Payload bounds and tests are not host benchmarks. Keep one authoritative API owner; load-test on the intended host before changing limits.

Additional provider subscriptions for Phase5: **₹0/month; ₹0/year**, assuming the existing host has measured headroom. Existing infrastructure, backups, bandwidth and human moderation remain costs. No Redis, broker, hosted realtime, managed authentication or separate paid admin hosting was introduced.

Start with `README.md`; implementation/acceptance detail is in `docs/phase5-protocol.md`, `docs/phase5-moderation.md` and `docs/phase5-acceptance.md`.
