# NoTitle complete application — setup and handover

Delivery date: 9 October 2026 UTC / 10 October 2026 IST. Business baseline: NoTitle V3.2. This ZIP contains the cumulative Phases 1–10 source, migrations, tests, deployment definitions and operating procedures.

**Release status: complete source handover; production acceptance is pending.** This is not a prebuilt or production-certified binary distribution. Authentic Go/npm dependency locks could not be generated in the delivery workspace because registry access was blocked; Go, Docker and PostgreSQL were unavailable. The commands below prepare those locks on your development machine and run the required checks. Do not open production admission until the actual candidate passes the documented gates. See [FINAL_DELIVERY_STATUS.md](FINAL_DELIVERY_STATUS.md) for checks actually run and outstanding work.

## 1. What you are building

NoTitle is an India-first workplace conversation website for adults, with mobile-first responsive screens and the same features on desktop. Guests, Free accounts and Premium accounts share one matching pool. Features include text, explicit-consent audio, mutual connections and online friend invitations, report/block, private moderation, account recovery/deletion, Premium purchases/refunds, support and privacy operations. Preserve the finalized mutual matching rules and role boundaries when configuring it.

The target is **200 connected people including 25 simultaneous two-person calls**, with up to 100 waiting people inside the same 200. It is a concurrent-load requirement, not a registered-account limit and not a measured result from this package. Ordinary chat stays in memory and audio is not recorded. Restart ends live interactions and temporary guest state.

| Component | Included implementation | Deployment |
| --- | --- | --- |
| Frontend | TypeScript, Svelte 5, SvelteKit static output, responsive CSS | Caddy serves static files; no production Node server |
| Backend | Go, one authoritative realtime coordinator, HTTP/WebSocket APIs and background jobs | One API process/container |
| Database | PostgreSQL, separate bootstrap/migration/runtime roles, cumulative migrations through schema 9 | Same private app host initially |
| Audio | Browser WebRTC/Opus with relay-only media; coturn and private relay control/watchdog | Separate TURN host |
| Payments | Cashfree hosted checkout; server verification, immutable duration ledger, refunds and reconciliation | Existing Go API plus Cashfree |
| Operations | Private MFA administration, case/privacy workflows, bounded metrics and recovery tools | Existing hosts plus reviewed off-host storage/monitoring destinations |

The planned starting sizes are a 2-vCPU/4-GiB app host and a 1-vCPU/1-GiB TURN host. Confirm them with the mandatory workloads. One app host is a shared failure domain; this MVP is not an automatic high-availability cluster. No Redis, Kubernetes, paid auth service or managed realtime service is required. The inherited planning budget is about ₹4,100/month or ₹49,200/year before gateway fees and stated exclusions; it is not a current provider quote. Storage/transfer, domain, taxes, staffing, temporary acceptance infrastructure and future growth must be budgeted separately. See [PHASE10_STATUS.md](PHASE10_STATUS.md) and [architecture.md](docs/architecture.md).

## 2. Read the right guide

| Task | Guide |
| --- | --- |
| Install, run locally, check basic workflows and select tests | This file |
| Every backend, frontend and deployment environment setting; secret formats | [FINAL_ENVIRONMENT_REFERENCE.md](docs/FINAL_ENVIRONMENT_REFERENCE.md) |
| Two-host provisioning, images, TLS, overlays, staging, launch and rollback | [FINAL_DEPLOYMENT_GUIDE.md](docs/FINAL_DEPLOYMENT_GUIDE.md) |
| Cashfree dashboard, credentials, catalog, callbacks, testing, refunds and settlement | [FINAL_PAYMENT_GUIDE.md](docs/FINAL_PAYMENT_GUIDE.md) |
| Actual delivery evidence and unresolved acceptance | [FINAL_DELIVERY_STATUS.md](FINAL_DELIVERY_STATUS.md) |
| Complete technical acceptance | [phase10-acceptance.md](docs/phase10-acceptance.md), including applicable Phases 1–9 |

Earlier phase documents record the state of that phase. Statements that a later feature is unavailable are historical. This cumulative package includes all ten phases; the final guides and Phase 10 acceptance describe the current release. Implementation and enabled/approved operation remain separate.

## 3. Prepare Windows or Linux

Use Bash on Linux. On Windows 11, use WSL2 Ubuntu and Docker Desktop's Linux/WSL2 integration:

1. Follow Microsoft's [WSL installation instructions](https://learn.microsoft.com/en-us/windows/wsl/install). The usual initial command is `wsl --install` in an administrator PowerShell window, followed by the requested restart and Ubuntu account setup.
2. Install Docker Desktop using its [WSL2 instructions](https://docs.docker.com/desktop/features/wsl/) and enable integration for the Ubuntu distribution. Review the vendor's applicable license terms. On a Linux host use the [Docker Engine instructions](https://docs.docker.com/engine/install/) for that distribution.
3. In the Linux/Ubuntu terminal, confirm `docker info` succeeds and `docker compose version` reports v2.30 or newer. Run application scripts as your normal Linux user with authorized Docker access.
4. Install Python 3.11+ for the operations fixture checks, plus `unzip`, `curl` and optionally `make` through your distribution's package manager. A host Go, Node or PostgreSQL installation is unnecessary for the container workflow. Optional host source checks require Node 24.
5. Allow access to the container and dependency registries required by the pinned manifests. Use a workstation with enough free memory/disk for image builds and three browser engines; as a starting development allowance, reserve 8 GiB RAM and 20 GiB disk, then measure actual usage. This is separate from the production host budget.

Keep extracted code in the Linux filesystem, for example `~/projects/notitle`, rather than a Windows-mounted drive. This preserves Linux permissions and makes bind-mounted builds more predictable. Keep production secrets off your development tree.

## 4. Verify and extract the download

Download `notitle-final.zip` and `notitle-final.zip.sha256` into the same directory. In a Linux/WSL terminal in that directory:

```bash
sha256sum -c notitle-final.zip.sha256
mkdir -p "$HOME/projects"
unzip notitle-final.zip -d "$HOME/projects"
cd "$HOME/projects/notitle"
```

Use a new destination if `~/projects/notitle` already exists; do not overwrite your existing secrets or work. The checksum should report `OK`. It detects an incomplete or changed download; it is not an independent signature from a third party.

If your extraction tool discarded executable permissions, repair only the supplied shell scripts:

```bash
find scripts deploy -type f -name '*.sh' -exec chmod u+x {} +
```

## 5. Prepare genuine dependencies and local secrets

From the `notitle` root:

```bash
./scripts/bootstrap.sh prepare
```

This uses the pinned Go/Node images to generate missing genuine `server/go.sum` and `web/package-lock.json`, verify dependencies, run formatters and initialize unique development secrets. It can change formatting and `go.mod`; review and retain those changes before building a release. It runs preparation containers but does not start the application stack. Repeating it preserves existing local secret values.

The local template becomes `deploy/dev/.env`; secrets are generated under `.local/secrets`. Do not copy these development credentials to staging/production or include them in another ZIP. There is no shared default password, default admin or bundled live gateway key.

If registry access fails, fix the authorized network/package access and rerun preparation. Do not create dummy lockfiles, bypass checksum verification or remove release checks. If you use Git, keep the genuine locks and reviewed source changes in the release commit and exclude secrets and build output. An archive-only release can use the source fingerprint without inventing a Git commit.

## 6. Start and stop the local application

Development mode, with frontend hot reload:

```bash
./scripts/start.sh dev
```

Open **http://localhost:5173**. The command starts PostgreSQL, applies cumulative migrations and starts the API and Vite. Use **http://localhost:5173/design-preview** only to inspect simulated UI states; it does not connect users or exercise the live workflows.

For the compiled static site served by Caddy:

```bash
./scripts/start.sh static
```

Open **http://localhost:8080**. Switching modes replaces API/web while preserving database data. The design preview returns 404 in static mode. Both local modes use preview release settings and draft public policies; neither is a publicly approved production deployment.

Useful commands from the root:

```bash
./scripts/compose.sh dev ps
./scripts/compose.sh dev logs --tail=100 api web postgres
./scripts/compose.sh dev down --remove-orphans
```

Use `static` instead of `dev` when running that mode. Shutdown preserves volumes. **Do not add `-v`** to a retained environment. After Go source changes use `make api-restart` in development, or rebuild with `./scripts/start.sh dev`. `make help` lists the supported shortcuts.

For development health checks:

```bash
curl --fail http://localhost:5173/health/live
curl --fail http://localhost:5173/health/ready
```

Use port 8080 for static mode. Local readiness should become healthy after migration/startup. Production deliberately starts with readiness 503 while admission is closed; that has a different meaning from liveness failure.

## 7. Exercise the real local workflows

Use two independent browser profiles or a normal and private window. Two tabs sharing one identity trigger takeover protection and do not represent two people.

1. Open `/chat`, complete the required adult/policy/gender selections and enter as a guest in each browser. Start Search on both; compatible users should share an interaction.
2. Send plain text both ways. Exercise Next and End: Next searches again only for the initiator; End returns both to idle. Check reconnect within 25 seconds and recovery after expiry. Do not expect a restart to preserve guest conversations.
3. In a conversation, choose Stay Connected from both sides. At `/friends`, test an accepted online invitation, decline, expiry and removal. A connection requires mutual consent.
4. Use synthetic test content to exercise report/block and the frozen evidence selection. Inspect case handling through private administration after provisioning an operator; do not submit real allegations as test data.
5. Register at `/register`, save the one-time recovery code privately, edit `/profile` and `/preferences`, then test logout/recovery and sensitive actions in `/settings`. Test account deletion only with disposable identities; access revocation and final erasure are different states.
6. Repeat core journeys at 320–430 CSS px first and desktop widths through 1920 px. Test focus, keyboard, 200% text, portrait/landscape and the mobile software keyboard. Actual Android Chrome/iPhone Safari remain mandatory beyond emulation.

The base local stack enables identity, realtime, safety, friends and private administration. Audio, gateway processing and full operations are disabled until their separate files, services and approvals are configured. A missing Call or checkout action in this base configuration is not proof of a frontend defect. Do not advertise a disabled capability as active.

Private administration is at **http://localhost:9090** locally. There is no default operator. Follow [phase5-moderation.md](docs/phase5-moderation.md) to build/run the offline `adminctl` with a protected input file, migration-role DSN and independent MFA key; import the generated TOTP enrollment privately. In this cumulative package apply migrations through **9**, even where the historical Phase 5 guide discusses migrations 4/5. Private deployed administration needs a distinct HTTPS origin behind authenticated private access; never add it to the public route map.

## 8. Run the test sequence

After preparation, execute the full container suite:

```bash
./scripts/verify.sh
```

It stops on missing prerequisites or failures. It runs release/source checks, Go/database/migration/role checks, Svelte/frontend/browser fixtures, dependency scans and a real local Caddy/API smoke stack. Migration reversal is confined to a disposable test database. Do not replace its database URL with retained production data. Resolve each failure and rerun the affected gate before release.

Optional quicker source checks, with host Node 24 and Python 3.11+:

```bash
./scripts/phase10-source-check.sh
```

This checks source contracts and JavaScript/Python fixtures only. It does not compile Go/Svelte, run a real database or demonstrate capacity. Frontend-specific commands are in [README.md](README.md); the container suite supplies dependencies/browser engines for its workflow.

Before launch, additionally complete:

| Gate | Required evidence |
| --- | --- |
| Gateway sandbox | Signed callback/retry matrix, authoritative captures, receipt/ledger/refund/reconciliation outcomes; [payment guide](docs/FINAL_PAYMENT_GUIDE.md) |
| Real devices | Android Chrome, iPhone Safari and desktop Chrome/Edge/Firefox/Safari on supported platforms; keyboard, permissions, interruptions, network changes |
| Relay enforcement | Real media, relay-only paths, cancellation/replay protection, watchdog failures and fresh consent after signaling loss |
| Capacity | Both six-hour 200-connected/25-call scenarios, 400-offered overload, dense friends, measured latency and memory headroom; [capacity runbook](docs/phase10-capacity.md) |
| Operations and recovery | Staffed primary/backup drills, external monitoring, encrypted full+WAL restore, newer deletion/hold journals, key recovery and schema-compatible rollback |
| Production validation | Actual domain/configuration, restricted smoke and separately authorized bounded capture/refund/bank/settlement evidence |

No source fixture substitutes for these results. A larger host is appropriate if measured capacity fails; reducing the requirement or adding a second uncoordinated API process is not.

## 9. Configure Cashfree, deploy and launch

Follow the final guides in this order:

1. Read the [environment reference](docs/FINAL_ENVIRONMENT_REFERENCE.md). Prepare separate development, isolated acceptance and production values. Public frontend settings are build-time inputs; secrets are file inputs outside the image/source. There is no universal `.env` that safely enables every feature by itself.
2. Complete [Cashfree sandbox setup](docs/FINAL_PAYMENT_GUIDE.md), including the reviewed catalog, private billing role, hosted SDK build configuration, webhook verification and refund cases. Keep production checkout off until its merchant/policy/tax/runtime gates pass. Payment processing and new checkout admission are distinct switches.
3. Follow the [deployment guide](docs/FINAL_DEPLOYMENT_GUIDE.md) to provision the app and separate relay host, DNS/TLS/private controls, recovery storage and the ordered Compose overlays. Build and scan immutable images outside the small app host; record real registry manifest digests.
4. Keep production closed while collecting isolated acceptance evidence against the exact candidate. Finish legal/operator/retention/coverage and recoverability requirements. The included pgBackRest files are templates: the base PostgreSQL image does not automatically install or activate a complete backup service.
5. After all pre-live gates and explicit bounded live-money authorization, use the restricted, time-limited validation stage to collect production smoke and real financial evidence. Waiting for genuine settlement does not justify marking a gate passed early.
6. Verify all final evidence, install its source/image/manifest-bound permit and let the appointed owner open a supervised cohort through private MFA. Observe a complete operating cycle before separately expanding public ingress. A Caddy setting cannot open backend admission by itself.

The deployment instructions include the actual command sequence. They do not provision resources, charge a payment, publish images or open the application automatically.

## 10. Common setup failures

| Symptom | Action |
| --- | --- |
| Docker unavailable or old Compose | Start the engine, enable the correct WSL integration and confirm Compose v2.30+. |
| Missing locks / unavailable registry | Run `bootstrap.sh prepare` with authorized registry access; retain genuine generated locks. |
| Permission denied on scripts | Extract on the Linux filesystem and restore shell executable permissions as above. |
| Secret-file permission failure | Use correct owner-only production files/readable image users. On Windows-backed mounts use the reviewed Linux-volume preparation method. Do not weaken secret validation. |
| Address already in use | Adjust the relevant ports and matching origins in `deploy/dev/.env`, then recreate the stack. A changed port must agree with the exact browser Origin. |
| CSRF/Origin rejection | Use the configured localhost URL consistently; do not mix localhost, 127.0.0.1, IP addresses or ports. |
| API unready after startup | Inspect bounded logs and migration status (`make migrate-status`); confirm schema 9, runtime grants and journal replay. Never erase a journal to force readiness. |
| Production remains paused | Complete the relevant evidence and private-owner opening flow; closed readiness is intentional. |
| Checkout unavailable / SDK blocked | Check compile-time SDK flag/environment, exact CSP, backend flags, enabled immutable catalog, account state and approvals. Rebuilding web is required for build-time changes. |
| Browser says paid but no Premium | Inspect server order verification/reconciliation and private billing work; never grant from a browser screenshot or return URL. |
| Audio unavailable | Inspect relay configuration, private supervisor/watchdog health, permissions, quotas and uncertain cleanup; never enable a direct-media fallback. |

## 11. Maintain the running service

Use [phase9-operations.md](docs/phase9-operations.md) for daily case/payment/recovery observation and primary/backup coverage, and [phase10-deployment.md](docs/phase10-deployment.md) for drain/deploy/rollback. Test recovery periodically and after material changes; keep keys and newer independent journals recoverable outside the app host. Rotate credentials through the provider/database plus mounted files and restart/reverify the affected clients.

Review security updates, image/dependency findings, certificate expiry, recurring costs and projected relay transfer. Investigate growth around 140 connected/18 calls, sustained CPU/latency rise, post-GC memory above 75%, owner lag above 100 ms, disk above 70% or rising job/WAL backlog. These are review thresholds, not lower product limits. First optimize measured work or resize the affected host; a future multi-owner design requires explicit coordination changes and new acceptance.

Do not reverse production migrations or restore an old database to roll back application code. Drain the single owner, verify relay cleanup, and use a schema-compatible prior image with current durable records. Any source/configuration/image change invalidates the affected release evidence and requires its checks again.
