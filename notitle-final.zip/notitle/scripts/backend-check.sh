#!/bin/sh
set -eu
test -s go.sum || { echo 'go.sum missing' >&2; exit 1; }
go mod verify
go mod tidy -diff
unformatted=$(gofmt -l .)
if [ -n "$unformatted" ]; then
  printf '%s\n' "$unformatted"
  echo 'Go formatting differs; run bootstrap or gofmt with the pinned Go version.' >&2
  exit 1
fi
go vet ./...
go test -mod=readonly -race -count=1 ./...
go build -mod=readonly -trimpath -o /tmp/notitle-check ./cmd/notitle
go build -mod=readonly -trimpath -o /tmp/notitle-adminctl-check ./cmd/adminctl
GOBIN=/tmp/notitle-tools go install golang.org/x/vuln/cmd/govulncheck@v1.8.0
/tmp/notitle-tools/govulncheck ./...
