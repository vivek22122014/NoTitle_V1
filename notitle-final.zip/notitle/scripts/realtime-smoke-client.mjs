// Minimal RFC 6455 client used only by the disposable integration gate. Node's
// browser WebSocket API cannot set the exact configured Origin behind Caddy.
// This client never prints credentials, frames or profile payloads.
import assert from 'node:assert/strict';
import { createHash, randomBytes } from 'node:crypto';
import http from 'node:http';
import https from 'node:https';

export class SmokeSocket {
  #socket;
  #buffer = Buffer.alloc(0);
  #messages = [];
  #waiters = [];
  #fragments = [];
  #fragmentBytes = 0;
  #closeWaiters = [];
  closed = false;
  closeCode = null;
  constructor(socket, head) {
    this.#socket = socket;
    socket.on('data', (data) => {
      try { this.#receive(data); } catch { this.abort(); }
    });
    socket.on('error', () => this.#finish());
    socket.on('close', () => this.#finish());
    if (head.length) this.#receive(head);
  }
  static open(base, origin, cookie = '', path = '/ws') {
    const url = new URL(path, base);
    const key = randomBytes(16).toString('base64');
    const expected = createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
    return new Promise((resolve, reject) => {
      const request = (url.protocol === 'https:' ? https : http).request(url, {
        headers: { Connection: 'Upgrade', Upgrade: 'websocket', 'Sec-WebSocket-Version': '13', 'Sec-WebSocket-Key': key, Origin: origin, Cookie: cookie },
        timeout: 10000
      });
      request.on('timeout', () => request.destroy(new Error('WebSocket handshake timed out')));
      request.on('error', () => reject(new Error('WebSocket handshake failed')));
      request.on('response', (response) => { response.resume(); reject(Object.assign(new Error('WebSocket upgrade rejected'), {status: response.statusCode})); });
      request.on('upgrade', (response, socket, head) => {
        try {
          assert.equal(response.statusCode, 101);
          assert.equal(response.headers['sec-websocket-accept'], expected);
          assert.equal((response.headers.upgrade ?? '').toLowerCase(), 'websocket');
          assert.equal(response.headers['sec-websocket-extensions'], undefined, 'Compression must stay disabled');
          socket.setTimeout(0);
          resolve(new SmokeSocket(socket, head));
        } catch { socket.destroy(); reject(new Error('Invalid WebSocket upgrade response')); }
      });
      request.end();
    });
  }
  #frame(opcode, data) {
    assert.ok(data.length <= 65535, 'Smoke frame too large');
    const mask = randomBytes(4);
    const header = Buffer.alloc(data.length < 126 ? 2 : 4);
    header[0] = 0x80 | opcode;
    if (data.length < 126) header[1] = 0x80 | data.length;
    else { header[1] = 0x80 | 126; header.writeUInt16BE(data.length, 2); }
    const payload = Buffer.from(data);
    for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i % 4];
    this.#socket.write(Buffer.concat([header, mask, payload]));
  }
  send(value) { this.sendRaw(JSON.stringify(value)); }
  sendRaw(value) { assert.ok(!this.closed, 'Socket is closed'); this.#frame(1, Buffer.from(value)); }
  #receive(data) {
    this.#buffer = Buffer.concat([this.#buffer, data]);
    assert.ok(this.#buffer.length <= 128 * 1024, 'Unbounded server frame');
    while (this.#buffer.length >= 2) {
      const first = this.#buffer[0], second = this.#buffer[1];
      assert.equal(first & 0x70, 0, 'Unexpected WebSocket extension bits');
      assert.equal(second & 0x80, 0, 'Server frames must be unmasked');
      const opcode = first & 15, final = (first & 0x80) !== 0;
      let size = second & 127, offset = 2;
      if (size === 126) { if (this.#buffer.length < 4) return; size = this.#buffer.readUInt16BE(2); offset = 4; }
      else if (size === 127) { if (this.#buffer.length < 10) return; const length = this.#buffer.readBigUInt64BE(2); assert.ok(length <= 65536n); size = Number(length); offset = 10; }
      if (this.#buffer.length < offset + size) return;
      const payload = this.#buffer.subarray(offset, offset + size);
      this.#buffer = this.#buffer.subarray(offset + size);
      if (opcode >= 8) {
        assert.ok(final && size <= 125, 'Invalid server control frame');
        if (opcode === 8) {
          assert.notEqual(size, 1, 'Invalid close payload');
          this.closeCode = size >= 2 ? payload.readUInt16BE(0) : 1005;
          if (!this.closed) this.#frame(8, payload);
          this.#socket.end(); this.#finish(); return;
        }
        if (opcode === 9) this.#frame(10, payload);
        else assert.equal(opcode, 10, 'Unexpected control opcode');
        continue;
      }
      assert.ok(opcode === 0 || opcode === 1, 'Expected text frames');
      assert.equal(opcode === 0, this.#fragments.length > 0, 'Unexpected continuation');
      this.#fragmentBytes += payload.length;
      assert.ok(this.#fragmentBytes <= 65536, 'Server message too large');
      this.#fragments.push(payload);
      if (final) {
        const content = new TextDecoder('utf-8', { fatal: true }).decode(Buffer.concat(this.#fragments));
        this.#fragments = []; this.#fragmentBytes = 0;
        const value = JSON.parse(content);
        const index = this.#waiters.findIndex((waiter) => waiter.predicate(value));
        if (index >= 0) { const [waiter] = this.#waiters.splice(index, 1); clearTimeout(waiter.timer); waiter.resolve(value); }
        else { assert.ok(this.#messages.length < 128, 'Unconsumed server messages'); this.#messages.push(value); }
      }
    }
  }
  event(type, predicate = () => true, timeout = 10000) {
    const types = Array.isArray(type) ? type : [type];
    const match = (value) => types.includes(value.type) && predicate(value);
    const index = this.#messages.findIndex(match);
    if (index >= 0) return Promise.resolve(this.#messages.splice(index, 1)[0]);
    if (this.closed) return Promise.reject(new Error(`Socket closed before ${type}`));
    return new Promise((resolve, reject) => {
      const waiter = { predicate: match, resolve, reject, timer: undefined };
      waiter.timer = setTimeout(() => { this.#waiters = this.#waiters.filter((value) => value !== waiter); reject(new Error(`Timed out waiting for ${type}`)); }, timeout);
      this.#waiters.push(waiter);
    });
  }
  #finish() {
    if (this.closed) return;
    this.closed = true;
    for (const waiter of this.#waiters) { clearTimeout(waiter.timer); waiter.reject(new Error('Socket closed before expected event')); }
    this.#waiters = [];
    for (const resolve of this.#closeWaiters) resolve(this.closeCode);
    this.#closeWaiters = [];
  }
  waitClosed(timeout = 10000) {
    if (this.closed) return Promise.resolve(this.closeCode);
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Socket did not close')), timeout);
      this.#closeWaiters.push((code) => { clearTimeout(timer); resolve(code); });
    });
  }
  abort() { this.#socket.destroy(); this.#finish(); }
}
