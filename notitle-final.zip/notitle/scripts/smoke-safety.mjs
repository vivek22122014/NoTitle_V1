// Real Phase 5 HTTP/WebSocket gate. smoke-stack.sh must own a disposable stack.
// This script never prints message bodies, credentials, report handles or cookies.
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { setTimeout as delay } from 'node:timers/promises';
import { SmokeSocket } from './realtime-smoke-client.mjs';

const base = process.env.SMOKE_BASE_URL ?? 'http://web:8080';
const origin = process.env.SMOKE_PUBLIC_ORIGIN ?? 'http://localhost:8080';
const sockets = new Set();
const ordinaryCanary = 'PHASE5_ORDINARY_ONLY_9f1f572bd2a94469';
class Browser {
  jar = new Map(); csrf = ''; identity; policies;
  cookie() { return [...this.jar].map(([key, value]) => `${key}=${value}`).join('; '); }
  async api(path, method = 'GET', body, expected = 200, overrides = {}) {
    const headers = { Cookie: this.cookie() };
    if (method !== 'GET') Object.assign(headers, { Origin: origin, 'Content-Type': 'application/json', 'X-CSRF-Token': this.csrf });
    Object.assign(headers, overrides);
    const response = await fetch(base + '/api/v1' + path, {
      method, headers, body: body === undefined ? undefined : JSON.stringify(body),
      redirect: 'manual', signal: AbortSignal.timeout(15000)
    });
    assert.ok((Array.isArray(expected) ? expected : [expected]).includes(response.status), `${method} ${path}: unexpected HTTP status ${response.status}`);
    assert.match(response.headers.get('cache-control') ?? '', /no-store/);
    for (const cookie of response.headers.getSetCookie()) {
      const pair = cookie.split(';', 1)[0], split = pair.indexOf('=');
      const name = pair.slice(0, split), value = pair.slice(split + 1);
      if (!value || /Max-Age=0/i.test(cookie)) this.jar.delete(name); else this.jar.set(name, value);
    }
    const value = await response.json();
    if (value.csrf_token) this.csrf = value.csrf_token;
    if (value.identity) this.identity = value.identity;
    return value;
  }
  async guest(gender) {
    const bootstrap = await this.api('/auth/bootstrap'); this.policies = bootstrap.policies;
    await this.api('/guest/session', 'POST', {
      profile: { gender, topic: 'general_talk', bio: '', professional: {profession: '', industry: '', experience: '', interests: []} },
      consent: {adult_confirmed: true, policies: this.policies}
    }, 201);
    return this;
  }
  async register() {
    await this.api('/auth/register', 'POST', {
      username: 'sf_' + randomUUID().replaceAll('-', '').slice(0, 16),
      password: 'Disposable safety test password 6942', profile: this.identity.profile,
      consent: {adult_confirmed: true, policies: this.policies}
    }, 201);
    assert.equal(this.identity.kind, 'account');
  }
  async connect() {
    // Registration's durable safety fence can temporarily reject authorization
    // until its owner snapshot is finalized. Exercise explicit retry responses;
    // do not sleep unconditionally to conceal an unsafe publication race.
    for (let attempt = 0; attempt < 8; attempt++) {
      const ticket = await this.api('/realtime/ticket', 'POST', {takeover: false}, [201, 429, 503]);
      if (!ticket.ticket) {
        assert.ok(['rate_limited', 'temporarily_unavailable'].includes(ticket.error?.code));
        await delay(Math.min(100 * 2 ** attempt, 1000)); continue;
      }
      const socket = await SmokeSocket.open(base, origin, this.cookie()); sockets.add(socket);
      socket.send({v: 1, id: randomUUID(), type: 'session.authenticate', generation: 0, payload: {ticket: ticket.ticket, takeover: false}});
      const event = await socket.event(['session.ready', 'error']);
      if (event.type === 'session.ready') return {socket, state: event.payload};
      assert.ok(event.payload.retryable && ['RATE_LIMITED', 'NOT_AVAILABLE'].includes(event.payload.code), 'Connection failed outside the retryable handoff fence');
      await socket.waitClosed(); await delay(Math.min(100 * 2 **attempt, 1000));
    }
    throw new Error('Registered safety handoff did not finalize within the bounded retry budget');
  }
}
function command(connection, type, interaction, payload = {}, id = randomUUID()) {
  connection.socket.send({v: 1, id, type, generation: connection.state.generation,
    ...(interaction ? {interaction_id: interaction.id, epoch: interaction.epoch} : {}), payload});
  return id;
}
function reference(connection, interaction) {
  return {generation: connection.state.generation, interaction_id: interaction.id, epoch: interaction.epoch};
}
async function pair(a, b) {
  command(a, 'queue.join'); await a.socket.event('queue.joined');
  command(b, 'queue.join');
  const [first, second] = await Promise.all([a.socket.event('match.found'), b.socket.event('match.found')]);
  assert.equal(first.payload.interaction.id, second.payload.interaction.id);
  return first.payload.interaction;
}
async function send(sender, receiver, interaction, text, clientSendID = randomUUID()) {
  command(sender, 'chat.send', interaction, {client_send_id: clientSendID, text});
  const ack = await sender.socket.event('chat.ack', (event) => event.payload.client_send_id === clientSendID && event.payload.status === 'accepted');
  const message = await receiver.socket.event('chat.message', (event) => event.payload.client_send_id === clientSendID);
  assert.equal(message.payload.text, text, 'Text must retain literal characters');
  assert.equal(message.payload.sender, 'peer');
  assert.equal(message.payload.server_sequence, ack.payload.server_sequence);
  command(receiver, 'chat.delivery_ack', interaction, {server_sequence: ack.payload.server_sequence});
  const delivered = await sender.socket.event('chat.ack', (event) => event.payload.client_send_id === clientSendID && event.payload.status === 'delivered');
  assert.equal(delivered.payload.server_sequence, ack.payload.server_sequence);
  return ack.payload;
}
function blocks(value) { assert.ok(Array.isArray(value.blocks)); return value.blocks; }

try {
  // The private operations service is never mounted on the public router.
  for (const path of ['/admin', '/admin/cases', '/ops/cases', '/api/v1/admin/cases']) {
    const response = await fetch(base + path, {redirect: 'manual', signal: AbortSignal.timeout(10000)});
    assert.equal(response.status, 404, 'Private administration leaked through public routing');
  }
  const a = await new Browser().guest('male'), b = await new Browser().guest('female'), c = await new Browser().guest('other');
  const ac = await a.connect(), bc = await b.connect(), cc = await c.connect();
  const first = await pair(ac, bc);
  const literal = '<img src=x onerror=alert(1)> **plain** https://example.invalid 🙂';
  const one = await send(ac, bc, first, literal);
  // New command envelope, same application send ID: retry returns its original
  // sequence. A following new message proves no extra sequence was allocated.
  command(ac, 'chat.send', first, {client_send_id: one.client_send_id, text: literal});
  const retry = await ac.socket.event('chat.ack', (event) => event.payload.client_send_id === one.client_send_id);
  assert.equal(retry.payload.server_sequence, one.server_sequence);
  const two = await send(bc, ac, first, ordinaryCanary);
  assert.equal(two.server_sequence, one.server_sequence + 1);

  command(ac, 'chat.send', first, {client_send_id: randomUUID(), text: 'unsafe\u202econtrol'});
  assert.equal((await ac.socket.event('error', (event) => event.payload.code === 'INVALID_TEXT')).payload.code, 'INVALID_TEXT');
  await a.api('/reports/begin', 'POST', reference(ac, first), 403, {'X-CSRF-Token': 'invalid'});
  const draft = await a.api('/reports/begin', 'POST', reference(ac, first), 201);
  assert.equal(draft.metadata_only, false);
  assert.equal(draft.messages.length, 2);
  assert.equal(draft.messages[0].speaker, 'self');
  assert.equal(draft.messages[1].speaker, 'peer');

  // Report Begin must win its actor turn before peer Next. Its frozen evidence
  // survives normal transcript purge, while a new Begin after End is metadata only.
  command(bc, 'match.next', first);
  const ended = await ac.socket.event('match.ended');
  await bc.socket.event('queue.joined'); command(bc, 'queue.leave'); await bc.socket.event('queue.paused');
  assert.ok(ended.payload.ended_report_ref);
  const metadata = await a.api('/reports/begin', 'POST', {ended_ref: ended.payload.ended_report_ref}, 201);
  assert.equal(metadata.metadata_only, true); assert.deepEqual(metadata.messages, []);
  const submission = {handle: draft.handle, submission_id: randomUUID(), category: 'other', statement: 'Synthetic smoke statement.', selected_sequences: [one.server_sequence]};
  await c.api('/reports', 'POST', submission, 410);
  await a.api('/reports', 'POST', {...submission, transcript: [{text: 'Fabricated'}]}, 400);
  await a.api('/reports', 'POST', {...submission, selected_sequences: [999999]}, 400);
  const receipt = await a.api('/reports', 'POST', submission, 201);
  assert.ok(receipt.case_ref); assert.equal(receipt.blocked, false);
  const repeated = await a.api('/reports', 'POST', submission, 201);
  assert.equal(repeated.case_ref, receipt.case_ref, 'Submission retry created another case');
  await a.api('/reports', 'POST', {...submission, statement: 'Changed statement'}, 409);
  await a.api('/reports', 'POST', {handle: metadata.handle, submission_id: randomUUID(), category: 'other', statement: 'Metadata-only smoke report.', selected_sequences: []}, 201);
  const stale = command(ac, 'chat.send', first, {client_send_id: randomUUID(), text: 'Must not send after end'});
  assert.equal((await ac.socket.event('error', (event) => event.reply_to === stale)).payload.code, 'STALE_EPOCH');

  const second = await pair(ac, cc);
  const combined = await a.api('/reports/begin', 'POST', {...reference(ac, second), block: true}, 201);
  assert.equal(combined.blocked, true);
  await ac.socket.event('match.ended'); await cc.socket.event('match.ended');
  const combinedSubmission = {handle: combined.handle, submission_id: randomUUID(), category: 'spam', statement: 'Synthetic combined action.', selected_sequences: []};
  const combinedReceipt = await a.api('/reports', 'POST', combinedSubmission, 201);
  assert.equal(combinedReceipt.blocked, true);
  const temporary = blocks(await a.api('/blocks'));
  assert.equal(temporary.length, 1); assert.equal(temporary[0].durable, false);
  assert.deepEqual(blocks(await c.api('/blocks')), [], 'Do not reveal incoming blocks');
  const denied = command(cc, 'chat.send', second, {client_send_id: randomUUID(), text: 'Must not send after block'});
  assert.equal((await cc.socket.event('error', (event) => event.reply_to === denied)).payload.code, 'STALE_EPOCH');
  await a.api('/blocks/' + temporary[0].ref, 'DELETE', {});
  assert.deepEqual(blocks(await a.api('/blocks')), []);
  const afterUnblockRetry = await a.api('/reports', 'POST', combinedSubmission, 201);
  assert.equal(afterUnblockRetry.case_ref, combinedReceipt.case_ref);
  assert.deepEqual(blocks(await a.api('/blocks')), [], 'A report receipt retry must not recreate a removed block');

  // Ordinary-only text was never selected for evidence. The companion SQL/log
  // gate inspects storage after this test; it must find exactly one evidence row.
  // Registration closes guest transports and preserves the same participant slot.
  await b.api('/auth/logout', 'POST', {}); await bc.socket.waitClosed();
  await a.register(); await ac.socket.waitClosed();
  const registeredA = await a.connect();
  await c.register(); await cc.socket.waitClosed();
  const registeredC = await c.connect();
  // The prior pair's strict four-second cooldown may still be in force.
  const third = await pair(registeredA, registeredC);
  const durable = await a.api('/blocks', 'POST', reference(registeredA, third), 201);
  assert.equal(durable.durable, true); assert.equal(durable.pending, false);
  await registeredA.socket.event('match.ended'); await registeredC.socket.event('match.ended');
  const durableList = blocks(await a.api('/blocks'));
  assert.equal(durableList.length, 1); assert.equal(durableList[0].durable, true);
  await a.api('/blocks/' + durableList[0].ref, 'DELETE', {});
  assert.deepEqual(blocks(await a.api('/blocks')), []);
  await a.api('/auth/logout', 'POST', {}); await c.api('/auth/logout', 'POST', {});
  console.log('Real safety lifecycle passed: sequenced text/ACK retry, literal payloads, stale epochs, frozen and metadata-only reports, ownership/provenance rejection, idempotency, guest/durable blocks and private-admin routing.');
} finally {
  for (const socket of sockets) socket.abort();
}
