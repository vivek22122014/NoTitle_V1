// Runs only inside isolated test-browser contexts. No SDP, ICE addresses,
// usernames, cookies, messages or resume proofs are copied into load reports.
export function installLoadObserver(approvedRelayHosts) {
  const peers = new Set(), sockets = new Set(), previous = new WeakMap();
  let socket, state = 'OFFLINE', generation = 0, interaction, errors = [], callStarted = 0;
  let setup = [], sent = 0, received = 0, accepted = 0, delivered = 0, errorCount = 0, connected = false;
  const NativeSocket = window.WebSocket, NativePeer = window.RTCPeerConnection;
  class ObservedSocket extends NativeSocket {
    constructor(...args) {
      super(...args); sockets.add(this); socket = this;
      this.addEventListener('close', () => { sockets.delete(this); if (socket === this) connected = false; });
      this.addEventListener('message', (event) => {
        try {
          const frame = JSON.parse(event.data), p = frame.payload;
          if (['session.ready', 'session.state', 'match.found', 'queue.joined', 'queue.paused', 'match.ended'].includes(frame.type)) {
            if (p.state) state = p.state;
            if (p.generation) generation = p.generation;
            if (frame.generation) generation = frame.generation;
            interaction = p.interaction;
            if (frame.type === 'match.found') state = 'MATCHED';
            if (frame.type === 'queue.joined') state = 'WAITING';
            if (frame.type === 'match.ended') state = 'IDLE';
            if (frame.type === 'session.ready') connected = true;
          }
          if (frame.type === 'error') { errorCount++; errors.push(String(p.code)); if (errors.length > 64) errors.shift(); }
          if (frame.type === 'chat.message' && p.sender === 'peer' && !p.replay) received++;
          if (frame.type === 'chat.ack' && p.status === 'accepted') accepted++;
          if (frame.type === 'chat.ack' && p.status === 'delivered') delivered++;
        } catch { /* Production client validates malformed frames. */ }
      });
    }
    send(raw) {
      try { const frame = JSON.parse(raw); if (frame.type === 'call.request' || frame.type === 'call.accept') callStarted = performance.now(); if (frame.type === 'chat.send') sent++; } catch { /* Never retain raw payload. */ }
      return super.send(raw);
    }
  }
  class ObservedPeer extends NativePeer {
    constructor(config) {
      if (config?.iceTransportPolicy !== 'relay') throw new Error('Load run refuses direct media');
      for (const server of config.iceServers ?? []) for (const url of Array.isArray(server.urls) ? server.urls : [server.urls]) {
        const host = /^turns?:([^:/?#]+)(?::\d+)?(?:\?transport=(?:udp|tcp))?$/.exec(url)?.[1];
        if (!host || !approvedRelayHosts.includes(host)) throw new Error('Unapproved test relay');
      }
      super(config); peers.add(this);
      this.addEventListener('connectionstatechange', () => {
        if (this.connectionState === 'connected' && callStarted) { setup.push(performance.now() - callStarted); callStarted = 0; }
        if (this.connectionState === 'closed') peers.delete(this);
      });
    }
  }
  window.WebSocket = ObservedSocket; window.RTCPeerConnection = ObservedPeer;
  // The observer never manufactures RTC stats or overrides microphone capture.
  window.__notitleLoad = {
    state: () => ({ connected, state, errors: [...errors], sent, received, accepted, delivered, errorCount }),
    clearErrors() { errors = []; },
    text() {
      if (!connected || state !== 'MATCHED' || !interaction || socket?.readyState !== 1) return false;
      socket.send(JSON.stringify({ v: 1, id: crypto.randomUUID(), type: 'chat.send', generation, interaction_id: interaction.id, epoch: interaction.epoch, payload: { client_send_id: crypto.randomUUID(), text: 'Consenting synthetic load participant.' } }));
      return true;
    },
    disconnect() { connected = false; socket?.close(1000, ''); },
    async sample() {
      let active = 0, senders = 0, receivers = 0, relay = 0, nonrelay = 0;
      for (const pc of peers) {
        if (pc.connectionState !== 'connected') continue;
        active++;
        const stats = await pc.getStats(); let out = 0, incoming = 0, selected;
        for (const s of stats.values()) {
          if (s.type === 'outbound-rtp' && (s.kind ?? s.mediaType) === 'audio') out += s.bytesSent ?? 0;
          if (s.type === 'inbound-rtp' && (s.kind ?? s.mediaType) === 'audio') incoming += s.bytesReceived ?? 0;
          if (s.type === 'transport' && s.selectedCandidatePairId) selected = stats.get(s.selectedCandidatePairId);
        }
        if (!selected) for (const s of stats.values()) if (s.type === 'candidate-pair' && s.state === 'succeeded' && s.nominated) selected = s;
        const local = selected && stats.get(selected.localCandidateId), remote = selected && stats.get(selected.remoteCandidateId);
        if (local?.candidateType === 'relay' && remote?.candidateType === 'relay') relay++; else nonrelay++;
        const old = previous.get(pc); if (old && out > old.out) senders++; if (old && incoming > old.incoming) receivers++;
        previous.set(pc, { out, incoming });
      }
      return { connected, state, active, senders, receivers, relay, nonrelay, setup: [...setup], sent, received, accepted, delivered, errorCount };
    },
    stop() { for (const pc of peers) { for (const sender of pc.getSenders()) sender.track?.stop(); pc.close(); } for (const ws of sockets) ws.close(1000, ''); peers.clear(); }
  };
}

export class Participant {
  constructor(context, page, kind) { this.context = context; this.page = page; this.kind = kind; this.csrf = ''; }
  async api(path, method = 'GET', data) {
    const r = await this.context.request.fetch('/api/v1' + path, { method, data, headers: method === 'GET' ? {} : { Origin: this.origin, 'X-CSRF-Token': this.csrf }, maxRedirects: 0, timeout: 15000 });
    if (!r.ok()) throw new Error('Load fixture API rejected');
    const body = await r.json(); if (body.csrf_token) this.csrf = body.csrf_token; return body;
  }
  static async create(browser, permit, fixture, { waiting = false, httpCredentials } = {}) {
    const context = await browser.newContext({ baseURL: permit.origin, viewport: { width: 390, height: 844 }, permissions: ['microphone'], httpCredentials, serviceWorkers: 'block' });
    // Never send fixture cookies or basic-auth credentials to any other origin.
    await context.route('**/*', (route) => new URL(route.request().url()).origin === permit.origin ? route.continue() : route.abort());
    await context.addInitScript(installLoadObserver, permit.relay_hosts);
    const page = await context.newPage(); page.setDefaultTimeout(15000);
    const p = new Participant(context, page, fixture ? 'account' : 'guest'); p.origin = permit.origin;
    try {
      const bootstrap = await p.api('/auth/bootstrap');
      if (fixture) {
        await p.api('/auth/login', 'POST', { username: fixture.username, password: fixture.password });
        const me = await p.api('/me');
        if (waiting && me.identity?.profile?.gender !== 'male') throw new Error('Waiting fixtures must be male accounts');
      } else await p.api('/guest/session', 'POST', { profile: { gender: 'other', topic: 'general_talk', bio: '', professional: { profession: '', industry: '', experience: '', interests: [] } }, consent: { adult_confirmed: true, policies: bootstrap.policies } });
      if (waiting) {
        const preference = await p.api('/me/matching-preferences');
        if (!preference.premium_active || Date.parse(preference.premium_expires_at) < Date.now() + 8 * 3600000) throw new Error('Waiting fixtures require existing trusted Premium valid for eight hours');
        await p.api('/me/matching-preferences', 'PATCH', { ...preference.preferences, gender: 'female' });
      }
      await page.goto('/chat', { waitUntil: 'domcontentloaded' });
      await page.getByRole('button', { name: 'Find a match', exact: true }).waitFor();
      return p;
    } catch { await context.close(); throw new Error('Could not initialize isolated load participant'); }
  }
  async search() { await this.page.getByRole('button', { name: 'Find a match', exact: true }).click(); }
  async wait(state) { await this.page.waitForFunction((s) => window.__notitleLoad?.state().state === s, state); }
  async sample() { return this.page.evaluate(() => window.__notitleLoad.sample()); }
  async text() { return this.page.evaluate(() => window.__notitleLoad.text()); }
  async close() { await this.page.evaluate(() => window.__notitleLoad?.stop()).catch(() => {}); await this.context.close(); }
}
export async function pair(a, b) { await a.search(); await b.search(); await Promise.all([a.wait('MATCHED'), b.wait('MATCHED')]); }
export async function call(a, b) {
  await a.page.getByRole('button', { name: 'Call partner', exact: true }).click();
  await b.page.getByRole('button', { name: 'Accept audio call', exact: true }).click();
  await Promise.all([a, b].map((p) => p.page.waitForFunction(async () => (await window.__notitleLoad.sample()).active === 1)));
}
