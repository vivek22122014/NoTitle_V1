#!/usr/bin/env node
// Local adapter only: no network/authentication, endpoint creation or remote
// command. Run on the application host, under the protected collector user.
import fs from 'node:fs/promises';
import { constants } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { readProtectedJSON } from './load-soak.mjs';
import { validatePermit } from './load-contract.mjs';
export const BOUNDS = [1, 5, 10, 25, 50, 100, 250, 300, 1000, null];
export function histogramMetric(metric) {
  if (!metric || typeof metric.scope !== 'string' || !Number.isSafeInteger(metric.samples) || metric.samples < 0 || !Array.isArray(metric.buckets) || metric.buckets.length !== BOUNDS.length || metric.buckets.some((n) => !Number.isSafeInteger(n) || n < 0) || metric.buckets.reduce((a, b) => a + b, 0) !== metric.samples) throw new Error('Invalid fixed server histogram');
  let count = 0, p95 = null;
  if (metric.samples) for (let i = 0; i < BOUNDS.length; i++) { count += metric.buckets[i]; if (count >= Math.ceil(metric.samples * .95)) { p95 = BOUNDS[i]; break; } }
  // Preserve the scope verbatim. A selected-pair scan cannot pass the separate
  // full compatible-availability-to-commit requirement.
  return { scope: metric.scope, samples: metric.samples, p95_ms: p95 };
}
export function subtractHistogram(current, baseline) {
  histogramMetric(current); histogramMetric(baseline);
  if (current.scope !== baseline.scope || current.samples < baseline.samples || current.buckets.some((n, i) => n < baseline.buckets[i])) throw new Error('Server histogram reset or scope changed');
  return histogramMetric({ scope: current.scope, samples: current.samples - baseline.samples, buckets: current.buckets.map((n, i) => n - baseline.buckets[i]) });
}
export function captureBaseline(permit, metrics, ready, now = Date.now()) {
  const requested = Date.parse(ready?.baseline_requested_at), sampled = Date.parse(metrics?.sampled_at);
  if (!Number.isFinite(requested) || !Number.isFinite(sampled) || requested > now || now - requested > 60000 || sampled < requested || sampled > now + 5000 || now - sampled > 30000) throw new Error('Baseline must follow a fresh ready checkpoint');
  if (!ready.run_id || ready.started_at !== null || ready.origin !== permit.origin || ready.source_sha256 !== permit.source_sha256 || ['api', 'web', 'migrate', 'postgres', 'turn'].some((k) => ready.image_digests?.[k] !== permit.image_digests?.[k])) throw new Error('Baseline release/run binding differs');
  if (!Number.isFinite(Date.parse(metrics.window_started_at)) || Date.parse(metrics.window_started_at) > sampled) throw new Error('Invalid process measurement window');
  const server = Object.fromEntries(['api', 'message', 'match'].map((key) => { const m = metrics.server?.[key]; histogramMetric(m); return [key, { scope: m.scope, samples: m.samples, buckets: [...m.buckets] }]; }));
  return { schema_version: 'notitle-load-baseline-v1', run_id: ready.run_id, origin: permit.origin, source_sha256: permit.source_sha256, image_digests: permit.image_digests, baseline_at: new Date(sampled).toISOString(), process_started_at: metrics.window_started_at, server };
}
export function memoryBytes(meminfo) {
  const read = (key) => { const values = [...meminfo.matchAll(new RegExp(`^${key}:\\s+(\\d+) kB$`, 'gm'))]; if (values.length !== 1) throw new Error('Missing host memory observation'); const n = Number(values[0][1]) * 1024; if (!Number.isSafeInteger(n) || n < 0) throw new Error('Invalid host memory observation'); return n; };
  const total_bytes = read('MemTotal'), available_bytes = read('MemAvailable'); if (!total_bytes || available_bytes > total_bytes) throw new Error('Invalid host headroom'); return { total_bytes, available_bytes };
}
export function collectObservation(permit, metrics, jobs, meminfo, baselineRecord, now = Date.now()) {
  const baseline = baselineRecord?.value;
  if (baseline?.schema_version !== 'notitle-load-baseline-v1' || !/^[a-f0-9]{64}$/.test(baselineRecord?.sha256 ?? '') || !baseline.run_id || baseline.origin !== permit.origin || baseline.source_sha256 !== permit.source_sha256 || ['api', 'web', 'migrate', 'postgres', 'turn'].some((k) => baseline.image_digests?.[k] !== permit.image_digests?.[k])) throw new Error('Protected baseline binding is required');
  if (metrics?.window_started_at !== baseline.process_started_at || !Number.isFinite(Date.parse(baseline.baseline_at)) || Date.parse(metrics.sampled_at) < Date.parse(baseline.baseline_at)) throw new Error('Process restart or baseline ordering changed');
  if (jobs?.origin !== permit.origin || jobs?.source_sha256 !== permit.source_sha256 || jobs?.application_host !== true) throw new Error('Observation host/release binding is required');
  for (const value of [metrics?.sampled_at, jobs.observed_at]) if (!Number.isFinite(Date.parse(value)) || now - Date.parse(value) > 30000 || Date.parse(value) > now + 5000) throw new Error('Exported measurement is stale');
  if (!Number.isFinite(Date.parse(metrics.window_started_at)) || Date.parse(metrics.window_started_at) > Date.parse(metrics.sampled_at)) throw new Error('Missing actual server observation window');
  for (const key of ['go_heap_bytes', 'goroutines']) if (!Number.isSafeInteger(metrics.process?.[key]) || metrics.process[key] < 0) throw new Error('Missing actual process observation');
  const server = Object.fromEntries(['api', 'message', 'match'].map((key) => [key, subtractHistogram(metrics.server?.[key], baseline.server?.[key])]));
  if (jobs.match_commit !== undefined) throw new Error('Separate matching overrides are not accepted; use the bound server histogram');
  const queues = Object.fromEntries(['bounded', 'ungranted_captures', 'overdue_jobs', 'goroutines_limit'].map((k) => [k, jobs.queues?.[k] ?? null]));
  const workload = Object.fromEntries(['payment_job', 'backup', 'moderation', 'safety_event'].map((k) => [k, jobs.workload?.[k] ?? null]));
  return { schema_version: 'notitle-load-observation-v1', origin: permit.origin, source_sha256: permit.source_sha256, run_id: baseline.run_id, baseline_sha256: baselineRecord.sha256, observed_at: new Date(Math.min(now, Date.parse(metrics.sampled_at), Date.parse(jobs.observed_at))).toISOString(), window_started_at: baseline.baseline_at, host: { ...memoryBytes(meminfo), go_heap_bytes: metrics.process.go_heap_bytes, goroutines: metrics.process.goroutines }, server, queues, workload, ...(jobs.overload ? { overload: Object.fromEntries(['safety_events_preserved', 'normal_cleanup_ms', 'orphan_cleanup_ms', 'cleanup_observation_verified'].map((k) => [k, jobs.overload[k] ?? null])) } : {}) };
}
async function writeExclusive(outputPath, result) {
  const file = await fs.open(outputPath, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 0o600);
  try { await file.writeFile(JSON.stringify(result) + '\n'); await file.sync(); } finally { await file.close(); }
}
export async function baseline({ permitPath, metricsPath, readyPath, outputPath }) {
  const permit = validatePermit((await readProtectedJSON(permitPath)).value);
  const metrics = (await readProtectedJSON(metricsPath)).value, ready = (await readProtectedJSON(readyPath)).value;
  const result = captureBaseline(permit, metrics, ready); await writeExclusive(outputPath, result); return result;
}
export async function collect({ permitPath, metricsPath, jobsPath, baselinePath, outputPath }) {
  const permit = validatePermit((await readProtectedJSON(permitPath)).value);
  const metrics = (await readProtectedJSON(metricsPath)).value, jobs = (await readProtectedJSON(jobsPath)).value;
  // This must be the app host's procfs. Running on the browser generator would
  // measure the wrong machine and requires application_host=false (rejected).
  const meminfo = await fs.readFile('/proc/meminfo', 'utf8');
  const result = collectObservation(permit, metrics, jobs, meminfo, await readProtectedJSON(baselinePath));
  const temporary = outputPath + '.new';
  const file = await fs.open(temporary, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 0o600);
  try { await file.writeFile(JSON.stringify(result) + '\n'); await file.sync(); } finally { await file.close(); }
  try { const old = await fs.lstat(outputPath); if (!old.isFile() || (old.mode & 0o077) || (process.geteuid && old.uid !== process.geteuid())) throw new Error('Unsafe prior observation'); } catch (error) { if (error.code !== 'ENOENT') { await fs.unlink(temporary); throw error; } }
  await fs.rename(temporary, outputPath); return result;
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const [mode, permitPath, metricsPath, third, fourth, fifth] = process.argv.slice(2);
  try {
    if (mode === 'baseline' && fourth && !fifth) await baseline({ permitPath, metricsPath, readyPath: third, outputPath: fourth });
    else if (mode === 'collect' && fifth) await collect({ permitPath, metricsPath, jobsPath: third, baselinePath: fourth, outputPath: fifth });
    else throw new Error('Use baseline PERMIT METRICS READY_REPORT NEW_BASELINE or collect PERMIT METRICS JOBS BASELINE OUT');
    console.log('Protected load measurement written.');
  } catch { console.error('Load observation rejected: missing, stale, unsafe, reset or inconsistent measured evidence.'); process.exitCode = 1; }
}
