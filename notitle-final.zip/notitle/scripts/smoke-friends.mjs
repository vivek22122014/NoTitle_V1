// Real Phase 6 HTTP/WebSocket gate for the disposable smoke-stack only.
// No credentials, user payloads, opaque handles or message content are logged.
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { setTimeout as delay } from 'node:timers/promises';
import { SmokeSocket } from './realtime-smoke-client.mjs';

const base = process.env.SMOKE_BASE_URL ?? 'http://web:8080';
const origin = process.env.SMOKE_PUBLIC_ORIGIN ?? 'http://localhost:8080';
const sockets = new Set();
class Browser {
  jar = new Map(); csrf = ''; identity; policies; username;
  password = 'Disposable friendship test password 6942';
  cookie() { return [...this.jar].map(([key, value]) => `${key}=${value}`).join('; '); }
  async api(path, method = 'GET', body, expected = 200, overrides = {}) {
    const headers = { Cookie: this.cookie() };
    if (method !== 'GET') Object.assign(headers, { Origin: origin, 'Content-Type': 'application/json', 'X-CSRF-Token': this.csrf });
    Object.assign(headers, overrides);
    const response = await fetch(base + '/api/v1' + path, {
      method, headers, body: body === undefined ? undefined : JSON.stringify(body),
      redirect: 'manual', signal: AbortSignal.timeout(15000)
    });
    assert.ok((Array.isArray(expected) ? expected : [expected]).includes(response.status), `Unexpected ${method} API status ${response.status}`);
    assert.match(response.headers.get('cache-control') ?? '', /no-store/);
    for (const cookie of response.headers.getSetCookie()) {
      const pair = cookie.split(';', 1)[0], split = pair.indexOf('=');
      const name = pair.slice(0, split), value = pair.slice(split + 1);
      if (!value || /Max-Age=0/i.test(cookie)) this.jar.delete(name); else this.jar.set(name, value);
    }
    const value = await response.json();
    if (value.csrf_token) this.csrf = value.csrf_token;
    if (value.identity) this.identity = value.identity;
    return value;
  }
  async guest(gender) {
    const bootstrap = await this.api('/auth/bootstrap'); this.policies = bootstrap.policies;
    await this.api('/guest/session', 'POST', {
      profile: { gender, topic: 'general_talk', bio: '', professional: {profession: '', industry: '', experience: '', interests: []} },
      consent: {adult_confirmed: true, policies: this.policies}
    }, 201);
    return this;
  }
  async register() {
    this.username = 'fr_' + randomUUID().replaceAll('-', '').slice(0, 16);
    await this.api('/auth/register', 'POST', {
      username: this.username, password: this.password, profile: this.identity.profile,
      consent: {adult_confirmed: true, policies: this.policies}
    }, 201);
    assert.equal(this.identity.kind, 'account');
  }
  async login() {
    await this.api('/auth/bootstrap');
    await this.api('/auth/login', 'POST', {username: this.username, password: this.password});
  }
  async connect(resume) {
    // Registration's durable safety fence can temporarily reject authorization
    // until its owner snapshot is finalized. Exercise explicit retry responses;
    // do not sleep unconditionally to conceal an unsafe publication race.
    for (let attempt = 0; attempt < 8; attempt++) {
      const ticket = await this.api('/realtime/ticket', 'POST', {takeover: false}, [201, 429, 503]);
      if (!ticket.ticket) {
        assert.ok(['rate_limited', 'temporarily_unavailable'].includes(ticket.error?.code));
        await delay(Math.min(100 * 2 ** attempt, 1000)); continue;
      }
      const socket = await SmokeSocket.open(base, origin, this.cookie()); sockets.add(socket);
      socket.send({v: 1, id: randomUUID(), type: 'session.authenticate', generation: 0, payload: {ticket: ticket.ticket, takeover: false, ...(resume ? {resume} : {})}});
      const event = await socket.event(['session.ready', 'error']);
      if (event.type === 'session.ready') return {socket, state: event.payload};
      assert.ok(event.payload.retryable && ['RATE_LIMITED', 'NOT_AVAILABLE'].includes(event.payload.code), 'Connection failed outside the retryable handoff fence');
      await socket.waitClosed(); await delay(Math.min(100 * 2 **attempt, 1000));
    }
    throw new Error('Registered safety handoff did not finalize within the bounded retry budget');
  }
}
function command(connection, type, interaction, payload = {}, id = randomUUID()) {
  connection.socket.send({v: 1, id, type, generation: connection.state.generation,
    ...(interaction ? {interaction_id: interaction.id, epoch: interaction.epoch} : {}), payload});
  return id;
}
function reference(connection, interaction) {
  return {generation: connection.state.generation, interaction_id: interaction.id, epoch: interaction.epoch};
}
async function pair(a, b) {
  command(a, 'queue.join'); await a.socket.event('queue.joined');
  command(b, 'queue.join');
  const [first, second] = await Promise.all([a.socket.event('match.found'), b.socket.event('match.found')]);
  assert.ok(first.payload.interaction.id === second.payload.interaction.id, 'Both participants must own the same interaction');
  return first.payload.interaction;
}
function friends(value) {
  assert.ok(Array.isArray(value.friends));
  for (const friend of value.friends) {
    assert.deepEqual(Object.keys(friend).sort(), ['created_at', 'display_name', 'durable', 'pending', 'presence', 'ref']);
    assert.ok(['online', 'busy', 'offline'].includes(friend.presence));
    assert.match(friend.ref, /^[A-Za-z0-9_-]{16,128}$/);
  }
  return value.friends;
}
async function list(browser) {
  // A concurrently committed safety/friend mutation can invalidate a read's
  // owner fence. Retry only explicit transient responses, within a fixed bound.
  for (let attempt = 0; attempt < 8; attempt++) {
    const value = await browser.api('/friends', 'GET', undefined, [200, 429, 503]);
    if (Array.isArray(value.friends)) return friends(value);
    assert.ok(['rate_limited', 'temporarily_unavailable'].includes(value.error?.code), 'Friend list failed outside a retryable authorization fence');
    await delay(Math.min(100 * 2 ** attempt, 1000));
  }
  throw new Error('Friend list did not stabilize within the bounded retry budget');
}
async function end(a, b, interaction) {
  command(a, 'match.end', interaction);
  await Promise.all([a.socket.event('match.ended'), b.socket.event('match.ended')]);
}
async function connectFriends(a, b, interaction) {
  command(a, 'friend.request', interaction);
  await a.socket.event('friend.request.sent');
  const incoming = await b.socket.event('friend.request.received');
  command(b, 'friend.accept', interaction, {request_ref: incoming.payload.request_ref});
  await Promise.all([a.socket.event('friend.created'), b.socket.event('friend.created')]);
}
async function invite(a, b, friendRef) {
  command(a, 'friend.invite', undefined, {friend_ref: friendRef, kind: 'text'});
  const sent = await a.socket.event('friend.invitation.sent');
  const incoming = await b.socket.event('friend.invitation.incoming');
  assert.ok(incoming.payload.invitation_ref === sent.payload.invitation_ref, 'Invitation references disagree');
  assert.equal(incoming.payload.kind, 'text');
  const remaining = Date.parse(incoming.payload.expires_at) - Date.now();
  assert.ok(remaining > 0 && remaining <= 31000, 'Invitation must expire after 30 seconds');
  command(b, 'friend.accept_invite', undefined, {invitation_ref: incoming.payload.invitation_ref});
  const [first, second] = await Promise.all([a.socket.event('match.found'), b.socket.event('match.found')]);
  assert.ok(first.payload.interaction.id === second.payload.interaction.id, 'Both participants must own the same interaction');
  assert.equal(first.payload.interaction.kind, 'friend');
  return first.payload.interaction;
}
async function eventuallyList(browser, predicate, description) {
  for (let attempt = 0; attempt < 20; attempt++) {
    const value = await list(browser);
    if (predicate(value)) return value;
    await delay(250);
  }
  throw new Error(description);
}

try {
  await new Browser().api('/friends', 'GET', undefined, 401);
  const a = await new Browser().guest('male'), b = await new Browser().guest('female'), c = await new Browser().guest('other');
  let ac = await a.connect(), bc = await b.connect(); const cc = await c.connect();
  assert.equal(ac.state.friends_enabled, true);
  assert.deepEqual(await list(a), []); assert.deepEqual(await list(c), []);
  const first = await pair(ac, bc);
  command(ac, 'friend.request', first);
  const sent = await ac.socket.event('friend.request.sent');
  const incoming = await bc.socket.event('friend.request.received');
  assert.ok(sent.payload.request_ref === incoming.payload.request_ref, 'Request references disagree');
  assert.deepEqual(await list(a), [], 'A single request must not establish a friendship or reveal presence');
  assert.deepEqual(await list(b), []);
  // Simultaneous/reciprocal affirmative requests produce one normalized link.
  command(bc, 'friend.request', first);
  await Promise.all([ac.socket.event('friend.created'), bc.socket.event('friend.created')]);
  let af = await list(a), bf = await list(b);
  assert.equal(af.length, 1); assert.equal(bf.length, 1);
  assert.equal(af[0].durable, false); assert.equal(af[0].pending, false);
  assert.equal(af[0].presence, 'busy');
  assert.deepEqual(await list(c), [], 'An unrelated guest cannot enumerate friends or presence');
  await a.api('/friends/' + af[0].ref, 'DELETE', {}, 403, {'X-CSRF-Token': 'invalid'});
  await c.api('/friends/' + af[0].ref, 'DELETE', {}, 404);
  assert.equal((await list(a)).length, 1, 'Another identity removed an unowned relationship');
  await end(ac, bc, first);
  af = await list(a); assert.equal(af[0].presence, 'online');

  const friendChat = await invite(ac, bc, af[0].ref);
  const overlapping = command(ac, 'queue.join');
  await ac.socket.event('error', (event) => event.reply_to === overlapping);
  const sendID = randomUUID(); command(ac, 'chat.send', friendChat, {client_send_id: sendID, text: 'Synthetic friend conversation.'});
  await bc.socket.event('chat.message', (event) => event.payload.client_send_id === sendID);
  await end(ac, bc, friendChat);

  const busyChat = await pair(bc, cc);
  assert.equal((await list(a))[0].presence, 'busy');
  const busyInvite = command(ac, 'friend.invite', undefined, {friend_ref: af[0].ref, kind: 'text'});
  await ac.socket.event('error', (event) => event.reply_to === busyInvite);
  const busySend = randomUUID(); command(bc, 'chat.send', busyChat, {client_send_id: busySend, text: 'Existing conversation remains active.'});
  await cc.socket.event('chat.message', (event) => event.payload.client_send_id === busySend);
  await end(bc, cc, busyChat);

  // Same guest cookie and RAM proof preserve accepted links through reconnect.
  const old = ac.state; ac.socket.abort();
  ac = await a.connect({token: old.resume_token, server_instance: old.server_instance, generation: old.generation});
  assert.ok((await list(a))[0].ref === af[0].ref, 'Reconnect lost the accepted relationship');

  // One registration keeps a guest link temporary; both promote only after SQL.
  await a.register(); await ac.socket.waitClosed(); ac = await a.connect();
  assert.equal((await list(a))[0].durable, false);
  assert.equal((await list(b))[0].durable, false);
  await b.register(); await bc.socket.waitClosed(); bc = await b.connect();
  af = await eventuallyList(a, (value) => value.length === 1 && value[0].durable && !value[0].pending, 'Mutually accepted guest link did not commit after both registrations');
  bf = await list(b); assert.equal(bf.length, 1); assert.equal(bf[0].durable, true);
  await a.api('/auth/logout', 'POST', {}); await ac.socket.waitClosed();
  assert.equal((await list(b))[0].presence, 'offline');
  await a.login(); ac = await a.connect();
  af = await list(a); assert.equal(af.length, 1); assert.equal(af[0].durable, true);

  // Remove ends a friend conversation, invalidates the handle and preserves no
  // implicit consent for a future recontact.
  const removedChat = await invite(ac, bc, af[0].ref);
  await a.api('/friends/' + af[0].ref, 'DELETE', {});
  await Promise.all([ac.socket.event('match.ended'), bc.socket.event('match.ended')]);
  assert.deepEqual(await list(a), []); assert.deepEqual(await list(b), []);
  const staleInvite = command(bc, 'friend.invite', undefined, {friend_ref: bf[0].ref, kind: 'text'});
  await bc.socket.event('error', (event) => event.reply_to === staleInvite);
  const staleChat = command(ac, 'chat.send', removedChat, {client_send_id: randomUUID(), text: 'Stale friend epoch.'});
  await ac.socket.event('error', (event) => event.reply_to === staleChat);

  // Re-consent is possible in a new random interaction; Block then removes the
  // durable relationship in the same database transaction. Unblock never restores it.
  const finalChat = await pair(ac, bc); await connectFriends(ac, bc, finalChat);
  await eventuallyList(a, (value) => value.length === 1 && value[0].durable, 'New mutual consent did not commit');
  const block = await a.api('/blocks', 'POST', reference(ac, finalChat), 201);
  assert.equal(block.durable, true);
  await Promise.all([ac.socket.event('match.ended'), bc.socket.event('match.ended')]);
  assert.deepEqual(await list(a), []); assert.deepEqual(await list(b), []);
  await a.api('/blocks/' + block.ref, 'DELETE', {});
  assert.deepEqual(await list(a), []); assert.deepEqual(await list(b), []);
  await a.api('/auth/logout', 'POST', {}); await b.api('/auth/logout', 'POST', {}); await c.api('/auth/logout', 'POST', {});

  // An explicit refusal stays private: the requester gets no refusal event and
  // sees its unchanged sent request when taking a same-epoch snapshot.
  const d = await new Browser().guest('male'), e = await new Browser().guest('female');
  let dc = await d.connect(); const ec = await e.connect(); const refusedChat = await pair(dc, ec);
  command(dc, 'friend.request', refusedChat); await dc.socket.event('friend.request.sent');
  const declined = await ec.socket.event('friend.request.received');
  const declineID = command(ec, 'friend.decline', refusedChat, {request_ref: declined.payload.request_ref});
  await ec.socket.event('command.ack', (event) => event.reply_to === declineID);
  const retrySent = command(dc, 'friend.request', refusedChat);
  const retryResponse = await dc.socket.event(['command.ack', 'error'], (event) => event.reply_to === retrySent);
  assert.equal(retryResponse.type, 'command.ack', 'A sender retry must not reveal whether the recipient declined');
  const prior = dc.state; dc.socket.abort();
  dc = await d.connect({token: prior.resume_token, server_instance: prior.server_instance, generation: prior.generation, interaction_id: refusedChat.id, epoch: refusedChat.epoch});
  assert.equal(dc.state.friend_request?.direction, 'outgoing');
  assert.deepEqual(await list(d), []); assert.deepEqual(await list(e), []);
  await end(dc, ec, refusedChat);
  const cleanupChat = await pair(dc, ec); await connectFriends(dc, ec, cleanupChat);
  await d.api('/auth/logout', 'POST', {}); await dc.socket.waitClosed();
  assert.deepEqual(await list(e), [], 'Ended guest identity left a dead peer in the friend list');
  await e.api('/auth/logout', 'POST', {});
  console.log('Real friendship lifecycle passed: mutual consent, guest/account promotion, scoped presence, reconnect, accepted text invitations, busy and overlap rejection, removal, blocks and guest-end cleanup.');
} finally {
  for (const socket of sockets) socket.abort();
}
