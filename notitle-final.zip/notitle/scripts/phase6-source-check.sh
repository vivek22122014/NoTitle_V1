#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/lib.sh"
command -v node >/dev/null || { echo 'Node 24 is required for the dependency-free source checks.' >&2; exit 1; }
cd "$ROOT"
node scripts/audit.mjs
node --test web/tests/*.test.mjs deploy/tests/*.test.mjs
node --check scripts/realtime-smoke-client.mjs
node --check scripts/smoke-realtime.mjs
node --check scripts/smoke-safety.mjs
node --check scripts/smoke-friends.mjs
node --check scripts/prepare-private-keys.mjs
echo 'Phase 6 source checks passed. This does not establish Go, Svelte, browser, Docker, load or release acceptance.'
