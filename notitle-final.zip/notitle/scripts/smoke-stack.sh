#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/lib.sh"
require_docker
require_locks
export COMPOSE_PROJECT_NAME="notitle-smoke-$$"
# Docker selects a free loopback port; tests use the private bridge.
export STATIC_WEB_PORT=0
export ADMIN_PORT=0
compose() { "$ROOT/scripts/compose.sh" static "$@"; }
cleanup() { compose down --volumes --remove-orphans >/dev/null; }
trap cleanup EXIT
"$ROOT/scripts/start.sh" static
smoke() {
  docker run --rm --network "${COMPOSE_PROJECT_NAME}_default" \
    --mount "type=bind,src=$ROOT/scripts/smoke-stack.mjs,dst=/work/scripts/smoke-stack.mjs,readonly" \
    --mount "type=bind,src=$ROOT/web/src/lib/config/routes.mjs,dst=/work/web/src/lib/config/routes.mjs,readonly" \
    "$NODE_IMAGE" node /work/scripts/smoke-stack.mjs "$@"
}
smoke
# The identity script creates and deletes only synthetic data in this disposable stack.
docker run --rm --network "${COMPOSE_PROJECT_NAME}_default" \
  --mount "type=bind,src=$ROOT/scripts/smoke-identity.mjs,dst=/work/smoke-identity.mjs,readonly" \
  "$NODE_IMAGE" node /work/smoke-identity.mjs
# Real WebSocket checks use a raw RFC6455 client with exact browser Origin.
# Mount the directory so its dependency-free client helper is available.
docker run --rm --network "${COMPOSE_PROJECT_NAME}_default" \
  --mount "type=bind,src=$ROOT/scripts,dst=/work/scripts,readonly" \
  "$NODE_IMAGE" node /work/scripts/smoke-realtime.mjs
# Text and safety checks inspect real durable outcomes on this isolated stack.
docker run --rm --network "${COMPOSE_PROJECT_NAME}_default" \
  --mount "type=bind,src=$ROOT/scripts,dst=/work/scripts,readonly" \
  "$NODE_IMAGE" node /work/scripts/smoke-safety.mjs
compose exec -T postgres sh -eu -c '
  export PGPASSWORD=$(cat /run/secrets/postgres_admin_password)
  exec psql -h 127.0.0.1 -U notitle_bootstrap -d notitle --no-psqlrc --set ON_ERROR_STOP=1
' < "$ROOT/scripts/safety-retention-check.sql"
# Scan in memory and print only the result. Do not write or echo application
# logs, which would amplify a retention regression if one were introduced.
compose logs --no-color api postgres web 2>&1 | docker run --rm -i "$NODE_IMAGE" node --input-type=module -e '
  const marker = "PHASE5_ORDINARY_ONLY_9f1f572bd2a94469";
  let tail = "", found = false;
  for await (const chunk of process.stdin) {
    const value = tail + chunk.toString("utf8");
    found ||= value.includes(marker);
    tail = value.slice(-marker.length);
  }
  if (found) {
    console.error("Ordinary chat was found in application/database/proxy logs.");
    process.exitCode = 1;
  }
'
echo 'Safety storage and ordinary-chat log retention checks passed.'
# Run friends after the exact safety evidence-count gate above.
docker run --rm --network "${COMPOSE_PROJECT_NAME}_default" \
  --mount "type=bind,src=$ROOT/scripts,dst=/work/scripts,readonly" \
  "$NODE_IMAGE" node /work/scripts/smoke-friends.mjs
# Audio stays disabled in the default stack until a controlled relay passes its
# own deployment/media gates. This proves the off-switch and text fallback;
# it never substitutes mocked signaling for real media acceptance.
docker run --rm --network "${COMPOSE_PROJECT_NAME}_default" \
  --mount "type=bind,src=$ROOT/scripts,dst=/work/scripts,readonly" \
  "$NODE_IMAGE" node /work/scripts/smoke-audio.mjs
# The audio fixture submits a unique SDP-only canary even while audio is off.
# Inspect in memory and print no log content if a regression is detected.
compose logs --no-color api postgres web 2>&1 | docker run --rm -i "$NODE_IMAGE" node --input-type=module -e '
  const marker = "PHASE7_SDP_ONLY_a8d271f40bc34821";
  let tail = "", found = false;
  for await (const chunk of process.stdin) {
    const value = tail + chunk.toString("utf8");
    found ||= value.includes(marker);
    tail = value.slice(-marker.length);
  }
  if (found) {
    console.error("SDP was found in application/database/proxy logs.");
    process.exitCode = 1;
  }
'
echo 'Audio-off and SDP log-retention checks passed; live media remains a separate gate.'
# Default payment integration/checkout remain off. This isolated check creates
# only one synthetic account and cannot contact a financial provider.
docker run --rm --network "${COMPOSE_PROJECT_NAME}_default" \
  -e SMOKE_DISPOSABLE_TARGET=1 \
  --mount "type=bind,src=$ROOT/scripts,dst=/work/scripts,readonly" \
  "$NODE_IMAGE" node /work/scripts/smoke-payments.mjs
compose logs --no-color api postgres web 2>&1 | docker run --rm -i "$NODE_IMAGE" node --input-type=module -e '
  const marker = "PHASE8_WEBHOOK_ONLY_f7b803bae1314e40";
  let tail = "", found = false;
  for await (const chunk of process.stdin) {
    const value = tail + chunk.toString("utf8");
    found ||= value.includes(marker);
    tail = value.slice(-marker.length);
  }
  if (found) {
    console.error("Raw payment webhook content was found in application/database/proxy logs.");
    process.exitCode = 1;
  }
'
echo 'Payment-off and raw-webhook log-retention checks passed; real financial acceptance remains a separate gate.'
compose run --rm -e DISPOSABLE_TEST_DATABASE=1 migrate down
smoke --not-ready
compose run --rm migrate up
smoke --wait-ready
smoke

# A real dependency outage must not kill liveness or produce false readiness.
compose stop postgres
smoke --not-ready
compose up -d --wait postgres
smoke --wait-ready
smoke

# Docker sends SIGTERM, then SIGKILL only after the bounded grace period.
# A clean zero exit and no OOM distinguish graceful shutdown from forced death.
api_id=$(compose ps --quiet api)
test -n "$api_id"
compose stop --timeout 20 api
exit_state=$(docker inspect --format '{{.State.ExitCode}} {{.State.OOMKilled}}' "$api_id")
test "$exit_state" = '0 false' || {
  echo "API did not shut down cleanly after SIGTERM: $exit_state" >&2
  exit 1
}
echo 'API exited cleanly after SIGTERM with exit code 0 and no OOM.'
