#!/usr/bin/env node
// Emits a reviewable plan only. Never connects, deploys, signals, or migrates.
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { main as checkLaunch, saveExclusive } from './launch-evidence.mjs';
import { sha256, strictJSON } from './launch-evidence-lib.mjs';
export async function createPlan({source, evidence, manifest, purpose = 'launch'}) {
  if (!['validation','launch'].includes(purpose)) throw new Error('Invalid purpose');
  const evidenceBefore = await readFile(evidence);
  const verdict = await checkLaunch(['check','--source',source,'--evidence',evidence,'--purpose',purpose]);
  if (verdict.exitCode !== 0) return {exitCode:1, output:{state:'blocked',message:'Deployment evidence is incomplete or expired; no execution plan produced.', blockers:verdict.output.blockers ?? verdict.output}};
  const bytes = await readFile(manifest);
  const deployment = strictJSON(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
  const evidenceAfter = await readFile(evidence);
  if (!evidenceBefore.equals(evidenceAfter)) throw new Error('Evidence changed during validation');
  const release = strictJSON(new TextDecoder('utf-8',{fatal:true}).decode(evidenceAfter));
  if (JSON.stringify(verdict.output.release) !== JSON.stringify(release.release)) throw new Error('Release changed during validation');
  if (sha256(bytes) !== release.release.deployment_manifest_sha256 || deployment.origin !== release.release.origin) throw new Error('Deployment manifest changed or differs from release evidence');
  return {exitCode:0, output:{
    schema_version:1, state:'review_only', purpose, source_sha256:release.release.source_sha256,
    evidence_sha256:sha256(evidenceAfter), deployment_manifest_sha256:sha256(bytes),
    origin:deployment.origin, images:deployment.images, database_schema:9,
    requires_deliberate_operator_execution:true, performs_deployment:false,
    operations:[
      {step:1,action:'Verify recoverable DB/WAL point within 15 minutes, both independent journal inventories, coverage, previous release compatibility and actual zero-second-owner inventory.'},
      {step:2,action:'Private owner-MFA drain with reason and at most 120 seconds. Preserve grievances, reports, provider callbacks and financial work.'},
      {step:3,action:'Wait for deadline, terminated interactions and confirmed TURN cleanup. Stop API; verify zero owners. Do not restart Caddy before drain completes.'},
      {step:4,action:'Forward-only compatible migration with dedicated migration image/role. Preserve database and deletion/hold journals.'},
      {step:5,action:'Start exactly one candidate API with maintenance enabled, then its matching web artifact in maintenance or protected cohort mode.'},
      {step:6,action:'Verify replay, private readiness and reconciliation. Install the checked short-lived permit with correct owner/mode; opening still requires named owner MFA.'},
      {step:7,action:purpose === 'validation' ? 'Named owner MFA opens only the source-restricted authenticated validation cohort for at most two hours. Perform only the specifically authorized production smoke/live-money checks; expiry automatically drains admission. Record actual outcomes and return closed before obtaining the full launch permit.' : 'Named owner MFA deliberately opens the supervised cohort; monitor the full operating cycle. Public promotion requires a new stage-bound manifest/permit after the cohort review.'},
      {step:8,action:'On failure drain/stop candidate; replace API+web only with recorded schema-compatible previous digests. Never DOWN or restore an old database to undo code.'}
    ],
    limitations:['Evidence consistency does not attest test authenticity or staff availability. This plan neither authorizes nor performs live transactions, messages, cloud changes or deployment.','Use one reviewed project and identical ordered overlays; no rolling overlap, scaling, volume deletion or production build.']
  }};
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const args=process.argv.slice(2),flags={};
    while(args.length){const key=args.shift();if(!['--source','--evidence','--manifest','--out','--purpose'].includes(key)||Object.hasOwn(flags,key)||!args.length)throw new Error('Invalid arguments');flags[key]=args.shift();}
    if(!flags['--source']||!flags['--evidence']||!flags['--manifest']||!flags['--out'])throw new Error('All source/evidence/manifest/out arguments are required');
    const result=await createPlan({source:flags['--source'],evidence:flags['--evidence'],manifest:flags['--manifest'],purpose:flags['--purpose'] ?? 'launch'});
    if(result.exitCode===0){await saveExclusive(flags['--out'],result.output,flags['--source']);console.log('Review-only deployment plan saved. No deployment performed.');}
    else console.log(JSON.stringify(result.output,null,2));
    process.exitCode=result.exitCode;
  } catch {console.error('Deployment plan rejected: invalid, changed or inaccessible evidence.');process.exitCode=2;}
}
