#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/lib.sh"
command -v node >/dev/null || { echo 'Node 24 is required for source checks.' >&2; exit 1; }
command -v python3 >/dev/null || { echo 'Python 3 is required for archive fixture checks.' >&2; exit 1; }
cd "$ROOT"
node scripts/audit.mjs
node --test web/tests/*.test.mjs deploy/tests/*.test.mjs
python3 scripts/operations-archive-test.py
python3 scripts/operations-observe-test.py
for script in scripts/*.mjs; do node --check "$script"; done
echo 'Phase 9 source checks passed. Go, PostgreSQL, browser, operator delivery, retention, restore, provider, relay, capacity and release acceptance remain separate required gates.'
