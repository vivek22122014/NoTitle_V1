#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/lib.sh"
require_docker
# Only explicit read-only render options are accepted. Never shell-source .env.
args=()
while (($#)); do
  case "$1" in
    --env-file|--project-name) test "$#" -ge 2 || exit 2; args+=("$1" "$2"); shift 2 ;;
    --overlay) test "$#" -ge 2 || exit 2; case "$2" in audio|payments|operations) args+=(-f "$ROOT/deploy/$2/compose.app.yml");; *) echo 'Unknown production overlay.' >&2; exit 2;; esac; shift 2 ;;
    *) echo 'Usage: production-config.sh [--env-file PATH] [--project-name NAME] [--overlay audio|payments|operations]' >&2; exit 2 ;;
  esac
done
# Interpolated config stays in a protected temporary directory; never print it.
umask 077
stage=$(mktemp -d)
trap 'rm -rf -- "$stage"' EXIT
if ! docker compose -f "$ROOT/deploy/production/compose.yml" "${args[@]}" config --format json > "$stage/compose.json" 2> "$stage/render-error"; then
  echo 'Compose render failed. Check required variables and overlay ordering; rendered details were withheld.' >&2
  exit 1
fi
# Shape-only sandbox: host secret checks are separately run by the operator on
# both hosts with deploy-config.mjs --check-files. No daemon/socket is mounted.
docker run --rm --network none --user "$(id -u):$(id -g)" \
  --mount "type=bind,src=$ROOT/scripts,dst=/scripts,readonly" \
  --mount "type=bind,src=$stage,dst=/input,readonly" \
  "$NODE_IMAGE" node /scripts/deploy-config.mjs validate --config /input/compose.json
