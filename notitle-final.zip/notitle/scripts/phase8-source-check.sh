#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/lib.sh"
command -v node >/dev/null || { echo 'Node 24 is required for the dependency-free source checks.' >&2; exit 1; }
cd "$ROOT"
node scripts/audit.mjs
node --test web/tests/*.test.mjs deploy/tests/*.test.mjs
for script in scripts/realtime-smoke-client.mjs scripts/smoke-realtime.mjs scripts/smoke-safety.mjs scripts/smoke-friends.mjs scripts/smoke-audio.mjs scripts/smoke-payments.mjs scripts/prepare-private-keys.mjs; do
  node --check "$script"
done
echo 'Phase 8 source checks passed. This does not establish Go, PostgreSQL, Svelte, browser, Cashfree, refund/settlement, relay, capacity or release acceptance.'
