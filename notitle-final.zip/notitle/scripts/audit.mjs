#!/usr/bin/env node
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { resolve, relative, extname } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const release = process.argv.includes('--release');
const failures = [];
const excluded = new Set(['.git', 'node_modules', '.svelte-kit', 'build', 'bin', 'secrets', 'test-results', 'playwright-report', 'coverage', '.local']);
const patterns = [
  [/-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----/, 'private key'],
  [/\bAKIA[0-9A-Z]{16}\b/, 'AWS access key identifier'],
  [/\b(?:rzp_live_|sk_live_)[A-Za-z0-9]{12,}\b/, 'live payment credential'],
];
function walk(dir) {
  return readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    if (excluded.has(entry.name)) return [];
    const path = resolve(dir, entry.name);
    if (entry.isSymbolicLink()) { failures.push(relative(root, path) + ': source symlinks are not allowed in the deliverable'); return []; }
    if (entry.isDirectory()) return walk(path);
    if (entry.name.startsWith('.env') && !entry.name.endsWith('.example')) return [];
    return [path];
  });
}
const files = walk(root);
for (const path of files) {
  if (!['.go', '.json', '.js', '.mjs', '.ts', '.svelte', '.yaml', '.yml', '.sh', '.md', '.sql', ''].includes(extname(path))) continue;
  const content = readFileSync(path, 'utf8');
  for (const [pattern, description] of patterns) {
    if (pattern.test(content)) failures.push(relative(root, path) + ': possible ' + description + ' (value suppressed)');
  }
}
const pkg = JSON.parse(readFileSync(resolve(root, 'web/package.json'), 'utf8'));
for (const group of ['dependencies', 'devDependencies']) {
  for (const [name, version] of Object.entries(pkg[group] || {})) {
    if (!/^\d+\.\d+\.\d+$/.test(version)) failures.push('web/package.json: direct dependency must have an exact stable version: ' + name);
  }
}
const lockPath = resolve(root, 'web/package-lock.json');
if (existsSync(lockPath)) {
  const lock = JSON.parse(readFileSync(lockPath, 'utf8'));
  if (lock.lockfileVersion !== 3 || !lock.packages?.['']) failures.push('web/package-lock.json: expected npm lockfile v3');
  for (const group of ['dependencies', 'devDependencies']) {
    if (JSON.stringify(Object.entries(pkg[group] || {}).sort()) !== JSON.stringify(Object.entries(lock.packages?.['']?.[group] || {}).sort())) {
      failures.push('web/package-lock.json: root ' + group + ' differs from package.json');
    }
  }
  for (const [name, entry] of Object.entries(lock.packages || {})) {
    if (!name) continue;
    if (entry.link || !entry.resolved?.startsWith('https://') || !/^sha(?:256|384|512)-[A-Za-z0-9+/]+=*$/.test(entry.integrity || '')) {
      failures.push('web/package-lock.json: unresolved, unverified or non-HTTPS dependency: ' + name);
    }
  }
} else if (release) failures.push('web/package-lock.json is missing: generate and review it with registry access');
const sumPath = resolve(root, 'server/go.sum');
if (existsSync(sumPath)) {
  const lines = readFileSync(sumPath, 'utf8').trim().split('\n');
  const seen = new Map();
  for (const line of lines) {
    const parts = line.trim().split(/\s+/);
    if (parts.length !== 3 || !parts[1].startsWith('v') || !/^h1:[A-Za-z0-9+/]{43}=$/.test(parts[2] || '')) {
      failures.push('server/go.sum: invalid checksum line'); break;
    }
    const key = parts[0] + ' ' + parts[1];
    if (seen.has(key) && seen.get(key) !== parts[2]) failures.push('server/go.sum: conflicting checksum for a module version');
    seen.set(key, parts[2]);
  }
} else if (release) failures.push('server/go.sum is missing: generate and verify it with module registry access');
if (failures.length) {
  for (const message of failures) console.error('FAIL: ' + message);
  process.exitCode = 1;
} else {
  console.log('Source credential-pattern and direct-version checks passed (' + files.length + ' files).');
  if (release) console.log('Dependency lock structure passed; go mod verify, npm ci and vulnerability scans are still required.');
  else console.log('Source-only check: this does not establish build, dependency, runtime or release readiness.');
}

