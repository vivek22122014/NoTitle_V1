#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/lib.sh"
command -v node >/dev/null || { echo 'Node 24 is required for source checks.' >&2; exit 1; }
command -v python3 >/dev/null || { echo 'Python 3.11+ is required for operations fixtures.' >&2; exit 1; }
node --input-type=module -e 'if (Number(process.versions.node.split(".")[0]) !== 24) { console.error("Use the pinned Node 24 runtime."); process.exit(1); }'
cd "$ROOT"
node scripts/audit.mjs
node --test web/tests/*.test.mjs deploy/tests/*.test.mjs scripts/tests/*.test.mjs
python3 scripts/operations-archive-test.py
python3 scripts/operations-observe-test.py
for script in scripts/*.mjs; do node --check "$script"; done
echo 'Phase 10 source checks passed. These are not Go, database, browser/device, real-media soak, live-payment, restore, deployment or launch acceptance.'
