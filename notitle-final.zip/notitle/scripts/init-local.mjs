import { randomBytes } from 'node:crypto';
import { chmodSync, existsSync, lstatSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';

process.umask(0o077);
const root = resolve(import.meta.dirname, '..');
function privateDirectory(path) {
  if (existsSync(path) && (!lstatSync(path).isDirectory() || lstatSync(path).isSymbolicLink())) {
    throw new Error('Local secret directories must be ordinary directories');
  }
  mkdirSync(path, { recursive: true, mode: 0o700 });
  chmodSync(path, 0o700);
}
privateDirectory(resolve(root, '.local'));
const directory = resolve(root, '.local/secrets');
privateDirectory(directory);
function keepOrCreate(name, create) {
  const path = resolve(directory, name);
  if (!existsSync(path)) {
    // Exclusive create refuses to overwrite a concurrent bootstrap's file.
    try { writeFileSync(path, create() + '\n', { flag: 'wx', mode: 0o400 }); }
    catch (error) { if (error.code !== 'EEXIST') throw error; }
  }
  if (!lstatSync(path).isFile() || lstatSync(path).isSymbolicLink()) {
    throw new Error('Local secrets must be ordinary files');
  }
  const value = readFileSync(path, 'utf8').trim();
  // Compose bind-mounted secrets preserve host file ownership. Read-only files
  // allow postgres and UID65532 to consume them; the host parent stays0700.
  chmodSync(path, 0o444);
  return value;
}
for (const name of ['postgres_admin_password', 'postgres_migration_password', 'postgres_runtime_password']) {
  const value = keepOrCreate(name, () => randomBytes(32).toString('hex'));
  if (!/^[a-f0-9]{64}$/.test(value)) throw new Error('Existing local secret has an unexpected format; nothing was replaced');
}
for (const [name, role, passwordFile] of [
  ['migration_database_url', 'notitle_migrate', 'postgres_migration_password'],
  ['runtime_database_url', 'notitle_app', 'postgres_runtime_password']
]) {
  const password = readFileSync(resolve(directory, passwordFile), 'utf8').trim();
  const expected = `postgres://${role}:${password}@postgres:5432/notitle?sslmode=disable`;
  if (keepOrCreate(name, () => expected) !== expected) {
    throw new Error('Existing local credential files disagree; perform deliberate rotation, not bootstrap replacement');
  }
}
const evidenceKeyring = JSON.parse(keepOrCreate('evidence_keyring', () => JSON.stringify({ active_key_id: 'local-v1', keys: { 'local-v1': randomBytes(32).toString('base64') } })));
if (!evidenceKeyring.keys?.[evidenceKeyring.active_key_id] || Object.keys(evidenceKeyring.keys).length > 16 || Object.values(evidenceKeyring.keys).some((key) => typeof key !== 'string' || Buffer.from(key, 'base64').length !== 32)) {
  throw new Error('Existing local evidence keyring is invalid; nothing was replaced');
}
const mfaKey = keepOrCreate('admin_mfa_key', () => randomBytes(32).toString('base64'));
if (!/^[A-Za-z0-9+/]{43}=$/.test(mfaKey) || Buffer.from(mfaKey, 'base64').length !== 32) throw new Error('Existing local MFA key is invalid; nothing was replaced');
const envPath = resolve(root, 'deploy/dev/.env');
if (!existsSync(envPath)) {
  try {
    writeFileSync(envPath, readFileSync(resolve(root, 'deploy/dev/.env.example')), { flag: 'wx', mode: 0o600 });
  } catch (error) { if (error.code !== 'EEXIST') throw error; }
}
console.log('Local secrets are ready. Existing values were preserved; no values were printed.');
