// HTTP/WebSocket audio-control gate for an isolated stack only. This program
// does not access a microphone, establish WebRTC media or prove relay capacity.
// Enabled mode requires explicit disposable-target acknowledgement and an
// already configured real supervisor/relay; it is never silently substituted.
// No credentials, SDP, ICE candidates, opaque handles or user content are logged.
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { SmokeSocket } from './realtime-smoke-client.mjs';

const base = process.env.SMOKE_BASE_URL ?? 'http://web:8080';
const origin = process.env.SMOKE_PUBLIC_ORIGIN ?? 'http://localhost:8080';
const enabled = process.env.SMOKE_AUDIO_ENABLED === '1';
if (enabled && process.env.SMOKE_DISPOSABLE_TARGET !== '1') {
  throw new Error('Enabled audio smoke requires an explicitly disposable target');
}
const sockets = new Set();
class Browser {
  jar = new Map(); csrf = '';
  cookie() { return [...this.jar].map(([key, value]) => `${key}=${value}`).join('; '); }
  async api(path, method = 'GET', body, status = 200) {
    const headers = {Cookie: this.cookie()};
    if (method !== 'GET') Object.assign(headers, {Origin: origin, 'Content-Type': 'application/json', 'X-CSRF-Token': this.csrf});
    const response = await fetch(base + '/api/v1' + path, {
      method, headers, body: body === undefined ? undefined : JSON.stringify(body),
      redirect: 'manual', signal: AbortSignal.timeout(15000)
    });
    assert.equal(response.status, status, 'Unexpected audio smoke API status');
    assert.match(response.headers.get('cache-control') ?? '', /no-store/);
    for (const cookie of response.headers.getSetCookie()) {
      const pair = cookie.split(';', 1)[0], split = pair.indexOf('=');
      const name = pair.slice(0, split), value = pair.slice(split + 1);
      if (!value || /Max-Age=0/i.test(cookie)) this.jar.delete(name); else this.jar.set(name, value);
    }
    const value = await response.json();
    if (value.csrf_token) this.csrf = value.csrf_token;
    return value;
  }
  async guest(gender) {
    const bootstrap = await this.api('/auth/bootstrap');
    await this.api('/guest/session', 'POST', {
      profile: {gender, topic: 'general_talk', bio: '', professional: {profession: '', industry: '', experience: '', interests: []}},
      consent: {adult_confirmed: true, policies: bootstrap.policies}
    }, 201);
    return this;
  }
  async connect(resume) {
    const ticket = await this.api('/realtime/ticket', 'POST', {takeover: false}, 201);
    const socket = await SmokeSocket.open(base, origin, this.cookie()); sockets.add(socket);
    socket.send({v: 1, id: randomUUID(), type: 'session.authenticate', generation: 0, payload: {
      ticket: ticket.ticket, takeover: false, ...(resume ? {resume} : {})
    }});
    return {socket, state: (await socket.event('session.ready')).payload};
  }
}
function command(connection, type, interaction, payload = {}, extra = {}) {
  const id = randomUUID();
  connection.socket.send({v: 1, id, type, generation: connection.state.generation,
    ...(interaction ? {interaction_id: interaction.id, epoch: interaction.epoch} : {}), payload, ...extra});
  return id;
}
async function rejected(connection, type, interaction, payload, codes, extra = {}) {
  const id = command(connection, type, interaction, payload, extra);
  const response = await connection.socket.event('error', (event) => event.reply_to === id);
  assert.ok(codes.includes(response.payload.code), 'Call command failed with an unexpected stable code');
}
async function sync(connection) {
  command(connection, 'state.sync');
  return (await connection.socket.event('session.state')).payload;
}
async function pair(a, b) {
  command(a, 'queue.join'); await a.socket.event('queue.joined');
  command(b, 'queue.join');
  const [left, right] = await Promise.all([a.socket.event('match.found'), b.socket.event('match.found')]);
  assert.ok(left.payload.interaction.id === right.payload.interaction.id, 'Interaction ownership disagrees');
  return left.payload.interaction;
}
async function noEvent(connection, type) {
  await assert.rejects(connection.socket.event(type, () => true, 250), (error) => error.message.startsWith('Timed out waiting for'));
}
function verifyCredentials(value, callRef) {
  assert.ok(value.call_ref === callRef, 'Credentials escaped their call scope');
  const c = value.credentials;
  assert.ok(typeof c.username === 'string' && c.username.length > 16);
  assert.ok(typeof c.credential === 'string' && c.credential.length > 16);
  assert.ok(Array.isArray(c.urls) && c.urls.length > 0 && c.urls.every((url) => /^turns?:[^/?#@]+(?::\d+)?\?transport=(?:udp|tcp)$/.test(url)));
  assert.ok(Array.isArray(c.relay_addresses) && c.relay_addresses.length > 0);
  assert.equal(c.relay_min_port, 49152); assert.equal(c.relay_max_port, 50175);
  const lifetime = Date.parse(c.expires_at) - Date.now(), refresh = Date.parse(c.refresh_at) - Date.now();
  assert.ok(lifetime > 8 * 60_000 && lifetime <= 10 * 60_000 + 2000, 'Credential lifetime differs from ten minutes');
  assert.ok(refresh > 3 * 60_000 && refresh <= 5 * 60_000 + 2000, 'Credential refresh differs from five minutes');
  return c;
}
function offer(extra = '') {
  return [
    'v=0', 'o=- 1 1 IN IP4 0.0.0.0', 's=-', 't=0 0', 'a=group:BUNDLE 0',
    'm=audio 9 UDP/TLS/RTP/SAVPF 111', 'c=IN IP4 0.0.0.0',
    'a=ice-ufrag:abcd', 'a=ice-pwd:abcdefghijklmnopqrstuvwxyz',
    `a=fingerprint:sha-256 ${Array(32).fill('AA').join(':')}`, 'a=setup:actpass',
    'a=mid:0', 'a=sendrecv', 'a=rtcp-mux', 'a=rtpmap:111 opus/48000/2',
    ...(extra ? [extra] : []), ''
  ].join('\r\n');
}

try {
  const a = await new Browser().guest('male'), b = await new Browser().guest('female');
  let ac = await a.connect(); const bc = await b.connect();
  assert.equal(ac.state.audio_enabled, enabled, 'Audio state must match the explicitly selected smoke mode');
  assert.equal(bc.state.audio_enabled, enabled);
  const interaction = await pair(ac, bc);
  const fakeRef = 'synthetic-unaccepted-call-0001';
  await rejected(ac, 'webrtc.offer', interaction, {
    call_ref: fakeRef, negotiation: 1,
    sdp: offer('a=x-private-fixture:PHASE7_SDP_ONLY_a8d271f40bc34821')
  }, ['NOT_AVAILABLE', 'STALE_EPOCH']);
  if (!enabled) {
    await rejected(ac, 'call.request', interaction, {}, ['NOT_AVAILABLE']);
    await rejected(ac, 'call.accept', interaction, {call_ref: fakeRef}, ['NOT_AVAILABLE', 'STALE_EPOCH']);
    assert.ok(!(await sync(ac)).call, 'Disabled audio retained a call');
    await noEvent(ac, 'call.credentials'); await noEvent(bc, 'call.credentials');
    const sendID = randomUUID();
    command(ac, 'chat.send', interaction, {client_send_id: sendID, text: 'Audio disabled text fallback fixture'});
    await bc.socket.event('chat.message');
    command(ac, 'match.end', interaction);
    await Promise.all([ac.socket.event('match.ended'), bc.socket.event('match.ended')]);
    console.log('Audio-disabled HTTP/WebSocket gate passed; text remains available. Enabled media was not tested.');
  } else {
    await rejected(ac, 'call.accept', interaction, {call_ref: fakeRef}, ['NOT_AVAILABLE', 'STALE_EPOCH']);
    command(ac, 'call.request', interaction);
    const request = await ac.socket.event('call.state', (event) => event.payload.state === 'REQUESTED');
    const incoming = await bc.socket.event('call.state', (event) => event.payload.state === 'RINGING');
    const callRef = request.payload.call_ref;
    assert.ok(incoming.payload.call_ref === callRef, 'Consent request scopes disagree');
    await noEvent(ac, 'call.credentials'); await noEvent(bc, 'call.credentials');
    await rejected(ac, 'webrtc.offer', interaction, {call_ref: callRef, negotiation: 1, sdp: offer()}, ['NOT_AVAILABLE']);
    command(bc, 'call.accept', interaction, {call_ref: callRef});
    const [left, right] = await Promise.all([ac.socket.event('call.credentials'), bc.socket.event('call.credentials')]);
    const negotiation = left.payload.negotiation;
    assert.ok(Number.isSafeInteger(negotiation) && negotiation > 0 && right.payload.negotiation === negotiation, 'Negotiation revisions disagree');
    const ca = verifyCredentials(left.payload, callRef), cb = verifyCredentials(right.payload, callRef);
    assert.ok(ca.username !== cb.username, 'Peers received a shared relay username');
    assert.ok(ca.credential !== cb.credential, 'Peers received a shared relay credential');
    // Test complete SDP fields that can leak an endpoint address before any
    // valid offer is forwarded. No SDP is printed on an assertion failure.
    for (const sdp of [
      offer().replace('c=IN IP4 0.0.0.0', 'c=IN IP4 192.168.1.2'),
      offer('a=candidate:1 1 UDP 1 192.168.1.2 50000 typ host'),
      offer('a=candidate:1 1 UDP 1 ::ffff:127.0.0.1 49152 typ relay'),
      offer('m=video 9 UDP/TLS/RTP/SAVPF 96'),
      offer('m=application 9 UDP/DTLS/SCTP webrtc-datachannel'),
      offer('a=x-private-address:192.168.1.2')
    ]) {
      await rejected(ac, 'webrtc.offer', interaction, {call_ref: callRef, negotiation, sdp}, ['INVALID_EVENT', 'INVALID_SIGNAL']);
      await noEvent(bc, 'webrtc.offer');
    }
    await rejected(bc, 'webrtc.offer', interaction, {call_ref: callRef, negotiation, sdp: offer()}, ['NOT_AVAILABLE', 'INVALID_EVENT']);
    await rejected(ac, 'webrtc.offer', interaction, {call_ref: callRef, negotiation, sdp: offer()}, ['STALE_EPOCH'], {epoch: interaction.epoch + 1});
    await rejected(ac, 'webrtc.offer', interaction, {call_ref: callRef, negotiation: negotiation + 1, sdp: offer()}, ['STALE_EPOCH', 'NOT_AVAILABLE']);
    // Synthetic SDP demonstrates the authorized signaling path only. These
    // fixtures are never claimed to represent a browser or allocated media.
    command(ac, 'webrtc.offer', interaction, {call_ref: callRef, negotiation, sdp: offer()});
    const forwardedOffer = await bc.socket.event('webrtc.offer');
    assert.ok(forwardedOffer.payload.call_ref === callRef && forwardedOffer.payload.negotiation === negotiation);
    command(bc, 'webrtc.answer', interaction, {call_ref: callRef, negotiation, sdp: offer().replace('a=setup:actpass', 'a=setup:active')});
    const forwardedAnswer = await ac.socket.event('webrtc.answer');
    assert.ok(forwardedAnswer.payload.call_ref === callRef && forwardedAnswer.payload.negotiation === negotiation);
    command(ac, 'webrtc.ice', interaction, {
      call_ref: callRef, negotiation,
      candidate: `candidate:1 1 UDP 1 ${ca.relay_addresses[0]} ${ca.relay_min_port} typ relay raddr 0.0.0.0 rport 0`,
      sdp_mid: '0', sdp_mline_index: 0
    });
    const forwardedICE = await bc.socket.event('webrtc.ice');
    assert.ok(forwardedICE.payload.call_ref === callRef && forwardedICE.payload.negotiation === negotiation);
    command(ac, 'call.connected', interaction, {call_ref: callRef, negotiation});
    command(bc, 'call.connected', interaction, {call_ref: callRef, negotiation});
    await Promise.all([
      ac.socket.event('call.state', (event) => event.payload.state === 'CONNECTED'),
      bc.socket.event('call.state', (event) => event.payload.state === 'CONNECTED')
    ]);
    const old = ac.state;
    ac.socket.abort();
    await bc.socket.event('call.ended', (event) => event.payload.call_ref === callRef);
    await bc.socket.event('peer.disconnected');
    ac = await a.connect({token: old.resume_token, server_instance: old.server_instance, generation: old.generation, interaction_id: interaction.id, epoch: interaction.epoch});
    assert.ok(ac.state.interaction?.id === interaction.id, 'Audio loss incorrectly discarded text reconnect state');
    assert.ok(!ac.state.call, 'Reconnect restored a call without new consent');
    await rejected(ac, 'webrtc.offer', interaction, {call_ref: callRef, negotiation, sdp: offer()}, ['NOT_AVAILABLE', 'STALE_EPOCH']);
    command(ac, 'match.end', interaction);
    await Promise.all([ac.socket.event('match.ended'), bc.socket.event('match.ended')]);
    console.log('Enabled audio consent, credential scope, malicious-SDP and disconnect signaling checks passed. No media, TURN replay, shutdown timing or capacity result is implied.');
  }
} finally {
  for (const socket of sockets) socket.abort();
}
