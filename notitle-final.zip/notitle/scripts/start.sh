#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/lib.sh"
mode=${1:-dev}
case "$mode" in dev|static) ;; *) echo 'Mode must be dev or static' >&2; exit 2;; esac
require_docker
require_locks
# Never remove a database volume. A mode switch safely replaces api/web only.
"$ROOT/scripts/compose.sh" "$mode" up -d --wait postgres
"$ROOT/scripts/compose.sh" "$mode" run --build --rm migrate up
# The API starts with --no-deps below, so its one-shot private-key dependency
# must finish explicitly, including on a fresh safety_keys volume.
"$ROOT/scripts/compose.sh" "$mode" run --rm --no-deps key-init
"$ROOT/scripts/compose.sh" "$mode" up -d --build --no-deps --wait --wait-timeout 240 api web
if [ "$mode" = dev ]; then
  echo 'Development is ready at http://localhost:5173 (or DEV_WEB_PORT in deploy/dev/.env).'
  echo 'Frontend edits hot reload; use make api-restart to compile backend changes.'
else
  echo 'Production-like static app is ready at http://localhost:8080 (or STATIC_WEB_PORT in deploy/dev/.env).'
fi
