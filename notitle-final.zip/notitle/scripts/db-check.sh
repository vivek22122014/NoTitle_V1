#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/lib.sh"
require_docker
require_locks
# A unique project gives these destructive DOWN tests their OWN empty volume.
export COMPOSE_PROJECT_NAME="notitle-dbcheck-$$"
compose() { "$ROOT/scripts/compose.sh" checks "$@"; }
cleanup() { compose down --volumes --remove-orphans >/dev/null; }
trap cleanup EXIT
compose up -d --wait postgres
compose run --build --rm migrate up
compose exec -T postgres sh -eu -c '
  export PGPASSWORD=$(cat /run/secrets/postgres_runtime_password)
  exec psql -h 127.0.0.1 -U notitle_app -d notitle --no-psqlrc --set ON_ERROR_STOP=1
' < "$ROOT/scripts/db-role-check.sql"
compose exec -T postgres sh -eu -c '
  export PGPASSWORD=$(cat /run/secrets/postgres_admin_password)
  exec psql -h 127.0.0.1 -U notitle_bootstrap -d notitle --no-psqlrc --set ON_ERROR_STOP=1
' <<'SQL'
DO $$
BEGIN
    IF (SELECT tableowner FROM pg_tables WHERE schemaname='notitle' AND tablename='schema_version') <> 'notitle_migrate' THEN
        RAISE EXCEPTION 'Migration role must own the marker';
    END IF;
    IF EXISTS (SELECT 1 FROM pg_authid WHERE rolname IN ('notitle_migrate','notitle_app')
        AND (rolpassword IS NULL OR rolpassword NOT LIKE 'SCRAM-SHA-256$%')) THEN
        RAISE EXCEPTION 'Application passwords must use SCRAM';
    END IF;
END
$$;
SQL
compose run --rm -e DISPOSABLE_TEST_DATABASE=1 migrate down
compose exec -T postgres sh -eu -c '
  export PGPASSWORD=$(cat /run/secrets/postgres_runtime_password)
  exec psql -h 127.0.0.1 -U notitle_app -d notitle --no-psqlrc --set ON_ERROR_STOP=1
' <<'SQL'
DO $$
DECLARE relation_name text;
BEGIN
    IF (SELECT version FROM notitle.schema_version)<>8
        OR to_regclass('notitle.grievances') IS NULL
        OR to_regclass('notitle.operational_alerts') IS NULL
        OR to_regclass('notitle.purchase_orders') IS NULL
        OR to_regprocedure('notitle.privacy_execute_job(uuid,uuid,timestamp with time zone)') IS NOT NULL
        OR to_regprocedure('notitle.privacy_scrub_account(uuid,text,timestamp with time zone)') IS NOT NULL
        OR to_regprocedure('notitle.privacy_expire_security_audit(text,timestamp with time zone)') IS NOT NULL
        OR NOT has_table_privilege(current_user,'notitle.legal_holds','INSERT')
        OR NOT has_table_privilege(current_user,'notitle.legal_holds','UPDATE')
        OR EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema='notitle' AND ((table_name='deletion_jobs' AND column_name='scrubbed_at') OR (table_name='reports' AND column_name='evidence_purged_at')))
    THEN RAISE EXCEPTION 'Privacy down migration did not restore intact operations/billing schema'; END IF;
    FOREACH relation_name IN ARRAY ARRAY['retention_policies','privacy_hold_events','privacy_holds','restricted_registration','privacy_jobs','privacy_purge_audit']
    LOOP
        IF to_regclass('notitle.'||relation_name) IS NOT NULL THEN RAISE EXCEPTION 'Privacy down migration retained %',relation_name; END IF;
    END LOOP;
END
$$;
SQL
compose run --rm -e DISPOSABLE_TEST_DATABASE=1 migrate down
compose exec -T postgres sh -eu -c '
  export PGPASSWORD=$(cat /run/secrets/postgres_runtime_password)
  exec psql -h 127.0.0.1 -U notitle_app -d notitle --no-psqlrc --set ON_ERROR_STOP=1
' <<'SQL'
DO $$
DECLARE relation_name text;
BEGIN
    IF (SELECT version FROM notitle.schema_version)<>7
        OR to_regclass('notitle.purchase_orders') IS NULL
        OR to_regclass('notitle.premium_adjustments') IS NULL
        OR to_regclass('notitle.admin_audit') IS NULL
        OR to_regprocedure('notitle.protect_grievance_receipt()') IS NOT NULL
        OR to_regprocedure('notitle.operations_expire_metadata(text,timestamp with time zone)') IS NOT NULL
    THEN RAISE EXCEPTION 'Operations down migration did not restore intact billing/admin schema'; END IF;
    FOREACH relation_name IN ARRAY ARRAY['legal_deadline_rules','grievances','grievance_messages','grievance_actions','operations_outbox','rule_notices','rule_notice_deliveries','operational_alerts','operational_alert_deliveries','operational_metric_hours']
    LOOP
        IF to_regclass('notitle.'||relation_name) IS NOT NULL THEN RAISE EXCEPTION 'Operations down migration retained %',relation_name; END IF;
    END LOOP;
END
$$;
SQL
compose run --rm -e DISPOSABLE_TEST_DATABASE=1 migrate down
compose exec -T postgres sh -eu -c '
  export PGPASSWORD=$(cat /run/secrets/postgres_runtime_password)
  exec psql -h 127.0.0.1 -U notitle_app -d notitle --no-psqlrc --set ON_ERROR_STOP=1
' <<'SQL'
DO $$
DECLARE relation_name text;
BEGIN
    IF (SELECT version FROM notitle.schema_version) <> 6
        OR to_regclass('notitle.friendships') IS NULL
        OR to_regclass('notitle.admin_audit') IS NULL
        OR to_regclass('notitle.reports') IS NULL
        OR NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='notitle' AND table_name='accounts' AND column_name='friend_revision')
        OR (SELECT count(*) FROM pg_trigger WHERE NOT tgisinternal AND tgenabled='O'
             AND ((tgname='friendships_block_barrier' AND tgrelid='notitle.blocks'::regclass)
               OR (tgname='friendships_deletion_barrier' AND tgrelid='notitle.accounts'::regclass))) <> 2
        OR to_regprocedure('notitle.billing_immutable_snapshot()') IS NOT NULL
    THEN
        RAISE EXCEPTION 'Billing down migration did not restore intact Phase 6 tables and friendship safety barriers';
    END IF;
    FOREACH relation_name IN ARRAY ARRAY['premium_plans','purchase_orders','payment_attempts','premium_accounts','premium_lots','premium_adjustments','refunds','disputes','billing_review_cases','billing_review_actions','billing_dispute_actions','payment_webhook_inbox','billing_jobs','billing_reconciliation_watermarks','settlement_reconciliation']
    LOOP
        IF to_regclass('notitle.'||relation_name) IS NOT NULL THEN
            RAISE EXCEPTION 'Disposable billing down migration retained relation %',relation_name;
        END IF;
    END LOOP;
END
$$;
SQL
compose run --rm -e DISPOSABLE_TEST_DATABASE=1 migrate down
friends_down=$(compose exec -T postgres sh -eu -c '
  export PGPASSWORD=$(cat /run/secrets/postgres_runtime_password)
  exec psql -h 127.0.0.1 -U notitle_app -d notitle --no-psqlrc -At --set ON_ERROR_STOP=1 -c "SELECT version=5 AND to_regclass('\''notitle.friendships'\'') IS NULL AND NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='\''notitle'\'' AND table_name='\''accounts'\'' AND column_name='\''friend_revision'\'') AND to_regclass('\''notitle.admin_users'\'') IS NOT NULL AND NOT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_proc p ON p.oid=t.tgfoid JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname='\''notitle'\'' AND p.proname IN ('\''friendships_block_barrier'\'','\''friendships_deletion_barrier'\'')) FROM notitle.schema_version"
')
test "$friends_down" = t || { echo 'Friendship down migration did not restore private administration marker' >&2; exit 1; }
compose run --rm -e DISPOSABLE_TEST_DATABASE=1 migrate down
admin_down=$(compose exec -T postgres sh -eu -c '
  export PGPASSWORD=$(cat /run/secrets/postgres_runtime_password)
  exec psql -h 127.0.0.1 -U notitle_app -d notitle --no-psqlrc -At --set ON_ERROR_STOP=1 -c "SELECT version=4 AND to_regclass('\''notitle.admin_users'\'') IS NULL AND to_regclass('\''notitle.admin_sessions'\'') IS NULL AND to_regclass('\''notitle.admin_audit'\'') IS NULL AND to_regclass('\''notitle.moderation_actions'\'') IS NOT NULL FROM notitle.schema_version"
')
test "$admin_down" = t || { echo 'Admin down migration did not restore safety marker' >&2; exit 1; }
compose run --rm -e DISPOSABLE_TEST_DATABASE=1 migrate down
safety_down=$(compose exec -T postgres sh -eu -c '
  export PGPASSWORD=$(cat /run/secrets/postgres_runtime_password)
  exec psql -h 127.0.0.1 -U notitle_app -d notitle --no-psqlrc -At --set ON_ERROR_STOP=1 -c "SELECT version=3 AND to_regclass('\''notitle.reports'\'') IS NULL AND to_regclass('\''notitle.report_evidence'\'') IS NULL AND to_regclass('\''notitle.blocks'\'') IS NULL AND to_regclass('\''notitle.legal_holds'\'') IS NULL AND to_regclass('\''notitle.pending_safety_handoffs'\'') IS NULL AND to_regclass('\''notitle.matchmaking_preferences'\'') IS NOT NULL FROM notitle.schema_version"
')
test "$safety_down" = t || { echo 'Safety down migration did not restore matching marker' >&2; exit 1; }
compose run --rm -e DISPOSABLE_TEST_DATABASE=1 migrate down
preferences_down=$(compose exec -T postgres sh -eu -c '
  export PGPASSWORD=$(cat /run/secrets/postgres_runtime_password)
  exec psql -h 127.0.0.1 -U notitle_app -d notitle --no-psqlrc -At --set ON_ERROR_STOP=1 -c "SELECT version=2 AND to_regclass('\''notitle.matchmaking_preferences'\'') IS NULL FROM notitle.schema_version"
')
test "$preferences_down" = t || { echo 'Matching preferences down migration did not restore identity marker' >&2; exit 1; }
compose run --rm -e DISPOSABLE_TEST_DATABASE=1 migrate down
identity_down=$(compose exec -T postgres sh -eu -c '
  export PGPASSWORD=$(cat /run/secrets/postgres_runtime_password)
  exec psql -h 127.0.0.1 -U notitle_app -d notitle --no-psqlrc -At --set ON_ERROR_STOP=1 -c "SELECT version=1 AND to_regclass('\''notitle.accounts'\'') IS NULL FROM notitle.schema_version"
')
test "$identity_down" = t || { echo 'Identity down migration did not restore foundation marker' >&2; exit 1; }
compose run --rm -e DISPOSABLE_TEST_DATABASE=1 migrate down
removed=$(compose exec -T postgres sh -eu -c '
  export PGPASSWORD=$(cat /run/secrets/postgres_admin_password)
  exec psql -h 127.0.0.1 -U notitle_bootstrap -d notitle --no-psqlrc -At --set ON_ERROR_STOP=1 -c "SELECT to_regnamespace('\''notitle'\'') IS NULL"
')
test "$removed" = t || { echo 'Down migration did not remove foundation schema' >&2; exit 1; }
compose run --rm migrate up
compose exec -T postgres sh -eu -c '
  export PGPASSWORD=$(cat /run/secrets/postgres_runtime_password)
  exec psql -h 127.0.0.1 -U notitle_app -d notitle --no-psqlrc --set ON_ERROR_STOP=1
' < "$ROOT/scripts/db-role-check.sql"
compose run --build --rm backend-check
echo 'Real PostgreSQL role constraints, migrations 9→8→7→6→5→4→3→2→1→absent→9 and backend checks passed.'
