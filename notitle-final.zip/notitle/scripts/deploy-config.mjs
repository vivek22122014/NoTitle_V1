#!/usr/bin/env node
// Read-only validation. This module never invokes Docker or contacts a host.
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { isIP } from 'node:net';
import { strictJSON, sourceDigest } from './launch-evidence-lib.mjs';
const digest = (s) => createHash('sha256').update(s).digest('hex');
export function canonical(value) {
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (value && typeof value === 'object') return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + canonical(value[k])).join(',') + '}';
  return JSON.stringify(value);
}
function requireThat(ok, code) { if (!ok) throw new Error(code); }
function image(value) {
  requireThat(typeof value === 'string' && /^[a-z0-9][a-z0-9./:_-]*@sha256:[a-f0-9]{64}$/.test(value) && !/@sha256:(.)\1{63}$/.test(value), 'immutable_image_required');
  return value;
}
function protectedPath(value, directory = false) {
  requireThat(typeof value === 'string' && path.isAbsolute(value) && path.normalize(value) === value && !/[\x00-\x1f]/.test(value), 'absolute_protected_path_required');
  let current = path.parse(value).root;
  for (const part of value.slice(current.length).split('/')) {
    if (!part) continue;
    current = path.join(current, part);
    const st = fs.lstatSync(current);
    requireThat(!st.isSymbolicLink(), 'symlink_secret_path');
    requireThat((st.mode & 0o022) === 0, 'writable_secret_parent');
  }
  const st = fs.lstatSync(value);
  requireThat(directory ? st.isDirectory() : st.isFile(), 'invalid_secret_file_type');
  requireThat((st.mode & 0o077) === 0, 'secret_mode_not_private');
  if (!directory) requireThat(st.size > 0 && st.size <= 65536 && st.nlink === 1, 'invalid_secret_file_size_or_links');
}
function ports(service) { return service.ports ?? []; }
function checkService(name, service, relay = false) {
  requireThat(service && typeof service === 'object' && !service.build, 'runtime_build_forbidden');
  image(service.image);
  requireThat(!service.privileged && !service.devices?.length && !service.pid && !service.ipc, 'privileged_service_forbidden');
  requireThat((service.scale ?? 1) === 1 && (service.deploy?.replicas ?? 1) === 1, 'one_replica_required');
  requireThat(relay ? service.network_mode === 'host' : !service.network_mode, 'unexpected_network_mode');
  requireThat(service.security_opt?.some(v => /^no-new-privileges(?::|=)true$/.test(v)), 'no_new_privileges_required');
  requireThat(service.ulimits?.core === 0 || (service.ulimits?.core?.soft === 0 && service.ulimits?.core?.hard === 0), 'core_dumps_forbidden');
  requireThat(!service.cap_add?.length || ['web','relay'].includes(name), 'excess_capability');
  if (name !== 'postgres') {
    requireThat(service.read_only === true && service.cap_drop?.includes('ALL'), 'readonly_capability_boundary_required');
    requireThat((service.cap_add ?? []).every(v => ['web', 'relay'].includes(name) && v === 'NET_BIND_SERVICE'), 'excess_capability');
  }
  requireThat(service.logging?.driver === 'local' && service.logging?.options?.['max-size'] && service.logging?.options?.['max-file'], 'bounded_logs_required');
  if (name !== 'migrate') requireThat(service.mem_limit && service.restart === 'unless-stopped', 'resource_restart_bounds_required');
  for (const [key, value] of Object.entries(service.environment ?? {})) {
    requireThat(typeof value === 'string' && !/[\x00-\x1f]/.test(value), 'invalid_environment_value');
    if (/PASSWORD|SECRET|TOKEN|DATABASE_URL|CLIENT_ID/.test(key) && !key.endsWith('_FILE') && !key.endsWith('_UNTIL') && value !== '') throw new Error('inline_secret_forbidden');
  }
  for (const volume of service.volumes ?? []) {
    requireThat(volume && typeof volume === 'object' && !/docker\.sock$/.test(volume.source ?? '') && !['/', '/proc', '/sys', '/dev'].includes(volume.target), 'unsafe_mount');
    if (volume.type === 'bind') requireThat(path.isAbsolute(volume.source) && volume.bind?.create_host_path === false, 'strict_bind_required');
  }
}
export function validateDeployment(config, relayConfig, { checkFiles = false, purpose = 'production', sourceSHA256 = null } = {}) {
  requireThat(['production','acceptance'].includes(purpose), 'purpose_invalid');
  const acceptance = purpose === 'acceptance';
  requireThat(sourceSHA256 === null || /^[a-f0-9]{64}$/.test(sourceSHA256), 'source_hash_invalid');
  requireThat(config && /^[a-z0-9][a-z0-9_-]{0,62}$/.test(config.name ?? ''), 'project_name_required');
  requireThat(Object.keys(config.services ?? {}).sort().join(',') === 'api,migrate,postgres,web', 'exact_app_topology_required');
  for (const [name, service] of Object.entries(config.services)) checkService(name, service);
  const { api, web, postgres, migrate } = config.services;
  requireThat(!ports(postgres).length && !ports(migrate).length, 'database_ports_forbidden');
  requireThat(ports(api).length === 1 && ports(api).every(p => p.host_ip === '127.0.0.1' && Number(p.target) === 9090 && p.protocol === 'tcp'), 'admin_must_be_loopback_only');
  requireThat(ports(web).length === 1 && ports(web).every(p => Number(p.target) === 443 && Number(p.published) === 443 && p.protocol === 'tcp'), 'origin_https_only');
  requireThat(config.networks?.database?.internal === true, 'private_database_network_required');
  requireThat(Object.keys(postgres.networks ?? {}).join(',') === 'database' && Object.keys(web.networks ?? {}).join(',') === 'edge', 'network_scope_invalid');
  requireThat(api.environment.APP_ENV === (acceptance ? 'staging' : 'production') && api.environment.MAINTENANCE_MODE === 'true', 'production_must_boot_closed');
  requireThat(web.environment.NOTITLE_DEPLOYMENT_MODE === (acceptance ? 'staging' : 'production'), 'production_artifact_required');
  requireThat(api.environment.DEPLOYED_API_IMAGE === api.image && api.environment.LAUNCH_APPROVAL_FILE === '/var/lib/notitle/launch/approval.json', 'launch_image_binding_required');
  const approval = api.volumes?.find(v => v.target === '/var/lib/notitle/launch');
  requireThat(approval?.type === 'bind' && approval.read_only === true, 'protected_launch_directory_required');
  if (!acceptance) requireThat(web.environment.ORIGIN_AUTH_SCOPE === 'zone', 'zone_origin_auth_required');
  const origin = api.environment.PUBLIC_ORIGIN;
  let parsed; try { parsed = new URL(origin); } catch { throw new Error('canonical_origin_required'); }
  requireThat(parsed.protocol === 'https:' && parsed.origin === origin && !parsed.port && !parsed.username && !parsed.password && /^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/.test(parsed.hostname) && isIP(parsed.hostname) === 0 && parsed.hostname.includes('.') && !parsed.hostname.endsWith('.test') && !parsed.hostname.endsWith('.invalid') && !parsed.hostname.endsWith('.example'), 'canonical_origin_required');
  requireThat(web.environment.PUBLIC_ORIGIN === origin && web.environment.APP_ADDRESS === parsed.hostname, 'origin_mismatch');
  const stage = api.environment.LAUNCH_STAGE ?? 'validation';
  const ingress = acceptance ? 'cohort' : (web.environment.NOTITLE_LAUNCH_STAGE ?? 'maintenance');
  requireThat(['validation','cohort','public'].includes(stage) && ['maintenance','validation','cohort','public'].includes(ingress), 'launch_stage_invalid');
  if (!acceptance && ingress !== 'maintenance') requireThat(ingress === stage, 'launch_stage_ingress_mismatch');
  let validationRestricted = false;
  if (!acceptance && stage === 'validation' && ingress === 'validation') {
    const cidrs = (web.environment.VALIDATION_SOURCE_CIDRS ?? '').split(/\s+/).filter(Boolean);
    validationRestricted = cidrs.length > 0 && cidrs.length <= 32 && cidrs.every(c => {const [address,bits,...rest] = c.split('/');const family = isIP(address);return rest.length === 0 && family && /^\d+$/.test(bits ?? '') && Number(bits) >= (family === 4 ? 24 : 64) && Number(bits) <= (family === 4 ? 32 : 128);});
    requireThat(validationRestricted, 'restricted_validation_cidrs_required');
  }
  if (acceptance) requireThat(/^[A-Za-z0-9_-]{1,64}$/.test(web.environment.STAGING_USERNAME ?? '') && web.environment.STAGING_PASSWORD_HASH_FILE, 'authenticated_acceptance_required');
  if (api.environment.PAYMENTS_ENABLED === 'true') requireThat(api.environment.PAYMENT_ENVIRONMENT === (acceptance ? 'sandbox' : 'production'), 'payment_environment_mismatch');
  if (['validation','cohort'].includes(ingress)) requireThat(/^[A-Za-z0-9_-]{1,64}$/.test(web.environment.COHORT_USERNAME ?? '') || acceptance, 'cohort_username_required');
  const featureFlags = {};
  for (const key of ['IDENTITY_ENABLED', 'REALTIME_ENABLED', 'SAFETY_ENABLED', 'ADMIN_ENABLED', 'FRIENDS_ENABLED', 'AUDIO_ENABLED', 'OPERATIONS_ENABLED', 'PAYMENTS_ENABLED', 'CHECKOUT_ENABLED']) {
    requireThat(['true', 'false'].includes(api.environment[key]), 'feature_flag_invalid'); featureFlags[key] = api.environment[key] === 'true';
  }
  if (ingress !== 'maintenance') requireThat(['IDENTITY_ENABLED','REALTIME_ENABLED','SAFETY_ENABLED','ADMIN_ENABLED','OPERATIONS_ENABLED'].every(k => featureFlags[k]), 'real_user_safety_required');
  requireThat(api.volumes?.some(v => v.type === 'volume' && v.source === 'deletion_tombstones' && v.target === '/var/lib/notitle/tombstones'), 'independent_deletion_volume_required');
  if (featureFlags.OPERATIONS_ENABLED) {
    const holds = api.volumes?.find(v => v.target === '/var/lib/notitle/holds');
    const keys = api.volumes?.find(v => v.target === '/var/lib/notitle/operations-keys');
    requireThat(holds?.type === 'bind' && holds.read_only !== true && keys?.type === 'bind' && keys.read_only === true && holds.source !== keys.source, 'independent_hold_journal_required');
    requireThat(!(postgres.volumes ?? []).some(v => v.source === holds.source), 'hold_journal_must_survive_database_rollback');
  }
  const tls = web.volumes?.find(v => v.target === '/run/notitle-origin');
  requireThat(tls?.type === 'bind' && tls.read_only === true, 'origin_tls_mount_required');
  const images = { api: api.image, web: web.image, migrate: migrate.image, postgres: postgres.image };
  let secretCount = 0;
  if (checkFiles) {
    for (const secret of Object.values(config.secrets ?? {})) { requireThat(!secret.external && secret.file, 'file_secret_required'); protectedPath(secret.file); secretCount++; }
    protectedPath(tls.source, true);
    for (const name of [...(!acceptance ? ['origin-cert.pem','origin-key.pem','origin-pull-ca.pem'] : []), ...(!acceptance && ['cohort','validation'].includes(ingress) ? ['cohort-password-hash'] : []), ...(!acceptance && ingress === 'validation' ? ['cloudflare-proxies'] : [])]) { protectedPath(path.join(tls.source, name)); secretCount++; }
    const directoryFiles = new Map([
      ['/var/lib/notitle/operations-keys', ['case_keyring','retention-policy.json','primary_token','backup_token']],
      ['/var/lib/notitle/payment-keys', ['client_id','client_secret']]
    ]);
    for (const volume of api.volumes ?? []) if (volume.type === 'bind') {
      protectedPath(volume.source, true);
      for (const name of directoryFiles.get(volume.target) ?? []) { protectedPath(path.join(volume.source, name)); secretCount++; }
    }
  }
  if (relayConfig) {
    requireThat(Object.keys(relayConfig.services ?? {}).join(',') === 'relay', 'exact_relay_topology_required');
    const relay = relayConfig.services.relay; checkService('relay', relay, true);
    requireThat(!ports(relay).length && relay.user === '65532:65532', 'relay_host_user_boundary_required');
    const control = (relay.environment.RELAY_CONTROL_ADDR ?? '').split(':');
    requireThat(control.length === 2 && control[1] === '9443' && isIP(control[0]) === 4 && /^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.)/.test(control[0]), 'private_relay_control_required');
    const secrets = relay.volumes?.find(v => v.target === '/run/secrets');
    requireThat(secrets?.read_only && secrets.type === 'bind', 'relay_secret_mount_required');
    if (checkFiles) { protectedPath(secrets.source, true); for (const name of ['relay-control-token','control-ca.pem','control-cert.pem','control-key.pem','turn-cert.pem','turn-key.pem']) { protectedPath(path.join(secrets.source,name)); secretCount++; } }
    images.turn = relay.image;
  }
  // This one field is populated with the final manifest hash after review;
  // exclude it from its own preimage. No other environment value is omitted.
  const boundConfig = structuredClone(config);
  boundConfig.services.api.environment.DEPLOYMENT_MANIFEST_SHA256 = '';
  return { schema_version: 1, environment: acceptance ? 'isolated_acceptance' : 'production', source_sha256: sourceSHA256, compose_sha256: digest(canonical(boundConfig)), relay_compose_sha256: relayConfig ? digest(canonical(relayConfig)) : null, origin, images, single_owner: true, database_schema: 9, origin_auth_scope: acceptance ? 'acceptance_review' : 'zone', stage, ingress_mode: ingress === 'validation' ? 'cohort' : ingress, validation_source_restricted: validationRestricted, feature_flags: featureFlags, secret_files_checked: checkFiles, secret_file_count: secretCount, limitations: ['Static configuration checks do not prove effective host firewall, TLS, image provenance, live owner count, secret readability inside containers, recovery or runtime acceptance.'] };
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const args = process.argv.slice(2); requireThat(args.shift() === 'validate', 'usage_validate_config_relay_config_out');
    const opts = {}; while (args.length) { const key = args.shift(); requireThat(['--config','--relay-config','--out','--check-files','--purpose','--source'].includes(key) && !(key in opts), 'invalid_argument'); opts[key] = key === '--check-files' ? true : args.shift(); requireThat(opts[key], 'missing_argument'); }
    requireThat(opts['--config'], 'config_required');
    const read = p => { requireThat(fs.statSync(p).size < 1024 * 1024, 'config_too_large'); return strictJSON(new TextDecoder('utf-8', {fatal:true}).decode(fs.readFileSync(p))); };
    const manifest = validateDeployment(read(opts['--config']), opts['--relay-config'] ? read(opts['--relay-config']) : undefined, {checkFiles: opts['--check-files'] === true, purpose: opts['--purpose'] ?? 'production', sourceSHA256: opts['--source'] ? (await sourceDigest(opts['--source'])).sha256 : null});
    const output = JSON.stringify(manifest, null, 2) + '\n';
    if (opts['--out']) fs.writeFileSync(opts['--out'], output, {flag:'wx', mode:0o600});
    else process.stdout.write(output);
  } catch (error) { console.error('Deployment validation failed: ' + (error instanceof Error && /^[a-z_]+$/.test(error.message) ? error.message : 'invalid_or_inaccessible_input')); process.exitCode = 1; }
}
