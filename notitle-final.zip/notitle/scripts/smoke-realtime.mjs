// Real Caddy + Go + PostgreSQL Phase 4 integration gate. This is called only by
// smoke-stack.sh, which owns a disposable database. No public load is generated.
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { setTimeout as delay } from 'node:timers/promises';
import { SmokeSocket } from './realtime-smoke-client.mjs';

const base = process.env.SMOKE_BASE_URL ?? 'http://web:8080';
const origin = process.env.SMOKE_PUBLIC_ORIGIN ?? 'http://localhost:8080';
const sockets = new Set();
class Browser {
  jar = new Map();
  csrf = '';
  identity;
  cookie() { return [...this.jar].map(([key, value]) => `${key}=${value}`).join('; '); }
  async api(path, method = 'GET', body, expected = 200, overrides = {}) {
    const headers = { Cookie: this.cookie(), ...overrides };
    if (method !== 'GET') Object.assign(headers, { Origin: origin, 'Content-Type': 'application/json', 'X-CSRF-Token': this.csrf }, overrides);
    const response = await fetch(base + '/api/v1' + path, {
      method, headers, body: body === undefined ? undefined : JSON.stringify(body),
      redirect: 'manual', signal: AbortSignal.timeout(15000)
    });
    assert.equal(response.status, expected, `${method} ${path}: unexpected HTTP status`);
    assert.match(response.headers.get('cache-control') ?? '', /no-store/);
    for (const cookie of response.headers.getSetCookie()) {
      const pair = cookie.split(';', 1)[0], separator = pair.indexOf('=');
      const name = pair.slice(0, separator), value = pair.slice(separator + 1);
      if (value === '' || /Max-Age=0/i.test(cookie)) this.jar.delete(name); else this.jar.set(name, value);
    }
    const result = await response.json();
    if (result.csrf_token) this.csrf = result.csrf_token;
    if (result.identity) this.identity = result.identity;
    return result;
  }
  async guest(gender) {
    const bootstrap = await this.api('/auth/bootstrap');
    await this.api('/guest/session', 'POST', {
      profile: { gender, topic: 'general_talk', bio: '', professional: {profession: '', industry: '', experience: '', interests: []} },
      consent: {adult_confirmed: true, policies: bootstrap.policies}
    }, 201);
    return this;
  }
  async ticket(takeover = false) { return this.api('/realtime/ticket', 'POST', {takeover}, 201); }
  async socket(ticket, {takeover = false, resume} = {}) {
    const socket = await SmokeSocket.open(base, origin, this.cookie());
    sockets.add(socket);
    socket.send({v: 1, id: randomUUID(), type: 'session.authenticate', generation: 0, payload: {ticket, takeover, ...(resume ? {resume} : {})}});
    return socket;
  }
  async connect(options = {}) {
    const ticket = await this.ticket(options.takeover ?? false);
    const socket = await this.socket(ticket.ticket, options);
    const event = await socket.event('session.ready');
    assert.equal(event.v, 1);
    assert.ok(event.generation > 0);
    return {socket, state: event.payload};
  }
  async afterWaitingDisconnect() {
    // TCP EOF and the replacement HTTP request travel on separate connections.
    // Retry a still-owned slot briefly, never turn a retry into a takeover.
    for (let attempt = 0; attempt < 5; attempt++) {
      const ticket = await this.ticket();
      const socket = await this.socket(ticket.ticket);
      const result = await socket.event(['session.ready', 'error']);
      if (result.type === 'session.ready') return {socket, state:result.payload};
      assert.equal(result.payload.code, 'TAKEOVER_REQUIRED');
      await socket.waitClosed();
      await delay(100);
    }
    throw new Error('Waiting connection was not released after disconnect');
  }
}
function command(connection, type, interaction, overrides = {}) {
  const envelope = {
    v: 1, id: randomUUID(), type, generation: connection.state.generation,
    ...(interaction ? {interaction_id: interaction.id, epoch: interaction.epoch} : {}),
    payload: {}, ...overrides
  };
  connection.socket.send(envelope);
  return envelope.id;
}
function resume(state, interaction) {
  return {
    token: state.resume_token, server_instance: state.server_instance, generation: state.generation,
    ...(interaction ? {interaction_id: interaction.id, epoch: interaction.epoch} : {})
  };
}
function peerProjection(peer) {
  assert.deepEqual(Object.keys(peer).sort(), ['bio', 'display_name', 'gender', 'topic']);
  assert.ok(['male', 'female', 'other'].includes(peer.gender));
}
function interaction(event) {
  const view = event.payload.interaction;
  assert.ok(view && view.id && view.epoch > 0, 'Expected authoritative interaction snapshot');
  peerProjection(view.peer);
  return view;
}

try {
  const a = await new Browser().guest('male');
  const b = await new Browser().guest('female');
  const c = await new Browser().guest('other');
  await a.api('/realtime/ticket', 'POST', {takeover:false}, 403, {Origin:'https://untrusted.invalid'});
  await a.api('/realtime/ticket', 'POST', {takeover:false}, 403, {'X-CSRF-Token':'invalid'});
  await assert.rejects(SmokeSocket.open(base, 'https://untrusted.invalid', a.cookie()), (error) => error.status === 403);

  const ticket = await a.ticket();
  const first = await a.socket(ticket.ticket);
  const firstReady = await first.event('session.ready');
  let ac = {socket:first, state:firstReady.payload};
  assert.equal(ac.state.state, 'IDLE');
  const replay = await a.socket(ticket.ticket);
  const replayError = await replay.event('error');
  assert.equal(replayError.payload.code, 'AUTHENTICATION_REQUIRED');
  await replay.waitClosed();
  let bc = await b.connect();
  const cc = await c.connect();

  // No client field or preference request can grant paid matching controls.
  const currentPreferences = await a.api('/me/matching-preferences');
  assert.equal(currentPreferences.premium_active, false);
  await a.api('/me/matching-preferences', 'PATCH', {
    ...currentPreferences.preferences, gender: 'female'
  }, 403);

  command(ac, 'queue.join');
  await ac.socket.event('queue.joined');
  command(bc, 'queue.join');
  const [am, bm] = await Promise.all([ac.socket.event('match.found'), bc.socket.event('match.found')]);
  const ai = interaction(am), bi = interaction(bm);
  assert.equal(ai.id, bi.id); assert.equal(ai.epoch, bi.epoch);
  assert.equal(ai.peer.gender, 'female'); assert.equal(bi.peer.gender, 'male');

  // Reject stale connection commands without disturbing the active match.
  const staleID = command(ac, 'match.end', ai, {generation: ac.state.generation + 1000});
  const stale = await ac.socket.event('error', (event) => event.reply_to === staleID);
  assert.equal(stale.payload.code, 'STALE_GENERATION');

  // Transient loss retains exactly this match; no new random match is queued.
  ac.socket.abort();
  await bc.socket.event('peer.disconnected');
  const oldState = ac.state;
  ac = await a.connect({resume: resume(oldState, ai)});
  assert.equal(ac.state.state, 'MATCHED');
  assert.equal(ac.state.interaction.id, ai.id);
  assert.equal(ac.state.interaction.epoch, ai.epoch);
  await bc.socket.event('peer.reconnected');

  // A second tab cannot silently seize control.
  const rejectedTicket = await a.ticket();
  const rejected = await a.socket(rejectedTicket.ticket);
  const takeoverError = await rejected.event('error');
  assert.equal(takeoverError.payload.code, 'TAKEOVER_REQUIRED');
  await rejected.waitClosed();
  // Next queues only its initiator. The peer stays idle until their own action.
  command(ac, 'match.next', ac.state.interaction);
  await bc.socket.event('match.ended');
  await ac.socket.event('queue.joined');
  command(cc, 'queue.join');
  const [secondA, secondC] = await Promise.all([ac.socket.event('match.found'), cc.socket.event('match.found')]);
  const secondAI = interaction(secondA), secondCI = interaction(secondC);
  assert.equal(secondAI.id, secondCI.id); assert.notEqual(secondAI.id, ai.id);
  assert.equal(secondAI.peer.gender, 'other');
  const oldEpochID = command(ac, 'match.end', ai);
  assert.equal((await ac.socket.event('error', (event) => event.reply_to === oldEpochID)).payload.code, 'STALE_EPOCH');

  // Profile changes do not rewrite the committed peer view or end this match.
  const owner = await a.api('/me');
  await a.api('/me/profile', 'PATCH', {version:owner.identity.profile.version, gender:'other'});
  command(cc, 'state.sync');
  const current = await cc.socket.event('session.state');
  assert.equal(current.payload.interaction.id, secondAI.id);
  assert.equal(current.payload.interaction.peer.gender, 'male');

  // Explicit takeover ends the previous interaction before the new tab becomes
  // idle. A delayed close of the replaced socket cannot disconnect its successor.
  const previous = ac;
  ac = await a.connect({takeover:true});
  await previous.socket.event('session.replaced');
  await previous.socket.waitClosed();
  await cc.socket.event('match.ended');
  assert.ok(ac.state.generation > previous.state.generation);
  assert.equal(ac.state.state, 'IDLE');
  assert.equal(ac.state.interaction, undefined);
  command(ac, 'queue.join');
  await ac.socket.event('queue.joined');
  command(bc, 'queue.join');
  const [thirdA, thirdB] = await Promise.all([ac.socket.event('match.found'), bc.socket.event('match.found')]);
  assert.equal(interaction(thirdA).id, interaction(thirdB).id);
  assert.equal(interaction(thirdB).peer.gender, 'other', 'Profile update must apply to the next match');

  // Logout invalidation outranks stale command work and immediately ends the
  // owned interaction instead of leaving a revoked socket usable for 25s.
  await a.api('/auth/logout', 'POST', {});
  await bc.socket.event('match.ended');
  await ac.socket.waitClosed();
  command(bc, 'queue.join');
  await bc.socket.event('queue.joined');
  bc.socket.abort();
  bc = await b.afterWaitingDisconnect();
  assert.equal(bc.state.state, 'IDLE', 'Disconnected waiting entries must not auto rejoin');
  await b.api('/auth/logout', 'POST', {});
  await c.api('/auth/logout', 'POST', {});
  console.log('Real realtime lifecycle passed: Origin/CSRF, single-use tickets, shared matching, private projections, stale generations/epochs, reconnect, explicit takeover, Next ownership, profile snapshot and logout revocation.');
} finally {
  for (const socket of sockets) socket.abort();
}
