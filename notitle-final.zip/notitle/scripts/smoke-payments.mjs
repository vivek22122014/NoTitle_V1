// Default-off boundary test against the real disposable Caddy/Go/PostgreSQL
// stack. This never creates a provider order, submits a payment or refunds.
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';

if (process.env.SMOKE_DISPOSABLE_TARGET !== '1') {
  throw new Error('Payment smoke creates a synthetic account; require SMOKE_DISPOSABLE_TARGET=1 on an isolated disposable stack.');
}
const base = process.env.SMOKE_BASE_URL ?? 'http://web:8080';
const origin = process.env.SMOKE_PUBLIC_ORIGIN ?? 'http://localhost:8080';
const jar = new Map();
let csrf = '';
const cookieHeader = () => [...jar].map(([key,value]) => `${key}=${value}`).join('; ');
async function call(path, method = 'GET', body, expected = 200, overrides = {}) {
  const headers = { Cookie: cookieHeader() };
  if (method !== 'GET') Object.assign(headers, { Origin: origin, 'Content-Type':'application/json', 'X-CSRF-Token':csrf });
  Object.assign(headers, overrides);
  const response = await fetch(base + '/api/v1' + path, {
    method, headers, body: body === undefined ? undefined : JSON.stringify(body),
    redirect: 'manual', signal: AbortSignal.timeout(15000)
  });
  // Never print responses, contact fields, session cookies or recovery codes.
  assert.equal(response.status, expected, `${method} payment smoke route: unexpected status`);
  assert.match(response.headers.get('cache-control') ?? '', /no-store/);
  for (const cookie of response.headers.getSetCookie()) {
    const pair = cookie.split(';',1)[0]; const split = pair.indexOf('=');
    const key = pair.slice(0,split); const value = pair.slice(split+1);
    if (value === '' || /Max-Age=0/i.test(cookie)) jar.delete(key); else jar.set(key,value);
  }
  const value = await response.json();
  if (value.csrf_token) csrf = value.csrf_token;
  return value;
}
function noCheckoutSecret(value) {
  const walk = (node) => {
    if (!node || typeof node !== 'object') return;
    for (const [key,child] of Object.entries(node)) {
      assert.ok(!['payment_session_id','client_secret','customer_phone','account_id','merchant_id','provider_order_id'].includes(key), 'Sensitive payment field leaked while checkout is disabled');
      walk(child);
    }
  };
  walk(value);
}

const plans = await call('/premium/plans');
assert.equal(plans.checkout_enabled, false, 'This smoke must run with checkout disabled');
assert.equal(plans.environment, 'sandbox', 'Never run this smoke against live financial mode');
assert.deepEqual(plans.plans, [], 'The initial migration must publish no unreviewed price');
assert.equal(plans.phone_required, true);
assert.match(plans.catalog_version, /^[a-f0-9]{64}$/);
noCheckoutSecret(plans);

await call('/me/premium','GET',undefined,401);
await call('/me/receipts','GET',undefined,401);
await call('/me/receipts/'+'a'.repeat(32),'GET',undefined,401);
await call('/payments/'+'a'.repeat(32),'GET',undefined,401);
const bootstrap = await call('/auth/bootstrap');
const consent = { adult_confirmed:true, policies:bootstrap.policies };
const profile = { gender:'other', display_name:'', bio:'', topic:'general_talk', professional:{profession:'',industry:'',experience:''} };
await call('/guest/session','POST',{profile,consent},201);
await call('/me/premium','GET',undefined,401);
await call('/payments/orders','POST',{plan_id:'seven_day',plan_version:1,idempotency_key:randomUUID(),customer_phone:'9999999999'},401);

const username = 'pay_' + randomUUID().replaceAll('-','').slice(0,16);
const password = 'Synthetic payment smoke password 9527';
await call('/auth/register','POST',{username,password,profile,consent},201);
const premium = await call('/me/premium');
assert.equal(premium.premium_active,false);
assert.equal(premium.remaining_seconds,0);
assert.ok(Number.isSafeInteger(premium.version) && premium.version >= 1);
assert.ok(!premium.expires_at);
noCheckoutSecret(premium);
const orders = await call('/me/orders');
const receipts = await call('/me/receipts');
assert.deepEqual(orders.orders,[]);
assert.deepEqual(receipts.receipts,[]);
noCheckoutSecret(orders); noCheckoutSecret(receipts);
await call('/payments/'+'a'.repeat(32),'GET',undefined,404);
await call('/me/receipts/'+'a'.repeat(32),'GET',undefined,404);
await call('/payments/'+'a'.repeat(32)+'/refunds','GET',undefined,404);

const attempt = {plan_id:'seven_day',plan_version:1,idempotency_key:randomUUID(),customer_phone:'9999999999'};
await call('/payments/orders','POST',attempt,403,{Origin:'https://untrusted.invalid'});
await call('/payments/orders','POST',attempt,403,{'X-CSRF-Token':'wrong'});
const off = await call('/payments/orders','POST',attempt,503);
assert.equal(off.error.code,'checkout_unavailable'); noCheckoutSecret(off);
await call('/payments/checkout','POST',{purchase_ref:'a'.repeat(32)},503);
await call('/payments/verify','POST',{purchase_ref:'a'.repeat(32)},404);
assert.deepEqual((await call('/me/orders')).orders,[], 'Disabled checkout must create no purchase intent');

// Provider authentication is a separate raw-body boundary. With integration
// disabled even a shaped event cannot enter the ledger, without CSRF or cookie.
const marker = 'PHASE8_WEBHOOK_ONLY_f7b803bae1314e40';
const webhook = await fetch(base + '/api/v1/webhooks/cashfree', {
  method:'POST', headers:{'Content-Type':'application/json'},
  body:JSON.stringify({type:'PAYMENT_SUCCESS_WEBHOOK',canary:marker,data:{order:{order_id:'a'.repeat(32)},payment:{cf_payment_id:'42'}}}),
  redirect:'manual', signal:AbortSignal.timeout(15000)
});
assert.equal(webhook.status,503);
assert.match(webhook.headers.get('cache-control') ?? '', /no-store/);
const hookError = await webhook.json(); noCheckoutSecret(hookError);
assert.equal((await call('/me/premium')).premium_active,false,'Forged callback cannot activate Premium');

await call('/auth/reauthenticate','POST',{password});
const deletion = await call('/me','DELETE',{confirm:true},202);
assert.equal(deletion.access_disabled,true);
await call('/me/premium','GET',undefined,401);
await call('/me/receipts','GET',undefined,401);
console.log('Payment off-switch, unpublished catalog, account-only scope, CSRF/Origin, inert webhook, empty receipts and deleted-session checks passed. No sandbox/live financial acceptance is implied.');
