#!/usr/bin/env python3
"""Filesystem and envelope tests. Fake age output does not establish encryption."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True

spec = importlib.util.spec_from_file_location("archive", Path(__file__).with_name("operations-archive.py"))
archive = importlib.util.module_from_spec(spec)
spec.loader.exec_module(archive)


class ArchiveTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)
        self.source = self.directory / "closed-segment"
        self.source.write_bytes(b'{"event":"health_change"}\n')
        self.source.chmod(0o600)
        self.recipient = "age1" + "a" * 58

    def fake_age(self, command, **kwargs):
        self.assertEqual(command, ["age", "--encrypt", "--recipient", self.recipient])
        body = json.loads(kwargs["input"])
        self.assertEqual(body["purpose"], "security")
        self.assertNotIn(str(self.source), kwargs["input"].decode())
        return subprocess.CompletedProcess(command, 0, b"age-encryption.org/v1\nSYNTHETIC_TEST_CIPHERTEXT", b"")

    def test_seal_publishes_private_opaque_files_and_preserves_source(self):
        result = archive.seal(self.source, self.directory, self.recipient, "security", self.fake_age)
        self.assertEqual(self.source.read_bytes(), b'{"event":"health_change"}\n')
        for name in [result["object"], result["object"] + ".json"]:
            self.assertEqual((self.directory / name).stat().st_mode & 0o777, 0o600)
        self.assertNotIn("plaintext_sha256", result)
        self.assertNotIn("payload_base64", result)

    def test_symlink_source_and_parent_rejected(self):
        link = self.directory / "linked"
        link.symlink_to(self.source)
        with self.assertRaises((ValueError, OSError)):
            archive.read_segment(link)
        parent_link = self.directory / "parent"
        parent_link.symlink_to(self.directory, target_is_directory=True)
        with self.assertRaises((ValueError, OSError)):
            archive.read_segment(parent_link / self.source.name)

    def test_non_private_and_empty_segments_rejected(self):
        self.source.chmod(0o644)
        with self.assertRaises(ValueError):
            archive.read_segment(self.source)
        self.source.chmod(0o600)
        self.source.write_bytes(b"")
        with self.assertRaises(ValueError):
            archive.read_segment(self.source)

    def test_oversized_segment_rejected_before_encryption(self):
        with self.source.open("wb") as output:
            output.truncate(archive.MAX_BYTES + 1)
        with self.assertRaises(ValueError):
            archive.read_segment(self.source)

    def test_encryption_failure_publishes_nothing(self):
        before = set(self.directory.iterdir())
        def fail(command, **kwargs):
            return subprocess.CompletedProcess(command, 1, b"", b"sensitive error not propagated")
        with self.assertRaisesRegex(ValueError, "encryption unavailable"):
            archive.seal(self.source, self.directory, self.recipient, "security", fail)
        self.assertEqual(before, set(self.directory.iterdir()))

    def test_shell_or_private_key_input_rejected(self):
        for value in ["AGE-SECRET-KEY-1TEST", "$(touch /tmp/bad)", self.recipient + "\n"]:
            with self.assertRaises(ValueError):
                archive.seal(self.source, self.directory, value, "security", self.fake_age)


if __name__ == "__main__":
    unittest.main()
