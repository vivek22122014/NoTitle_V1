#!/usr/bin/env node
// Local immutable-candidate preparation. Never pushes images or deploys a host.
import { spawn } from 'node:child_process';
import { lstat, mkdir, readFile, realpath, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { readJSON, sourceDigest, validOrigin } from './launch-evidence-lib.mjs';

const BASES = ['go', 'node', 'caddy', 'migration', 'turn', 'postgres'];
const SERVICES = ['api', 'web', 'migrate', 'turn'];
const IMAGE = /^(?=.{1,400}$)[a-z0-9][a-z0-9._/-]*@sha256:[a-f0-9]{64}$/;
const TAG = /^(?=.{1,400}$)[a-z0-9][a-z0-9._/-]*:[a-zA-Z0-9][a-zA-Z0-9_.-]{0,63}$/;
const HASH = /^[a-f0-9]{64}$/;
const exact = (v, keys) => v && typeof v === 'object' && !Array.isArray(v) && Object.keys(v).length === keys.length && keys.every((key) => Object.hasOwn(v, key));
export function validateBuildInput(input) {
  if (!exact(input, ['schema_version', 'source_sha256', 'version', 'commit', 'release_mode', 'origin', 'checkout_enabled', 'base_images', 'tags']) || input.schema_version !== 'notitle-build-v1') throw new Error('Invalid build input shape');
  if (typeof input.source_sha256 !== 'string' || !HASH.test(input.source_sha256) || typeof input.version !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$/.test(input.version) || (input.commit !== null && (typeof input.commit !== 'string' || !/^[a-f0-9]{40}$/.test(input.commit))) || !['production', 'staging'].includes(input.release_mode) || !validOrigin(input.origin) || typeof input.checkout_enabled !== 'boolean') throw new Error('Reviewed source, version, optional actual commit, release mode and actual HTTPS origin required');
  if (!exact(input.base_images, BASES) || !BASES.every((key) => typeof input.base_images[key] === 'string' && IMAGE.test(input.base_images[key]))) throw new Error('Six reviewed immutable base/runtime image references required');
  if (!exact(input.tags, SERVICES) || !SERVICES.every((key) => typeof input.tags[key] === 'string' && TAG.test(input.tags[key])) || new Set(Object.values(input.tags)).size !== 4) throw new Error('Four distinct versioned output tags required');
  return input;
}
export function buildPlan(input, now = new Date(), webOnly = false) {
  const c = validateBuildInput(input);
  if (!Number.isFinite(now.valueOf())) throw new Error('Invalid build clock');
  const common = ['--build-arg', `GO_BUILD_IMAGE=${c.base_images.go}`];
  const steps = [
    { service: 'api', file: 'server/Dockerfile', args: [...common, '--build-arg', `VERSION=${c.version}`, '--build-arg', `COMMIT=${c.commit ?? 'archive'}`, '--build-arg', `BUILD_TIME=${now.toISOString()}`, '--build-arg', `SOURCE_SHA256=${c.source_sha256}`] },
    { service: 'web', file: 'deploy/app/Caddy.Dockerfile', args: ['--build-arg', `NODE_BUILD_IMAGE=${c.base_images.node}`, '--build-arg', `CADDY_RUNTIME_IMAGE=${c.base_images.caddy}`, '--build-arg', `PUBLIC_RELEASE_MODE=${c.release_mode}`, '--build-arg', `PUBLIC_SITE_ORIGIN=${c.origin}`, '--build-arg', `PUBLIC_CHECKOUT_SDK_ENABLED=${c.checkout_enabled}`, '--build-arg', `PUBLIC_CHECKOUT_ENVIRONMENT=${c.release_mode === 'production' ? 'production' : 'sandbox'}`] },
    { service: 'migrate', file: 'deploy/migrate/Dockerfile', args: [...common, '--build-arg', `MIGRATION_RUNTIME_IMAGE=${c.base_images.migration}`] },
    { service: 'turn', file: 'deploy/turn/Dockerfile', args: [...common, '--build-arg', `TURN_RUNTIME_IMAGE=${c.base_images.turn}`] },
  ].filter((s) => !webOnly || s.service === 'web').map((s) => ({ service: s.service, command: 'docker', args: ['build', '--pull', '--file', s.file, '--tag', c.tags[s.service], ...s.args, '.'] }));
  return { schema_version: 'notitle-build-plan-v1', source_sha256: c.source_sha256, version: c.version, commit: c.commit, release_mode: c.release_mode, origin: c.origin, created_at: now.toISOString(), steps, postgres: c.base_images.postgres, performs_push: false, performs_deploy: false, launch_approved: false };
}
async function command(args, { cwd, capture = false } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn('docker', args, { cwd, shell: false, stdio: capture ? ['ignore', 'pipe', 'ignore'] : ['ignore', 'inherit', 'inherit'] });
    let output = ''; let failed = false; let killTimer;
    const stop = () => {
      failed = true; child.kill('SIGTERM');
      if (!killTimer) { killTimer = setTimeout(() => child.kill('SIGKILL'), 2000); killTimer.unref(); }
    };
    const timer = setTimeout(stop, 20 * 60 * 1000);
    timer.unref();
    const cleanup = () => { clearTimeout(timer); clearTimeout(killTimer); };
    const onFail = () => { cleanup(); reject(new Error('Docker build/inspection failed; no release approval produced')); };
    child.once('error', onFail);
    child.stdout?.on('data', (chunk) => { if (!failed) output += chunk.toString(); if (Buffer.byteLength(output) > 1024 * 1024) stop(); });
    child.once('close', (code) => { cleanup(); if (failed || code !== 0) onFail(); else resolve(output); });
  });
}
export async function prepareBuild({ source, output, config, execute = false, webOnly = false, now = new Date() }) {
  const root = await realpath(source); const c = validateBuildInput(config);
  const destination = path.resolve(output); const parent = await realpath(path.dirname(destination));
  if (path.relative(root, parent) === '' || !path.relative(root, parent).startsWith(`..${path.sep}`) && path.relative(root, parent) !== '..') throw new Error('Keep build outputs outside the source tree');
  try { await lstat(destination); throw new Error('Use a new output directory; existing output is never overwritten'); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  for (const relative of ['server/go.sum', 'web/package-lock.json']) {
    const p = path.join(root, relative); const st = await lstat(p);
    if (!st.isFile() || st.isSymbolicLink() || st.size === 0 || st.size > 16 * 1024 * 1024) throw new Error('Authentic reviewed dependency locks required');
  }
  const lock = JSON.parse(await readFile(path.join(root, 'web/package-lock.json'), 'utf8'));
  if (lock.lockfileVersion !== 3 || !lock.packages?.['']) throw new Error('Authentic npm lockfile v3 required');
  const digest = await sourceDigest(root);
  if (digest.sha256 !== c.source_sha256) throw new Error('Source changed since the build input was reviewed');
  const plan = buildPlan(c, now, webOnly);
  await mkdir(destination, { mode: 0o700 });
  await writeFile(path.join(destination, 'build-plan.json'), JSON.stringify(plan, null, 2) + '\n', { mode: 0o600, flag: 'wx' });
  if (!execute) return { state: 'planned', output: destination, launch_approved: false };
  const images = {};
  for (const step of plan.steps) {
    await command(step.args, { cwd: root });
    const inspected = JSON.parse(await command(['image', 'inspect', c.tags[step.service]], { cwd: root, capture: true }));
    if (!Array.isArray(inspected) || inspected.length !== 1 || !/^sha256:[a-f0-9]{64}$/.test(inspected[0].Id)) throw new Error('Image inspection invalid');
    images[step.service] = { local_image_id: inspected[0].Id, tag: c.tags[step.service], repository_digests: (inspected[0].RepoDigests ?? []).filter((v) => IMAGE.test(v)) };
  }
  if ((await sourceDigest(root)).sha256 !== c.source_sha256) throw new Error('Source changed during build; discard these candidates');
  const result = { schema_version: 'notitle-build-result-v1', completed_at: new Date().toISOString(), source_sha256: c.source_sha256, version: c.version, commit: c.commit, release_mode: c.release_mode, origin: c.origin, images, postgres: c.base_images.postgres, tests_passed: false, scans_passed: false, launch_approved: false, note: 'Local image IDs are configuration digests, not registry manifest digests. Complete image scans, controlled publication, staging and launch evidence before deployment.' };
  await writeFile(path.join(destination, 'build-result.json'), JSON.stringify(result, null, 2) + '\n', { mode: 0o600, flag: 'wx' });
  return { state: 'candidates_built', output: destination, launch_approved: false };
}
async function main() {
  const args = process.argv.slice(2); const opts = {}; let execute = false; let webOnly = false;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--execute' && !execute) { execute = true; continue; }
    if (args[i] === '--web-only' && !webOnly) { webOnly = true; continue; }
    if (!['--source', '--config', '--output'].includes(args[i]) || Object.hasOwn(opts, args[i]) || !args[i + 1] || args[i + 1].startsWith('--')) throw new Error('Usage: release-build.mjs --source DIR --config FILE --output NEW_OUTSIDE_DIR [--execute] [--web-only]');
    opts[args[i]] = args[++i];
  }
  if (Object.keys(opts).length !== 3) throw new Error('Source, config and a new external output directory are required');
  console.log(JSON.stringify(await prepareBuild({ source: opts['--source'], config: await readJSON(opts['--config']), output: opts['--output'], execute, webOnly })));
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main().catch(() => { console.error('Release preparation blocked. Check inputs, immutable images, source binding, protected external output and authentic dependency locks. No deployment or launch approval was performed.'); process.exitCode = 1; });
