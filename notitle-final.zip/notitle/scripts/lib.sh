#!/usr/bin/env bash
# Common shell helpers; paths and tool versions are explicit.
set -euo pipefail
ROOT=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
GO_IMAGE=golang:1.27.2-bookworm
NODE_IMAGE=node:24.19.0-bookworm-slim
require_docker() {
  command -v docker >/dev/null || { echo 'Install Docker Engine/Desktop with Compose v2.30+ first.' >&2; exit 1; }
  docker info >/dev/null 2>&1 || { echo 'Docker is not running or is inaccessible to this user.' >&2; exit 1; }
  local compose_version
  compose_version=$(docker compose version --short)
  if [[ ! $compose_version =~ ^v?([0-9]+)\.([0-9]+) ]] ||
     (( BASH_REMATCH[1] < 2 || (BASH_REMATCH[1] == 2 && BASH_REMATCH[2] < 30) )); then
    echo 'Docker Compose v2.30 or newer is required.' >&2
    exit 1
  fi
}
require_locks() {
  test -s "$ROOT/server/go.sum" && test -s "$ROOT/web/package-lock.json" || {
    echo 'Dependency locks are missing. Run ./scripts/bootstrap.sh prepare on a networked machine, review and commit both authentic locks.' >&2
    exit 1
  }
}
docker_source() {
  local image=$1 directory=$2
  shift 2
  docker run --rm --user "$(id -u):$(id -g)" \
    --mount "type=bind,src=$ROOT,dst=/work" -w "/work/$directory" \
    -e npm_config_cache=/tmp/notitle-npm-cache -e GOCACHE=/tmp/notitle-go-cache \
    -e GOMODCACHE=/tmp/notitle-go-mod -e GOTOOLCHAIN=local \
    "$image" "$@"
}
