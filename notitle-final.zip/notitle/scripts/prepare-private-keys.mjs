// Local container setup only. Host bind secrets live beneath a protected0700
// directory; the API receives only this UID65532-owned0400 volume, never0444 keys.
import { chmodSync, chownSync, lstatSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

process.umask(0o077);
const directory = '/keys';
mkdirSync(directory, { recursive: true, mode: 0o700 });
if (!lstatSync(directory).isDirectory() || lstatSync(directory).isSymbolicLink()) throw new Error('Private key destination must be a directory');
chmodSync(directory, 0o700);
for (const name of ['evidence_keyring', 'admin_mfa_key']) {
  const source = '/run/secrets/' + name;
  const info = lstatSync(source);
  if (!info.isFile() || info.size > 16384) throw new Error('Invalid private key input');
  const data = readFileSync(source);
  const temporary = join(directory, name + '.pending');
  writeFileSync(temporary, data, { flag: 'w', mode: 0o400 });
  chmodSync(temporary, 0o400); chownSync(temporary, 65532, 65532);
  renameSync(temporary, join(directory, name));
}
chownSync(directory, 65532, 65532);
console.log('Private application keys prepared. No key values were printed.');
