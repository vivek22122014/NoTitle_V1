// Offline evidence checks. Browser traffic proves end-to-end behavior; only
// separately measured server observations can establish server processing SLOs.
export const SCHEMA = 'notitle-capacity-v1';
export const IMAGE_KEYS = ['api', 'web', 'migrate', 'postgres', 'turn'];
const digest = /^[a-f0-9]{64}$/;
const image = /^[a-z0-9][a-z0-9._:/-]*@sha256:[a-f0-9]{64}$/;
const finite = (n) => typeof n === 'number' && Number.isFinite(n) && n >= 0;
export function percentile(values, p = 0.95) {
  if (!values.length || values.some((v) => !finite(v))) return null;
  return [...values].sort((a, b) => a - b)[Math.max(0, Math.ceil(values.length * p) - 1)];
}
export function validatePermit(p, now = Date.now()) {
  const fail = (message) => { throw new Error(message); };
  if (!p || p.schema_version !== 'notitle-load-permit-v1') fail('Load permit schema is required');
  let u; try { u = new URL(p.origin); } catch { fail('Invalid permitted origin'); }
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(u.hostname);
  if (u.origin !== p.origin || u.pathname !== '/' || u.search || u.hash || u.username || u.password || (!local && (u.protocol !== 'https:' || !/^(staging|load)\./.test(u.hostname)))) fail('Only exact loopback or explicitly named HTTPS staging/load origins are allowed');
  if (!['http:', 'https:'].includes(u.protocol)) fail('Invalid origin protocol');
  if (p.isolated_target !== true || p.no_real_users !== true || p.synthetic_accounts_only !== true || p.no_live_money !== true || typeof p.approved_by !== 'string' || p.approved_by.trim().length < 3) fail('An isolated, synthetic, no-live-money target approval is required');
  const until = Date.parse(p.expires_at), from = Date.parse(p.not_before);
  if (!Number.isFinite(until) || !Number.isFinite(from) || from > now || until <= now || until - from > 48 * 3600000) fail('Permit must be current and at most 48 hours long');
  if (p.maximum_seconds !== 21600 || p.maximum_offered !== 400 || p.maximum_connected !== 200 || p.maximum_calls !== 25) fail('Permit must preserve the fixed six-hour/400-offered/200-connected/25-call budget');
  if (!digest.test(p.source_sha256) || !IMAGE_KEYS.every((key) => image.test(p.image_digests?.[key]))) fail('Exact release source and all five immutable image digests are required');
  if (!Array.isArray(p.relay_hosts) || !p.relay_hosts.length || p.relay_hosts.length > 4 || p.relay_hosts.some((h) => typeof h !== 'string' || !/^[a-z0-9.-]+$/.test(h))) fail('Approved relay hosts are required');
  return p;
}
function common(report, failures) {
  if (!report || report.schema_version !== SCHEMA) failures.push('schema');
  if (!digest.test(report?.source_sha256) || !digest.test(report?.permit_sha256) || !IMAGE_KEYS.every((key) => image.test(report?.image_digests?.[key]))) failures.push('release_binding');
  try { const u = new URL(report.origin); if (u.origin !== report.origin) throw new Error(); } catch { failures.push('origin'); }
  for (const key of ['started_at', 'ended_at']) { try { if (new Date(report?.[key]).toISOString() !== report[key]) failures.push('measurement_timestamps'); } catch { failures.push('measurement_timestamps'); } }
  if (!(Date.parse(report?.ended_at) >= Date.parse(report?.started_at))) failures.push('measurement_order');
  if (!digest.test(report?.baseline_sha256) || !Number.isFinite(Date.parse(report?.baseline_started_at)) || Date.parse(report.baseline_started_at) > Date.parse(report.started_at) || Date.parse(report.started_at) - Date.parse(report.baseline_started_at) > 60000) failures.push('measurement_baseline');
  if (report?.termination !== 'completed') failures.push('incomplete_run');
  if (!Array.isArray(report?.failures) || report.failures.length) failures.push('run_failures');
}
export function validateCapacityReport(report) {
  const failures = []; common(report, failures);
  if (!['A', 'B'].includes(report?.scenario)) failures.push('scenario');
  if (report?.media !== 'chromium-synthetic-pcm-over-real-turn') failures.push('real_media');
  const duration = (Date.parse(report?.ended_at) - Date.parse(report?.started_at)) / 1000;
  if (!finite(duration) || duration < 21600 || duration > 21720 || Math.abs(duration - report?.duration_seconds) > 1) failures.push('six_hour_duration');
  const samples = report?.samples;
  if (!Array.isArray(samples) || samples.length < 720 || samples.length > 1500) return { passed: false, failures: [...failures, 'sample_coverage'] };
  let previous = Date.parse(report.started_at), full = 0, previousMessages = null;
  const count = (n) => Number.isSafeInteger(n) && n >= 0;
  for (const s of samples) {
    const at = Date.parse(s?.at);
    if (!Number.isFinite(at) || at < previous || at - previous > 45000 || at > Date.parse(report.ended_at)) failures.push('sample_gap');
    const interval = (at - previous) / 1000; previous = at;
    const messages = s.messages;
    if (!messages || !['offered', 'accepted', 'received', 'delivered', 'errors'].every((key) => Number.isSafeInteger(messages[key]) && messages[key] >= 0) || messages.errors !== 0) failures.push('message_evidence');
    if (previousMessages && interval >= 10) {
      const expectedRate = report.scenario === 'A' ? 20 : 40;
      for (const key of ['offered', 'accepted', 'received', 'delivered']) if (!messages || messages[key] - previousMessages[key] < interval * expectedRate * .75) failures.push('message_progress');
    }
    previousMessages = messages;
    if (messages && (messages.accepted > messages.offered || messages.received > messages.offered || messages.delivered > messages.offered)) failures.push('message_accounting');
    if (!['connected', 'waiting', 'text_participants', 'audio_participants', 'calls', 'rtp_senders', 'rtp_receivers', 'relay_endpoints', 'nonrelay_endpoints'].every((key) => count(s[key]))) failures.push('invalid_sample_counts');
    const expectedWaiting = report.scenario === 'A' ? 100 : 0;
    const expectedText = report.scenario === 'A' ? 50 : 150;
    if (s.connected === 200 && s.waiting === expectedWaiting && s.text_participants === expectedText && s.audio_participants === 50 && s.calls === 25 && s.rtp_senders === 50 && s.rtp_receivers === 50 && s.relay_endpoints === 50) full++;
    if (s.connected > 200 || s.waiting > 100 || s.calls > 25 || s.nonrelay_endpoints > 0) failures.push('admission_or_relay_violation');
    if (s.server_observation_fresh !== true || s.server_baseline_sha256 !== report.baseline_sha256 || s.server_window_started_at !== report.baseline_started_at || !Number.isFinite(Date.parse(s.server_observed_at)) || Math.abs(at - Date.parse(s.server_observed_at)) > 45000) failures.push('missing_server_observation');
    const h = s.host;
    if (!h || !finite(h.total_bytes) || h.total_bytes === 0 || !finite(h.available_bytes) || h.available_bytes < h.total_bytes * .25 || h.available_bytes < 1073741824 || !finite(h.go_heap_bytes) || !finite(h.goroutines)) failures.push('memory_headroom');
    for (const [key, limit, scope] of [['api', 300, 'ordinary_api_server'], ['message', 100, 'message_owner_processing'], ['match', 1000, 'available_candidate_to_commit_upper_bound']]) {
      const metric = s.server?.[key];
      if (!metric || metric.scope !== scope || !Number.isSafeInteger(metric.samples) || metric.samples < 0 || (metric.samples === 0 ? metric.p95_ms !== null : !finite(metric.p95_ms) || metric.p95_ms >= limit)) failures.push(`server_${key}_p95`);
    }
    const q = s.queues;
    if (!q || q.bounded !== true || !finite(q.ungranted_captures) || !finite(q.overdue_jobs) || !finite(q.goroutines_limit) || h?.goroutines > q.goroutines_limit) failures.push('bounded_queues');
  }
  if (Date.parse(report.ended_at) - previous > 45000 || full !== samples.length) failures.push('sustained_200_connected_25_calls');
  const quarter = Math.max(1, Math.floor(samples.length / 4));
  const mean = (items, key) => items.reduce((sum, s) => sum + (s.host?.[key] ?? Infinity), 0) / items.length;
  for (const key of ['go_heap_bytes', 'goroutines']) if (mean(samples.slice(-quarter), key) > mean(samples.slice(0, quarter), key) * 1.1) failures.push(`growing_${key}`);
  const firstMessage = samples[0].messages, lastMessage = samples.at(-1).messages;
  if (!firstMessage || !lastMessage) failures.push('message_evidence');
  else {
    const expected = duration * (report.scenario === 'A' ? 20 : 40);
    if (lastMessage.offered - firstMessage.offered < expected * .98) failures.push('message_offered_rate');
    for (const key of ['accepted', 'received', 'delivered']) if (lastMessage[key] - firstMessage[key] !== lastMessage.offered - firstMessage.offered) failures.push('message_delivery');
  }
  for (const key of ['api', 'message', 'match']) {
    const startCount = samples[0].server?.[key]?.samples, endCount = samples.at(-1).server?.[key]?.samples;
    if (!Number.isSafeInteger(startCount) || !Number.isSafeInteger(endCount) || endCount <= startCount) failures.push('server_samples_no_progress');
  }
  const first = samples[0].queues, last = samples.at(-1).queues;
  if (!first || !last || last.ungranted_captures > first.ungranted_captures || last.overdue_jobs > first.overdue_jobs) failures.push('growing_payment_backlog');
  const c = report.call_setup;
  if (!c || !count(c.attempts) || !count(c.successes) || c.attempts < 25 || c.successes > c.attempts || c.successes / c.attempts < .95 || !finite(c.p95_ms) || c.p95_ms >= 10000) failures.push('call_setup');
  for (const key of ['next', 'reconnect', 'slow_reader', 'login_hash', 'guest_friend_accept', 'payment_job', 'backup', 'moderation', 'safety_event']) if (!Number.isSafeInteger(report.workload?.[key]) || report.workload[key] < 1) failures.push(`workload_${key}`);
  return { passed: failures.length === 0, failures: [...new Set(failures)] };
}
export function validateOverloadReport(report) {
  const failures = []; common(report, failures);
  if (report?.media !== 'chromium-synthetic-pcm-over-real-turn') failures.push('real_media');
  if (report?.scenario !== 'overload' || report.offered !== 400 || report.baseline_connected !== 200 || report.refused_connections !== 200) failures.push('400_offered');
  for (const key of ['participant_201_rejected', 'waiter_101_rejected', 'call_26_rejected', 'established_sessions_preserved', 'safety_events_preserved']) if (report?.[key] !== true) failures.push(key);
  if (!finite(report?.normal_cleanup_ms) || report.normal_cleanup_ms > 5000 || !finite(report?.orphan_cleanup_ms) || report.orphan_cleanup_ms > 30000 || report.cleanup_observation_verified !== true) failures.push('relay_cleanup');
  return { passed: !failures.length, failures: [...new Set(failures)] };
}
