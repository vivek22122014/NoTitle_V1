#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/lib.sh"
require_docker
docker_source "$GO_IMAGE" server sh -eu -c '
  echo "Formatting Go source with Go1.27.2; review any paths listed below."
  gofmt -l .
  gofmt -w .
  if test -f go.sum; then
    test -s go.sum || { echo "Existing go.sum is empty; refusing to pretend it is a lock." >&2; exit 1; }
    go mod download
    go mod verify
    go mod tidy -diff
  else
    go mod tidy
    test -s go.sum
    go mod verify
    echo "Generated genuine server/go.sum and updated go.mod; review and commit both."
  fi
'
