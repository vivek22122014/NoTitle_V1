// Real Caddy + Go + PostgreSQL identity lifecycle gate. Never run against a
// retained production database: smoke-stack.sh provisions a disposable stack.
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';

const base = process.env.SMOKE_BASE_URL ?? 'http://web:8080';
const origin = process.env.SMOKE_PUBLIC_ORIGIN ?? 'http://localhost:8080';
const jar = new Map();
let csrf = '';
async function call(path, method = 'GET', body, status = 200, overrides = {}) {
  const headers = { Cookie: [...jar].map(([key,value]) => `${key}=${value}`).join('; ') };
  if (method !== 'GET') Object.assign(headers, { Origin: origin, 'Content-Type': 'application/json', 'X-CSRF-Token': csrf });
  Object.assign(headers, overrides);
  const response = await fetch(base + '/api/v1' + path, {
    method, headers, body: body === undefined ? undefined : JSON.stringify(body),
    redirect: 'manual', signal: AbortSignal.timeout(15000)
  });
  // Never print body/cookies/recovery codes when a check fails.
  assert.equal(response.status, status, `${method} ${path}: unexpected HTTP status`);
  assert.match(response.headers.get('cache-control') ?? '', /no-store/);
  for (const cookie of response.headers.getSetCookie()) {
    assert.match(cookie, /HttpOnly/i); assert.match(cookie, /SameSite=Lax/i);
    assert.match(cookie, /Path=\//i); assert.ok(!/Domain=/i.test(cookie));
    const pair = cookie.split(';', 1)[0]; const split = pair.indexOf('=');
    const name = pair.slice(0, split); const value = pair.slice(split + 1);
    if (/Max-Age=0/i.test(cookie) || value === '') jar.delete(name); else jar.set(name, value);
  }
  const value = await response.json();
  if (value.csrf_token) csrf = value.csrf_token;
  return value;
}
function cookieHeader() { return [...jar].map(([key,value]) => `${key}=${value}`).join('; '); }
function privateProjection(owner) {
  assert.ok(!('id' in owner) && !('account_id' in owner) && !('session_id' in owner));
  assert.ok(!('password_hash' in owner) && !('recovery_hash' in owner));
}
const bootstrap = await call('/auth/bootstrap');
const consent = { adult_confirmed: true, policies: bootstrap.policies };
const profile = { gender: 'other', display_name: '', bio: '', topic: 'general_talk', professional: {profession:'',industry:'',experience:''} };
await call('/guest/session', 'POST', {profile,consent}, 403, {Origin:'https://untrusted.invalid'});
await call('/guest/session', 'POST', {profile,consent}, 403, {'X-CSRF-Token':'wrong'});
await call('/guest/session', 'POST', {profile:{...profile,gender:''},consent}, 400);
const guest = await call('/guest/session', 'POST', {profile,consent}, 201);
assert.equal(guest.identity.kind, 'guest'); privateProjection(guest.identity);
const guestCookie = cookieHeader();
const username = 'qa_' + randomUUID().replaceAll('-', '').slice(0,16);
const password = 'Initial test password 7864';
const registered = await call('/auth/register', 'POST', {username,password,profile:{...profile,display_name:'QA Colleague'},consent}, 201);
assert.equal(registered.identity.kind, 'account'); privateProjection(registered.identity);
assert.equal(registered.identity.profile.gender, 'other');
assert.equal(typeof registered.recovery_code, 'string');
assert.notEqual(cookieHeader(), guestCookie, 'guest cookie must rotate');
await call('/me', 'GET', undefined, 401, {Cookie:guestCookie});
const beforeRecoveryCookie = cookieHeader();
const initialVersion = registered.identity.profile.version;
const changed = await call('/me/profile', 'PATCH', {version:initialVersion,bio:'Testing versioned profiles'});
assert.equal(changed.profile.gender, 'other'); assert.equal(changed.profile.version, initialVersion+1);
await call('/me/profile', 'PATCH', {version:initialVersion,bio:'Stale edit'}, 409);
await call('/me/profile', 'PATCH', {version:changed.profile.version,gender:''}, 400);
const newPassword = 'Replacement test password 9087';
const recovered = await call('/auth/recover', 'POST', {username,recovery_code:registered.recovery_code,new_password:newPassword});
assert.notEqual(recovered.recovery_code, registered.recovery_code, 'recovery must rotate');
await call('/me', 'GET', undefined, 401, {Cookie:beforeRecoveryCookie});
await call('/auth/recover', 'POST', {username,recovery_code:registered.recovery_code,new_password:newPassword}, 401);
const beforeLogoutCookie = cookieHeader();
await call('/auth/logout-all', 'POST', {});
await call('/me', 'GET', undefined, 401, {Cookie:beforeLogoutCookie});
await call('/auth/bootstrap');
await call('/auth/login', 'POST', {username,password:newPassword});
await call('/auth/reauthenticate', 'POST', {password:newPassword});
const beforeDeleteCookie = cookieHeader();
const deletion = await call('/me', 'DELETE', {confirm:true}, 202);
assert.equal(deletion.access_disabled, true);
assert.equal(deletion.tombstone_durable, true, 'healthy dedicated journal must acknowledge durability');
assert.equal(deletion.state, 'awaiting_retention_review');
await call('/me', 'GET', undefined, 401, {Cookie:beforeDeleteCookie});
await call('/auth/bootstrap');
const status = await call('/account/deletion/status', 'POST', {receipt:deletion.receipt});
assert.equal(status.access_disabled, true); assert.equal(status.tombstone_durable, true);
assert.ok(!('receipt' in status));
console.log('Real identity lifecycle: consent, guest handoff, profile conflicts, recovery replay, logout-all, deletion durability and revoked sessions passed.');
