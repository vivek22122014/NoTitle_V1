#!/usr/bin/env node
// Isolated staging runner. Never run this against production or real people.
import fs from 'node:fs/promises';
import { constants } from 'node:fs';
import { createHash, randomUUID } from 'node:crypto';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { performance } from 'node:perf_hooks';
import { SCHEMA, validatePermit, validateCapacityReport, validateOverloadReport, percentile } from './load-contract.mjs';
import { strictJSON } from './launch-evidence-lib.mjs';
import { Participant, pair, call } from './load-browser.mjs';
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
export async function readProtectedJSON(path, maximum = 1024 * 1024) {
  const file = await fs.open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const stat = await file.stat();
    if (!stat.isFile() || stat.size > maximum || (stat.mode & 0o077) || (process.geteuid && stat.uid !== process.geteuid())) throw new Error('Input must be a bounded owner-only regular file');
    const buffer = Buffer.alloc(maximum + 1); let size = 0;
    while (size < buffer.length) { const { bytesRead } = await file.read(buffer, size, buffer.length - size, size); if (!bytesRead) break; size += bytesRead; }
    if (size > maximum) throw new Error('Input grew beyond its bound');
    const bytes = buffer.subarray(0, size);
    return { value: strictJSON(new TextDecoder('utf-8', { fatal: true }).decode(bytes)), sha256: hash(bytes) };
  } finally { await file.close(); }
}
async function deadline(promise, milliseconds = 15000) {
  let timer; try { return await Promise.race([promise, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('Bounded browser operation expired')), milliseconds); })]); } finally { clearTimeout(timer); }
}
async function bounded(items, fn, concurrency = 8) {
  let next = 0; const results = new Array(items.length);
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, async () => { for (;;) { const i = next++; if (i >= items.length) break; results[i] = await deadline(Promise.resolve().then(() => fn(items[i], i))); } })); return results;
}
export function projectObservation(input, binding, at = Date.now()) {
  const fresh = input?.schema_version === 'notitle-load-observation-v1' && input.origin === binding.origin && input.source_sha256 === binding.source_sha256 && input.run_id === binding.run_id && input.baseline_sha256 === binding.baseline_sha256 && input.window_started_at === binding.baseline_started_at && Math.abs(at - Date.parse(input.observed_at)) <= 45000 && Date.parse(input.window_started_at) <= Date.parse(binding.started_at) && Date.parse(input.window_started_at) >= Date.parse(binding.started_at) - 60000;
  // Explicit fixed fields only: operator notes and private dashboard data never
  // accidentally enter the shareable capacity report.
  const projectMetric = (m) => ({ scope: m?.scope ?? '', samples: m?.samples ?? 0, p95_ms: m?.p95_ms ?? null });
  return {
    server_observation_fresh: fresh,
    server_baseline_sha256: input?.baseline_sha256 ?? '',
    server_window_started_at: input?.window_started_at ?? '',
    server_observed_at: input?.observed_at ?? '',
    host: Object.fromEntries(['total_bytes', 'available_bytes', 'go_heap_bytes', 'goroutines'].map((k) => [k, input?.host?.[k] ?? null])),
    server: Object.fromEntries(['api', 'message', 'match'].map((k) => [k, projectMetric(input?.server?.[k])])),
    queues: Object.fromEntries(['bounded', 'ungranted_captures', 'overdue_jobs', 'goroutines_limit'].map((k) => [k, input?.queues?.[k] ?? null]))
  };
}
export function workloadProgress(baseline, input, binding, now = Date.now()) {
  const keys = ['payment_job', 'backup', 'moderation', 'safety_event'];
  const observed = Date.parse(input?.observed_at);
  const valid = input?.schema_version === 'notitle-load-observation-v1' && input.origin === binding.origin && input.source_sha256 === binding.source_sha256 && input.run_id === binding.run_id && input.baseline_sha256 === binding.baseline_sha256 && input.window_started_at === binding.baseline_started_at && Number.isFinite(observed) && observed >= Date.parse(binding.started_at) && Math.abs(now - observed) <= 45000 && keys.every((key) => Number.isSafeInteger(input.workload?.[key]) && input.workload[key] >= 0);
  if (!valid) return { baseline, counts: {} };
  if (!baseline) return { baseline: { observed_at: input.observed_at, counts: Object.fromEntries(keys.map((key) => [key, input.workload[key]])) }, counts: {} };
  if (observed <= Date.parse(baseline.observed_at) || keys.some((key) => input.workload[key] < baseline.counts[key])) return { baseline, counts: {} };
  return { baseline, counts: Object.fromEntries(keys.map((key) => [key, input.workload[key] - baseline.counts[key]])) };
}
export async function run({ permitPath, fixturePath, observationPath, outputPath, scenario, seconds = 21600 }) {
  if (!['A', 'B', 'overload'].includes(scenario) || !Number.isInteger(seconds) || seconds < 60 || seconds > 21600) throw new Error('Use scenario A, B or overload and 60..21600 seconds');
  const loaded = await readProtectedJSON(permitPath), permit = validatePermit(loaded.value);
  if (Date.parse(permit.expires_at) < Date.now() + (seconds + 900) * 1000) throw new Error('Permit must cover setup and the entire bounded run');
  const fixtures = (await readProtectedJSON(fixturePath)).value;
  if (fixtures.origin !== permit.origin || !Array.isArray(fixtures.waiting_accounts) || ((scenario === 'A' || scenario === 'overload') && fixtures.waiting_accounts.length < 101) || !fixtures.hash_account) throw new Error('Origin-bound synthetic fixtures are incomplete');
  const report = { schema_version: SCHEMA, run_id: randomUUID(), scenario, origin: permit.origin, source_sha256: permit.source_sha256, image_digests: permit.image_digests, permit_sha256: loaded.sha256, media: 'chromium-synthetic-pcm-over-real-turn', termination: 'blocked', started_at: null, ended_at: null, duration_seconds: 0, samples: [], failures: [], call_setup: { attempts: 0, successes: 0, p95_ms: null }, workload: Object.fromEntries(['next', 'reconnect', 'slow_reader', 'login_hash', 'guest_friend_accept', 'payment_job', 'backup', 'moderation', 'safety_event'].map((k) => [k, 0])) };
  const output = await fs.open(outputPath, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 0o600);
  const save = async () => { const bytes = Buffer.from(JSON.stringify(report, null, 2) + '\n'); await output.truncate(0); let offset = 0; while (offset < bytes.length) { const { bytesWritten } = await output.write(bytes, offset, bytes.length - offset, offset); offset += bytesWritten; } await output.sync(); };
  await save();
  const participants = [], browsers = []; let stopped = false, traffic, watchdog, sending = false, sampling = false;
  const stop = () => { stopped = true; for (const browser of browsers) void browser.close({ reason: 'Load permit ended or interrupted' }).catch(() => {}); }; process.once('SIGINT', stop); process.once('SIGTERM', stop);
  // Browser generators are separate from the application/relay machines.
  try {
    const require = createRequire(new URL('../web/package.json', import.meta.url));
    const { chromium } = require('@playwright/test');
    watchdog = setTimeout(stop, (seconds + 900) * 1000);
    for (let n = 0; n < 4; n++) browsers.push(await chromium.launch({ headless: true, args: ['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream', '--autoplay-policy=no-user-gesture-required', '--disable-background-timer-throttling', '--disable-renderer-backgrounding', '--mute-audio'] }));
    const add = async (fixture, waiting = false) => {
      if (stopped || Date.now() >= Date.parse(permit.expires_at) || participants.length >= 400) throw new Error('Load budget exhausted');
      const p = await Participant.create(browsers[participants.length % browsers.length], permit, fixture, { waiting, httpCredentials: fixtures.http_credentials }); participants.push(p); return p;
    };
    const pairs = [];
    const targetPairs = scenario === 'B' ? 100 : 50;
    for (let n = 0; n < targetPairs; n++) {
      const a = await add(), b = await add(); await pair(a, b); pairs.push([a, b]);
      await delay(250);
    }
    if (scenario !== 'B') for (let n = 0; n < 100; n++) { const p = await add(fixtures.waiting_accounts[n], true); await p.search(); await p.wait('WAITING'); await delay(2200); }
    // Measure initial call setup with all 200 participants already admitted.
    for (const [a, b] of pairs.slice(0, 25)) { report.call_setup.attempts++; await call(a, b); report.call_setup.successes++; }
    const baseline = [...participants], textPair = pairs[25];
    await bounded(baseline, (p) => p.sample()); await delay(1000);
    const observation = async () => { try { return (await readProtectedJSON(observationPath)).value; } catch { return null; } };
    // Stop before the timed window until the operator collector captures a new
    // snapshot after this ready marker. Ramp-up/history can never set p95.
    report.baseline_requested_at = new Date().toISOString(); await save();
    const baselineUntil = Date.now() + 60000; let initialObservation = null;
    while (!stopped && Date.now() < baselineUntil) {
      const candidate = await observation();
      if (candidate?.schema_version === 'notitle-load-observation-v1' && candidate.origin === permit.origin && candidate.source_sha256 === permit.source_sha256 && candidate.run_id === report.run_id && /^[a-f0-9]{64}$/.test(candidate.baseline_sha256 ?? '') && Date.parse(candidate.window_started_at) >= Date.parse(report.baseline_requested_at) && Date.parse(candidate.window_started_at) <= Date.now() && Math.abs(Date.now() - Date.parse(candidate.observed_at)) <= 30000) { initialObservation = candidate; break; }
      await delay(250);
    }
    if (!initialObservation || stopped) throw new Error('Fresh run-bound baseline was not captured in time');
    report.baseline_sha256 = initialObservation.baseline_sha256; report.baseline_started_at = initialObservation.window_started_at;
    report.started_at = new Date().toISOString(); await save(); const monotonicStart = performance.now();
    // Both affirmative guest actions occur inside the measured window.
    await textPair[0].page.getByRole('button', { name: 'Stay Connected', exact: true }).click();
    await textPair[1].page.getByRole('button', { name: 'Accept connection', exact: true }).click();
    report.workload.guest_friend_accept++;
    let workloadBaseline = null;
    traffic = setInterval(async () => { if (sending || stopped) return; sending = true; try { while (sampling && !stopped) await delay(25); if (stopped) return; await bounded(baseline, (p) => p.churning ? false : p.text(), 16); } catch { report.failures.push('traffic_driver_failure'); stopped = true; } finally { sending = false; } }, 5000);
    const sample = async () => {
      while (sending && !stopped) await delay(25); sampling = true;
      try {
      const views = await bounded(baseline, (p) => p.sample()); const external = await observation();
      const sum = (key) => views.reduce((n, v) => n + Number(v[key]), 0);
      const audio = sum('active');
      report.samples.push({ at: new Date().toISOString(), connected: sum('connected'), waiting: views.filter((v) => v.state === 'WAITING').length, text_participants: views.filter((v) => v.state === 'MATCHED' && !v.active).length, audio_participants: audio, calls: audio / 2, rtp_senders: sum('senders'), rtp_receivers: sum('receivers'), relay_endpoints: sum('relay'), nonrelay_endpoints: sum('nonrelay'), messages: { offered: sum('sent'), accepted: sum('accepted'), received: sum('received'), delivered: sum('delivered'), errors: sum('errorCount') }, ...projectObservation(external, report) });
      const workload = workloadProgress(workloadBaseline, external, report);
      workloadBaseline = workload.baseline; Object.assign(report.workload, workload.counts);
      if (workloadBaseline) report.workload_baseline_at = workloadBaseline.observed_at;
      const setup = views.slice(0, 50).flatMap((v) => v.setup); report.call_setup.p95_ms = percentile(setup);
      if (scenario !== 'overload' && sum('errorCount')) { stopped = true; report.failures.push('unexpected_protocol_error'); }
      if (sum('nonrelay')) { stopped = true; report.failures.push('direct_media_detected'); }
      return views;
      } finally { sampling = false; }
    };
    if (scenario === 'overload') {
      const before = await sample(); report.baseline_connected = before.filter((v) => v.connected).length;
      const extras = [];
      for (let n = 0; n < 200; n++) { extras.push(await add(n === 0 ? fixtures.waiting_accounts[100] : undefined, n === 0)); await delay(250); }
      // All 200 extra client attempts are issued together, at most 400 offered.
      await Promise.all(extras.map((p) => p.search()));
      await bounded(extras, (p) => p.page.waitForFunction(() => window.__notitleLoad.state().errors.includes('CAPACITY_REACHED')));
      report.offered = 400; report.refused_connections = (await bounded(extras, (p) => p.page.evaluate(() => window.__notitleLoad.state()))).filter((s) => !s.connected && s.errors.includes('CAPACITY_REACHED')).length;
      report.participant_201_rejected = report.refused_connections === 200;
      await bounded(extras.slice(1), (p) => p.close());
      await bounded(pairs.flat(), async (p) => {
        const before = await p.page.evaluate(() => window.__notitleLoad.state().delivered);
        if (!await p.text()) throw new Error('Established text participant lost');
        await p.page.waitForFunction((old) => window.__notitleLoad.state().delivered > old, before);
      });
      const intact = await sample();
      const beforeReleaseIntact = intact.every((s, i) => s.connected && (i < 100 ? s.state === 'MATCHED' : s.state === 'WAITING')) && intact.slice(0, 50).every((s) => s.active === 1 && s.senders === 1 && s.receivers === 1 && s.relay === 1);
      // The 26th call comes from an already admitted text pair.
      await textPair[0].page.evaluate(() => window.__notitleLoad.clearErrors());
      await textPair[0].page.getByRole('button', { name: 'Call partner', exact: true }).click();
      await textPair[0].page.waitForFunction(() => window.__notitleLoad.state().errors.includes('CAPACITY_REACHED'));
      report.call_26_rejected = (await textPair[0].sample()).active === 0;
      // Free one admitted text participant, then offer an incompatible 101st
      // waiter. The baseline already has 100 strict female-seeking male users.
      textPair.forEach((p) => { p.churning = true; });
      await textPair[0].page.getByRole('button', { name: 'End match', exact: true }).click();
      await Promise.all(textPair.map((p) => p.wait('IDLE')));
      await textPair[0].close(); await delay(500);
      const replacement = extras[0];
      await replacement.page.getByRole('button', { name: 'Retry connection', exact: true }).click();
      await replacement.page.waitForFunction(() => window.__notitleLoad.state().connected);
      await replacement.page.evaluate(() => window.__notitleLoad.clearErrors());
      await replacement.search();
      await replacement.page.waitForFunction(() => window.__notitleLoad.state().errors.includes('CAPACITY_REACHED'));
      const replacementState = await replacement.page.evaluate(() => window.__notitleLoad.state());
      report.waiter_101_rejected = replacementState.connected && replacementState.state === 'IDLE' && replacementState.errors.includes('CAPACITY_REACHED');
      const preserved = await bounded(pairs.slice(0, 25).flat(), (p) => p.sample());
      const remainingText = await bounded(pairs.slice(26).flat(), (p) => p.sample());
      report.established_sessions_preserved = beforeReleaseIntact && remainingText.every((s) => s.connected && s.state === 'MATCHED') && preserved.every((s) => s.connected && s.state === 'MATCHED' && s.active === 1 && s.senders === 1 && s.receivers === 1 && s.relay === 1);
      const external = await observation();
      report.safety_events_preserved = external?.overload?.safety_events_preserved === true && Date.parse(external.observed_at) >= Date.parse(report.started_at);
      // Real cleanup/crash drills run under the separate operator runbook;
      // synthetic browser closure never invents relay cleanup measurements.
      report.normal_cleanup_ms = external?.overload?.normal_cleanup_ms ?? null;
      report.orphan_cleanup_ms = external?.overload?.orphan_cleanup_ms ?? null;
      report.cleanup_observation_verified = external?.overload?.cleanup_observation_verified === true && external.origin === report.origin && external.source_sha256 === report.source_sha256;
    } else {
      let nextSample = 0, nextChurn = 300000;
      while (!stopped && performance.now() - monotonicStart < seconds * 1000) {
        const elapsed = performance.now() - monotonicStart;
        if (elapsed >= nextSample) { await sample(); nextSample += 30000; }
        if (elapsed >= nextChurn) {
          textPair.forEach((p) => { p.churning = true; });
          await bounded(textPair, (p) => p.page.waitForFunction(() => { const s = window.__notitleLoad.state(); return s.sent === s.accepted && s.sent === s.delivered; }));
          const temporaryWaiters = scenario === 'A' ? baseline.slice(100, 102) : [];
          for (const p of temporaryWaiters) { await p.page.getByRole('button', { name: 'Cancel search', exact: true }).click(); await p.wait('IDLE'); }
          for (let n = 0; n < 3; n++) { await textPair[0].page.getByRole('button', { name: 'Next match', exact: true }).click(); await textPair[1].wait('IDLE'); await delay(4100); await textPair[1].search(); await Promise.all(textPair.map((p) => p.wait('MATCHED'))); report.workload.next++; }
          for (const p of temporaryWaiters) { await p.search(); await p.wait('WAITING'); }
          await textPair[0].page.evaluate(() => window.__notitleLoad.disconnect());
          await textPair[0].page.waitForFunction(() => window.__notitleLoad.state().connected); report.workload.reconnect++;
          // Actual renderer pause exercises delayed application reads without
          // forging WebSocket frames or WebRTC statistics.
          const cdp = await textPair[1].context.newCDPSession(textPair[1].page); await cdp.send('Debugger.enable'); await cdp.send('Debugger.pause'); await textPair[0].text(); await delay(2000); await cdp.send('Debugger.resume'); await cdp.detach(); report.workload.slow_reader++;
          await Promise.all([0, 1].map(async () => {
            const hashContext = await browsers[0].newContext({ baseURL: permit.origin, httpCredentials: fixtures.http_credentials });
            try { const b = await hashContext.request.get('/api/v1/auth/bootstrap', { maxRedirects: 0, timeout: 15000 }); const data = await b.json(); const login = await hashContext.request.post('/api/v1/auth/login', { maxRedirects: 0, timeout: 15000, headers: { Origin: permit.origin, 'X-CSRF-Token': data.csrf_token }, data: fixtures.hash_account }); if (!login.ok()) throw new Error(); report.workload.login_hash++; } finally { await hashContext.close(); }
          }));
          textPair.forEach((p) => { p.churning = false; });
          nextChurn += 300000;
        }
        await delay(Math.min(250, Math.max(0, seconds * 1000 - (performance.now() - monotonicStart))));
      }
      if (!stopped) {
        clearInterval(traffic); while (sending && !stopped) await delay(25);
        await bounded(baseline, (p) => p.page.waitForFunction(() => { const s = window.__notitleLoad.state(); return s.sent === s.accepted && s.sent === s.delivered; }, undefined, { timeout: 10000 }));
        await sample();
      }
    }
    report.termination = stopped ? 'interrupted' : 'completed';
    report.ended_at = new Date().toISOString();
  } catch {
    // Never print browser assertions, request bodies or authentication data.
    report.failures.push('runner_or_fixture_failure');
  } finally {
    if (!report.ended_at) report.ended_at = new Date().toISOString();
    clearInterval(traffic); clearTimeout(watchdog); stopped = true;
    const drainUntil = Date.now() + 5000; while (sending && Date.now() < drainUntil) await delay(100);
    await bounded(participants, (p) => p.close().catch(() => {})).catch(() => { report.failures.push('browser_teardown_timeout'); });
    await deadline(Promise.all(browsers.map((b) => b.close().catch(() => {})))).catch(() => { report.failures.push('browser_teardown_timeout'); });
    process.off('SIGINT', stop); process.off('SIGTERM', stop);
    report.duration_seconds = report.started_at ? (Date.parse(report.ended_at) - Date.parse(report.started_at)) / 1000 : 0;
    const result = scenario === 'overload' ? validateOverloadReport(report) : validateCapacityReport(report); report.result = result;
    try { await save(); } finally { await output.close(); }
  }
  return report;
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const [permitPath, fixturePath, observationPath, outputPath, scenario, rawSeconds] = process.argv.slice(2);
  if (!scenario) { console.error('Usage: node scripts/load-soak.mjs PERMIT FIXTURES OBSERVATION NEW_REPORT A|B|overload [SECONDS]'); process.exitCode = 2; }
  else try { const report = await run({ permitPath, fixturePath, observationPath, outputPath, scenario, seconds: rawSeconds === undefined ? 21600 : Number(rawSeconds) }); console.log(JSON.stringify({ scenario, passed: report.result.passed, failures: report.result.failures })); process.exitCode = report.result.passed ? 0 : 1; } catch { console.error('Load preflight rejected; verify protected inputs, exact target binding and bounded permit.'); process.exitCode = 2; }
}
