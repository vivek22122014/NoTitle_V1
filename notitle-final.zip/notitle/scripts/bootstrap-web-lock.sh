#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/lib.sh"
require_docker
docker_source "$NODE_IMAGE" web sh -eu -c '
  if test -f package-lock.json; then
    test -s package-lock.json || { echo "Existing package-lock.json is empty." >&2; exit 1; }
    echo "Keeping existing package-lock.json; npm ci in the build will verify it."
  else
    npm install --package-lock-only --ignore-scripts --no-audit --no-fund
    test -s package-lock.json
    echo "Generated genuine web/package-lock.json; review and commit it."
  fi
  npm ci --no-audit --no-fund
  echo "Formatting frontend source; review all formatting and lock changes."
  npm run format
'
