#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/lib.sh"
mode=${1:-dev}
shift || true
case "$mode" in dev) overlay=fast.yml;; static) overlay=static.yml;; checks) overlay=checks.yml;; *) echo 'Compose mode must be dev, static, or checks' >&2; exit 2;; esac
test -f "$ROOT/deploy/dev/.env" || { echo 'Run ./scripts/bootstrap.sh prepare first.' >&2; exit 1; }
exec docker compose --project-name "${COMPOSE_PROJECT_NAME:-notitle-local}" \
  --env-file "$ROOT/deploy/dev/.env" -f "$ROOT/deploy/dev/compose.yml" \
  -f "$ROOT/deploy/dev/$overlay" "$@"
