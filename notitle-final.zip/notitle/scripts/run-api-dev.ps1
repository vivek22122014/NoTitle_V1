$ErrorActionPreference = "Stop"
Write-Error "Host API mode was removed because PostgreSQL is private. Use WSL2 with Docker Desktop and ./scripts/bootstrap.sh dev; then make api-restart."
exit 1
