#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/lib.sh"
require_docker
require_locks
command -v python3 >/dev/null || { echo 'Python 3.11+ is required for operations fixture checks.' >&2; exit 1; }
python3 "$ROOT/scripts/operations-archive-test.py"
python3 "$ROOT/scripts/operations-observe-test.py"
# Release audit must pass before any build or test can be called successful.
docker_source "$NODE_IMAGE" "" node scripts/audit.mjs --release
cd "$ROOT"
docker_source "$NODE_IMAGE" "" node --test deploy/tests/*.test.mjs scripts/tests/*.test.mjs
"$ROOT/scripts/db-check.sh"
docker build -f "$ROOT/deploy/test/Web.Dockerfile" -t notitle-web-check:local "$ROOT"
# Includes Chromium/Firefox/WebKit desktop fixtures and Android/iPhone emulation.
# These tests cannot replace physical browser, keyboard, media or payment evidence.
docker run --rm --init --shm-size=256m notitle-web-check:local
docker build -f "$ROOT/server/Dockerfile" -t notitle-api-check:local "$ROOT"
docker build -f "$ROOT/deploy/app/Caddy.Dockerfile" -t notitle-static-check:local "$ROOT"
"$ROOT/scripts/smoke-stack.sh"
echo 'Executed build, backend, database, migration, frontend/browser-fixture, dependency-security and static-stack checks. Physical devices, both real-media six-hour soaks, cloud restore/operator drills and authorized live settlement remain separate launch gates.'
