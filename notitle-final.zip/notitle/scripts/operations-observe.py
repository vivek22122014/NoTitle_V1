#!/usr/bin/env python3
"""Bounded Linux host sampling plus independently verified observation inputs.

No network request or synthetic recovery timestamp. Run every five seconds under
the dedicated collector user. First run stores baseline and does not claim a
complete sample. The application separately rejects stale/unproven evidence.
"""
import argparse
import datetime as dt
import importlib.util
import json
import math
import os
from pathlib import Path
import secrets
import stat
import subprocess
import sys
import time

sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location("archive_files", Path(__file__).with_name("operations-archive.py"))
files = importlib.util.module_from_spec(spec)
spec.loader.exec_module(files)

EVIDENCE_KEYS = {
    "clock_offset_ms", "recoverable_wal_at", "deletion_journal_recoverable_at",
    "hold_journal_recoverable_at", "external_probe_at", "external_probe_healthy",
    "relay_enabled", "relay_observed_at", "relay_ready", "relay_allocations",
    "relay_control_failures", "relay_packet_loss_percent", "transfer_projected_bytes",
    "transfer_allowance_bytes", "primary_drill_at", "backup_drill_at",
}
TIMES = {key for key in EVIDENCE_KEYS if key.endswith("_at")}
BOOLS = {"external_probe_healthy", "relay_enabled", "relay_ready"}


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate key")
        result[key] = value
    return result


def read_json(path, max_bytes=16384):
    fd = files.private_open(path)
    try:
        with os.fdopen(os.dup(fd), "rb") as stream:
            raw = stream.read(max_bytes + 1)
        if len(raw) > max_bytes:
            raise ValueError("record too large")
        value = json.loads(raw, object_pairs_hook=unique_object, parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite")))
        if not isinstance(value, dict):
            raise ValueError("object required")
        return value
    finally:
        os.close(fd)


def evidence(path, now):
    value = read_json(path)
    if set(value) != EVIDENCE_KEYS | {"evidence_observed_at"}:
        raise ValueError("evidence fields incomplete or unexpected")
    for key in TIMES | {"evidence_observed_at"}:
        text = value[key]
        if not isinstance(text, str) or not text.endswith("Z"):
            raise ValueError("UTC evidence timestamp required")
        parsed = dt.datetime.fromisoformat(text[:-1] + "+00:00")
        if parsed.timestamp() > now + 5:
            raise ValueError("future evidence")
        if key == "evidence_observed_at" and now - parsed.timestamp() > 120:
            raise ValueError("external evidence input stale")
    for key in EVIDENCE_KEYS - TIMES:
        val = value[key]
        if key in BOOLS:
            if type(val) is not bool:
                raise ValueError("boolean evidence required")
        elif key == "relay_packet_loss_percent":
            if type(val) not in (int, float) or not math.isfinite(val) or not 0 <= val <= 100:
                raise ValueError("invalid loss evidence")
        elif type(val) is not int or abs(val) > 2**53 - 1 or (key != "clock_offset_ms" and val < 0):
            raise ValueError("invalid numeric evidence")
    del value["evidence_observed_at"]
    return value


def atomic_json(path, value):
    target = Path(path)
    if not target.is_absolute() or target.name in ("", ".", ".."):
        raise ValueError("protected absolute output required")
    directory = files.private_open(target.parent, directory=True)
    temporary = ".sample-" + secrets.token_hex(16)
    created = False
    try:
        try:
            old = os.stat(target.name, dir_fd=directory, follow_symlinks=False)
            if not stat.S_ISREG(old.st_mode) or old.st_mode & 0o077 or old.st_uid != os.geteuid():
                raise ValueError("unsafe prior output")
        except FileNotFoundError:
            pass
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=directory)
        created = True
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, separators=(",", ":"), allow_nan=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.rename(temporary, target.name, src_dir_fd=directory, dst_dir_fd=directory)
        created = False
        os.fsync(directory)
    finally:
        if created:
            os.unlink(temporary, dir_fd=directory)
        os.close(directory)


def host_sample(disk_path):
    with open("/proc/stat", encoding="ascii") as stream:
        fields = stream.readline().split()
    if fields[0] != "cpu" or len(fields) < 9:
        raise ValueError("cpu counters unavailable")
    ticks = [int(x) for x in fields[1:9]]  # guest counters are already in user/nice.
    with open("/proc/meminfo", encoding="ascii") as stream:
        memory = {parts[0].rstrip(":"): int(parts[1]) for line in stream if (parts := line.split())}
    if memory.get("MemTotal", 0) <= 0 or not 0 <= memory.get("MemAvailable", -1) <= memory["MemTotal"]:
        raise ValueError("memory counters unavailable")
    disk = os.statvfs(disk_path)
    total = disk.f_blocks * disk.f_frsize
    available = disk.f_bavail * disk.f_frsize
    if total <= 0 or not 0 <= available <= total:
        raise ValueError("disk counters unavailable")
    with open("/proc/sys/kernel/random/boot_id", encoding="ascii") as stream:
        boot_id = stream.read(128).strip()
    if len(boot_id) != 36:
        raise ValueError("boot identity unavailable")
    return {"at": time.time(), "boot_id": boot_id, "total_ticks": sum(ticks), "idle_ticks": ticks[3] + ticks[4],
            "steal_ticks": ticks[7], "memory_percent": 100 * (1 - memory["MemAvailable"] / memory["MemTotal"]),
            "disk_total": total, "disk_used": total - available}


def calculate(current, prior):
    if not prior or prior.get("boot_id") != current["boot_id"]:
        return None
    elapsed = current["at"] - prior["at"]
    ticks = current["total_ticks"] - prior["total_ticks"]
    idle = current["idle_ticks"] - prior["idle_ticks"]
    steal = current["steal_ticks"] - prior["steal_ticks"]
    if not 1 <= elapsed <= 120 or ticks <= 0 or not 0 <= idle <= ticks or not 0 <= steal <= ticks:
        return None
    increase = current["disk_used"] - prior["disk_used"]
    remaining = current["disk_total"] - current["disk_used"]
    # 36500 is a bounded 'no positive growth observed this interval' sentinel,
    # not a promise of capacity. The current percentage still alerts at 70%.
    growth_days = 36500 if increase <= 0 else min(36500, remaining * elapsed / increase / 86400)
    return {"host_cpu_percent": 100 * (ticks - idle) / ticks,
            "host_memory_percent": current["memory_percent"],
            "disk_used_percent": 100 * current["disk_used"] / current["disk_total"],
            "disk_growth_days": growth_days, "cpu_steal_percent": 100 * steal / ticks}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", required=True)
    parser.add_argument("--state", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--disk-path", required=True, help="actual PostgreSQL/WAL filesystem mount")
    args = parser.parse_args()
    try:
        if len({str(Path(p).absolute()) for p in (args.evidence, args.state, args.output)}) != 3:
            raise ValueError("input, state and output must be distinct")
        current = host_sample(args.disk_path)
        try:
            prior = read_json(args.state)
        except FileNotFoundError:
            prior = None
        measured = calculate(current, prior)
        # Always advance a valid local baseline. Invalid external evidence never
        # causes a previously published observation to be refreshed as healthy.
        atomic_json(args.state, current)
        if measured is None:
            print("collector baseline recorded; complete sample unavailable", file=sys.stderr)
            return 2
        verified = evidence(args.evidence, current["at"])
        timestamp = dt.datetime.fromtimestamp(current["at"], dt.timezone.utc).isoformat().replace("+00:00", "Z")
        atomic_json(args.output, {"observed_at": timestamp, **measured, **verified})
    except (OSError, ValueError, KeyError, TypeError, OverflowError, subprocess.SubprocessError):
        print("observation unavailable; inspect the private collector and evidence source", file=sys.stderr)
        return 1
    print("aggregate observation published")
    return 0


if __name__ == "__main__":
    sys.exit(main())
