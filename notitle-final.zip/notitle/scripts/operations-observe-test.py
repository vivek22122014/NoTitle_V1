#!/usr/bin/env python3
import datetime as dt
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location("observe", Path(__file__).with_name("operations-observe.py"))
observe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(observe)


class ObservationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "evidence.json"
        self.now = 1791504000
        stamp = dt.datetime.fromtimestamp(self.now, dt.timezone.utc).isoformat().replace("+00:00", "Z")
        self.record = {key: ("0001-01-01T00:00:00Z" if key in observe.TIMES else False if key in observe.BOOLS else 0) for key in observe.EVIDENCE_KEYS}
        self.record["evidence_observed_at"] = stamp

    def save(self, value=None):
        self.path.write_text(json.dumps(self.record if value is None else value))
        self.path.chmod(0o600)

    def test_unknown_recovery_remains_unknown(self):
        self.save()
        result = observe.evidence(self.path, self.now)
        self.assertEqual(result["recoverable_wal_at"], "0001-01-01T00:00:00Z")
        self.assertFalse(result["external_probe_healthy"])
        self.assertNotIn("evidence_observed_at", result)

    def test_stale_future_and_incomplete_evidence_rejected(self):
        self.save()
        with self.assertRaises(ValueError):
            observe.evidence(self.path, self.now + 121)
        with self.assertRaises(ValueError):
            observe.evidence(self.path, self.now - 6)
        del self.record["hold_journal_recoverable_at"]
        self.save()
        with self.assertRaises(ValueError):
            observe.evidence(self.path, self.now)

    def test_duplicate_or_nonfinite_input_never_silently_overrides(self):
        for raw in ['{"a":1,"a":2}', '{"a":NaN}']:
            self.path.write_text(raw)
            self.path.chmod(0o600)
            with self.assertRaises(ValueError):
                observe.read_json(self.path)

    def test_cpu_disk_projection_and_reboot_boundaries(self):
        prior = {"at": self.now, "boot_id": "same", "total_ticks": 1000, "idle_ticks": 700, "steal_ticks": 10, "disk_used": 1000}
        current = {"at": self.now + 5, "boot_id": "same", "total_ticks": 1200, "idle_ticks": 800, "steal_ticks": 30,
                   "disk_total": 10000, "disk_used": 2000, "memory_percent": 70}
        result = observe.calculate(current, prior)
        self.assertEqual(result["host_cpu_percent"], 50)
        self.assertEqual(result["cpu_steal_percent"], 10)
        self.assertEqual(result["disk_used_percent"], 20)
        self.assertAlmostEqual(result["disk_growth_days"], 40 / 86400)
        self.assertIsNone(observe.calculate(current, None))
        self.assertIsNone(observe.calculate({**current, "boot_id": "restarted"}, prior))
        self.assertIsNone(observe.calculate({**current, "at": self.now - 1}, prior))
        self.assertIsNone(observe.calculate({**current, "total_ticks": 999}, prior))

    def test_atomic_output_private_and_symlink_rejected(self):
        observe.atomic_json(self.path, {"first": 1})
        self.assertEqual(self.path.stat().st_mode & 0o777, 0o600)
        observe.atomic_json(self.path, {"second": 2})
        self.assertEqual(json.loads(self.path.read_text()), {"second": 2})
        link = self.path.with_name("link")
        link.symlink_to(self.path)
        with self.assertRaises(ValueError):
            observe.atomic_json(link, {"malicious": 3})
        self.assertEqual(json.loads(self.path.read_text()), {"second": 2})

    def test_boolean_string_and_negative_counter_rejected(self):
        self.record["external_probe_healthy"] = "true"
        self.save()
        with self.assertRaises(ValueError):
            observe.evidence(self.path, self.now)
        self.record["external_probe_healthy"] = False
        self.record["relay_allocations"] = -1
        self.save()
        with self.assertRaises(ValueError):
            observe.evidence(self.path, self.now)


if __name__ == "__main__":
    unittest.main()
