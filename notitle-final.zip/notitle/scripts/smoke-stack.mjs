import assert from 'node:assert/strict';
import { appPaths, publicPaths } from '../web/src/lib/config/routes.mjs';

const base = process.env.SMOKE_BASE_URL ?? 'http://web:8080';
async function get(path, status) {
  const response = await fetch(base + path, {
    redirect: 'manual',
    signal: AbortSignal.timeout(5000)
  });
  assert.equal(response.status, status, path);
  return response;
}
if (process.argv.includes('--not-ready')) {
  await get('/health/live', 200);
  await get('/health/ready', 503);
  console.log('Liveness remains up and readiness fails while the database dependency is unavailable.');
  process.exit(0);
}
if (process.argv.includes('--wait-ready')) {
  for (let attempt = 0; attempt < 30; attempt++) {
    try {
      await get('/health/ready', 200);
      console.log('API readiness recovered after the database dependency was restored.');
      process.exit(0);
    } catch (error) {
      if (attempt === 29) throw error;
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
  }
}
const titles = new Set();
const expectProduction = process.env.SMOKE_EXPECT_MODE === 'production';
for (const path of publicPaths) {
  const response = await get(path, 200);
  assert.match(response.headers.get('content-security-policy') ?? '', /frame-ancestors 'none'/, path);
  if (!expectProduction) assert.match(response.headers.get('x-robots-tag') ?? '', /noindex/, path);
  const html = await response.text();
  assert.match(html, /http-equiv=["']content-security-policy["']/i, path);
  assert.match(html, /sha256-/, path);
  assert.match(html, /<h1[\s>]/, path);
  const title = html.match(/<title>([^<]+)<\/title>/)?.[1];
  assert.ok(title && !titles.has(title), 'Unique route title: ' + path);
  titles.add(title);
  assert.match(html, /name=["']description["']/i, path);
  assert.match(html, /property=["']og:title["']/i, path);
  if (expectProduction) assert.match(html, /rel=["']canonical["']/i, path);
  if (path !== '/') {
    const redirect = await get(path + '/', 308);
    assert.equal(redirect.headers.get('location'), path);
  }
}
for (const path of appPaths) {
  const response = await get(path, 200);
  assert.equal(response.headers.get('cache-control'), 'no-store', path);
  assert.match(response.headers.get('x-robots-tag') ?? '', /noindex/, path);
  assert.match(await response.text(), /noindex/, path);
  const redirect = await get(path + '/', 308);
  assert.equal(redirect.headers.get('location'), path);
}
for (const path of ['/unknown', '/chat/nested', '/app.html', '/index.html', '/design-preview', '/notitle-build.json']) {
  const response = await get(path, 404);
  assert.match(response.headers.get('content-type') ?? '', /text\/html/, path);
  assert.match(response.headers.get('x-robots-tag') ?? '', /noindex/, path);
  assert.match(await response.text(), /Page not found/i, path);
}
const robots = await get('/robots.txt', 200);
assert.match(await robots.text(), /User-agent:\s*\*/i);
const sitemap = await (await get('/sitemap.xml', 200)).text();
assert.match(sitemap, /<urlset\b/);
for (const path of appPaths) assert.ok(!sitemap.includes(path + '</loc>'), 'Private route absent from sitemap: ' + path);
await get('/logo.svg', 200);
await get('/social-card.png', 200);
await get('/health/live', 200);
await get('/health/ready', 200);
console.log('All public/app routes, HTML metadata, discovery files, real 404s, CSP, cache rules and API health checks passed.');
