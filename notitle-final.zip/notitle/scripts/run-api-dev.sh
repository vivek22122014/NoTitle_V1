#!/usr/bin/env bash
set -euo pipefail
# PostgreSQL is deliberately not exposed to the host.
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
exec "$ROOT/scripts/compose.sh" dev restart api
