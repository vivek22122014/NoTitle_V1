#!/usr/bin/env python3
"""Seal one approved, bounded, closed security/journal segment for off-host transfer.

No upload, deletion or key generation occurs here. age must be installed from a
reviewed release. Plaintext is passed over a pipe and never written to a temp file.
"""
import argparse
import base64
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import secrets
import stat
import subprocess
import sys

MAX_BYTES = 16 * 1024 * 1024
PURPOSES = {"security", "deletion-journal", "hold-journal"}


def private_open(path, directory=False):
    """Walk with openat/no-follow so symlinks, including parents, are rejected."""
    path = Path(path)
    if not path.is_absolute() or ".." in path.parts:
        raise ValueError("absolute protected path required")
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
    try:
        for i, part in enumerate(path.parts[1:]):
            final = i == len(path.parts) - 2
            flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC
            if not final or directory:
                flags |= os.O_DIRECTORY
            next_fd = os.open(part, flags, dir_fd=fd)
            os.close(fd)
            fd = next_fd
        info = os.fstat(fd)
        expected = stat.S_ISDIR if directory else stat.S_ISREG
        if not expected(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077:
            raise ValueError("owner-only path required")
        result, fd = fd, None
        return result
    finally:
        if fd is not None:
            os.close(fd)


def read_segment(path):
    fd = private_open(path)
    try:
        before = os.fstat(fd)
        if not 0 < before.st_size <= MAX_BYTES:
            raise ValueError("segment size outside bounds")
        with os.fdopen(os.dup(fd), "rb") as source:
            data = source.read(MAX_BYTES + 1)
        after = os.fstat(fd)
        if len(data) != before.st_size or before.st_mtime_ns != after.st_mtime_ns or before.st_ctime_ns != after.st_ctime_ns:
            raise ValueError("segment changed during read")
        return data
    finally:
        os.close(fd)


def seal(source, destination, recipient, purpose, runner=subprocess.run):
    if purpose not in PURPOSES or not recipient.startswith("age1") or len(recipient) != 62 or not recipient.isalnum():
        raise ValueError("invalid purpose or age recipient")
    data = read_segment(source)
    directory = private_open(destination, directory=True)
    name = secrets.token_hex(24) + ".age"
    metadata_name = name + ".json"
    published = []
    try:
        created = dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")
        envelope = json.dumps({"schema": 1, "purpose": purpose, "created_at": created,
                               "plaintext_sha256": hashlib.sha256(data).hexdigest(),
                               "payload_base64": base64.b64encode(data).decode("ascii")}, separators=(",", ":")).encode()
        completed = runner(["age", "--encrypt", "--recipient", recipient], input=envelope,
                           capture_output=True, timeout=60, check=False)
        ciphertext = completed.stdout
        if completed.returncode != 0 or not ciphertext.startswith(b"age-encryption.org/v1\n") or len(ciphertext) > MAX_BYTES * 2:
            raise ValueError("encryption unavailable")
        metadata = {"schema": 1, "purpose": purpose, "created_at": created, "object": name,
                    "ciphertext_sha256": hashlib.sha256(ciphertext).hexdigest(), "bytes": len(ciphertext)}
        for filename, payload in [(name, ciphertext), (metadata_name, json.dumps(metadata, separators=(",", ":")).encode())]:
            fd = os.open(filename, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=directory)
            published.append(filename)
            with os.fdopen(fd, "wb") as output:
                output.write(payload)
                output.flush()
                os.fsync(output.fileno())
        os.fsync(directory)
        return metadata
    except BaseException:
        for filename in published:
            os.unlink(filename, dir_fd=directory)
        raise
    finally:
        os.close(directory)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--recipient", required=True, help="public age recipient, never a private key")
    parser.add_argument("--purpose", required=True, choices=sorted(PURPOSES))
    args = parser.parse_args()
    try:
        result = seal(args.input, args.output_dir, args.recipient, args.purpose)
    except (OSError, ValueError, subprocess.SubprocessError):
        print("archive unavailable; retain the source segment and notify operations", file=sys.stderr)
        return 1
    print(json.dumps(result, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    sys.exit(main())
