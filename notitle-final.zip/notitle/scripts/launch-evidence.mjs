#!/usr/bin/env node
import { lstat, open, readFile, realpath } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { checkEvidence, newEvidence, readJSON, sha256, sourceDigest, strictJSON, validOrigin } from './launch-evidence-lib.mjs';

export async function saveExclusive(file, value, source, mode = 0o600) {
  const sourcePath = await realpath(source);
  const absolute = path.resolve(file);
  const parent = await realpath(path.dirname(absolute));
  if (parent === sourcePath || parent.startsWith(sourcePath + path.sep)) throw new Error('Evidence output must be outside source');
  // Do not follow a parent symlink into an unexpected destination.
  let cursor = path.parse(absolute).root;
  for (const part of path.dirname(absolute).slice(cursor.length).split(path.sep).filter(Boolean)) { cursor = path.join(cursor, part); if ((await lstat(cursor)).isSymbolicLink()) throw new Error('Output symlink is not allowed'); }
  const fd = await open(absolute, 'wx', mode);
  try { await fd.writeFile(JSON.stringify(value, null, 2) + '\n'); await fd.sync(); } finally { await fd.close(); }
}

async function validators() {
  try { const v = await import('./load-contract.mjs'); return { capacityValidator: v.validateCapacityReport, overloadValidator: v.validateOverloadReport, permitValidator: v.validatePermit }; }
  catch { return {}; } // A missing validator leaves capacity blocked, never passed.
}

export async function main(args, { now = new Date() } = {}) {
  const [action, ...rest] = args;
  if (!['init', 'check', 'permit'].includes(action) || rest.length % 2) throw new Error('Usage: launch-evidence.mjs init|check|permit --source DIR --out FILE | --evidence FILE [--origin HTTPS --images FILE] [--evidence-ref ID]');
  const flags = {};
  const allowed = action === 'init' ? ['--source', '--out', '--origin', '--images'] : action === 'check' ? ['--source', '--evidence', '--purpose'] : ['--source', '--evidence', '--out', '--evidence-ref', '--purpose'];
  for (let i = 0; i < rest.length; i += 2) { if (!allowed.includes(rest[i]) || Object.hasOwn(flags, rest[i]) || !rest[i + 1] || rest[i + 1].startsWith('--')) throw new Error('Invalid or repeated argument'); flags[rest[i]] = rest[i + 1]; }
  if (!flags['--source']) throw new Error('Source directory is required');
  if (action === 'init') {
    if (!flags['--out']) throw new Error('Output file is required');
    if (flags['--origin'] && !validOrigin(flags['--origin'])) throw new Error('Actual canonical HTTPS origin is required');
    const draft = newEvidence({ source_sha256: (await sourceDigest(flags['--source'])).sha256, origin: flags['--origin'] ?? null, images: flags['--images'] ? await readJSON(flags['--images']) : null, now });
    // Run schema validation before writing; the pending verdict is expected.
    await checkEvidence(draft, { source: flags['--source'], evidenceDirectory: path.dirname(path.resolve(flags['--out'])), now });
    await saveExclusive(flags['--out'], draft, flags['--source']);
    return { exitCode: 0, output: { state: 'pending', message: 'Created pending evidence only; no checks or approvals are claimed.' } };
  }
  if (!flags['--evidence']) throw new Error('Evidence file is required');
  const evidencePath = path.resolve(flags['--evidence']);
  const evidence = await readJSON(evidencePath);
  const purpose = flags['--purpose'] ?? 'launch';
  const result = await checkEvidence(evidence, { source: flags['--source'], evidenceDirectory: path.dirname(evidencePath), purpose, now, ...await validators() });
  const eligible = result.eligible_for_supervised_cohort || result.eligible_for_controlled_validation;
  if (action === 'check' || !eligible) return { exitCode: eligible ? 0 : 1, output: result };
  if (!flags['--out'] || !/^[a-z][a-z0-9_]{0,63}$/.test(flags['--evidence-ref'] ?? '')) throw new Error('Permit output and opaque evidence reference are required');
  // Re-read for the digest only after matching the same in-memory evidence.
  const raw = await readFile(evidencePath);
  if (JSON.stringify(strictJSON(new TextDecoder('utf-8', { fatal: true }).decode(raw))) !== JSON.stringify(evidence)) throw new Error('Evidence changed during validation');
  const approvedAt = new Date(now);
  const expires = Math.min(approvedAt.valueOf() + (purpose === 'validation' ? 7200000 : 86400000), ...Object.values(evidence.gates).filter((g) => g.status === 'passed').map((g) => Date.parse(g.valid_until)), ...Object.values(evidence.approvals).map((a) => Date.parse(a.valid_until)), purpose === 'validation' ? Date.parse(evidence.validation_authorization.expires_at) : Infinity);
  if (expires <= approvedAt.valueOf()) throw new Error('Evidence expired during validation');
  const permit = { schema_version: 1, source_sha256: evidence.release.source_sha256, api_image: evidence.release.images.api, deployment_manifest_sha256: evidence.release.deployment_manifest_sha256, origin: evidence.release.origin, schema: 9, purpose, limits: { connected: 200, waiting: 100, calls: 25 }, approved_at: approvedAt.toISOString(), expires_at: new Date(expires).toISOString(), evidence_sha256: sha256(raw), evidence_ref: flags['--evidence-ref'], approved: true };
  await saveExclusive(flags['--out'], permit, flags['--source'], 0o400);
  return { exitCode: 0, output: { state: 'permit_created', expires_at: permit.expires_at, message: 'Protected short-lived permit created; production remains unchanged. Named owner MFA and current readiness are still required.' } };
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try { const result = await main(process.argv.slice(2)); process.stdout.write(JSON.stringify(result.output, null, 2) + '\n'); process.exitCode = result.exitCode; }
  catch (error) { process.stderr.write(JSON.stringify({ state: 'invalid', error: error instanceof Error ? error.message : 'Invalid evidence' }) + '\n'); process.exitCode = 2; }
}
