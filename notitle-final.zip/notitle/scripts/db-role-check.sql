-- Executed as notitle_app against an isolated test database.
\set ON_ERROR_STOP on
DO $$
DECLARE
    permission_record record;
BEGIN
    IF current_user <> 'notitle_app' THEN
        RAISE EXCEPTION 'Role check must run as notitle_app';
    END IF;
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname=current_user
        AND (rolsuper OR rolcreatedb OR rolcreaterole OR rolreplication OR rolbypassrls)) THEN
        RAISE EXCEPTION 'Runtime role has forbidden role privileges';
    END IF;
    IF EXISTS (SELECT 1 FROM pg_auth_members WHERE member=(SELECT oid FROM pg_roles WHERE rolname=current_user)) THEN
        RAISE EXCEPTION 'Runtime role must not inherit another role';
    END IF;
    IF has_database_privilege(current_user,current_database(),'CREATE')
        OR has_database_privilege(current_user,current_database(),'TEMP')
        OR has_schema_privilege(current_user,'public','CREATE')
        OR has_schema_privilege(current_user,'notitle','CREATE') THEN
        RAISE EXCEPTION 'Runtime role can create database objects';
    END IF;
    IF (SELECT count(*) FROM notitle.schema_version WHERE version=9) <> 1 THEN
        RAISE EXCEPTION 'Expected operations and privacy schema marker';
    END IF;
    FOR permission_record IN SELECT * FROM (VALUES
        ('account_safety_state',true,false),
        ('pending_safety_handoffs',false,true),
        ('blocks',true,true),
        ('reports',true,false),
        ('case_subject_refs',false,false),
        ('report_evidence',false,false),
        ('moderation_actions',false,false),
        ('admin_sessions',true,true),
        ('admin_audit',false,false),
        ('friendships',false,true),
        ('purchase_orders',true,false),
        ('payment_attempts',true,false),
        ('premium_accounts',true,false),
        ('premium_lots',true,false),
        ('premium_adjustments',false,false),
        ('refunds',true,false),
        ('disputes',true,false),
        ('billing_review_cases',true,false),
        ('billing_review_actions',false,false),
        ('billing_dispute_actions',false,false),
        ('payment_webhook_inbox',false,false),
        ('billing_jobs',true,false),
        ('billing_reconciliation_watermarks',true,false),
        ('settlement_reconciliation',false,false),
        ('grievances',true,false),('grievance_messages',true,false),('grievance_actions',false,false),
        ('operations_outbox',true,false),('rule_notice_deliveries',true,false),
        ('operational_alerts',true,false),('operational_alert_deliveries',true,false),('operational_metric_hours',true,false),
        ('privacy_hold_events',false,false),('privacy_holds',true,false),('privacy_jobs',true,false)
    ) AS expected(table_name,allow_update,allow_delete)
    LOOP
        IF NOT has_table_privilege(current_user,'notitle.'||permission_record.table_name,'SELECT')
            OR NOT has_table_privilege(current_user,'notitle.'||permission_record.table_name,'INSERT')
            OR has_table_privilege(current_user,'notitle.'||permission_record.table_name,'UPDATE') <> permission_record.allow_update
            OR has_table_privilege(current_user,'notitle.'||permission_record.table_name,'DELETE') <> permission_record.allow_delete
            OR has_table_privilege(current_user,'notitle.'||permission_record.table_name,'TRUNCATE')
            OR has_table_privilege(current_user,'notitle.'||permission_record.table_name,'TRIGGER')
            OR has_table_privilege(current_user,'notitle.'||permission_record.table_name,'REFERENCES')
            OR (SELECT tableowner FROM pg_tables WHERE schemaname='notitle' AND tablename=permission_record.table_name) <> 'notitle_migrate'
        THEN
            RAISE EXCEPTION 'Application table % runtime grants are incorrect',permission_record.table_name;
        END IF;
    END LOOP;
    IF NOT has_table_privilege(current_user,'notitle.premium_plans','SELECT')
        OR has_table_privilege(current_user,'notitle.premium_plans','INSERT')
        OR has_table_privilege(current_user,'notitle.premium_plans','UPDATE')
        OR has_table_privilege(current_user,'notitle.premium_plans','DELETE')
        OR has_table_privilege(current_user,'notitle.premium_plans','TRUNCATE')
        OR has_table_privilege(current_user,'notitle.premium_plans','TRIGGER')
        OR has_table_privilege(current_user,'notitle.premium_plans','REFERENCES')
        OR EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='notitle' AND table_name='premium_plans'
            AND (has_column_privilege(current_user,'notitle.premium_plans',column_name,'UPDATE')
              OR has_column_privilege(current_user,'notitle.premium_plans',column_name,'INSERT')))
        OR (SELECT tableowner FROM pg_tables WHERE schemaname='notitle' AND tablename='premium_plans') <> 'notitle_migrate'
    THEN
        RAISE EXCEPTION 'Runtime may read the approved catalog but cannot publish plans or change economics';
    END IF;
    FOR permission_record IN SELECT * FROM (VALUES
        ('premium_adjustments','created_at'),
        ('payment_webhook_inbox','received_at'),
        ('settlement_reconciliation','recorded_at'),
        ('billing_review_actions','created_at'),
        ('billing_dispute_actions','created_at'),('grievance_actions','created_at'),('privacy_hold_events','recorded_at')
    ) AS immutable(table_name,probe_column)
    LOOP
        BEGIN
            EXECUTE format('UPDATE notitle.%I SET %I=%I WHERE false',permission_record.table_name,permission_record.probe_column,permission_record.probe_column);
            RAISE EXCEPTION 'Runtime immutable financial history update unexpectedly succeeded';
        EXCEPTION WHEN insufficient_privilege THEN NULL;
        END;
        BEGIN
            EXECUTE format('DELETE FROM notitle.%I WHERE false',permission_record.table_name);
            RAISE EXCEPTION 'Runtime immutable financial history deletion unexpectedly succeeded';
        EXCEPTION WHEN insufficient_privilege THEN NULL;
        END;
    END LOOP;
    FOR permission_record IN SELECT * FROM (VALUES
        ('premium_adjustments_id_seq'),('premium_lots_grant_sequence_seq'),('billing_jobs_id_seq'),
        ('billing_review_actions_id_seq'),('billing_dispute_actions_id_seq'),('operational_alert_deliveries_id_seq')
    ) AS financial(sequence_name)
    LOOP
        IF NOT has_sequence_privilege(current_user,'notitle.'||permission_record.sequence_name,'USAGE')
            OR NOT has_sequence_privilege(current_user,'notitle.'||permission_record.sequence_name,'SELECT')
            OR has_sequence_privilege(current_user,'notitle.'||permission_record.sequence_name,'UPDATE') THEN
            RAISE EXCEPTION 'Runtime may allocate financial event IDs but cannot reset sequencing';
        END IF;
    END LOOP;
    IF has_function_privilege(current_user,'notitle.billing_immutable_snapshot()','EXECUTE') THEN
        RAISE EXCEPTION 'Snapshot trigger helper must not be a direct runtime RPC';
    END IF;
    FOR permission_record IN SELECT * FROM (VALUES
        ('legal_deadline_rules'),('rule_notices'),('retention_policies'),('restricted_registration'),('privacy_purge_audit'),('legal_holds')
    ) AS readonly(table_name)
    LOOP
        IF NOT has_table_privilege(current_user,'notitle.'||permission_record.table_name,'SELECT')
            OR has_table_privilege(current_user,'notitle.'||permission_record.table_name,'INSERT,UPDATE,DELETE,TRUNCATE,TRIGGER,REFERENCES')
            OR EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='notitle' AND table_name=permission_record.table_name
                AND (has_column_privilege(current_user,'notitle.'||permission_record.table_name,column_name,'UPDATE')
                  OR has_column_privilege(current_user,'notitle.'||permission_record.table_name,column_name,'INSERT')))
            OR (SELECT tableowner FROM pg_tables WHERE schemaname='notitle' AND tablename=permission_record.table_name)<>'notitle_migrate'
        THEN RAISE EXCEPTION 'Reviewed policy or restricted projection % has excess runtime grants',permission_record.table_name; END IF;
    END LOOP;
    IF has_function_privilege(current_user,'notitle.protect_grievance_receipt()','EXECUTE') THEN
        RAISE EXCEPTION 'Grievance receipt trigger helper exposed as runtime RPC';
    END IF;
    FOR permission_record IN SELECT * FROM (VALUES
        ('notitle.privacy_scrub_account(uuid,text,timestamp with time zone)'),
        ('notitle.privacy_execute_job(uuid,uuid,timestamp with time zone)'),
        ('notitle.privacy_expire_security_audit(text,timestamp with time zone)'),
        ('notitle.operations_expire_metadata(text,timestamp with time zone)')
    ) AS guarded(function_name)
    LOOP
        IF NOT has_function_privilege(current_user,permission_record.function_name,'EXECUTE')
            OR NOT EXISTS (SELECT 1 FROM pg_proc WHERE oid=to_regprocedure(permission_record.function_name)
                AND prosecdef AND proowner=(SELECT oid FROM pg_roles WHERE rolname='notitle_migrate')
                AND 'search_path=pg_catalog'=ANY(proconfig))
            OR EXISTS (SELECT 1 FROM pg_proc p CROSS JOIN LATERAL aclexplode(COALESCE(p.proacl,acldefault('f',p.proowner))) a
                WHERE p.oid=to_regprocedure(permission_record.function_name) AND a.grantee=0 AND a.privilege_type='EXECUTE')
        THEN RAISE EXCEPTION 'Guarded privacy entrypoint has unsafe owner, search path or grants'; END IF;
    END LOOP;
    IF NOT has_table_privilege(current_user,'notitle.admin_users','SELECT')
        OR has_table_privilege(current_user,'notitle.admin_users','INSERT')
        OR has_table_privilege(current_user,'notitle.admin_users','UPDATE')
        OR has_table_privilege(current_user,'notitle.admin_users','DELETE')
        OR has_table_privilege(current_user,'notitle.admin_users','TRUNCATE')
        OR has_table_privilege(current_user,'notitle.admin_users','TRIGGER')
        OR has_table_privilege(current_user,'notitle.admin_users','REFERENCES')
        OR (SELECT tableowner FROM pg_tables WHERE schemaname='notitle' AND tablename='admin_users') <> 'notitle_migrate'
        OR NOT has_column_privilege(current_user,'notitle.admin_users','last_counter','UPDATE')
        OR EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema='notitle' AND table_name='admin_users'
            AND column_name <> 'last_counter' AND has_column_privilege(current_user,'notitle.admin_users',column_name,'UPDATE'))
    THEN
        RAISE EXCEPTION 'Runtime can alter privileged operator identity or cannot enforce MFA replay protection';
    END IF;
    -- Row-locking guards must work with column UPDATE(last_counter) alone;
    -- this never updates a record or broadens the operator grants.
    PERFORM id FROM notitle.admin_users WHERE false FOR UPDATE;
    IF NOT has_table_privilege(current_user,'notitle.accounts','SELECT')
        OR NOT has_table_privilege(current_user,'notitle.accounts','INSERT')
        OR NOT has_table_privilege(current_user,'notitle.accounts','UPDATE')
        OR NOT has_table_privilege(current_user,'notitle.professional_interests','SELECT')
        OR NOT has_table_privilege(current_user,'notitle.professional_interests','INSERT')
        OR NOT has_table_privilege(current_user,'notitle.professional_interests','DELETE')
        OR has_table_privilege(current_user,'notitle.professional_interests','UPDATE')
        OR has_table_privilege(current_user,'notitle.accounts','DELETE')
        OR has_table_privilege(current_user,'notitle.consent_events','UPDATE')
        OR has_table_privilege(current_user,'notitle.consent_events','DELETE') THEN
        RAISE EXCEPTION 'Identity runtime table grants are incorrect';
    END IF;
    IF NOT has_table_privilege(current_user,'notitle.matchmaking_preferences','SELECT')
        OR NOT has_table_privilege(current_user,'notitle.matchmaking_preferences','INSERT')
        OR NOT has_table_privilege(current_user,'notitle.matchmaking_preferences','UPDATE')
        OR has_table_privilege(current_user,'notitle.matchmaking_preferences','DELETE')
        OR has_table_privilege(current_user,'notitle.matchmaking_preferences','TRUNCATE')
        OR NOT has_function_privilege(current_user,'notitle.unique_choices(text[],integer)','EXECUTE') THEN
        RAISE EXCEPTION 'Matchmaking preference runtime grants are incorrect';
    END IF;
    BEGIN
        CREATE TABLE notitle.forbidden_probe (id integer);
        RAISE EXCEPTION 'Runtime DDL unexpectedly succeeded';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        CREATE TEMP TABLE forbidden_probe (id integer);
        RAISE EXCEPTION 'Runtime TEMP unexpectedly succeeded';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        UPDATE notitle.schema_version SET version=1;
        RAISE EXCEPTION 'Runtime marker mutation unexpectedly succeeded';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        SET ROLE notitle_migrate;
        RAISE EXCEPTION 'Runtime escalation unexpectedly succeeded';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        UPDATE notitle.admin_users SET roles=ARRAY['owner'] WHERE false;
        RAISE EXCEPTION 'Runtime operator privilege escalation unexpectedly succeeded';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        INSERT INTO notitle.admin_users DEFAULT VALUES;
        RAISE EXCEPTION 'Runtime operator provisioning unexpectedly succeeded';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        UPDATE notitle.admin_audit SET reason='forbidden probe' WHERE false;
        RAISE EXCEPTION 'Runtime audit rewrite unexpectedly succeeded';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        DELETE FROM notitle.admin_audit WHERE false;
        RAISE EXCEPTION 'Runtime audit deletion unexpectedly succeeded';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        DELETE FROM notitle.report_evidence WHERE false;
        RAISE EXCEPTION 'Runtime evidence deletion unexpectedly succeeded';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        UPDATE notitle.moderation_actions SET reason='forbidden probe' WHERE false;
        RAISE EXCEPTION 'Runtime moderation history rewrite unexpectedly succeeded';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        UPDATE notitle.premium_plans SET enabled=true WHERE false;
        RAISE EXCEPTION 'Runtime plan publication unexpectedly succeeded';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
    BEGIN
        DELETE FROM notitle.purchase_orders WHERE false;
        RAISE EXCEPTION 'Runtime purchase removal unexpectedly succeeded';
    EXCEPTION WHEN insufficient_privilege THEN NULL;
    END;
END
$$;
