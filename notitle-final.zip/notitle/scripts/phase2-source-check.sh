#!/usr/bin/env bash
set -euo pipefail
source "$(dirname -- "$0")/lib.sh"
command -v node >/dev/null || { echo 'Node24 is required for the dependency-free source checks.' >&2; exit 1; }
cd "$ROOT"
node scripts/audit.mjs
node --test web/tests/*.test.mjs deploy/tests/*.test.mjs
echo 'Phase2 source checks passed. This does not establish Svelte, browser, Docker or release acceptance.'
