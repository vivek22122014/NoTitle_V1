import { createHash } from 'node:crypto';
import { lstat, readdir, readFile, realpath } from 'node:fs/promises';
import path from 'node:path';
import { isIP } from 'node:net';

export const IMAGE_KEYS = ['api', 'web', 'migrate', 'postgres', 'turn'];
export const GATES = Object.freeze({
  source_dependencies: 30, backend_database: 30, security_review: 30,
  web_build: 30, browser_desktop: 30, mobile_real_devices: 30,
  accessibility_seo: 30, acceptance_matrix: 30, audio_enforcement: 30,
  load_a: 30, load_b: 30, overload: 30, dense_friends: 30,
  restore: 30, rollback_drain: 30, deploy_security: 7, domain_tls: 7,
  external_monitor: 7, operator_drills: 30, legal_privacy: 90,
  tax_refunds: 90, merchant_approval: 90, live_money: 30,
  production_smoke: 7, cost_caps: 30, owner_scope: 7,
});
export const APPROVAL_ROLES = ['engineering', 'business', 'operations', 'counsel', 'accountant'];
export const ACCEPTANCE_AREAS = ['shared_pool', 'gender_truth_table', 'soft_ranking', 'recent_pairs', 'concurrency', 'identity', 'text_reports', 'friends', 'voice', 'voice_enforcement', 'money', 'refunds', 'operations', 'recovery', 'responsive_seo', 'minimum_capacity'];
export const SECURITY_AREAS = ['session_fixation_revocation', 'csrf_origin_websocket', 'enumeration_object_access', 'xss', 'oversize_flood_slow_readers', 'forged_stale_epochs', 'payment_forgery', 'admin_role_mfa_exports', 'relay_targets', 'untrusted_proxy_headers', 'secret_dependency_image_scans', 'no_content_retention'];
export const MOBILE_AREAS = ['guest_account_recovery', 'matching_text_friends', 'report_block_support_privacy', 'microphone_denial', 'incoming_calls', 'app_switch', 'screen_lock', 'rotation', 'wifi_cellular_switch', 'checkout_return', 'fresh_consent_after_signaling_loss', 'keyboard_safe_area', 'screen_reader', 'zoom_200', 'targets_44px'];
export const RESTORE_AREAS = ['full_wal_verified', 'deletion_hold_journal_replay', 'restored_sessions_revoked', 'payment_reconciled', 'restrictions_verified', 'missing_corrupt_journal_closed', 'object_store_denial', 'corrupt_backup', 'full_disk', 'lost_host', 'backup_operator'];
export const sha256 = (value) => createHash('sha256').update(value).digest('hex');
const HASH = /^[a-f0-9]{64}$/;
const ID = /^[a-z][a-z0-9_]{0,63}$/;
const IMAGE = /^(?=.{1,500}$)[a-z0-9][a-z0-9._:/-]*@sha256:[a-f0-9]{64}$/;
const DAY = 86400000;
const MAX_JSON = 8 * 1024 * 1024;
const own = (o, key) => Object.hasOwn(o, key);
const isObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const text = (v) => typeof v === 'string' && v.trim().length >= 3 && v.length <= 500 && !/[\x00-\x1f\x7f]/.test(v);
const time = (v) => typeof v === 'string' && /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{3})?Z$/.test(v) && Number.isFinite(Date.parse(v)) && new Date(v).toISOString().replace('.000Z', 'Z') === v.replace('.000Z', 'Z');
const sorted = (a) => [...a].sort();
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const sameImages = (a, b) => digestImages(a) && digestImages(b) && IMAGE_KEYS.every((key) => a[key] === b[key]);
function fields(value, required, optional = []) {
  if (!isObject(value) || required.some((key) => !own(value, key)) || Object.keys(value).some((key) => !required.includes(key) && !optional.includes(key))) throw new Error('Unexpected or missing object fields');
}
function strings(value, expected) { return Array.isArray(value) && value.length === new Set(value).size && expected.every((v) => value.includes(v)) && value.every((v) => typeof v === 'string'); }
function digestImages(value) { return isObject(value) && same(sorted(Object.keys(value)), sorted(IMAGE_KEYS)) && IMAGE_KEYS.every((k) => typeof value[k] === 'string' && IMAGE.test(value[k])); }
export function validOrigin(value) {
  try { const u = new URL(value); return u.protocol === 'https:' && u.origin === value && !u.username && !u.password && !u.port && !isIP(u.hostname) && u.hostname.includes('.') && !/(^|\.)(localhost|example\.(com|net|org)|test|invalid|local|internal)$/.test(u.hostname); } catch { return false; }
}

// Reject duplicate keys before JSON.parse can silently replace a reviewed value.
export function strictJSON(input) {
  if (Buffer.byteLength(input) > MAX_JSON) throw new Error('JSON exceeds size limit');
  let i = 0;
  const ws = () => { while (/\s/.test(input[i] ?? '') && i < input.length) i++; };
  const string = () => { const start = i++; while (i < input.length) { if (input[i] === '\\') { i += 2; continue; } if (input[i++] === '"') return JSON.parse(input.slice(start, i)); } throw new Error('Unterminated JSON string'); };
  const value = (depth) => {
    if (depth > 64) throw new Error('JSON nesting exceeds limit');
    ws();
    if (input[i] === '{') { i++; ws(); const keys = new Set(); if (input[i] === '}') { i++; return; } while (i < input.length) { ws(); if (input[i] !== '"') throw new Error('Invalid JSON key'); const key = string(); if (keys.has(key)) throw new Error('Duplicate JSON key'); keys.add(key); ws(); if (input[i++] !== ':') throw new Error('Invalid JSON object'); value(depth + 1); ws(); const c = input[i++]; if (c === '}') return; if (c !== ',') throw new Error('Invalid JSON object'); } }
    else if (input[i] === '[') { i++; ws(); if (input[i] === ']') { i++; return; } while (i < input.length) { value(depth + 1); ws(); const c = input[i++]; if (c === ']') return; if (c !== ',') throw new Error('Invalid JSON array'); } }
    else if (input[i] === '"') { string(); return; }
    else { const m = /^(?:true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)/.exec(input.slice(i)); if (!m) throw new Error('Invalid JSON scalar'); i += m[0].length; return; }
    throw new Error('Incomplete JSON');
  };
  value(0); ws(); if (i !== input.length) throw new Error('Trailing JSON');
  const result = JSON.parse(input);
  const finite = (v) => { if (typeof v === 'number' && !Number.isFinite(v)) throw new Error('Non-finite number'); if (v && typeof v === 'object') for (const item of Object.values(v)) finite(item); };
  finite(result); return result;
}

async function bytes(file, max = MAX_JSON) {
  const s = await lstat(file);
  if (!s.isFile() || s.isSymbolicLink() || s.size > max) throw new Error('Expected bounded regular file');
  const b = await readFile(file); if (b.length > max) throw new Error('File exceeds size limit'); return b;
}
export async function readJSON(file) { return strictJSON(new TextDecoder('utf-8', { fatal: true }).decode(await bytes(file))); }
const EXCLUDED = new Set(['.git', '.local', 'node_modules', '.svelte-kit', 'build', 'dist', 'coverage', 'test-results', 'playwright-report', '__pycache__']);
export async function sourceDigest(directory) {
  const root = await realpath(directory); const entries = []; let total = 0;
  async function walk(relative) {
    for (const entry of (await readdir(path.join(root, relative))).sort()) {
      if (EXCLUDED.has(entry)) continue;
      if (['.npmrc', '.netrc', '.pypirc', 'id_rsa', 'id_ed25519', 'credentials'].includes(entry) || /\.(?:pem|key|p12|pfx)$/i.test(entry) || ((entry === '.env' || entry.startsWith('.env.') || entry.endsWith('.env')) && !entry.endsWith('.example'))) throw new Error('Credential files must remain outside release source');
      const name = relative ? `${relative}/${entry}` : entry;
      if (!/^[a-zA-Z0-9._/@+()\[\] -]+$/.test(name)) throw new Error('Unsupported source path');
      const stat = await lstat(path.join(root, name));
      if (stat.isSymbolicLink()) throw new Error('Source symlinks are not accepted');
      if (stat.isDirectory()) { await walk(name); continue; }
      if (!stat.isFile() || stat.size > 32 * 1024 * 1024 || entries.length >= 10000 || (total += stat.size) > 512 * 1024 * 1024) throw new Error('Source inventory exceeds bounds');
      entries.push([name, stat.mode & 0o111 ? 'executable' : 'regular', sha256(await readFile(path.join(root, name)))]);
    }
  }
  await walk('');
  return { sha256: sha256(JSON.stringify(entries)), files: entries.length };
}
export async function hashSourceTree(directory) { return (await sourceDigest(directory)).sha256; }

export function newEvidence({ source_sha256, origin = null, images = null, now = new Date() }) {
  return {
    schema_version: 'notitle-launch-v1', generated_at: now.toISOString(),
    release: { source_sha256, origin, schema: 9, images, deployment_manifest_sha256: null, acceptance: null },
    artifacts: {},
    gates: Object.fromEntries(Object.keys(GATES).map((id) => [id, { status: 'pending', reviewer: null, completed_at: null, valid_until: null, artifact_ids: [], details: {} }])),
    approvals: Object.fromEntries(APPROVAL_ROLES.map((role) => [role, { reviewer: null, reviewed_at: null, valid_until: null, artifact_id: null }])),
    defects: [],
    validation_authorization: null,
    rollout: { scope: 'full_v1', initial_stage: 'supervised_cohort', public_enabled: false, cohort_observation: null },
  };
}

function validateShape(e) {
  fields(e, ['schema_version', 'generated_at', 'release', 'artifacts', 'gates', 'approvals', 'defects', 'rollout', 'validation_authorization']);
  if (e.schema_version !== 'notitle-launch-v1' || !time(e.generated_at)) throw new Error('Unsupported evidence version or timestamp');
  fields(e.release, ['source_sha256', 'origin', 'schema', 'images', 'deployment_manifest_sha256', 'acceptance']);
  if (!HASH.test(e.release.source_sha256) || e.release.schema !== 9) throw new Error('Invalid release source or schema');
  if (e.release.origin !== null && !validOrigin(e.release.origin)) throw new Error('Invalid release origin');
  if (e.release.images !== null && !digestImages(e.release.images)) throw new Error('Invalid immutable release images');
  if (e.release.deployment_manifest_sha256 !== null && !HASH.test(e.release.deployment_manifest_sha256)) throw new Error('Invalid deployment manifest digest');
  if (e.release.acceptance !== null) {
    fields(e.release.acceptance, ['origin', 'images', 'deployment_manifest_sha256']);
    if (!validOrigin(e.release.acceptance.origin) || !/^(staging|load)\./.test(new URL(e.release.acceptance.origin).hostname) || !digestImages(e.release.acceptance.images) || !HASH.test(e.release.acceptance.deployment_manifest_sha256)) throw new Error('Invalid isolated acceptance deployment binding');
  }
  if (e.validation_authorization !== null) fields(e.validation_authorization, ['authorized_by', 'authorized_at', 'expires_at', 'artifact_id', 'max_total_paise', 'max_purchases', 'max_refunds', 'scope']);
  if (!isObject(e.artifacts) || Object.keys(e.artifacts).length > 256) throw new Error('Invalid artifact inventory');
  for (const [id, a] of Object.entries(e.artifacts)) { if (!ID.test(id)) throw new Error('Invalid artifact identifier'); fields(a, ['path', 'sha256']); if (typeof a.path !== 'string' || !/^[a-zA-Z0-9_./-]{1,240}$/.test(a.path) || path.isAbsolute(a.path) || a.path.split('/').some((p) => p === '..' || p === '' || p === '.') || !HASH.test(a.sha256)) throw new Error('Invalid artifact path or hash'); }
  fields(e.gates, Object.keys(GATES));
  for (const g of Object.values(e.gates)) {
    fields(g, ['status', 'reviewer', 'completed_at', 'valid_until', 'artifact_ids', 'details']);
    if (!['pending', 'passed', 'failed'].includes(g.status) || !Array.isArray(g.artifact_ids) || g.artifact_ids.length > 40 || new Set(g.artifact_ids).size !== g.artifact_ids.length || !g.artifact_ids.every((id) => typeof id === 'string' && ID.test(id)) || !isObject(g.details)) throw new Error('Invalid gate record');
  }
  fields(e.approvals, APPROVAL_ROLES);
  for (const a of Object.values(e.approvals)) fields(a, ['reviewer', 'reviewed_at', 'valid_until', 'artifact_id']);
  if (!Array.isArray(e.defects) || e.defects.length > 500) throw new Error('Invalid defect inventory');
  for (const d of e.defects) { fields(d, ['id', 'severity', 'state', 'artifact_id']); if (!ID.test(d.id) || !['critical', 'high', 'medium', 'low'].includes(d.severity) || !['open', 'resolved'].includes(d.state) || !ID.test(d.artifact_id)) throw new Error('Invalid defect record'); }
  if (new Set(e.defects.map((d) => d.id)).size !== e.defects.length) throw new Error('Duplicate defect');
  fields(e.rollout, ['scope', 'initial_stage', 'public_enabled', 'cohort_observation']);
  if (typeof e.rollout.public_enabled !== 'boolean') throw new Error('Invalid rollout state');
}

export async function checkEvidence(e, { source, evidenceDirectory, now = new Date(), capacityValidator, overloadValidator, permitValidator, purpose = 'launch' } = {}) {
  validateShape(e);
  if (!['validation', 'launch'].includes(purpose)) throw new Error('Unknown check purpose');
  if (!Number.isFinite(now.valueOf())) throw new Error('Invalid clock');
  const issues = []; const add = (gate, reason) => issues.push({ gate, reason });
  const clock = now.valueOf();
  if (Date.parse(e.generated_at) > clock || clock - Date.parse(e.generated_at) > 90 * DAY) add('release', 'Evidence timestamp is future or older than 90 days');
  const inventory = await sourceDigest(source);
  if (inventory.sha256 !== e.release.source_sha256) add('release', 'Source digest differs from the reviewed release');
  if (!validOrigin(e.release.origin)) add('release', 'Actual HTTPS origin is missing');
  if (!digestImages(e.release.images)) add('release', 'Five immutable deployed image references are required');
  if (!HASH.test(e.release.deployment_manifest_sha256)) add('release', 'Reviewed deployment manifest digest is missing');
  if (!e.release.acceptance) add('release', 'Isolated acceptance origin, image and manifest binding is missing');
  else if (!['api', 'migrate', 'postgres', 'turn'].every((key) => e.release.acceptance.images[key] === e.release.images?.[key])) add('release', 'Acceptance and production service images must match except the reviewed static web build');
  const artifactBytes = new Map(); const root = await realpath(evidenceDirectory);
  let total = 0;
  for (const [id, a] of Object.entries(e.artifacts)) {
    try {
      let cursor = root;
      for (const part of a.path.split('/')) { cursor = path.join(cursor, part); if ((await lstat(cursor)).isSymbolicLink()) throw new Error('Symlink'); }
      const b = await bytes(cursor, 64 * 1024 * 1024);
      if ((total += b.length) > 512 * 1024 * 1024) throw new Error('Artifact budget');
      if (sha256(b) !== a.sha256) throw new Error('Hash mismatch');
      artifactBytes.set(id, b);
    } catch { add('artifacts', `Missing, unsafe, oversized or changed artifact: ${id}`); }
  }
  const report = (g, key = 'report_id') => {
    const id = g.details[key];
    if (!g.artifact_ids.includes(id) || !artifactBytes.has(id)) return null;
    try { return strictJSON(new TextDecoder('utf-8', { fatal: true }).decode(artifactBytes.get(id))); } catch { return null; }
  };
  const permittedRun = (g, r) => {
    const p = report(g, 'permit_id');
    if (!p || !r || !time(r.started_at) || !time(r.ended_at) || r.permit_sha256 !== sha256(artifactBytes.get(g.details.permit_id) ?? '') || p.origin !== r.origin || p.source_sha256 !== r.source_sha256 || !sameImages(p.image_digests, r.image_digests) || Date.parse(p.expires_at) < Date.parse(r.ended_at)) return false;
    try { return !!permitValidator?.(p, Date.parse(r.started_at)); } catch { return false; }
  };
  const measuredRun = (g, r) => {
    const b = report(g, 'baseline_id');
    if (!b || !r || b.schema_version !== 'notitle-load-baseline-v1' || typeof b.run_id !== 'string' || !/^[a-zA-Z0-9_-]{3,128}$/.test(b.run_id) || b.run_id !== r.run_id || b.origin !== r.origin || b.source_sha256 !== r.source_sha256 || !sameImages(b.image_digests, r.image_digests) || r.baseline_sha256 !== sha256(artifactBytes.get(g.details.baseline_id) ?? '') || !time(b.baseline_at) || b.baseline_at !== r.baseline_started_at || !time(b.process_started_at) || Date.parse(b.process_started_at) > Date.parse(b.baseline_at) || !time(r.started_at) || Date.parse(b.baseline_at) > Date.parse(r.started_at) || Date.parse(r.started_at) - Date.parse(b.baseline_at) > 60000) return false;
    try {
      fields(b, ['schema_version', 'run_id', 'origin', 'source_sha256', 'image_digests', 'baseline_at', 'process_started_at', 'server']);
      fields(b.server, ['api', 'message', 'match']);
      for (const [key, scope] of [['api', 'ordinary_api_server'], ['message', 'message_owner_processing'], ['match', 'available_candidate_to_commit_upper_bound']]) {
        const m = b.server[key]; fields(m, ['scope', 'samples', 'buckets']);
        if (m.scope !== scope || !Number.isSafeInteger(m.samples) || m.samples < 0 || !Array.isArray(m.buckets) || m.buckets.length !== 10 || m.buckets.some((n) => !Number.isSafeInteger(n) || n < 0) || m.buckets.reduce((sum, n) => sum + n, 0) !== m.samples) return false;
      }
    } catch { return false; }
    return true;
  };
  const fresh = (start, until, days) => time(start) && time(until) && Date.parse(start) <= clock && Date.parse(until) > clock && Date.parse(until) > Date.parse(start) && Date.parse(until) - Date.parse(start) <= days * DAY && clock - Date.parse(start) <= days * DAY;
  const requireAreas = (id, expected) => { if (!strings(e.gates[id].details.coverage, expected)) add(id, 'Required coverage is incomplete'); };
  for (const [id, days] of Object.entries(GATES)) {
    const g = e.gates[id];
    if (purpose === 'validation' && ['live_money', 'production_smoke'].includes(id) && g.status === 'pending') continue;
    if (g.status !== 'passed') { add(id, `Gate is ${g.status}`); continue; }
    if (!text(g.reviewer) || !fresh(g.completed_at, g.valid_until, days)) add(id, 'Named review and current bounded evidence dates are required');
    if (!g.artifact_ids.length || !g.artifact_ids.every((a) => artifactBytes.has(a))) add(id, 'Verified evidence artifacts are missing');
  }
  for (const [role, a] of Object.entries(e.approvals)) if (!text(a.reviewer) || !fresh(a.reviewed_at, a.valid_until, role === 'counsel' || role === 'accountant' ? 90 : 7) || !artifactBytes.has(a.artifact_id)) add(`approval_${role}`, 'Current named approval artifact is required');
  for (const d of e.defects) { if (!artifactBytes.has(d.artifact_id)) add('defects', 'Defect disposition evidence is missing'); if (d.state === 'open' && ['critical', 'high'].includes(d.severity)) add('defects', `Unresolved ${d.severity} defect: ${d.id}`); }
  for (const lock of ['server/go.sum', 'web/package-lock.json']) { try { const b = await bytes(path.join(source, lock)); if (b.length < 10) throw new Error('Empty lock'); } catch { add('source_dependencies', `Authentic reviewed dependency lock is missing: ${lock}`); } }
  const commands = (id, needed) => {
    const rows = e.gates[id].details.commands;
    if (!Array.isArray(rows) || needed.some((name) => !rows.some((r) => isObject(r) && r.name === name && r.exit_code === 0 && r.skipped === 0 && text(r.command) && artifactBytes.has(r.artifact_id) && e.gates[id].artifact_ids.includes(r.artifact_id))) || new Set(rows?.map((r) => r?.name)).size !== rows?.length) add(id, 'Executed commands, zero exits, no skips and matching log artifacts are required');
  };
  commands('source_dependencies', ['dependency_lock_review', 'dependency_scan', 'secret_scan', 'image_scan']);
  commands('backend_database', ['go_format', 'go_vet', 'go_build', 'go_race', 'go_fuzz', 'postgres_integration', 'migration_up_down_up', 'runtime_least_privilege']);
  commands('web_build', ['svelte_check', 'lint', 'unit', 'build', 'browser']);
  requireAreas('acceptance_matrix', ACCEPTANCE_AREAS);
  requireAreas('security_review', SECURITY_AREAS);
  requireAreas('accessibility_seo', ['320_360_375_390_430', '768_1024_1280_1440_1920', 'intermediate_resize_landscape', 'no_overflow', 'keyboard_screen_reader', 'zoom_200_reflow', 'targets_44px_focus', 'public_initial_html', 'canonical_metadata_sitemap', 'private_noindex_nostore', 'unknown_404', 'cache_bypass', 'lab_web_vitals']);
  requireAreas('restore', RESTORE_AREAS);
  requireAreas('audio_enforcement', ['relay_only_network_proof', 'full_sdp_ice_privacy', 'no_recording', 'explicit_consent', 'late_mic_cleanup', 'credential_refresh_replay', 'supervisor_api_watchdog_failure', 'next_block_delete_revoke', 'restricted_tcp_tls', 'wifi_wifi', 'wifi_cellular', 'cellular_cellular']);
  const audio = e.gates.audio_enforcement.details;
  if (!(Number.isFinite(audio.max_cancel_seconds) && audio.max_cancel_seconds >= 0 && audio.max_cancel_seconds <= 5 && Number.isFinite(audio.max_orphan_seconds) && audio.max_orphan_seconds >= 0 && audio.max_orphan_seconds <= 30)) add('audio_enforcement', 'Measured cancellation <=5s and orphan cleanup <=30s are required');
  const restore = e.gates.restore.details;
  if (!(Number.isFinite(restore.rpo_seconds) && restore.rpo_seconds >= 0 && restore.rpo_seconds <= 900 && Number.isFinite(restore.rto_seconds) && restore.rto_seconds > 0 && restore.rto_seconds <= 14400)) add('restore', 'Measured RPO <=15 minutes and staffed RTO <=4 hours are required');
  const desktop = e.gates.browser_desktop.details.devices;
  if (!Array.isArray(desktop) || ['Chrome', 'Edge', 'Firefox', 'Safari'].some((browser) => !desktop.some((d) => isObject(d) && d.browser === browser && text(d.browser_version) && text(d.os_version) && text(d.os) && (browser !== 'Safari' || d.os === 'macOS') && d.environment === 'supported_desktop' && artifactBytes.has(d.artifact_id) && e.gates.browser_desktop.artifact_ids.includes(d.artifact_id)))) add('browser_desktop', 'Supported desktop Chrome, Edge, Firefox and macOS Safari versioned evidence is required');
  const mobile = e.gates.mobile_real_devices.details.devices;
  if (!Array.isArray(mobile) || [['Android', 'Chrome'], ['iOS', 'Safari']].some(([os, browser]) => !mobile.some((d) => isObject(d) && d.os === os && d.browser === browser && text(d.browser_version) && text(d.os_version) && text(d.hardware) && d.environment === 'physical_device' && strings(d.coverage, MOBILE_AREAS) && artifactBytes.has(d.artifact_id) && e.gates.mobile_real_devices.artifact_ids.includes(d.artifact_id)))) add('mobile_real_devices', 'Physical Android Chrome and iPhone Safari with versions and complete mobile workflows are required');
  for (const [id, scenario] of [['load_a', 'A'], ['load_b', 'B']]) {
    const r = report(e.gates[id]);
    let verdict; try { verdict = capacityValidator?.(r); } catch { verdict = null; }
    if (!r || r.scenario !== scenario || !verdict?.passed || !permittedRun(e.gates[id], r) || !measuredRun(e.gates[id], r) || r.origin !== e.release.acceptance?.origin || r.source_sha256 !== e.release.source_sha256 || !sameImages(r.image_digests, e.release.acceptance?.images) || !time(r.ended_at) || Date.parse(r.ended_at) > Date.parse(e.gates[id].completed_at) || clock - Date.parse(r.ended_at) > 30 * DAY) add(id, 'Independent capacity validation, recorded run permit/baseline, fresh measurements and exact acceptance release binding are required');
  }
  const overloaded = report(e.gates.overload);
  let overloadVerdict; try { overloadVerdict = overloadValidator?.(overloaded); } catch { overloadVerdict = null; }
  if (!overloaded || !overloadVerdict?.passed || !permittedRun(e.gates.overload, overloaded) || !measuredRun(e.gates.overload, overloaded) || overloaded.origin !== e.release.acceptance?.origin || overloaded.source_sha256 !== e.release.source_sha256 || !sameImages(overloaded.image_digests, e.release.acceptance?.images) || !time(overloaded.ended_at) || Date.parse(overloaded.ended_at) > Date.parse(e.gates.overload.completed_at) || clock - Date.parse(overloaded.ended_at) > 30 * DAY) add('overload', 'Independent 400-offered overload validation, recorded run permit/baseline, fresh measurements and exact acceptance release binding are required');
  const dense = e.gates.dense_friends.details;
  if (!(dense.accounts === 200 && dense.friends_per_account === 100 && dense.retained_relationships === 20000 && Number.isFinite(dense.duration_seconds) && dense.duration_seconds >= 1800 && Number.isFinite(dense.p95_owner_ms) && dense.p95_owner_ms >= 0 && dense.p95_owner_ms < 100 && Number.isFinite(dense.minimum_memory_headroom_percent) && dense.minimum_memory_headroom_percent >= 25 && dense.minimum_memory_headroom_percent <= 100 && dense.rejected_legitimate_operations === 0 && strings(dense.coverage, ['normal_typing', 'rate_limit_boundary', 'text_ack', 'presence_refresh_reconnect', 'p50_p95_p99', 'cpu_rss_allocations', 'bounded_queues']))) add('dense_friends', 'Dense 200-account/20,000-relationship performance evidence is incomplete');
  requireAreas('rollback_drain', ['maintenance_admission_closed', 'two_minute_deadline', 'existing_sessions_notified', 'relay_revoked_before_stop', 'webhooks_grievances_remain', 'single_owner', 'schema_compatible_code_rollback', 'no_old_database_restore', 'reopen_smoke']);
  const manifest = report(e.gates.deploy_security);
  const featureKeys = ['IDENTITY_ENABLED', 'REALTIME_ENABLED', 'SAFETY_ENABLED', 'ADMIN_ENABLED', 'FRIENDS_ENABLED', 'AUDIO_ENABLED', 'OPERATIONS_ENABLED', 'PAYMENTS_ENABLED', 'CHECKOUT_ENABLED'];
  if (!manifest || sha256(artifactBytes.get(e.gates.deploy_security.details.report_id) ?? '') !== e.release.deployment_manifest_sha256 || manifest.schema_version !== 1 || manifest.database_schema !== 9 || manifest.environment !== 'production' || manifest.source_sha256 !== e.release.source_sha256 || manifest.origin !== e.release.origin || !sameImages(manifest.images, e.release.images) || manifest.single_owner !== true || manifest.secret_files_checked !== true || !HASH.test(manifest.compose_sha256) || !HASH.test(manifest.relay_compose_sha256) || (purpose === 'validation' ? manifest.stage !== 'validation' || manifest.ingress_mode !== 'cohort' || manifest.validation_source_restricted !== true : !['cohort', 'public'].includes(manifest.stage) || manifest.ingress_mode !== manifest.stage) || !featureKeys.every((key) => manifest.feature_flags?.[key] === true)) add('deploy_security', 'Validated full-V1 app/relay manifest, secrets check and purpose-specific ingress stage are required');
  const acceptance = report(e.gates.deploy_security, 'acceptance_manifest_id');
  if (!acceptance || acceptance.schema_version !== 1 || acceptance.environment !== 'isolated_acceptance' || acceptance.database_schema !== 9 || acceptance.source_sha256 !== e.release.source_sha256 || acceptance.origin !== e.release.acceptance?.origin || !sameImages(acceptance.images, e.release.acceptance?.images) || sha256(artifactBytes.get(e.gates.deploy_security.details.acceptance_manifest_id) ?? '') !== e.release.acceptance?.deployment_manifest_sha256 || acceptance.single_owner !== true || acceptance.secret_files_checked !== true || !HASH.test(acceptance.compose_sha256) || !HASH.test(acceptance.relay_compose_sha256) || !featureKeys.every((key) => acceptance.feature_flags?.[key] === true)) add('deploy_security', 'Reviewed actual isolated acceptance manifest with source, images and secret checks is required');
  if (!artifactBytes.has(e.gates.deploy_security.details.build_difference_review_id) || !e.gates.deploy_security.artifact_ids.includes(e.gates.deploy_security.details.build_difference_review_id) || !strings(e.gates.deploy_security.details.allowed_build_differences, ['web_canonical_origin', 'web_release_mode', 'cashfree_sandbox']) || e.gates.deploy_security.details.allowed_build_differences.length !== 3) add('deploy_security', 'Reviewed acceptance-to-production canonical/build-mode/payment-sandbox differences are required');
  requireAreas('domain_tls', ['domain_control', 'alternate_redirect', 'edge_full_strict', 'origin_firewall', 'private_admin', 'turn_dns_only', 'turn_cert_reload', 'dnssec_caa_review', 'ipv6_disposition']);
  requireAreas('external_monitor', ['lost_app_host_detected', 'primary_device_received', 'backup_device_received', 'human_ack', 'bounded_retry_dead_letter', 'fresh_wal_deletion_hold_recovery']);
  const drills = e.gates.operator_drills.details;
  if (!text(drills.primary) || !text(drills.backup) || drills.primary === drills.backup || !strings(drills.coverage, ['critical_safety', 'failed_payment', 'privacy_request', 'lost_host', 'backup_independent', 'urgent_timing', 'mfa_recovery'])) add('operator_drills', 'Distinct trained primary/backup and all timed drills are required');
  requireAreas('legal_privacy', ['actual_entity_contacts', 'brand_review', 'it_dpdp_certin_effective_dates', 'age_approach', 'retention_no_hidden_archive', 'notices_content_digest', 'appeals', 'grievance_officer', 'processors_india', 'upcoming_duties']);
  requireAreas('tax_refunds', ['classification', 'inclusive_prices', 'invoices', 'financial_retention', 'fees_refund_accounting', 'refund_policy', 'annual_economics', 'annual_later_refund_route']);
  requireAreas('merchant_approval', ['written_actual_category', 'pseudonymous_guests', 'random_text_audio', 'friends', 'paid_gender_preferences', 'checkout_data_notifications', 'activated_merchant', 'annual_refund_route']);
  const live = e.gates.live_money.details;
  if (purpose === 'launch' || e.gates.live_money.status === 'passed') {
    if (!(text(live.authorized_by) && time(live.authorized_at) && time(live.started_at) && time(live.settlement_verified_at) && Date.parse(live.authorized_at) <= Date.parse(live.started_at) && Date.parse(live.started_at) < Date.parse(live.settlement_verified_at) && Date.parse(live.settlement_verified_at) <= clock && strings(live.coverage, ['authorized_live_purchase', 'capture', 'webhook', 'single_entitlement', 'receipt', 'refund', 'bank_credit', 'settlement_reconciled']) && artifactBytes.has(live.authorization_artifact_id) && e.gates.live_money.artifact_ids.includes(live.authorization_artifact_id))) add('live_money', 'Prior explicit authorization and live capture/refund/bank/settlement evidence are required');
  }
  if (purpose === 'launch' || e.gates.production_smoke.status === 'passed') requireAreas('production_smoke', ['two_browser_conversation', 'report_block', 'cross_network_audio', 'login_recovery', 'payment_status', 'jobs_ready', 'private_admin_denied', 'mobile_desktop']);
  if (purpose === 'validation') {
    const a = e.validation_authorization;
    if (!a || a.authorized_by !== e.approvals.business.reviewer || !fresh(a.authorized_at, a.expires_at, 1) || !artifactBytes.has(a.artifact_id) || !Number.isSafeInteger(a.max_total_paise) || a.max_total_paise < 1 || !Number.isSafeInteger(a.max_purchases) || a.max_purchases < 1 || a.max_purchases > 5 || !Number.isSafeInteger(a.max_refunds) || a.max_refunds < 1 || a.max_refunds > 5 || a.scope !== 'production_validation_only' || e.rollout.public_enabled) add('validation_authorization', 'Prior named-owner authorization with <=24-hour expiry, bounded money/actions and private validation scope is required');
  }
  const cost = e.gates.cost_caps.details;
  if (!(Number.isInteger(cost.monthly_cap_inr) && cost.monthly_cap_inr > 0 && Number.isInteger(cost.annual_cap_inr) && cost.annual_cap_inr >= cost.monthly_cap_inr * 12 && strings(cost.coverage, ['compute', 'storage_logs_backups', 'transfer', 'gateway_fees_tax', 'human_coverage', 'cash_reserve', '140_connections_18_calls_review']))) add('cost_caps', 'Reviewed INR budget, fees, transfer and human operating costs are required');
  const scope = e.gates.owner_scope.details;
  if (!(scope.scope === 'full_v1' && scope.initial_stage === 'supervised_cohort' && Number.isInteger(scope.cohort_connection_cap) && scope.cohort_connection_cap > 0 && scope.cohort_connection_cap <= 200 && Number.isInteger(scope.cohort_call_cap) && scope.cohort_call_cap > 0 && scope.cohort_call_cap <= 25 && text(scope.active_hours) && text(scope.rollback_owner) && strings(scope.features, ['identity', 'realtime', 'safety', 'friends', 'audio', 'payments', 'checkout', 'operations']))) add('owner_scope', 'Deliberate full-V1 supervised cohort, bounded caps, hours and rollback owner are required');
  if (e.rollout.scope !== 'full_v1' || e.rollout.initial_stage !== 'supervised_cohort') add('rollout', 'Limited feature scope cannot establish full V1');
  // Public enablement is an external human action, never a validator side effect.
  let broader = false;
  const cohort = e.rollout.cohort_observation;
  if (cohort !== null) {
    try { fields(cohort, ['reviewer', 'started_at', 'completed_at', 'artifact_id', 'coverage', 'approved_by', 'approved_at']); } catch { add('rollout', 'Malformed cohort observation'); }
    broader = isObject(cohort) && text(cohort.reviewer) && cohort.approved_by === e.approvals.business.reviewer && time(cohort.started_at) && time(cohort.completed_at) && time(cohort.approved_at) && Date.parse(cohort.completed_at) > Date.parse(cohort.started_at) && Date.parse(cohort.approved_at) >= Date.parse(cohort.completed_at) && Date.parse(cohort.approved_at) <= clock && clock - Date.parse(cohort.completed_at) <= 7 * DAY && artifactBytes.has(cohort.artifact_id) && strings(cohort.coverage, ['full_operating_cycle', 'payments_reconciled', 'urgent_case_coverage', 'capacity_within_tested_limits', 'cost_backlog_review', 'no_critical_defects']);
    if (!broader) add('rollout', 'A full supervised operating cycle and owner review are required before broader acquisition');
  }
  if (manifest?.stage === 'public' && !broader) add('rollout', 'Public ingress requires the completed supervised operating cycle before a new launch permit');
  return { schema_version: 'notitle-launch-check-v1', checked_at: now.toISOString(), purpose, state: issues.length ? 'blocked' : purpose === 'validation' ? 'ready_for_controlled_validation' : broader ? 'ready_for_broader_acquisition' : 'ready_for_owner_enablement', eligible_for_controlled_validation: issues.length === 0 && purpose === 'validation', eligible_for_supervised_cohort: issues.length === 0 && purpose === 'launch', eligible_for_broader_acquisition: issues.length === 0 && purpose === 'launch' && broader, public_enabled: e.rollout.public_enabled, pending_gates: Object.keys(e.gates).filter((id) => e.gates[id].status === 'pending'), release: e.release, source_files: inventory.files, issues, assurance: 'Checks structure, binding, freshness, thresholds and supplied evidence bytes. It does not authenticate authors, prove execution, grant legal or merchant approval, or enable production.' };
}
