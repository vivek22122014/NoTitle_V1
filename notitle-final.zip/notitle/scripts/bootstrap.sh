#!/usr/bin/env bash
set -euo pipefail
umask 077
source "$(dirname -- "$0")/lib.sh"
mode=${1:-dev}
case "$mode" in dev|static|prepare) ;; *) echo 'Usage: ./scripts/bootstrap.sh [dev|static|prepare]' >&2; exit 2;; esac
require_docker
docker_source "$NODE_IMAGE" "" node scripts/init-local.mjs
"$ROOT/scripts/bootstrap-backend-lock.sh"
"$ROOT/scripts/bootstrap-web-lock.sh"
require_locks
docker_source "$NODE_IMAGE" "" node scripts/audit.mjs --release
if [ "$mode" = prepare ]; then
  echo 'Prepared local secrets and real dependency locks. Review changed source/lock files; no application containers started.'
  exit 0
fi
"$ROOT/scripts/start.sh" "$mode"
