import test from 'node:test';
import assert from 'node:assert/strict';
import { BOUNDS, histogramMetric, memoryBytes, collectObservation, captureBaseline, subtractHistogram } from '../load-collect.mjs';
const now = Date.parse('2026-10-09T00:00:00Z');
const metric = (scope = 'ordinary_api_server') => ({ scope, samples: 100, buckets: [0, 0, 0, 95, 5, 0, 0, 0, 0, 0] });
const permit = { origin: 'https://staging.fixture.invalid', source_sha256: 'a'.repeat(64), image_digests: Object.fromEntries(['api','web','migrate','postgres','turn'].map((k) => [k, 'fixture.invalid/' + k + '@sha256:' + 'a'.repeat(64)])) };
function baselineRecord(metrics) { return { sha256: 'b'.repeat(64), value: { schema_version: 'notitle-load-baseline-v1', ...permit, run_id: 'synthetic-run', baseline_at: new Date(now - 10000).toISOString(), process_started_at: metrics.window_started_at, server: Object.fromEntries(Object.entries(metrics.server).map(([k, m]) => [k, { scope: m.scope, samples: 0, buckets: BOUNDS.map(() => 0) }])) } }; }
const mem = 'MemTotal:       4194304 kB\nMemAvailable:   2097152 kB\n';
function inputs() { return { metrics: { sampled_at: new Date(now - 2000).toISOString(), window_started_at: new Date(now - 60000).toISOString(), server: { api: metric(), message: metric('message_owner_processing'), match: metric('selected_pair_commit_processing') }, process: { go_heap_bytes: 1234, goroutines: 5, secret: 'not-exported' } }, jobs: { ...permit, application_host: true, observed_at: new Date(now - 1000).toISOString(), queues: { bounded: true, ungranted_captures: 0, overdue_jobs: 0, goroutines_limit: 100 }, workload: { payment_job: 1, backup: 1, moderation: 1, safety_event: 1 } } }; }
test('fixed noncumulative histogram uses conservative nearest-rank bucket bound, not invented midpoint', () => {
  assert.deepEqual(histogramMetric(metric()), { scope: 'ordinary_api_server', samples: 100, p95_ms: 25 });
  assert.equal(histogramMetric({ ...metric(), buckets: BOUNDS.map((_, i) => i === 9 ? 100 : 0) }).p95_ms, null);
  assert.throws(() => histogramMetric({ ...metric(), samples: 101 }));
  assert.throws(() => histogramMetric({ ...metric(), buckets: [-1, 1] }));
});
test('MemAvailable includes actual host headroom, and malformed/missing/duplicate fields reject', () => {
  assert.deepEqual(memoryBytes(mem), { total_bytes: 4294967296, available_bytes: 2147483648 });
  for (const value of ['', mem + 'MemTotal: 12 kB\n', 'MemTotal: 1 kB\nMemAvailable: 2 kB\n']) assert.throws(() => memoryBytes(value));
});
test('collector retains original sample age and narrow metric scope; it does not export arbitrary fields', () => {
  const { metrics, jobs } = inputs(); const result = collectObservation(permit, metrics, jobs, mem, baselineRecord(metrics), now);
  assert.equal(result.observed_at, metrics.sampled_at); assert.equal(result.window_started_at, baselineRecord(metrics).value.baseline_at);
  assert.equal(result.server.match.scope, 'selected_pair_commit_processing'); assert.equal(JSON.stringify(result).includes('not-exported'), false);
});
test('collector refuses stale/wrong-host evidence and rejects unbound matching overrides', () => {
  const { metrics, jobs } = inputs();
  assert.throws(() => collectObservation(permit, metrics, jobs, mem, baselineRecord(metrics), now + 31000));
  assert.throws(() => collectObservation(permit, metrics, { ...jobs, application_host: false }, mem, baselineRecord(metrics), now));
  assert.throws(() => collectObservation(permit, metrics, { ...jobs, source_sha256: '' }, mem, baselineRecord(metrics), now));
  assert.throws(() => collectObservation(permit, metrics, { ...jobs, match_commit: metric('browser_rtt') }, mem, baselineRecord(metrics), now));
  assert.throws(() => collectObservation(permit, metrics, { ...jobs, match_commit: metric('available_candidate_to_commit_upper_bound') }, mem, baselineRecord(metrics), now));
  metrics.server.match = metric('available_candidate_to_commit_upper_bound');
  assert.equal(collectObservation(permit, metrics, jobs, mem, baselineRecord(metrics), now).server.match.scope, 'available_candidate_to_commit_upper_bound');
});

test('baseline subtraction exposes a new latency collapse hidden by long healthy history', () => {
  const old = { scope: 'ordinary_api_server', samples: 1000000, buckets: [1000000,0,0,0,0,0,0,0,0,0] };
  const current = { scope: old.scope, samples: 1000100, buckets: [1000000,0,0,0,0,0,0,0,100,0] };
  assert.equal(histogramMetric(current).p95_ms, 1);
  assert.deepEqual(subtractHistogram(current, old), { scope: old.scope, samples: 100, p95_ms: 1000 });
  assert.throws(() => subtractHistogram(old, current));
  assert.throws(() => subtractHistogram({ ...current, scope: 'changed' }, old));
  const regressed = { ...current, buckets: [999999,101,0,0,0,0,0,0,0,0] }; assert.throws(() => subtractHistogram(regressed, old));
});
test('baseline capture binds a fresh post-ready snapshot, exact release, and process identity', () => {
  const { metrics, jobs } = inputs(); const ready = { ...permit, run_id: 'synthetic-run', started_at: null, baseline_requested_at: new Date(now - 5000).toISOString() };
  const value = captureBaseline(permit, metrics, ready, now); assert.equal(value.baseline_at, metrics.sampled_at);
  assert.throws(() => captureBaseline(permit, metrics, { ...ready, baseline_requested_at: new Date(now - 61000).toISOString() }, now));
  assert.throws(() => captureBaseline(permit, metrics, { ...ready, baseline_requested_at: new Date(now).toISOString() }, now));
  assert.throws(() => captureBaseline(permit, metrics, { ...ready, source_sha256: '' }, now));
  assert.throws(() => captureBaseline(permit, metrics, { ...ready, started_at: new Date(now).toISOString() }, now));
  const record = { sha256: 'b'.repeat(64), value };
  assert.throws(() => collectObservation(permit, { ...metrics, window_started_at: new Date(now - 1000).toISOString() }, jobs, mem, record, now));
  assert.throws(() => collectObservation(permit, metrics, jobs, mem, { ...record, value: { ...value, source_sha256: '' } }, now));
});
