import test from 'node:test';
import assert from 'node:assert/strict';
import { chmod, lstat, mkdtemp, mkdir, readFile, rm, symlink, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { ACCEPTANCE_AREAS, APPROVAL_ROLES, GATES, IMAGE_KEYS, MOBILE_AREAS, RESTORE_AREAS, SECURITY_AREAS, checkEvidence, newEvidence, readJSON, sha256, sourceDigest, strictJSON } from '../launch-evidence-lib.mjs';
import { main, saveExclusive } from '../launch-evidence.mjs';
import { validatePermit } from '../load-contract.mjs';

const NOW = new Date('2026-10-09T12:00:00Z');
const completed = '2026-10-09T10:00:00Z';
const expires = '2026-10-10T10:00:00Z';
const clone = (v) => structuredClone(v);

async function fixture(t) {
  const root = await mkdtemp(path.join(os.tmpdir(), 'notitle-launch-unit-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const source = path.join(root, 'source'); const evidenceDirectory = path.join(root, 'evidence');
  await mkdir(path.join(source, 'server'), { recursive: true }); await mkdir(path.join(source, 'web')); await mkdir(evidenceDirectory);
  await writeFile(path.join(source, 'server/go.sum'), 'unit-fixture-not-an-authentic-production-lock\n');
  await writeFile(path.join(source, 'web/package-lock.json'), '{"fixture":true,"lockfileVersion":3}\n');
  const images = Object.fromEntries(IMAGE_KEYS.map((k, i) => [k, `registry.notitle.test/${k}@sha256:${String(i + 1).repeat(64)}`]));
  const e = newEvidence({ source_sha256: (await sourceDigest(source)).sha256, origin: 'https://notitle-fixture.org', images, now: NOW });
  e.release.acceptance = { origin: 'https://staging.notitle-fixture.org', images: { ...images, web: `registry.notitle.test/web@sha256:${'6'.repeat(64)}` }, deployment_manifest_sha256: '0'.repeat(64) };
  const artifact = async (id, value) => { const body = typeof value === 'string' ? value : JSON.stringify(value); await writeFile(path.join(evidenceDirectory, `${id}.json`), body); e.artifacts[id] = { path: `${id}.json`, sha256: sha256(body) }; };
  await artifact('review', 'Synthetic unit-test attestation. Never deploy.');
  for (const id of Object.keys(GATES)) Object.assign(e.gates[id], { status: 'passed', reviewer: 'Fixture Reviewer', completed_at: completed, valid_until: expires, artifact_ids: ['review'] });
  for (const role of APPROVAL_ROLES) Object.assign(e.approvals[role], { reviewer: `Fixture ${role}`, reviewed_at: completed, valid_until: expires, artifact_id: 'review' });
  const command = (name) => ({ name, command: `fixture ${name}`, exit_code: 0, skipped: 0, artifact_id: 'review' });
  e.gates.source_dependencies.details.commands = ['dependency_lock_review', 'dependency_scan', 'secret_scan', 'image_scan'].map(command);
  e.gates.backend_database.details.commands = ['go_format', 'go_vet', 'go_build', 'go_race', 'go_fuzz', 'postgres_integration', 'migration_up_down_up', 'runtime_least_privilege'].map(command);
  e.gates.web_build.details.commands = ['svelte_check', 'lint', 'unit', 'build', 'browser'].map(command);
  e.gates.acceptance_matrix.details.coverage = ACCEPTANCE_AREAS;
  e.gates.security_review.details.coverage = SECURITY_AREAS;
  e.gates.accessibility_seo.details.coverage = ['320_360_375_390_430', '768_1024_1280_1440_1920', 'intermediate_resize_landscape', 'no_overflow', 'keyboard_screen_reader', 'zoom_200_reflow', 'targets_44px_focus', 'public_initial_html', 'canonical_metadata_sitemap', 'private_noindex_nostore', 'unknown_404', 'cache_bypass', 'lab_web_vitals'];
  e.gates.restore.details = { coverage: RESTORE_AREAS, rpo_seconds: 900, rto_seconds: 14400 };
  e.gates.audio_enforcement.details = { coverage: ['relay_only_network_proof', 'full_sdp_ice_privacy', 'no_recording', 'explicit_consent', 'late_mic_cleanup', 'credential_refresh_replay', 'supervisor_api_watchdog_failure', 'next_block_delete_revoke', 'restricted_tcp_tls', 'wifi_wifi', 'wifi_cellular', 'cellular_cellular'], max_cancel_seconds: 5, max_orphan_seconds: 30 };
  e.gates.browser_desktop.details.devices = ['Chrome', 'Edge', 'Firefox', 'Safari'].map((browser) => ({ browser, browser_version: '123.0', os: browser === 'Safari' ? 'macOS' : 'Linux', os_version: 'unit-1', environment: 'supported_desktop', artifact_id: 'review' }));
  e.gates.mobile_real_devices.details.devices = [['Android', 'Chrome'], ['iOS', 'Safari']].map(([os, browser]) => ({ os, browser, browser_version: '123.0', os_version: 'unit-1', hardware: 'Unit physical device fixture', environment: 'physical_device', coverage: MOBILE_AREAS, artifact_id: 'review' }));
  await artifact('load_permit', { schema_version: 'notitle-load-permit-v1', origin: e.release.acceptance.origin, image_digests: e.release.acceptance.images, source_sha256: e.release.source_sha256, isolated_target: true, no_real_users: true, synthetic_accounts_only: true, no_live_money: true, approved_by: 'Fixture Owner', not_before: '2026-10-09T00:00:00Z', expires_at: expires, maximum_seconds: 21600, maximum_offered: 400, maximum_connected: 200, maximum_calls: 25, relay_hosts: ['turn.notitle-fixture.org'] });
  for (const [id, scenario] of [['load_a', 'A'], ['load_b', 'B'], ['overload', 'overload']]) {
    const baselineId = `${id}_baseline`;
    await artifact(baselineId, { schema_version: 'notitle-load-baseline-v1', run_id: `${id}_unit_run`, origin: e.release.acceptance.origin, source_sha256: e.release.source_sha256, image_digests: e.release.acceptance.images, baseline_at: '2026-10-09T03:59:59.000Z', process_started_at: '2026-10-09T03:00:00.000Z', server: Object.fromEntries([['api', 'ordinary_api_server'], ['message', 'message_owner_processing'], ['match', 'available_candidate_to_commit_upper_bound']].map(([key, scope]) => [key, { scope, samples: 0, buckets: Array(10).fill(0) }])) });
    await artifact(id, { unit_fixture: true, scenario, run_id: `${id}_unit_run`, origin: e.release.acceptance.origin, source_sha256: e.release.source_sha256, image_digests: e.release.acceptance.images, permit_sha256: e.artifacts.load_permit.sha256, baseline_sha256: e.artifacts[baselineId].sha256, baseline_started_at: '2026-10-09T03:59:59.000Z', started_at: '2026-10-09T04:00:00Z', ended_at: completed, status: 'passed' });
    e.gates[id].details.report_id = id; e.gates[id].details.permit_id = 'load_permit'; e.gates[id].details.baseline_id = baselineId; e.gates[id].artifact_ids.push(id, 'load_permit', baselineId);
  }
  e.gates.dense_friends.details = { accounts: 200, friends_per_account: 100, retained_relationships: 20000, duration_seconds: 1800, p95_owner_ms: 99, minimum_memory_headroom_percent: 25, rejected_legitimate_operations: 0, coverage: ['normal_typing', 'rate_limit_boundary', 'text_ack', 'presence_refresh_reconnect', 'p50_p95_p99', 'cpu_rss_allocations', 'bounded_queues'] };
  e.gates.rollback_drain.details.coverage = ['maintenance_admission_closed', 'two_minute_deadline', 'existing_sessions_notified', 'relay_revoked_before_stop', 'webhooks_grievances_remain', 'single_owner', 'schema_compatible_code_rollback', 'no_old_database_restore', 'reopen_smoke'];
  await artifact('deployment', { schema_version: 1, database_schema: 9, source_sha256: e.release.source_sha256, environment: 'production', compose_sha256: 'a'.repeat(64), relay_compose_sha256: 'b'.repeat(64), images, origin: e.release.origin, single_owner: true, stage: 'cohort', ingress_mode: 'cohort', validation_source_restricted: false, secret_files_checked: true, feature_flags: Object.fromEntries(['IDENTITY_ENABLED', 'REALTIME_ENABLED', 'SAFETY_ENABLED', 'ADMIN_ENABLED', 'FRIENDS_ENABLED', 'AUDIO_ENABLED', 'OPERATIONS_ENABLED', 'PAYMENTS_ENABLED', 'CHECKOUT_ENABLED'].map((key) => [key, true])) });
  e.release.deployment_manifest_sha256 = e.artifacts.deployment.sha256; e.gates.deploy_security.artifact_ids.push('deployment'); e.gates.deploy_security.details.report_id = 'deployment';
  await artifact('acceptance_deployment', { schema_version: 1, database_schema: 9, source_sha256: e.release.source_sha256, environment: 'isolated_acceptance', compose_sha256: 'c'.repeat(64), relay_compose_sha256: 'b'.repeat(64), images: e.release.acceptance.images, origin: e.release.acceptance.origin, single_owner: true, secret_files_checked: true, feature_flags: Object.fromEntries(['IDENTITY_ENABLED', 'REALTIME_ENABLED', 'SAFETY_ENABLED', 'ADMIN_ENABLED', 'FRIENDS_ENABLED', 'AUDIO_ENABLED', 'OPERATIONS_ENABLED', 'PAYMENTS_ENABLED', 'CHECKOUT_ENABLED'].map((key) => [key, true])) });
  e.release.acceptance.deployment_manifest_sha256 = e.artifacts.acceptance_deployment.sha256; e.gates.deploy_security.artifact_ids.push('acceptance_deployment'); e.gates.deploy_security.details.acceptance_manifest_id = 'acceptance_deployment'; e.gates.deploy_security.details.build_difference_review_id = 'review'; e.gates.deploy_security.details.allowed_build_differences = ['web_canonical_origin', 'web_release_mode', 'cashfree_sandbox'];
  e.gates.domain_tls.details.coverage = ['domain_control', 'alternate_redirect', 'edge_full_strict', 'origin_firewall', 'private_admin', 'turn_dns_only', 'turn_cert_reload', 'dnssec_caa_review', 'ipv6_disposition'];
  e.gates.external_monitor.details.coverage = ['lost_app_host_detected', 'primary_device_received', 'backup_device_received', 'human_ack', 'bounded_retry_dead_letter', 'fresh_wal_deletion_hold_recovery'];
  e.gates.operator_drills.details = { primary: 'Operator Primary', backup: 'Operator Backup', coverage: ['critical_safety', 'failed_payment', 'privacy_request', 'lost_host', 'backup_independent', 'urgent_timing', 'mfa_recovery'] };
  e.gates.legal_privacy.details.coverage = ['actual_entity_contacts', 'brand_review', 'it_dpdp_certin_effective_dates', 'age_approach', 'retention_no_hidden_archive', 'notices_content_digest', 'appeals', 'grievance_officer', 'processors_india', 'upcoming_duties'];
  e.gates.tax_refunds.details.coverage = ['classification', 'inclusive_prices', 'invoices', 'financial_retention', 'fees_refund_accounting', 'refund_policy', 'annual_economics', 'annual_later_refund_route'];
  e.gates.merchant_approval.details.coverage = ['written_actual_category', 'pseudonymous_guests', 'random_text_audio', 'friends', 'paid_gender_preferences', 'checkout_data_notifications', 'activated_merchant', 'annual_refund_route'];
  e.gates.live_money.details = { authorized_by: 'Fixture Owner', authorized_at: '2026-10-09T01:00:00Z', started_at: '2026-10-09T02:00:00Z', settlement_verified_at: '2026-10-09T03:00:00Z', authorization_artifact_id: 'review', coverage: ['authorized_live_purchase', 'capture', 'webhook', 'single_entitlement', 'receipt', 'refund', 'bank_credit', 'settlement_reconciled'] };
  e.gates.production_smoke.details.coverage = ['two_browser_conversation', 'report_block', 'cross_network_audio', 'login_recovery', 'payment_status', 'jobs_ready', 'private_admin_denied', 'mobile_desktop'];
  e.gates.cost_caps.details = { monthly_cap_inr: 4100, annual_cap_inr: 49200, coverage: ['compute', 'storage_logs_backups', 'transfer', 'gateway_fees_tax', 'human_coverage', 'cash_reserve', '140_connections_18_calls_review'] };
  e.gates.owner_scope.details = { scope: 'full_v1', initial_stage: 'supervised_cohort', cohort_connection_cap: 20, cohort_call_cap: 5, active_hours: 'Owner-approved staffed hours', rollback_owner: 'Fixture Operator', features: ['identity', 'realtime', 'safety', 'friends', 'audio', 'payments', 'checkout', 'operations'] };
  const opts = { source, evidenceDirectory, now: NOW, capacityValidator: (r) => ({ passed: r?.unit_fixture === true }), overloadValidator: (r) => ({ passed: r?.unit_fixture === true }), permitValidator: validatePermit };
  return { root, source, evidenceDirectory, e, opts, artifact };
}

test('duplicate, malformed, non-finite and trailing JSON cannot override reviewed data', () => {
  for (const bad of ['{"x":1,"x":2}', '{"a":{"x":1,"x":2}}', '{"\\u0078":1,"x":2}', '{"x":1e999}', '{"x":1} false', '{"x":}', '[1,]']) assert.throws(() => strictJSON(bad));
  assert.deepEqual(strictJSON('{"a":[1,true,null,"quote\\\""]}'), { a: [1, true, null, 'quote"'] });
});

test('consistent unit evidence is a candidate, never automatic public enablement', async (t) => {
  const { e, opts } = await fixture(t); const result = await checkEvidence(e, opts);
  assert.deepEqual(result.issues, []); assert.equal(result.state, 'ready_for_owner_enablement');
  assert.equal(result.public_enabled, false); assert.equal(result.eligible_for_broader_acquisition, false);
});

test('template preserves all pending gates and no implicit approvals', async (t) => {
  const { e, opts } = await fixture(t);
  const pending = newEvidence({ source_sha256: e.release.source_sha256, now: NOW });
  const result = await checkEvidence(pending, opts);
  assert.equal(result.state, 'blocked');
  for (const id of [...Object.keys(GATES), ...APPROVAL_ROLES.map((r) => `approval_${r}`)]) assert.ok(result.issues.some((i) => i.gate === id), id);
});

test('missing/unknown gates, unknown top-level fields and duplicate defects fail closed', async (t) => {
  const { e, opts } = await fixture(t);
  for (const mutate of [(v) => delete v.gates.load_a, (v) => { v.gates.extra = v.gates.load_a; }, (v) => { v.approved = true; }, (v) => { v.defects = [{ id: 'defect_a', severity: 'critical', state: 'resolved', artifact_id: 'review' }, { id: 'defect_a', severity: 'critical', state: 'resolved', artifact_id: 'review' }]; }]) { const v = clone(e); mutate(v); await assert.rejects(() => checkEvidence(v, opts)); }
});

test('changed source bytes or executable modes invalidate the release binding', async (t) => {
  const { e, opts, source } = await fixture(t);
  await writeFile(path.join(source, 'feature.js'), 'changed');
  assert.ok((await checkEvidence(e, opts)).issues.some((i) => i.gate === 'release'));
  const before = await sourceDigest(source); await chmod(path.join(source, 'feature.js'), 0o755);
  assert.notEqual((await sourceDigest(source)).sha256, before.sha256);
});

test('source inventory ignores generated dependencies and rejects credential files/symlinks', async (t) => {
  const { source } = await fixture(t); const before = await sourceDigest(source);
  await mkdir(path.join(source, 'node_modules')); await writeFile(path.join(source, 'node_modules/ignored'), 'dependency');
  assert.deepEqual(await sourceDigest(source), before);
  for (const name of ['.npmrc', '.netrc', '.pypirc', '.env', '.env.production', 'secret.pem', 'server.key']) { await writeFile(path.join(source, name), 'not-a-real-secret'); await assert.rejects(() => sourceDigest(source)); await rm(path.join(source, name)); }
  await symlink('server/go.sum', path.join(source, 'bad-link')); await assert.rejects(() => sourceDigest(source));
});

test('source inventory includes nested Svelte catch-all and parameter route names', async (t) => {
  const { source } = await fixture(t);
  const before = await sourceDigest(source);
  const catchAll = path.join(source, 'web/src/routes/[...app]');
  const parameter = path.join(source, 'web/src/routes/(private)/[account]');
  await mkdir(catchAll, { recursive: true }); await mkdir(parameter, { recursive: true });
  await writeFile(path.join(catchAll, '+page.svelte'), '<p>Catch-all route fixture</p>');
  await writeFile(path.join(catchAll, '+page.ts'), 'export const prerender = false;\n');
  await writeFile(path.join(parameter, '+page.svelte'), '<p>Parameter route fixture</p>');
  const after = await sourceDigest(source);
  assert.equal(after.files, before.files + 3); assert.notEqual(after.sha256, before.sha256);
  await writeFile(path.join(catchAll, '+page.svelte'), '<p>Changed route fixture</p>');
  assert.notEqual((await sourceDigest(source)).sha256, after.sha256);
});

test('artifact tamper, absence and symlink replacement cannot pass', async (t) => {
  const { e, opts, evidenceDirectory } = await fixture(t);
  const file = path.join(evidenceDirectory, 'review.json'); await writeFile(file, 'altered');
  assert.ok((await checkEvidence(e, opts)).issues.some((i) => i.gate === 'artifacts'));
  await rm(file); assert.ok((await checkEvidence(e, opts)).issues.some((i) => i.gate === 'artifacts'));
  await symlink('load_a.json', file); assert.ok((await checkEvidence(e, opts)).issues.some((i) => i.gate === 'artifacts'));
});

test('artifact traversal and duplicate paths disguised as dot segments are invalid', async (t) => {
  const { e, opts } = await fixture(t);
  for (const p of ['../review.json', '/tmp/review.json', './review.json', 'x/../review.json', 'x//review.json']) { const v = clone(e); v.artifacts.review.path = p; await assert.rejects(() => checkEvidence(v, opts)); }
});

test('expired or future gate and role review records block, including long validity', async (t) => {
  const { e, opts } = await fixture(t);
  for (const mutation of [(v) => { v.gates.load_a.valid_until = NOW.toISOString(); }, (v) => { v.gates.load_a.completed_at = '2026-10-10T10:00:00Z'; }, (v) => { v.gates.load_a.valid_until = '2027-10-09T10:00:00Z'; }, (v) => { v.approvals.business.reviewer = null; }, (v) => { v.approvals.counsel.valid_until = '2026-10-08T10:00:00Z'; }]) { const v = clone(e); mutation(v); assert.equal((await checkEvidence(v, opts)).state, 'blocked'); }
});

test('numeric cancellation, orphan, RPO and RTO limits reject just over the boundary', async (t) => {
  const { e, opts } = await fixture(t);
  for (const [gate, field, value] of [['audio_enforcement', 'max_cancel_seconds', 5.001], ['audio_enforcement', 'max_orphan_seconds', 30.001], ['restore', 'rpo_seconds', 900.001], ['restore', 'rto_seconds', 14400.001], ['dense_friends', 'minimum_memory_headroom_percent', 24.999], ['dense_friends', 'p95_owner_ms', 100]]) { const v = clone(e); v.gates[gate].details[field] = value; assert.ok((await checkEvidence(v, opts)).issues.some((i) => i.gate === gate)); }
});

test('capacity status flags cannot bypass independent validators or image binding', async (t) => {
  const { e, opts, artifact } = await fixture(t);
  let result = await checkEvidence(e, { ...opts, capacityValidator: () => ({ passed: false }), overloadValidator: () => ({ passed: false }) });
  for (const id of ['load_a', 'load_b', 'overload']) assert.ok(result.issues.some((i) => i.gate === id));
  result = await checkEvidence(e, { ...opts, capacityValidator: undefined, overloadValidator: undefined }); assert.equal(result.state, 'blocked');
  await artifact('load_a', { unit_fixture: true, scenario: 'A', origin: e.release.acceptance.origin, source_sha256: e.release.source_sha256, image_digests: { ...e.release.acceptance.images, api: `registry.unit/api@sha256:${'e'.repeat(64)}` }, ended_at: completed, status: 'passed' });
  assert.ok((await checkEvidence(e, opts)).issues.some((i) => i.gate === 'load_a'));
});

test('physical mobile devices and supported desktop Safari cannot be replaced by emulation', async (t) => {
  const { e, opts } = await fixture(t); const v = clone(e);
  v.gates.mobile_real_devices.details.devices[1].environment = 'emulated'; v.gates.browser_desktop.details.devices[3].os = 'Windows';
  const result = await checkEvidence(v, opts);
  for (const id of ['mobile_real_devices', 'browser_desktop']) assert.ok(result.issues.some((i) => i.gate === id));
});

test('skipped runtime tests, missing commands and pending critical defects block', async (t) => {
  const { e, opts } = await fixture(t); const v = clone(e);
  v.gates.backend_database.details.commands[4].skipped = 1; v.gates.web_build.details.commands.pop();
  v.defects.push({ id: 'unresolved_money', severity: 'critical', state: 'open', artifact_id: 'review' });
  const result = await checkEvidence(v, opts);
  for (const id of ['backend_database', 'web_build', 'defects']) assert.ok(result.issues.some((i) => i.gate === id));
});

test('disabled feature scope and retroactive live-payment authorization cannot establish full V1', async (t) => {
  const { e, opts } = await fixture(t); const v = clone(e);
  v.gates.owner_scope.details.features = ['identity']; v.rollout.scope = 'text_only';
  v.gates.live_money.details.authorized_at = '2026-10-09T11:00:00Z';
  const result = await checkEvidence(v, opts);
  for (const id of ['owner_scope', 'rollout', 'live_money']) assert.ok(result.issues.some((i) => i.gate === id));
});

test('broader acquisition requires full cohort-cycle evidence after the initial candidate', async (t) => {
  const { e, opts } = await fixture(t);
  e.rollout.cohort_observation = { reviewer: 'Review Operator', started_at: '2026-10-08T10:00:00Z', completed_at: '2026-10-09T08:00:00Z', artifact_id: 'review', coverage: ['full_operating_cycle', 'payments_reconciled', 'urgent_case_coverage', 'capacity_within_tested_limits', 'cost_backlog_review', 'no_critical_defects'], approved_by: e.approvals.business.reviewer, approved_at: '2026-10-09T09:00:00Z' };
  assert.equal((await checkEvidence(e, opts)).state, 'ready_for_broader_acquisition');
  e.rollout.cohort_observation.approved_at = '2026-10-09T07:00:00Z'; assert.equal((await checkEvidence(e, opts)).state, 'blocked');
});

test('CLI init writes only a pending file and refuses overwrite or output inside source', async (t) => {
  const { source, evidenceDirectory } = await fixture(t); const file = path.join(evidenceDirectory, 'pending.json');
  const result = await main(['init', '--source', source, '--out', file]); assert.equal(result.exitCode, 0);
  const pending = await readJSON(file); assert.ok(Object.values(pending.gates).every((g) => g.status === 'pending'));
  await assert.rejects(() => main(['init', '--source', source, '--out', file]));
  await assert.rejects(() => saveExclusive(path.join(source, 'bad.json'), {}, source));
  await assert.rejects(() => main(['check', '--source', source, '--source', source]));
});

test('CLI permit refuses pending evidence and never writes a permit', async (t) => {
  const { source, evidenceDirectory } = await fixture(t); const evidence = path.join(evidenceDirectory, 'pending.json'); const out = path.join(evidenceDirectory, 'permit.json');
  await main(['init', '--source', source, '--out', evidence]);
  const result = await main(['permit', '--source', source, '--evidence', evidence, '--out', out, '--evidence-ref', 'review_a']);
  assert.equal(result.exitCode, 1); await assert.rejects(() => readFile(out));
});

test('controlled validation requires all pre-live gates, bounded prior authorization and private stage', async (t) => {
  const { e, opts, artifact, evidenceDirectory } = await fixture(t);
  for (const id of ['live_money', 'production_smoke']) e.gates[id] = { status: 'pending', reviewer: null, completed_at: null, valid_until: null, artifact_ids: [], details: {} };
  const deployment = JSON.parse(await readFile(path.join(evidenceDirectory, 'deployment.json'), 'utf8')); deployment.stage = 'validation'; deployment.validation_source_restricted = true;
  await artifact('deployment', deployment); e.release.deployment_manifest_sha256 = e.artifacts.deployment.sha256;
  e.validation_authorization = { authorized_by: e.approvals.business.reviewer, authorized_at: completed, expires_at: expires, artifact_id: 'review', max_total_paise: 100000, max_purchases: 2, max_refunds: 2, scope: 'production_validation_only' };
  const result = await checkEvidence(e, { ...opts, purpose: 'validation' });
  assert.deepEqual(result.issues, []); assert.equal(result.state, 'ready_for_controlled_validation');
  assert.equal(result.eligible_for_supervised_cohort, false); assert.deepEqual(result.pending_gates, ['live_money', 'production_smoke']);
  assert.equal((await checkEvidence(e, opts)).state, 'blocked');
  for (const mutate of [(v) => { v.gates.live_money.status = 'failed'; }, (v) => { v.validation_authorization = null; }, (v) => { v.rollout.public_enabled = true; }, (v) => { v.gates.load_b.status = 'pending'; }]) { const v = clone(e); mutate(v); assert.equal((await checkEvidence(v, { ...opts, purpose: 'validation' })).state, 'blocked'); }
});

test('only reviewed static web variation is allowed between acceptance and production', async (t) => {
  const { e, opts } = await fixture(t);
  for (const key of ['api', 'migrate', 'postgres', 'turn']) { const v = clone(e); v.release.acceptance.images[key] = `registry.unit/${key}@sha256:${'e'.repeat(64)}`; assert.ok((await checkEvidence(v, opts)).issues.some((i) => i.gate === 'release')); }
  const v = clone(e); v.gates.deploy_security.details.build_difference_review_id = 'missing'; assert.equal((await checkEvidence(v, opts)).state, 'blocked');
});

test('all-disabled deployment flags cannot certify full V1', async (t) => {
  const { e, opts, artifact, evidenceDirectory } = await fixture(t);
  const deployment = JSON.parse(await readFile(path.join(evidenceDirectory, 'deployment.json'), 'utf8'));
  deployment.feature_flags.AUDIO_ENABLED = false; await artifact('deployment', deployment); e.release.deployment_manifest_sha256 = e.artifacts.deployment.sha256;
  assert.ok((await checkEvidence(e, opts)).issues.some((i) => i.gate === 'deploy_security'));
});

test('public promotion needs a new matching manifest and completed supervised cycle', async (t) => {
  const { e, opts, artifact, evidenceDirectory } = await fixture(t);
  const deployment = JSON.parse(await readFile(path.join(evidenceDirectory, 'deployment.json'), 'utf8'));
  deployment.stage = 'public'; deployment.ingress_mode = 'public'; await artifact('deployment', deployment); e.release.deployment_manifest_sha256 = e.artifacts.deployment.sha256;
  assert.ok((await checkEvidence(e, opts)).issues.some((i) => i.gate === 'rollout'));
  e.rollout.cohort_observation = { reviewer: 'Review Operator', started_at: '2026-10-08T10:00:00Z', completed_at: '2026-10-09T08:00:00Z', artifact_id: 'review', coverage: ['full_operating_cycle', 'payments_reconciled', 'urgent_case_coverage', 'capacity_within_tested_limits', 'cost_backlog_review', 'no_critical_defects'], approved_by: e.approvals.business.reviewer, approved_at: '2026-10-09T09:00:00Z' };
  assert.equal((await checkEvidence(e, opts)).state, 'ready_for_broader_acquisition');
});

test('fresh signoff cannot refresh old measurements or an unrelated load permit', async (t) => {
  const { e, opts, artifact, evidenceDirectory } = await fixture(t);
  const r = JSON.parse(await readFile(path.join(evidenceDirectory, 'load_a.json'), 'utf8'));
  r.ended_at = '2026-09-01T10:00:00Z'; await artifact('load_a', r);
  assert.ok((await checkEvidence(e, opts)).issues.some((i) => i.gate === 'load_a'));
  r.ended_at = completed; r.permit_sha256 = 'a'.repeat(64); await artifact('load_a', r);
  assert.ok((await checkEvidence(e, opts)).issues.some((i) => i.gate === 'load_a'));
});

test('original counter baseline is required and binds the run, release, window and metric scopes', async (t) => {
  const { e, opts, artifact, evidenceDirectory } = await fixture(t);
  const baseline = await readJSON(path.join(evidenceDirectory, 'load_a_baseline.json'));
  const originalReport = await readJSON(path.join(evidenceDirectory, 'load_a.json'));
  const missing = clone(e); missing.gates.load_a.details.baseline_id = 'absent';
  assert.ok((await checkEvidence(missing, opts)).issues.some((i) => i.gate === 'load_a'));
  for (const mutate of [(b) => { b.run_id = 'different_run'; }, (b) => { b.source_sha256 = 'a'.repeat(64); }, (b) => { b.origin = 'https://staging.other-fixture.org'; }, (b) => { b.image_digests.api = `registry.unit/api@sha256:${'f'.repeat(64)}`; }, (b) => { b.process_started_at = '2026-10-09T04:01:00.000Z'; }, (b) => { b.baseline_at = '2026-10-09T03:58:00.000Z'; }, (b) => { b.server.match.scope = 'selection_scan'; }, (b) => { b.server.api.samples = 1; }]) {
    const changed = clone(baseline); mutate(changed); await artifact('load_a_baseline', changed);
    await artifact('load_a', { ...originalReport, baseline_sha256: e.artifacts.load_a_baseline.sha256 });
    assert.ok((await checkEvidence(e, opts)).issues.some((i) => i.gate === 'load_a'));
  }
});

test('CLI integrates actual report validators and emits only a two-hour protected validation permit', async (t) => {
  const { e, source, artifact, evidenceDirectory } = await fixture(t);
  const start = Date.parse('2026-10-09T04:00:00Z');
  const common = { schema_version: 'notitle-capacity-v1', origin: e.release.acceptance.origin, source_sha256: e.release.source_sha256, image_digests: e.release.acceptance.images, permit_sha256: e.artifacts.load_permit.sha256, media: 'chromium-synthetic-pcm-over-real-turn', termination: 'completed', failures: [], started_at: new Date(start).toISOString(), ended_at: new Date(start + 21600000).toISOString() };
  // Entirely synthetic unit fixtures: these values are never stored in delivery evidence.
  for (const scenario of ['A', 'B']) {
    const rate = scenario === 'A' ? 600 : 1200;
    const baselineId = `load_${scenario.toLowerCase()}_baseline`;
    const baselineSha = e.artifacts[baselineId].sha256;
    const report = { ...common, scenario, run_id: `load_${scenario.toLowerCase()}_unit_run`, baseline_sha256: baselineSha, baseline_started_at: '2026-10-09T03:59:59.000Z', duration_seconds: 21600, samples: Array.from({ length: 721 }, (_, n) => ({ at: new Date(start + n * 30000).toISOString(), connected: 200, waiting: scenario === 'A' ? 100 : 0, text_participants: scenario === 'A' ? 50 : 150, audio_participants: 50, calls: 25, rtp_senders: 50, rtp_receivers: 50, relay_endpoints: 50, nonrelay_endpoints: 0, messages: { offered: n * rate, accepted: n * rate, received: n * rate, delivered: n * rate, errors: 0 }, server_observation_fresh: true, server_baseline_sha256: baselineSha, server_window_started_at: '2026-10-09T03:59:59.000Z', server_observed_at: new Date(start + n * 30000).toISOString(), host: { total_bytes: 4294967296, available_bytes: 2147483648, go_heap_bytes: 100000000, goroutines: 600 }, server: Object.fromEntries([['api', 'ordinary_api_server'], ['message', 'message_owner_processing'], ['match', 'available_candidate_to_commit_upper_bound']].map(([key, scope]) => [key, { scope, samples: 1000 + n, p95_ms: 50 }])), queues: { bounded: true, ungranted_captures: 0, overdue_jobs: 0, goroutines_limit: 2000 } })), call_setup: { attempts: 25, successes: 25, p95_ms: 1000 }, workload: Object.fromEntries(['next', 'reconnect', 'slow_reader', 'login_hash', 'guest_friend_accept', 'payment_job', 'backup', 'moderation', 'safety_event'].map((key) => [key, 1])) };
    await artifact(`load_${scenario.toLowerCase()}`, report);
  }
  await artifact('overload', { ...common, scenario: 'overload', run_id: 'overload_unit_run', baseline_sha256: e.artifacts.overload_baseline.sha256, baseline_started_at: '2026-10-09T03:59:59.000Z', offered: 400, baseline_connected: 200, refused_connections: 200, participant_201_rejected: true, waiter_101_rejected: true, call_26_rejected: true, established_sessions_preserved: true, safety_events_preserved: true, normal_cleanup_ms: 4500, orphan_cleanup_ms: 29000, cleanup_observation_verified: true });
  e.gates.live_money = { status: 'pending', reviewer: null, completed_at: null, valid_until: null, artifact_ids: [], details: {} };
  // Keep genuinely passed smoke evidence rather than changing it back to pending.
  const deployment = JSON.parse(await readFile(path.join(evidenceDirectory, 'deployment.json'), 'utf8'));
  deployment.stage = 'validation'; deployment.validation_source_restricted = true; await artifact('deployment', deployment); e.release.deployment_manifest_sha256 = e.artifacts.deployment.sha256;
  e.validation_authorization = { authorized_by: e.approvals.business.reviewer, authorized_at: completed, expires_at: expires, artifact_id: 'review', max_total_paise: 100000, max_purchases: 2, max_refunds: 2, scope: 'production_validation_only' };
  const evidence = path.join(evidenceDirectory, 'complete-fixture.json'); const permit = path.join(evidenceDirectory, 'permit-fixture.json'); await writeFile(evidence, JSON.stringify(e));
  const result = await main(['permit', '--purpose', 'validation', '--source', source, '--evidence', evidence, '--out', permit, '--evidence-ref', 'unit_test_only'], { now: NOW });
  assert.equal(result.exitCode, 0, JSON.stringify(result.output.issues));
  const p = await readJSON(permit); assert.equal(Date.parse(p.expires_at) - Date.parse(p.approved_at), 7200000); assert.equal(p.purpose, 'validation'); assert.deepEqual(p.limits, { connected: 200, waiting: 100, calls: 25 }); assert.equal(p.deployment_manifest_sha256, e.release.deployment_manifest_sha256); assert.equal((await lstat(permit)).mode & 0o777, 0o400);
  e.gates.production_smoke.details.coverage = []; await writeFile(evidence, JSON.stringify(e));
  const invalid = await main(['check', '--purpose', 'validation', '--source', source, '--evidence', evidence], { now: NOW }); assert.equal(invalid.exitCode, 1);
});
