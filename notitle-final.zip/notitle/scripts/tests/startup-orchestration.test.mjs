import test from 'node:test';
import assert from 'node:assert/strict';
import { copyFile, mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const sourceRoot = fileURLToPath(new URL('../../', import.meta.url));

async function temporary(t) {
  const root = await mkdtemp(path.join(os.tmpdir(), 'notitle-startup-fixture-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const bin = path.join(root, 'bin'); await mkdir(bin);
  return { root, bin, env: { PATH: `${bin}:${path.dirname(process.execPath)}:/usr/bin:/bin` } };
}

async function startupFixture(t) {
  const f = await temporary(t);
  for (const name of ['scripts', 'server', 'web', 'deploy/dev']) await mkdir(path.join(f.root, name), { recursive: true });
  for (const name of ['start.sh', 'compose.sh', 'lib.sh']) await copyFile(path.join(sourceRoot, 'scripts', name), path.join(f.root, 'scripts', name));
  // Sentinel files satisfy only the orchestration precondition. They are not
  // dependency locks and never enter the delivered source or a release build.
  await writeFile(path.join(f.root, 'server/go.sum'), 'orchestration-fixture-only');
  await writeFile(path.join(f.root, 'web/package-lock.json'), 'orchestration-fixture-only');
  await writeFile(path.join(f.root, 'deploy/dev/.env'), 'fixture-only');
  const trace = path.join(f.root, 'docker-calls.jsonl');
  await writeFile(path.join(f.bin, 'docker'), `#!${process.execPath}
const fs = require('node:fs');
const args = process.argv.slice(2);
fs.appendFileSync(process.env.NOTITLE_TEST_DOCKER_TRACE, JSON.stringify(args) + '\\n');
if (args[0] === 'info') process.exit(0);
if (args[0] === 'compose' && args[1] === 'version') { process.stdout.write('2.30.2\\n'); process.exit(0); }
if (args.at(-1) === 'key-init' && process.env.NOTITLE_TEST_KEY_INIT_FAIL === 'true') process.exit(37);
process.exit(0);
`, { mode: 0o755 });
  return { ...f, trace, env: { ...f.env, NOTITLE_TEST_DOCKER_TRACE: trace } };
}

async function composeCalls(trace) {
  return (await readFile(trace, 'utf8')).trim().split('\n').map(JSON.parse).filter((args) => args[0] === 'compose' && args[1] !== 'version').map((args) => {
    const files = args.flatMap((value, index) => value === '-f' ? [args[index + 1]] : []);
    const end = args.lastIndexOf('-f') + 2;
    return { files, action: args.slice(end) };
  });
}

for (const mode of ['dev', 'static']) {
  test(`${mode} startup completes private keys after migration and before no-deps API startup`, async (t) => {
    const f = await startupFixture(t);
    const result = spawnSync('bash', [path.join(f.root, 'scripts/start.sh'), mode], { env: f.env, encoding: 'utf8' });
    assert.equal(result.status, 0, result.stderr);
    const calls = await composeCalls(f.trace);
    assert.deepEqual(calls.map((call) => call.action), [
      ['up', '-d', '--wait', 'postgres'],
      ['run', '--build', '--rm', 'migrate', 'up'],
      ['run', '--rm', '--no-deps', 'key-init'],
      ['up', '-d', '--build', '--no-deps', '--wait', '--wait-timeout', '240', 'api', 'web'],
    ]);
    assert.ok(calls.every((call) => path.basename(call.files.at(-1)) === (mode === 'dev' ? 'fast.yml' : 'static.yml')));
    assert.ok(!calls.some((call) => call.action.includes('down')));
  });

  test(`${mode} startup halts before API/web when private-key preparation fails`, async (t) => {
    const f = await startupFixture(t);
    const result = spawnSync('bash', [path.join(f.root, 'scripts/start.sh'), mode], { env: { ...f.env, NOTITLE_TEST_KEY_INIT_FAIL: 'true' }, encoding: 'utf8' });
    assert.equal(result.status, 37);
    const calls = await composeCalls(f.trace);
    assert.equal(calls.length, 3);
    assert.equal(calls.at(-1).action.at(-1), 'key-init');
    assert.ok(!calls.some((call) => call.action.includes('api') || call.action.includes('web')));
    assert.ok(!result.stdout.includes('is ready at'));
  });
}

test('database role bootstrap keeps password values out of argv and SQL while retaining literal quoting', async (t) => {
  const f = await temporary(t);
  const migration = `synthetic-migration-'quote-\\-$()-value`;
  const runtime = `synthetic-runtime-\"quote-\\-$()-value`;
  const migrationFile = path.join(f.root, 'migration-password'); const runtimeFile = path.join(f.root, 'runtime-password');
  await writeFile(migrationFile, migration + '\n', { mode: 0o600 }); await writeFile(runtimeFile, runtime + '\n', { mode: 0o600 });
  const trace = path.join(f.root, 'psql.json');
  await writeFile(path.join(f.bin, 'psql'), `#!${process.execPath}
const fs = require('node:fs');
fs.writeFileSync(process.env.NOTITLE_TEST_PSQL_TRACE, JSON.stringify({ args: process.argv.slice(2), sql: fs.readFileSync(0, 'utf8'), migration: process.env.NOTITLE_BOOTSTRAP_MIGRATION_PASSWORD, runtime: process.env.NOTITLE_BOOTSTRAP_RUNTIME_PASSWORD }), { mode: 0o600 });
`, { mode: 0o755 });
  const shell = '. "$1"; test -z "${NOTITLE_BOOTSTRAP_MIGRATION_PASSWORD+x}"; test -z "${NOTITLE_BOOTSTRAP_RUNTIME_PASSWORD+x}"; test -z "${migration_password+x}"; test -z "${runtime_password+x}"';
  const result = spawnSync('sh', ['-c', shell, 'notitle-test', path.join(sourceRoot, 'deploy/postgres/init-app-role.sh')], { env: { ...f.env, NOTITLE_TEST_PSQL_TRACE: trace, POSTGRES_DB: 'notitle', POSTGRES_USER: 'notitle_bootstrap', POSTGRES_MIGRATION_PASSWORD_FILE: migrationFile, POSTGRES_APP_PASSWORD_FILE: runtimeFile }, encoding: 'utf8' });
  assert.equal(result.status, 0, result.stderr);
  const actual = JSON.parse(await readFile(trace, 'utf8'));
  assert.deepEqual(actual.args, ['--username', 'notitle_bootstrap', '--dbname', 'notitle', '--no-psqlrc', '--set', 'ON_ERROR_STOP=1']);
  assert.equal(actual.migration, migration); assert.equal(actual.runtime, runtime);
  for (const secret of [migration, runtime]) { assert.ok(!actual.sql.includes(secret)); assert.ok(!result.stdout.includes(secret)); assert.ok(!result.stderr.includes(secret)); }
  assert.match(actual.sql, /\\getenv migration_password NOTITLE_BOOTSTRAP_MIGRATION_PASSWORD/);
  assert.match(actual.sql, /\\getenv runtime_password NOTITLE_BOOTSTRAP_RUNTIME_PASSWORD/);
  assert.match(actual.sql, /PASSWORD :'migration_password'/);
  assert.match(actual.sql, /PASSWORD :'runtime_password'/);
});
