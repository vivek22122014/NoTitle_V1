import test from 'node:test';
import assert from 'node:assert/strict';
import { chmod, mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { buildPlan, prepareBuild, validateBuildInput } from '../release-build.mjs';
import { sourceDigest } from '../launch-evidence-lib.mjs';

// Synthetic references are used only to test parser/planning boundaries. No
// image is fetched, built, approved or represented as actually existing.
const input = () => ({ schema_version: 'notitle-build-v1', source_sha256: 'a'.repeat(64), version: 'v1.0.0', commit: 'b'.repeat(40), release_mode: 'production', origin: 'https://notitle.fixture-company.in', checkout_enabled: false,
  base_images: Object.fromEntries(['go','node','caddy','migration','turn','postgres'].map((x) => [x, `${x}@sha256:${'c'.repeat(64)}`])),
  tags: Object.fromEntries(['api','web','migrate','turn'].map((x) => [x, `notitle/${x}:v1.0.0`])) });
test('release build rejects mutable images, production placeholders, injected arguments and unknown controls', () => {
  for (const change of [c => { c.base_images.go='golang:latest'; }, c => { c.origin='https://example.com'; }, c => { c.version='v1; touch /tmp/unsafe'; }, c => { c.version=true; }, c => { c.push=true; }, c => { c.tags.turn=c.tags.api; }]) { const c=input();change(c);assert.throws(() => validateBuildInput(c)); }
});
test('release candidate plan binds source and does not publish or enable production', () => {
  const p=buildPlan(input(),new Date('2026-10-09T20:00:00Z'));
  assert.equal(p.steps.length,4);assert.equal(p.launch_approved,false);assert.equal(p.performs_push,false);assert.equal(p.performs_deploy,false);
  assert.ok(p.steps[0].args.includes(`SOURCE_SHA256=${'a'.repeat(64)}`));
  assert.ok(p.steps[1].args.includes('PUBLIC_CHECKOUT_SDK_ENABLED=false'));
  assert.ok(p.steps.every(s => !s.args.includes('push')&&!s.args.includes('up')));
});
test('archive source stays fingerprint-bound and staging rebuild changes only the web candidate', () => {
  const c=input(); c.commit=null; c.release_mode='staging'; c.origin='https://staging.fixture-company.in';
  assert.ok(buildPlan(c).steps[0].args.includes('COMMIT=archive'));
  const p=buildPlan(c,new Date('2026-10-09T20:00:00Z'),true);
  assert.equal(p.steps.length,1);assert.equal(p.steps[0].service,'web');
  assert.ok(p.steps[0].args.includes('PUBLIC_CHECKOUT_ENVIRONMENT=sandbox'));
  assert.ok(p.steps[0].args.includes('PUBLIC_RELEASE_MODE=staging'));
  assert.equal(p.source_sha256,c.source_sha256);
});
test('release build refuses missing locks before any candidate output or Docker work', async (t) => {
  const temp=await mkdtemp(path.join(os.tmpdir(),'notitle-build-fixture-'));t.after(()=>rm(temp,{recursive:true,force:true}));const source=path.join(temp,'source');await mkdir(source);
  await assert.rejects(prepareBuild({source,output:path.join(temp,'output'),config:input()}));
});
test('release build cannot place generated evidence inside the hashed source or overwrite an existing output', async (t) => {
  const temp=await mkdtemp(path.join(os.tmpdir(),'notitle-build-fixture-'));t.after(()=>rm(temp,{recursive:true,force:true}));const source=path.join(temp,'source');await mkdir(source);
  await assert.rejects(prepareBuild({source,output:path.join(source,'output'),config:input()}),/outside/);
  const output=path.join(temp,'existing');await mkdir(output);await writeFile(path.join(output,'retained'),'keep');await assert.rejects(prepareBuild({source,output,config:input()}),/never overwritten/);
});
test('source fingerprint detects executable-mode and content changes used by release approval', async (t) => {
  const temp=await mkdtemp(path.join(os.tmpdir(),'notitle-source-fixture-'));t.after(()=>rm(temp,{recursive:true,force:true}));await writeFile(path.join(temp,'main.go'),'package main\n');const first=await sourceDigest(temp);await writeFile(path.join(temp,'main.go'),'package modified\n');const second=await sourceDigest(temp);assert.notEqual(first.sha256,second.sha256);
  await chmod(path.join(temp,'main.go'),0o700);const executable=await sourceDigest(temp);assert.notEqual(second.sha256,executable.sha256);
});
