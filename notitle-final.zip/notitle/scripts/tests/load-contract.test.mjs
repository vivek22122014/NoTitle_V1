import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { IMAGE_KEYS, percentile, validatePermit, validateCapacityReport, validateOverloadReport } from '../load-contract.mjs';
import { projectObservation, readProtectedJSON, workloadProgress } from '../load-soak.mjs';
const start = Date.parse('2026-10-09T00:00:00Z');
const hash = 'a'.repeat(64), images = Object.fromEntries(IMAGE_KEYS.map((key) => [key, `fixture.invalid/${key}@sha256:${hash}`]));
function permit() { return { schema_version: 'notitle-load-permit-v1', origin: 'https://staging.fixture.invalid', isolated_target: true, no_real_users: true, synthetic_accounts_only: true, no_live_money: true, approved_by: 'synthetic fixture', not_before: new Date(start - 1000).toISOString(), expires_at: new Date(start + 25 * 3600000).toISOString(), maximum_seconds: 21600, maximum_offered: 400, maximum_connected: 200, maximum_calls: 25, source_sha256: hash, image_digests: images, relay_hosts: ['turn.fixture.invalid'] }; }
function report(scenario = 'A') {
  return { schema_version: 'notitle-capacity-v1', origin: 'https://staging.fixture.invalid', source_sha256: hash, image_digests: images, permit_sha256: hash, baseline_sha256: hash, baseline_started_at: new Date(start - 1000).toISOString(), scenario, media: 'chromium-synthetic-pcm-over-real-turn', termination: 'completed', failures: [], started_at: new Date(start).toISOString(), ended_at: new Date(start + 21600000).toISOString(), duration_seconds: 21600, samples: Array.from({ length: 721 }, (_, n) => ({ at: new Date(start + n * 30000).toISOString(), connected: 200, waiting: scenario === 'A' ? 100 : 0, text_participants: scenario === 'A' ? 50 : 150, audio_participants: 50, calls: 25, rtp_senders: 50, rtp_receivers: 50, relay_endpoints: 50, nonrelay_endpoints: 0, messages: { offered: n * (scenario === 'A' ? 600 : 1200), accepted: n * (scenario === 'A' ? 600 : 1200), received: n * (scenario === 'A' ? 600 : 1200), delivered: n * (scenario === 'A' ? 600 : 1200), errors: 0 }, server_observation_fresh: true, server_baseline_sha256: hash, server_window_started_at: new Date(start - 1000).toISOString(), server_observed_at: new Date(start + n * 30000).toISOString(), host: { total_bytes: 4 * 1073741824, available_bytes: 2 * 1073741824, go_heap_bytes: 100000000, goroutines: 600 }, server: { api: { scope: 'ordinary_api_server', samples: 1000 + n, p95_ms: 100 }, message: { scope: 'message_owner_processing', samples: 1000 + n, p95_ms: 50 }, match: { scope: 'available_candidate_to_commit_upper_bound', samples: 1000 + n, p95_ms: 100 } }, queues: { bounded: true, ungranted_captures: 0, overdue_jobs: 0, goroutines_limit: 2000 } })), call_setup: { attempts: 25, successes: 25, p95_ms: 1000 }, workload: Object.fromEntries(['next', 'reconnect', 'slow_reader', 'login_hash', 'guest_friend_accept', 'payment_job', 'backup', 'moderation', 'safety_event'].map((k) => [k, 1])) };
}
test('permit binds an isolated target, exact limits, expiration and immutable artifacts', () => {
  assert.equal(validatePermit(permit(), start).maximum_calls, 25);
  for (const change of [{ origin: 'https://production.fixture.invalid' }, { origin: 'https://staging.fixture.invalid/path' }, { origin: 'https://user:pass@staging.fixture.invalid' }, { origin: 'http://staging.fixture.invalid' }, { no_real_users: false }, { no_live_money: false }, { maximum_calls: 26 }, { maximum_offered: 401 }, { expires_at: new Date(start - 1).toISOString() }, { source_sha256: '' }, { image_digests: {} }]) assert.throws(() => validatePermit({ ...permit(), ...change }, start));
});
test('both exact six-hour workload contracts accept only complete synthetic evidence fixtures', () => {
  assert.equal(validateCapacityReport(report('A')).passed, true); assert.equal(validateCapacityReport(report('B')).passed, true);
  const wrong = report('B'); wrong.samples[0].waiting = 100; wrong.samples.forEach((s) => { s.text_participants = 50; }); assert.equal(validateCapacityReport(wrong).passed, false);
});
test('short probes, WebSocket-only media, frozen RTP and sample gaps fail closed', () => {
  for (const mutate of [(r) => { r.ended_at = new Date(start + 60000).toISOString(); r.duration_seconds = 60; }, (r) => { r.media = 'synthetic-sdp'; }, (r) => r.samples.forEach((s) => { s.rtp_receivers = 0; }), (r) => { r.samples[300].at = r.samples[298].at; }, (r) => { r.samples[10].nonrelay_endpoints = 1; }]) { const r = report(); mutate(r); assert.equal(validateCapacityReport(r).passed, false); }
});
test('server targets are strict and cannot be supplied by missing client-only measurements', () => {
  for (const [metric, limit] of [['api', 300], ['message', 100], ['match', 1000]]) { const r = report(); r.samples[2].server[metric].p95_ms = limit; assert.ok(validateCapacityReport(r).failures.includes(`server_${metric}_p95`)); }
  const r = report(); delete r.samples[0].server; assert.equal(validateCapacityReport(r).passed, false);
});
test('headroom, memory growth, payment backlog, background coverage and call success are mandatory', () => {
  for (const mutate of [(r) => { r.samples[0].host.available_bytes = 1073741823; }, (r) => { r.samples.slice(-181).forEach((s) => { s.host.go_heap_bytes *= 2; }); }, (r) => { r.samples.at(-1).queues.ungranted_captures = 1; }, (r) => { r.workload.backup = 0; }, (r) => { r.call_setup.successes = 23; }, (r) => { delete r.call_setup.attempts; }, (r) => { r.call_setup.successes = 26; }, (r) => { r.samples[0].connected = -1; }, (r) => { r.samples[0].server.match.scope = 'selection_scan'; }, (r) => { r.samples[0].server_observation_fresh = false; }, (r) => { r.samples.forEach((s) => { s.messages.accepted = 0; }); }, (r) => { r.samples[2].messages.errors = 1; }, (r) => { r.samples.forEach((s) => { s.server.message.samples = 1000; }); }]) { const r = report(); mutate(r); assert.equal(validateCapacityReport(r).passed, false); }
});
test('400-offered gate does not infer cleanup or safety from rejected connection counts', () => {
  const r = { ...report(), scenario: 'overload', offered: 400, baseline_connected: 200, refused_connections: 200, participant_201_rejected: true, waiter_101_rejected: true, call_26_rejected: true, established_sessions_preserved: true, safety_events_preserved: true, normal_cleanup_ms: 4500, orphan_cleanup_ms: 29000, cleanup_observation_verified: true };
  assert.equal(validateOverloadReport(r).passed, true);
  for (const patch of [{ orphan_cleanup_ms: null }, { normal_cleanup_ms: 5001 }, { cleanup_observation_verified: false }, { offered: 399 }, { waiter_101_rejected: false }, { safety_events_preserved: false }]) assert.equal(validateOverloadReport({ ...r, ...patch }).passed, false);
});
test('observation projection rejects stale or wrong-release evidence and strips arbitrary private fields', () => {
  const binding = { origin: permit().origin, source_sha256: hash, run_id: 'synthetic-run', baseline_sha256: hash, baseline_started_at: new Date(start).toISOString(), started_at: new Date(start).toISOString() };
  const input = { schema_version: 'notitle-load-observation-v1', ...binding, observed_at: new Date(start).toISOString(), window_started_at: new Date(start).toISOString(), secret: 'must not leave collector' };
  assert.equal(projectObservation(input, binding, start).server_observation_fresh, true);
  assert.equal(projectObservation(input, binding, start + 45001).server_observation_fresh, false);
  assert.equal(projectObservation({ ...input, source_sha256: 'b'.repeat(64) }, binding, start).server_observation_fresh, false);
  assert.equal(JSON.stringify(projectObservation(input, binding, start)).includes('must not leave'), false);
});
test('measurement baseline cannot include historical traffic or be swapped mid-run', () => {
  for (const change of [(r) => { r.baseline_started_at = new Date(start - 60001).toISOString(); }, (r) => { r.samples[1].server_baseline_sha256 = 'b'.repeat(64); }, (r) => { r.samples[1].server_window_started_at = r.started_at; }]) { const r = report(); change(r); assert.equal(validateCapacityReport(r).passed, false); }
  const early = report(); for (const m of Object.values(early.samples[0].server)) { m.samples = 0; m.p95_ms = null; } assert.equal(validateCapacityReport(early).passed, true);
  const absent = report(); absent.samples.forEach((s) => { s.server.api.samples = 0; s.server.api.p95_ms = null; }); assert.equal(validateCapacityReport(absent).passed, false);
});
test('protected fixture reader rejects symlinks, broad modes and excessive files', async () => {
  const folder = await fs.mkdtemp(path.join(os.tmpdir(), 'notitle-load-contract-'));
  try { const file = path.join(folder, 'fixture.json'); await fs.writeFile(file, '{}', { mode: 0o600 }); assert.deepEqual((await readProtectedJSON(file)).value, {}); await assert.rejects(readProtectedJSON(file, 1)); await fs.writeFile(file, '{"x":1,"x":2}'); await assert.rejects(readProtectedJSON(file)); await fs.writeFile(file, Buffer.from([0xff])); await assert.rejects(readProtectedJSON(file)); await fs.writeFile(file, '{}'); await fs.symlink(file, path.join(folder, 'link')); await assert.rejects(readProtectedJSON(path.join(folder, 'link'))); await fs.chmod(file, 0o644); await assert.rejects(readProtectedJSON(file)); } finally { await fs.rm(folder, { recursive: true, force: true }); }
});
test('nearest-rank percentile never silently converts absent values into a pass', () => { assert.equal(percentile([]), null); assert.equal(percentile([Infinity]), null); assert.equal(percentile([2, 1, 4, 3]), 4); });

test('background work starts from a fresh in-window bound snapshot, not pre-run completions', () => {
  const binding = { origin: permit().origin, source_sha256: hash, run_id: 'synthetic-run', baseline_sha256: hash, baseline_started_at: new Date(start - 1000).toISOString(), started_at: new Date(start).toISOString() };
  const input = { schema_version: 'notitle-load-observation-v1', ...binding, window_started_at: binding.baseline_started_at, observed_at: new Date(start - 1).toISOString(), workload: { payment_job: 100, backup: 100, moderation: 100, safety_event: 100 } };
  assert.equal(workloadProgress(null, input, binding, start).baseline, null);
  input.observed_at = new Date(start + 1000).toISOString();
  const first = workloadProgress(null, input, binding, start + 1000); assert.deepEqual(first.counts, {});
  input.workload.backup++; assert.deepEqual(workloadProgress(first.baseline, input, binding, start + 1000).counts, {});
  input.observed_at = new Date(start + 2000).toISOString();
  assert.deepEqual(workloadProgress(first.baseline, input, binding, start + 2000).counts, { payment_job: 0, backup: 1, moderation: 0, safety_event: 0 });
  assert.deepEqual(workloadProgress(first.baseline, { ...input, run_id: 'old-run' }, binding, start + 2000).counts, {});
  assert.deepEqual(workloadProgress(first.baseline, { ...input, baseline_sha256: 'b'.repeat(64) }, binding, start + 2000).counts, {});
});
