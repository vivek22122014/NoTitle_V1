-- Run only after smoke-safety.mjs inside the disposable smoke-stack database.
-- Outputs counts/assertion failures only; never print column values or evidence.
DO $$
DECLARE
    candidate record;
    found boolean;
    marker constant text := 'PHASE5_ORDINARY_ONLY_9f1f572bd2a94469';
BEGIN
    IF (SELECT count(*) FROM notitle.report_evidence WHERE kind = 'server_text') <> 1 THEN
        RAISE EXCEPTION 'Only the one deliberately selected evidence message may be retained';
    END IF;
    IF (SELECT count(*) FROM notitle.reports) <> 3 THEN
        RAISE EXCEPTION 'Report retry did not preserve the three submitted cases';
    END IF;
    FOR candidate IN
        SELECT table_schema, table_name, column_name
        FROM information_schema.columns
        WHERE table_schema IN ('notitle', 'notitle_admin')
          AND data_type IN ('text', 'character varying', 'character', 'json', 'jsonb')
    LOOP
        EXECUTE format('SELECT EXISTS (SELECT 1 FROM %I.%I WHERE position($1 IN %I::text)>0)',
            candidate.table_schema, candidate.table_name, candidate.column_name)
            INTO found USING marker;
        IF found THEN
            RAISE EXCEPTION 'Ordinary conversation canary was found in durable storage';
        END IF;
    END LOOP;
    FOR candidate IN
        SELECT table_schema, table_name, column_name
        FROM information_schema.columns
        WHERE table_schema IN ('notitle', 'notitle_admin') AND data_type = 'bytea'
    LOOP
        EXECUTE format('SELECT EXISTS (SELECT 1 FROM %I.%I WHERE position(convert_to($1,''UTF8'') IN %I)>0)',
            candidate.table_schema, candidate.table_name, candidate.column_name)
            INTO found USING marker;
        IF found THEN
            RAISE EXCEPTION 'Ordinary conversation canary was found in durable binary storage';
        END IF;
    END LOOP;
    IF EXISTS (SELECT 1 FROM notitle.report_evidence
        WHERE position(convert_to('<img src=x onerror=alert(1)>','UTF8') IN ciphertext)>0) THEN
        RAISE EXCEPTION 'Selected evidence was stored without encryption';
    END IF;
    IF EXISTS (SELECT 1 FROM pg_tables WHERE schemaname IN ('notitle','notitle_admin')
        AND tablename IN ('messages','chat_messages','conversations','chat_history','transcripts')) THEN
        RAISE EXCEPTION 'Unexpected ordinary conversation persistence table';
    END IF;
END;
$$;
