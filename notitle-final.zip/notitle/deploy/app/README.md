# Static frontend edge

The image builds the SvelteKit public documents, app fallback, discovery files and HTML/CSP finalizer, then copies only generated output into Caddy. A Node application server is unnecessary. A genuine npm lock is required.

Local `./scripts/bootstrap.sh static` builds a **preview** image and binds only `127.0.0.1:8080`. All preview responses carry `X-Robots-Tag: noindex, nofollow`. Preview is for reviewing draft content; it is never a publishable release.

## Build modes and release gate

`PUBLIC_RELEASE_MODE` is a build argument: `preview` (default), `staging` or `production`. `PUBLIC_SITE_ORIGIN` is a build argument containing the exact origin. Hosted modes require HTTPS. Both values describe public output, not secrets. The entire `web/config` directory is copied into the build, so the approved release inventory and Premium plan configuration are part of the reviewed artifact.

The build finalizer emits `notitle-build.json` using frontend marker schema 2, binding checkout enabled/environment controls as well as the release mode. It verifies exact checkout/realtime CSP on all generated public documents and the app shell, including an actual production checkout candidate. Old schema-1 frontend artifacts must be rebuilt; runtime preparation rejects missing checkout controls and sandbox-enabled production checkout. A separate validation step extracts its mode, origin and legal approval into `/etc/notitle-build`, outside the served directory, together with checkout-enabled and checkout-environment markers. The startup entrypoint requires artifact mode to equal `NOTITLE_DEPLOYMENT_MODE`. Production also requires an approved legal inventory and exact equality among the built origin, `PUBLIC_ORIGIN` and `https://APP_ADDRESS`. Changing runtime variables cannot turn a draft preview image into a production artifact. The metadata JSON itself has no public route.

The production build command is documented in `../production/README.md`; unresolved operator, grievance, tax and privacy data must be completed and reviewed before it succeeds. Do not change draft markers merely to make the gate pass.

Staging requires an image built with staging mode, a matching HTTPS origin, a username and a bcrypt hash mounted from an external file. Browser routes require HTTP Basic Authentication and emit noindex. Only the exact `/api/v1/webhooks/cashfree` route bypasses that browser password; the API requires a valid provider signature and durable inbox commit, or returns an error when payments are off. See `../staging/README.md`.

## Routes and headers

Caddy has explicit allowlists for the 11 public documents and eight application paths from `web/src/lib/config/routes.mjs`. Public paths with trailing slashes redirect to their canonical path. All app paths use `app.html` with no-store and noindex. Unsupported paths, direct HTML filenames, `/design-preview` and release metadata return a meaningful HTML page with HTTP 404 and noindex. App noindex is not authorization; later account APIs still require their own access control.

Only fingerprinted assets get year-long immutable caching. Public documents use revalidation, and compressed build sidecars are used when supported. Source maps are hidden. The edge serves only declared branding assets plus robots.txt and sitemap.xml outside `/_app/`.

Svelte generates enforced hash-based meta CSP. Caddy adds `frame-ancestors 'none'` as a response header because this directive cannot work in a meta tag. Do not replace the generated policy with a fixed script policy that invalidates bootstrap hashes. Third-party checkout/audio scripts stay absent from public pages.

Backend `/api/*`, `/health/*` and `/ws` proxy to the private API. Request access logs remain disabled. Caddy automatic HTTPS and persistent certificate volumes apply to hosted environments; HSTS is sent only over HTTPS. The administration listener is disabled.

The dependency-free fixture suite is `node --test deploy/tests/static-serving.test.mjs`; it validates the Node test server and marker parser, not Caddy itself. `./scripts/smoke-stack.sh` exercises the real built/Caddy/API stack and must pass in a Docker-capable environment before release.
