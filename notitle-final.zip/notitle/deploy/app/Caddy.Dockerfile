ARG NODE_BUILD_IMAGE=node:24.19.0-bookworm-slim
ARG CADDY_RUNTIME_IMAGE=caddy:2.11.7-alpine
FROM ${NODE_BUILD_IMAGE} AS web-build
WORKDIR /src
COPY web/package.json web/package-lock.json ./
RUN npm ci --ignore-scripts --no-audit --no-fund
COPY web/ ./
ARG PUBLIC_RELEASE_MODE=preview
ARG PUBLIC_CHECKOUT_SDK_ENABLED=false
ARG PUBLIC_CHECKOUT_ENVIRONMENT=sandbox
ARG PUBLIC_SITE_ORIGIN=
ENV PUBLIC_RELEASE_MODE=$PUBLIC_RELEASE_MODE PUBLIC_SITE_ORIGIN=$PUBLIC_SITE_ORIGIN PUBLIC_CHECKOUT_SDK_ENABLED=$PUBLIC_CHECKOUT_SDK_ENABLED PUBLIC_CHECKOUT_ENVIRONMENT=$PUBLIC_CHECKOUT_ENVIRONMENT
RUN npm run prepare && npm run build
COPY deploy/app/prepare-runtime.mjs /prepare-runtime.mjs
RUN node /prepare-runtime.mjs /src/build /release

FROM ${CADDY_RUNTIME_IMAGE}
COPY deploy/app/Caddyfile /etc/caddy/Caddyfile
COPY deploy/app/entrypoint.sh /usr/local/bin/notitle-web-entrypoint
COPY --from=web-build /src/build /srv
COPY --from=web-build /release /etc/notitle-build
RUN chmod 0555 /usr/local/bin/notitle-web-entrypoint
ENTRYPOINT ["/usr/local/bin/notitle-web-entrypoint"]
