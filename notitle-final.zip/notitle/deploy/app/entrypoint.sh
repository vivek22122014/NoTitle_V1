#!/bin/sh
set -eu
fail() { printf '%s\n' "$1" >&2; exit 1; }
build_mode=$(cat /etc/notitle-build/mode) || fail 'Frontend build marker is missing.'
build_origin=$(cat /etc/notitle-build/origin) || fail 'Frontend origin marker is missing.'
legal_approved=$(cat /etc/notitle-build/legal-approved) || fail 'Frontend legal marker is missing.'
deployment_mode=${NOTITLE_DEPLOYMENT_MODE:-preview}
test "$build_mode" = "$deployment_mode" || fail 'Frontend artifact mode differs from deployment mode. Rebuild for the intended environment.'
umask 077
: > /tmp/notitle-global.caddy
: > /tmp/notitle-tls.caddy
: > /tmp/notitle-admission.caddy

case "$deployment_mode" in
  preview)
    test "${APP_ADDRESS:-}" = ':8080' || fail 'Preview artifacts may only use the local :8080 listener.'
    printf '%s\n' 'header X-Robots-Tag "noindex, nofollow"' > /tmp/notitle-access.caddy
    ;;
  staging|production)
    test -n "$build_origin" && test "$build_origin" = "${PUBLIC_ORIGIN:-}" || fail 'Runtime public origin must match the frontend build origin.'
    case "$build_origin" in https://*) ;; *) fail 'Hosted frontend requires HTTPS.';; esac
    test "https://${APP_ADDRESS:-}" = "$build_origin" || fail 'Caddy hostname must match the frontend build origin.'
    if test "$deployment_mode" = production; then
      test "$legal_approved" = true || fail 'Production frontend requires reviewed, complete release inventory.'
      : > /tmp/notitle-access.caddy
      test "${ORIGIN_AUTH_SCOPE:-}" = zone || fail 'Production requires reviewed zone-specific authenticated origin pulls.'
      # Production origin TLS is provisioned independently; no account/API token
      # is placed in Caddy environment or source. The CA is Cloudflare AOP only.
      for tls_file in origin-cert.pem origin-key.pem origin-pull-ca.pem; do
        test -f "/run/notitle-origin/$tls_file" && test ! -L "/run/notitle-origin/$tls_file" || fail 'Production origin TLS material is missing or is a symlink.'
      done
      cat > /tmp/notitle-tls.caddy <<'TLS'
tls /run/notitle-origin/origin-cert.pem /run/notitle-origin/origin-key.pem {
    protocols tls1.2 tls1.3
    client_auth {
        mode require_and_verify
        trust_pool file /run/notitle-origin/origin-pull-ca.pem
    }
}
TLS
      launch_stage=${NOTITLE_LAUNCH_STAGE:-maintenance}
      case "$launch_stage" in maintenance|validation|cohort|public) ;; *) fail 'Unknown production launch stage.';; esac
      if test "$launch_stage" = validation; then
        # Trust source headers only from the reviewed proxy ranges and require
        # real operator source CIDRs in addition to the cohort password.
        test -f /run/notitle-origin/cloudflare-proxies && test ! -L /run/notitle-origin/cloudflare-proxies || fail 'Validation requires reviewed Cloudflare proxy CIDRs.'
        proxy_cidrs=$(cat /run/notitle-origin/cloudflare-proxies | tr '\n' ' ')
        source_cidrs=${VALIDATION_SOURCE_CIDRS:-}
        for cidr_list in "$proxy_cidrs" "$source_cidrs"; do
          test -n "$cidr_list" && test "${#cidr_list}" -le 4096 || fail 'Validation CIDRs are missing or too large.'
          case "$cidr_list" in *[!0-9a-fA-F:./\ ]*) fail 'Invalid CIDR characters.';; esac
          cidr_count=0
          for cidr in $cidr_list; do
            cidr_count=$((cidr_count + 1))
            case "$cidr" in */0|0.0.0.0/*|::/*) fail 'Unrestricted validation CIDR is forbidden.';; */*) ;; *) fail 'Explicit CIDR prefixes are required.';; esac
          done
          test "$cidr_count" -gt 0 || fail 'Validation CIDRs cannot be empty.'
        done
        {
          printf 'servers {\n    trusted_proxies static %s\n    trusted_proxies_strict\n    client_ip_headers CF-Connecting-IP\n}\n' "$proxy_cidrs"
        } > /tmp/notitle-global.caddy
        launch_stage=cohort
      fi
      if test "$launch_stage" != public; then
        printf '%s\n' 'header X-Robots-Tag "noindex, nofollow"' > /tmp/notitle-access.caddy
        cat > /tmp/notitle-admission.caddy <<'ADMISSION'
@new_admission path /chat /chat/ /register /register/ /ws /api/v1/auth/register /api/v1/realtime/ticket /api/v1/payments/orders /api/v1/payments/checkout
@new_guest {
    path /api/v1/guest/session
    method POST
}
ADMISSION
        if test "${NOTITLE_LAUNCH_STAGE:-}" = validation; then
          for matcher in new_admission new_guest; do
            printf '@%s_source_denied {\n    not client_ip %s\n' "$matcher" "$source_cidrs" >> /tmp/notitle-admission.caddy
            if test "$matcher" = new_guest; then
              printf '%s\n' '    path /api/v1/guest/session' '    method POST' >> /tmp/notitle-admission.caddy
            else
              printf '%s\n' '    path /chat /chat/ /register /register/ /ws /api/v1/auth/register /api/v1/realtime/ticket /api/v1/payments/orders /api/v1/payments/checkout' >> /tmp/notitle-admission.caddy
            fi
            printf '}\nrespond @%s_source_denied "Restricted validation cohort." 403\n' "$matcher" >> /tmp/notitle-admission.caddy
          done
        fi
        if test "$launch_stage" = maintenance; then
          for matcher in new_admission new_guest; do
            printf 'header @%s Cache-Control "no-store"\nheader @%s Retry-After "120"\nrespond @%s "Scheduled maintenance. Support, privacy and payment status remain available." 503\n' "$matcher" "$matcher" "$matcher" >> /tmp/notitle-admission.caddy
          done
        else
          cohort_user=${COHORT_USERNAME:-}
          test -n "$cohort_user" && test "${#cohort_user}" -le 64 || fail 'Cohort requires an authentication username.'
          case "$cohort_user" in *[!A-Za-z0-9_-]*) fail 'Invalid cohort username.';; esac
          test -f /run/notitle-origin/cohort-password-hash && test ! -L /run/notitle-origin/cohort-password-hash || fail 'Cohort requires a protected bcrypt file.'
          cohort_hash=$(cat /run/notitle-origin/cohort-password-hash)
          test "${#cohort_hash}" -eq 60 || fail 'Cohort file must contain one bcrypt hash.'
          printf '%s' "$cohort_hash" | grep -Eq '^\$2[aby]\$[0-9]{2}\$[./A-Za-z0-9]{53}$' || fail 'Cohort file must contain one bcrypt hash.'
          for matcher in new_admission new_guest; do
            printf 'basic_auth @%s {\n    %s %s\n}\n' "$matcher" "$cohort_user" "$cohort_hash" >> /tmp/notitle-admission.caddy
          done
          unset cohort_hash
        fi
      fi
    else
      staging_user=${STAGING_USERNAME:-}
      test -n "$staging_user" && test "${#staging_user}" -le 64 || fail 'Staging requires a simple nonempty authentication username.'
      case "$staging_user" in *[!A-Za-z0-9_-]*) fail 'Staging authentication username contains unsupported characters.';; esac
      test -n "${STAGING_PASSWORD_HASH_FILE:-}" && test -f "$STAGING_PASSWORD_HASH_FILE" || fail 'Staging requires an external bcrypt password-hash file.'
      staging_hash=$(cat "$STAGING_PASSWORD_HASH_FILE")
      test "${#staging_hash}" -eq 60 || fail 'Staging password file must contain one bcrypt hash.'
      printf '%s' "$staging_hash" | grep -Eq '^\$2[aby]\$[0-9]{2}\$[./A-Za-z0-9]{53}$' || fail 'Staging password file must contain one bcrypt hash.'
      {
        # Cashfree cannot present a staging browser password. Only the exact
        # server-authenticated webhook bypasses Basic Auth; every other route,
        # including checkout and browser return, remains private.
        printf '%s\n' 'header X-Robots-Tag "noindex, nofollow"' '@staging_browser not path /api/v1/webhooks/cashfree' 'basic_auth @staging_browser {'
        printf '    %s %s\n' "$staging_user" "$staging_hash"
        printf '%s\n' '}'
      } > /tmp/notitle-access.caddy
      unset staging_hash
    fi
    ;;
  *) fail 'Unknown frontend deployment mode.';;
esac
exec caddy run --config /etc/caddy/Caddyfile --adapter caddyfile
