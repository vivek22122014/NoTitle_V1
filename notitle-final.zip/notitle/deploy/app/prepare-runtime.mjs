// Build-time marker validation. Only validated scalar values enter the runtime image.
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export function validateBuildMarker(marker) {
  if (!marker || marker.schemaVersion !== 2 || !['preview', 'staging', 'production'].includes(marker.mode)) {
    throw new Error('Missing or unsupported frontend deployment marker');
  }
  if (typeof marker.legalApproved !== 'boolean' || !/^[a-f0-9]{64}$/.test(marker.inventorySha256 ?? '')) {
    throw new Error('Frontend release inventory marker is incomplete');
  }
  if (!marker.checkout || typeof marker.checkout.enabled !== 'boolean' || !['sandbox', 'production'].includes(marker.checkout.environment)) {
    throw new Error('Frontend checkout build marker is incomplete');
  }
  if (marker.mode === 'production' && marker.checkout.enabled && marker.checkout.environment !== 'production') {
    throw new Error('Production checkout artifact cannot target sandbox');
  }
  const origin = marker.origin ?? '';
  if (origin) {
    const url = new URL(origin);
    if (url.origin !== origin || url.username || url.password || !['http:', 'https:'].includes(url.protocol)) {
      throw new Error('Frontend marker origin must be an exact HTTP(S) origin');
    }
  }
  if (marker.mode !== 'preview' && (!origin || new URL(origin).protocol !== 'https:')) {
    throw new Error('Staging and production artifacts require an HTTPS origin');
  }
  if (marker.mode === 'production' && !marker.legalApproved) {
    throw new Error('Production artifact requires approved release inventory');
  }
  return { mode: marker.mode, origin, legalApproved: marker.legalApproved, checkout: { enabled: marker.checkout.enabled, environment: marker.checkout.environment } };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const build = process.argv[2] ?? '/src/build';
  const output = process.argv[3] ?? '/release';
  const marker = validateBuildMarker(JSON.parse(await readFile(resolve(build, 'notitle-build.json'), 'utf8')));
  for (const file of ['index.html', 'app.html', '404.html', 'robots.txt', 'sitemap.xml']) {
    if (!(await readFile(resolve(build, file))).length) throw new Error('Required static output is empty: ' + file);
  }
  await mkdir(output, { recursive: true });
  await Promise.all([
    writeFile(resolve(output, 'mode'), marker.mode + '\n'),
    writeFile(resolve(output, 'origin'), marker.origin + '\n'),
    writeFile(resolve(output, 'legal-approved'), String(marker.legalApproved) + '\n'),
    writeFile(resolve(output, 'checkout-enabled'), String(marker.checkout.enabled) + '\n'),
    writeFile(resolve(output, 'checkout-environment'), marker.checkout.environment + '\n')
  ]);
}
