# Payment processing activation

The base configurations keep payment processing and checkout disabled. This optional overlay adds settings and a protected credential mount to the existing API. It adds no container, database, paid queue, email service or recurring subscription. Cashfree hosted checkout is the single implemented provider; ordinary settlement is used.

Keep `PAYMENTS_ENABLED=true` once purchases exist so verified captures, refunds, disputes, reconciliation and existing entitlements keep working. Set `CHECKOUT_ENABLED=false` to stop new checkout without abandoning those obligations. The overlay defaults to this processing-only state. Enabling a boolean does not establish merchant approval, settlement evidence or production readiness.

Before processing is enabled, migrate the isolated database through the cumulative schema 9 and enable identity, safety and private administration in the base environment. Migration 7 originally introduced payments; stopping there is incompatible with this cumulative release. Existing realtime and audio flags remain independent. The private billing operator requires the existing MFA session and billing role; public Caddy never exposes the admin listener. The consolidated setup is in `../../docs/FINAL_PAYMENT_GUIDE.md`.

## Protected credential files

The API image runs as UID/GID `65532:65532`, including its development target. On the Linux host, prepare a dedicated directory containing regular files named `client_id` and `client_secret`. Its owner must be `65532:65532`, directory mode `0700`, and both credential files mode `0400` or `0600` with the same owner. Set `PAYMENT_SECRET_DIRECTORY` to its absolute host path. Mount only this directory, not a parent containing other operational secrets.

Provision values through the operator's protected secret workflow. Do not put credential values in shell arguments, Compose environment values, committed files, build arguments, image layers or logs. The optional overlay mounts the directory read-only at `/var/lib/notitle/payment-keys`; the API rejects symlinks, nonregular files and files readable by group or others. A direct default Compose secret mount (`0444`) will be rejected. Merely writing `mode: 0400` on a file-backed Compose secret is not a substitute for confirming the real mounted ownership and permissions.

On Docker Desktop or another host that cannot preserve Unix bind permissions, first provision a Linux volume with UID `65532` ownership and the same modes using a reviewed one-shot secret preparation step, and replace the directory bind with that read-only volume. Do not weaken `ReadSecretFile` or run the API as root to work around host permissions. Keep the volume separate from ordinary application source and backup archives.

## Isolated sandbox configuration

Use a separate project, database and credential directory. `APP_ENV=development`, `test` or `staging` requires `PAYMENT_ENVIRONMENT=sandbox`; `APP_ENV=production` requires `PAYMENT_ENVIRONMENT=production`. Set the actual merchant identifier in `PAYMENT_MERCHANT_ID`, use that environment's credentials, and never copy financial records between them. The ledger and provider references are also scoped by environment.

Merge `deploy/payments/compose.app.yml` last, after the chosen base and any staging or audio overlay. For example, this command only renders and checks an existing protected staging configuration:

```bash
docker compose --project-name notitle-staging --env-file /protected/staging.env \
  -f deploy/production/compose.yml -f deploy/staging/compose.yml \
  -f deploy/payments/compose.app.yml config --quiet
```

Use exactly the same project and ordered files for subsequent authorized operations. The existing wrapper scripts do not append this optional overlay automatically. All host secret paths must be absolute because Compose resolves relative paths against its first configuration file. No command here creates credentials, provisions a host, publishes checkout or initiates a transaction.

Catalog versions are immutable. The migration seeds the four agreed plans disabled with tax treatment awaiting review. An authorized migration/operator process must publish the reviewed catalog version; the runtime role can only read it. The annual plan additionally needs `PAYMENT_ANNUAL_APPROVED=true`, an approved late-refund procedure and the economics review. Existing order snapshots remain unchanged when a plan is disabled or superseded.

## Static frontend and checkout

The checkout SDK and its exact allowed origins are compile-time settings. Build the static web image from `deploy/app/Caddy.Dockerfile` with these arguments in the controlled release environment:

| Build argument | Sandbox/staging checkout | Live checkout |
| --- | --- | --- |
| `PUBLIC_RELEASE_MODE` | `preview` locally or `staging` | `production` |
| `PUBLIC_SITE_ORIGIN` | Empty for preview; actual HTTPS staging origin for staging | Approved canonical HTTPS origin |
| `PUBLIC_CHECKOUT_SDK_ENABLED` | `true` when running approved sandbox checkout acceptance | `true` after live prerequisites are closed |
| `PUBLIC_CHECKOUT_ENVIRONMENT` | `sandbox` | `production` |

Setting these in the running Caddy container does not change already built JavaScript or CSP. Rebuild the web image and record its digest when changing SDK admission or environment. Backend `CHECKOUT_ENABLED` must also be true, the plan must be enabled, and the returned checkout environment must agree with the build. SDK availability alone cannot grant Premium. A processing-only build can leave `PUBLIC_CHECKOUT_SDK_ENABLED=false` and retain in-account payment status and receipts.

Hosted checkout uses a full-page redirect and the pinned Cashfree SDK origin; no payment iframe or unrestricted wildcard CSP is added. The payment return reads authenticated server status. A browser redirect or SDK callback cannot change the ledger. Payment-only phone data is disclosed at checkout, used for the real provider field, omitted from ordinary registration and never saved to peers or the local financial ledger. Verify provider notification settings separately.

The browser fixture command `npm run test:payments-ui` exercises the mobile and desktop interface with synthetic provider responses and no real money. The test image includes it after existing browser suites. Actual sandbox checkout, webhook ingress, recovery, refunds, reconciliation and device return-from-checkout still require the Phase 8 acceptance procedure. Protected staging must expose only the exact authenticated-by-signature webhook route needed by Cashfree; do not remove authentication from general staging pages to make webhooks work. Confirm the reverse proxy's route behavior before gateway testing.

## Rotation and live gates

For a bounded overlap, provision a separate `previous_secret` file with the same protected ownership/modes. Set `CASHFREE_PREVIOUS_SECRET_CONTAINER_FILE=/var/lib/notitle/payment-keys/previous_secret` and `CASHFREE_PREVIOUS_SECRET_UNTIL` to a future RFC3339 deadline no more than 24 hours away, then restart the API with the new primary credential. Both settings must be removed when the overlap ends; remove the retired key from the protected directory. The application does not print either key and refuses an unbounded overlap.

Production processing requires `PAYMENT_MERCHANT_APPROVED=true` and `PAYMENT_POLICY_APPROVED=true` only after written acceptance of the actual product, approved tax/refund disclosures and deployment review. Live purchase/refund/settlement validation requires separate deliberate authorization and recorded evidence. Follow `docs/phase8-acceptance.md`; keep new checkout off until its gates pass. No live transaction, credential provisioning or deployment has been performed by these templates.
