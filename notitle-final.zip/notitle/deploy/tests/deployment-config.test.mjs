import test from 'node:test';
import assert from 'node:assert/strict';
import { validateDeployment, canonical } from '../../scripts/deploy-config.mjs';
const image = 'registry.example/notitle@sha256:' + 'a1'.repeat(32);
function fixture() {
  const base = {image,read_only:true,cap_drop:['ALL'],security_opt:['no-new-privileges:true'],ulimits:{core:{soft:0,hard:0}},logging:{driver:'local',options:{'max-size':'10m','max-file':'5'}},restart:'unless-stopped',mem_limit:1024,environment:{},volumes:[]};
  const service = () => structuredClone(base);
  const postgres = {...service(),networks:{database:{}},read_only:false};
  const migrate = {...service(),networks:{database:{}}};
  const api = {...service(),networks:{edge:{},database:{}},ports:[{host_ip:'127.0.0.1',target:9090,published:'9090',protocol:'tcp'}],volumes:[{type:'volume',source:'deletion_tombstones',target:'/var/lib/notitle/tombstones'}]};
  api.environment = {APP_ENV:'production',PUBLIC_ORIGIN:'https://chat.acme.in',MAINTENANCE_MODE:'true',LAUNCH_STAGE:'validation',DEPLOYED_API_IMAGE:image,LAUNCH_APPROVAL_FILE:'/var/lib/notitle/launch/approval.json'};
  api.volumes.push({type:'bind',source:'/protected/launch',target:'/var/lib/notitle/launch',read_only:true,bind:{create_host_path:false}});
  for (const name of ['IDENTITY','REALTIME','SAFETY','ADMIN','FRIENDS','AUDIO','OPERATIONS','PAYMENTS','CHECKOUT']) api.environment[name+'_ENABLED'] = 'false';
  const web = {...service(),networks:{edge:{}},ports:[{target:443,published:'443',protocol:'tcp'}],volumes:[{type:'bind',source:'/protected/origin',target:'/run/notitle-origin',read_only:true,bind:{create_host_path:false}}],environment:{ORIGIN_AUTH_SCOPE:'zone',NOTITLE_DEPLOYMENT_MODE:'production',NOTITLE_LAUNCH_STAGE:'maintenance',PUBLIC_ORIGIN:'https://chat.acme.in',APP_ADDRESS:'chat.acme.in'}};
  return {name:'notitle',services:{api,web,postgres,migrate},networks:{database:{internal:true},edge:{}}};
}
test('manifest is deterministic, secret-free and honest about unavailable host proof',()=>{
  const config = fixture(); config.services.api.environment.DATABASE_URL_FILE='/run/secrets/runtime';
  const manifest=validateDeployment(config);
  assert.equal(manifest.database_schema,9);assert.equal(manifest.single_owner,true);assert.equal(manifest.secret_files_checked,false);
  assert.equal(manifest.stage,'validation');assert.equal(manifest.ingress_mode,'maintenance');assert.match(manifest.compose_sha256,/^[a-f0-9]{64}$/);
  assert.doesNotMatch(JSON.stringify(manifest),/run\/secrets|protected\/origin/);
  assert.equal(canonical({b:2,a:1}),canonical({a:1,b:2}));
  config.services.api.environment.DB_MAX_CONNS='7'; assert.notEqual(validateDeployment(config).compose_sha256,manifest.compose_sha256);
});
test('tags, fake digest placeholders and runtime builds are rejected',()=>{
  for (const value of ['notitle:latest','notitle@sha256:'+'0'.repeat(64)]) {const c=fixture();c.services.api.image=value;assert.throws(()=>validateDeployment(c),/immutable/);}
  const c=fixture();c.services.api.build={context:'.'};assert.throws(()=>validateDeployment(c),/runtime_build/);
});
test('rejects second owner, extra service and secret-bearing environment',()=>{
  let c=fixture();c.services.api.deploy={replicas:2};assert.throws(()=>validateDeployment(c),/one_replica/);
  c=fixture();c.services.worker=structuredClone(c.services.api);assert.throws(()=>validateDeployment(c),/exact_app/);
  c=fixture();c.services.api.environment.DATABASE_URL='postgres://private:password@db';assert.throws(()=>validateDeployment(c),/inline_secret/);
});
test('public admin/database and insecure origin fail closed',()=>{
  let c=fixture();c.services.api.ports[0].host_ip='0.0.0.0';assert.throws(()=>validateDeployment(c),/loopback/);
  c=fixture();c.services.postgres.ports=[{target:5432}];assert.throws(()=>validateDeployment(c),/database_ports/);
  c=fixture();c.services.web.environment.PUBLIC_ORIGIN='https://evil.acme.in';assert.throws(()=>validateDeployment(c),/origin_mismatch/);
  c=fixture();c.services.api.environment.MAINTENANCE_MODE='false';assert.throws(()=>validateDeployment(c),/boot_closed/);
});
test('cohort cannot bypass staffed safety and operations requirements',()=>{
  const c=fixture();c.services.api.environment.LAUNCH_STAGE='cohort';c.services.web.environment.NOTITLE_LAUNCH_STAGE='cohort';c.services.web.environment.COHORT_USERNAME='pilot';assert.throws(()=>validateDeployment(c),/real_user_safety/);
  for(const key of ['IDENTITY','REALTIME','SAFETY','ADMIN','OPERATIONS']) c.services.api.environment[key+'_ENABLED']='true';
  c.services.api.volumes.push({type:'bind',source:'/protected/holds',target:'/var/lib/notitle/holds',bind:{create_host_path:false}}, {type:'bind',source:'/protected/operations',target:'/var/lib/notitle/operations-keys',read_only:true,bind:{create_host_path:false}});
  assert.equal(validateDeployment(c).stage,'cohort');
  c.services.api.volumes[2].source = c.services.api.volumes[3].source; assert.throws(()=>validateDeployment(c),/hold_journal/);
});
test('rejects privileged containers and unreviewed writable mount creation',()=>{
  let c=fixture();c.services.api.privileged=true;assert.throws(()=>validateDeployment(c),/privileged/);
  c=fixture();c.services.web.volumes[0].bind.create_host_path=true;assert.throws(()=>validateDeployment(c),/strict_bind/);
  c=fixture();c.services.api.volumes=c.services.api.volumes.filter(v=>v.type!=='volume');assert.throws(()=>validateDeployment(c),/deletion_volume/);
});
test('relay requires immutable image and private control boundary',()=>{
  const c=fixture();const relay=structuredClone(c.services.web);delete relay.networks;relay.network_mode='host';relay.user='65532:65532';relay.ports=[];
  relay.environment={RELAY_CONTROL_ADDR:'10.1.2.3:9443'};relay.volumes=[{type:'bind',source:'/protected/relay',target:'/run/secrets',read_only:true,bind:{create_host_path:false}}];
  assert.equal(validateDeployment(c,{services:{relay}}).images.turn,image);
  relay.environment.RELAY_CONTROL_ADDR='0.0.0.0:9443';assert.throws(()=>validateDeployment(c,{services:{relay}}),/private_relay/);
});

test('validation stage is source restricted and manifest digest is not self-referential',()=>{
  const c=fixture();c.services.web.environment.NOTITLE_LAUNCH_STAGE='validation';c.services.web.environment.COHORT_USERNAME='pilot';
  for(const key of ['IDENTITY','REALTIME','SAFETY','ADMIN','OPERATIONS']) c.services.api.environment[key+'_ENABLED']='true';
  c.services.api.volumes.push({type:'bind',source:'/protected/holds',target:'/var/lib/notitle/holds',bind:{create_host_path:false}}, {type:'bind',source:'/protected/operations',target:'/var/lib/notitle/operations-keys',read_only:true,bind:{create_host_path:false}});
  assert.throws(()=>validateDeployment(c),/validation_cidrs/);
  c.services.web.environment.VALIDATION_SOURCE_CIDRS='0.0.0.0/0';assert.throws(()=>validateDeployment(c),/validation_cidrs/);
  c.services.web.environment.VALIDATION_SOURCE_CIDRS='198.51.100.7/32';const first=validateDeployment(c);assert.equal(first.validation_source_restricted,true);assert.equal(first.ingress_mode,'cohort');
  c.services.api.environment.DEPLOYMENT_MANIFEST_SHA256='b2'.repeat(32);assert.equal(validateDeployment(c).compose_sha256,first.compose_sha256);
});
test('acceptance manifest binds isolated staging environment and source inventory',()=>{
  const c=fixture();c.services.api.environment.APP_ENV='staging';c.services.web.environment.NOTITLE_DEPLOYMENT_MODE='staging';
  c.services.web.environment.STAGING_USERNAME='reviewer';c.services.web.environment.STAGING_PASSWORD_HASH_FILE='/run/secrets/staging_password_hash';
  for(const key of ['IDENTITY','REALTIME','SAFETY','ADMIN','OPERATIONS']) c.services.api.environment[key+'_ENABLED']='true';
  c.services.api.volumes.push({type:'bind',source:'/protected/holds',target:'/var/lib/notitle/holds',bind:{create_host_path:false}}, {type:'bind',source:'/protected/operations',target:'/var/lib/notitle/operations-keys',read_only:true,bind:{create_host_path:false}});
  const m=validateDeployment(c,undefined,{purpose:'acceptance',sourceSHA256:'a1'.repeat(32)});assert.equal(m.environment,'isolated_acceptance');assert.equal(m.source_sha256,'a1'.repeat(32));assert.equal(m.ingress_mode,'cohort');
  assert.throws(()=>validateDeployment(c),/boot_closed/);
  delete c.services.web.environment.STAGING_USERNAME;assert.throws(()=>validateDeployment(c,undefined,{purpose:'acceptance'}),/authenticated_acceptance/);
});
