import assert from 'node:assert/strict';
import { mkdtemp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { createBuiltServer } from '../../web/scripts/serve-built.mjs';
import { appPaths, publicPaths } from '../../web/src/lib/config/routes.mjs';
import { validateBuildMarker } from '../app/prepare-runtime.mjs';

test('static server preserves public documents, private fallbacks and real 404s', async (t) => {
  const root = await mkdtemp(path.join(tmpdir(), 'notitle-static-'));
  const server = createBuiltServer({ root });
  t.after(async () => {
    server.closeAllConnections();
    await new Promise((resolve) => server.close(resolve));
    await rm(root, { recursive: true, force: true });
  });
  await mkdir(path.join(root, '_app', 'immutable'), { recursive: true });
  await Promise.all([
    ...publicPaths.map((route) => writeFile(path.join(root, route === '/' ? 'index.html' : route.slice(1) + '.html'), '<h1>Public ' + route + '</h1>')),
    writeFile(path.join(root, 'app.html'), '<meta name="robots" content="noindex"><h1>App shell</h1>'),
    writeFile(path.join(root, '404.html'), '<meta name="robots" content="noindex"><h1>Page not found</h1>'),
    writeFile(path.join(root, 'notitle-build.json'), '{"internal":true}'),
    writeFile(path.join(root, '_app', 'immutable', 'test.js'), 'export {};'),
    writeFile(path.join(root, '_app', 'private.map'), '{}'),
    writeFile(path.join(root, 'robots.txt'), 'User-agent: *\n'),
    writeFile(path.join(root, 'sitemap.xml'), '<urlset/>')
  ]);
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const base = 'http://127.0.0.1:' + server.address().port;
  for (const route of publicPaths) {
    const response = await fetch(base + route);
    assert.equal(response.status, 200, route);
    assert.match(await response.text(), /Public /);
    assert.match(response.headers.get('x-robots-tag'), /noindex/);
  }
  for (const route of appPaths) {
    const response = await fetch(base + route);
    assert.equal(response.status, 200, route);
    assert.equal(response.headers.get('cache-control'), 'no-store');
    assert.match(response.headers.get('x-robots-tag'), /noindex/);
    assert.match(await response.text(), /App shell/);
    const redirect = await fetch(base + route + '/', { redirect: 'manual' });
    assert.equal(redirect.status, 308);
    assert.equal(redirect.headers.get('location'), route);
  }
  for (const route of ['/unknown', '/design-preview', '/app.html', '/index.html', '/notitle-build.json', '/chat/nested', '/_app/private.map', '/api/unknown']) {
    const response = await fetch(base + route);
    assert.equal(response.status, 404, route);
    assert.match(response.headers.get('content-type'), /text\/html/);
    assert.match(response.headers.get('x-robots-tag'), /noindex/);
    assert.match(await response.text(), /Page not found/);
  }
  const head = await fetch(base + '/premium', { method: 'HEAD' });
  assert.equal(head.status, 200);
  assert.equal(await head.text(), '');
  const write = await fetch(base + '/premium', { method: 'POST' });
  assert.equal(write.status, 405);
  assert.equal(write.headers.get('allow'), 'GET, HEAD');
  const immutable = await fetch(base + '/_app/immutable/test.js');
  assert.equal(immutable.status, 200);
  assert.equal(immutable.headers.get('cache-control'), 'public, max-age=31536000, immutable');
  assert.equal((await fetch(base + '/robots.txt')).status, 200);
  assert.equal((await fetch(base + '/sitemap.xml')).status, 200);
});

test('runtime artifact preparation rejects invalid release markers', () => {
  const base = { schemaVersion: 2, mode: 'preview', origin: null, legalApproved: false, inventorySha256: 'a'.repeat(64), checkout: { enabled: false, environment: 'sandbox' } };
  assert.equal(validateBuildMarker(base).mode, 'preview');
  assert.throws(() => validateBuildMarker({ ...base, schemaVersion: 1 }), /unsupported/);
  assert.throws(() => validateBuildMarker({ ...base, checkout: undefined }), /checkout/);
  assert.throws(() => validateBuildMarker({ ...base, checkout: { enabled: 'false', environment: 'sandbox' } }), /checkout/);
  assert.throws(() => validateBuildMarker({ ...base, mode: 'production', origin: 'https://example.test', legalApproved: true, checkout: { enabled: true, environment: 'sandbox' } }), /sandbox/);
  assert.deepEqual(validateBuildMarker({ ...base, mode: 'production', origin: 'https://example.test', legalApproved: true, checkout: { enabled: true, environment: 'production' } }).checkout, { enabled: true, environment: 'production' });
  assert.throws(() => validateBuildMarker({ ...base, mode: 'production', origin: 'https://example.test' }), /approved/);
  assert.throws(() => validateBuildMarker({ ...base, mode: 'staging' }), /HTTPS/);
  assert.throws(() => validateBuildMarker({ ...base, mode: 'production', legalApproved: true, origin: 'http://example.test' }), /HTTPS/);
  assert.throws(() => validateBuildMarker({ ...base, origin: 'https://example.test/path' }), /exact/);
  assert.throws(() => validateBuildMarker({ ...base, origin: 'https://user:pass@example.test' }), /exact/);
  assert.throws(() => validateBuildMarker({ ...base, inventorySha256: 'unverified' }), /incomplete/);
  assert.throws(() => validateBuildMarker({ ...base, mode: 'unknown' }), /unsupported/);
  assert.equal(validateBuildMarker({ ...base, mode: 'production', origin: 'https://example.test', legalApproved: true }).mode, 'production');
});

test('shell startup fails closed across deployment modes and staging credentials', async (t) => {
  const root = await mkdtemp(path.join(tmpdir(), 'notitle-runtime-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const markerRoot = path.join(root, 'marker');
  const access = path.join(root, 'access.caddy');
  const tlsRoot = path.join(root, 'tls');
  await mkdir(tlsRoot);
  for (const name of ['origin-cert.pem', 'origin-key.pem', 'origin-pull-ca.pem']) await writeFile(path.join(tlsRoot, name), 'SYNTHETIC FILE');
  await mkdir(markerRoot);
  const source = await readFile(new URL('../app/entrypoint.sh', import.meta.url), 'utf8');
  // Change fixture paths only. The real startup branches execute unchanged.
  const entrypoint = source.replaceAll('/etc/notitle-build', markerRoot).replaceAll('/tmp/notitle-access.caddy', access).replaceAll('/tmp/notitle-global.caddy', path.join(root, 'global.caddy')).replaceAll('/tmp/notitle-tls.caddy', path.join(root, 'tls.caddy')).replaceAll('/tmp/notitle-admission.caddy', path.join(root, 'admission.caddy')).replaceAll('/run/notitle-origin', tlsRoot);
  await writeFile(path.join(root, 'entrypoint.sh'), entrypoint);
  await writeFile(path.join(root, 'caddy'), '#!/bin/sh\nprintf "%s\\n" "Caddy handoff reached"\n', { mode: 0o700 });
  async function run(mode, origin, approved, env) {
    await Promise.all([
      writeFile(path.join(markerRoot, 'mode'), mode + '\n'),
      writeFile(path.join(markerRoot, 'origin'), origin + '\n'),
      writeFile(path.join(markerRoot, 'legal-approved'), String(approved) + '\n')
    ]);
    return spawnSync('/bin/sh', [path.join(root, 'entrypoint.sh')], {
      encoding: 'utf8', env: { PATH: root + ':/usr/bin:/bin', ...env }
    });
  }
  assert.equal((await run('preview', '', false, { APP_ADDRESS: ':8080' })).status, 0);
  assert.match(await readFile(access, 'utf8'), /noindex/);
  assert.notEqual((await run('preview', '', false, { APP_ADDRESS: 'example.test' })).status, 0);
  const production = { ORIGIN_AUTH_SCOPE: 'zone', NOTITLE_DEPLOYMENT_MODE: 'production', APP_ADDRESS: 'example.test', PUBLIC_ORIGIN: 'https://example.test' };
  assert.notEqual((await run('preview', '', false, production)).status, 0);
  assert.notEqual((await run('production', 'https://example.test', false, production)).status, 0);
  assert.notEqual((await run('production', 'https://different.test', true, production)).status, 0);
  assert.equal((await run('production', 'https://example.test', true, production)).status, 0);
  assert.match(await readFile(access, 'utf8'), /noindex/);
  assert.match(await readFile(path.join(root, 'admission.caddy'), 'utf8'), /respond @new_admission.*503/);
  assert.match(await readFile(path.join(root, 'tls.caddy'), 'utf8'), /require_and_verify/);
  assert.equal((await run('production', 'https://example.test', true, {...production, NOTITLE_LAUNCH_STAGE:'public'})).status, 0);
  assert.equal(await readFile(access, 'utf8'), '');
  assert.equal(await readFile(path.join(root, 'admission.caddy'), 'utf8'), '');
  assert.notEqual((await run('production', 'https://example.test', true, {...production, NOTITLE_LAUNCH_STAGE:'cohort', COHORT_USERNAME:'pilot'})).status, 0);
  await writeFile(path.join(tlsRoot, 'cohort-password-hash'), '$2b$12$' + 'B'.repeat(53) + '\n');
  assert.equal((await run('production', 'https://example.test', true, {...production, NOTITLE_LAUNCH_STAGE:'cohort', COHORT_USERNAME:'pilot'})).status, 0);
  assert.match(await readFile(path.join(root, 'admission.caddy'), 'utf8'), /basic_auth @new_guest/);
  assert.doesNotMatch(await readFile(path.join(root, 'admission.caddy'), 'utf8'), /support|webhooks|privacy|payments\/verify/);
  const validation = {...production, NOTITLE_LAUNCH_STAGE:'validation', COHORT_USERNAME:'pilot', VALIDATION_SOURCE_CIDRS:'198.51.100.7/32'};
  assert.notEqual((await run('production','https://example.test',true,validation)).status,0);
  await writeFile(path.join(tlsRoot, 'cloudflare-proxies'), '203.0.113.0/24\n');
  assert.equal((await run('production','https://example.test',true,validation)).status,0);
  assert.match(await readFile(path.join(root, 'admission.caddy'), 'utf8'), /not client_ip 198\.51\.100\.7\/32/);
  assert.match(await readFile(path.join(root, 'global.caddy'), 'utf8'), /client_ip_headers CF-Connecting-IP/);
  assert.notEqual((await run('production','https://example.test',true,{...validation, VALIDATION_SOURCE_CIDRS:'0.0.0.0/0'})).status,0);
  assert.notEqual((await run('production','https://example.test',true,{...validation, VALIDATION_SOURCE_CIDRS:'198.51.100.7/32;respond / 200'})).status,0);
  const staging = { NOTITLE_DEPLOYMENT_MODE: 'staging', APP_ADDRESS: 'stage.example.test', PUBLIC_ORIGIN: 'https://stage.example.test', STAGING_USERNAME: 'reviewer' };
  assert.notEqual((await run('staging', staging.PUBLIC_ORIGIN, false, staging)).status, 0);
  const hashFile = path.join(root, 'staging-hash');
  // Synthetic format fixture; it is never used as an authentication credential.
  await writeFile(hashFile, '$2b$12$' + 'A'.repeat(53) + '\n');
  staging.STAGING_PASSWORD_HASH_FILE = hashFile;
  assert.equal((await run('staging', staging.PUBLIC_ORIGIN, false, staging)).status, 0);
  assert.match(await readFile(access, 'utf8'), /basic_auth @staging_browser \{/);
  assert.match(await readFile(access, 'utf8'), /^@staging_browser not path \/api\/v1\/webhooks\/cashfree$/m);
  assert.match(await readFile(access, 'utf8'), /noindex/);
  assert.notEqual((await run('staging', staging.PUBLIC_ORIGIN, false, { ...staging, STAGING_USERNAME: 'reviewer\n}' })).status, 0);
  await writeFile(hashFile, '$2b$12$' + 'A'.repeat(53) + '\n}\n');
  assert.notEqual((await run('staging', staging.PUBLIC_ORIGIN, false, staging)).status, 0);
});
