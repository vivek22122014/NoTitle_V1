import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp, mkdir, rm, writeFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {createPlan} from '../../scripts/deploy-plan.mjs';
import {newEvidence, sourceDigest} from '../../scripts/launch-evidence-lib.mjs';
test('pending evidence cannot produce a deployment plan or read a pretend manifest', async t=>{
  const root=await mkdtemp(path.join(tmpdir(),'notitle-deploy-plan-'));t.after(()=>rm(root,{recursive:true,force:true}));
  const source=path.join(root,'source');await mkdir(source);await writeFile(path.join(source,'README.md'),'Synthetic source.');
  const evidence=path.join(root,'evidence.json');await writeFile(evidence,JSON.stringify(newEvidence({source_sha256:(await sourceDigest(source)).sha256,origin:null,images:null})));
  const result=await createPlan({source,evidence,manifest:path.join(root,'does-not-exist')});
  assert.equal(result.exitCode,1);assert.equal(result.output.state,'blocked');assert.equal(result.output.operations,undefined);
});
