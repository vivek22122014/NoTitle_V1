# Phase 10 production candidate — closed until evidence passes

Read [the Phase 10 deployment runbook](../../docs/phase10-deployment.md) before this historical phase-by-phase guidance. Production now boots the API in maintenance mode and Caddy with `NOTITLE_LAUNCH_STAGE=maintenance`. Provision protected `ORIGIN_TLS_DIRECTORY` (origin certificate/key, Cloudflare AOP CA) and `LAUNCH_APPROVAL_DIRECTORY`; no approvals are supplied. The independent API owner-MFA admission control must be opened only against a current source/image-bound launch approval. `validation` adds source-restricted protected ingress for a bounded preauthorized production check, and `cohort` adds protected ingress credentials; `public` removes that ingress gate only after the supervised cohort evidence passes. Changing Caddy never opens the backend by itself.

The current database schema is **9**. Planning budgets on the 4-GiB app VM are PostgreSQL1280MiB, API768MiB and Caddy192MiB, leaving host/backup overhead. These are unbenchmarked budgets, not capacity evidence. The separate1-GiB TURN VM uses a768MiB container cap. The required200-connected/25-call mixed workloads remain acceptance gates.


This cumulative source implements accounts, realtime matching, text, reporting/private moderation, mutual connections, friend invitations and relay-only audio, with full acceptance still pending. Audio runtime acceptance, payments, operational backups and staffed safety workflows remain launch gates. This template covers the low-cost app host; Phase7 adds a separate TURN host. Neither has been deployed or load-tested.

The web container now rejects preview/staging artifacts in production. The frontend must be built with `PUBLIC_RELEASE_MODE=production`, `PUBLIC_SITE_ORIGIN=https://` followed by the actual canonical hostname, and a complete reviewed release inventory in `web/config/release.json` and plan configuration in `web/config/plans.json`. Draft policy values block the production build. Runtime `PUBLIC_ORIGIN` and `APP_ADDRESS` must exactly match that built origin. A runtime variable alone cannot promote a preview image.

After filling and approving the inventory, an operator can build an image candidate with the following command (the shell variables must contain real approved values):

```bash
docker build -f deploy/app/Caddy.Dockerfile \
  --build-arg PUBLIC_RELEASE_MODE=production \
  --build-arg PUBLIC_SITE_ORIGIN="https://${APP_DOMAIN}" \
  -t "$NOTITLE_WEB_BUILD_TAG" .
```

Publish through the approved registry process and resolve the resulting immutable digest before setting `NOTITLE_WEB_IMAGE`. No image build, registry publication or deployment is performed by this documentation.

Only Caddy publishes TCP443; the provider firewall restricts it to reviewed Cloudflare address ranges. PostgreSQL sits on an internal Docker network without a host port. API containers reach both networks. The public API has no host port; the separate moderation listener binds only host loopback at9090. This same-host private database bridge uses a SCRAM credential; local example DSNs disable transport TLS because they never cross a host boundary. If the database moves to another machine or service, provision certificate verification and use sslmode=verify-full.

Before an authorized release:

1. Complete all application/security/business gates and run `make check` on a networked machine.
2. Build the API, migration and Caddy images from the exact reviewed source with committed locks. Resolve every base image digest and scan operating-system and application dependencies. Record commit, tool versions, image digests and scan output in the release record. Tags alone are insufficient for a public release.
3. Provision the approved host/firewall/DNS. Restrict SSH by key and source policy. Keep PostgreSQL/API/admin ports private; TCP443 is the only published public container port.
4. Generate independent production passwords outside git and build contexts. Provision the five database secret files on the host: administrator password, migration password, runtime password, migration DSN and runtime DSN. DSNs must match the corresponding role/password and private host `postgres`, database `notitle`. Never reuse `.local` development secrets.
5. Restrict host secret directories to their operator. Use owner-only 0400/0600 regular secret files; the final deployment validator rejects group/other-readable files, including 0444. Runtime DSN files must be owned/readable by API UID 65532. Separately provision migration and PostgreSQL files for the actual users of those pinned images and verify readability inside each container. Compose file-secret uid/gid/mode settings do not remap ordinary bind-mount ownership. Use a reviewed Linux volume preparation step when the host filesystem cannot preserve these permissions. For rotation, update the database role and mounted credential together, then restart affected clients; modifying files alone is insufficient.
6. Configure off-host encrypted database backups and a tested restore; include separate restoration of deployment configuration and Caddy state. Define the operating log retention/export policy before real users. The small rotating Docker logs here only prevent disk exhaustion and do not satisfy statutory retention by themselves.
7. Set environment variables to reviewed image references and absolute secret paths, inspect the rendered configuration, then initialize PostgreSQL and apply the dedicated migration image before starting API/web.
8. Test HTTPS, headers, correct origins, schema/role readiness, restart recovery and a restore rehearsal. Measure memory and latency under realistic load before assigning capacity.

Required variables (values are not included):

```text
APP_DOMAIN
NOTITLE_POSTGRES_IMAGE
NOTITLE_API_IMAGE
NOTITLE_WEB_IMAGE
NOTITLE_MIGRATION_IMAGE
POSTGRES_ADMIN_PASSWORD_FILE
POSTGRES_MIGRATION_PASSWORD_FILE
POSTGRES_RUNTIME_PASSWORD_FILE
MIGRATION_DATABASE_URL_FILE
RUNTIME_DATABASE_URL_FILE
```

All four image references must use reviewed `@sha256:` digests; resolve them through the actual registry, never invent them. `./scripts/production-config.sh` validates these references and emits only a sanitized manifest, withholding the interpolated Compose configuration. It performs no deployment. Supply an environment file via `--env-file /protected/path` if desired; that file contains paths/image references, not inline passwords.

After separate release authorization, the operator sequence is `docker compose -f deploy/production/compose.yml up -d --wait postgres`, then `docker compose -f deploy/production/compose.yml --profile ops run --rm migrate up`, then `docker compose -f deploy/production/compose.yml up -d api web`. In Phase10, API readiness intentionally stays503 while admission is closed; do not use `--wait api` as the approval mechanism. Add the same protected `--env-file` argument to every command if used. These commands are documented, not executed by any bootstrap or CI job.

The current template caps PostgreSQL at 1280MiB, API at 768MiB and Caddy at 192MiB with 8 API database connections / 40 database connection maximum. These are provisional limits, not a measured chat/audio capacity envelope. Revisit limits with later phases, realistic load and the blueprint's 4GiB host budget. A single host has a shared failure domain; off-host backups are necessary, and high availability remains a later measured upgrade.

## Phase 3 identity and deletion volume

Identity remains disabled by default in this template. After the full acceptance suite and policy approvals, set `IDENTITY_ENABLED=true` and explicit `TERMS_VERSION`, `PRIVACY_VERSION`, `COMMUNITY_VERSION` values matching the reviewed public policy copies. This is a deliberate release setting, not a paid service activation.

The `deletion_tombstones` volume is separate from `postgres_data`. It must be owned by UID/GID65532 with mode0700; the runtime image seeds a new named volume. Preserve it across restarts and database restoration. Do not run volume-deleting commands against production. Stop the API for a database restore, restore/verify the independent journal, then restart: identity readiness stays closed until replay completes. Never replace an existing journal with an empty directory to bypass an error.

Before launch, configure and test encrypted off-host journal/database backups and continuity checks. This source supplies local durable records and replay, not a managed backup service or final erasure worker. API memory budget is768MiB for two bounded64MiB Argon2 operations plus runtime overhead; benchmark the target VM, including PostgreSQL/Caddy, before accepting the budget.

## Phase 4 realtime candidate

`REALTIME_ENABLED=false` remains the deployed default. Controlled acceptance environments can set it to `true` alongside identity. Caddy's existing same-origin `/ws` route carries the upgrade; there is no new listener, Redis instance, hosted realtime subscription or public Premium toggle. Keep exactly one API replica.

Apply all migrations through version9 before starting this cumulative API version. Rolling back binaries requires an explicit schema compatibility decision; do not run destructive DOWN migrations on real data. A restart ends live interactions, guests, temporary connections and invitations. Registered profiles/preferences and committed account friendships remain in PostgreSQL; clients must reconnect and explicitly search or invite again. Shutdown closes and waits for hijacked WebSockets before stopping their coordinator.

## Phase 5 protected text/report acceptance

Provision independent `EVIDENCE_KEYRING_FILE` and `ADMIN_MFA_KEY_FILE` host files in addition to the database secrets. The evidence file is JSON with `active_key_id` and a `keys` object mapping key IDs to base64-encoded random32-byte keys; the MFA file contains a separate base64-encoded random32-byte key. See configuration documentation. Both are mounted read-only; own them by UID65532 with mode0400 inside a protected directory. All secret files must retain owner-only permissions. Compose bind mounts preserve host ownership/mode. Store recoverable encrypted key backups separately from ordinary database backups. Changing the active evidence key requires retaining old keys until all protected records and approved backups can be decrypted; this is not an automatic rotation service.

After full runtime acceptance, approved retention and staffed coverage, configure `SAFETY_ENABLED=true`, `ADMIN_ENABLED=true`, the reviewed `CASE_RETENTION_DAYS` and `CASE_RETENTION_POLICY_VERSION`, `MODERATION_COVERAGE_CONFIRMED=true`, and a private HTTPS `ADMIN_ORIGIN` on a distinct hostname. Flags are assertions of completed work, not automatic approval. Both flags defaultfalse in this template. Host loopback port9090 can be changed with `ADMIN_PORT`; it must only be reached through an authenticated private gateway/VPN with TLS. Preserve the configured Host/Origin. Public Caddy has no admin route. Apply migrations through 9 before starting the candidate and provision founder/backup operators through the offline CLI; there is no default login.

Human report/grievance coverage, training and a backup must exist before any real-user testing. The public grievance page remains an honest draft until actual contact details and the case workflow are approved. Case retention deadlines and holds are recorded, but automated hold-aware erasure is implemented in Phase9 and requires its runtime/retention gates. Do not enable public use on the strength of a source check or a config flag.

Run the report/block/admin tests, selected-evidence SQL canary and clean logs check in the disposable full-stack suite. Exercise database failure, Next/report races, restart, encrypted backup restore with retained keys, and interrupted guest handoff. A pending account handoff is fail-closed and cannot be repaired by blind fence deletion. Keep one API replica, the same PostgreSQL and static frontend; no additional paid provider is introduced.

## Phase 6 connections candidate

`FRIENDS_ENABLED=false` remains the deployed default. After Phase6 acceptance, set it to true together with safety; `FRIENDS_PER_IDENTITY` defaults to 100 and only lowers new-admission capacity when reduced. The existing Go owner coordinates random and friend interactions; the existing database stores only committed account friendships. There is no Redis, extra listener or hosted messaging subscription. Invitations are online-only and expire after 30 seconds. Audio invitations additionally require the Phase7 audio gates and share the call allocator.

Run `docs/phase6-acceptance.md`, including stale-write removal fences, offline-peer promotion, restart, blocked/deleted users, two independent browser contexts and mobile/desktop views. Benchmark the intended host with 200 connected users, realistic friendship density and typing/receipt traffic before accepting resource limits. The 25-call requirement remains an unmeasured full-V1 target for the media phase.

## Phase 7 audio candidate

`AUDIO_ENABLED=false` remains the default in every base stack. After controlled acceptance, production additionally requires `AUDIO_SAFETY_VERIFIED=true`; this flag records an operator assertion, not an automated test result. Review `../audio/compose.app.yml` with this app configuration and deploy `../turn/compose.yml` on the separate relay host. Use reviewed immutable image digests, protected private-control bearer and mTLS files, DNS-only TURN records, a publicly trusted certificate and the documented firewall. Do not share the public web TLS listener with TURN TLS443.

Read `../../docs/phase7-relay-runbook.md` and complete `../../docs/phase7-acceptance.md`: private lease/revocation control, actual coturn inventory/cancellation, old-credential replay, watchdog/restart failures, bounded clock skew, microphone consent, mobile/desktop network testing and both six-hour 200-connected/25-call workloads. Capacity reservations include uncertain relay cleanup. Do not enable audio or reduce the minimum because a source check passes. If relay control becomes unavailable, calls end while text remains independently available. Signaling reconnection never restarts the microphone automatically.

Audio-only rollback must terminate active calls, revoke allocations and confirm relay shutdown before removing its configuration. Private reported-call references/timing use the existing encrypted case metadata; no ordinary call history, recording or new database migration is introduced. The relay VM is already part of the approved blueprint budget; do not count it twice.
