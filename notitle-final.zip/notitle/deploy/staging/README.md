# Protected staging

Staging is optional and temporary; it needs no separate ongoing subscription. Use an isolated host/environment and separate credentials and database volumes. Never overlay this configuration on a live production project.

Build the frontend image using `PUBLIC_RELEASE_MODE=staging` and `PUBLIC_SITE_ORIGIN=https://` followed by the actual staging hostname. Set `APP_DOMAIN` to that same hostname. Use reviewed digest references and the external database secrets required by the production template.

Set `STAGING_USERNAME` to a username containing only letters, digits, underscore or hyphen. Generate a unique password hash using Caddy's interactive `caddy hash-password` command. Put the **bcrypt hash only** in a protected external file and set `STAGING_PASSWORD_HASH_FILE` to its absolute host path. Do not put a plaintext password into Compose, shell arguments, git or an image. The runtime refuses missing or malformed hash input and applies Basic Authentication over HTTPS. Only the exact `/api/v1/webhooks/cashfree` route is exempt so Cashfree can deliver signed events; the API independently rejects invalid signatures and acknowledges only durable inbox commits. Payments default off, making that route unavailable. No other API, page, checkout or browser-return route is exempt.

Render both files before any separately authorized deployment:

```bash
docker compose --project-name notitle-staging --env-file /protected/staging.env \
  -f deploy/production/compose.yml -f deploy/staging/compose.yml config
```

Use both files and the same distinct project name for migration, startup and teardown. The staging overlay changes the API environment, requires web authentication and leaves all pages noindex. Browser test credentials belong in protected test configuration, never the URL. Verify unauthenticated browser responses are 401, authenticated routes work, noindex survives all response paths and `/design-preview` remains 404. Exercise the exact webhook exception with valid/invalid signatures and ensure trailing or nested paths still require Basic Authentication. Local static preview is deliberately separate and available only on loopback.

No staging host has been provisioned or deployed by this implementation. Caddy parsing and live Basic Authentication need container verification before use.
