# Application-side audio control

The ordinary development and production stacks keep audio off. The optional `compose.app.yml` adds only the application's authenticated control connection; the media relay remains on its own host. Merge this file after the appropriate base Compose files. Use absolute host paths for all four control files, so Compose's first-file path rules cannot redirect secrets.

The control URL is a private HTTPS origin. Configure its server certificate, trusted CA and client certificate for mutual TLS, plus the independent control token. Use a private network/firewall rule admitting only the application host. Public Caddy never proxies the control service. The approved public TURN addresses are separate from this private URL.

Staging is for controlled acceptance and can use `AUDIO_ENABLED=true` without the production assertion. Production additionally requires `AUDIO_SAFETY_VERIFIED=true` after the real relay/device/shutdown/load evidence is recorded. This boolean records an operator decision; it does not execute or substitute for tests. Safety and realtime must be enabled. The supervisor must synchronize successfully before the owner advertises audio availability.

For a review-only production configuration rendering, append `-f deploy/audio/compose.app.yml` after `-f deploy/production/compose.yml` and run `docker compose ... config --quiet` with the reviewed environment and secret paths. Do not print inline secrets or disable TLS verification to make the control connection work. The base release script still validates image references; this overlay adds no image or paid service.

On a host process used for local tests only, explicit literal-loopback HTTP can be enabled with `AUDIO_ALLOW_LOOPBACK_HTTP=true`; that exception is refused in staging/production. The supplied Compose overlay deliberately uses mutual TLS even for container testing.

Run `docs/phase7-acceptance.md` and follow `docs/phase7-relay-runbook.md` plus `deploy/turn/README.md`. Source checks do not deploy the relay, issue public certificates, test real microphone devices or establish the 200-connected/25-call capacity.
