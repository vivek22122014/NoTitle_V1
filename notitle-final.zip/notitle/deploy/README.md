# Local deployment contract

This cumulative Phases1–7 source supplies the foundation, public pages/SEO, identity, realtime matching, text/safety/moderation, mutual connections, friend invitations and relay-only audio. Audio defaults off until its runtime acceptance passes; billing remains later work. Full acceptance and public launch remain pending. Deployment files are reviewable templates, not executed deployments.

## Prerequisites and first run

Install Bash and Docker Engine/Desktop with Docker Compose v2.30 or newer. On Windows, run these commands in WSL2 with Docker Desktop integration. Docker must be running. Host Go and Node installations are not required; the scripts use pinned containers. Allow outbound access to Docker Hub, the Go module proxy/checksum database, npm registry and, for checks, the Go vulnerability database and Playwright browser downloads. Reserve several GB of free disk and approximately 4GB of local Docker memory for builds and browser tests; this is a development prerequisite, not a production capacity claim.

From the repository root:

```bash
./scripts/bootstrap.sh
```

Default mode is `dev`. The command:

1. Creates a private `.local/secrets` directory and three independent 256-bit random passwords. Existing secret values are never replaced.
2. Creates migration/runtime connection files for fixed, separate database roles.
3. Runs pinned Go formatting and authentic module resolution; creates `server/go.sum` if missing. Existing locks are verified rather than silently refreshed.
4. Generates `web/package-lock.json` through npm if missing, runs `npm ci`, and formats frontend source using the installed project formatter.
5. Runs the release source/lock audit, starts PostgreSQL, applies Goose migrations, then waits for the API and Vite frontend to become healthy.

Review and commit source formatting changes, `server/go.mod`, `server/go.sum` and `web/package-lock.json` after initial preparation. Nothing fabricates checksums. A download, permission, lock, build or health failure stops the command; it is not reported as a passing application check.

Open http://localhost:5173. Vite proxies API/health/WebSocket paths over the private Docker network, so the browser uses one origin. Frontend edits hot reload. `make api-restart` recompiles and restarts the development API. There is no public or loopback PostgreSQL port.

Phase 2 local builds are explicitly previews: all static responses are noindex and draft policies remain visibly marked. The image startup refuses a preview artifact in production. Hosted staging requires access control; see `app/README.md`, `staging/README.md` and `production/README.md` for the reviewed release inventory, origin and artifact-mode contracts. No unresolved legal/operator placeholder can be published by the production build path.

## Modes and commands

| Command | Effect |
|---|---|
| `./scripts/bootstrap.sh prepare` | Creates/preserves local secrets, formats source and generates/verifies authentic locks; does not start the app |
| `./scripts/bootstrap.sh dev` | Full development stack with Vite; first-run default |
| `./scripts/bootstrap.sh static` | Full stack with compiled API and Caddy static frontend at http://localhost:8080 |
| `make dev` / `make static` | Start/rebuild the chosen stack after preparation; no source formatting or lock generation |
| `make api-restart` | Recompile/restart development API; use only while dev mode is active |
| `make down MODE=dev` | Stop local containers, preserve PostgreSQL volume |
| `make logs MODE=static` | Follow selected local stack logs |
| `make migrate` / `make migrate-status` | Apply migrations or inspect version status |
| `make check` | Strict full acceptance checks; never formats or generates locks |
| `make db-check` | Fresh isolated PostgreSQL role/migration/backend/security checks |
| `make smoke` | Fresh isolated Caddy/API routing, CSP and readiness checks |

Modes share the same local PostgreSQL volume, and switching modes recreates the API/web containers. Default browser ports are loopback only. To change ports, edit the nonsecret `deploy/dev/.env` port and matching `*_PUBLIC_ORIGIN` values together. A single machine should run one default local mode at a time.

Each destructive migration test uses its own uniquely named Compose project and volume and removes only that test volume afterward. The migration wrapper permits `down` only when an explicit disposable-database flag is set by those test scripts. Production rollback uses a reviewed forward repair or validated restore; it does not automatically run destructive SQL.

## Credentials and database privileges

Local secret creation starts with `umask 077`; the host parent directories are 0700. Files are read-only 0444 so Docker Compose's file mounts can be read by PostgreSQL and the unprivileged API UID 65532. The restricted parent prevents access by other normal host users. Docker/host administrators can still access them. Compose secrets are file mounts, not encrypted secret storage. Files and local directories are excluded from git and image contexts.

The administrator credential is mounted only into PostgreSQL. Initialization creates:

- `notitle_bootstrap`: cluster/bootstrap administrator; never used by the app or migration runner.
- `notitle_migrate`: can connect/create schemas, owns schema and Goose bookkeeping, has no superuser/database-creation/role-management/bypass-RLS powers.
- `notitle_app`: can connect, use the application schema and perform only explicit per-table operations granted by migrations. It cannot create temporary/persistent objects, inherit another role or mutate the marker. Friendship grants are SELECT/INSERT/DELETE, without UPDATE.

PUBLIC database/schema privileges are revoked. Future migrations must grant explicit table operations; broad default runtime write grants are absent.

The current readiness contract is exactly one row with `version=7` in `notitle.schema_version`, owned by `notitle_migrate`. The backend checks database access, marker and restricted role permissions. Migration6 adds the normalized durable account friendship table, consent timestamps, revision fences and atomic block/deletion cleanup. Temporary guest links, requests, invitations, presence and ordinary chat remain outside PostgreSQL.

PostgreSQL 18 uses `PGDATA=/var/lib/postgresql/18/docker`, with the persistent volume mounted at `/var/lib/postgresql`. Initialization scripts only run on a new empty volume. Editing a password file does not rotate an existing database role. Rotation is a deliberate operator procedure; bootstrap never attempts it.

## Validation and release limits

CI requires committed, nonempty authentic dependency locks and executes `scripts/audit.mjs --release` before builds. It runs Go formatting checks, module verification, vet, race tests with a real restricted-role database, reversible migration/DDL denial checks, govulncheck, frontend type/lint/build checks, npm security audit, mobile/desktop browser tests and the Caddy smoke tests. Smoke tests stop the actual database, assert liveness 200/readiness 503, restart it and wait for readiness recovery. They also stop the API with SIGTERM and require exit code 0 with no OOM kill. These are executable gates, not results already obtained here. Missing registry/advisory access fails verification.

Current pins are Go 1.27.2, Node 24.19.0, PostgreSQL 18.6, Caddy 2.11.7, Goose 3.28.0 and govulncheck 1.8.0. The migration runtime is Debian 13-slim. Version tags are intentionally visible; image digests still need to be resolved, scanned and recorded on a networked release machine before deployment. CI checkout is pinned to the official v7.0.1 commit 3d3c42e5aac5ba805825da76410c181273ba90b1:
https://github.com/actions/checkout/commit/3d3c42e5aac5ba805825da76410c181273ba90b1

The repository was prepared in an environment without Go/Docker and with dependency downloads restricted. Shell/JS/source inspection is not a substitute for the real checks above. Do not mark Phase 1 acceptance complete until they execute successfully.

No scheduled deployment, cloud account, registry publication, paid service, SMTP or telemetry sink is created by these files.

Phase5 adds a one-shot local key initializer and private admin loopback port9090. The normal stack remains one static Caddy frontend, one Go API/owner and one PostgreSQL instance. Encryption keys are copied to a UID65532 mode0400 volume; this initializer is setup work, not another running application service. See `docs/phase5-moderation.md` before operator provisioning.

Phase6 adds no running service or provider. `FRIENDS_ENABLED=true` is explicit in local development and defaults false in production; it requires safety. `FRIENDS_PER_IDENTITY=100` sets new connection admission, with a supported range 1–100. Keep one API owner. The disposable smoke suite exercises mutual consent, invitation expiry/busy behavior, account promotion, remove/block and authorization boundaries. See `docs/phase6-acceptance.md` before enabling a deployed candidate.

Phase7 adds the blueprint's separate coturn host with a private lease supervisor and watchdog. The app host still runs one API owner, PostgreSQL and Caddy. Audio requires explicit Call/Accept consent, private authenticated relay admission and approved relay addresses. No recording or managed media subscription is added. Start with `audio/README.md`, `turn/README.md` and `../docs/phase7-relay-runbook.md`. Both base stacks retain `AUDIO_ENABLED=false`; enabling the app overlay does not provision a relay, certificate or firewall. Run `../docs/phase7-acceptance.md`, including actual allocation cancellation/replay checks, physical devices and both six-hour 200-connected/25-call workloads before public activation. Phase 8 advances readiness to version7; call state and credentials remain transient.

## Phase 8 payment processing

Migration7 adds the versioned purchase/FIFO ledger, refund/dispute records, restricted financial review, webhook inbox, jobs and reconciliation. The existing app process runs bounded financial workers; no additional worker container or managed service is required. Runtime credentials cannot publish catalog versions, change immutable purchase economics or update/delete append-only financial history. Financial records must survive identity deletion under reviewed retention.

Both base stacks keep payment processing and checkout off. Read `payments/README.md` for the optional protected-credential overlay and separate SDK build settings. Maintain processing after purchases exist; use `CHECKOUT_ENABLED=false` to pause new purchases. Run `../docs/phase8-acceptance.md` before activation. Schema7 rollout must precede the new API, and rollback must retain financial history; down migrations are disposable-test operations only.
