# Offline release evidence

These tools assemble and check release evidence. They do not provision infrastructure, send notifications, perform payments, change feature flags or open public access. A fresh source delivery has pending gates; it is not a launch certificate.

Keep the evidence directory outside the source tree, on a protected operator machine. Do not put credentials, raw chat, audio, SDP, payment contact details or unrestricted case evidence in reports. Use sanitized logs and separately restricted approval records.

```bash
node scripts/launch-evidence.mjs init --source . --out ../release-evidence/evidence.json
node scripts/launch-evidence.mjs check --source . --evidence ../release-evidence/evidence.json
```

The output directory must already exist. `init` computes the actual source inventory digest and creates only pending records. It never overwrites an existing file. `--origin` and `--images` may supply the real production origin and a JSON object containing actual immutable registry references. Omit unknown values until verified. Local Docker image IDs are not registry manifest references.

`check` emits a JSON checklist and exits **0** when the supplied evidence satisfies the selected purpose, **1** when blocked, and **2** when malformed or inaccessible. Its default purpose is `launch`. It does not execute commands recorded in evidence and does not fetch remote URLs. The structural JSON schema is `evidence.schema.json`; runtime checks additionally enforce hashes, source consistency, dates, measurements, individual gate details and approval artifacts. `checklist.template.json` is a planning inventory, not a passing evidence file.

## Binding and evidence files

`release` contains the source digest, production origin, schema9, actual `api`, `web`, `migrate`, `postgres` and `turn` registry references, and the SHA-256 of the exact production deployment manifest bytes. The separate `release.acceptance` contains the isolated HTTPS `staging.`/`load.` origin, tested images and acceptance manifest hash. API, migration, PostgreSQL and TURN images must be identical. The static web image may differ only for the reviewed canonical origin, release mode and sandbox checkout build settings. Record the comparison, actual resolved configurations and final production smoke results; a different backend build needs new acceptance runs.

Use `deploy-config.mjs validate --purpose production|acceptance --source DIR` with actual resolved application and relay Compose inputs and `--check-files`. See the deployment documentation for the complete invocation. The acceptance manifest must declare the same source digest, schema9, isolated environment and all features. Production must boot in maintenance, with exactly one API owner. For a controlled-validation permit, its reviewed ingress is authenticated and restricted to approved source ranges. Full V1 cannot be certified with audio, checkout or any other finalized feature disabled.

Each `artifacts` entry is `{ "path": "relative-file-name", "sha256": "actual-file-hash" }`. Paths are relative to the evidence file directory; absolute paths, traversal and symlinks are rejected. Files are bounded to64MiB each/512MiB total. Gate `artifact_ids` must identify the files reviewed for that gate. Changing any file invalidates its hash. Record actual command text for reproducibility, but the checker never executes it.

Every passed gate needs `status`, a named `reviewer`, UTC `completed_at`, bounded `valid_until`, listed artifact IDs and its required `details`. Most technical evidence expires within30days; deployment, external monitoring, production smoke and owner rollout decisions within7days; legal/tax/merchant reviews within90days. A new signature cannot refresh an old capacity report. All five named role approvals—engineering, business, operations, counsel and accountant—need their own current artifact references. One person may hold several roles; primary and backup operations coverage still require distinct people.

Source inventory covers relative file names, executable status and bytes. It excludes only the documented generated/dependency directories in `sourceDigest`; private environment/credential files are rejected. Evidence outputs stay outside source to avoid self-reference. Any source, lock or executable-mode change invalidates the recorded source digest. This algorithm does not establish dependency authenticity or review quality; those remain explicit reviewed gates.

## Gate details

The authoritative field checks are in `scripts/launch-evidence-lib.mjs`. Lists below identify the required content of sanitized artifacts, not results obtained by source delivery.

| Gates | Required detail |
| --- | --- |
| `source_dependencies`, `backend_database`, `web_build` | `commands` rows with the fixed required check name, actual command, `exit_code:0`, `skipped:0` and gate-listed log artifact. Go format/vet/build/race/fuzz, real PostgreSQL integration/migration/role checks and Svelte/browser execution cannot be replaced by source syntax checks. |
| `acceptance_matrix`, `security_review`, `accessibility_seo` | Full fixed `coverage` lists from the validator, mapped to actual reports. Coverage spans shared matching, lifecycle races, money, security, mobile/desktop, initial HTML, private noindex/cache behavior, keyboard/screen reader and widths320–1920. |
| `browser_desktop`, `mobile_real_devices` | `devices` rows with exact browser/OS versions and gate-listed artifact IDs. Desktop Chrome/Edge/Firefox/Safari on supported systems; desktop Safari uses macOS. Mobile rows require physical Android Chrome and iPhone Safari, hardware, version and every mobile workflow. Emulation does not pass these rows. |
| `audio_enforcement` | Full consent/privacy/replay/failure/network coverage, measured `max_cancel_seconds<=5` and `max_orphan_seconds<=30`. |
| `load_a`, `load_b`, `overload` | `report_id`, `permit_id` and `baseline_id` pointing to gate-listed hashed JSON files. The original baseline must bind the same run, source, origin, images, process/window timestamps and exact histogram scopes; report-shaped hashes alone do not pass. The checker invokes the independent load validators, verifies the original permit for the run window and binds reports to the acceptance deployment. Both six-hour200-connected/25-call real-media scenarios and400-offered overload must pass. |
| `dense_friends` |200accounts ×100distinct offline friends,20,000retained relationships, explicit duration of at least30minutes, finite p95 owner latency below100ms, at least25% memory headroom, zero rejected legitimate operations, typing/rate-boundary/presence/ACK coverage. The30-minute duration is a conservative engineering acceptance floor for this separate test, not a blueprint claim that a benchmark ran. |
| `restore`, `rollback_drain` | Full WAL, hold/deletion replay, restored-session revocation, money reconciliation, corrupt/missing archive cases and backup-operator evidence; measured RPO<=900s/RTO<=14,400s. Rehearse two-minute drain, relay cleanup and compatible code rollback without restoring an old database to undo code. |
| `deploy_security` | `report_id` production manifest; `acceptance_manifest_id`; `build_difference_review_id`; exact `allowed_build_differences` list of `web_canonical_origin`, `web_release_mode`, `cashfree_sandbox`. All IDs must be listed and hash-verified. |
| `domain_tls`, `external_monitor`, `operator_drills` | Actual domain/TLS/firewall/private-admin configuration, independently observed lost-host alert delivery/human acknowledgement, WAL/journal recovery and all four timed operator drills including independent backup coverage. |
| `legal_privacy`, `tax_refunds`, `merchant_approval` | Named current approvals for actual product/operator, applicable rules/effective dates, retention/notices, refunds/tax/invoices and actual provider acceptance of guests, random audio/text, friends and paid gender preferences. Templates/flags cannot supply approval. |
| `live_money` | Prior explicit authorization artifact and named authorizer/time; actual start and later verified settlement time; capture/webhook/single entitlement/receipt/refund/bank credit/settlement evidence. Sandbox results cannot pass. |
| `production_smoke` | Actual final deployment: two-browser conversation, report/block, cross-network audio, identity recovery, payment status, jobs, private-admin denial and mobile/desktop use. |
| `cost_caps`, `owner_scope` | Reviewed monthly/annual INR limits covering infrastructure, transfer, gateway/tax, staffing and reserve. Full-V1 supervised cohort with named rollback owner, staffed hours and cohort caps no greater than the measured200-connected/25-call limits. Smaller cohort admission does not reduce required proven capacity. |

Keep the defect inventory current. Any open critical or high-severity defect blocks eligibility. Missing defect disposition artifacts also block. A passed checkbox with no recorded issue inventory cannot establish that no unreported defect exists.

## Controlled validation before launch

Production normally boots closed. To gather the final live-money and production-smoke evidence without claiming launch completion, use a **separate** validation purpose:

```bash
node scripts/launch-evidence.mjs check --purpose validation --source . --evidence ../release-evidence/evidence.json
node scripts/launch-evidence.mjs permit --purpose validation --source . --evidence ../release-evidence/evidence.json --out ../release-evidence/validation-permit.json --evidence-ref controlled_validation_01
```

Every pre-live gate and all five role approvals must already pass. Only genuinely pending `live_money`/`production_smoke` gates may be deferred; failed gates cannot be waived. Preserve already passed results and validate them normally. Top-level `validation_authorization` must reference an existing explicit business-owner approval, precede the actions, expire within24hours, specify maximum total paise, at most5purchases and5refunds, and state `production_validation_only`. These are reviewed human limits; the checker performs no transaction and cannot enforce a provider's external spending. The operators must follow the authorization exactly.

Validation also requires a matching production manifest with `stage:validation`, authenticated cohort ingress and source restrictions. Its result is `ready_for_controlled_validation`, with pending gates still visible and full-V1 eligibility false. The generated permit expires within **two hours**, or sooner when any required evidence/authorization expires. The backend independently checks the protected permit and owner-MFA open action, binds the running source/API/configuration and automatically drains an expired validation window. Renewing requires a newly checked, still-current record; do not change passed results back to pending.

## Deliberate launch and expansion

After every gate passes, review the initial supervised-cohort manifest and use the default `launch` purpose:

```bash
node scripts/launch-evidence.mjs permit --source . --evidence ../release-evidence/evidence.json --out ../release-evidence/launch-permit.json --evidence-ref supervised_cohort_01
```

Permits are newly created owner-read-only0400 files. They bind the source/API digest, production manifest digest, origin, schema9, evidence bytes/reference, purpose and exact maximum limits200connected/100waiting/25calls. A launch permit is valid for opening for at most24hours and never longer than its evidence; expiration does not imply a daily shutdown of an already authorized launch. No command here copies it to a host or opens admission. Review actual running images and effective configuration, install it through the controlled deployment procedure and deliberately perform the private owner-MFA action.

Public acquisition requires a current `rollout.cohort_observation` covering a full operating cycle, money reconciliation, urgent coverage, resource/cost review and owner approval. Only then can a newly reviewed `stage:public` manifest qualify. Re-drain, create the new manifest/permit, verify actual configuration and explicitly reopen. A cohort without full features or measured200-connected/25-call acceptance is a limited rollout, not complete V1.

## Assurance limits

The checker detects malformed/duplicate JSON, missing or changed files, stale evidence, wrong source/images, omitted coverage and unacceptable declared measurements. Hashes prove byte consistency; they do **not** authenticate a report author, prove a test actually ran or make a self-written approval legitimate. Manual reviewer names and artifacts are attestations for authorized human review, not digital signatures. Review original CI/provider/operator records through trusted channels. No boolean, manifest, schema or generated permit replaces legal/provider approval, delivered alert drills, real devices, actual media or an owner's deliberate launch decision.
