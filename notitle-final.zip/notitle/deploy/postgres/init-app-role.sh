#!/bin/sh
set -eu
# Runs once, only when PostgreSQL initializes an empty data volume.
: "${POSTGRES_DB:?POSTGRES_DB required}"
: "${POSTGRES_USER:?POSTGRES_USER required}"
: "${POSTGRES_MIGRATION_PASSWORD_FILE:?Migration password file required}"
: "${POSTGRES_APP_PASSWORD_FILE:?Runtime password file required}"
migration_password=$(cat "$POSTGRES_MIGRATION_PASSWORD_FILE")
runtime_password=$(cat "$POSTGRES_APP_PASSWORD_FILE")
[ -n "$migration_password" ] && [ -n "$runtime_password" ]
NOTITLE_BOOTSTRAP_MIGRATION_PASSWORD="$migration_password" \
NOTITLE_BOOTSTRAP_RUNTIME_PASSWORD="$runtime_password" \
psql --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" --no-psqlrc \
  --set ON_ERROR_STOP=1 <<'SQL'
\getenv migration_password NOTITLE_BOOTSTRAP_MIGRATION_PASSWORD
\getenv runtime_password NOTITLE_BOOTSTRAP_RUNTIME_PASSWORD
SET password_encryption = 'scram-sha-256';
CREATE ROLE notitle_migrate LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS PASSWORD :'migration_password';
CREATE ROLE notitle_app LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS PASSWORD :'runtime_password';
SELECT format('REVOKE ALL ON DATABASE %I FROM PUBLIC', current_database()) \gexec
SELECT format('GRANT CONNECT, CREATE ON DATABASE %I TO notitle_migrate', current_database()) \gexec
SELECT format('GRANT CONNECT ON DATABASE %I TO notitle_app', current_database()) \gexec
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT USAGE, CREATE ON SCHEMA public TO notitle_migrate;
ALTER ROLE notitle_app SET search_path = pg_catalog, notitle;
ALTER ROLE notitle_migrate SET search_path = public;
ALTER DEFAULT PRIVILEGES FOR ROLE notitle_migrate REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE notitle_migrate REVOKE USAGE ON TYPES FROM PUBLIC;
SQL
unset migration_password runtime_password
