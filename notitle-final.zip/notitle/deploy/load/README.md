# Isolated load environment

Use `docs/phase10-capacity.md` before running. These deliberately invalid examples
contain no approval, credentials, artifact digest or measured result. Do not
turn assertions on without the corresponding isolated-target evidence.

Run the browser generator on a separate temporary workstation or VM, never the
2-vCPU / 4-GiB application host or relay. Four Chromium processes create up to
400 independent contexts; measure generator saturation and use sufficient
resources (a 16–32-GiB generator is a planning starting point, not a benchmark).
The application still has exactly one coordinator. This is a temporary test
cost, not a new required production subscription.

The target must be loopback or an approved HTTPS `staging.`/`load.` hostname,
access controlled, with no real users and no live gateway money operations.
The permit binds one exact origin, five immutable image references and source
SHA-256, lasts at most 48 hours and cannot raise the budgets. Browser requests
are restricted to the exact origin; WebRTC permits only named relay hosts.
Keep working JSON and reports outside the source tree, mode0600. No screen,
trace, HAR, video, audio, SDP, ICE or ordinary chat capture is enabled.

Install the repository's pinned Playwright dependency and its Chromium browser
through the normal approved bootstrap. The harness does not install a package,
provision a host or contact any target unless deliberately invoked.

```bash
node scripts/load-soak.mjs /secure/permit.json /secure/fixtures.json /secure/observation.json /evidence/load-A.json A
node scripts/load-soak.mjs /secure/permit.json /secure/fixtures.json /secure/observation.json /evidence/load-B.json B
node scripts/load-soak.mjs /secure/permit.json /secure/fixtures.json /secure/observation.json /evidence/load-overload.json overload
```

Each invocation requires a new report filename and per-run histogram baseline.
After setup the report publishes `baseline_requested_at` and waits at most
60 seconds. Capture a new audited metrics export, then use the collector's
`baseline` and `collect` commands documented in `docs/phase10-capacity.md`.
The collector subtracts that protected baseline, rejecting process restarts or
counter regressions; process-lifetime p95 cannot satisfy the load gate.

Each invocation requires a new report filename. Reports are created before any
network action and updated after setup and completion. An in-progress report
is blocked; interruption, missing metrics, incomplete setup or shorter runs
cannot pass. Add `60` only for a one-minute calibration run that intentionally
fails the six-hour acceptance contract. Ctrl-C stops workload admission and
closes browser streams/contexts; the relay must independently enforce leases.
