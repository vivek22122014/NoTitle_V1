# Dedicated TURN relay

This is a reviewable deployment template, not a deployed or validated service.
Audio stays disabled until the Phase7 relay/browser acceptance gates pass.

Build and scan on the release workstation, with reviewed `GO_BUILD_IMAGE` and `TURN_RUNTIME_IMAGE` digest build arguments, then publish through the approved registry process. Set `NOTITLE_TURN_IMAGE` to the resolved immutable image digest. The production relay Compose file contains no `build` block.
The image pins coturn4.18.0-r0; resolve and record its verified digest before release.
The supervisor rejects any binary version other than4.18.0 and refuses startup
if its strict CLI probe fails. The official release exists, but this workspace
could not retrieve its tag-specific CLI source or run its binary. The parser is
based on the official upstream source and requires validation against this exact
image; a version tag is not proof of compatibility.

Use a dedicated Linux host. Set `TURN_HOSTNAME` to a DNS-only hostname,
`TURN_PUBLIC_IP` to its public IPv4, `TURN_RELAY_IP` to the host interface IPv4
(the same public IP if there is no NAT), `RELAY_CONTROL_ADDR` to its private IP
and port9443, and `RELAY_SECRETS_DIR` to an absolute protected directory. Files
must be readable by container UID65532; the token must have mode0400 or0600:

- `relay-control-token`:64hex characters from32cryptographically random bytes.
- `control-ca.pem`, `control-cert.pem`, `control-key.pem`: private control PKI;
  app certificates must have clientAuth usage, relay certificate serverAuth and
  the DNS/IP SAN used by `AUDIO_CONTROL_URL`.
- `turn-cert.pem`, `turn-key.pem`: publicly trusted certificate/key covering the
  TURN hostname. Renewal requires an orderly drain and container restart.

Allow public UDP/TCP3478, TCP443 and UDP49152–50175. Restrict TCP9443 to the app
private address;5766 must remain host loopback, and no metrics/web administration
listener is enabled. TURN443 carries TURN over TLS, not HTTPS. Do not route it
through the ordinary Cloudflare proxy. A rootless application user is used;
binding443 requires the boundedNET_BIND_SERVICE capability. A rootless container
engine may need an operator-reviewed host low-port setting or port forwarding.

The supervisor is PID1. Its own watchdog child kills both supervisor and coturn
if the1-second heartbeat stops for3seconds. Linux parent-death signals also kill
both children after supervisor death. The entire container must be restarted;
do not run these processes as independent services or mount a Docker socket.
Every boot rotates the TURN secret, CLI password and boot ID. All old allocations
are destroyed with the old process, and old credentials stop authenticating.
The new process accepts no call leases until a private app-instance sync completes.

The loop scans allocations once per second using coturn `ps`, maps full usernames
to call participants, then issues `cs` for canceled, expired, unknown or excess
allocations. The app renews a30-second lease at most10seconds apart; enforcement
reserves6seconds for cleanup plus2seconds for bounded clock skew. It uses the
earlier of receipt+24seconds and the transmitted deadline−8seconds (normally
22seconds with aligned clocks). Host clock offset must remain within2seconds;
the protocol rejects deadlines over32seconds ahead but cannot measure clock
offset independently. Store runtime leases using local monotonic deadlines.
Credentials
last10minutes and refresh at5minutes. Each refresh has new random usernames;
both generations count toward the same4-allocation participant limit. Revoked
credentials remain tracked through expiry; replayed allocations are canceled
on every scan. A failed/malformed/overflowing CLI read kills coturn immediately.
An allocation still present2seconds after cancellation was requested also kills
coturn; an administrative prompt is not accepted as proof of deletion.
No credentials, IP listings, SDP or media are written to operational logs.

The total allocation cap is256 (200required plus56initial headroom), with25active
call leases and1024relay ports. The bandwidth caps are64,000bytes/s per allocation
and16,384,000bytes/s aggregate; they are abuse ceilings, not a claim that a1vCPU
host sustains that bandwidth. Tune only from the required25-call load evidence.
Revocation metadata has a2048-record cap; new calls fail closed when full.

The private API is bearer-authenticated and mTLS-protected: GET`/v1/status`,
POST`/v1/sync`, POST`/v1/lease`, and aggregate GET`/v1/metrics`. Metrics contain
counts and scan health only, with no usernames, IPs or call/identity references.
It has no public route, log endpoint or arbitrary
coturn command execution. A loopback HTTP mode exists only for local development
(`RELAY_ALLOW_LOOPBACK_HTTP=true`, literal127.0.0.1 address), with the same bearer
token; it is not used in this production template. WSL2 development can use the
same container with test TLS files and a real reachable relay IP. Purely local
private-IP audio is intentionally rejected by the production peer-deny policy.

Run the authored Go tests and the live contract/transport/kill/replay matrix in
`docs/phase7-relay-runbook.md` before enabling public audio. Neither Go tests nor
actual coturn allocation cancellation have run in the authoring workspace.

Primary references: [release](https://github.com/coturn/coturn/releases/tag/4.18.0),
[official CLI implementation](https://github.com/coturn/coturn/blob/master/src/apps/relay/turn_admin_server.c),
[official configuration](https://github.com/coturn/coturn/blob/master/examples/etc/turnserver.conf).
