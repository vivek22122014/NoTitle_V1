FROM node:24.19.0-bookworm-slim
WORKDIR /src
COPY web/package.json web/package-lock.json ./
RUN npm ci --ignore-scripts --no-audit --no-fund
COPY web/ ./
RUN npm run prepare && npx playwright install --with-deps chromium firefox webkit
ENV CI=true
CMD ["sh", "-ec", "npm run check && npm run lint && npm run test:unit && npm audit --audit-level=high && npm run test:cross-browser && npm run test:design && npm run test:payments-ui"]
