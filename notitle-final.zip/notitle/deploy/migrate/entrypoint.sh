#!/bin/sh
set -eu
umask 077
[ "$#" -eq 1 ] || { echo 'Specify exactly one migration action: up, status, or version.' >&2; exit 2; }
case "$1" in
    up|status|version) ;;
    down)
        [ "${DISPOSABLE_TEST_DATABASE:-}" = 1 ] || {
            echo 'Down is restricted to explicitly disposable test databases.' >&2
            exit 2
        }
        ;;
    *) echo 'Unsupported migration action.' >&2; exit 2 ;;
esac
: "${DATABASE_URL_FILE:?DATABASE_URL_FILE is required for migrations}"
export GOOSE_DRIVER=postgres
GOOSE_DBSTRING=$(cat "$DATABASE_URL_FILE")
[ -n "$GOOSE_DBSTRING" ] || { echo 'Migration credential file is empty' >&2; exit 1; }
export GOOSE_DBSTRING
output=$(mktemp /tmp/notitle-migration.XXXXXX)
trap 'rm -f "$output"' EXIT HUP INT TERM
if goose -dir /migrations "$@" >"$output" 2>&1; then
    cat "$output"
else
    code=$?
    # Driver connection errors may contain a DSN. Never print raw failures.
    echo 'Migration failed. Check private database health, credential files, migration SQL and role grants; connection details were suppressed.' >&2
    exit "$code"
fi
