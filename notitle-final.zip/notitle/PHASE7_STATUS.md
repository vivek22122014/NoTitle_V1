# Phase 7 source delivery

Date: 2026-10-09. Baseline: NoTitle V1 final implementation blueprint V3.2 and the cumulative Phase 6 source. This package contains Phases 1–7; earlier status records describe their historical deliveries.

**Implemented in source; runtime and production acceptance remain pending.** No public deployment, relay VM purchase, certificate issuance or public audio activation was performed. The required minimum remains **200 connected participants including 25 simultaneous two-person calls**, with mobile-first design and desktop feature parity.

## Included

- Explicit Call/Accept consent for guest and registered participants; one request per interaction, deterministic simultaneous-call handling, 30-second ringing and 15-second decline cooldown. Accepted friend audio invitations use the same interaction owner and 25-call allocator.
- Scoped call state, offer ownership, generation/interaction/epoch fencing and a server-issued negotiation counter. Ordinary WebSocket frames remain 8 KiB; explicitly typed offers/answers alone can use the 64 KiB envelope allowance. SDP has a separate bounded payload.
- Audio-only Opus with relay-only ICE. The browser sanitizes address-bearing fields and the server independently validates the complete SDP and every candidate against approved relay addresses. Video, data channels, direct candidates and unsupported address extensions are rejected.
- Mobile/desktop call controls, mute, End, microphone errors, text fallback and remote-audio tap-to-play fallback. Incoming calls never capture automatically; delayed permission results are stopped after teardown. Signaling loss, Next, block/report-and-block, friend removal, logout, deletion, authentication loss, device removal and lifecycle termination close audio. Text reconnect never silently resumes the microphone.
- Random per-call endpoint TURN credentials after acceptance, ten-minute validity and five-minute authorized refresh with ICE restart. Existing microphone tracks are reused only for that accepted live call. Credentials and SDP remain transient and are not logged.
- Separate coturn deployment candidate, private mutually authenticated HTTPS control, bounded leases, recurring allocation inventory, repeated cancellation of replayed credentials, verified cleanup before releasing uncertain capacity, and a supervisor/watchdog that stops the relay when enforcement fails. A reboot rotates TURN secrets and requires application resynchronization.
- Four allocations per participant across credential generations; 256 aggregate allocation slots, a 1,024-port range and bounded revocation records. These are provisional limits requiring real measurements. Application, database and frontend architecture remain unchanged; schema readiness remains version6.
- The latest accepted call's server-derived reference and timing can be frozen into a submitted report's existing encrypted case metadata. The private audited case view labels these as reported-call metadata, without recording, transcription, ordinary call history or a claim that moderators can replay speech.
- Deployment templates, configuration validation/schema, public protocol/OpenAPI updates, security/threat/retention documentation, relay operations and failure runbook, regression tests and disabled/enabled signaling smoke paths.

## Executed evidence

| Check | Actual outcome |
| --- | --- |
| `./scripts/phase7-source-check.sh` | **112 passed, 0 failed, 0 skipped:** 109 frontend Node tests and 3 deployment/source tests. Includes 20 new audio/controller/integration tests. Output: `docs/phase7-source-check.txt`. |
| Source credential-pattern/direct-version audit | Passed; this is not a comprehensive security scan. |
| TypeScript/Svelte script syntax | 76 executable source/test script sections parsed after type stripping. No Svelte compilation, import resolution or typecheck claim. |
| Shell/JSON/YAML syntax | 21 shell scripts passed `bash -n`; 7 JSON and 10 YAML files parsed. This does not validate Docker Compose runtime behavior. |
| Public OpenAPI | 26 paths, 30 unique operation IDs; all 177 local references resolve. Private moderation/control APIs are not public routes. |
| `./scripts/verify.sh` | Stopped because Docker/Compose is unavailable. |
| `node scripts/audit.mjs --release` | Failed as intended: authentic `web/package-lock.json` and `server/go.sum` are absent. |
| Go/PostgreSQL/browser/coturn execution | Not run. Go, gofmt, Docker, psql and coturn are unavailable; frontend dependencies and browsers are not installed. |

Additional authored, unexecuted tests cover coordinator lifecycle/races and capacity, strict SDP/ICE and fuzz inputs, private job serialization, relay credentials/quotas/replay/lease expiry, ineffective cancellation, shutdown barriers, process watchdog behavior, configuration/mTLS boundaries, feature authorization and encrypted report metadata. Eight Playwright audio cases supplement existing responsive/browser coverage. Their presence is not passing runtime evidence.

## Acceptance and operating limits

On a supported Docker host, run `./scripts/bootstrap.sh prepare`, review authentic locks and formatting changes, then run `./scripts/verify.sh`. Resolve every compiler, race, database, security, Svelte and browser failure. The cumulative defaults keep audio off even in local development; the optional app overlay requires a separately prepared relay. Production additionally requires the explicit safety assertion after actual acceptance. Read `docs/phase7-acceptance.md`, `docs/phase7-protocol.md` and `docs/phase7-relay-runbook.md`.

The private controller uses the earlier of receipt plus24 seconds or the transmitted lease deadline minus8 seconds, reserving six seconds for enforcement and two seconds for allowed cross-host clock skew. Both hosts require synchronized, monitored clocks. Cancellation is confirmed by inventory; ineffective cancellation stops coturn. This implementation does **not** establish the five-second normal-revocation or thirty-second orphan target without measurements on the pinned coturn binary and actual operating systems. Exact CLI compatibility, certificate/firewall behavior, process death, watchdog stalls, credential replay and long-call refresh remain mandatory gates.

Complete physical Android/iPhone and desktop browser tests across Wi-Fi, cellular and restrictive networks. The deliberately narrow SDP grammar may require reviewed adjustments for supported browsers; never bypass full address validation to make a browser pass. Background and locked-screen continuity are not promised. No direct-media fallback is permitted.

Run both mandatory six-hour mixed workloads with real bidirectional media: 200 connected people with25 calls, plus either100 waiting/50 texting or150 texting. Include existing friendship, safety, password-hash, reconnect and backup loads, excess-load rejection and at least25% memory headroom. Configured admission limits and Node mocks are not capacity or performance benchmarks. Keep one API replica until a reviewed architecture change.

No new managed subscription was introduced. The separate relay host already belongs to the blueprint budget. At the retained planning assumptions of US$6/month, ₹97/US$ and18% tax, its allowance is approximately **₹687/month or ₹8,241/year**, excluding excess transfer; do not add it again to the full blueprint total. These are planning assumptions, not current provider quotations or an incurred bill. Measure actual relay egress; the runbook includes traffic scenarios and cost arithmetic. All earlier launch gates, including approved policies, staffed moderation, backups and later operational phases, remain in force.
