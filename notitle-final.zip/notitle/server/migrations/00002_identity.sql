-- +goose Up
-- Runtime credentials cannot run this migration or own identity records.
-- +goose StatementBegin
DO $$
BEGIN
    IF current_user <> 'notitle_migrate' THEN
        RAISE EXCEPTION 'Migrations require the dedicated notitle_migrate role';
    END IF;
END
$$;
-- +goose StatementEnd

CREATE TABLE notitle.accounts (
    id uuid PRIMARY KEY,
    username text COLLATE "C" NOT NULL UNIQUE
        CHECK (username ~ '^[a-z0-9_-]{4,24}$'),
    password_hash text NOT NULL CHECK (length(password_hash) BETWEEN 40 AND 256 AND password_hash LIKE '$argon2id$v=19$%'),
    recovery_hash bytea NOT NULL CHECK (octet_length(recovery_hash) = 32),
    generation bigint NOT NULL DEFAULT 1 CHECK (generation > 0),
    status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'deletion_pending')),
    created_at timestamptz NOT NULL,
    deletion_requested_at timestamptz,
    CHECK ((status = 'deletion_pending') = (deletion_requested_at IS NOT NULL))
);

CREATE TABLE notitle.profiles (
    account_id uuid PRIMARY KEY REFERENCES notitle.accounts(id) ON DELETE RESTRICT,
    display_name text NOT NULL CHECK (char_length(display_name) BETWEEN 2 AND 24 AND display_name !~ '[[:cntrl:]]'),
    gender text NOT NULL CHECK (gender IN ('male', 'female', 'other')),
    bio text NOT NULL DEFAULT '' CHECK (char_length(bio) <= 160 AND bio !~ '[[:cntrl:]]'),
    topic text NOT NULL DEFAULT 'general_talk' CHECK (topic IN ('general_talk', 'work_culture', 'career_growth', 'managers', 'salaries', 'hiring', 'office_politics', 'industry_experiences')),
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0),
    updated_at timestamptz NOT NULL
);

CREATE TABLE notitle.professional_profiles (
    account_id uuid PRIMARY KEY REFERENCES notitle.accounts(id) ON DELETE RESTRICT,
    profession text NOT NULL DEFAULT '' CHECK (profession IN ('', 'engineering', 'product', 'design', 'data', 'operations', 'sales', 'marketing', 'hr', 'finance', 'legal', 'education', 'healthcare', 'student', 'other')),
    industry text NOT NULL DEFAULT '' CHECK (industry IN ('', 'technology', 'finance', 'healthcare', 'education', 'manufacturing', 'retail', 'consulting', 'public_service', 'media', 'other')),
    experience text NOT NULL DEFAULT '' CHECK (experience IN ('', 'student', '0_2', '3_5', '6_10', '11_plus'))
);

CREATE TABLE notitle.professional_interests (
    account_id uuid NOT NULL REFERENCES notitle.accounts(id) ON DELETE RESTRICT,
    interest text NOT NULL CHECK (interest IN ('career_growth', 'leadership', 'work_life_balance', 'interview_prep', 'learning_skills', 'compensation', 'workplace_culture', 'entrepreneurship')),
    PRIMARY KEY (account_id, interest)
);

CREATE TABLE notitle.sessions (
    id uuid PRIMARY KEY,
    token_hash bytea NOT NULL UNIQUE CHECK (octet_length(token_hash) = 32),
    account_id uuid NOT NULL REFERENCES notitle.accounts(id) ON DELETE RESTRICT,
    account_generation bigint NOT NULL CHECK (account_generation > 0),
    created_at timestamptz NOT NULL,
    last_seen_at timestamptz NOT NULL,
    absolute_expires_at timestamptz NOT NULL,
    authenticated_at timestamptz NOT NULL,
    revoked_at timestamptz,
    CHECK (absolute_expires_at > created_at AND absolute_expires_at <= created_at + interval '30 days'),
    CHECK (last_seen_at >= created_at AND last_seen_at < absolute_expires_at),
    CHECK (authenticated_at >= created_at AND authenticated_at < absolute_expires_at)
);
CREATE INDEX sessions_account_active_idx ON notitle.sessions (account_id, created_at, id) WHERE revoked_at IS NULL;
CREATE INDEX sessions_expiry_idx ON notitle.sessions (absolute_expires_at);
CREATE INDEX sessions_idle_idx ON notitle.sessions (last_seen_at);

CREATE TABLE notitle.consent_events (
    account_id uuid NOT NULL REFERENCES notitle.accounts(id) ON DELETE RESTRICT,
    policy_type text NOT NULL CHECK (policy_type IN ('adult', 'terms', 'privacy', 'community')),
    policy_version text NOT NULL CHECK (policy_version ~ '^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$'),
    accepted boolean NOT NULL,
    recorded_at timestamptz NOT NULL,
    provenance text NOT NULL DEFAULT 'registration' CHECK (provenance = 'registration'),
    PRIMARY KEY (account_id, policy_type, policy_version, recorded_at)
);

CREATE TABLE notitle.deletion_jobs (
    id uuid PRIMARY KEY,
    account_id uuid NOT NULL UNIQUE REFERENCES notitle.accounts(id) ON DELETE RESTRICT,
    account_generation bigint NOT NULL CHECK (account_generation > 0),
    -- Replay after restoring an older DB cannot recreate a missing receipt verifier.
    receipt_hash bytea UNIQUE CHECK (receipt_hash IS NULL OR octet_length(receipt_hash) = 32),
    requested_at timestamptz NOT NULL,
    state text NOT NULL DEFAULT 'awaiting_retention_review' CHECK (state = 'awaiting_retention_review'),
    tombstone_durable boolean NOT NULL DEFAULT false,
    tombstone_durable_at timestamptz,
    CHECK (tombstone_durable = (tombstone_durable_at IS NOT NULL))
);
CREATE INDEX deletion_jobs_pending_idx ON notitle.deletion_jobs (requested_at, id) WHERE NOT tombstone_durable;
COMMENT ON TABLE notitle.deletion_jobs IS 'Access is disabled immediately. Purge awaits an approved purpose-specific retention workflow; this is not proof of completed erasure.';
COMMENT ON COLUMN notitle.deletion_jobs.receipt_hash IS 'Verifier only. NULL when independent tombstone replay reconstructed a lost job.';
COMMENT ON TABLE notitle.consent_events IS 'Append-only registration consent. No IP, email, date of birth or guest identity is collected.';

REVOKE ALL ON ALL TABLES IN SCHEMA notitle FROM PUBLIC;
GRANT SELECT, INSERT, UPDATE ON notitle.accounts, notitle.profiles, notitle.professional_profiles, notitle.deletion_jobs TO notitle_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON notitle.sessions TO notitle_app;
GRANT SELECT, INSERT ON notitle.consent_events TO notitle_app;
GRANT SELECT, INSERT, DELETE ON notitle.professional_interests TO notitle_app;
-- No DELETE grant on accounts, profiles, consent or deletion jobs. A later
-- reviewed retention worker needs its own restricted role and migration.
ALTER TABLE notitle.schema_version DROP CONSTRAINT schema_version_version_check;
UPDATE notitle.schema_version SET version = 2 WHERE version = 1;
ALTER TABLE notitle.schema_version ADD CONSTRAINT schema_version_version_check CHECK (version = 2);
COMMENT ON TABLE notitle.schema_version IS 'Readiness contract for Phase 3 identity; update deliberately with future migrations.';

-- +goose Down
-- Rollback removes Phase 3 data and is permitted by tooling only in an explicitly
-- disposable test database. Never use DOWN as a production data recovery plan.
DROP TABLE notitle.deletion_jobs;
DROP TABLE notitle.consent_events;
DROP TABLE notitle.sessions;
DROP TABLE notitle.professional_interests;
DROP TABLE notitle.professional_profiles;
DROP TABLE notitle.profiles;
DROP TABLE notitle.accounts;
ALTER TABLE notitle.schema_version DROP CONSTRAINT schema_version_version_check;
UPDATE notitle.schema_version SET version = 1 WHERE version = 2;
ALTER TABLE notitle.schema_version ADD CONSTRAINT schema_version_version_check CHECK (version = 1);
COMMENT ON TABLE notitle.schema_version IS 'Readiness contract for Phase 1; update deliberately with future migrations.';
