-- +goose Up
-- +goose StatementBegin
DO $$ BEGIN IF current_user <> 'notitle_migrate' THEN RAISE EXCEPTION 'Dedicated migration role required'; END IF; END $$;
-- +goose StatementEnd
CREATE TABLE notitle.legal_deadline_rules (
 version text NOT NULL CHECK (version ~ '^[A-Za-z0-9_.-]{1,64}$'),
 category text NOT NULL CHECK (category IN ('general','removal','intimate','court_order')),
 trigger text NOT NULL CHECK (trigger='original_receipt'),
 effective_at timestamptz NOT NULL,
 published_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 legal_source text NOT NULL CHECK (length(legal_source) BETWEEN 8 AND 1000),
 acknowledge_seconds bigint NOT NULL CHECK (acknowledge_seconds BETWEEN 60 AND 86400),
 resolve_seconds bigint NOT NULL CHECK (resolve_seconds BETWEEN 60 AND 604800),
 backup_seconds bigint NOT NULL CHECK (backup_seconds BETWEEN 60 AND 3600),
 responsible_role text NOT NULL CHECK (responsible_role='grievance_officer'),
 approved_by text,
 approved_at timestamptz,
    review_due timestamptz,
 PRIMARY KEY(version,category),
 CHECK ((approved_by IS NULL AND approved_at IS NULL) OR (length(approved_by)>0 AND approved_at IS NOT NULL AND review_due IS NOT NULL AND review_due>approved_at))
);
-- Draft engineering fixtures are deliberately not launch-date legal advice.
INSERT INTO notitle.legal_deadline_rules(version,category,trigger,effective_at,legal_source,acknowledge_seconds,resolve_seconds,backup_seconds,responsible_role)
VALUES
('draft-2026-10','general','original_receipt','2026-02-19T18:30:00Z','https://www.mib.gov.in/sites/default/files/2026-05/it-rules-2021-2.pdf ; applicability pending counsel review',86400,604800,3600,'grievance_officer'),
('draft-2026-10','removal','original_receipt','2026-02-19T18:30:00Z','https://www.mib.gov.in/sites/default/files/2026-05/it-rules-2021-2.pdf ; applicability pending counsel review',86400,129600,600,'grievance_officer'),
('draft-2026-10','intimate','original_receipt','2026-02-19T18:30:00Z','https://www.mib.gov.in/sites/default/files/2026-05/it-rules-2021-2.pdf ; applicability pending counsel review',7200,7200,600,'grievance_officer'),
('draft-2026-10','court_order','original_receipt','2026-02-19T18:30:00Z','https://www.mib.gov.in/sites/default/files/2026-05/it-rules-2021-2.pdf ; applicability pending counsel review',10800,10800,600,'grievance_officer');
CREATE TABLE notitle.grievances (
 ref text PRIMARY KEY CHECK (ref ~ '^[a-f0-9]{32}$'),
 submission_id text NOT NULL UNIQUE CHECK (submission_id ~ '^[A-Za-z0-9_-]{22,64}$'),
 secret_hash bytea NOT NULL CHECK (octet_length(secret_hash)=32),
 submission_hash bytea NOT NULL CHECK (octet_length(submission_hash)=32),
 fingerprint_key_id text NOT NULL,
 fingerprint_nonce bytea NOT NULL CHECK (octet_length(fingerprint_nonce)=12),
 fingerprint_ciphertext bytea NOT NULL CHECK (octet_length(fingerprint_ciphertext)=48),
 account_id uuid REFERENCES notitle.accounts(id) ON DELETE SET NULL,
 kind text NOT NULL CHECK (kind IN ('grievance','appeal','access','correction','deletion','receipt')),
 category text NOT NULL CHECK (category IN ('general','removal','intimate','court_order')),
 state text NOT NULL CHECK (state IN ('received','acknowledged','reviewing','resolved','appealed')),
 severity text NOT NULL CHECK (severity IN ('normal','urgent')),
 received_at timestamptz NOT NULL,
 acknowledge_due timestamptz NOT NULL,
 resolution_due timestamptz NOT NULL,
 acknowledged_at timestamptz,
 acknowledged_revision bigint NOT NULL DEFAULT 0 CHECK (acknowledged_revision>=0),
 pending_attention boolean NOT NULL DEFAULT true,
 closed_at timestamptz,
 policy_version text NOT NULL,
 assignee uuid REFERENCES notitle.admin_users(id) ON DELETE RESTRICT,
 revision bigint NOT NULL DEFAULT 1 CHECK (revision>0),
 retention_until timestamptz NOT NULL,
 retention_policy_version text NOT NULL CHECK (retention_policy_version ~ '^[A-Za-z0-9_.-]{1,64}$'),
 FOREIGN KEY(policy_version,category) REFERENCES notitle.legal_deadline_rules(version,category),
 CHECK (acknowledge_due>=received_at AND resolution_due>=received_at),
 CHECK ((state='resolved')=(closed_at IS NOT NULL))
);
CREATE INDEX grievances_worklist_idx ON notitle.grievances(resolution_due,received_at,ref) WHERE closed_at IS NULL;
CREATE INDEX grievances_account_idx ON notitle.grievances(account_id,received_at DESC) WHERE account_id IS NOT NULL;
CREATE INDEX grievances_retention_idx ON notitle.grievances(retention_until);
CREATE TABLE notitle.grievance_messages (
 ref text PRIMARY KEY CHECK (ref ~ '^[a-f0-9]{32}$'),
 case_ref text NOT NULL REFERENCES notitle.grievances(ref) ON DELETE RESTRICT,
 submission_id text NOT NULL CHECK (submission_id ~ '^[A-Za-z0-9_-]{22,64}$'),
 submission_hash bytea NOT NULL CHECK (octet_length(submission_hash)=32),
 author text NOT NULL CHECK (author IN ('complainant','operator','note')),
 is_initial boolean NOT NULL DEFAULT false,
 appeal boolean NOT NULL DEFAULT false,
 created_at timestamptz NOT NULL,
 key_id text,
 nonce bytea,
 ciphertext bytea,
 retention_until timestamptz NOT NULL,
 retention_policy_version text NOT NULL CHECK (retention_policy_version ~ '^[A-Za-z0-9_.-]{1,64}$'),
 purged_at timestamptz,
 UNIQUE(case_ref,submission_id),
 CHECK ((purged_at IS NULL AND key_id IS NOT NULL AND octet_length(nonce)=12 AND octet_length(ciphertext) BETWEEN 16 AND 32768) OR (purged_at IS NOT NULL AND key_id IS NULL AND nonce IS NULL AND ciphertext IS NULL))
);
CREATE INDEX grievance_messages_case_idx ON notitle.grievance_messages(case_ref,created_at,ref);
CREATE INDEX grievance_messages_retention_idx ON notitle.grievance_messages(retention_until) WHERE purged_at IS NULL;
CREATE TABLE notitle.grievance_actions (
 id uuid PRIMARY KEY,
 case_ref text NOT NULL REFERENCES notitle.grievances(ref) ON DELETE RESTRICT,
 actor_id uuid NOT NULL REFERENCES notitle.admin_users(id) ON DELETE RESTRICT,
 submission_id text NOT NULL CHECK (submission_id ~ '^[A-Za-z0-9_-]{22,64}$'),
 expected_revision bigint NOT NULL CHECK (expected_revision>0),
 action text NOT NULL CHECK (action IN ('ack','note','reply','resolve','reopen','reclassify','assign')),
 reason text NOT NULL CHECK (reason ~ '^[a-z][a-z0-9_]{2,63}$'),
 input_hash bytea NOT NULL CHECK (octet_length(input_hash)=32),
 created_at timestamptz NOT NULL,
 UNIQUE(actor_id,submission_id)
);
CREATE INDEX grievance_actions_case_idx ON notitle.grievance_actions(case_ref,created_at,id);
CREATE TABLE notitle.operations_outbox (
 id text PRIMARY KEY CHECK (id ~ '^[a-f0-9]{32}$'),
 case_ref text NOT NULL REFERENCES notitle.grievances(ref) ON DELETE RESTRICT,
 event_revision bigint NOT NULL CHECK (event_revision>0),
 kind text NOT NULL CHECK (kind IN ('new_case','reply','appeal','reclassification')),
 severity text NOT NULL CHECK (severity IN ('normal','urgent')),
 audience text NOT NULL CHECK (audience IN ('primary','backup')),
 state text NOT NULL DEFAULT 'pending' CHECK (state IN ('pending','leased','delivered','cancelled','dead')),
 attempts integer NOT NULL DEFAULT 0 CHECK (attempts BETWEEN 0 AND 8),
 available_at timestamptz NOT NULL,
 created_at timestamptz NOT NULL,
 lease_token text,
 lease_until timestamptz,
 delivered_at timestamptz,
 UNIQUE(case_ref,event_revision,audience),
 CHECK ((state='leased')=(lease_token IS NOT NULL AND lease_until IS NOT NULL))
);
CREATE INDEX operations_outbox_due_idx ON notitle.operations_outbox(available_at,id) WHERE state IN ('pending','leased');
CREATE TABLE notitle.rule_notices (
 version text PRIMARY KEY CHECK (version ~ '^[A-Za-z0-9_.-]{1,64}$'),
 text text NOT NULL CHECK (length(text) BETWEEN 10 AND 4000),
 effective_at timestamptz NOT NULL,
 published_at timestamptz NOT NULL DEFAULT CURRENT_TIMESTAMP,
 approved_by text,
 approved_at timestamptz,
    review_due timestamptz,
 repeat_months integer NOT NULL DEFAULT 3 CHECK (repeat_months BETWEEN 1 AND 3),
 CHECK ((approved_by IS NULL AND approved_at IS NULL) OR (length(approved_by)>0 AND approved_at IS NOT NULL AND review_due IS NOT NULL AND review_due>approved_at))
);
INSERT INTO notitle.rule_notices(version,text,effective_at) VALUES ('draft-2026-10','Follow the Community Guidelines. Harassment, threats, unlawful content and misuse may lead to content restriction or loss of access. You may report concerns or appeal through Support.','2026-10-09T00:00:00Z');
CREATE TABLE notitle.rule_notice_deliveries (
 account_id uuid NOT NULL REFERENCES notitle.accounts(id) ON DELETE CASCADE,
 version text NOT NULL REFERENCES notitle.rule_notices(version) ON DELETE RESTRICT,
 delivered_at timestamptz NOT NULL,
 acknowledged_at timestamptz,
 next_due timestamptz NOT NULL,
 PRIMARY KEY(account_id,version,delivered_at),
 CHECK (next_due>delivered_at AND (acknowledged_at IS NULL OR acknowledged_at>=delivered_at))
);
CREATE INDEX rule_notice_deliveries_account_idx ON notitle.rule_notice_deliveries(account_id,version,delivered_at DESC);
-- Immutable receipt and deadline tightening prevent reassignment/retry timer resets.
-- +goose StatementBegin
CREATE FUNCTION notitle.protect_grievance_receipt() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
 IF NEW.ref<>OLD.ref OR NEW.submission_id<>OLD.submission_id OR NEW.secret_hash<>OLD.secret_hash OR NEW.submission_hash<>OLD.submission_hash OR NEW.fingerprint_key_id<>OLD.fingerprint_key_id OR NEW.fingerprint_nonce<>OLD.fingerprint_nonce OR NEW.fingerprint_ciphertext<>OLD.fingerprint_ciphertext OR NEW.received_at<>OLD.received_at OR NEW.kind<>OLD.kind OR NEW.acknowledge_due>OLD.acknowledge_due OR NEW.resolution_due>OLD.resolution_due THEN RAISE EXCEPTION 'Immutable complaint receipt or deadline'; END IF;
 RETURN NEW;
END $$;
-- +goose StatementEnd
REVOKE ALL ON FUNCTION notitle.protect_grievance_receipt() FROM PUBLIC,notitle_app;
CREATE TRIGGER protect_grievance_receipt BEFORE UPDATE ON notitle.grievances FOR EACH ROW EXECUTE FUNCTION notitle.protect_grievance_receipt();
REVOKE ALL ON notitle.legal_deadline_rules,notitle.grievances,notitle.grievance_messages,notitle.grievance_actions,notitle.operations_outbox,notitle.rule_notices,notitle.rule_notice_deliveries FROM PUBLIC;
GRANT SELECT ON notitle.legal_deadline_rules,notitle.rule_notices TO notitle_app;
GRANT SELECT,INSERT,UPDATE ON notitle.grievances,notitle.grievance_messages,notitle.operations_outbox,notitle.rule_notice_deliveries TO notitle_app;
GRANT SELECT,INSERT ON notitle.grievance_actions TO notitle_app;
COMMENT ON TABLE notitle.grievances IS 'Explicit support submissions only. A bearer authorizes this case, never the claimed account or financial subject.';
COMMENT ON TABLE notitle.grievance_messages IS 'Purpose-bound encrypted user submissions, replies and operator notes. No ordinary transcripts or uploads.';
CREATE TABLE notitle.operational_alerts (
 event_ref text PRIMARY KEY CHECK(event_ref ~ '^[A-Za-z0-9_-]{16,128}$'),
 code text NOT NULL CHECK(length(code) BETWEEN 1 AND 64),severity text NOT NULL CHECK(severity IN ('warning','urgent')),
 state text NOT NULL CHECK(state IN ('open','acknowledged','resolved')),opened_at timestamptz NOT NULL,touched_at timestamptz NOT NULL,
 acknowledged_at timestamptz,acknowledged_by uuid REFERENCES notitle.admin_users(id) ON DELETE RESTRICT,resolved_at timestamptz,
 generation bigint NOT NULL DEFAULT 1 CHECK(generation>0)
);
CREATE UNIQUE INDEX operational_alerts_active_code_idx ON notitle.operational_alerts(code) WHERE state<>'resolved';
CREATE TABLE notitle.operational_alert_deliveries (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,event_ref text NOT NULL REFERENCES notitle.operational_alerts(event_ref) ON DELETE RESTRICT,
 channel text NOT NULL CHECK(channel IN ('primary','backup')),state text NOT NULL CHECK(state IN ('pending','leased','delivered','dead','cancelled')),
 attempts integer NOT NULL DEFAULT 0 CHECK(attempts BETWEEN 0 AND 8),available_at timestamptz NOT NULL,lease_until timestamptz,lease_token text,
 last_result text NOT NULL DEFAULT '' CHECK(last_result IN ('','delivered','receiver_unavailable','attempts_exhausted')),delivered_at timestamptz,
 UNIQUE(event_ref,channel),
 CHECK ((state='leased')=(lease_token IS NOT NULL AND lease_until IS NOT NULL))
);
CREATE INDEX operational_alert_delivery_due_idx ON notitle.operational_alert_deliveries(available_at) WHERE state IN ('pending','leased');
CREATE TABLE notitle.operational_metric_hours (
 bucket timestamptz PRIMARY KEY,samples bigint NOT NULL CHECK(samples>0),connected_max integer NOT NULL,waiting_max integer NOT NULL,calls_max integer NOT NULL,
 heap_max bigint NOT NULL,probe_max_ms bigint NOT NULL,cpu_sum double precision NOT NULL,memory_max double precision NOT NULL,disk_max double precision NOT NULL,updated_at timestamptz NOT NULL
);
REVOKE ALL ON notitle.operational_alerts,notitle.operational_alert_deliveries,notitle.operational_metric_hours FROM PUBLIC;
GRANT SELECT,INSERT,UPDATE ON notitle.operational_alerts,notitle.operational_alert_deliveries,notitle.operational_metric_hours TO notitle_app;
GRANT DELETE ON notitle.operational_metric_hours TO notitle_app;
GRANT USAGE,SELECT ON SEQUENCE notitle.operational_alert_deliveries_id_seq TO notitle_app;
COMMENT ON TABLE notitle.operational_metric_hours IS 'Fixed global hourly resource aggregates only; 13-month upper bound, no identities/demographic dimensions/content.';

-- Caller cannot invent an expiry cutoff; reviewed schema9 policy is checked
-- again by a narrow definer. Tables in schema9 are resolved at execution time.
-- +goose StatementBegin
CREATE FUNCTION notitle.operations_expire_metadata(policy_ text,now_ timestamptz) RETURNS bigint LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE p_ jsonb;rule_ jsonb;days_ integer;ids_ text[];rows_ bigint:=0;metric_rows_ bigint:=0;
BEGIN
 IF abs(extract(epoch FROM clock_timestamp()-now_))>5 THEN RAISE EXCEPTION 'Invalid execution clock'; END IF;
 SELECT document INTO p_ FROM notitle.retention_policies WHERE version=policy_ AND approved;
 IF p_ IS NULL OR (p_->>'review_due_at')::timestamptz<=now_ THEN RETURN 0; END IF;
 SELECT r INTO rule_ FROM jsonb_array_elements(p_->'rules')r WHERE r->>'purpose'='cases' AND r->>'trigger'='closure' AND (r->>'effective_at')::timestamptz<=now_ AND (r->>'reviewed_until')::timestamptz>now_;
 IF rule_ IS NOT NULL THEN
  days_:=(rule_->>'maximum_days')::integer;
  IF days_ BETWEEN 1 AND 36525 AND days_>=(rule_->>'minimum_days')::integer THEN
   SELECT array_agg(event_ref) INTO ids_ FROM (SELECT event_ref FROM notitle.operational_alerts WHERE state='resolved' AND resolved_at<=now_-days_*interval '1 day' ORDER BY resolved_at LIMIT 50 FOR UPDATE SKIP LOCKED)due;
   DELETE FROM notitle.operational_alert_deliveries WHERE event_ref=ANY(ids_);
   DELETE FROM notitle.operational_alerts WHERE event_ref=ANY(ids_);GET DIAGNOSTICS rows_=ROW_COUNT;
  END IF;
 END IF;
 SELECT r INTO rule_ FROM jsonb_array_elements(p_->'rules')r WHERE r->>'purpose'='metrics' AND r->>'trigger'='collection' AND (r->>'effective_at')::timestamptz<=now_ AND (r->>'reviewed_until')::timestamptz>now_;
 IF rule_ IS NOT NULL THEN
  days_:=(rule_->>'maximum_days')::integer;
  IF days_ BETWEEN 1 AND 36525 AND days_>=(rule_->>'minimum_days')::integer THEN
   DELETE FROM notitle.operational_metric_hours WHERE bucket IN (SELECT bucket FROM notitle.operational_metric_hours WHERE bucket+interval '1 hour'<=now_-days_*interval '1 day' ORDER BY bucket LIMIT 24);GET DIAGNOSTICS metric_rows_=ROW_COUNT;
  END IF;
 END IF;
 IF rows_+metric_rows_>0 THEN INSERT INTO notitle.privacy_purge_audit(kind,subject_ref,policy_version,affected_rows,executed_at)VALUES('operations_metadata','aggregate',policy_,rows_+metric_rows_,now_); END IF;
 RETURN rows_+metric_rows_;
END $$;
-- +goose StatementEnd
REVOKE ALL ON FUNCTION notitle.operations_expire_metadata(text,timestamptz) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION notitle.operations_expire_metadata(text,timestamptz) TO notitle_app;
REVOKE DELETE ON notitle.operational_metric_hours FROM notitle_app;
COMMENT ON TABLE notitle.operational_metric_hours IS 'Fixed global hourly aggregates; expiry uses reviewed metrics rule, proposed13months. No identities/demographic dimensions/content.';

ALTER TABLE notitle.schema_version DROP CONSTRAINT schema_version_version_check;
UPDATE notitle.schema_version SET version=8 WHERE version=7;
ALTER TABLE notitle.schema_version ADD CONSTRAINT schema_version_version_check CHECK(version=8);

-- +goose Down
DROP FUNCTION notitle.operations_expire_metadata(text,timestamptz);
DROP TABLE notitle.operational_metric_hours,notitle.operational_alert_deliveries,notitle.operational_alerts;
DROP TABLE notitle.rule_notice_deliveries,notitle.rule_notices,notitle.operations_outbox,notitle.grievance_actions,notitle.grievance_messages;
DROP TRIGGER protect_grievance_receipt ON notitle.grievances;
DROP FUNCTION notitle.protect_grievance_receipt();
DROP TABLE notitle.grievances,notitle.legal_deadline_rules;
ALTER TABLE notitle.schema_version DROP CONSTRAINT schema_version_version_check;
UPDATE notitle.schema_version SET version=7 WHERE version=8;
ALTER TABLE notitle.schema_version ADD CONSTRAINT schema_version_version_check CHECK(version=7);
