-- +goose Up
-- +goose StatementBegin
DO $$ BEGIN
 IF current_user <> 'notitle_migrate' THEN RAISE EXCEPTION 'Migrations require the dedicated notitle_migrate role'; END IF;
END $$;
-- +goose StatementEnd

-- A bounded per-account fence, not a history of removed or pending requests.
-- Removal/block increments the fence even when acceptance has not yet committed.
ALTER TABLE notitle.accounts ADD COLUMN friend_revision bigint NOT NULL DEFAULT 1 CHECK(friend_revision > 0);
CREATE TABLE notitle.friendships (
 relation_ref text COLLATE "C" PRIMARY KEY CHECK(relation_ref ~ '^[A-Za-z0-9_-]{16,128}$'),
 account_a uuid NOT NULL REFERENCES notitle.accounts(id) ON DELETE CASCADE,
 account_b uuid NOT NULL REFERENCES notitle.accounts(id) ON DELETE CASCADE,
 consent_a_at timestamptz NOT NULL,
 consent_b_at timestamptz NOT NULL,
 created_at timestamptz NOT NULL,
 UNIQUE(account_a,account_b), CHECK(account_a < account_b),
 CHECK(consent_a_at <= created_at AND consent_b_at <= created_at)
);
CREATE INDEX friendships_a_time_idx ON notitle.friendships(account_a,created_at DESC,relation_ref);
CREATE INDEX friendships_b_time_idx ON notitle.friendships(account_b,created_at DESC,relation_ref);
COMMENT ON TABLE notitle.friendships IS 'Mutually accepted account pairs only. No guests, pending requests, invitations, messages or presence history.';

-- Database-side deletion covers every durable block writer: ordinary block,
-- report-and-block, promotion, and the batched registration safety handoff.
-- +goose StatementBegin
CREATE FUNCTION notitle.friendships_block_barrier() RETURNS trigger
LANGUAGE plpgsql SET search_path = pg_catalog AS $$
BEGIN
 -- Updating an already active block's opaque handle is an idempotent retry,
 -- not a new communication barrier. Do not revoke unrelated pending consent.
 IF TG_OP='INSERT' OR OLD.blocker_id IS DISTINCT FROM NEW.blocker_id OR OLD.blocked_id IS DISTINCT FROM NEW.blocked_id THEN
  UPDATE notitle.accounts SET friend_revision=friend_revision+1 WHERE id IN (NEW.blocker_id,NEW.blocked_id);
 END IF;
 DELETE FROM notitle.friendships WHERE account_a=LEAST(NEW.blocker_id,NEW.blocked_id) AND account_b=GREATEST(NEW.blocker_id,NEW.blocked_id);
 RETURN NEW;
END $$;
-- +goose StatementEnd
CREATE TRIGGER friendships_block_barrier AFTER INSERT OR UPDATE ON notitle.blocks
 FOR EACH ROW EXECUTE FUNCTION notitle.friendships_block_barrier();

-- Access-disabled deletion (including journal replay) removes relationships
-- in its original transaction, before any later retention/erasure worker.
-- +goose StatementBegin
CREATE FUNCTION notitle.friendships_deletion_barrier() RETURNS trigger
LANGUAGE plpgsql SET search_path = pg_catalog AS $$
BEGIN
 UPDATE notitle.accounts SET friend_revision=friend_revision+1 WHERE id=NEW.id;
 DELETE FROM notitle.friendships WHERE account_a=NEW.id OR account_b=NEW.id;
 RETURN NEW;
END $$;
-- +goose StatementEnd
CREATE TRIGGER friendships_deletion_barrier AFTER UPDATE OF status ON notitle.accounts
 FOR EACH ROW WHEN (NEW.status='deletion_pending' AND OLD.status IS DISTINCT FROM NEW.status)
 EXECUTE FUNCTION notitle.friendships_deletion_barrier();
REVOKE ALL ON FUNCTION notitle.friendships_block_barrier(),notitle.friendships_deletion_barrier() FROM PUBLIC;
REVOKE ALL ON notitle.friendships FROM PUBLIC;
GRANT SELECT,INSERT,DELETE ON notitle.friendships TO notitle_app;

ALTER TABLE notitle.schema_version DROP CONSTRAINT schema_version_version_check;
UPDATE notitle.schema_version SET version=6 WHERE version=5;
ALTER TABLE notitle.schema_version ADD CONSTRAINT schema_version_version_check CHECK(version=6);
COMMENT ON TABLE notitle.schema_version IS 'Readiness contract for Phase 6 mutual account friendships.';

-- +goose Down
-- Disposable tests only. Never erase retained real relationships with DOWN.
DROP TRIGGER friendships_deletion_barrier ON notitle.accounts;
DROP TRIGGER friendships_block_barrier ON notitle.blocks;
DROP FUNCTION notitle.friendships_deletion_barrier();
DROP FUNCTION notitle.friendships_block_barrier();
DROP TABLE notitle.friendships;
ALTER TABLE notitle.accounts DROP COLUMN friend_revision;
ALTER TABLE notitle.schema_version DROP CONSTRAINT schema_version_version_check;
UPDATE notitle.schema_version SET version=5 WHERE version=6;
ALTER TABLE notitle.schema_version ADD CONSTRAINT schema_version_version_check CHECK(version=5);
COMMENT ON TABLE notitle.schema_version IS 'Readiness contract for Phase 5 private moderation.';
