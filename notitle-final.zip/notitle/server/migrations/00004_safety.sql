-- +goose Up
-- +goose StatementBegin
DO $$ BEGIN
 IF current_user <> 'notitle_migrate' THEN RAISE EXCEPTION 'Migrations require the dedicated notitle_migrate role'; END IF;
END $$;
-- +goose StatementEnd

CREATE TABLE notitle.account_safety_state (
 account_id uuid PRIMARY KEY REFERENCES notitle.accounts(id) ON DELETE RESTRICT,
 version bigint NOT NULL DEFAULT 1 CHECK(version > 0),
 restricted_until timestamptz,
 restriction_updated_at timestamptz,
 restriction_reason text NOT NULL DEFAULT '' CHECK(char_length(restriction_reason) <= 500),
 updated_at timestamptz NOT NULL
);
COMMENT ON TABLE notitle.account_safety_state IS 'Interaction restrictions leave authentication, settings, reporting and grievance access available. Never derive restrictions from report counts.';

CREATE TABLE notitle.pending_safety_handoffs (
 account_id uuid PRIMARY KEY REFERENCES notitle.accounts(id) ON DELETE RESTRICT,
 created_at timestamptz NOT NULL
);
COMMENT ON TABLE notitle.pending_safety_handoffs IS 'Fail-closed registration fence. Clear only with an authoritative in-session safety snapshot; orphaned rows after restart require private operator review, never automatic expiry.';

CREATE TABLE notitle.blocks (
 id uuid PRIMARY KEY,
 block_ref text COLLATE "C" NOT NULL UNIQUE CHECK(block_ref ~ '^[A-Za-z0-9_-]{22,64}$'),
 blocker_id uuid NOT NULL REFERENCES notitle.accounts(id) ON DELETE RESTRICT,
 blocked_id uuid NOT NULL REFERENCES notitle.accounts(id) ON DELETE RESTRICT,
 created_at timestamptz NOT NULL,
 UNIQUE(blocker_id, blocked_id), CHECK(blocker_id <> blocked_id)
);
CREATE INDEX blocks_inbound_idx ON notitle.blocks(blocked_id, blocker_id);
CREATE INDEX blocks_owner_time_idx ON notitle.blocks(blocker_id, created_at DESC, id);

CREATE TABLE notitle.reports (
 id uuid PRIMARY KEY,
 case_ref text COLLATE "C" NOT NULL UNIQUE CHECK(case_ref ~ '^[A-Za-z0-9_-]{22,64}$'),
 submission_hash bytea NOT NULL UNIQUE CHECK(octet_length(submission_hash)=32),
 request_hash bytea NOT NULL CHECK(octet_length(request_hash)=32),
 category text NOT NULL CHECK(category IN ('harassment','threats','doxxing','confidentiality','targeted_false_accusations','scams','impersonation','suspected_underage_access','sexual_misconduct','spam','other')),
 severity text NOT NULL CHECK(severity IN ('normal','urgent')),
 state text NOT NULL DEFAULT 'open' CHECK(state IN ('open','resolved')),
 version bigint NOT NULL DEFAULT 1 CHECK(version>0),
 submitted_at timestamptz NOT NULL,
 due_at timestamptz NOT NULL,
 retention_until timestamptz NOT NULL,
 retention_policy_version text NOT NULL CHECK(retention_policy_version ~ '^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$'),
 blocked boolean NOT NULL,
 CHECK(due_at >= submitted_at), CHECK(retention_until > submitted_at)
);
CREATE INDEX reports_triage_idx ON notitle.reports((state='open') DESC, (severity='urgent') DESC, due_at, id);
CREATE INDEX reports_retention_idx ON notitle.reports(retention_until,id);

CREATE TABLE notitle.case_subject_refs (
 case_id uuid NOT NULL REFERENCES notitle.reports(id) ON DELETE RESTRICT,
 subject_ref text COLLATE "C" NOT NULL CHECK(subject_ref ~ '^[A-Za-z0-9_-]{22,64}$'),
 role text NOT NULL CHECK(role IN ('reporter','subject')),
 account_id uuid REFERENCES notitle.accounts(id) ON DELETE RESTRICT,
 guest_case_tag bytea,
 PRIMARY KEY(case_id,subject_ref), UNIQUE(case_id,role),
 CHECK((account_id IS NOT NULL AND guest_case_tag IS NULL) OR (account_id IS NULL AND octet_length(guest_case_tag)=32))
);
CREATE INDEX case_subject_account_idx ON notitle.case_subject_refs(account_id,case_id) WHERE account_id IS NOT NULL;
COMMENT ON COLUMN notitle.case_subject_refs.guest_case_tag IS 'Random case-scoped tag; no guest ID, persistent guest profile, network identifier or cross-case correlation key.';

CREATE TABLE notitle.report_evidence (
 id uuid PRIMARY KEY,
 case_id uuid NOT NULL REFERENCES notitle.reports(id) ON DELETE RESTRICT,
 server_sequence bigint NOT NULL CHECK(server_sequence>=0),
 speaker_ref text COLLATE "C" NOT NULL,
 kind text NOT NULL CHECK(kind IN ('server_text','user_statement','interaction_metadata')),
 collection_reason text NOT NULL CHECK(collection_reason='user_submitted_report'),
 collected_at timestamptz NOT NULL,
 retention_until timestamptz NOT NULL,
 key_id text NOT NULL CHECK(key_id ~ '^[A-Za-z0-9_-]{1,48}$'),
 nonce bytea NOT NULL CHECK(octet_length(nonce)=12),
 ciphertext bytea NOT NULL CHECK(octet_length(ciphertext) BETWEEN 16 AND 131088),
 aad bytea NOT NULL CHECK(octet_length(aad) BETWEEN 1 AND 4096),
 FOREIGN KEY(case_id,speaker_ref) REFERENCES notitle.case_subject_refs(case_id,subject_ref) ON DELETE RESTRICT,
 UNIQUE(case_id,kind,server_sequence),
 CHECK(retention_until > collected_at), CHECK((kind='server_text')=(server_sequence>0))
);
CREATE INDEX report_evidence_case_idx ON notitle.report_evidence(case_id,server_sequence,id);
CREATE TABLE notitle.moderation_actions (
 id uuid PRIMARY KEY,
 case_id uuid NOT NULL REFERENCES notitle.reports(id) ON DELETE RESTRICT,
 admin_id uuid NOT NULL,
 action text NOT NULL CHECK(action IN ('suspend','unsuspend','resolve','note','reopen','hold','release_hold')),
 reason text NOT NULL CHECK(char_length(reason) BETWEEN 1 AND 2000),
 created_at timestamptz NOT NULL,
 until_at timestamptz,
 case_version bigint NOT NULL CHECK(case_version>1)
);
CREATE INDEX moderation_actions_case_idx ON notitle.moderation_actions(case_id,created_at,id);
CREATE TABLE notitle.legal_holds (
 id uuid PRIMARY KEY,
 case_id uuid NOT NULL REFERENCES notitle.reports(id) ON DELETE RESTRICT,
 action_id uuid NOT NULL UNIQUE REFERENCES notitle.moderation_actions(id) ON DELETE RESTRICT,
 created_at timestamptz NOT NULL,
 released_by_action uuid UNIQUE REFERENCES notitle.moderation_actions(id) ON DELETE RESTRICT
);
CREATE INDEX legal_holds_active_idx ON notitle.legal_holds(case_id) WHERE released_by_action IS NULL;

REVOKE ALL ON notitle.account_safety_state,notitle.blocks,notitle.reports,notitle.case_subject_refs,notitle.report_evidence,notitle.moderation_actions,notitle.legal_holds FROM PUBLIC;
REVOKE ALL ON notitle.pending_safety_handoffs FROM PUBLIC;
GRANT SELECT,INSERT,DELETE ON notitle.pending_safety_handoffs TO notitle_app;
GRANT SELECT,INSERT,UPDATE ON notitle.account_safety_state,notitle.reports,notitle.legal_holds TO notitle_app;
GRANT SELECT,INSERT,UPDATE,DELETE ON notitle.blocks TO notitle_app;
GRANT SELECT,INSERT ON notitle.case_subject_refs,notitle.report_evidence,notitle.moderation_actions TO notitle_app;
-- Evidence/action history cannot be updated or deleted by the runtime. Purge
-- needs a separately reviewed retention worker honoring legal holds and backup
-- retention; no unapproved automatic erasure is introduced by this foundation.
ALTER TABLE notitle.schema_version DROP CONSTRAINT schema_version_version_check;
UPDATE notitle.schema_version SET version=4 WHERE version=3;
ALTER TABLE notitle.schema_version ADD CONSTRAINT schema_version_version_check CHECK(version=4);
COMMENT ON TABLE notitle.schema_version IS 'Readiness contract for Phase 5 safety storage.';

-- +goose Down
-- Disposable migration tests only; never erase real reports with rollback.
DROP TABLE notitle.legal_holds;
DROP TABLE notitle.moderation_actions;
DROP TABLE notitle.report_evidence;
DROP TABLE notitle.case_subject_refs;
DROP TABLE notitle.reports;
DROP TABLE notitle.blocks;
DROP TABLE notitle.account_safety_state;
DROP TABLE notitle.pending_safety_handoffs;
ALTER TABLE notitle.schema_version DROP CONSTRAINT schema_version_version_check;
UPDATE notitle.schema_version SET version=3 WHERE version=4;
ALTER TABLE notitle.schema_version ADD CONSTRAINT schema_version_version_check CHECK(version=3);
COMMENT ON TABLE notitle.schema_version IS 'Readiness contract for Phase 4 realtime preferences.';
