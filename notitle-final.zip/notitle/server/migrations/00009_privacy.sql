-- +goose Up
-- Purpose-specific erasure is disabled until an approved manifest is installed.
-- +goose StatementBegin
DO $$ BEGIN IF current_user<>'notitle_migrate' THEN RAISE EXCEPTION 'Dedicated migration role required'; END IF; END $$;
-- +goose StatementEnd
CREATE TABLE notitle.retention_policies (
 version text PRIMARY KEY CHECK(length(version) BETWEEN 1 AND 64),digest text NOT NULL CHECK(digest ~ '^[a-f0-9]{64}$'),
 document jsonb NOT NULL,approved boolean NOT NULL,installed_at timestamptz NOT NULL
);
CREATE TABLE notitle.privacy_hold_events (
 event_id uuid PRIMARY KEY,hold_id uuid NOT NULL,revision bigint NOT NULL CHECK(revision>0),snapshot jsonb NOT NULL,recorded_at timestamptz NOT NULL,UNIQUE(hold_id,revision)
);
CREATE TABLE notitle.privacy_holds (
 id uuid PRIMARY KEY,event_id uuid NOT NULL UNIQUE REFERENCES notitle.privacy_hold_events(event_id),revision bigint NOT NULL CHECK(revision>0),
 scope_kind text NOT NULL CHECK(scope_kind IN ('account','report','operations_case','financial')),scope_ref text NOT NULL,
 reason text NOT NULL CHECK(char_length(reason) BETWEEN 5 AND 1000),approver_id uuid NOT NULL,
 review_at timestamptz NOT NULL,recorded_at timestamptz NOT NULL,released_at timestamptz,release_reason text NOT NULL DEFAULT '',
 CHECK(review_at>=recorded_at),CHECK((released_at IS NULL AND release_reason='')OR(released_at>=recorded_at AND char_length(release_reason) BETWEEN 5 AND 1000))
);
CREATE INDEX privacy_holds_active ON notitle.privacy_holds(scope_kind,scope_ref,review_at) WHERE released_at IS NULL;
CREATE TABLE notitle.restricted_registration (
 account_id uuid PRIMARY KEY REFERENCES notitle.accounts(id),registration jsonb NOT NULL,retained_at timestamptz NOT NULL,
 retention_until timestamptz NOT NULL,policy_version text NOT NULL REFERENCES notitle.retention_policies(version),CHECK(retention_until>=retained_at)
);
CREATE TABLE notitle.privacy_jobs (
 id uuid PRIMARY KEY,kind text NOT NULL CHECK(kind IN ('registration','report','operations_case','financial')),subject_ref text NOT NULL,
 state text NOT NULL DEFAULT 'ready' CHECK(state IN ('ready','leased','done','dead','held')),policy_version text NOT NULL REFERENCES notitle.retention_policies(version),
 not_before timestamptz NOT NULL,attempts integer NOT NULL DEFAULT 0 CHECK(attempts BETWEEN 0 AND 8),last_error text NOT NULL DEFAULT '',
 reason text NOT NULL CHECK(char_length(reason) BETWEEN 5 AND 1000),approved_by uuid,created_at timestamptz NOT NULL,
 lease_owner uuid,lease_until timestamptz,completed_at timestamptz,UNIQUE(kind,subject_ref,policy_version),
 CHECK((state='leased')=(lease_owner IS NOT NULL AND lease_until IS NOT NULL))
);
CREATE INDEX privacy_jobs_due ON notitle.privacy_jobs(not_before,id) WHERE state IN ('ready','leased','held');
CREATE TABLE notitle.privacy_purge_audit (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,job_id uuid,kind text NOT NULL,subject_ref text NOT NULL,
 policy_version text NOT NULL,affected_rows bigint NOT NULL CHECK(affected_rows>=0),executed_at timestamptz NOT NULL
);
ALTER TABLE notitle.deletion_jobs DROP CONSTRAINT deletion_jobs_state_check;
ALTER TABLE notitle.deletion_jobs ADD CONSTRAINT deletion_jobs_state_check CHECK(state IN ('awaiting_retention_review','ordinary_erased_restricted_retained'));
ALTER TABLE notitle.deletion_jobs ADD COLUMN scrubbed_at timestamptz;
ALTER TABLE notitle.reports ADD COLUMN evidence_purged_at timestamptz;
COMMENT ON TABLE notitle.restricted_registration IS 'Reviewed minimum registration preservation after cancellation. No profile biography, professional data, credentials, or conversation content.';
COMMENT ON TABLE notitle.privacy_hold_events IS 'Append-only full legal-hold snapshots from independently durable journal; no administrator FK so restored holds can predate restored operator records.';
REVOKE ALL ON notitle.retention_policies,notitle.privacy_hold_events,notitle.privacy_holds,notitle.restricted_registration,notitle.privacy_jobs,notitle.privacy_purge_audit FROM PUBLIC;
GRANT SELECT ON notitle.retention_policies TO notitle_app;
GRANT SELECT,INSERT ON notitle.privacy_hold_events TO notitle_app;
GRANT SELECT,INSERT,UPDATE ON notitle.privacy_holds,notitle.privacy_jobs TO notitle_app;
GRANT SELECT ON notitle.restricted_registration,notitle.privacy_purge_audit TO notitle_app;
-- Legacy holds remain authoritative but all new hold/release changes require
-- the independent journal. Reviewed conversion uses the migration role.
REVOKE INSERT,UPDATE ON notitle.legal_holds FROM notitle_app;

-- Narrow SECURITY DEFINER entry points retain least privilege. No generic
-- DELETE on evidence, consent, books, profiles, hold history or audit is granted.
-- Every purge and hold update takes the same advisory lock; account locks order
-- with existing identity/billing transactions. Functions never run dynamic SQL.
-- +goose StatementBegin
CREATE FUNCTION notitle.privacy_scrub_account(account_ uuid,policy_ text,now_ timestamptz) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE p_ jsonb;d_ notitle.deletion_jobs%ROWTYPE;a_ notitle.accounts%ROWTYPE;days_ integer;rows_ bigint;
BEGIN
 IF abs(extract(epoch FROM clock_timestamp()-now_))>5 THEN RAISE EXCEPTION 'Invalid execution clock'; END IF;
 PERFORM pg_advisory_xact_lock(7183924509);
 SELECT document INTO p_ FROM notitle.retention_policies WHERE version=policy_ AND approved;
 IF p_ IS NULL OR (p_->>'review_due_at')::timestamptz<=now_ OR NOT (p_->>'ordinary_deletion_approved')::boolean THEN RETURN false; END IF;
 SELECT * INTO a_ FROM notitle.accounts WHERE id=account_ FOR UPDATE;
 IF a_.id IS NULL OR a_.status<>'deletion_pending' THEN RETURN false; END IF;
 SELECT * INTO d_ FROM notitle.deletion_jobs WHERE account_id=account_ FOR UPDATE;
 IF d_.id IS NULL OR NOT d_.tombstone_durable OR d_.scrubbed_at IS NOT NULL THEN RETURN false; END IF;
 IF EXISTS(SELECT 1 FROM notitle.privacy_holds WHERE scope_kind='account' AND scope_ref=account_::text AND released_at IS NULL) THEN RETURN false; END IF;
 SELECT (r->>'maximum_days')::integer INTO days_ FROM jsonb_array_elements(p_->'rules')r WHERE r->>'purpose'='registration' AND (r->>'effective_at')::timestamptz<=now_ AND (r->>'reviewed_until')::timestamptz>now_;
 IF days_ IS NULL OR days_<180 THEN RETURN false; END IF;
 INSERT INTO notitle.restricted_registration(account_id,registration,retained_at,retention_until,policy_version)
 VALUES(account_,jsonb_build_object('username',a_.username,'created_at',a_.created_at,'cancelled_at',d_.requested_at),now_,GREATEST(now_,d_.requested_at+days_*interval '1 day'),policy_) ON CONFLICT(account_id) DO NOTHING;
 DELETE FROM notitle.sessions WHERE account_id=account_;
 DELETE FROM notitle.friendships WHERE account_a=account_ OR account_b=account_;
 DELETE FROM notitle.blocks WHERE blocker_id=account_ OR blocked_id=account_;
 DELETE FROM notitle.matchmaking_preferences WHERE account_id=account_;
 DELETE FROM notitle.professional_interests WHERE account_id=account_;
 DELETE FROM notitle.professional_profiles WHERE account_id=account_;
 DELETE FROM notitle.profiles WHERE account_id=account_;
 DELETE FROM notitle.pending_safety_handoffs WHERE account_id=account_;
 UPDATE notitle.accounts SET username='closed_'||substr(replace(id::text,'-',''),1,17),password_hash='$argon2id$v=19$deleted-account-inaccessible',recovery_hash=decode(repeat('00',32),'hex') WHERE id=account_;
 UPDATE notitle.deletion_jobs SET state='ordinary_erased_restricted_retained',scrubbed_at=now_ WHERE id=d_.id;
 INSERT INTO notitle.privacy_purge_audit(kind,subject_ref,policy_version,affected_rows,executed_at)VALUES('ordinary_account',account_::text,policy_,1,now_);
 RETURN true;
END $$;
-- +goose StatementEnd
REVOKE ALL ON FUNCTION notitle.privacy_scrub_account(uuid,text,timestamptz) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION notitle.privacy_scrub_account(uuid,text,timestamptz) TO notitle_app;

-- +goose StatementBegin
CREATE FUNCTION notitle.privacy_execute_job(job_ uuid,lease_ uuid,now_ timestamptz) RETURNS text LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE j_ notitle.privacy_jobs%ROWTYPE;p_ jsonb;rows_ bigint:=0;account_ uuid;anchor_ timestamptz;rule_ jsonb;min_ integer;max_ integer;case_ uuid;
BEGIN
 IF abs(extract(epoch FROM clock_timestamp()-now_))>5 THEN RAISE EXCEPTION 'Invalid execution clock'; END IF;
 PERFORM pg_advisory_xact_lock(7183924509);
 SELECT * INTO j_ FROM notitle.privacy_jobs WHERE id=job_ FOR UPDATE;
 IF j_.id IS NULL OR j_.state<>'leased' OR j_.lease_owner<>lease_ OR j_.lease_until<=now_ OR j_.not_before>now_ THEN RETURN 'conflict'; END IF;
 SELECT document INTO p_ FROM notitle.retention_policies WHERE version=j_.policy_version AND approved;
 IF p_ IS NULL OR (p_->>'review_due_at')::timestamptz<=now_ THEN RETURN 'policy'; END IF;
 SELECT r INTO rule_ FROM jsonb_array_elements(p_->'rules')r WHERE r->>'purpose'=CASE WHEN j_.kind IN ('report','operations_case') THEN 'cases' ELSE j_.kind END AND (r->>'effective_at')::timestamptz<=now_ AND (r->>'reviewed_until')::timestamptz>now_;
 IF rule_ IS NULL THEN RETURN 'policy'; END IF;min_:=(rule_->>'minimum_days')::integer;max_:=(rule_->>'maximum_days')::integer;
 IF j_.kind IN ('registration','financial') THEN
  account_:=j_.subject_ref::uuid;PERFORM 1 FROM notitle.accounts WHERE id=account_ AND status='deletion_pending' FOR UPDATE;
  IF NOT FOUND THEN RETURN 'conflict'; END IF;
 ELSIF j_.kind='report' THEN
  case_:=j_.subject_ref::uuid;PERFORM 1 FROM notitle.reports WHERE id=case_ FOR UPDATE;
 ELSIF j_.kind='operations_case' THEN
  PERFORM 1 FROM notitle.grievances WHERE ref=j_.subject_ref FOR UPDATE;
 END IF;
 IF EXISTS(SELECT 1 FROM notitle.privacy_holds h WHERE h.released_at IS NULL AND ((h.scope_kind=CASE WHEN j_.kind='registration' THEN 'account' ELSE j_.kind END AND h.scope_ref=j_.subject_ref)OR(h.scope_kind='account' AND h.scope_ref=account_::text))) THEN RETURN 'held'; END IF;
 IF j_.kind='registration' THEN
  SELECT d.requested_at INTO anchor_ FROM notitle.deletion_jobs d WHERE d.account_id=account_ AND d.tombstone_durable AND d.scrubbed_at IS NOT NULL;
  IF anchor_ IS NULL OR now_<anchor_+min_*interval '1 day' THEN RETURN 'not_due'; END IF;
  IF EXISTS(SELECT 1 FROM notitle.restricted_registration WHERE account_id=account_ AND retention_until>now_) THEN RETURN 'not_due'; END IF;
  DELETE FROM notitle.restricted_registration WHERE account_id=account_;GET DIAGNOSTICS rows_=ROW_COUNT;
  DELETE FROM notitle.consent_events WHERE account_id=account_;
  DELETE FROM notitle.rule_notice_deliveries WHERE account_id=account_;
 ELSIF j_.kind='report' THEN
  IF EXISTS(SELECT 1 FROM notitle.legal_holds WHERE case_id=case_ AND released_by_action IS NULL) OR EXISTS(SELECT 1 FROM notitle.case_subject_refs s JOIN notitle.privacy_holds h ON h.scope_kind='account' AND h.scope_ref=s.account_id::text AND h.released_at IS NULL WHERE s.case_id=case_) THEN RETURN 'held'; END IF;
  SELECT max(created_at) INTO anchor_ FROM notitle.moderation_actions WHERE case_id=case_ AND action='resolve';
  IF anchor_ IS NULL OR NOT EXISTS(SELECT 1 FROM notitle.reports WHERE id=case_ AND state='resolved') OR now_<anchor_+min_*interval '1 day' OR now_<anchor_+max_*interval '1 day' THEN RETURN 'not_due'; END IF;
  IF EXISTS(SELECT 1 FROM notitle.report_evidence WHERE case_id=case_ AND retention_until>now_) OR EXISTS(SELECT 1 FROM notitle.reports WHERE id=case_ AND retention_until>now_) THEN RETURN 'not_due'; END IF;
  DELETE FROM notitle.report_evidence WHERE case_id=case_;GET DIAGNOSTICS rows_=ROW_COUNT;
  DELETE FROM notitle.legal_holds WHERE case_id=case_;
  DELETE FROM notitle.moderation_actions WHERE case_id=case_;
  DELETE FROM notitle.case_subject_refs WHERE case_id=case_;
  DELETE FROM notitle.reports WHERE id=case_;
 ELSIF j_.kind='operations_case' THEN
  SELECT closed_at,account_id INTO anchor_,account_ FROM notitle.grievances WHERE ref=j_.subject_ref AND state='resolved';
  IF anchor_ IS NULL OR now_<anchor_+max_*interval '1 day' THEN RETURN 'not_due'; END IF;
  IF EXISTS(SELECT 1 FROM notitle.privacy_holds WHERE scope_kind='account' AND scope_ref=account_::text AND released_at IS NULL) THEN RETURN 'held'; END IF;
  IF EXISTS(SELECT 1 FROM notitle.grievance_messages WHERE case_ref=j_.subject_ref AND retention_until>now_) OR EXISTS(SELECT 1 FROM notitle.grievances WHERE ref=j_.subject_ref AND retention_until>now_) THEN RETURN 'not_due'; END IF;
  UPDATE notitle.grievance_messages SET ciphertext=NULL,nonce=NULL,key_id=NULL,purged_at=now_ WHERE case_ref=j_.subject_ref AND purged_at IS NULL;GET DIAGNOSTICS rows_=ROW_COUNT;
  DELETE FROM notitle.operations_outbox WHERE case_ref=j_.subject_ref;
  DELETE FROM notitle.grievance_actions WHERE case_ref=j_.subject_ref;
  DELETE FROM notitle.grievance_messages WHERE case_ref=j_.subject_ref;
  DELETE FROM notitle.grievances WHERE ref=j_.subject_ref;
 ELSIF j_.kind='financial' THEN
  IF j_.approved_by IS NULL OR NOT EXISTS(SELECT 1 FROM notitle.admin_users WHERE id=j_.approved_by AND NOT disabled AND 'owner'=ANY(roles)) OR NOT (p_->>'financial_schedule_approved')::boolean THEN RETURN 'policy'; END IF;
  IF NOT EXISTS(SELECT 1 FROM notitle.deletion_jobs WHERE account_id=account_ AND tombstone_durable AND scrubbed_at IS NOT NULL) THEN RETURN 'conflict'; END IF;
  IF EXISTS(SELECT 1 FROM notitle.purchase_orders o WHERE o.account_id=account_ AND (o.state IN ('intent','checkout_ready','processing','financial_review') OR EXISTS(SELECT 1 FROM notitle.payment_attempts a WHERE a.order_ref=o.ref AND a.status='PENDING') OR EXISTS(SELECT 1 FROM notitle.refunds r WHERE r.order_ref=o.ref AND r.state IN ('pending','review')) OR EXISTS(SELECT 1 FROM notitle.disputes d WHERE d.order_ref=o.ref AND d.state IN ('open','review')) OR EXISTS(SELECT 1 FROM notitle.billing_review_cases b WHERE b.order_ref=o.ref AND b.state='open') OR EXISTS(SELECT 1 FROM notitle.billing_jobs b WHERE b.order_ref=o.ref AND b.state IN ('ready','leased')))) THEN RETURN 'held'; END IF;
  SELECT max(at_) INTO anchor_ FROM (
   SELECT GREATEST(o.created_at,o.paid_at)at_ FROM notitle.purchase_orders o WHERE o.account_id=account_
   UNION ALL SELECT GREATEST(r.created_at,r.processed_at) FROM notitle.refunds r JOIN notitle.purchase_orders o ON o.ref=r.order_ref WHERE o.account_id=account_
   UNION ALL SELECT d.updated_at FROM notitle.disputes d JOIN notitle.purchase_orders o ON o.ref=d.order_ref WHERE o.account_id=account_
   UNION ALL SELECT r.recorded_at FROM notitle.settlement_reconciliation r JOIN notitle.purchase_orders o ON o.ref=r.order_ref WHERE o.account_id=account_
   UNION ALL SELECT a.created_at FROM notitle.premium_adjustments a WHERE a.account_id=account_
   UNION ALL SELECT b.resolved_at FROM notitle.billing_review_cases b JOIN notitle.purchase_orders o ON o.ref=b.order_ref WHERE o.account_id=account_
   UNION ALL SELECT a.created_at FROM notitle.billing_review_actions a JOIN notitle.billing_review_cases b ON b.ref=a.case_ref JOIN notitle.purchase_orders o ON o.ref=b.order_ref WHERE o.account_id=account_
   UNION ALL SELECT a.created_at FROM notitle.billing_dispute_actions a JOIN notitle.purchase_orders o ON o.ref=a.order_ref WHERE o.account_id=account_
  )a;
  IF anchor_ IS NULL OR now_<anchor_+max_*interval '1 day' THEN RETURN 'not_due'; END IF;
  IF (SELECT count(*) FROM notitle.premium_adjustments WHERE account_id=account_)>10000 OR (SELECT count(*) FROM notitle.purchase_orders WHERE account_id=account_)>1000 THEN RETURN 'review'; END IF;
  DELETE FROM notitle.billing_review_actions WHERE case_ref IN (SELECT b.ref FROM notitle.billing_review_cases b JOIN notitle.purchase_orders o ON o.ref=b.order_ref WHERE o.account_id=account_);
  DELETE FROM notitle.billing_review_cases WHERE order_ref IN (SELECT ref FROM notitle.purchase_orders WHERE account_id=account_);
  DELETE FROM notitle.billing_dispute_actions WHERE order_ref IN (SELECT ref FROM notitle.purchase_orders WHERE account_id=account_);
  DELETE FROM notitle.disputes WHERE order_ref IN (SELECT ref FROM notitle.purchase_orders WHERE account_id=account_);
  DELETE FROM notitle.refunds WHERE order_ref IN (SELECT ref FROM notitle.purchase_orders WHERE account_id=account_);
  DELETE FROM notitle.premium_adjustments WHERE account_id=account_;
  DELETE FROM notitle.premium_lots WHERE account_id=account_;
  DELETE FROM notitle.premium_accounts WHERE account_id=account_;
  DELETE FROM notitle.payment_attempts WHERE order_ref IN (SELECT ref FROM notitle.purchase_orders WHERE account_id=account_);
  DELETE FROM notitle.payment_webhook_inbox WHERE order_ref IN (SELECT ref FROM notitle.purchase_orders WHERE account_id=account_);
  DELETE FROM notitle.settlement_reconciliation WHERE order_ref IN (SELECT ref FROM notitle.purchase_orders WHERE account_id=account_);
  DELETE FROM notitle.billing_jobs WHERE order_ref IN (SELECT ref FROM notitle.purchase_orders WHERE account_id=account_);
  DELETE FROM notitle.purchase_orders WHERE account_id=account_;GET DIAGNOSTICS rows_=ROW_COUNT;
 END IF;
 INSERT INTO notitle.privacy_purge_audit(job_id,kind,subject_ref,policy_version,affected_rows,executed_at)VALUES(job_,j_.kind,j_.subject_ref,j_.policy_version,rows_,now_);
 UPDATE notitle.privacy_jobs SET state='done',lease_owner=NULL,lease_until=NULL,completed_at=now_,last_error='' WHERE id=job_;
 RETURN 'done';
END $$;
-- +goose StatementEnd
REVOKE ALL ON FUNCTION notitle.privacy_execute_job(uuid,uuid,timestamptz) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION notitle.privacy_execute_job(uuid,uuid,timestamptz) TO notitle_app;
-- SQL audit records have their own reviewed ICT-log lifecycle. This is not a
-- transcript archive. Expiry cannot bypass active relevant holds or legal review.
-- +goose StatementBegin
CREATE FUNCTION notitle.privacy_expire_security_audit(policy_ text,now_ timestamptz) RETURNS bigint LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog AS $$
DECLARE p_ jsonb;r_ jsonb;days_ integer;rows_ bigint:=0;
BEGIN
 IF abs(extract(epoch FROM clock_timestamp()-now_))>5 THEN RAISE EXCEPTION 'Invalid execution clock'; END IF;
 PERFORM pg_advisory_xact_lock(7183924509);
 SELECT document INTO p_ FROM notitle.retention_policies WHERE version=policy_ AND approved;
 IF p_ IS NULL OR p_->>'storage_region'<>'IN' OR (p_->>'review_due_at')::timestamptz<=now_ THEN RETURN 0; END IF;
 SELECT r INTO r_ FROM jsonb_array_elements(p_->'rules')r WHERE r->>'purpose'='security_logs' AND (r->>'effective_at')::timestamptz<=now_ AND (r->>'reviewed_until')::timestamptz>now_;
 IF r_ IS NULL OR (r_->>'minimum_days')::integer<180 THEN RETURN 0; END IF;
 days_:=(r_->>'maximum_days')::integer;IF days_<180 THEN RETURN 0; END IF;
 DELETE FROM notitle.admin_audit a WHERE a.id IN (
  SELECT x.id FROM notitle.admin_audit x WHERE x.created_at<=now_-days_*interval '1 day'
  AND NOT EXISTS(SELECT 1 FROM notitle.privacy_holds h WHERE h.released_at IS NULL AND (
    h.id::text=x.subject_ref OR h.scope_ref=x.subject_ref
    OR (h.scope_kind='report' AND EXISTS(SELECT 1 FROM notitle.reports r WHERE r.id::text=h.scope_ref AND r.case_ref=x.subject_ref))
    OR (h.scope_kind IN ('account','financial') AND EXISTS(SELECT 1 FROM notitle.purchase_orders o WHERE o.account_id::text=h.scope_ref AND o.ref=x.subject_ref))
    OR (h.scope_kind='account' AND EXISTS(SELECT 1 FROM notitle.case_subject_refs c JOIN notitle.reports r ON r.id=c.case_id WHERE c.account_id::text=h.scope_ref AND r.case_ref=x.subject_ref))
  )) AND NOT EXISTS(SELECT 1 FROM notitle.legal_holds h JOIN notitle.reports r ON r.id=h.case_id WHERE h.released_by_action IS NULL AND r.case_ref=x.subject_ref)
  ORDER BY x.created_at,x.id LIMIT 50 FOR UPDATE SKIP LOCKED
 );GET DIAGNOSTICS rows_=ROW_COUNT;
 IF rows_>0 THEN INSERT INTO notitle.privacy_purge_audit(kind,subject_ref,policy_version,affected_rows,executed_at)VALUES('security_audit','',policy_,rows_,now_); END IF;
 RETURN rows_;
END $$;
-- +goose StatementEnd
REVOKE ALL ON FUNCTION notitle.privacy_expire_security_audit(text,timestamptz) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION notitle.privacy_expire_security_audit(text,timestamptz) TO notitle_app;
ALTER TABLE notitle.schema_version DROP CONSTRAINT schema_version_version_check;
UPDATE notitle.schema_version SET version=9 WHERE version=8;
ALTER TABLE notitle.schema_version ADD CONSTRAINT schema_version_version_check CHECK(version=9);
-- +goose Down
GRANT INSERT,UPDATE ON notitle.legal_holds TO notitle_app;
DROP FUNCTION notitle.privacy_execute_job(uuid,uuid,timestamptz),notitle.privacy_scrub_account(uuid,text,timestamptz),notitle.privacy_expire_security_audit(text,timestamptz);
ALTER TABLE notitle.reports DROP COLUMN evidence_purged_at;
ALTER TABLE notitle.deletion_jobs DROP COLUMN scrubbed_at;
ALTER TABLE notitle.deletion_jobs DROP CONSTRAINT deletion_jobs_state_check;
UPDATE notitle.deletion_jobs SET state='awaiting_retention_review';
ALTER TABLE notitle.deletion_jobs ADD CONSTRAINT deletion_jobs_state_check CHECK(state='awaiting_retention_review');
DROP TABLE notitle.privacy_purge_audit,notitle.privacy_jobs,notitle.restricted_registration,notitle.privacy_holds,notitle.privacy_hold_events,notitle.retention_policies;
ALTER TABLE notitle.schema_version DROP CONSTRAINT schema_version_version_check;
UPDATE notitle.schema_version SET version=8 WHERE version=9;
ALTER TABLE notitle.schema_version ADD CONSTRAINT schema_version_version_check CHECK(version=8);
