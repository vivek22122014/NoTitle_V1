-- +goose Up
-- All amounts are integer paise and all durations are exact seconds.
-- +goose StatementBegin
DO $$ BEGIN
 IF current_user <> 'notitle_migrate' THEN RAISE EXCEPTION 'Migrations require the dedicated notitle_migrate role'; END IF;
END $$;
-- +goose StatementEnd
CREATE TABLE notitle.premium_plans (
 id text NOT NULL CHECK(id IN ('three-day','seven-day','thirty-day','annual')),
 version bigint NOT NULL CHECK(version>0), name text NOT NULL,
 amount_paise bigint NOT NULL CHECK(amount_paise>0 AND amount_paise<=100000000),
 currency text NOT NULL CHECK(currency='INR'), duration_seconds bigint NOT NULL CHECK(duration_seconds>0 AND duration_seconds<=31536000),
 tax_treatment text NOT NULL CHECK(tax_treatment IN ('pending_review','not_applicable','inclusive')),
 tax_paise bigint NOT NULL CHECK(tax_paise>=0 AND tax_paise<=amount_paise),
 enabled boolean NOT NULL DEFAULT false,
 annual_approved boolean NOT NULL DEFAULT false,
 PRIMARY KEY(id,version), CHECK(NOT enabled OR tax_treatment<>'pending_review'), CHECK(id<>'annual' OR NOT enabled OR annual_approved)
);
INSERT INTO notitle.premium_plans VALUES
 ('three-day',1,'Three days',9900,'INR',259200,'pending_review',0,false,false),
 ('seven-day',1,'Seven days',19900,'INR',604800,'pending_review',0,false,false),
 ('thirty-day',1,'Thirty days',49900,'INR',2592000,'pending_review',0,false,false),
 ('annual',1,'One year',149900,'INR',31536000,'pending_review',0,false,false);
CREATE UNIQUE INDEX premium_plans_one_enabled ON notitle.premium_plans(id) WHERE enabled;
CREATE TABLE notitle.purchase_orders (
 ref text COLLATE "C" PRIMARY KEY CHECK(ref ~ '^[A-Za-z0-9_-]{16,128}$'),
 account_id uuid REFERENCES notitle.accounts(id) ON DELETE SET NULL,
 financial_subject text NOT NULL,
 idempotency_key text NOT NULL CHECK(idempotency_key ~ '^[A-Za-z0-9_-]{16,128}$'),
 environment text NOT NULL CHECK(environment IN ('sandbox','production')),
 merchant_id text NOT NULL CHECK(length(merchant_id) BETWEEN 1 AND 128),
 provider_order_id text, checkout_session text,
 plan_id text NOT NULL,plan_version bigint NOT NULL,plan_name text NOT NULL,
 amount_paise bigint NOT NULL CHECK(amount_paise>0),currency text NOT NULL CHECK(currency='INR'),
 duration_seconds bigint NOT NULL CHECK(duration_seconds>0 AND duration_seconds<=31536000),
 tax_treatment text NOT NULL CHECK(tax_treatment IN ('not_applicable','inclusive')),tax_paise bigint NOT NULL CHECK(tax_paise>=0 AND tax_paise<=amount_paise),
 state text NOT NULL CHECK(state IN ('intent','checkout_ready','processing','paid','financial_review','expired')),
 created_at timestamptz NOT NULL,paid_at timestamptz,last_reconciled_at timestamptz,
 UNIQUE(environment,financial_subject,idempotency_key), UNIQUE(environment,provider_order_id),
 FOREIGN KEY(plan_id,plan_version) REFERENCES notitle.premium_plans(id,version)
);
CREATE INDEX purchase_orders_account_time ON notitle.purchase_orders(account_id,created_at DESC);
CREATE INDEX purchase_orders_pending ON notitle.purchase_orders(environment,created_at) WHERE state IN ('intent','checkout_ready','processing');
CREATE TABLE notitle.payment_attempts (
 environment text NOT NULL CHECK(environment IN ('sandbox','production')),
 payment_id text NOT NULL,order_ref text NOT NULL REFERENCES notitle.purchase_orders(ref),
 amount_paise bigint NOT NULL CHECK(amount_paise>0),currency text NOT NULL CHECK(currency='INR'),
 status text NOT NULL CHECK(status IN ('SUCCESS','PENDING','FAILED','USER_DROPPED','CANCELLED','VOID','NOT_ATTEMPTED')),
 paid_at timestamptz,observed_at timestamptz NOT NULL,
 PRIMARY KEY(environment,payment_id),CHECK(status<>'SUCCESS' OR paid_at IS NOT NULL)
);
CREATE INDEX payment_attempts_order ON notitle.payment_attempts(order_ref);
CREATE TABLE notitle.premium_accounts (
 account_id uuid NOT NULL REFERENCES notitle.accounts(id) ON DELETE RESTRICT, environment text NOT NULL CHECK(environment IN ('sandbox','production')),
 checkpoint_at timestamptz NOT NULL, revision bigint NOT NULL DEFAULT 1 CHECK(revision>0),PRIMARY KEY(account_id,environment)
);
CREATE TABLE notitle.premium_lots (
 ref text PRIMARY KEY,grant_sequence bigint GENERATED ALWAYS AS IDENTITY UNIQUE,account_id uuid NOT NULL REFERENCES notitle.accounts(id) ON DELETE RESTRICT,
 order_ref text NOT NULL UNIQUE REFERENCES notitle.purchase_orders(ref),environment text NOT NULL CHECK(environment IN ('sandbox','production')),payment_id text NOT NULL,
 duration_seconds bigint NOT NULL CHECK(duration_seconds>0),remaining_seconds bigint NOT NULL CHECK(remaining_seconds>=0),
 held_seconds bigint NOT NULL DEFAULT 0 CHECK(held_seconds>=0),consumed_seconds bigint NOT NULL DEFAULT 0 CHECK(consumed_seconds>=0),revoked_seconds bigint NOT NULL DEFAULT 0 CHECK(revoked_seconds>=0),
 paid_controls_used boolean NOT NULL DEFAULT false,granted_at timestamptz NOT NULL,
 UNIQUE(environment,payment_id),FOREIGN KEY(environment,payment_id) REFERENCES notitle.payment_attempts(environment,payment_id),
 CHECK(duration_seconds=remaining_seconds+held_seconds+consumed_seconds+revoked_seconds)
);
CREATE INDEX premium_lots_fifo ON notitle.premium_lots(account_id,grant_sequence);
CREATE TABLE notitle.premium_adjustments (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,environment text NOT NULL CHECK(environment IN ('sandbox','production')),account_id uuid NOT NULL REFERENCES notitle.accounts(id),lot_ref text REFERENCES notitle.premium_lots(ref),
 kind text NOT NULL CHECK(kind IN ('grant','consume','hold','restore','revoke','paid_use','checkpoint')),
 seconds bigint NOT NULL CHECK(seconds>=0),revision bigint NOT NULL CHECK(revision>0),reference text NOT NULL DEFAULT '',created_at timestamptz NOT NULL
);
CREATE INDEX premium_adjustments_account ON notitle.premium_adjustments(account_id,id);
CREATE TABLE notitle.refunds (
 ref text PRIMARY KEY,order_ref text NOT NULL REFERENCES notitle.purchase_orders(ref),environment text NOT NULL CHECK(environment IN ('sandbox','production')),payment_id text NOT NULL,
 idempotency_key text NOT NULL UNIQUE,provider_refund_id text,
 amount_paise bigint NOT NULL CHECK(amount_paise>0),treatment text NOT NULL CHECK(treatment IN ('full','money_only','duration')),
 held_seconds bigint NOT NULL DEFAULT 0 CHECK(held_seconds>=0),
 state text NOT NULL CHECK(state IN ('pending','processed','failed','cancelled','review')),external boolean NOT NULL DEFAULT false,last_reconciled_at timestamptz,
 actor_id uuid REFERENCES notitle.admin_users(id),reason text NOT NULL CHECK(length(reason) BETWEEN 1 AND 1000),
 created_at timestamptz NOT NULL,processed_at timestamptz,
 UNIQUE(environment,provider_refund_id),FOREIGN KEY(environment,payment_id) REFERENCES notitle.payment_attempts(environment,payment_id)
);
CREATE INDEX refunds_order ON notitle.refunds(order_ref,created_at);
CREATE TABLE notitle.disputes (
 environment text NOT NULL CHECK(environment IN ('sandbox','production')),provider_dispute_id text NOT NULL,order_ref text NOT NULL REFERENCES notitle.purchase_orders(ref),payment_id text NOT NULL,
 state text NOT NULL CHECK(state IN ('open','won','lost','review')),response_due timestamptz NOT NULL,
 held_seconds bigint NOT NULL DEFAULT 0 CHECK(held_seconds>=0),reason text NOT NULL,created_at timestamptz NOT NULL,updated_at timestamptz NOT NULL,
 revision bigint NOT NULL DEFAULT 1 CHECK(revision>0),
 PRIMARY KEY(environment,provider_dispute_id),FOREIGN KEY(environment,payment_id) REFERENCES notitle.payment_attempts(environment,payment_id)
);
CREATE TABLE notitle.billing_review_cases (
 ref text PRIMARY KEY,environment text NOT NULL CHECK(environment IN ('sandbox','production')),kind text NOT NULL,order_ref text NOT NULL DEFAULT '',payment_id text NOT NULL DEFAULT '',
 state text NOT NULL DEFAULT 'open' CHECK(state IN ('open','resolved')),reason text NOT NULL DEFAULT '',created_at timestamptz NOT NULL,resolved_at timestamptz,
 revision bigint NOT NULL DEFAULT 1 CHECK(revision>0),
 UNIQUE(environment,kind,order_ref,payment_id)
);
CREATE INDEX billing_review_open ON notitle.billing_review_cases(created_at) WHERE state='open';
CREATE TABLE notitle.billing_review_actions (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 case_ref text NOT NULL REFERENCES notitle.billing_review_cases(ref),actor_id uuid NOT NULL REFERENCES notitle.admin_users(id),
 idempotency_key text NOT NULL CHECK(idempotency_key ~ '^[A-Za-z0-9_-]{16,128}$'),
 expected_revision bigint NOT NULL CHECK(expected_revision>0),action text NOT NULL CHECK(action IN ('note','resolve','reopen')),
 reason text NOT NULL CHECK(length(reason) BETWEEN 5 AND 1000),created_at timestamptz NOT NULL,
 UNIQUE(actor_id,idempotency_key)
);
CREATE TABLE notitle.billing_dispute_actions (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 actor_id uuid NOT NULL REFERENCES notitle.admin_users(id),idempotency_key text NOT NULL CHECK(idempotency_key ~ '^[A-Za-z0-9_-]{16,128}$'),
 provider_dispute_id text NOT NULL,order_ref text NOT NULL REFERENCES notitle.purchase_orders(ref),payment_id text NOT NULL,
 expected_revision bigint NOT NULL CHECK(expected_revision>=0),status text NOT NULL CHECK(status IN ('open','won','lost','review')),
 hold_access boolean NOT NULL,response_due timestamptz NOT NULL,reason text NOT NULL CHECK(length(reason) BETWEEN 5 AND 1000),created_at timestamptz NOT NULL,
 UNIQUE(actor_id,idempotency_key)
);
CREATE TABLE notitle.payment_webhook_inbox (
 environment text NOT NULL CHECK(environment IN ('sandbox','production')),event_key text NOT NULL,kind text NOT NULL,order_ref text NOT NULL,payment_id text NOT NULL DEFAULT '',refund_id text NOT NULL DEFAULT '',dispute_id text NOT NULL DEFAULT '',
 dispute_status text NOT NULL DEFAULT '',response_due timestamptz,received_at timestamptz NOT NULL,PRIMARY KEY(environment,event_key)
);
CREATE TABLE notitle.billing_jobs (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,environment text NOT NULL CHECK(environment IN ('sandbox','production')),kind text NOT NULL,order_ref text NOT NULL DEFAULT '',refund_ref text NOT NULL DEFAULT '',event_key text NOT NULL DEFAULT '',
 dedupe_key text NOT NULL UNIQUE,state text NOT NULL DEFAULT 'ready' CHECK(state IN ('ready','leased','done','dead')),
 attempts integer NOT NULL DEFAULT 0 CHECK(attempts>=0),run_at timestamptz NOT NULL,lease_owner text,lease_until timestamptz,
 period_start timestamptz,period_end timestamptz,cursor text NOT NULL DEFAULT '',page_count integer NOT NULL DEFAULT 0 CHECK(page_count BETWEEN 0 AND 1000),created_at timestamptz NOT NULL,finished_at timestamptz
);
CREATE INDEX billing_jobs_claim ON notitle.billing_jobs(environment,run_at,id) WHERE state IN ('ready','leased');
CREATE INDEX billing_jobs_active_order ON notitle.billing_jobs(environment,order_ref,kind) WHERE state IN ('ready','leased');
CREATE INDEX billing_jobs_active_refund ON notitle.billing_jobs(environment,refund_ref,kind) WHERE state IN ('ready','leased');
CREATE TABLE notitle.billing_reconciliation_watermarks (environment text NOT NULL CHECK(environment IN ('sandbox','production')),kind text NOT NULL,next_period timestamptz NOT NULL,PRIMARY KEY(environment,kind));
REVOKE ALL ON notitle.billing_reconciliation_watermarks FROM PUBLIC;
GRANT SELECT,INSERT,UPDATE ON notitle.billing_reconciliation_watermarks TO notitle_app;
CREATE TABLE notitle.settlement_reconciliation (
 ref text PRIMARY KEY,environment text NOT NULL CHECK(environment IN ('sandbox','production')),kind text NOT NULL,order_ref text NOT NULL DEFAULT '',payment_id text NOT NULL DEFAULT '',refund_id text NOT NULL DEFAULT '',
 state text NOT NULL,provider_status text NOT NULL DEFAULT '',currency text NOT NULL DEFAULT '',money_complete boolean NOT NULL DEFAULT false,amount_paise bigint NOT NULL CHECK(amount_paise>=0),fee_paise bigint NOT NULL CHECK(fee_paise>=0),tax_paise bigint NOT NULL CHECK(tax_paise>=0),net_paise bigint NOT NULL,
 period_start timestamptz NOT NULL,period_end timestamptz NOT NULL,recorded_at timestamptz NOT NULL,CHECK(period_end>=period_start)
);
-- Versioned plan economics and original purchase terms cannot be edited even
-- by application SQL. Only publication toggles are permitted on a plan version.
-- +goose StatementBegin
CREATE FUNCTION notitle.billing_immutable_snapshot() RETURNS trigger LANGUAGE plpgsql SET search_path=pg_catalog AS $$
BEGIN
 IF TG_TABLE_NAME='premium_plans' THEN
  IF (to_jsonb(NEW)-'enabled'-'annual_approved') IS DISTINCT FROM (to_jsonb(OLD)-'enabled'-'annual_approved') THEN RAISE EXCEPTION 'Plan versions are immutable'; END IF;
 ELSE
  IF (NEW.ref,NEW.financial_subject,NEW.idempotency_key,NEW.environment,NEW.merchant_id,NEW.plan_id,NEW.plan_version,NEW.plan_name,NEW.amount_paise,NEW.currency,NEW.duration_seconds,NEW.tax_treatment,NEW.tax_paise,NEW.created_at)
   IS DISTINCT FROM (OLD.ref,OLD.financial_subject,OLD.idempotency_key,OLD.environment,OLD.merchant_id,OLD.plan_id,OLD.plan_version,OLD.plan_name,OLD.amount_paise,OLD.currency,OLD.duration_seconds,OLD.tax_treatment,OLD.tax_paise,OLD.created_at) THEN RAISE EXCEPTION 'Purchase terms are immutable'; END IF;
  IF OLD.provider_order_id IS NOT NULL AND NEW.provider_order_id IS DISTINCT FROM OLD.provider_order_id THEN RAISE EXCEPTION 'Provider association is immutable'; END IF;
 END IF; RETURN NEW;
END $$;
-- +goose StatementEnd
CREATE TRIGGER premium_plan_immutable BEFORE UPDATE ON notitle.premium_plans FOR EACH ROW EXECUTE FUNCTION notitle.billing_immutable_snapshot();
CREATE TRIGGER purchase_order_immutable BEFORE UPDATE ON notitle.purchase_orders FOR EACH ROW EXECUTE FUNCTION notitle.billing_immutable_snapshot();
REVOKE ALL ON FUNCTION notitle.billing_immutable_snapshot() FROM PUBLIC;
REVOKE ALL ON notitle.premium_plans,notitle.purchase_orders,notitle.payment_attempts,notitle.premium_accounts,notitle.premium_lots,notitle.premium_adjustments,notitle.refunds,notitle.disputes,notitle.billing_review_cases,notitle.payment_webhook_inbox,notitle.billing_jobs,notitle.settlement_reconciliation FROM PUBLIC;
GRANT SELECT ON notitle.premium_plans TO notitle_app;
GRANT SELECT,INSERT,UPDATE ON notitle.purchase_orders,notitle.payment_attempts,notitle.premium_accounts,notitle.premium_lots,notitle.refunds,notitle.disputes,notitle.billing_review_cases,notitle.billing_jobs TO notitle_app;
GRANT SELECT,INSERT ON notitle.premium_adjustments,notitle.payment_webhook_inbox,notitle.settlement_reconciliation,notitle.billing_review_actions,notitle.billing_dispute_actions TO notitle_app;
GRANT USAGE,SELECT ON SEQUENCE notitle.premium_adjustments_id_seq,notitle.premium_lots_grant_sequence_seq,notitle.billing_jobs_id_seq,notitle.billing_review_actions_id_seq,notitle.billing_dispute_actions_id_seq TO notitle_app;
REVOKE ALL ON notitle.billing_review_actions,notitle.billing_dispute_actions FROM PUBLIC;
COMMENT ON TABLE notitle.premium_adjustments IS 'Append-only financial duration events; no runtime UPDATE or DELETE. Lots are rebuildable projections.';
COMMENT ON TABLE notitle.payment_webhook_inbox IS 'Verified normalized financial identifiers only; never raw payload, customer phone, email, bank or card data.';
ALTER TABLE notitle.schema_version DROP CONSTRAINT schema_version_version_check;
UPDATE notitle.schema_version SET version=7 WHERE version=6;
ALTER TABLE notitle.schema_version ADD CONSTRAINT schema_version_version_check CHECK(version=7);
-- +goose Down
-- Disposable fixtures only; never reverse retained financial records.
DROP TRIGGER purchase_order_immutable ON notitle.purchase_orders;
DROP TRIGGER premium_plan_immutable ON notitle.premium_plans;
DROP FUNCTION notitle.billing_immutable_snapshot();
DROP TABLE notitle.billing_reconciliation_watermarks,notitle.settlement_reconciliation,notitle.billing_jobs,notitle.payment_webhook_inbox,notitle.billing_dispute_actions,notitle.billing_review_actions,notitle.billing_review_cases,notitle.disputes,notitle.refunds,notitle.premium_adjustments,notitle.premium_lots,notitle.premium_accounts,notitle.payment_attempts,notitle.purchase_orders,notitle.premium_plans;
ALTER TABLE notitle.schema_version DROP CONSTRAINT schema_version_version_check;
UPDATE notitle.schema_version SET version=6 WHERE version=7;
ALTER TABLE notitle.schema_version ADD CONSTRAINT schema_version_version_check CHECK(version=6);
