-- +goose Up
-- +goose StatementBegin
DO $$
BEGIN
    IF current_user <> 'notitle_migrate' THEN
        RAISE EXCEPTION 'Migrations require the dedicated notitle_migrate role';
    END IF;
END
$$;
-- +goose StatementEnd

-- Arrays are small controlled selections, never arbitrary free text. The helper
-- is immutable and checks dimensionality, NULL elements and duplicate values.
-- +goose StatementBegin
CREATE FUNCTION notitle.unique_choices(values_ text[], maximum_ integer)
RETURNS boolean LANGUAGE sql IMMUTABLE STRICT PARALLEL SAFE
SET search_path = pg_catalog
AS $$
    SELECT cardinality(values_) <= maximum_
       AND COALESCE(array_ndims(values_), 1) = 1
       AND array_position(values_, NULL) IS NULL
       AND cardinality(values_) = (SELECT count(DISTINCT value_) FROM unnest(values_) AS value_)
$$;
-- +goose StatementEnd
REVOKE ALL ON FUNCTION notitle.unique_choices(text[], integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION notitle.unique_choices(text[], integer) TO notitle_app;

CREATE TABLE notitle.matchmaking_preferences (
    account_id uuid PRIMARY KEY REFERENCES notitle.accounts(id) ON DELETE RESTRICT,
    version bigint NOT NULL DEFAULT 1 CHECK (version > 0),
    gender_preference text NOT NULL DEFAULT 'everyone' CHECK (gender_preference IN ('everyone','male','female','other')),
    professional_mode text NOT NULL DEFAULT 'none' CHECK (professional_mode IN ('none','custom')),
    industry_none boolean NOT NULL DEFAULT true,
    profession_none boolean NOT NULL DEFAULT true,
    experience_none boolean NOT NULL DEFAULT true,
    interests_none boolean NOT NULL DEFAULT true,
    topics_none boolean NOT NULL DEFAULT true,
    preferred_industries text[] NOT NULL DEFAULT ARRAY[]::text[] CHECK (
        notitle.unique_choices(preferred_industries,5) AND preferred_industries <@ ARRAY['technology','finance','healthcare','education','manufacturing','retail','consulting','public_service','media','other']::text[]),
    preferred_roles text[] NOT NULL DEFAULT ARRAY[]::text[] CHECK (
        notitle.unique_choices(preferred_roles,5) AND preferred_roles <@ ARRAY['engineering','product','design','data','operations','sales','marketing','hr','finance','legal','education','healthcare','student','other']::text[]),
    preferred_experience text[] NOT NULL DEFAULT ARRAY[]::text[] CHECK (
        notitle.unique_choices(preferred_experience,5) AND preferred_experience <@ ARRAY['student','0_2','3_5','6_10','11_plus']::text[]),
    preferred_interests text[] NOT NULL DEFAULT ARRAY[]::text[] CHECK (
        notitle.unique_choices(preferred_interests,10) AND preferred_interests <@ ARRAY['career_growth','leadership','work_life_balance','interview_prep','learning_skills','compensation','workplace_culture','entrepreneurship']::text[]),
    preferred_topics text[] NOT NULL DEFAULT ARRAY[]::text[] CHECK (
        notitle.unique_choices(preferred_topics,5) AND preferred_topics <@ ARRAY['general_talk','work_culture','career_growth','managers','salaries','hiring','office_politics','industry_experiences']::text[]),
    updated_at timestamptz NOT NULL,
    CHECK (NOT industry_none OR cardinality(preferred_industries) = 0),
    CHECK (NOT profession_none OR cardinality(preferred_roles) = 0),
    CHECK (NOT experience_none OR cardinality(preferred_experience) = 0),
    CHECK (NOT interests_none OR cardinality(preferred_interests) = 0),
    CHECK (NOT topics_none OR cardinality(preferred_topics) = 0)
);
COMMENT ON TABLE notitle.matchmaking_preferences IS 'Owner-private saved choices. Global No preference preserves category choices; entitlement never comes from this row. Guests remain in coordinator memory.';
REVOKE ALL ON notitle.matchmaking_preferences FROM PUBLIC;
GRANT SELECT, INSERT, UPDATE ON notitle.matchmaking_preferences TO notitle_app;
ALTER TABLE notitle.schema_version DROP CONSTRAINT schema_version_version_check;
UPDATE notitle.schema_version SET version = 3 WHERE version = 2;
ALTER TABLE notitle.schema_version ADD CONSTRAINT schema_version_version_check CHECK (version = 3);
COMMENT ON TABLE notitle.schema_version IS 'Readiness contract for Phase 4 realtime preferences.';

-- +goose Down
-- Disposable test databases only. Production rollback must preserve saved data.
DROP TABLE notitle.matchmaking_preferences;
DROP FUNCTION notitle.unique_choices(text[], integer);
ALTER TABLE notitle.schema_version DROP CONSTRAINT schema_version_version_check;
UPDATE notitle.schema_version SET version = 2 WHERE version = 3;
ALTER TABLE notitle.schema_version ADD CONSTRAINT schema_version_version_check CHECK (version = 2);
COMMENT ON TABLE notitle.schema_version IS 'Readiness contract for Phase 3 identity.';
