-- +goose Up
-- Private operations identities are deliberately unrelated to public accounts.
-- +goose StatementBegin
DO $$
BEGIN
    IF current_user <> 'notitle_migrate' THEN
        RAISE EXCEPTION 'Migrations require the dedicated notitle_migrate role';
    END IF;
END
$$;
-- +goose StatementEnd
CREATE TABLE notitle.admin_users (
    id uuid PRIMARY KEY,
    username text COLLATE "C" NOT NULL UNIQUE CHECK (username ~ '^[a-z0-9_.-]{4,64}$'),
    password_hash text NOT NULL CHECK (length(password_hash) BETWEEN 40 AND 256 AND password_hash LIKE '$argon2id$v=19$%'),
    totp_ciphertext bytea NOT NULL CHECK (octet_length(totp_ciphertext) = 48),
    roles text[] NOT NULL CHECK (cardinality(roles) BETWEEN 1 AND 5 AND roles <@ ARRAY['owner','moderator','grievance_officer','billing_operator','operations_readonly']::text[]),
    generation bigint NOT NULL DEFAULT 1 CHECK (generation > 0),
    disabled boolean NOT NULL DEFAULT false,
    last_counter bigint NOT NULL DEFAULT -1 CHECK (last_counter >= -1),
    created_at timestamptz NOT NULL
);
CREATE TABLE notitle.admin_sessions (
    token_hash bytea PRIMARY KEY CHECK (octet_length(token_hash) = 32),
    admin_id uuid NOT NULL REFERENCES notitle.admin_users(id) ON DELETE RESTRICT,
    admin_generation bigint NOT NULL CHECK (admin_generation > 0),
    created_at timestamptz NOT NULL,
    last_seen_at timestamptz NOT NULL,
    absolute_expires_at timestamptz NOT NULL,
    CHECK (absolute_expires_at = created_at + interval '4 hours'),
    CHECK (last_seen_at >= created_at AND last_seen_at < absolute_expires_at)
);
CREATE INDEX admin_sessions_user_idx ON notitle.admin_sessions(admin_id, created_at);
CREATE INDEX admin_sessions_expiry_idx ON notitle.admin_sessions(absolute_expires_at);
CREATE TABLE notitle.admin_audit (
    id uuid PRIMARY KEY,
    admin_id uuid REFERENCES notitle.admin_users(id) ON DELETE RESTRICT,
    action text NOT NULL CHECK (char_length(action) BETWEEN 1 AND 64),
    subject_ref text NOT NULL DEFAULT '' CHECK (char_length(subject_ref) <= 128),
    reason text NOT NULL DEFAULT '' CHECK (char_length(reason) <= 1000),
    result text NOT NULL CHECK (result IN ('success','denied','failed')),
    created_at timestamptz NOT NULL
);
CREATE INDEX admin_audit_actor_time_idx ON notitle.admin_audit(admin_id, created_at DESC);
CREATE INDEX admin_audit_subject_time_idx ON notitle.admin_audit(subject_ref, created_at DESC);
ALTER TABLE notitle.moderation_actions ADD CONSTRAINT moderation_actions_admin_fk FOREIGN KEY(admin_id) REFERENCES notitle.admin_users(id) ON DELETE RESTRICT;
REVOKE ALL ON notitle.admin_users, notitle.admin_sessions, notitle.admin_audit FROM PUBLIC;
GRANT SELECT ON notitle.admin_users TO notitle_app;
GRANT UPDATE(last_counter) ON notitle.admin_users TO notitle_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON notitle.admin_sessions TO notitle_app;
GRANT SELECT, INSERT ON notitle.admin_audit TO notitle_app;
COMMENT ON TABLE notitle.admin_audit IS 'Append-only sensitive access and action audit. Restricted personal data; no runtime UPDATE or DELETE grant.';
COMMENT ON COLUMN notitle.admin_users.totp_ciphertext IS 'AES-256-GCM encrypted TOTP secret; separate mounted MFA key, AAD bound to admin UUID.';
ALTER TABLE notitle.schema_version DROP CONSTRAINT schema_version_version_check;
UPDATE notitle.schema_version SET version = 5 WHERE version = 4;
ALTER TABLE notitle.schema_version ADD CONSTRAINT schema_version_version_check CHECK (version = 5);

-- +goose Down
ALTER TABLE notitle.moderation_actions DROP CONSTRAINT moderation_actions_admin_fk;
DROP TABLE notitle.admin_audit;
DROP TABLE notitle.admin_sessions;
DROP TABLE notitle.admin_users;
ALTER TABLE notitle.schema_version DROP CONSTRAINT schema_version_version_check;
UPDATE notitle.schema_version SET version = 4 WHERE version = 5;
ALTER TABLE notitle.schema_version ADD CONSTRAINT schema_version_version_check CHECK (version = 4);
