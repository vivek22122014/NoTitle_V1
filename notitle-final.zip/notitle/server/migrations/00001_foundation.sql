-- +goose Up
-- Catch accidental use of the administrator or runtime credential.
-- +goose StatementBegin
DO $$
BEGIN
    IF current_user <> 'notitle_migrate' THEN
        RAISE EXCEPTION 'Migrations require the dedicated notitle_migrate role';
    END IF;
END
$$;
-- +goose StatementEnd

CREATE SCHEMA notitle AUTHORIZATION notitle_migrate;
COMMENT ON SCHEMA notitle IS 'Durable foundation only; never store chat content, audio, or matchmaking queues here.';
REVOKE ALL ON SCHEMA notitle FROM PUBLIC;
GRANT USAGE ON SCHEMA notitle TO notitle_app;

CREATE TABLE notitle.schema_version (
    version bigint PRIMARY KEY CHECK (version = 1)
);
INSERT INTO notitle.schema_version (version) VALUES (1);
COMMENT ON TABLE notitle.schema_version IS 'Readiness contract for Phase 1; update deliberately with future migrations.';
REVOKE ALL ON TABLE notitle.schema_version FROM PUBLIC;
GRANT SELECT ON TABLE notitle.schema_version TO notitle_app;
-- Future migrations grant only the operations their runtime tables require.
-- There are deliberately no blanket runtime write/default privileges.

-- +goose Down
DROP TABLE notitle.schema_version;
DROP SCHEMA notitle;
