package health

import (
	"context"
	"encoding/json"
	"net/http"
	"sync/atomic"
	"time"
)

type Checker interface {
	Ready(context.Context) error
}
type Handler struct {
	checks []Checker
	readinessTimeout time.Duration
	draining atomic.Bool
}

func New(readinessTimeout time.Duration, checks ...Checker) *Handler {
	return &Handler{checks: checks, readinessTimeout: readinessTimeout}
}
func (h *Handler) BeginShutdown() {
	h.draining.Store(true)
}
func (h *Handler) Live(w http.ResponseWriter, _ *http.Request) {
	writeStatus(w, http.StatusOK, "ok")
}
func (h *Handler) Ready(w http.ResponseWriter, r *http.Request) {
	if h.draining.Load() || len(h.checks) == 0 {
		writeStatus(w, http.StatusServiceUnavailable, "not_ready")
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), h.readinessTimeout)
	defer cancel()
	for _, check := range h.checks {
		if ctx.Err() != nil || check.Ready(ctx) != nil {
			writeStatus(w, http.StatusServiceUnavailable, "not_ready")
			return
		}
	}
	if h.draining.Load() || ctx.Err() != nil {
		writeStatus(w, http.StatusServiceUnavailable, "not_ready")
		return
	}
	writeStatus(w, http.StatusOK, "ok")
}
func writeStatus(w http.ResponseWriter, status int, value string) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(struct{ Status string `json:"status"` }{Status: value})
}
