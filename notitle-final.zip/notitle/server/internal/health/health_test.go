package health

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

type checkFunc func(context.Context) error
func (f checkFunc) Ready(ctx context.Context) error {
	return f(ctx)
}

func TestLiveDoesNotTouchDependencies(t *testing.T) {
	h := New(time.Second, checkFunc(func(context.Context) error {
		t.Fatal("liveness touched dependency")
		return nil
	}))
	h.BeginShutdown()
	rr := httptest.NewRecorder()
	h.Live(rr, httptest.NewRequest(http.MethodGet, "/health/live", nil))
	if rr.Code != http.StatusOK || rr.Body.String() != "{\"status\":\"ok\"}\n" {
		t.Fatalf("unexpected liveness %d %s", rr.Code, rr.Body)
	}
}

func TestReadyRequiresAllDependenciesAndHidesDetails(t *testing.T) {
	for _, fail := range []int{0, 1} {
		checks := []Checker{
			checkFunc(func(context.Context) error { return nil }),
			checkFunc(func(context.Context) error { return nil }),
		}
		checks[fail] = checkFunc(func(context.Context) error {
			return errors.New("secret database credential")
		})
		h := New(time.Second, checks...)
		rr := httptest.NewRecorder()
		h.Ready(rr, httptest.NewRequest(http.MethodGet, "/health/ready", nil))
		if rr.Code != http.StatusServiceUnavailable || rr.Body.String() != "{\"status\":\"not_ready\"}\n" {
			t.Fatalf("unsafe readiness: %d %s", rr.Code, rr.Body)
		}
	}
}

func TestReadyTimeoutAndShutdown(t *testing.T) {
	h := New(10*time.Millisecond, checkFunc(func(ctx context.Context) error {
		<-ctx.Done()
		return ctx.Err()
	}))
	rr := httptest.NewRecorder()
	h.Ready(rr, httptest.NewRequest(http.MethodGet, "/health/ready", nil))
	if rr.Code != http.StatusServiceUnavailable {
		t.Fatal("timed-out dependency was ready")
	}
	h = New(time.Second, checkFunc(func(context.Context) error { return nil }))
	rr = httptest.NewRecorder()
	h.Ready(rr, httptest.NewRequest(http.MethodGet, "/health/ready", nil))
	if rr.Code != http.StatusOK {
		t.Fatal("healthy dependencies not ready")
	}
	h.BeginShutdown()
	rr = httptest.NewRecorder()
	h.Ready(rr, httptest.NewRequest(http.MethodGet, "/health/ready", nil))
	if rr.Code != http.StatusServiceUnavailable {
		t.Fatal("draining service was ready")
	}
}

func TestReadyWithoutChecksFailsClosed(t *testing.T) {
	h := New(time.Second)
	rr := httptest.NewRecorder()
	h.Ready(rr, httptest.NewRequest(http.MethodGet, "/health/ready", nil))
	if rr.Code != http.StatusServiceUnavailable {
		t.Fatal("empty readiness configuration accepted")
	}
}
