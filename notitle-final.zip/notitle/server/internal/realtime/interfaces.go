package realtime

import (
	"context"
	"time"

	"notitle/internal/identity"
)

type ConnectionRef struct { Handle string; Generation uint64 }
type AttachRequest struct { Auth AuthSnapshot; Takeover bool; Resume *Resume }
type Connection struct { Ref ConnectionRef; Events <-chan ServerEvent; Closed <-chan struct{} }

// Actor is implemented by the ONE coordinator. Methods copy caller-owned data;
// no method performs database/network I/O in the actor loop. Only the actor
// produces events on Connection.Events; a slow consumer closes its connection.
type Actor interface {
	AuthFence(context.Context) (uint64, error)
	Attach(context.Context, AttachRequest) (Connection, error)
	Command(context.Context, ConnectionRef, ClientEnvelope) error
	Detach(context.Context, ConnectionRef, string) error
	Refresh(context.Context, AuthSnapshot) error
	HealthOutage(context.Context, bool) error
}

// Authorizer obtains fresh trusted state outside the owner loop. Implementations
// capture Actor.AuthFence BEFORE reauthenticating principal.TokenHash and reading
// preferences/safety/entitlements. Passing a previously accepted principal is
// not sufficient authorization: its current session must be checked again.
type Authorizer interface { Authorize(context.Context, identity.Principal) (AuthSnapshot, error) }

type PreferenceStore interface {
	GetPreferences(context.Context, identity.Principal) (PreferenceView, error)
	UpdatePreferences(context.Context, identity.Principal, Preferences) (PreferenceView, error)
}

type Clock interface { Now() time.Time }

// RecentPairLookup is a pure snapshot read; never call a database from matching.
type RecentPairLookup func(a, b QueueEntry) (PairHistory, bool)
