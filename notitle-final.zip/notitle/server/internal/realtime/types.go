// Package realtime defines the live protocol and pure shared-pool policy.
// Internal authorization and queue records must never be serialized to peers.
package realtime

import (
	"encoding/json"
	"errors"
	"time"

	"notitle/internal/identity"
 "notitle/internal/audiotypes"
	"notitle/internal/friendtypes"
)

const (
	ProtocolVersion = 1
	MaxFrameBytes = 8 * 1024
 MaxSDPFrameBytes = 64 * 1024
	TicketTTL = 60 * time.Second
	FirstFrameTimeout = 5 * time.Second
	HeartbeatInterval = 20 * time.Second
	DeadConnectionTimeout = 45 * time.Second
	ReconnectGrace = 25 * time.Second
	MatchInterval = 100 * time.Millisecond
	RematchCooldown = 4 * time.Second
	RecentPairTTL = 5 * time.Minute
	OutboundCapacity = 32
	MaxCommandDedupe = 128
	MaxTextCodePoints = 2000
	MaxTextBytes = 6 * 1024
	MaxMessages = 30
	MaxMessageBufferBytes = 64 * 1024
	// Two participants sending once per five seconds produce 8,640 accepted
	// messages in the mandatory six-hour mixed load. Keep their epoch receipts
	// without evicting old IDs or imposing a mid-test artificial send ceiling.
	MaxSendDedupe = 16384
	MaxBlockedIdentities = 4000
	TextBurst = 8
	TextPerSecond = 2
)

type Error struct { Code string; Message string; Retryable bool }
func (e *Error) Error() string { return e.Code }
var (
	ErrProtocol = &Error{"INVALID_EVENT", "This realtime event is not supported.", false}
	ErrVersion = &Error{"UNSUPPORTED_VERSION", "Refresh to use the current realtime version.", false}
	ErrStaleGeneration = &Error{"STALE_GENERATION", "This connection has been replaced.", false}
	ErrStaleEpoch = &Error{"STALE_EPOCH", "This conversation has ended or changed.", false}
	ErrUnavailable = &Error{"NOT_AVAILABLE", "Realtime is temporarily unavailable.", true}
	ErrUnauthorized = &Error{"AUTHENTICATION_REQUIRED", "Your session has ended. Sign in or start again.", false}
	ErrPremiumRequired = &Error{"PREMIUM_REQUIRED", "This preference requires active Premium.", false}
	ErrGenderRequired = &Error{"GENDER_REQUIRED", "Choose Male, Female or Other before searching.", false}
	ErrCapacity = &Error{"CAPACITY_REACHED", "Realtime is full. Please try again shortly.", true}
	ErrRateLimited = &Error{"RATE_LIMITED", "Please wait before trying again.", true}
	ErrTakeoverRequired = &Error{"TAKEOVER_REQUIRED", "Confirm before replacing your other connection.", false}
	ErrBlocked = &Error{"BLOCKED", "This interaction is not available.", false}
	ErrInvalidText = &Error{"INVALID_TEXT", "Use plain text within the 2,000 character and 6 KiB limits, without unsupported controls.", false}
)
func PublicError(err error) *Error { var result *Error; if errors.As(err, &result) { return result }; return ErrUnavailable }

type GenderPreference string
const (
	Everyone GenderPreference = "everyone"
	PreferMale GenderPreference = "male"
	PreferFemale GenderPreference = "female"
	PreferOther GenderPreference = "other"
)
// Empty choices and category NoPreference both contribute zero. Global No
// preference and General Talk disable influence without erasing saved choices.
type CategoryPreference struct { NoPreference bool `json:"no_preference"`; Choices []string `json:"choices"` }
type ProfessionalPreferences struct {
	NoPreference bool `json:"no_preference"`
	Industry CategoryPreference `json:"industry"`
	Profession CategoryPreference `json:"profession"`
	Experience CategoryPreference `json:"experience"`
	Interests CategoryPreference `json:"interests"`
	Topics CategoryPreference `json:"topics"`
}
type Preferences struct {
	Version int64 `json:"version"`
	Gender GenderPreference `json:"gender"`
	Professional ProfessionalPreferences `json:"professional"`
}
type PreferenceView struct {
	Preferences Preferences `json:"preferences"`
	PremiumActive bool `json:"premium_active"`
	PremiumExpiresAt *time.Time `json:"premium_expires_at,omitempty"`
	RequiresEveryoneConfirmation bool `json:"requires_everyone_confirmation"`
}
// Entitlement is trusted server state. There is no client or environment flag
// which grants Premium. Usage fields describe ONLY the current FIFO purchase
// lot. They never cross the wire or identify a peer, conversation or message.
type Entitlement struct {
	Premium bool
	Version int64
	ExpiresAt time.Time
	UsageLotID string
	UsageUntil time.Time
	PaidControlsUsed bool
}
func (e Entitlement) Active(now time.Time) bool { return e.Premium && now.Before(e.ExpiresAt) }

// AuthSnapshot is PRIVATE. Fence is captured before reauthenticating the cookie
// and reading storage, then checked by the coordinator before publication.
// This prevents slow external work from reviving a revoked actor binding.
type AuthSnapshot struct {
	Fence uint64
	Kind identity.Kind
	IdentityID string
	SessionID string
	IdentityGeneration int64
	SessionVerifier identity.Verifier
	Profile identity.Profile
	Preferences Preferences
	Entitlement Entitlement
	SafetyVersion int64
	Restricted bool
	TextEnabled bool
	FriendsEnabled bool
 AudioEnabled bool
	FriendRevision int64
	FriendLinks []friendtypes.Relation
	BlockedIdentities []string
	ValidUntil time.Time
	AuthorizedAt time.Time
}
func (AuthSnapshot) MarshalJSON() ([]byte, error) { return nil, errors.New("private authorization cannot be serialized") }
type ParticipantState string
const (
	Offline ParticipantState = "OFFLINE"
	Idle ParticipantState = "IDLE"
	Waiting ParticipantState = "WAITING"
	Reserved ParticipantState = "RESERVED"
	Matched ParticipantState = "MATCHED"
)
// QueueEntry never crosses the wire. IdentityID and SlotID are private keys.
type QueueEntry struct {
	SlotID string
	Auth AuthSnapshot
	QueuedAt time.Time
	Connected bool
	Available bool
	TieBreak uint64
}
func (QueueEntry) MarshalJSON() ([]byte, error) { return nil, errors.New("private queue state cannot be serialized") }
type PairHistory struct { EndedAt time.Time; Skips []time.Time }
type Resume struct {
	Token string `json:"token"`
	ServerInstance string `json:"server_instance"`
	Generation uint64 `json:"generation"`
	InteractionID string `json:"interaction_id,omitempty"`
	Epoch uint64 `json:"epoch,omitempty"`
}
type AuthenticatePayload struct {
	Ticket string `json:"ticket"`
	Takeover bool `json:"takeover"`
	Resume *Resume `json:"resume,omitempty"`
}
// This explicit one-search override retains saved strict preferences on expiry.
// Absence/false does not authorize automatic relaxation to Everyone.
type QueueJoinPayload struct { ContinueWithEveryone bool `json:"continue_with_everyone,omitempty"` }
type ClientEnvelope struct {
	V int `json:"v"`
	ID string `json:"id"`
	Type string `json:"type"`
	Generation uint64 `json:"generation"`
	InteractionID string `json:"interaction_id,omitempty"`
	Epoch uint64 `json:"epoch,omitempty"`
	Payload json.RawMessage `json:"payload"`
}
type ServerEvent struct {
	V int `json:"v"`
	ID string `json:"id"`
	Type string `json:"type"`
	Generation uint64 `json:"generation"`
	InteractionID string `json:"interaction_id,omitempty"`
	Epoch uint64 `json:"epoch,omitempty"`
	ReplyTo string `json:"reply_to,omitempty"`
	Payload any `json:"payload"`
}
type ErrorPayload struct { Code string `json:"code"`; Message string `json:"message"`; Retryable bool `json:"retryable"` }
type StatusPayload struct { Reason string `json:"reason,omitempty"` }
type InteractionView struct {
	Kind string `json:"kind"`
	FriendRef string `json:"friend_ref,omitempty"`
	ID string `json:"id"`
	Epoch uint64 `json:"epoch"`
	Peer identity.PublicPeer `json:"peer"`
	OwnTopic string `json:"own_topic"`
	PeerConnected bool `json:"peer_connected"`
	ReconnectUntil *time.Time `json:"reconnect_until,omitempty"`
}
type StateSnapshot struct {
	Maintenance *MaintenanceView `json:"maintenance,omitempty"`
	State ParticipantState `json:"state"`
	ServerInstance string `json:"server_instance"`
	ResumeToken string `json:"resume_token"`
	Generation uint64 `json:"generation"`
	Interaction *InteractionView `json:"interaction,omitempty"`
	QueuedAt *time.Time `json:"queued_at,omitempty"`
	Reason string `json:"reason,omitempty"`
	RepeatAdvisory bool `json:"repeat_advisory,omitempty"`
	HeartbeatSeconds int `json:"heartbeat_seconds"`
	ReconnectSeconds int `json:"reconnect_seconds"`
	TextEnabled bool `json:"text_enabled"`
	FriendsEnabled bool `json:"friends_enabled"`
	PremiumActive bool `json:"premium_active"`
	PremiumExpiresAt *time.Time `json:"premium_expires_at,omitempty"`
	RequiresEveryoneConfirmation bool `json:"requires_everyone_confirmation"`
 AudioEnabled bool `json:"audio_enabled"`
 Call *audiotypes.View `json:"call,omitempty"`
	FriendRequest *friendtypes.RequestView `json:"friend_request,omitempty"`
	FriendInvitations []friendtypes.InvitationView `json:"friend_invitations"`
	EndedReportRef string `json:"ended_report_ref,omitempty"`
	EndedReportExpiresAt *time.Time `json:"ended_report_expires_at,omitempty"`
}
// Maintenance is server-owned admission state. A deadline does not revoke
// report/block or existing text/audio before the planned drain completes.
type MaintenanceView struct { Deadline time.Time `json:"deadline"` }
type TicketResponse struct { Ticket string `json:"ticket"`; ExpiresAt time.Time `json:"expires_at"`; ProtocolVersion int `json:"protocol_version"` }

// ClientSendID remains stable across retry/reconnect; the transport envelope ID
// can change. Its scope is one sender in one interaction epoch, never a new
// conversation. The coordinator owns server sequence assignment.
type ChatSend struct { ClientSendID string `json:"client_send_id"`; Text string `json:"text"` }
type ChatDeliveryAck struct { ServerSequence uint64 `json:"server_sequence"` }
type ChatMessage struct {
	ServerSequence uint64 `json:"server_sequence"`
	ClientSendID string `json:"client_send_id"`
	Sender string `json:"sender"` // self or peer; never a subject ID
	Text string `json:"text"`
	SentAt time.Time `json:"sent_at"`
	Delivered bool `json:"delivered"`
	Replay bool `json:"replay"`
}
type ChatAck struct { ClientSendID string `json:"client_send_id"`; ServerSequence uint64 `json:"server_sequence"`; Status string `json:"status"` }

// Friend commands never accept account IDs, peer identities or consent flags.
// RequestRef belongs only to the current interaction; accepted relationship
// and invitation refs are scoped again to the authenticated owner.
type FriendResponse struct { RequestRef string `json:"request_ref"` }
type FriendInvite struct { FriendRef string `json:"friend_ref"`; Kind string `json:"kind"` }
type FriendInviteResponse struct { InvitationRef string `json:"invitation_ref"` }
type FriendCreated struct { Friend friendtypes.View `json:"friend"` }
type FriendRemoved struct { FriendRef string `json:"friend_ref"` }
type FriendRequestClosed struct { RequestRef string `json:"request_ref"` }
type FriendInvitationClosed struct { InvitationRef string `json:"invitation_ref"`; Reason string `json:"reason"` }
type FriendPresence struct { FriendRef string `json:"friend_ref"`; Presence friendtypes.Presence `json:"presence"` }
