package realtime

import (
	"encoding/json"
	"os"
	"strings"
	"testing"
)

func TestRecordedSyntheticProtocolFixtures(t *testing.T) {
	data, err := os.ReadFile("testdata/protocol-v1.json")
	if err != nil { t.Fatal(err) }
	var fixtures []struct { Name string `json:"name"`; Wire string `json:"wire"`; Error string `json:"error"` }
	if err := json.Unmarshal(data, &fixtures); err != nil { t.Fatal(err) }
	for _, fixture := range fixtures {
		t.Run(fixture.Name, func(t *testing.T) {
			_, err := DecodeEnvelope([]byte(fixture.Wire))
			code := ""
			if err != nil { code = PublicError(err).Code }
			if code != fixture.Error { t.Fatalf("got %q, want %q", code, fixture.Error) }
		})
	}
}

func TestAllowedPhase4Envelopes(t *testing.T) {
	for _, input:=range []string{
		`{"v":1,"id":"a","type":"session.authenticate","generation":0,"payload":{"ticket":"abcdefghijklmnopqrstuvwxyz1234567890","takeover":false}}`,
		`{"v":1,"id":"a","type":"session.authenticate","generation":0,"payload":{"ticket":"abcdefghijklmnopqrstuvwxyz1234567890","resume":{"token":"abcdefghijklmnopqrstuvwxyz1234567890","server_instance":"instance","generation":2,"interaction_id":"interaction","epoch":2}}}`,
		`{"v":1,"id":"a","type":"queue.join","generation":1,"payload":{}}`,
		`{"v":1,"id":"a","type":"queue.join","generation":1,"payload":{"continue_with_everyone":true}}`,
		`{"v":1,"id":"a","type":"queue.leave","generation":1,"payload":{}}`,
		`{"v":1,"id":"a","type":"match.next","generation":1,"interaction_id":"interaction","epoch":1,"payload":{}}`,
		`{"v":1,"id":"a","type":"match.end","generation":1,"interaction_id":"interaction","epoch":1,"payload":{}}`,
		`{"v":1,"id":"a","type":"heartbeat","generation":1,"payload":{}}`,
		`{"v":1,"id":"a","type":"state.sync","generation":1,"payload":{}}`,
	} { if _,err:=DecodeEnvelope([]byte(input));err!=nil {t.Fatalf("valid event rejected: %s: %v",input,err)} }
}

func TestRejectMalformedOrUnauthorizedEnvelopeShapes(t *testing.T) {
	for _, input:=range []string{
		`null`, `[]`, `{}`, `{"v":1}`, `{"v":1} {"v":1}`,
		`{"v":2,"id":"a","type":"queue.join","generation":1,"payload":{}}`,
		`{"v":1,"id":"a","type":"queue.join","generation":0,"payload":{}}`,
		`{"v":1,"id":"a","type":"queue.join","generation":1,"payload":null}`,
		`{"v":1,"id":"a","type":"queue.join","generation":1,"payload":[]}`,
		`{"v":1,"id":"a","type":"queue.join","generation":1,"payload":{"continue_with_everyone":null}}`,
		`{"v":1,"id":"a","type":"queue.join","generation":1,"payload":{"premium":true}}`,
		`{"v":1,"id":"a","type":"queue.join","generation":1,"peer":"chosen","payload":{}}`,
		`{"v":1,"id":"a","id":"b","type":"queue.join","generation":1,"payload":{}}`,
		`{"v":1,"V":1,"id":"a","type":"queue.join","generation":1,"payload":{}}`,
		`{"v":1,"id":"a","type":"queue.join","generation":1,"payload":{"Continue_With_Everyone":true}}`,
		`{"v":1,"id":"a","type":"queue.join","generation":1,"payload":{"continue_with_everyone":true,"continue_with_everyone":false}}`,
		`{"v":1,"id":"a","type":"match.next","generation":1,"payload":{}}`,
		`{"v":1,"id":"a","type":"match.end","generation":1,"interaction_id":"interaction","epoch":0,"payload":{}}`,
		`{"v":1,"id":"a","type":"queue.leave","generation":1,"interaction_id":"interaction","epoch":1,"payload":{}}`,
		`{"v":1,"id":"a","type":"chat.send","generation":1,"interaction_id":"interaction","epoch":1,"payload":{"text":"no"}}`,
		`{"v":1,"id":"a","type":"friend.request","generation":1,"payload":{}}`,
		`{"v":1,"id":"a","type":"session.authenticate","payload":{"ticket":"abcdefghijklmnopqrstuvwxyz1234567890"}}`,
		`{"v":1,"id":"a","type":"session.authenticate","generation":null,"payload":{"ticket":"abcdefghijklmnopqrstuvwxyz1234567890"}}`,
		`{"v":1,"id":"a","type":"session.authenticate","generation":0,"payload":{"ticket":"abcdefghijklmnopqrstuvwxyz1234567890","takeover":null}}`,
		`{"v":1,"id":"a","type":"session.authenticate","generation":0,"payload":{"ticket":"abcdefghijklmnopqrstuvwxyz1234567890","Takeover":true}}`,
		`{"v":1,"id":"a","type":"session.authenticate","generation":0,"payload":{"ticket":"short"}}`,
		`{"v":1,"id":"a","type":"session.authenticate","generation":1,"payload":{"ticket":"abcdefghijklmnopqrstuvwxyz1234567890"}}`,
		`{"v":1,"id":"a","type":"session.authenticate","generation":0,"payload":{"ticket":"abcdefghijklmnopqrstuvwxyz1234567890","takeover":true,"resume":{"token":"abcdefghijklmnopqrstuvwxyz1234567890","server_instance":"instance","generation":2}}}`,
		`{"v":1,"id":"a","type":"session.authenticate","generation":0,"payload":{"ticket":"abcdefghijklmnopqrstuvwxyz1234567890","resume":{"token":"abcdefghijklmnopqrstuvwxyz1234567890","server_instance":"instance","generation":2,"epoch":1}}}`,
	} { if _,err:=DecodeEnvelope([]byte(input));err==nil {t.Fatalf("invalid event accepted: %s",input)} }
	if _,err:=DecodeEnvelope([]byte(strings.Repeat(" ",MaxFrameBytes+1)));err==nil{t.Fatal("oversized frame accepted")}
	if _,err:=DecodeEnvelope([]byte{'{',0xff,'}'});err==nil{t.Fatal("invalid UTF-8 accepted")}
}

func TestDecodeQueueJoinRetainsExplicitOverride(t *testing.T) {
	event,err:=DecodeEnvelope([]byte(`{"v":1,"id":"a","type":"queue.join","generation":7,"payload":{"continue_with_everyone":true}}`))
	if err!=nil{t.Fatal(err)}
	payload,err:=DecodeQueueJoin(event)
	if err!=nil||!payload.ContinueWithEveryone{t.Fatal("explicit consent was lost")}
}

func FuzzEnvelopeDecode(f *testing.F) {
	f.Add([]byte(`{"v":1,"id":"a","type":"queue.join","generation":1,"payload":{}}`))
	f.Add([]byte(`{"v":1,"id":"a","type":"match.end","generation":1,"interaction_id":"interaction","epoch":1,"payload":{}}`))
	f.Add([]byte(`{"v":1,"id":"a","type":"session.authenticate","generation":0,"payload":{"ticket":"abcdefghijklmnopqrstuvwxyz1234567890"}}`))
	f.Add([]byte(`{"v":1,"v":2}`))
	f.Fuzz(func(t *testing.T,data []byte){
		event,err:=DecodeEnvelope(data);if err!=nil{return}
		if event.V!=ProtocolVersion||len(data)>FrameLimit(event.Type)||event.ID==""{t.Fatal("accepted event broke envelope invariant")}
		roundtrip,err:=json.Marshal(event);if err!=nil{t.Fatal(err)}
		if _,err=DecodeEnvelope(roundtrip);err!=nil{t.Fatalf("accepted event failed normalized decode: %v",err)}
	})
}
