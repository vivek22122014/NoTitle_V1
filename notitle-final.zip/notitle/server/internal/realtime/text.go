package realtime

import (
	"bytes"
	"encoding/json"
	"strings"
	"unicode"
	"unicode/utf8"
)

func DecodeChatSend(event ClientEnvelope) (ChatSend, error) {
	var payload ChatSend
	if event.Type != "chat.send" || !validObject(event.Payload) || decodeStrict(event.Payload, &payload) != nil { return payload, ErrProtocol }
	var fields map[string]json.RawMessage
	if json.Unmarshal(event.Payload, &fields) != nil || !allowedFields(fields, "client_send_id", "text") || len(fields) != 2 || !wireID.MatchString(payload.ClientSendID) || len(payload.ClientSendID) > 64 { return payload, ErrProtocol }
	if err := ValidateText(payload.Text); err != nil { return payload, err }
	return payload, nil
}

func DecodeChatDeliveryAck(event ClientEnvelope) (ChatDeliveryAck, error) {
	var payload ChatDeliveryAck
	if event.Type != "chat.delivery_ack" || !validObject(event.Payload) || decodeStrict(event.Payload, &payload) != nil { return payload, ErrProtocol }
	var fields map[string]json.RawMessage
	if json.Unmarshal(event.Payload, &fields) != nil || !allowedFields(fields, "server_sequence") || len(fields) != 1 || payload.ServerSequence == 0 { return payload, ErrProtocol }
	return payload, nil
}

// ValidateText rejects rather than normalizes. Newlines, normal RTL letters,
// emoji joiners and variation selectors retain their original meaning. Format
// controls (including bidi overrides/isolates) are forbidden, except ZWNJ/ZWJ
// needed by ordinary writing and compound emoji. Rendering must use text nodes.
func ValidateText(value string) error {
	if !utf8.ValidString(value) || len(value) == 0 || len(value) > MaxTextBytes || utf8.RuneCountInString(value) > MaxTextCodePoints || strings.TrimSpace(value) == "" { return ErrInvalidText }
	for _, char := range value {
		if char == '\n' || char == '\u200C' || char == '\u200D' { continue }
		if unicode.IsControl(char) || unicode.In(char, unicode.Cf) { return ErrInvalidText }
	}
	// U+2028/2029 must be escaped by Go's JSON encoder even with HTML escaping
	// disabled. Bound their expansion before accepting a message, reserving at
	// least 1 KiB for the envelope, timestamp and IDs within the 8 KiB frame.
	var wire bytes.Buffer
	encoder := json.NewEncoder(&wire)
	encoder.SetEscapeHTML(false)
	if encoder.Encode(value) != nil || wire.Len() > MaxFrameBytes - 1024 { return ErrInvalidText }
	return nil
}
