package realtime

import (
	"encoding/json"
	"fmt"
	"math"
	"testing"
	"time"

	"notitle/internal/identity"
)

var policyNow = time.Date(2026, 10, 9, 12, 0, 0, 0, time.UTC)

func participant(id, tier string, gender identity.Gender, age time.Duration) QueueEntry {
	kind := identity.KindAccount
	if tier == "guest" { kind = identity.KindGuest }
	return QueueEntry{SlotID: "slot-" + id, QueuedAt: policyNow.Add(-age), Connected: true, Available: true, Auth: AuthSnapshot{
		Kind: kind, IdentityID: id, SessionID: "session-" + id, IdentityGeneration: 1,
		Profile: identity.Profile{Version: 1, DisplayName: "Person", Gender: gender, Topic: "general_talk"},
		Preferences: DefaultPreferences(), Entitlement: Entitlement{Premium: tier == "premium", ExpiresAt: policyNow.Add(time.Hour)},
		ValidUntil: policyNow.Add(time.Minute),
	}}
}

func TestEveryTierAndMutualGenderCombination(t *testing.T) {
	genders := []identity.Gender{identity.GenderMale, identity.GenderFemale, identity.GenderOther}
	preferences := []GenderPreference{Everyone, PreferMale, PreferFemale, PreferOther}
	for _, tierA := range []string{"guest", "free", "premium"} {
		for _, tierB := range []string{"guest", "free", "premium"} {
			for _, genderA := range genders {
				for _, genderB := range genders {
					for _, preferenceA := range preferences {
						for _, preferenceB := range preferences {
							name := fmt.Sprintf("%s_%s_%s_%s_%s_%s", tierA, tierB, genderA, genderB, preferenceA, preferenceB)
							t.Run(name, func(t *testing.T) {
								a := participant("a", tierA, genderA, time.Second)
								b := participant("b", tierB, genderB, 0)
								a.Auth.Preferences.Gender, b.Auth.Preferences.Gender = preferenceA, preferenceB
								want := (preferenceA == Everyone || tierA == "premium") && (preferenceB == Everyone || tierB == "premium") &&
									(preferenceA == Everyone || string(preferenceA) == string(genderB)) && (preferenceB == Everyone || string(preferenceB) == string(genderA))
								if got := HardCompatible(a, b, policyNow, PairHistory{}); got != want { t.Fatalf("got %v, want %v", got, want) }
							})
						}
					}
				}
			}
		}
	}
}

func TestHardSafetyExpiryAndMissingGender(t *testing.T) {
	baseA := participant("a", "premium", identity.GenderMale, time.Second)
	baseB := participant("b", "free", identity.GenderFemale, 0)
	for _, test := range []struct { name string; change func(*QueueEntry, *QueueEntry) }{
		{"missing gender", func(a, b *QueueEntry) { a.Auth.Profile.Gender = "" }},
		{"invalid gender", func(a, b *QueueEntry) { b.Auth.Profile.Gender = "unknown" }},
		{"blocked forward", func(a, b *QueueEntry) { a.Auth.BlockedIdentities = []string{b.Auth.IdentityID} }},
		{"blocked reverse", func(a, b *QueueEntry) { b.Auth.BlockedIdentities = []string{a.Auth.IdentityID} }},
		{"restricted", func(a, b *QueueEntry) { b.Auth.Restricted = true }},
		{"offline", func(a, b *QueueEntry) { b.Connected = false }},
		{"already owned", func(a, b *QueueEntry) { a.Available = false }},
		{"same slot", func(a, b *QueueEntry) { b.SlotID = a.SlotID }},
		{"same account", func(a, b *QueueEntry) { b.Auth.IdentityID = a.Auth.IdentityID }},
		{"expired authority", func(a, b *QueueEntry) { a.Auth.ValidUntil = policyNow }},
		{"expired strict", func(a, b *QueueEntry) { a.Auth.Preferences.Gender = PreferFemale; a.Auth.Entitlement.ExpiresAt = policyNow }},
		{"forged guest premium", func(a, b *QueueEntry) { a.Auth.Kind = identity.KindGuest; a.Auth.Preferences.Gender = PreferFemale }},
	} {
		t.Run(test.name, func(t *testing.T) { a, b := CloneAuthorization(baseA.Auth), CloneAuthorization(baseB.Auth); left, right := baseA, baseB; left.Auth, right.Auth = a, b; test.change(&left, &right); if HardCompatible(left, right, policyNow, PairHistory{}) { t.Fatal("unsafe pair accepted") } })
	}
	baseA.Auth.Entitlement.ExpiresAt = policyNow
	if !HardCompatible(baseA, baseB, policyNow, PairHistory{}) { t.Fatal("Everyone should remain compatible when paid ranking expires") }
}

func fullProfessional(entry *QueueEntry) {
	entry.Auth.Profile.Topic = "career_growth"
	entry.Auth.Profile.Professional = identity.ProfessionalProfile{Profession: "engineering", Industry: "technology", Experience: "3_5", Interests: []string{"leadership", "learning_skills"}}
	p := &entry.Auth.Preferences.Professional
	p.NoPreference = false
	p.Profession = CategoryPreference{Choices: []string{"engineering", "design"}}
	p.Industry = CategoryPreference{Choices: []string{"technology"}}
	p.Experience = CategoryPreference{Choices: []string{"3_5"}}
	p.Interests = CategoryPreference{Choices: []string{"leadership", "learning_skills"}}
	p.Topics = CategoryPreference{Choices: []string{"career_growth"}}
}

func closeTo(t *testing.T, got, want float64) { t.Helper(); if math.Abs(got - want) > 1e-10 { t.Fatalf("got %.12f, want %.12f", got, want) } }

func TestBonusCapsORAndFiveSecondDecay(t *testing.T) {
	a := participant("a", "premium", identity.GenderOther, 0)
	b := participant("b", "premium", identity.GenderFemale, 0)
	fullProfessional(&a); fullProfessional(&b)
	topic, professional := RelevanceBonuses(a, b, policyNow)
	closeTo(t, topic, .5); closeTo(t, professional, .5)
	a.QueuedAt = policyNow.Add(-2500 * time.Millisecond)
	topic, professional = RelevanceBonuses(a, b, policyNow)
	closeTo(t, topic, .25); closeTo(t, professional, .25)
	for _, age := range []time.Duration{5*time.Second, time.Hour} {
		a.QueuedAt = policyNow.Add(-age)
		topic, professional = RelevanceBonuses(a, b, policyNow)
		closeTo(t, topic, 0); closeTo(t, professional, 0)
	}
	a.QueuedAt = policyNow
	b.Auth.Preferences.Professional.NoPreference = true
	a.Auth.Preferences.Professional = ProfessionalPreferences{Profession: CategoryPreference{Choices: []string{"finance", "engineering"}}}
	_, professional = RelevanceBonuses(a, b, policyNow)
	closeTo(t, professional, .05) // One category is not normalized into a large bonus.
	a.Auth.Preferences.Professional = ProfessionalPreferences{Interests: CategoryPreference{Choices: []string{"leadership", "entrepreneurship"}}}
	_, professional = RelevanceBonuses(a, b, policyNow)
	closeTo(t, professional, .025) // One of two requested interests, one paid direction.
}

func TestNoPreferenceUnknownAndGeneralTalkContributeZero(t *testing.T) {
	for _, test := range []struct { name string; change func(*QueueEntry, *QueueEntry) }{
		{"global none", func(a, b *QueueEntry) { a.Auth.Preferences.Professional.NoPreference = true; b.Auth.Preferences.Professional.NoPreference = true }},
		{"categories none", func(a, b *QueueEntry) {
			for _, entry := range []*QueueEntry{a,b} { p:= &entry.Auth.Preferences.Professional; p.Industry.NoPreference=true; p.Profession.NoPreference=true; p.Experience.NoPreference=true; p.Interests.NoPreference=true; p.Topics.NoPreference=true }
		}},
		{"general talk", func(a, b *QueueEntry) { a.Auth.Profile.Topic = "general_talk" }},
		{"free and guest", func(a, b *QueueEntry) { a.Auth.Entitlement.Premium = false; b.Auth.Kind = identity.KindGuest }},
		{"expired", func(a, b *QueueEntry) { a.Auth.Entitlement.ExpiresAt = policyNow; b.Auth.Entitlement.ExpiresAt = policyNow }},
		{"unknown and missing", func(a, b *QueueEntry) { a.Auth.Profile.Professional=identity.ProfessionalProfile{}; b.Auth.Profile.Professional=identity.ProfessionalProfile{Profession:"unknown"}; a.Auth.Profile.Topic="work_culture"; b.Auth.Profile.Topic="managers" }},
	} {
		t.Run(test.name, func(t *testing.T) { a:=participant("a","premium",identity.GenderMale,0); b:=participant("b","premium",identity.GenderFemale,0); fullProfessional(&a); fullProfessional(&b); test.change(&a,&b); _, professional:=RelevanceBonuses(a,b,policyNow); closeTo(t,professional,0); if !HardCompatible(a,b,policyNow,PairHistory{}) { t.Fatal("soft preferences became a hard filter") } })
	}
}

func TestImmediateZeroOverlapAndConstrainedAnchorDoesNotBlock(t *testing.T) {
	a:=participant("a","premium",identity.GenderMale,30*time.Second)
	a.Auth.Preferences.Gender=PreferOther // Nobody declares Other; this oldest entry cannot monopolize matching.
	b:=participant("b","free",identity.GenderMale,time.Second)
	c:=participant("c","premium",identity.GenderFemale,0)
	fullProfessional(&c)
	pair,ok:=SelectPair([]QueueEntry{c,a,b},policyNow,nil)
	if !ok || pair.Anchor.SlotID!=b.SlotID || pair.Candidate.SlotID!=c.SlotID { t.Fatalf("expected immediate unrelated pair, got %#v %v",pair,ok) }
	b.Auth.Profile.Professional.Profession="finance"
	c.Auth.Preferences.Gender=PreferMale
	pair,ok=SelectPair([]QueueEntry{b,c},policyNow,nil)
	if !ok { t.Fatal("zero professional overlap delayed an eligible pair") }
}

func TestUncappedWaitingAndRandomFinalTie(t *testing.T) {
	a:=participant("anchor","free",identity.GenderMale,1000*time.Second)
	b:=participant("older","free",identity.GenderFemale,800*time.Second)
	c:=participant("younger","free",identity.GenderOther,700*time.Second)
	lookup:=func(a,b QueueEntry)(PairHistory,bool) { if b.SlotID=="slot-older" { return PairHistory{EndedAt:policyNow.Add(-4*time.Second)},true }; return PairHistory{},false }
	pair,ok:=SelectPair([]QueueEntry{c,b,a},policyNow,lookup)
	if !ok || pair.Anchor.SlotID!=a.SlotID || pair.Candidate.SlotID!=b.SlotID { t.Fatal("waiting age was capped or oldest feasible anchor ignored") }
	b.QueuedAt,c.QueuedAt=policyNow,policyNow
	b.TieBreak,c.TieBreak=10,1
	pair,ok=SelectPair([]QueueEntry{b,c,a},policyNow,nil)
	if !ok || pair.Candidate.SlotID!=c.SlotID { t.Fatal("final tie did not use server tie value") }
}

func TestProfessionalInfluenceCannotJumpHalfSecondOlderCandidate(t *testing.T) {
	a:=participant("anchor","premium",identity.GenderMale,2*time.Second)
	b:=participant("newer","premium",identity.GenderFemale,0)
	c:=participant("older","free",identity.GenderOther,501*time.Millisecond)
	fullProfessional(&a); fullProfessional(&b)
	c.Auth.Profile.Topic=a.Auth.Profile.Topic
	pair,ok:=SelectPair([]QueueEntry{a,b,c},policyNow,nil)
	if !ok || pair.Candidate.SlotID!=c.SlotID { t.Fatal("professional preference displaced a >0.5 second older candidate") }
}

func TestRematchBoundaryPenaltyAndExpiry(t *testing.T) {
	a:=participant("a","guest",identity.GenderOther,time.Second)
	b:=participant("b","free",identity.GenderFemale,0)
	for _, elapsed:=range []time.Duration{0,3999*time.Millisecond,4*time.Second,14*time.Second,5*time.Minute} {
		prior:=PairHistory{EndedAt:policyNow.Add(-elapsed)}
		want:=elapsed>=4*time.Second
		if HardCompatible(a,b,policyNow,prior)!=want { t.Fatalf("wrong cooldown boundary at %s",elapsed) }
		_,ok:=SelectPair([]QueueEntry{a,b},policyNow,func(a,b QueueEntry)(PairHistory,bool){return prior,true})
		if ok!=want { t.Fatalf("sole compatible rematch was delayed at %s",elapsed) }
	}
	closeTo(t,RecentPairPenalty(PairHistory{EndedAt:policyNow.Add(-4*time.Second)},policyNow),60)
	closeTo(t,RecentPairPenalty(PairHistory{EndedAt:policyNow.Add(-14*time.Second)},policyNow),60/math.E)
	closeTo(t,RecentPairPenalty(PairHistory{EndedAt:policyNow.Add(-5*time.Minute)},policyNow),0)
}

func TestPreferenceValidationAndCopyIsolation(t *testing.T) {
	p:=DefaultPreferences()
	if ValidatePreferences(p)!=nil || RequiresPremium(p) { t.Fatal("No preference defaults are not free") }
	p.Professional.Profession=CategoryPreference{Choices:[]string{"engineering","design"}}
	if RequiresPremium(p) { t.Fatal("globally inactive saved choices became active") }
	p.Professional.NoPreference=false
	if !RequiresPremium(p) || ValidatePreferences(p)!=nil { t.Fatal("active OR choices not recognized") }
	copy:=ClonePreferences(p); copy.Professional.Profession.Choices[0]="finance"
	if p.Professional.Profession.Choices[0]!="engineering" { t.Fatal("preference slices alias owner state") }
	for _, choices:=range [][]string{{""},{"unknown"},{"engineering","engineering"},{"engineering","design","data","hr","finance","legal"}} {
		copy=ClonePreferences(p); copy.Professional.Profession.Choices=choices
		if ValidatePreferences(copy)==nil { t.Fatalf("invalid category accepted: %#v",choices) }
	}
	for _, gender:=range []GenderPreference{"","unknown"} { copy=ClonePreferences(p); copy.Gender=gender; if ValidatePreferences(copy)==nil { t.Fatal("invalid gender preference accepted") } }
}

func TestPrivateRecordsCannotSerializeAndPeerProjectionIsAllowlisted(t *testing.T) {
	a:=participant("private-account-id","free",identity.GenderOther,0)
	for _, value:=range []any{a.Auth,a} { if _,err:=json.Marshal(value);err==nil { t.Fatal("private record was serializable") } }
	payload,err:=json.Marshal(a.Auth.Profile.PublicPeer());if err!=nil {t.Fatal(err)}
	var fields map[string]any;if err=json.Unmarshal(payload,&fields);err!=nil{t.Fatal(err)}
	if len(fields)!=4 {t.Fatalf("unexpected peer fields: %s",payload)}
	for _,key:=range []string{"display_name","gender","bio","topic"} {if _,ok:=fields[key];!ok{t.Fatalf("missing peer field %s",key)}}
}
