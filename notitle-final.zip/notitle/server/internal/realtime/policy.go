package realtime

import (
	"math"
	"sort"
	"time"

	"notitle/internal/identity"
)

func DefaultPreferences() Preferences {
	none := CategoryPreference{NoPreference: true, Choices: []string{}}
	return Preferences{Version: 1, Gender: Everyone, Professional: ProfessionalPreferences{
		NoPreference: true, Industry: none, Profession: none, Experience: none, Interests: none, Topics: none,
	}}
}

func ClonePreferences(p Preferences) Preferences {
	p.Professional.Industry.Choices = append([]string{}, p.Professional.Industry.Choices...)
	p.Professional.Profession.Choices = append([]string{}, p.Professional.Profession.Choices...)
	p.Professional.Experience.Choices = append([]string{}, p.Professional.Experience.Choices...)
	p.Professional.Interests.Choices = append([]string{}, p.Professional.Interests.Choices...)
	p.Professional.Topics.Choices = append([]string{}, p.Professional.Topics.Choices...)
	return p
}

func CloneAuthorization(a AuthSnapshot) AuthSnapshot {
	a.Profile.Professional.Interests = append([]string{}, a.Profile.Professional.Interests...)
	a.Preferences = ClonePreferences(a.Preferences)
	a.BlockedIdentities = append([]string{}, a.BlockedIdentities...)
	return a
}

func ValidatePreferences(p Preferences) error {
	if p.Version < 1 || !validPreference(p.Gender) { return ErrProtocol }
	v := identity.Vocabularies()
	for _, field := range []struct { value CategoryPreference; vocabulary []identity.Choice; max int }{
		{p.Professional.Industry, v.Industries, 5}, {p.Professional.Profession, v.Professions, 5},
		{p.Professional.Experience, v.Experience, 5}, {p.Professional.Interests, v.Interests, 10},
		{p.Professional.Topics, v.Topics, 5},
	} {
		if len(field.value.Choices) > field.max { return ErrProtocol }
		seen := make(map[string]bool, len(field.value.Choices))
		for _, selected := range field.value.Choices {
			if selected == "" || seen[selected] { return ErrProtocol }
			seen[selected] = true
			found := false
			for _, allowed := range field.vocabulary { if allowed.Value == selected { found = true; break } }
			if !found { return ErrProtocol }
		}
	}
	return nil
}

func RequiresPremium(p Preferences) bool {
	if p.Gender != Everyone { return true }
	if p.Professional.NoPreference { return false }
	for _, category := range []CategoryPreference{p.Professional.Industry, p.Professional.Profession, p.Professional.Experience, p.Professional.Interests, p.Professional.Topics} {
		if !category.NoPreference && len(category.Choices) > 0 { return true }
	}
	return false
}

func validPreference(p GenderPreference) bool { return p == Everyone || p == PreferMale || p == PreferFemale || p == PreferOther }
func validGender(g identity.Gender) bool { return g == identity.GenderMale || g == identity.GenderFemale || g == identity.GenderOther }
func accepts(p GenderPreference, g identity.Gender) bool { return p == Everyone || string(p) == string(g) }
func premium(a AuthSnapshot, now time.Time) bool { return a.Kind == identity.KindAccount && a.Entitlement.Active(now) }
func blocked(a, b AuthSnapshot) bool {
	for _, id := range a.BlockedIdentities { if id == b.IdentityID { return true } }
	return false
}

// HardCompatible checks current snapshots, not just index membership. The owner
// must call it again after reserving both slots immediately before commit.
func HardCompatible(a, b QueueEntry, now time.Time, prior PairHistory) bool {
	if !a.Connected || !b.Connected || !a.Available || !b.Available || a.SlotID == "" || a.SlotID == b.SlotID { return false }
	if a.Auth.IdentityID == "" || b.Auth.IdentityID == "" || (a.Auth.Kind == b.Auth.Kind && a.Auth.IdentityID == b.Auth.IdentityID) { return false }
	for _, entry := range []QueueEntry{a, b} {
		auth := entry.Auth
		if !validGender(auth.Profile.Gender) || !validPreference(auth.Preferences.Gender) || auth.Restricted || !now.Before(auth.ValidUntil) { return false }
		if auth.Kind != identity.KindGuest && auth.Kind != identity.KindAccount { return false }
		if auth.Preferences.Gender != Everyone && !premium(auth, now) { return false }
	}
	if blocked(a.Auth, b.Auth) || blocked(b.Auth, a.Auth) { return false }
	if !accepts(a.Auth.Preferences.Gender, b.Auth.Profile.Gender) || !accepts(b.Auth.Preferences.Gender, a.Auth.Profile.Gender) { return false }
	return prior.EndedAt.IsZero() || now.Sub(prior.EndedAt) >= RematchCooldown
}

func waitingSeconds(entry QueueEntry, now time.Time) float64 { return math.Max(0, now.Sub(entry.QueuedAt).Seconds()) }

func RecentPairPenalty(prior PairHistory, now time.Time) float64 {
	if prior.EndedAt.IsZero() { return 0 }
	age := now.Sub(prior.EndedAt)
	if age >= RecentPairTTL { return 0 }
	if age < RematchCooldown { return math.Inf(1) }
	return 60 * math.Exp(-(age.Seconds() - RematchCooldown.Seconds()) / 10)
}

func categoryMatch(category CategoryPreference, actual string) float64 {
	if category.NoPreference || actual == "" { return 0 }
	for _, value := range category.Choices { if value == actual { return 0.1 } }
	return 0
}

func professionalDirection(from, to AuthSnapshot, now time.Time) float64 {
	if !premium(from, now) || from.Preferences.Professional.NoPreference { return 0 }
	p := from.Preferences.Professional
	profile := to.Profile.Professional
	score := categoryMatch(p.Industry, profile.Industry) + categoryMatch(p.Profession, profile.Profession) + categoryMatch(p.Experience, profile.Experience) + categoryMatch(p.Topics, to.Profile.Topic)
	if !p.Interests.NoPreference && len(p.Interests.Choices) > 0 {
		overlap := 0
		for _, preferred := range p.Interests.Choices {
			for _, actual := range profile.Interests { if preferred == actual { overlap++; break } }
		}
		score += 0.1 * math.Min(1, float64(overlap) / float64(len(p.Interests.Choices)))
	}
	return math.Min(0.5, score)
}

// RelevanceBonuses returns the independently capped topic and professional
// bonuses in waiting-second units, after the common five-second linear decay.
// General Talk is an opt-out from professional influence for the pair.
func RelevanceBonuses(a, b QueueEntry, now time.Time) (topic, professional float64) {
	decay := math.Max(0, 1 - math.Max(waitingSeconds(a, now), waitingSeconds(b, now)) / 5)
	if a.Auth.Profile.Topic != "" && a.Auth.Profile.Topic != "general_talk" && a.Auth.Profile.Topic == b.Auth.Profile.Topic { topic = 0.5 }
	if a.Auth.Profile.Topic != "general_talk" && b.Auth.Profile.Topic != "general_talk" {
		professional = (professionalDirection(a.Auth, b.Auth, now) + professionalDirection(b.Auth, a.Auth, now)) / 2
	}
	return topic * decay, professional * decay
}

func CandidateScore(anchor, candidate QueueEntry, now time.Time, prior PairHistory) float64 {
	topic, professional := RelevanceBonuses(anchor, candidate, now)
	return waitingSeconds(candidate, now) - RecentPairPenalty(prior, now) + topic + professional
}

type PairSelection struct { Anchor QueueEntry; Candidate QueueEntry }

// SelectPair scans the entire bounded shared waiting collection. No profile
// bucket or score threshold may delay a feasible match. A constrained oldest
// participant without any partner is skipped, so unrelated pairs can proceed.
// TieBreak is random server state assigned on queue insertion, never client data.
func SelectPair(entries []QueueEntry, now time.Time, lookup RecentPairLookup) (PairSelection, bool) {
	order := make([]int, len(entries))
	for index := range entries { order[index] = index }
	sort.Slice(order, func(i, j int) bool {
		a, b := entries[order[i]], entries[order[j]]
		if !a.QueuedAt.Equal(b.QueuedAt) { return a.QueuedAt.Before(b.QueuedAt) }
		if a.TieBreak != b.TieBreak { return a.TieBreak < b.TieBreak }
		return a.SlotID < b.SlotID
	})
	for _, anchorIndex := range order {
		anchor := entries[anchorIndex]
		best := -1
		bestScore := math.Inf(-1)
		for candidateIndex, candidate := range entries {
			if candidateIndex == anchorIndex { continue }
			prior := PairHistory{}
			if lookup != nil { prior, _ = lookup(anchor, candidate) }
			if !HardCompatible(anchor, candidate, now, prior) { continue }
			score := CandidateScore(anchor, candidate, now, prior)
			if best < 0 || score > bestScore || (score == bestScore && candidateBefore(candidate, entries[best])) { best = candidateIndex; bestScore = score }
		}
		if best >= 0 { return PairSelection{Anchor: anchor, Candidate: entries[best]}, true }
	}
	return PairSelection{}, false
}

func candidateBefore(a, b QueueEntry) bool {
	if !a.QueuedAt.Equal(b.QueuedAt) { return a.QueuedAt.Before(b.QueuedAt) }
	if a.TieBreak != b.TieBreak { return a.TieBreak < b.TieBreak }
	return a.SlotID < b.SlotID
}
