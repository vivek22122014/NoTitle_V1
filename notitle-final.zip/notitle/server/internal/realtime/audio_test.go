package realtime

import (
 "encoding/json"
 "strings"
 "testing"

 "notitle/internal/audiotypes"
)

func audioEnvelope(kind string,payload any)[]byte{wire,_:=json.Marshal(map[string]any{"v":1,"id":"audio-test","type":kind,"generation":2,"interaction_id":"interaction-test","epoch":3,"payload":payload});return wire}
func TestAudioActionsRequireCurrentScopeAndExactPayload(t *testing.T){
 for _,kind:=range []string{"call.request","call.accept","call.decline","call.end","call.connected","webrtc.offer","webrtc.answer","webrtc.ice"}{
  payload:=map[string]any{"call_ref":"synthetic-call-0001"}
  if kind=="call.connected"||kind=="webrtc.offer"||kind=="webrtc.answer"||kind=="webrtc.ice"{payload["negotiation"]=1}
  switch kind{case "call.request":payload=map[string]any{};case "webrtc.offer","webrtc.answer":payload["sdp"]="v=0\r\n";case "webrtc.ice":payload["candidate"]="candidate:1 1 udp 1 203.0.113.5 49152 typ relay";payload["sdp_mid"]="0";payload["sdp_mline_index"]=0}
  wire:=audioEnvelope(kind,payload)
  if _,err:=DecodeEnvelope(wire);err!=nil{t.Fatalf("valid shape %s rejected: %v",kind,err)}
  var object map[string]any;_ = json.Unmarshal(wire,&object);delete(object,"epoch");without,_:=json.Marshal(object)
  if _,err:=DecodeEnvelope(without);err!=ErrStaleEpoch{t.Fatalf("%s accepted without epoch",kind)}
  payload["peer_id"]="private-peer";if _,err:=DecodeEnvelope(audioEnvelope(kind,payload));err==nil{t.Fatalf("%s accepted arbitrary peer routing",kind)}
 }
 for _,payload:=range []map[string]any{
  {"call_ref":"short"},{"call_ref":"synthetic-call-0001","Call_Ref":"synthetic-call-0002"},
 }{if _,err:=DecodeEnvelope(audioEnvelope("call.accept",payload));err==nil{t.Fatal("unsafe call reference accepted")}}
}
func TestOnlyTypedSDPEnvelopesReceiveLargerBound(t *testing.T){
 payload:=map[string]any{"call_ref":"synthetic-call-0001","negotiation":1,"sdp":strings.Repeat("x",MaxFrameBytes+1)}
 for _,kind:=range []string{"webrtc.offer","webrtc.answer"}{if _,err:=DecodeEnvelope(audioEnvelope(kind,payload));err!=nil{t.Fatal("typed SDP denied larger limit",err)}}
 if _,err:=DecodeEnvelope(audioEnvelope("call.accept",payload));err==nil{t.Fatal("ordinary event enlarged through SDP-looking field")}
 payload["sdp"]=strings.Repeat("x",audiotypes.MaxSDPBytes+1)
 if _,err:=DecodeEnvelope(audioEnvelope("webrtc.offer",payload));err==nil{t.Fatal("oversized SDP body accepted")}
 valid:=audioEnvelope("call.request",map[string]any{})
 if _,err:=DecodeEnvelope(append([]byte(strings.Repeat(" ",MaxFrameBytes)),valid...));err==nil{t.Fatal("ordinary whitespace padding escaped 8 KiB cap")}
 if _,err:=DecodeEnvelope(append([]byte(strings.Repeat(" ",MaxSDPFrameBytes)),valid...));err==nil{t.Fatal("outer frame cap ignored")}
}
func TestICEPayloadCannotRouteToOtherMedia(t *testing.T){
 for _,payload:=range []map[string]any{
  {"call_ref":"synthetic-call-0001","negotiation":1,"candidate":"candidate:1","sdp_mid":"1","sdp_mline_index":0},
  {"call_ref":"synthetic-call-0001","negotiation":1,"candidate":"candidate:1","sdp_mid":"0","sdp_mline_index":1},
  {"call_ref":"synthetic-call-0001","negotiation":1,"candidate":"candidate:1","sdp_mid":"0"},
  {"call_ref":"synthetic-call-0001","negotiation":1,"candidate":"","sdp_mid":"0","sdp_mline_index":0},
  {"call_ref":"synthetic-call-0001","negotiation":1,"candidate":"candidate:1","sdp_mid":"0","sdp_mline_index":nil},
 }{if _,err:=DecodeEnvelope(audioEnvelope("webrtc.ice",payload));err==nil{t.Fatal("invalid media route accepted")}}
}
