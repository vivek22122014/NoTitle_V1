package realtime

import (
 "encoding/json"
 "strings"
 "testing"
)

func friendEnvelope(kind,payload string,current bool) string {
 scope:=""
 if current { scope=`,"interaction_id":"synthetic-interaction","epoch":3` }
 return `{"v":1,"id":"synthetic-command","type":"`+kind+`","generation":7`+scope+`,"payload":`+payload+`}`
}
func TestFriendCommandsBindConsentToCurrentEpoch(t *testing.T) {
 for _,kind:=range []string{"friend.request","friend.accept","friend.decline","friend.withdraw"} {
  payload:=`{}`
  if kind!="friend.request" { payload=`{"request_ref":"synthetic-request-0001"}` }
  if _,err:=DecodeEnvelope([]byte(friendEnvelope(kind,payload,true)));err!=nil { t.Fatalf("valid %s rejected: %v",kind,err) }
  if _,err:=DecodeEnvelope([]byte(friendEnvelope(kind,payload,false)));err!=ErrStaleEpoch { t.Fatalf("%s accepted without current scope",kind) }
 }
}
func TestFriendInviteDoesNotAcceptInteractionOrPeerIdentity(t *testing.T) {
 valid:=map[string]string{
  "friend.invite":`{"friend_ref":"synthetic-relation-0001","kind":"text"}`,
  "friend.accept_invite":`{"invitation_ref":"synthetic-invitation-0001"}`,
  "friend.decline_invite":`{"invitation_ref":"synthetic-invitation-0001"}`,
 }
 for kind,payload:=range valid {
  if _,err:=DecodeEnvelope([]byte(friendEnvelope(kind,payload,false)));err!=nil { t.Fatalf("valid %s rejected: %v",kind,err) }
  if _,err:=DecodeEnvelope([]byte(friendEnvelope(kind,payload,true)));err==nil { t.Fatalf("%s accepted unrelated epoch",kind) }
 }
 // Audio is a reserved wire kind only. The current owner rejects it; parsing
 // does not grant media consent, microphone access or a call allocation.
 if _,err:=DecodeEnvelope([]byte(friendEnvelope("friend.invite",`{"friend_ref":"synthetic-relation-0001","kind":"audio"}`,false)));err!=nil { t.Fatal(err) }
 for _,payload:=range []string{
  `{}`, `{"friend_ref":"short","kind":"text"}`,
  `{"friend_ref":"synthetic-relation-0001"}`,
  `{"friend_ref":"synthetic-relation-0001","kind":"video"}`,
  `{"friend_ref":"synthetic-relation-0001","kind":"text","peer_id":"account-id"}`,
  `{"friend_ref":"synthetic-relation-0001","kind":"text","consent":true}`,
  `{"friend_ref":"synthetic-relation-0001","kind":"text","Kind":"audio"}`,
  `{"friend_ref":"synthetic-relation-0001","kind":null}`,
  `{"friend_ref":"synthetic-relation-0001","friend_ref":"different-relation-0001","kind":"text"}`,
  `{"friend_ref":"synthetic-relation-0001","kind":"text\ud800"}`,
 } { if _,err:=DecodeEnvelope([]byte(friendEnvelope("friend.invite",payload,false)));err==nil { t.Fatal("forged or malformed invite accepted") } }
}
func TestFriendResponsesRequireExactScopedReferences(t *testing.T) {
 for _,kind:=range []string{"friend.accept","friend.decline","friend.withdraw"} {
  for _,payload:=range []string{`{}`,`{"request_ref":null}`,`{"request_ref":"short"}`,`{"Request_Ref":"synthetic-request-0001"}`,`{"request_ref":"synthetic-request-0001","accepted":true}`,`{"request_ref":"`+strings.Repeat("a",129)+`"}`} {
   if _,err:=DecodeEnvelope([]byte(friendEnvelope(kind,payload,true)));err==nil { t.Fatalf("malformed %s accepted",kind) }
  }
 }
 event,err:=DecodeEnvelope([]byte(friendEnvelope("friend.accept",`{"request_ref":"synthetic-request-0001"}`,true)))
 if err!=nil { t.Fatal(err) }
 wire,err:=json.Marshal(event);if err!=nil{t.Fatal(err)}
 normalized,err:=DecodeEnvelope(wire);if err!=nil{t.Fatal(err)}
 response,err:=DecodeFriendResponse(normalized)
 if err!=nil||response.RequestRef!="synthetic-request-0001" { t.Fatal("reference altered during round trip") }
 if _,err:=DecodeFriendInvite(normalized);err==nil { t.Fatal("cross-command decoder accepted response") }
}
