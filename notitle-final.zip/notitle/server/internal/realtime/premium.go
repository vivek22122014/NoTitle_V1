package realtime

import (
 "context"
 "errors"
 "time"
 "notitle/internal/identity"
)

// PremiumUsageJob is a bounded, ephemeral admission intent. The durable store
// records only the current purchase lot's minimal use flag, not this job or any
// conversation metadata. A crash before acknowledgement cannot grant paid use.
type PremiumUsageJob struct {
 ID string
 Guard identity.Guard
 EntitlementVersion int64
 LotID string
}
func(PremiumUsageJob)MarshalJSON()([]byte,error){return nil,errors.New("private paid-use authorization")}
type PremiumUsageResult struct { Entitlement Entitlement; Trusted bool }
func(Entitlement)MarshalJSON()([]byte,error){return nil,errors.New("private entitlement authorization")}
type PremiumUsageOwner interface {
 ClaimPremiumUsageJobs(context.Context,int)([]PremiumUsageJob,error)
 FinishPremiumUsage(context.Context,string,PremiumUsageResult)(bool,error)
}

// PremiumMutationOwner is the mandatory publication barrier around a durable
// grant, refund hold, revocation, restoration or dispute entitlement change.
// Begin must complete BEFORE opening the economic transaction. Unknown outcomes
// leave the fence pending until a fresh authoritative ledger read can finish it.
type PremiumMutationOwner interface {
 BeginPremiumMutation(context.Context,string)(string,error)
 FinishPremiumMutation(context.Context,string,string,Entitlement)error
}

func(e Entitlement) PaidUseAuthorized(now time.Time)bool{
 return e.Active(now)&&e.PaidControlsUsed&&e.UsageLotID!=""&&now.Before(e.UsageUntil)&&!e.UsageUntil.After(e.ExpiresAt)
}

// UsesPaidMatching describes effective search controls, not saved choices.
// General Talk disables professional influence while preserving those choices.
func UsesPaidMatching(a AuthSnapshot)bool{
 if a.Preferences.Gender!=Everyone{return true}
 return a.Profile.Topic!="general_talk"&&RequiresPremium(a.Preferences)
}
