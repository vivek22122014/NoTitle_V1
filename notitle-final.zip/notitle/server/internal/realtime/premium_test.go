package realtime

import (
 "encoding/json"
 "testing"
 "time"
 "notitle/internal/identity"
)
func TestPremiumUsageIsBoundToCurrentLotWindow(t *testing.T){
 now:=time.Date(2026,10,9,10,0,0,0,time.UTC);e:=Entitlement{Premium:true,Version:1,ExpiresAt:now.Add(time.Hour),UsageLotID:"oldest_lot",UsageUntil:now.Add(time.Minute),PaidControlsUsed:true}
 if !e.PaidUseAuthorized(now)||e.PaidUseAuthorized(now.Add(time.Minute)){t.Fatal("FIFO boundary did not end previous lot authority")}
 e.UsageUntil=e.ExpiresAt.Add(time.Second);if e.PaidUseAuthorized(now){t.Fatal("lot window exceeded total entitlement")}
 e.UsageUntil=now.Add(time.Minute);e.PaidControlsUsed=false;if e.PaidUseAuthorized(now){t.Fatal("unpersisted paid usage accepted")}
}
func TestPremiumUsageJobCannotBeSerialized(t *testing.T){if _,err:=json.Marshal(PremiumUsageJob{ID:"private_job",Guard:identity.Guard{AccountID:"private_account",TokenHash:identity.Verifier{1}}});err==nil{t.Fatal("private usage job could leak session/account bindings")}}
func TestPremiumEntitlementCannotExposePurchaseLot(t *testing.T){if _,err:=json.Marshal(Entitlement{Premium:true,Version:1,UsageLotID:"private_purchase",PaidControlsUsed:true});err==nil{t.Fatal("server entitlement could expose purchase usage")}}
func TestEffectivePaidControlsRespectEveryoneAndGeneralTalk(t *testing.T){
 a:=AuthSnapshot{Preferences:DefaultPreferences(),Profile:identity.Profile{Topic:"general_talk"}}
 a.Preferences.Professional.NoPreference=false;a.Preferences.Professional.Profession=CategoryPreference{Choices:[]string{"engineering"}}
 if UsesPaidMatching(a){t.Fatal("General Talk selected saved profession as active control")}
 a.Profile.Topic="work_culture";if !UsesPaidMatching(a){t.Fatal("effective profession not attributed")}
 a.Preferences.Professional.NoPreference=true;if UsesPaidMatching(a){t.Fatal("No preference marked paid use")}
 a.Preferences.Gender=PreferOther;if !UsesPaidMatching(a){t.Fatal("hard gender preference lost use attribution")}
}
