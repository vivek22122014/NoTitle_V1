package realtime

import (
	"bytes"
	"encoding/json"
	"io"
	"regexp"
	"unicode/utf8"

	"notitle/internal/friendtypes"
 "notitle/internal/audiotypes"
)

var wireID = regexp.MustCompile(`^[A-Za-z0-9_-]{1,96}$`)

// DecodeEnvelope rejects duplicate keys at every depth, malformed UTF-8,
// unknown fields, trailing values, unsupported events and phase-later payloads.
// The socket reader additionally enforces MaxSDPFrameBytes before allocation;
// only explicit webrtc.offer/answer frames may exceed the ordinary 8 KiB cap.
func DecodeEnvelope(data []byte) (ClientEnvelope, error) {
	var event ClientEnvelope
	if len(data) == 0 || len(data) > MaxSDPFrameBytes || !utf8.Valid(data) || !validObject(data) { return event, ErrProtocol }
	if err := decodeStrict(data, &event); err != nil { return event, ErrProtocol }
 if len(data)>FrameLimit(event.Type) { return event,ErrProtocol }
	var fields map[string]json.RawMessage
	if json.Unmarshal(data, &fields) != nil { return event, ErrProtocol }
	if !allowedFields(fields, "v", "id", "type", "generation", "interaction_id", "epoch", "payload") { return event, ErrProtocol }
	for _, required := range []string{"v", "id", "type", "generation", "payload"} { if _, present := fields[required]; !present { return event, ErrProtocol } }
	if event.V != ProtocolVersion { return event, ErrVersion }
	if !wireID.MatchString(event.ID) || len(event.ID) > 64 || len(event.Payload) == 0 || !validObject(event.Payload) { return event, ErrProtocol }
	if event.Type == "session.authenticate" {
		if event.Generation != 0 || event.InteractionID != "" || event.Epoch != 0 { return event, ErrProtocol }
		if _, err := DecodeAuthenticate(event); err != nil { return event, err }
		return event, nil
	}
	if event.Generation == 0 { return event, ErrStaleGeneration }
	interactionAction := event.Type == "match.next" || event.Type == "match.end" || event.Type == "chat.send" || event.Type == "chat.delivery_ack" || event.Type == "friend.request" || event.Type == "friend.accept" || event.Type == "friend.decline" || event.Type == "friend.withdraw" || isAudioAction(event.Type)
	if interactionAction {
		if !wireID.MatchString(event.InteractionID) || event.Epoch == 0 { return event, ErrStaleEpoch }
	} else if event.InteractionID != "" || event.Epoch != 0 { return event, ErrProtocol }
	switch event.Type {
	case "call.connected":
  if _,err:=DecodeCallConnected(event);err!=nil{return event,err}
 case "call.accept", "call.decline", "call.end":
  if _,err:=DecodeCallRef(event);err!=nil{return event,err}
 case "webrtc.offer", "webrtc.answer":
  if _,err:=DecodeSDP(event);err!=nil{return event,err}
 case "webrtc.ice":
  if _,err:=DecodeICE(event);err!=nil{return event,err}
 case "queue.join":
		if _, err := DecodeQueueJoin(event); err != nil { return event, ErrProtocol }
	case "chat.send":
		if _, err := DecodeChatSend(event); err != nil { return event, err }
	case "chat.delivery_ack":
		if _, err := DecodeChatDeliveryAck(event); err != nil { return event, err }
	case "friend.accept", "friend.decline", "friend.withdraw":
		if _, err := DecodeFriendResponse(event); err != nil { return event, err }
	case "friend.invite":
		if _, err := DecodeFriendInvite(event); err != nil { return event, err }
	case "friend.accept_invite", "friend.decline_invite":
		if _, err := DecodeFriendInviteResponse(event); err != nil { return event, err }
	case "queue.leave", "match.next", "match.end", "heartbeat", "state.sync", "friend.request", "call.request":
		var payload struct{}
		if err := decodeStrict(event.Payload, &payload); err != nil { return event, ErrProtocol }
	default:
		return event, ErrProtocol
	}
	return event, nil
}

func DecodeAuthenticate(event ClientEnvelope) (AuthenticatePayload, error) {
	var payload AuthenticatePayload
	if event.Type != "session.authenticate" || !validObject(event.Payload) || decodeStrict(event.Payload, &payload) != nil { return payload, ErrProtocol }
	var fields map[string]json.RawMessage
	if json.Unmarshal(event.Payload, &fields) != nil || !allowedFields(fields, "ticket", "takeover", "resume") { return payload, ErrProtocol }
	if len(payload.Ticket) < 32 || len(payload.Ticket) > 128 || !wireID.MatchString(payload.Ticket) { return payload, ErrProtocol }
	if payload.Resume != nil {
		r := payload.Resume
		var resumeFields map[string]json.RawMessage
		if json.Unmarshal(fields["resume"], &resumeFields) != nil || !allowedFields(resumeFields, "token", "server_instance", "generation", "interaction_id", "epoch") { return payload, ErrProtocol }
		if payload.Takeover || len(r.Token) < 32 || !wireID.MatchString(r.Token) || !wireID.MatchString(r.ServerInstance) || r.Generation == 0 { return payload, ErrProtocol }
		if (r.InteractionID == "") != (r.Epoch == 0) || (r.InteractionID != "" && !wireID.MatchString(r.InteractionID)) { return payload, ErrProtocol }
	}
	return payload, nil
}

func DecodeQueueJoin(event ClientEnvelope) (QueueJoinPayload, error) {
	var payload QueueJoinPayload
	if event.Type != "queue.join" || !validObject(event.Payload) || decodeStrict(event.Payload, &payload) != nil { return payload, ErrProtocol }
	var fields map[string]json.RawMessage
	if json.Unmarshal(event.Payload, &fields) != nil || !allowedFields(fields, "continue_with_everyone") { return payload, ErrProtocol }
	return payload, nil
}

// encoding/json otherwise accepts case-insensitive struct-field aliases.
// Exact names prevent alternate-case duplicate fields from overriding values.
func allowedFields(fields map[string]json.RawMessage, allowed ...string) bool {
	for field := range fields {
		found := false
		for _, name := range allowed { if field == name { found = true; break } }
		if !found { return false }
	}
	return true
}

func decodeStrict(data []byte, target any) error {
	d := json.NewDecoder(bytes.NewReader(data))
	d.DisallowUnknownFields()
	if err := d.Decode(target); err != nil { return err }
	var trailing any
	if err := d.Decode(&trailing); err != io.EOF { return ErrProtocol }
	return nil
}

func validObject(data []byte) bool {
	trimmed := bytes.TrimSpace(data)
	if len(trimmed) == 0 || trimmed[0] != '{' || !ValidJSONUnicode(trimmed) { return false }
	d := json.NewDecoder(bytes.NewReader(trimmed))
	d.UseNumber()
	if !uniqueValue(d, 0) { return false }
	_, err := d.Token()
	return err == io.EOF
}

// ValidJSONUnicode checks raw UTF-8 and escaped UTF-16 scalar validity before
// encoding/json can silently substitute replacement characters. It is not a
// complete JSON schema or syntax validator; callers must still decode strictly.
func ValidJSONUnicode(data []byte) bool { return utf8.Valid(data) && validUnicodeEscapes(data) }

// encoding/json replaces unmatched escaped UTF-16 surrogates with U+FFFD. That
// silently changes supplied meaning, so reject them before decoding instead.
func validUnicodeEscapes(data []byte) bool {
	inString := false
	for index := 0; index < len(data); index++ {
		if data[index] == '"' { inString = !inString; continue }
		if !inString || data[index] != '\\' { continue }
		index++
		if index >= len(data) { return false }
		if data[index] != 'u' { continue }
		value, ok := hexQuad(data, index + 1)
		if !ok { return false }
		index += 4
		if value >= 0xDC00 && value <= 0xDFFF { return false }
		if value < 0xD800 || value > 0xDBFF { continue }
		if index + 6 >= len(data) || data[index + 1] != '\\' || data[index + 2] != 'u' { return false }
		low, ok := hexQuad(data, index + 3)
		if !ok || low < 0xDC00 || low > 0xDFFF { return false }
		index += 6
	}
	return !inString
}

func hexQuad(data []byte, start int) (uint16, bool) {
	if start + 4 > len(data) { return 0, false }
	var value uint16
	for _, digit := range data[start:start+4] {
		value <<= 4
		switch {
		case digit >= '0' && digit <= '9': value += uint16(digit - '0')
		case digit >= 'a' && digit <= 'f': value += uint16(digit - 'a' + 10)
		case digit >= 'A' && digit <= 'F': value += uint16(digit - 'A' + 10)
		default: return 0, false
		}
	}
	return value, true
}

func uniqueValue(d *json.Decoder, depth int) bool {
	if depth > 8 { return false }
	token, err := d.Token()
	if err != nil { return false }
	delimiter, compound := token.(json.Delim)
	if !compound { return token != nil }
	switch delimiter {
	case '{':
		keys := map[string]bool{}
		for d.More() {
			keyToken, err := d.Token()
			if err != nil { return false }
			key, ok := keyToken.(string)
			if !ok || keys[key] { return false }
			keys[key] = true
			if !uniqueValue(d, depth + 1) { return false }
		}
		end, err := d.Token()
		return err == nil && end == json.Delim('}')
	case '[':
		for d.More() { if !uniqueValue(d, depth + 1) { return false } }
		end, err := d.Token()
		return err == nil && end == json.Delim(']')
	default:
		return false
	}
}

func DecodeFriendResponse(event ClientEnvelope) (FriendResponse,error) {
 var payload FriendResponse
 if event.Type != "friend.accept" && event.Type != "friend.decline" && event.Type != "friend.withdraw" { return payload,ErrProtocol }
 if !friendPayload(event.Payload,&payload,"request_ref") || !friendtypes.ValidRef(payload.RequestRef) { return payload,ErrProtocol }
 return payload,nil
}
func DecodeFriendInvite(event ClientEnvelope) (FriendInvite,error) {
 var payload FriendInvite
 if event.Type != "friend.invite" || !friendPayload(event.Payload,&payload,"friend_ref","kind") || !friendtypes.ValidRef(payload.FriendRef) || (payload.Kind != "text" && payload.Kind != "audio") { return payload,ErrProtocol }
 return payload,nil
}
func DecodeFriendInviteResponse(event ClientEnvelope) (FriendInviteResponse,error) {
 var payload FriendInviteResponse
 if event.Type != "friend.accept_invite" && event.Type != "friend.decline_invite" { return payload,ErrProtocol }
 if !friendPayload(event.Payload,&payload,"invitation_ref") || !friendtypes.ValidRef(payload.InvitationRef) { return payload,ErrProtocol }
 return payload,nil
}
func friendPayload(data []byte,target any,fields ...string) bool {
 if !validObject(data) || decodeStrict(data,target) != nil { return false }
 var object map[string]json.RawMessage
 if json.Unmarshal(data,&object) != nil || !allowedFields(object,fields...) { return false }
 for _,field := range fields { if _,ok:=object[field]; !ok { return false } }
 return true
}

// FrameLimit is used by both socket directions. Renaming an ordinary command
// never enlarges its limit because unsupported/invalid SDP schemas still fail.
func FrameLimit(eventType string) int {
 if eventType=="webrtc.offer" || eventType=="webrtc.answer" { return MaxSDPFrameBytes }
 return MaxFrameBytes
}
func isAudioAction(eventType string) bool {
 switch eventType {case "call.request","call.accept","call.decline","call.end","call.connected","webrtc.offer","webrtc.answer","webrtc.ice":return true};return false
}
func DecodeCallRef(event ClientEnvelope) (audiotypes.RefPayload,error) {
 var payload audiotypes.RefPayload
 if event.Type!="call.accept"&&event.Type!="call.decline"&&event.Type!="call.end" {return payload,ErrProtocol}
 if !friendPayload(event.Payload,&payload,"call_ref")||!audiotypes.ValidRef(payload.CallRef){return payload,ErrProtocol};return payload,nil
}
func DecodeSDP(event ClientEnvelope) (audiotypes.SDPPayload,error) {
 var payload audiotypes.SDPPayload
 if event.Type!="webrtc.offer"&&event.Type!="webrtc.answer" {return payload,ErrProtocol}
 if !friendPayload(event.Payload,&payload,"call_ref","negotiation","sdp")||!audiotypes.ValidRef(payload.CallRef)||payload.Negotiation==0||len(payload.SDP)==0||len(payload.SDP)>audiotypes.MaxSDPBytes {return payload,ErrProtocol};return payload,nil
}
func DecodeICE(event ClientEnvelope) (audiotypes.ICEPayload,error) {
 var payload audiotypes.ICEPayload
 if event.Type!="webrtc.ice"||!friendPayload(event.Payload,&payload,"call_ref","negotiation","candidate","sdp_mid","sdp_mline_index")||!audiotypes.ValidRef(payload.CallRef)||payload.Negotiation==0||len(payload.Candidate)==0||len(payload.Candidate)>audiotypes.MaxCandidateBytes||payload.SDPMid!="0"||payload.SDPMLineIndex!=0 {return payload,ErrProtocol};return payload,nil
}

func DecodeCallConnected(event ClientEnvelope) (audiotypes.ConnectedPayload,error) {
 var payload audiotypes.ConnectedPayload
 if event.Type!="call.connected"||!friendPayload(event.Payload,&payload,"call_ref","negotiation")||!audiotypes.ValidRef(payload.CallRef)||payload.Negotiation==0 {return payload,ErrProtocol};return payload,nil
}
