package realtime

import (
	"bytes"
	"encoding/json"
	"strings"
	"testing"
	"unicode/utf8"
)

func textEnvelope(t *testing.T, text string) []byte {
	t.Helper()
	payload, err := json.Marshal(ChatSend{ClientSendID: "send_1", Text: text})
	if err != nil { t.Fatal(err) }
	wire, err := json.Marshal(ClientEnvelope{V: 1, ID: "command_1", Type: "chat.send", Generation: 7, InteractionID: "interaction", Epoch: 9, Payload: payload})
	if err != nil { t.Fatal(err) }
	return wire
}

func TestPlainTextPreservesUnicodeAndLiteralMarkup(t *testing.T) {
	for _, value := range []string{"Hello\nworld", "नमस्ते", "مرحبا", "👩‍💻", "می‌خواهم", "<script>alert('x')</script>", "https://example.test is plain text", "\uFFFD"} {
		if err := ValidateText(value); err != nil { t.Fatalf("valid text rejected: %v", err) }
		event, err := DecodeEnvelope(textEnvelope(t, value))
		if err != nil { t.Fatal(err) }
		payload, err := DecodeChatSend(event)
		if err != nil || payload.Text != value || payload.ClientSendID != "send_1" { t.Fatal("text or send ID changed") }
	}
}

func TestTextCodepointByteControlAndFrameLimits(t *testing.T) {
	for _, value := range []string{strings.Repeat("a", 2000), strings.Repeat("界", 2000), strings.Repeat("😀", 1536), strings.Repeat("a", 1999) + "\n"} {
		if err := ValidateText(value); err != nil { t.Fatal("valid boundary text rejected", err) }
	}
	for _, value := range []string{"", " \n ", strings.Repeat("a", 2001), strings.Repeat("😀", 1537), "a\x00b", "a\tb", "a\rb", "a\u202Eb", "a\u2066b", "a\u061Cb", "a\u200Fb", "a\uFEFFb", "a\u200Bb", string([]byte{0xff}), "x" + strings.Repeat("\u2028", 1999)} {
		if err := ValidateText(value); err == nil { t.Fatal("invalid text accepted") }
	}
}

func TestChatRequiresScopedEpochAndExactPayload(t *testing.T) {
	for _, input := range []string{
		`{"v":1,"id":"command","type":"chat.send","generation":7,"interaction_id":"interaction","epoch":9,"payload":{"client_send_id":"send","text":"Hi"}}`,
		`{"v":1,"id":"command","type":"chat.delivery_ack","generation":7,"interaction_id":"interaction","epoch":9,"payload":{"server_sequence":1}}`,
	} { if _, err := DecodeEnvelope([]byte(input)); err != nil { t.Fatal(err) } }
	for _, input := range []string{
		`{"v":1,"id":"command","type":"chat.send","generation":7,"payload":{"client_send_id":"send","text":"Hi"}}`,
		`{"v":1,"id":"command","type":"chat.send","generation":7,"interaction_id":"interaction","epoch":9,"payload":{"client_send_id":"send","text":"Hi","peer_id":"chosen"}}`,
		`{"v":1,"id":"command","type":"chat.send","generation":7,"interaction_id":"interaction","epoch":9,"payload":{"client_send_id":"send","text":"Hi","Text":"override"}}`,
		`{"v":1,"id":"command","type":"chat.send","generation":7,"interaction_id":"interaction","epoch":9,"payload":{"client_send_id":"send","text":null}}`,
		`{"v":1,"id":"command","type":"chat.send","generation":7,"interaction_id":"interaction","epoch":9,"payload":{"client_send_id":"","text":"Hi"}}`,
		`{"v":1,"id":"command","type":"chat.delivery_ack","generation":7,"interaction_id":"interaction","epoch":9,"payload":{"server_sequence":0}}`,
		`{"v":1,"id":"command","type":"chat.delivery_ack","generation":7,"interaction_id":"interaction","epoch":9,"payload":{"server_sequence":1.5}}`,
		`{"v":1,"id":"command","type":"chat.delivery_ack","generation":7,"interaction_id":"interaction","epoch":9,"payload":{"server_sequence":1,"delivered":true}}`,
	} { if _, err := DecodeEnvelope([]byte(input)); err == nil { t.Fatal("invalid chat shape accepted") } }
}

func TestJSONSurrogatesRejectInsteadOfChangingMeaning(t *testing.T) {
	for _, text := range []string{`\ud800`, `\udc00`, `\ud800x`, `\ud800\u0061`, `\ud800\ud800`, `\udc00\ud800`} {
		input := `{"v":1,"id":"command","type":"chat.send","generation":7,"interaction_id":"interaction","epoch":9,"payload":{"client_send_id":"send","text":"` + text + `"}}`
		if _, err := DecodeEnvelope([]byte(input)); err == nil { t.Fatal("unpaired surrogate accepted") }
	}
	input := `{"v":1,"id":"command","type":"chat.send","generation":7,"interaction_id":"interaction","epoch":9,"payload":{"client_send_id":"send","text":"\ud83d\ude00"}}`
	event, err := DecodeEnvelope([]byte(input))
	if err != nil { t.Fatal(err) }
	payload, err := DecodeChatSend(event)
	if err != nil || payload.Text != "😀" { t.Fatal("paired surrogate not preserved") }
	if !validUnicodeEscapes([]byte(`{"text":"literal \\ud800 and escaped \" quote"}`)) { t.Fatal("escaped literal rejected") }
}

func FuzzChatText(f *testing.F) {
	f.Add("hello 👩‍💻\nworld")
	f.Add("<img src=x onerror=alert(1)>")
	f.Add("\u202E")
	f.Fuzz(func(t *testing.T, value string) {
		if ValidateText(value) != nil { return }
		if len(value) > MaxTextBytes || utf8.RuneCountInString(value) > MaxTextCodePoints || !utf8.ValidString(value) { t.Fatal("text limit broken") }
		var payload bytes.Buffer
		encoder := json.NewEncoder(&payload); encoder.SetEscapeHTML(false)
		if err := encoder.Encode(ChatSend{ClientSendID: "send_1", Text: value}); err != nil { t.Fatal(err) }
		var wire bytes.Buffer
		encoder = json.NewEncoder(&wire); encoder.SetEscapeHTML(false)
		if err := encoder.Encode(ClientEnvelope{V: 1, ID: "command_1", Type: "chat.send", Generation: 7, InteractionID: "interaction", Epoch: 9, Payload: payload.Bytes()}); err != nil { t.Fatal(err) }
		event, err := DecodeEnvelope(wire.Bytes())
		if err != nil { t.Fatal("accepted text failed bounded wire decode", err) }
		decoded, err := DecodeChatSend(event)
		if err != nil || decoded.Text != value { t.Fatal("wire round trip changed text") }
	})
}
