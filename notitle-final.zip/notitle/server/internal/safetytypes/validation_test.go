package safetytypes

import (
	"encoding/json"
	"strings"
	"testing"
)

func TestCurrentOrEndedReferenceIsExclusive(t *testing.T) {
	for _, request := range []BeginReportRequest{{Generation: 3, InteractionID: "interaction", Epoch: 2}, {EndedRef: strings.Repeat("e", 43), Block: true}} {
		if ValidateBeginReport(request) != nil { t.Fatal("valid scope rejected") }
	}
	for _, request := range []BeginReportRequest{{}, {Generation: 3, InteractionID: "interaction"}, {EndedRef: "guess"}, {EndedRef: strings.Repeat("e", 43), Generation: 3, InteractionID: "interaction", Epoch: 2}} {
		if ValidateBeginReport(request) == nil { t.Fatal("invalid or mixed scope accepted") }
	}
}

func TestReportSelectionAndStatementValidation(t *testing.T) {
	request := SubmitReportRequest{Handle: strings.Repeat("h", 43), SubmissionID: strings.Repeat("s", 32), Category: "harassment", SelectedSequences: []uint64{1, 4}}
	if ValidateSubmitReport(request) != nil { t.Fatal("valid report rejected") }
	request.SelectedSequences = []uint64{1, 1}
	if ValidateSubmitReport(request) == nil { t.Fatal("duplicate evidence accepted") }
	request.SelectedSequences = nil
	if ValidateSubmitReport(request) == nil { t.Fatal("empty metadata report accepted") }
	request.Statement = "My statement about unrecorded audio."
	if ValidateSubmitReport(request) != nil { t.Fatal("metadata statement rejected") }
	request.Category = "client_defined"
	if ValidateSubmitReport(request) == nil { t.Fatal("unknown category accepted") }
	for _, value := range []string{strings.Repeat("x", 2001), strings.Repeat("😀", 1537), "a\u202Eb", "a\u200Fb", string([]byte{0xff})} {
		if ValidateStatement(value) == nil { t.Fatal("invalid statement accepted") }
	}
	for _, value := range []string{"", "Hello\nनमस्ते 👩‍💻", "مرحبا", "<script>statement, never executable HTML</script>"} {
		if ValidateStatement(value) != nil { t.Fatal("valid plain statement rejected") }
	}
}

func TestPrivateSafetyRecordsNeverSerialize(t *testing.T) {
	for _, value := range []any{Guard{}, Subject{}, PreparedReport{}, BlockMutation{}, RestrictionMutation{}, HandoffFinalization{}} {
		if _, err := json.Marshal(value); err == nil { t.Fatal("private safety record serialized") }
	}
}

func TestBlockFriendReferenceIsExclusiveAndOpaque(t *testing.T) {
 ref := strings.Repeat("f",32)
 if ValidateBlock(BlockRequest{FriendRef:ref}) != nil { t.Fatal("valid friend reference rejected") }
 for _,request:=range []BlockRequest{
  {FriendRef:"guess"}, {FriendRef:ref,EndedRef:strings.Repeat("e",32)},
  {FriendRef:ref,Generation:1}, {FriendRef:ref,Epoch:1},
  {FriendRef:ref,InteractionID:"interaction"},
 } { if ValidateBlock(request)==nil { t.Fatal("mixed or malformed friend block scope accepted") } }
 // A friend reference cannot be repurposed as a report scope: evidence still
 // requires current participation or an owner-issued ended interaction handle.
 if ValidateBeginReport(BeginReportRequest{}) == nil { t.Fatal("unscoped report accepted") }
}
