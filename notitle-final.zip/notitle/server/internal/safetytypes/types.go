// Package safetytypes contains shared safety contracts. Only explicit View and
// request types may cross HTTP boundaries; subject IDs and prepared evidence
// remain private to the coordinator and persistence service.
package safetytypes

import (
	"context"
	"errors"
	"time"

	"notitle/internal/identity"
)

const (
	ReportDraftTTL = 2 * time.Minute
	EndedReferenceTTL = 10 * time.Minute
	MaxDrafts = 64
	MaxDraftsPerIdentity = 2
	MaxEndedReferences = 2000
	MaxLocalBlocks = 4000
	MaxBlocksPerIdentity = 100
	MaxStatementCodePoints = 2000
	MaxStatementBytes = 6 * 1024
	MaxSelectedEvidence = 30
	PromotionLeaseTTL = 30 * time.Second
)

type Error struct { Code string; Message string; Retryable bool }
func (e *Error) Error() string { return e.Code }
var (
	ErrInvalid = &Error{"INVALID_REQUEST", "Check the report or block request.", false}
	ErrUnauthorized = &Error{"AUTHENTICATION_REQUIRED", "Your session has ended. Sign in or start again.", false}
	ErrExpired = &Error{"REPORT_EXPIRED", "The temporary report reference has expired. Use the grievance route.", false}
	ErrStale = &Error{"STALE_EPOCH", "This conversation has ended or changed.", false}
	ErrUnavailable = &Error{"NOT_AVAILABLE", "Safety storage is temporarily unavailable. Please retry or use the grievance route.", true}
	ErrCapacity = &Error{"CAPACITY_REACHED", "Please retry shortly or use the grievance route.", true}
	ErrConflict = &Error{"CONFLICT", "This request has already been used for different details.", false}
	ErrBusy = &Error{"BUSY", "A safety update is in progress. Please retry shortly.", true}
)
func PublicError(err error) *Error { var result *Error; if errors.As(err, &result) { return result }; return ErrUnavailable }

// Guard is produced by trusted server code after capturing AuthFence and then
// refreshing Principal. A request cannot provide a subject, identity or fence.
type Guard struct { Principal identity.Principal; Fence uint64 }
func (Guard) MarshalJSON() ([]byte, error) { return nil, errors.New("private safety guard cannot be serialized") }
type Subject struct { Kind identity.Kind; ID string; Generation int64 }
func (Subject) MarshalJSON() ([]byte, error) { return nil, errors.New("private safety subject cannot be serialized") }

type BeginReportRequest struct {
	Generation uint64 `json:"generation,omitempty"`
	InteractionID string `json:"interaction_id,omitempty"`
	Epoch uint64 `json:"epoch,omitempty"`
	EndedRef string `json:"ended_ref,omitempty"`
	Block bool `json:"block,omitempty"`
}
type SubmitReportRequest struct {
	Handle string `json:"handle"`
	SubmissionID string `json:"submission_id"`
	Category string `json:"category"`
	Statement string `json:"statement"`
	SelectedSequences []uint64 `json:"selected_sequences"`
}
type EvidenceView struct {
	ServerSequence uint64 `json:"server_sequence"`
	Speaker string `json:"speaker"` // self or peer; never an identity ID
	Text string `json:"text"`
	SentAt time.Time `json:"sent_at"`
}
type DraftView struct {
	Handle string `json:"handle"`
	ExpiresAt time.Time `json:"expires_at"`
	Messages []EvidenceView `json:"messages"`
	MetadataOnly bool `json:"metadata_only"`
	Blocked bool `json:"blocked"`
}
type ReportReceipt struct { CaseRef string `json:"case_ref"`; SubmittedAt time.Time `json:"submitted_at"`; Blocked bool `json:"blocked"` }
type Evidence struct { ServerSequence uint64; Sender Subject; Text string; SentAt time.Time }
// CallMetadata is frozen by the owner for a user-initiated report. It contains
// only the last accepted call's reference and timing, never media or signaling.
type CallMetadata struct {
	CallRef string `json:"call_ref"`
	RequestedAt time.Time `json:"requested_at"`
	AcceptedAt *time.Time `json:"accepted_at,omitempty"`
	EndedAt *time.Time `json:"ended_at,omitempty"`
}
type PreparedReport struct {
	Handle string
	SubmissionID string
	Reporter Subject
	Subject Subject
	InteractionID string
	Epoch uint64
	StartedAt time.Time
	EndedAt *time.Time
	Call *CallMetadata
	Evidence []Evidence
	Category string
	Statement string
	Block *BlockMutation
	CompletedReceipt *ReportReceipt
}
func (PreparedReport) MarshalJSON() ([]byte, error) { return nil, errors.New("private prepared report cannot be serialized") }
type ReportCompletion struct { Handle string; SubmissionID string; CaseRef string; Persisted bool; BlockVersion uint64; DurableBlockPersisted bool; Receipt *ReportReceipt }
type BlockRequest struct {
	FriendRef string `json:"friend_ref,omitempty"`
	Generation uint64 `json:"generation,omitempty"`
	InteractionID string `json:"interaction_id,omitempty"`
	Epoch uint64 `json:"epoch,omitempty"`
	EndedRef string `json:"ended_ref,omitempty"`
}
type BlockView struct {
	Ref string `json:"ref"`
	DisplayName string `json:"display_name"`
	CreatedAt time.Time `json:"created_at"`
	Durable bool `json:"durable"`
	Pending bool `json:"pending"`
}
type BlockMutation struct { Ref string; Blocker Subject; Blocked Subject; CreatedAt time.Time; Version uint64; LeaseID string }
func (BlockMutation) MarshalJSON() ([]byte, error) { return nil, errors.New("private block mutation cannot be serialized") }
type RestrictionMutation struct { LeaseID string; Subject Subject; Until time.Time; DecidedAt time.Time }
func (RestrictionMutation) MarshalJSON() ([]byte, error) { return nil, errors.New("private restriction mutation cannot be serialized") }
type HandoffFinalization struct { LeaseID string; Subject Subject; Blocks []BlockMutation; RestrictionUntil time.Time; RestrictionDecidedAt time.Time; Version uint64 }
func (HandoffFinalization) MarshalJSON() ([]byte, error) { return nil, errors.New("private safety handoff cannot be serialized") }

// Owner is implemented by the single coordinator. No method performs storage
// or network I/O. Report/Block commands enter its priority safety mailbox.
// PrepareUnblock reserves the block before storage deletion and excludes
// promotion/re-block races. FinishUnblock releases only its exact live lease;
// failed persistence keeps the local block. A late callback cannot undo a newer
// restriction. Lease expiry must not allow an uncertain DB write to resurrect.
type Owner interface {
	AuthFence(context.Context) (uint64, error)
	BeginReport(context.Context, Guard, BeginReportRequest) (DraftView, error)
	PrepareReport(context.Context, Guard, SubmitReportRequest) (PreparedReport, error)
	FinishReport(context.Context, Guard, ReportCompletion) error
	BlockPeer(context.Context, Guard, BlockRequest) (BlockMutation, error)
	ListLocalBlocks(context.Context, Guard) ([]BlockView, error)
	PrepareUnblock(context.Context, Guard, string) (BlockMutation, error)
	PrepareDurableUnblock(context.Context, Guard, BlockMutation) (BlockMutation, error)
	FinishUnblock(context.Context, Guard, string, bool) error
	ApplyRestriction(context.Context, Subject, bool) error
	ApplyTimedRestriction(context.Context, Subject, time.Time) error
	ResolveSafetySubject(context.Context, Subject) (Subject, error)
	ClaimBlockPromotions(context.Context, int) ([]BlockMutation, error)
	FinishBlockPromotion(context.Context, string, bool) error
	ClaimRestrictionPromotions(context.Context, int) ([]RestrictionMutation, error)
	FinishRestrictionPromotion(context.Context, string, bool) error
	ClaimHandoffFinalizations(context.Context, int) ([]HandoffFinalization, error)
	FinishHandoffFinalization(context.Context, string, bool) error
}

var Categories = []string{"harassment", "threats", "doxxing", "confidentiality", "targeted_false_accusations", "scams", "impersonation", "suspected_underage_access", "sexual_misconduct", "spam", "other"}
func ValidCategory(category string) bool { for _, value := range Categories { if value == category { return true } }; return false }
