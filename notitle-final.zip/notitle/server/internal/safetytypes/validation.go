package safetytypes

import (
	"regexp"
	"strings"
	"unicode"
	"unicode/utf8"
)

var opaqueReference = regexp.MustCompile(`^[A-Za-z0-9_-]{16,128}$`)
var interactionReference = regexp.MustCompile(`^[A-Za-z0-9_-]{1,96}$`)

// ValidateStatement preserves user statements verbatim and keeps them separate
// from server-attributed evidence. Empty statements are allowed when selected
// evidence supplies the report content; metadata-only reports need a statement.
func ValidateStatement(value string) error {
	if !utf8.ValidString(value) || len(value) > MaxStatementBytes || utf8.RuneCountInString(value) > MaxStatementCodePoints { return ErrInvalid }
	for _, char := range value {
		if char == '\n' || char == '\u200C' || char == '\u200D' { continue }
		if unicode.IsControl(char) || unicode.In(char, unicode.Cf) { return ErrInvalid }
	}
	return nil
}

func ValidateBeginReport(request BeginReportRequest) error {
	if request.EndedRef != "" {
		if !opaqueReference.MatchString(request.EndedRef) || request.Generation != 0 || request.InteractionID != "" || request.Epoch != 0 { return ErrInvalid }
		return nil
	}
	if request.Generation == 0 || request.Epoch == 0 || !interactionReference.MatchString(request.InteractionID) { return ErrInvalid }
	return nil
}

func ValidateBlock(request BlockRequest) error {
	if request.FriendRef != "" {
		if !opaqueReference.MatchString(request.FriendRef) || request.EndedRef != "" || request.Generation != 0 || request.InteractionID != "" || request.Epoch != 0 { return ErrInvalid }
		return nil
	}
	return ValidateBeginReport(BeginReportRequest{Generation: request.Generation, InteractionID: request.InteractionID, Epoch: request.Epoch, EndedRef: request.EndedRef})
}

func ValidateSubmitReport(request SubmitReportRequest) error {
	if !opaqueReference.MatchString(request.Handle) || !opaqueReference.MatchString(request.SubmissionID) || len(request.SubmissionID) > 64 || !ValidCategory(request.Category) || len(request.SelectedSequences) > MaxSelectedEvidence || ValidateStatement(request.Statement) != nil { return ErrInvalid }
	if len(request.SelectedSequences) == 0 && strings.TrimSpace(request.Statement) == "" { return ErrInvalid }
	selected := make(map[uint64]bool, len(request.SelectedSequences))
	for _, sequence := range request.SelectedSequences { if sequence == 0 || selected[sequence] { return ErrInvalid }; selected[sequence] = true }
	return nil
}
