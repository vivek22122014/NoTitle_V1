package identityhttp

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"notitle/internal/identity"
 "notitle/internal/realtime"
)

type fakeService struct {
	Service
	principal identity.Principal
	authErr error
	result identity.AuthResult
	loginErr error
	loginCalls int
	guestCalls int
	profileCalls int
	profile identity.Profile
	deleteCalls int
}
func (f *fakeService) Policies() identity.PolicyVersions { return identity.PolicyVersions{Terms:"test-1",Privacy:"test-1",Community:"test-1"} }
func (f *fakeService) Authenticate(context.Context,string,bool) (identity.Principal,error) { return f.principal,f.authErr }
func (f *fakeService) Current(context.Context,string) (identity.SessionDTO,error) { return f.result.Session,f.authErr }
func (f *fakeService) Login(context.Context,string,identity.LoginInput) (identity.AuthResult,error) { f.loginCalls++; return f.result,f.loginErr }
func (f *fakeService) StartGuest(context.Context,identity.GuestInput) (identity.AuthResult,error) { f.guestCalls++; return f.result,nil }
func (f *fakeService) UpdateProfile(_ context.Context,_ identity.Principal,p identity.Profile) (identity.OwnerDTO,error) {
	f.profileCalls++; f.profile = p
	if err := identity.ValidateProfile(p); err != nil { return identity.OwnerDTO{},err }
	p.Version++; return identity.OwnerDTO{Kind:identity.KindAccount,Profile:p},nil
}
func (f *fakeService) Delete(context.Context,identity.Principal,identity.DeleteInput) (identity.DeletionReceipt,error) {
	f.deleteCalls++
	return identity.DeletionReceipt{Receipt:strings.Repeat("r",43),AccessDisabled:true,TombstoneDurable:false,State:"pending_tombstone"},nil
}
func fixture(t *testing.T, origin string) (*Handler,*fakeService) {
	t.Helper()
	now := time.Date(2026,10,9,12,0,0,0,time.UTC)
	f := &fakeService{authErr:identity.ErrUnauthorized}
	f.result = identity.AuthResult{CookieToken:"COOKIE_SECRET_NEVER_IN_JSON",RecoveryCode:"RECOVERY_SHOWN_ONCE",Session:identity.SessionDTO{CSRFToken:"new-session-csrf",Identity:identity.OwnerDTO{Kind:identity.KindAccount,Profile:identity.Profile{Version:1,DisplayName:"Sample",Gender:identity.GenderOther},AbsoluteExpiresAt:now.Add(identity.SessionAbsoluteTTL)}}}
	h,err := New(Options{Service:f,PublicOrigin:origin,AllowInsecureLocalhost:true,Now:func()time.Time{return now}})
	if err != nil { t.Fatal(err) }; return h,f
}
func bootstrapFixture(t *testing.T,h *Handler) (*http.Cookie,string) {
	t.Helper()
	rr := httptest.NewRecorder(); h.ServeHTTP(rr,httptest.NewRequest("GET","/api/v1/auth/bootstrap",nil))
	if rr.Code != 200 { t.Fatalf("bootstrap %d",rr.Code) }
	var body struct { CSRF string `json:"csrf_token"` }; if err := json.Unmarshal(rr.Body.Bytes(),&body); err != nil { t.Fatal(err) }
	for _,cookie := range rr.Result().Cookies() { if cookie.Name == h.csrfCookie { return cookie,body.CSRF } }
	t.Fatal("missing anonymous CSRF cookie"); return nil,""
}
func request(h *Handler,method,path,body,csrf string,cookie *http.Cookie) *httptest.ResponseRecorder {
	r := httptest.NewRequest(method,path,strings.NewReader(body))
	r.Header.Set("Origin",h.origin); r.Header.Set("Content-Type","application/json"); r.Header.Set("X-CSRF-Token",csrf)
	if cookie != nil { r.AddCookie(cookie) }
	rr := httptest.NewRecorder(); h.ServeHTTP(rr,r); return rr
}
func accountFixture(t *testing.T) (*Handler,*fakeService,*http.Cookie) {
	h,f := fixture(t,"https://notitle.example")
	f.authErr = nil
	f.principal = identity.Principal{Kind:identity.KindAccount,CSRFToken:"account-csrf",AccountSession:identity.AccountSession{Account:identity.Account{ID:"PRIVATE_ACCOUNT_ID",Username:"owner_private",Profile:identity.Profile{Version:3,DisplayName:"Sample",Gender:identity.GenderOther,Bio:"Keep this",Topic:"work_culture",Professional:identity.ProfessionalProfile{Profession:"engineering"}}}}}
	return h,f,&http.Cookie{Name:h.sessionCookie,Value:"account-cookie"}
}

func TestHTTPSCookieAndNoBearerInBody(t *testing.T) {
	h,f := fixture(t,"https://notitle.example"); cookie,csrf := bootstrapFixture(t,h)
	if !cookie.Secure || !cookie.HttpOnly || cookie.SameSite != http.SameSiteLaxMode || cookie.Path != "/" || cookie.Domain != "" || !strings.HasPrefix(cookie.Name,"__Host-") { t.Fatal("unsafe anonymous cookie") }
	rr := request(h,"POST","/api/v1/auth/login",`{"username":"sample","password":"twelve valid characters"}`,csrf,cookie)
	if rr.Code != 200 || f.loginCalls != 1 || strings.Contains(rr.Body.String(),f.result.CookieToken) { t.Fatal("auth secret exposed or login failed") }
	var sessionCookie *http.Cookie
	for _,c := range rr.Result().Cookies() { if c.Name == "__Host-session" { sessionCookie = c } }
	if sessionCookie == nil || !sessionCookie.Secure || !sessionCookie.HttpOnly || sessionCookie.Domain != "" || sessionCookie.Path != "/" || sessionCookie.SameSite != http.SameSiteLaxMode { t.Fatal("unsafe session cookie") }
	if rr.Header().Get("Cache-Control") != "no-store" { t.Fatal("credential response cacheable") }
}

func TestInsecureCookiesRestrictedToExplicitLocalDevelopment(t *testing.T) {
	for _,origin := range []string{"http://notitle.example","ftp://localhost","http://localhost/path"} {
		if _,err := New(Options{Service:&fakeService{},PublicOrigin:origin,AllowInsecureLocalhost:true}); err == nil { t.Fatal("accepted insecure non-local origin") }
	}
	if _,err := New(Options{Service:&fakeService{},PublicOrigin:"http://localhost:5173"}); err == nil { t.Fatal("insecure cookie requires explicit development mode") }
	h,_ := fixture(t,"http://localhost:5173"); cookie,_ := bootstrapFixture(t,h)
	if cookie.Secure || strings.HasPrefix(cookie.Name,"__Host-") || !cookie.HttpOnly { t.Fatal("local-only cookie attributes wrong") }
}

func TestAnonymousCSRFOriginExpiryAndTamper(t *testing.T) {
	for _,scenario := range []string{"no-origin","cross-origin","cross-site","missing-header","tampered-cookie","expired"} {
		t.Run(scenario,func(t *testing.T){
			h,f := fixture(t,"https://notitle.example"); cookie,csrf := bootstrapFixture(t,h)
			r := httptest.NewRequest("POST","/api/v1/auth/login",strings.NewReader(`{"username":"sample","password":"sample password"}`))
			r.Header.Set("Origin",h.origin); r.Header.Set("Content-Type","application/json"); r.Header.Set("X-CSRF-Token",csrf)
			switch scenario { case "no-origin":r.Header.Del("Origin"); case "cross-origin":r.Header.Set("Origin","https://evil.example"); case "cross-site":r.Header.Set("Sec-Fetch-Site","cross-site"); case "missing-header":r.Header.Del("X-CSRF-Token"); case "tampered-cookie":cookie.Value += "x"; case "expired":prior := h.now(); h.now = func()time.Time{return prior.Add(csrfLifetime+time.Second)} }
			r.AddCookie(cookie); rr := httptest.NewRecorder(); h.ServeHTTP(rr,r)
			if rr.Code != 403 || f.loginCalls != 0 { t.Fatal("CSRF rejection occurred after service mutation") }
		})
	}
}

func TestAuthenticatedWritesRejectAnonymousCSRFAndMissingSession(t *testing.T) {
	h,f,cookie := accountFixture(t)
	for _,token := range []string{"","wrong-token"} {
		rr := request(h,"PATCH","/api/v1/me/profile",`{"version":3,"bio":"New"}`,token,cookie)
		if rr.Code != 403 || f.profileCalls != 0 { t.Fatal("missing authenticated CSRF accepted") }
	}
	rr := request(h,"PATCH","/api/v1/me/profile",`{"version":3,"bio":"New"}`,"account-csrf",nil)
	if rr.Code != 401 || f.profileCalls != 0 { t.Fatal("missing cookie accepted") }
}

func TestStrictJSONBeforeCredentialWork(t *testing.T) {
	for _,body := range []string{`null`,`[]`,`{"username":"sample","username":"other","password":"valid password"}`,`{"username":null,"password":"valid password"}`,`{"username":"sample","password":"valid password","email":"x@example.test"}`,`{"username":"sample","password":"valid password"}{}`} {
		h,f := fixture(t,"https://notitle.example"); cookie,csrf := bootstrapFixture(t,h)
		rr := request(h,"POST","/api/v1/auth/login",body,csrf,cookie)
		if rr.Code != 400 || f.loginCalls != 0 { t.Fatalf("invalid JSON reached login: %s",body) }
	}
	h,f := fixture(t,"https://notitle.example"); cookie,csrf := bootstrapFixture(t,h)
	rr := request(h,"POST","/api/v1/auth/login",strings.Repeat("x",8193),csrf,cookie)
	if rr.Code != 413 || f.loginCalls != 0 { t.Fatal("body bound missing") }
}

func TestPartialProfileRetainsGenderAndProfessionalFields(t *testing.T) {
	h,f,cookie := accountFixture(t)
	rr := request(h,"PATCH","/api/v1/me/profile",`{"version":3,"bio":"Updated"}`,"account-csrf",cookie)
	if rr.Code != 200 || f.profile.Gender != identity.GenderOther || f.profile.Professional.Profession != "engineering" || f.profile.Bio != "Updated" { t.Fatal("omitted profile fields were lost") }
	if strings.Contains(rr.Body.String(),"PRIVATE_ACCOUNT_ID") { t.Fatal("internal account ID leaked") }
	rr = request(h,"PATCH","/api/v1/me/profile",`{"version":3,"gender":""}`,"account-csrf",cookie)
	if rr.Code != 400 { t.Fatal("blank gender accepted") }
}

func TestSnapshotVersionGuardPrecedesMerge(t *testing.T) {
	for _,path := range []string{"/api/v1/me/profile","/api/v1/me/professional-profile"} {
		h,f,cookie := accountFixture(t)
		body := `{"version":4,"bio":"New"}`; if strings.Contains(path,"professional") { body = `{"version":4,"profession":"design"}` }
		rr := request(h,"PATCH",path,body,"account-csrf",cookie)
		if rr.Code != 409 || f.profileCalls != 0 { t.Fatal("a newer supplied version allowed a stale principal snapshot merge") }
	}
}

func TestProfessionalInterestsAreBoundedPrivateChoices(t *testing.T) {
	h,f,cookie := accountFixture(t)
	rr := request(h,"PATCH","/api/v1/me/professional-profile",`{"version":3,"interests":["career_growth","leadership"]}`,"account-csrf",cookie)
	if rr.Code != 200 || len(f.profile.Professional.Interests) != 2 || f.profile.Gender != identity.GenderOther { t.Fatal("private interest patch failed or discarded gender") }
	for _,body := range []string{`{"version":3,"interests":[["leadership"]]}`,`{"version":3,"interests":null}`,`{"version":3,"interests":["leadership","leadership"]}`,`{"version":3,"interests":["uncontrolled"]}`} {
		rr = request(h,"PATCH","/api/v1/me/professional-profile",body,"account-csrf",cookie)
		if rr.Code != 400 { t.Fatalf("unsupported interests accepted: %s",body) }
	}
	rr = request(h,"PATCH","/api/v1/me/professional-profile",`{"version":3,"interests":[]}`,"account-csrf",cookie)
	if rr.Code != 200 || len(f.profile.Professional.Interests) != 0 { t.Fatal("explicit empty interests cannot clear choices") }
}

func TestAnonymousBootstrapReusesValidCookieAcrossTabs(t *testing.T) {
	h,_ := fixture(t,"https://notitle.example"); cookie,csrf := bootstrapFixture(t,h)
	r := httptest.NewRequest("GET","/api/v1/auth/bootstrap",nil); r.AddCookie(cookie)
	rr := httptest.NewRecorder(); h.ServeHTTP(rr,r)
	var body struct { CSRF string `json:"csrf_token"` }; if err := json.Unmarshal(rr.Body.Bytes(),&body); err != nil { t.Fatal(err) }
	if rr.Code != 200 || body.CSRF != csrf || len(rr.Result().Cookies()) != 0 { t.Fatal("opening another entry form invalidated the first form") }
}

func TestCredentialLimiterBeforeHashAndGenericFailure(t *testing.T) {
	h,f := fixture(t,"https://notitle.example"); f.loginErr = identity.ErrCredentials; cookie,csrf := bootstrapFixture(t,h)
	for i := 0; i < 6; i++ {
		rr := request(h,"POST","/api/v1/auth/login",`{"username":"sample","password":"private password"}`,csrf,cookie)
		if i < 5 && (rr.Code != 401 || !strings.Contains(rr.Body.String(),"invalid_credentials")) { t.Fatal("credential response is not generic") }
		if i == 5 && (rr.Code != 429 || rr.Header().Get("Retry-After") == "") { t.Fatal("pre-hash limiter missing") }
		if strings.Contains(rr.Body.String(),"private password") || strings.Contains(rr.Body.String(),"sample") { t.Fatal("credential response leaked input") }
	}
	if f.loginCalls != 5 { t.Fatal("rate-limited attempt reached credential work") }
}

func TestDuplicateCookiesRejectedBeforeAuthentication(t *testing.T) {
	h,f := fixture(t,"https://notitle.example"); cookie,csrf := bootstrapFixture(t,h)
	r := httptest.NewRequest("POST","/api/v1/auth/login",strings.NewReader(`{"username":"sample","password":"sample password"}`))
	r.Header.Set("Origin",h.origin); r.Header.Set("Content-Type","application/json"); r.Header.Set("X-CSRF-Token",csrf)
	r.AddCookie(cookie); r.AddCookie(&http.Cookie{Name:h.sessionCookie,Value:"first"}); r.AddCookie(&http.Cookie{Name:h.sessionCookie,Value:"second"})
	rr := httptest.NewRecorder(); h.ServeHTTP(rr,r)
	if rr.Code != 403 || f.loginCalls != 0 { t.Fatal("ambiguous cookies accepted") }
}

func TestReadyFailureDoesNotFallBackToAnonymousIdentity(t *testing.T) {
	h,f := fixture(t,"https://notitle.example")
	h.ready = func(context.Context)error{return errors.New("PRIVATE restore barrier")}
	rr := httptest.NewRecorder(); h.ServeHTTP(rr,httptest.NewRequest("GET","/api/v1/auth/bootstrap",nil))
	if rr.Code != 503 || len(rr.Result().Cookies()) != 0 || f.guestCalls != 0 || strings.Contains(rr.Body.String(),"PRIVATE") { t.Fatal("restore gate failed open or leaked details") }
}

func TestDeletionClearsCookieButDoesNotClaimErasure(t *testing.T) {
	h,f,cookie := accountFixture(t)
	rr := request(h,"DELETE","/api/v1/me",`{"confirm":true}`,"account-csrf",cookie)
	if rr.Code != 202 || f.deleteCalls != 1 || !strings.Contains(rr.Body.String(),`"tombstone_durable":false`) || !strings.Contains(rr.Body.String(),`"access_disabled":true`) { t.Fatal("deletion receipt misrepresents pending durability") }
	found := false; for _,c := range rr.Result().Cookies() { if c.Name == h.sessionCookie && c.MaxAge < 0 { found = true } }; if !found { t.Fatal("deleted account browser credential retained") }
}

func TestLimiterBoundsAndNoTrustInForwardedHeaders(t *testing.T) {
	h,f := fixture(t,"https://notitle.example"); f.loginErr = identity.ErrCredentials; cookie,csrf := bootstrapFixture(t,h)
	for i := 0; i < 13; i++ {
		r := httptest.NewRequest("POST","/api/v1/auth/login",strings.NewReader(`{"username":"user`+strings.Repeat("a",i+1)+`","password":"sample password"}`))
		r.Header.Set("Origin",h.origin); r.Header.Set("Content-Type","application/json"); r.Header.Set("X-CSRF-Token",csrf); r.Header.Set("X-Forwarded-For",strings.Repeat("1",i+1)+".2.3.4"); r.AddCookie(cookie)
		rr := httptest.NewRecorder(); h.ServeHTTP(rr,r); if i == 12 && rr.Code != 429 { t.Fatal("global hashing budget bypassed through forged forwarding headers") }
	}
	if f.loginCalls != 12 { t.Fatal("unexpected hash budget") }
	l := limiter{entries:make(map[[32]byte]bucket)}; now := h.now()
	for i := 0; i < limiterCapacity; i++ { var key [32]byte; key[0] = byte(i); key[1] = byte(i>>8); l.entries[key] = bucket{updated:now,tokens:1} }
	if l.allow(now,"request","127.0.0.1:1234","") || len(l.entries) != limiterCapacity { t.Fatal("limiter map exceeded its bound") }
	if !l.allow(now.Add(limiterTTL+time.Second),"request","127.0.0.1:1234","") || len(l.entries) > 2 { t.Fatal("expired temporary limits not reclaimed") }
}

type fakeTicketIssuer struct{calls int;takeover bool}
func(f *fakeTicketIssuer)IssueTicket(_ context.Context,_ identity.Principal,takeover bool)(realtime.TicketResponse,error){f.calls++;f.takeover=takeover;return realtime.TicketResponse{Ticket:strings.Repeat("A",43),ProtocolVersion:1},nil}
func TestRealtimeTicketUsesExistingOriginCSRFAndCookieGuards(t *testing.T){
 h,_,cookie:=accountFixture(t);issuer:=&fakeTicketIssuer{};h.realtime=issuer
 denied:=request(h,"POST","/api/v1/realtime/ticket",`{"takeover":true}`,"wrong-csrf",cookie)
 if denied.Code!=403 || issuer.calls!=0{t.Fatal("ticket issued without CSRF")}
 allowed:=request(h,"POST","/api/v1/realtime/ticket",`{"takeover":true}`,"account-csrf",cookie)
 if allowed.Code!=201 || issuer.calls!=1 || !issuer.takeover{t.Fatal("ticket guard did not dispatch")}
 forged:=request(h,"POST","/api/v1/realtime/ticket",`{"takeover":false,"premium":true}`,"account-csrf",cookie)
 if forged.Code!=400 || issuer.calls!=1{t.Fatal("ticket accepted client authority")}
 if allowed.Header().Get("Cache-Control")!="no-store"{t.Fatal("ticket is cacheable")}
}
