package identityhttp

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"strconv"
	"strings"
	"time"
)

const csrfLifetime = 30 * time.Minute

// Anonymous CSRF is a signed, short-lived HttpOnly cookie plus a distinct
// response token. A random process key bounds its lifetime to this process;
// restart requires a fresh bootstrap, without retaining anonymous identities.
func (h *Handler) anonymousCSRF(now time.Time) (string, string, error) {
	var nonce [32]byte
	if _, err := rand.Read(nonce[:]); err != nil { return "", "", err }
	value := base64.RawURLEncoding.EncodeToString(nonce[:]) + "." + strconv.FormatInt(now.Add(csrfLifetime).Unix(), 10)
	value += "." + h.mac("cookie:", value)
	return value, h.mac("header:", value), nil
}

func (h *Handler) mac(purpose, value string) string {
	m := hmac.New(sha256.New, h.key[:])
	_, _ = m.Write([]byte(purpose))
	_, _ = m.Write([]byte(value))
	return base64.RawURLEncoding.EncodeToString(m.Sum(nil))
}

func (h *Handler) validAnonymousCSRF(cookie, token string, now time.Time) bool {
	if len(cookie) > 128 || len(token) != 43 { return false }
	parts := strings.Split(cookie, ".")
	if len(parts) != 3 || len(parts[0]) != 43 { return false }
	nonce, err := base64.RawURLEncoding.DecodeString(parts[0])
	if err != nil || len(nonce) != 32 { return false }
	expires, err := strconv.ParseInt(parts[1], 10, 64)
	if err != nil || expires <= now.Unix() || expires > now.Add(csrfLifetime).Unix() { return false }
	return sameSecret(parts[2], h.mac("cookie:", parts[0]+"."+parts[1])) && sameSecret(token, h.mac("header:", cookie))
}

func sameSecret(a, b string) bool {
	return len(a) > 0 && len(a) == len(b) && subtle.ConstantTimeCompare([]byte(a), []byte(b)) == 1
}
