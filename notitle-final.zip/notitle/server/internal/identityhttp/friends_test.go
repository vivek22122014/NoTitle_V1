package identityhttp

import (
	"context"
	"net/http"
	"strings"
	"testing"

	"notitle/internal/friendtypes"
	"notitle/internal/identity"
)

type fakeFriends struct { calls int; ref string; err error }
func (f *fakeFriends) ListFriends(context.Context,identity.Principal)([]friendtypes.View,error) {f.calls++;return nil,f.err}
func (f *fakeFriends) RemoveFriend(_ context.Context,_ identity.Principal,ref string)error {f.calls++;f.ref=ref;return f.err}

func TestFriendsRequireAuthenticationAndRemovalCSRF(t *testing.T) {
	h,_,cookie:=accountFixture(t);service:=&fakeFriends{};h.friends=service
	path:="/api/v1/friends/"+strings.Repeat("opaque_",4)
	if r:=request(h,http.MethodGet,"/api/v1/friends","","",nil);r.Code!=401 {t.Fatal("friend presence exposed without a session")}
	if r:=request(h,http.MethodDelete,path,`{}`,"wrong",cookie);r.Code!=403 {t.Fatal("friend removal accepted invalid CSRF")}
	if r:=request(h,http.MethodDelete,path,`{}`,"account-csrf",nil);r.Code!=401 {t.Fatal("friend removal accepted missing session")}
	if service.calls!=0 {t.Fatal("friend operations ran before authorization")}
	if r:=request(h,http.MethodGet,"/api/v1/friends","","",cookie);r.Code!=200 || r.Body.String()!="{\"friends\":[]}\n" {t.Fatal("empty private friends list rejected")}
}
func TestFriendRemovalOnlyAcceptsScopedHandle(t *testing.T) {
	h,_,cookie:=accountFixture(t);service:=&fakeFriends{};h.friends=service
	ref:=strings.Repeat("opaque_",4);path:="/api/v1/friends/"+ref
	if !h.Owns(path) || h.Owns(path+"/nested") || h.Owns("/api/v1/friends/x") {t.Fatal("unbounded friend reference route")}
	if r:=request(h,http.MethodDelete,path,`{"peer_id":"forged"}`,"account-csrf",cookie);r.Code!=400 || service.calls!=0 {t.Fatal("client-selected peer reached removal service")}
	if r:=request(h,http.MethodDelete,path,`{}`,"account-csrf",cookie);r.Code!=200 || service.ref!=ref {t.Fatal("scoped removal failed")}
	service.err=friendtypes.ErrNotFound
	if r:=request(h,http.MethodDelete,path,`{}`,"account-csrf",cookie);r.Code!=404 || !strings.Contains(r.Body.String(),"not_found") {t.Fatal("foreign or missing reference was not normalized")}
	service.err=friendtypes.ErrUnavailable
	if r:=request(h,http.MethodDelete,path,`{}`,"account-csrf",cookie);r.Code!=503 || strings.Contains(r.Body.String(),"removed") {t.Fatal("failed storage operation acknowledged removal")}
}
