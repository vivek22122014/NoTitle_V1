package identityhttp

import (
	"context"
	"net/http"
	"strings"

	"notitle/internal/httpserver/apierror"
	"notitle/internal/identity"
	"notitle/internal/safetytypes"
)

type SafetyService interface {
	BeginReport(context.Context,identity.Principal,safetytypes.BeginReportRequest)(safetytypes.DraftView,error)
	SubmitReport(context.Context,identity.Principal,safetytypes.SubmitReportRequest)(safetytypes.ReportReceipt,error)
	ListBlocks(context.Context,identity.Principal)([]safetytypes.BlockView,error)
	Block(context.Context,identity.Principal,safetytypes.BlockRequest)(safetytypes.BlockView,error)
	Unblock(context.Context,identity.Principal,string)error
}

func blockReference(path string) string {
	const prefix = "/api/v1/blocks/"
	if !strings.HasPrefix(path,prefix) { return "" }
	ref := strings.TrimPrefix(path,prefix)
	if len(ref) < 16 || len(ref) > 128 { return "" }
	for _,r := range ref { if !(r >= 'a' && r <= 'z' || r >= 'A' && r <= 'Z' || r >= '0' && r <= '9' || r == '_' || r == '-') { return "" } }
	return ref
}
func (h *Handler) beginReport(w http.ResponseWriter,r *http.Request) {
	if h.safety == nil { h.fail(w,r,apierror.Unavailable); return }
	p,ok := h.mutation(w,r,false); if !ok { return }
	var input safetytypes.BeginReportRequest
	if !h.decode(w,r,&input) { return }
	result,err := h.safety.BeginReport(r.Context(),p,input)
	if err != nil { h.fail(w,r,err); return }
	h.json(w,http.StatusCreated,result)
}
func (h *Handler) submitReport(w http.ResponseWriter,r *http.Request) {
	if h.safety == nil { h.fail(w,r,apierror.Unavailable); return }
	p,ok := h.mutation(w,r,false); if !ok { return }
	var input safetytypes.SubmitReportRequest
	if !h.decode(w,r,&input) { return }
	result,err := h.safety.SubmitReport(r.Context(),p,input)
	if err != nil { h.fail(w,r,err); return }
	h.json(w,http.StatusCreated,result)
}
func (h *Handler) listBlocks(w http.ResponseWriter,r *http.Request) {
	if h.safety == nil { h.fail(w,r,apierror.Unavailable); return }
	p,err := h.service.Authenticate(r.Context(),h.session(r),false)
	if err != nil { h.fail(w,r,err); return }
	blocks,err := h.safety.ListBlocks(r.Context(),p)
	if err != nil { h.fail(w,r,err); return }
	if blocks == nil { blocks = []safetytypes.BlockView{} }
	h.json(w,http.StatusOK,struct { Blocks []safetytypes.BlockView `json:"blocks"` }{blocks})
}
func (h *Handler) blockPeer(w http.ResponseWriter,r *http.Request) {
	if h.safety == nil { h.fail(w,r,apierror.Unavailable); return }
	p,ok := h.mutation(w,r,false); if !ok { return }
	var input safetytypes.BlockRequest
	if !h.decode(w,r,&input) { return }
	result,err := h.safety.Block(r.Context(),p,input)
	if err != nil { h.fail(w,r,err); return }
	h.json(w,http.StatusCreated,result)
}
func (h *Handler) unblock(w http.ResponseWriter,r *http.Request) {
	if h.safety == nil { h.fail(w,r,apierror.Unavailable); return }
	p,ok := h.mutation(w,r,false); if !ok { return }
	var input struct{}
	if !h.decode(w,r,&input) { return }
	if err := h.safety.Unblock(r.Context(),p,blockReference(r.URL.Path)); err != nil { h.fail(w,r,err); return }
	h.json(w,http.StatusOK,struct { Removed bool `json:"removed"` }{true})
}
