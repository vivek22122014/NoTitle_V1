package identityhttp

import (
 "net/http"

 "notitle/internal/httpserver/apierror"
 "notitle/internal/realtime"
)

func (h *Handler) realtimeTicket(w http.ResponseWriter,r *http.Request) {
 if h.realtime==nil {h.fail(w,r,apierror.Unavailable);return}
 p,ok:=h.mutation(w,r,false);if !ok{return}
 var input struct{Takeover bool `json:"takeover"`}
 if !h.decode(w,r,&input)||!h.limit(w,r,"realtime-ticket",string(p.TokenHash[:])){return}
 result,err:=h.realtime.IssueTicket(r.Context(),p,input.Takeover);if err!=nil{h.fail(w,r,err);return}
 h.json(w,http.StatusCreated,result)
}
func (h *Handler) matchingPreferences(w http.ResponseWriter,r *http.Request) {
 if h.preferences==nil {h.fail(w,r,apierror.Unavailable);return}
 p,err:=h.service.Authenticate(r.Context(),h.session(r),false);if err!=nil{h.fail(w,r,err);return}
 result,err:=h.preferences.GetPreferences(r.Context(),p);if err!=nil{h.fail(w,r,err);return}
 h.json(w,http.StatusOK,result)
}
func (h *Handler) patchMatchingPreferences(w http.ResponseWriter,r *http.Request) {
 if h.preferences==nil {h.fail(w,r,apierror.Unavailable);return}
 p,ok:=h.mutation(w,r,false);if !ok{return}
 var input realtime.Preferences;if !h.decode(w,r,&input){return}
 result,err:=h.preferences.UpdatePreferences(r.Context(),p,input);if err!=nil{h.fail(w,r,err);return}
 h.json(w,http.StatusOK,result)
}
