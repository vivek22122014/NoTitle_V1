package identityhttp

import (
	"errors"
	"net/http"
	"time"

	"notitle/internal/httpserver/apierror"
	"notitle/internal/identity"
)

func (h *Handler) bootstrap(w http.ResponseWriter,r *http.Request) {
	csrf := ""
	if token := h.session(r); token != "" {
		current,err := h.service.Current(r.Context(),token)
		if err == nil { csrf = current.CSRFToken } else if errors.Is(err,identity.ErrUnauthorized) || errors.Is(err,identity.ErrStale) { h.clearCookie(w,h.sessionCookie) } else { h.fail(w,r,err); return }
	}
	if csrf == "" {
		cookie := h.cookie(r,h.csrfCookie)
		token := h.mac("header:",cookie)
		if h.validAnonymousCSRF(cookie,token,h.now()) { csrf = token } else {
			cookie,token,err := h.anonymousCSRF(h.now()); if err != nil { h.fail(w,r,apierror.Unavailable); return }
			h.setCookie(w,h.csrfCookie,cookie,h.now().Add(csrfLifetime)); csrf = token
		}
	}
	h.json(w,http.StatusOK,struct {
		CSRFToken string `json:"csrf_token"`
		Policies identity.PolicyVersions `json:"policies"`
		Vocabularies identity.Vocabulary `json:"vocabularies"`
	}{csrf,h.service.Policies(),identity.Vocabularies()})
}
func (h *Handler) current(w http.ResponseWriter,r *http.Request) {
	result,err := h.service.Current(r.Context(),h.session(r)); if err != nil { h.fail(w,r,err); return }
	h.json(w,http.StatusOK,result)
}
func (h *Handler) authSuccess(w http.ResponseWriter,status int,result identity.AuthResult) {
	h.setCookie(w,h.sessionCookie,result.CookieToken,result.Session.Identity.AbsoluteExpiresAt)
	h.clearCookie(w,h.csrfCookie)
	h.json(w,status,struct {
		identity.SessionDTO
		RecoveryCode string `json:"recovery_code,omitempty"`
		HandoffState string `json:"handoff_state,omitempty"`
	}{result.Session,result.RecoveryCode,result.HandoffState})
}
func (h *Handler) startGuest(w http.ResponseWriter,r *http.Request) {
	p,ok := h.mutation(w,r,true); if !ok { return }
	if p.Kind != "" { h.fail(w,r,apierror.Conflict); return }
	var input identity.GuestInput; if !h.decode(w,r,&input) || !h.limit(w,r,"guest","") { return }
	result,err := h.service.StartGuest(r.Context(),input); if err != nil { h.fail(w,r,err); return }
	h.authSuccess(w,http.StatusCreated,result)
}
func (h *Handler) register(w http.ResponseWriter,r *http.Request) {
	p,ok := h.mutation(w,r,true); if !ok { return }
	if p.Kind == identity.KindAccount { h.fail(w,r,apierror.Conflict); return }
	var input identity.RegisterInput; if !h.decode(w,r,&input) || !h.limit(w,r,"hash",input.Username) { return }
	currentCookie := ""; if p.Kind == identity.KindGuest { currentCookie = h.session(r) }
	result,err := h.service.Register(r.Context(),currentCookie,input); if err != nil { h.fail(w,r,err); return }
	h.authSuccess(w,http.StatusCreated,result)
}
func (h *Handler) login(w http.ResponseWriter,r *http.Request) {
	if _,ok := h.mutation(w,r,true); !ok { return }
	var input identity.LoginInput; if !h.decode(w,r,&input) || !h.limit(w,r,"hash",input.Username) { return }
	result,err := h.service.Login(r.Context(),h.session(r),input); if err != nil { h.fail(w,r,err); return }
	h.authSuccess(w,http.StatusOK,result)
}
func (h *Handler) recover(w http.ResponseWriter,r *http.Request) {
	if _,ok := h.mutation(w,r,true); !ok { return }
	var input identity.RecoveryInput; if !h.decode(w,r,&input) || !h.limit(w,r,"hash",input.Username) { return }
	result,err := h.service.Recover(r.Context(),h.session(r),input); if err != nil { h.fail(w,r,err); return }
	h.authSuccess(w,http.StatusOK,result)
}

type profilePatch struct {
	Version int64 `json:"version"`
	DisplayName *string `json:"display_name"`
	Gender *identity.Gender `json:"gender"`
	Bio *string `json:"bio"`
	Topic *string `json:"topic"`
}
func principalProfile(p identity.Principal) identity.Profile {
	if p.Kind == identity.KindGuest { return p.Guest.Profile }; return p.AccountSession.Account.Profile
}
func (h *Handler) patchProfile(w http.ResponseWriter,r *http.Request) {
	p,ok := h.mutation(w,r,false); if !ok { return }
	var input profilePatch; if !h.decode(w,r,&input) { return }
	if input.Version < 1 || (input.DisplayName == nil && input.Gender == nil && input.Bio == nil && input.Topic == nil) { h.fail(w,r,apierror.Invalid); return }
	profile := principalProfile(p)
	if input.Version != profile.Version { h.fail(w,r,identity.ErrStale); return }
	if input.DisplayName != nil { profile.DisplayName = *input.DisplayName }
	if input.Gender != nil { profile.Gender = *input.Gender }
	if input.Bio != nil { profile.Bio = *input.Bio }
	if input.Topic != nil { profile.Topic = *input.Topic }
	owner,err := h.service.UpdateProfile(r.Context(),p,profile); if err != nil { h.fail(w,r,err); return }
	h.json(w,http.StatusOK,owner)
}
type professionalPatch struct {
	Version int64 `json:"version"`
	Profession *string `json:"profession"`
	Industry *string `json:"industry"`
	Experience *string `json:"experience"`
	Interests *[]string `json:"interests"`
}
func (h *Handler) patchProfessional(w http.ResponseWriter,r *http.Request) {
	p,ok := h.mutation(w,r,false); if !ok { return }
	var input professionalPatch; if !h.decode(w,r,&input) { return }
	if input.Version < 1 || (input.Profession == nil && input.Industry == nil && input.Experience == nil && input.Interests == nil) { h.fail(w,r,apierror.Invalid); return }
	profile := principalProfile(p)
	if input.Version != profile.Version { h.fail(w,r,identity.ErrStale); return }
	if input.Profession != nil { profile.Professional.Profession = *input.Profession }
	if input.Industry != nil { profile.Professional.Industry = *input.Industry }
	if input.Experience != nil { profile.Professional.Experience = *input.Experience }
	if input.Interests != nil { profile.Professional.Interests = append([]string{},(*input.Interests)... ) }
	owner,err := h.service.UpdateProfile(r.Context(),p,profile); if err != nil { h.fail(w,r,err); return }
	h.json(w,http.StatusOK,owner)
}
func (h *Handler) accountMutation(w http.ResponseWriter,r *http.Request) (identity.Principal,bool) {
	p,ok := h.mutation(w,r,false); if !ok { return p,false }
	if p.Kind != identity.KindAccount { h.fail(w,r,apierror.Unauthorized); return p,false }
	return p,true
}
func (h *Handler) reauthenticate(w http.ResponseWriter,r *http.Request) {
	p,ok := h.accountMutation(w,r); if !ok { return }
	var input identity.ReauthenticateInput; if !h.decode(w,r,&input) || !h.limit(w,r,"hash",p.AccountSession.Account.Username) { return }
	until,err := h.service.Reauthenticate(r.Context(),p,input); if err != nil { h.fail(w,r,err); return }
	h.json(w,http.StatusOK,struct { Until time.Time `json:"reauthentication_until"` }{until})
}
func (h *Handler) changePassword(w http.ResponseWriter,r *http.Request) {
	p,ok := h.accountMutation(w,r); if !ok { return }
	var input identity.PasswordInput; if !h.decode(w,r,&input) || !h.limit(w,r,"hash",p.AccountSession.Account.Username) { return }
	result,err := h.service.ChangePassword(r.Context(),p,input); if err != nil { h.fail(w,r,err); return }
	h.authSuccess(w,http.StatusOK,result)
}
func (h *Handler) emptyBody(w http.ResponseWriter,r *http.Request) bool { var input struct{}; return h.decode(w,r,&input) }
func (h *Handler) rotateRecovery(w http.ResponseWriter,r *http.Request) {
	p,ok := h.accountMutation(w,r); if !ok || !h.emptyBody(w,r) { return }
	result,err := h.service.RotateRecovery(r.Context(),p); if err != nil { h.fail(w,r,err); return }
	h.authSuccess(w,http.StatusOK,result)
}
func (h *Handler) signedOut(w http.ResponseWriter) {
	h.clearCookie(w,h.sessionCookie); h.clearCookie(w,h.csrfCookie)
	h.json(w,http.StatusOK,struct { Status string `json:"status"` }{"signed_out"})
}
func (h *Handler) endGuest(w http.ResponseWriter,r *http.Request) {
	p,ok := h.mutation(w,r,false); if !ok || !h.emptyBody(w,r) { return }
	if p.Kind != identity.KindGuest { h.fail(w,r,apierror.Conflict); return }
	if err := h.service.Logout(r.Context(),p); err != nil { h.fail(w,r,err); return }; h.signedOut(w)
}
func (h *Handler) logout(w http.ResponseWriter,r *http.Request) {
	p,ok := h.mutation(w,r,false); if !ok || !h.emptyBody(w,r) { return }
	if err := h.service.Logout(r.Context(),p); err != nil { h.fail(w,r,err); return }; h.signedOut(w)
}
func (h *Handler) logoutAll(w http.ResponseWriter,r *http.Request) {
	p,ok := h.accountMutation(w,r); if !ok || !h.emptyBody(w,r) { return }
	if err := h.service.LogoutAll(r.Context(),p); err != nil { h.fail(w,r,err); return }; h.signedOut(w)
}
func (h *Handler) deleteAccount(w http.ResponseWriter,r *http.Request) {
	p,ok := h.accountMutation(w,r); if !ok { return }
	var input identity.DeleteInput; if !h.decode(w,r,&input) { return }
	result,err := h.service.Delete(r.Context(),p,input); if err != nil { h.fail(w,r,err); return }
	h.clearCookie(w,h.sessionCookie); h.clearCookie(w,h.csrfCookie)
	h.json(w,http.StatusAccepted,result)
}
func (h *Handler) deletionStatus(w http.ResponseWriter,r *http.Request) {
	if _,ok := h.mutation(w,r,true); !ok { return }
	var input struct { Receipt string `json:"receipt"` }; if !h.decode(w,r,&input) { return }
	if len(input.Receipt) < 32 || len(input.Receipt) > 128 { h.fail(w,r,apierror.Invalid); return }
	result,err := h.service.DeletionStatus(r.Context(),input.Receipt); if err != nil { h.fail(w,r,err); return }
	result.Receipt = "" // Status never returns the bearer secret a second time.
	h.json(w,http.StatusOK,result)
}
