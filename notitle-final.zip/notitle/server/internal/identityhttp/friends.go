package identityhttp

import (
	"context"
	"net/http"
	"strings"

	"notitle/internal/friendtypes"
	"notitle/internal/httpserver/apierror"
	"notitle/internal/identity"
)

type FriendsService interface {
	ListFriends(context.Context,identity.Principal)([]friendtypes.View,error)
	RemoveFriend(context.Context,identity.Principal,string)error
}
func friendReference(path string) string {
	const prefix="/api/v1/friends/"
	if !strings.HasPrefix(path,prefix) {return ""}
	ref:=strings.TrimPrefix(path,prefix)
	if !friendtypes.ValidRef(ref) {return ""}
	return ref
}
func (h *Handler) listFriends(w http.ResponseWriter,r *http.Request) {
	if h.friends==nil {h.fail(w,r,apierror.Unavailable);return}
	p,err:=h.service.Authenticate(r.Context(),h.session(r),false)
	if err!=nil {h.fail(w,r,err);return}
	values,err:=h.friends.ListFriends(r.Context(),p)
	if err!=nil {h.fail(w,r,err);return}
	if values==nil {values=[]friendtypes.View{}}
	h.json(w,http.StatusOK,struct{Friends []friendtypes.View `json:"friends"`}{values})
}
func (h *Handler) removeFriend(w http.ResponseWriter,r *http.Request) {
	if h.friends==nil {h.fail(w,r,apierror.Unavailable);return}
	p,ok:=h.mutation(w,r,false);if !ok {return}
	var input struct{}
	if !h.decode(w,r,&input) {return}
	if err:=h.friends.RemoveFriend(r.Context(),p,friendReference(r.URL.Path));err!=nil {h.fail(w,r,err);return}
	h.json(w,http.StatusOK,struct{Removed bool `json:"removed"`}{true})
}
