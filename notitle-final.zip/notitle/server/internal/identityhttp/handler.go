// Package identityhttp is the bounded, same-origin transport for Phase 3.
// It serializes explicit projections only, never domain persistence records.
package identityhttp

import (
	"context"
	"crypto/rand"
	"encoding/json"
	"errors"
	"io"
	"mime"
	"net/http"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"

	"notitle/internal/httpserver/apierror"
	"notitle/internal/httpserver/middleware"
	"notitle/internal/identity"
 "notitle/internal/billing"
 "notitle/internal/realtime"
 "notitle/internal/safetytypes"
 "notitle/internal/friendtypes"
)

type Service interface {
	Policies() identity.PolicyVersions
	StartGuest(context.Context, identity.GuestInput) (identity.AuthResult, error)
	Register(context.Context, string, identity.RegisterInput) (identity.AuthResult, error)
	Login(context.Context, string, identity.LoginInput) (identity.AuthResult, error)
	Recover(context.Context, string, identity.RecoveryInput) (identity.AuthResult, error)
	Authenticate(context.Context, string, bool) (identity.Principal, error)
	Current(context.Context, string) (identity.SessionDTO, error)
	UpdateProfile(context.Context, identity.Principal, identity.Profile) (identity.OwnerDTO, error)
	Reauthenticate(context.Context, identity.Principal, identity.ReauthenticateInput) (time.Time, error)
	ChangePassword(context.Context, identity.Principal, identity.PasswordInput) (identity.AuthResult, error)
	RotateRecovery(context.Context, identity.Principal) (identity.AuthResult, error)
	Logout(context.Context, identity.Principal) error
	LogoutAll(context.Context, identity.Principal) error
	Delete(context.Context, identity.Principal, identity.DeleteInput) (identity.DeletionReceipt, error)
	DeletionStatus(context.Context, string) (identity.DeletionReceipt, error)
}

type TicketIssuer interface { IssueTicket(context.Context,identity.Principal,bool)(realtime.TicketResponse,error) }

type Options struct {
 Billing BillingService
 Friends FriendsService
 Safety SafetyService
 Realtime TicketIssuer
 Preferences realtime.PreferenceStore
	Service Service
	PublicOrigin string
	AllowInsecureLocalhost bool
	Ready func(context.Context) error
	Now func() time.Time
}
type Handler struct {
 billing BillingService
 friends FriendsService
 safety SafetyService
 realtime TicketIssuer
 preferences realtime.PreferenceStore
	service Service
	origin string
	secure bool
	sessionCookie string
	csrfCookie string
	key [32]byte
	limits limiter
	now func() time.Time
	ready func(context.Context) error
	routes map[string]map[string]http.HandlerFunc
}

func New(opts Options) (*Handler, error) {
	u, err := url.Parse(opts.PublicOrigin)
	if err != nil || u.Hostname() == "" || u.User != nil || u.Path != "" || u.RawQuery != "" || u.Fragment != "" || u.Opaque != "" || u.ForceQuery || strings.Contains(opts.PublicOrigin, "#") {
		return nil, errors.New("identity HTTP requires a valid origin")
	}
	secure := u.Scheme == "https"
	local := u.Hostname() == "localhost" || u.Hostname() == "127.0.0.1" || u.Hostname() == "::1"
	if !secure && !(opts.AllowInsecureLocalhost && local && u.Scheme == "http") { return nil, errors.New("identity HTTP requires HTTPS except explicit localhost development") }
	if opts.Service == nil { return nil, errors.New("identity HTTP requires a service") }
	h := &Handler{billing:opts.Billing, friends:opts.Friends, safety:opts.Safety, realtime:opts.Realtime, preferences:opts.Preferences, service:opts.Service, origin:opts.PublicOrigin, secure:secure, ready:opts.Ready, now:opts.Now, sessionCookie:"__Host-session", csrfCookie:"__Host-notitle-csrf"}
	if !secure { h.sessionCookie = "notitle_dev_session"; h.csrfCookie = "notitle_dev_csrf" }
	if h.now == nil { h.now = time.Now }
	if _, err := rand.Read(h.key[:]); err != nil { return nil, errors.New("identity HTTP entropy unavailable") }
	h.limits = limiter{key:h.key, entries:make(map[[32]byte]bucket)}
	h.routes = map[string]map[string]http.HandlerFunc{
  "/api/v1/premium/plans": {http.MethodGet:h.premiumPlans},
  "/api/v1/me/premium": {http.MethodGet:h.premiumCurrent},
  "/api/v1/me/orders": {http.MethodGet:h.paymentOrders},
  "/api/v1/me/receipts": {http.MethodGet:h.paymentReceipts},
  "/api/v1/payments/orders": {http.MethodPost:h.paymentCreate},
  "/api/v1/payments/checkout": {http.MethodPost:h.paymentResume},
  "/api/v1/payments/verify": {http.MethodPost:h.paymentVerify},
		"/api/v1/friends": {http.MethodGet:h.listFriends},
		"/api/v1/reports/begin": {http.MethodPost:h.beginReport},
		"/api/v1/reports": {http.MethodPost:h.submitReport},
		"/api/v1/blocks": {http.MethodGet:h.listBlocks,http.MethodPost:h.blockPeer},
		"/api/v1/auth/bootstrap": {http.MethodGet:h.bootstrap},
 "/api/v1/realtime/ticket": {http.MethodPost:h.realtimeTicket},
 "/api/v1/me/matching-preferences": {http.MethodGet:h.matchingPreferences,http.MethodPatch:h.patchMatchingPreferences},
		"/api/v1/guest/session": {http.MethodPost:h.startGuest, http.MethodDelete:h.endGuest},
		"/api/v1/auth/register": {http.MethodPost:h.register},
		"/api/v1/auth/login": {http.MethodPost:h.login},
		"/api/v1/auth/recover": {http.MethodPost:h.recover},
		"/api/v1/me": {http.MethodGet:h.current, http.MethodDelete:h.deleteAccount},
		"/api/v1/me/profile": {http.MethodPatch:h.patchProfile},
		"/api/v1/me/professional-profile": {http.MethodPatch:h.patchProfessional},
		"/api/v1/auth/reauthenticate": {http.MethodPost:h.reauthenticate},
		"/api/v1/auth/change-password": {http.MethodPost:h.changePassword},
		"/api/v1/auth/recovery-code": {http.MethodPost:h.rotateRecovery},
		"/api/v1/auth/logout": {http.MethodPost:h.logout},
		"/api/v1/auth/logout-all": {http.MethodPost:h.logoutAll},
		"/api/v1/account/deletion/status": {http.MethodPost:h.deletionStatus},
	}
	return h, nil
}

func (h *Handler) Owns(path string) bool { _, ok := h.routes[path]; payment,_:=paymentReference(path); return ok || payment!="" || receiptReference(path)!="" || blockReference(path) != "" || friendReference(path) != "" }
func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Vary", "Cookie, Origin")
	methods, ok := h.routes[r.URL.Path]
 if payment,_:=paymentReference(r.URL.Path); !ok && payment!="" { methods=map[string]http.HandlerFunc{http.MethodGet:h.paymentDetail};ok=true }
 if !ok && receiptReference(r.URL.Path)!="" {methods=map[string]http.HandlerFunc{http.MethodGet:h.paymentReceipt};ok=true}
	if !ok && blockReference(r.URL.Path) != "" { methods = map[string]http.HandlerFunc{http.MethodDelete:h.unblock}; ok = true }
	if !ok && friendReference(r.URL.Path) != "" { methods = map[string]http.HandlerFunc{http.MethodDelete:h.removeFriend}; ok = true }
	if !ok { h.fail(w,r,apierror.NotFound); return }
	handler, ok := methods[r.Method]
	if !ok {
		allowed := make([]string,0,len(methods)); for method := range methods { allowed = append(allowed,method) }; sort.Strings(allowed)
		w.Header().Set("Allow", strings.Join(allowed,", ")); h.fail(w,r,apierror.MethodNotAllowed); return
	}
	r.Pattern = r.Method+" "+r.URL.Path // Replaced below for every scoped reference.
 if payment,refunds:=paymentReference(r.URL.Path);payment!="" {r.Pattern="GET /api/v1/payments/{purchaseRef}";if refunds{r.Pattern+="/refunds"}}
 if receiptReference(r.URL.Path)!="" {r.Pattern="GET /api/v1/me/receipts/{purchaseRef}"}
	if blockReference(r.URL.Path) != "" { r.Pattern = "DELETE /api/v1/blocks/{blockRef}" }
	if friendReference(r.URL.Path) != "" { r.Pattern = "DELETE /api/v1/friends/{friendRef}" }
	counts := map[string]int{}
	for _, cookie := range r.Cookies() {
		if cookie.Name == h.sessionCookie || cookie.Name == h.csrfCookie {
			counts[cookie.Name]++
			if counts[cookie.Name] > 1 { h.fail(w,r,apierror.Forbidden); return }
		}
	}
	if r.URL.RawQuery != "" || r.URL.ForceQuery { h.fail(w,r,apierror.Invalid); return }
	if len(r.Header.Values("Origin"))>1 { h.fail(w,r,apierror.Forbidden); return }
 if origin := r.Header.Get("Origin"); origin != "" && origin != h.origin { h.fail(w,r,apierror.Forbidden); return }
	if r.Header.Get("Sec-Fetch-Site") == "cross-site" { h.fail(w,r,apierror.Forbidden); return }
	if r.Method != http.MethodGet && r.Header.Get("Origin") != h.origin { h.fail(w,r,apierror.Forbidden); return }
	if !h.limit(w,r,"request","") { return }
	if h.ready != nil && h.ready(r.Context()) != nil { h.fail(w,r,apierror.Unavailable); return }
	handler(w,r)
}

func (h *Handler) limit(w http.ResponseWriter, r *http.Request, category, subject string) bool {
	if h.limits.allow(h.now(),category,r.RemoteAddr,subject) { return true }
	w.Header().Set("Retry-After", "60"); h.fail(w,r,apierror.RateLimited); return false
}
func (h *Handler) fail(w http.ResponseWriter,r *http.Request,err error) {
	public := apierror.Internal
	var known apierror.Error
	var safetyError *safetytypes.Error
	var friendError *friendtypes.Error
	switch {
	case errors.As(err,&known): public = known
	case errors.As(err,&friendError):
		switch friendError.Code {
		case "INVALID_REQUEST": public = apierror.Invalid
		case "AUTHENTICATION_REQUIRED": public = apierror.Unauthorized
		case "NOT_FOUND": public = apierror.NotFound
		case "STALE_EPOCH": public = apierror.StaleInteraction
		case "CONFLICT": public = apierror.FriendConflict
		case "CAPACITY_REACHED": public = apierror.FriendCapacity
		case "BUSY": public = apierror.RateLimited
		default: public = apierror.Unavailable
		}
	case errors.As(err,&safetyError):
		switch safetyError.Code {
		case "INVALID_REQUEST": public = apierror.Invalid
		case "AUTHENTICATION_REQUIRED": public = apierror.Unauthorized
		case "REPORT_EXPIRED": public = apierror.ReportExpired
		case "STALE_EPOCH": public = apierror.StaleInteraction
		case "CONFLICT": public = apierror.SafetyConflict
		case "BUSY", "CAPACITY_REACHED": public = apierror.RateLimited
		default: public = apierror.Unavailable
		}
	case errors.Is(err,billing.ErrDisabled): public=apierror.CheckoutUnavailable
 case errors.Is(err,billing.ErrConflict): public=apierror.BillingConflict
 case errors.Is(err,billing.ErrReview): public=apierror.PaymentReview
 case errors.Is(err,billing.ErrNotFound): public=apierror.NotFound
 case errors.Is(err,billing.ErrInvalid): public=apierror.Invalid
 case errors.Is(err,billing.ErrUnavailable): public=apierror.Unavailable
 case errors.Is(err,realtime.ErrPremiumRequired): public = apierror.PremiumRequired
 case errors.Is(err,realtime.ErrUnavailable): public = apierror.Unavailable
 case errors.Is(err,realtime.ErrUnauthorized): public = apierror.Unauthorized
 case errors.Is(err,realtime.ErrCapacity): public = apierror.RateLimited
 case errors.Is(err,realtime.ErrRateLimited): public = apierror.RateLimited
 case errors.Is(err,realtime.ErrProtocol): public = apierror.Invalid
 case errors.Is(err,identity.ErrInvalid): public = apierror.Invalid
	case errors.Is(err,identity.ErrCredentials): public = apierror.Credentials
	case errors.Is(err,identity.ErrUnauthorized): public = apierror.Unauthorized
	case errors.Is(err,identity.ErrReauthentication): public = apierror.Reauthentication
	case errors.Is(err,identity.ErrStale): public = apierror.Stale
	case errors.Is(err,identity.ErrConflict): public = apierror.Conflict
	case errors.Is(err,identity.ErrHandoff): public = apierror.Handoff
	case errors.Is(err,identity.ErrBusy),errors.Is(err,identity.ErrCapacity): public = apierror.RateLimited; w.Header().Set("Retry-After","60")
	case errors.Is(err,identity.ErrUnavailable),errors.Is(err,context.DeadlineExceeded),errors.Is(err,context.Canceled): public = apierror.Unavailable
	}
	apierror.Write(w,middleware.RequestIDFromContext(r.Context()),public)
}
func (h *Handler) json(w http.ResponseWriter,status int,value any) {
	w.WriteHeader(status); _ = json.NewEncoder(w).Encode(value)
}

func (h *Handler) cookie(r *http.Request,name string) string {
	value := ""; count := 0
	for _, cookie := range r.Cookies() { if cookie.Name == name { count++; value = cookie.Value } }
	if count != 1 || len(value) > 256 { return "" }
	return value
}
func (h *Handler) session(r *http.Request) string { return h.cookie(r,h.sessionCookie) }
func (h *Handler) setCookie(w http.ResponseWriter,name,value string,expiry time.Time) {
	maxAge := int(expiry.Sub(h.now()).Seconds()); if maxAge < 1 { maxAge = 1 }
	http.SetCookie(w,&http.Cookie{Name:name,Value:value,Path:"/",Secure:h.secure,HttpOnly:true,SameSite:http.SameSiteLaxMode,Expires:expiry,MaxAge:maxAge})
}
func (h *Handler) clearCookie(w http.ResponseWriter,name string) {
	http.SetCookie(w,&http.Cookie{Name:name,Value:"",Path:"/",Secure:h.secure,HttpOnly:true,SameSite:http.SameSiteLaxMode,Expires:time.Unix(1,0),MaxAge:-1})
}

// mutation validates CSRF before any mutation or expensive hashing. Anonymous
// bootstrap tokens authorize only entry/recovery/status, never an account write.
func (h *Handler) mutation(w http.ResponseWriter,r *http.Request,anonymous bool) (identity.Principal,bool) {
	var principal identity.Principal
	if token := h.session(r); token != "" {
		p,err := h.service.Authenticate(r.Context(),token,false)
		if err == nil {
			if !sameSecret(r.Header.Get("X-CSRF-Token"),p.CSRFToken) { h.fail(w,r,apierror.Forbidden); return principal,false }
			return p,true
		}
		if !errors.Is(err,identity.ErrUnauthorized) && !errors.Is(err,identity.ErrStale) { h.fail(w,r,err); return principal,false }
	}
	if !anonymous { h.fail(w,r,apierror.Unauthorized); return principal,false }
	if !h.validAnonymousCSRF(h.cookie(r,h.csrfCookie),r.Header.Get("X-CSRF-Token"),h.now()) { h.fail(w,r,apierror.Forbidden); return principal,false }
	return principal,true
}

func (h *Handler) decode(w http.ResponseWriter,r *http.Request,dst any) bool {
	media,params,err := mime.ParseMediaType(r.Header.Get("Content-Type"))
	if err != nil || media != "application/json" || (params["charset"] != "" && !strings.EqualFold(params["charset"],"utf-8")) { h.fail(w,r,apierror.UnsupportedMedia); return false }
	const maximum = 8 << 10
	if r.ContentLength > maximum { h.fail(w,r,apierror.TooLarge); return false }
	r.Body = http.MaxBytesReader(w,r.Body,maximum)
	data,err := io.ReadAll(r.Body)
	if err != nil { var tooLarge *http.MaxBytesError; if errors.As(err,&tooLarge) { h.fail(w,r,apierror.TooLarge) } else { h.fail(w,r,apierror.Invalid) }; return false }
	if !utf8.Valid(data) || !realtime.ValidJSONUnicode(data) || !validJSONObject(data) { h.fail(w,r,apierror.Invalid); return false }
	decoder := json.NewDecoder(strings.NewReader(string(data))); decoder.DisallowUnknownFields()
	if err := decoder.Decode(dst); err != nil { h.fail(w,r,apierror.Invalid); return false }
	return true
}

// Reject duplicate keys, null, trailing values and excessive nesting. Null is
// never a field-clear operation: optional strings are cleared explicitly by "".
func validJSONObject(data []byte) bool {
	decoder := json.NewDecoder(strings.NewReader(string(data)))
	decoder.UseNumber()
	first,err := decoder.Token(); if err != nil || first != json.Delim('{') { return false }
	if !jsonObject(decoder,1) { return false }
	_,err = decoder.Token(); return errors.Is(err,io.EOF)
}
func jsonObject(decoder *json.Decoder,depth int) bool {
	if depth > 8 { return false }
	seen := make(map[string]bool)
	for decoder.More() {
		key,err := decoder.Token(); if err != nil { return false }; name,ok := key.(string); if !ok || seen[name] { return false }; seen[name] = true
		value,err := decoder.Token(); if err != nil || value == nil { return false }
		if delim,ok := value.(json.Delim); ok {
			if delim == '[' && name == "selected_sequences" { if !jsonSequences(decoder) { return false } } else if delim == '[' && (name == "interests" || name == "choices") { if !jsonInterests(decoder) { return false } } else if delim != '{' || !jsonObject(decoder,depth+1) { return false }
		}
	}
	last,err := decoder.Token(); return err == nil && last == json.Delim('}')
}
func jsonInterests(decoder *json.Decoder) bool {
	count := 0
	for decoder.More() {
		value,err := decoder.Token(); if err != nil { return false }
		if _,ok := value.(string); !ok { return false }
		count++; if count > 10 { return false }
	}
	last,err := decoder.Token(); return err == nil && last == json.Delim(']')
}

func jsonSequences(decoder *json.Decoder) bool {
	seen := make(map[uint64]bool)
	for decoder.More() {
		value,err := decoder.Token(); if err != nil { return false }
		number,ok := value.(json.Number); if !ok { return false }
		sequence,err := strconv.ParseUint(number.String(),10,64)
		if err != nil || sequence == 0 || sequence > 9007199254740991 || seen[sequence] || len(seen) >= safetytypes.MaxSelectedEvidence { return false }
		seen[sequence] = true
	}
	last,err := decoder.Token(); return err == nil && last == json.Delim(']')
}
