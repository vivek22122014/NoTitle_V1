package identityhttp

import (
	"context"
	"net/http"
	"strings"
	"testing"

	"notitle/internal/identity"
	"notitle/internal/safetytypes"
)

type fakeSafety struct { calls int; input safetytypes.SubmitReportRequest; ref string; err error }
func (f *fakeSafety) BeginReport(context.Context,identity.Principal,safetytypes.BeginReportRequest)(safetytypes.DraftView,error) { f.calls++; return safetytypes.DraftView{Messages:[]safetytypes.EvidenceView{}},f.err }
func (f *fakeSafety) SubmitReport(_ context.Context,_ identity.Principal,input safetytypes.SubmitReportRequest)(safetytypes.ReportReceipt,error) { f.calls++;f.input=input;return safetytypes.ReportReceipt{},f.err }
func (f *fakeSafety) ListBlocks(context.Context,identity.Principal)([]safetytypes.BlockView,error) { f.calls++;return nil,f.err }
func (f *fakeSafety) Block(context.Context,identity.Principal,safetytypes.BlockRequest)(safetytypes.BlockView,error) { f.calls++;return safetytypes.BlockView{},f.err }
func (f *fakeSafety) Unblock(_ context.Context,_ identity.Principal,ref string)error { f.calls++;f.ref=ref;return f.err }

func TestSafetyRequiresSessionOriginAndCSRF(t *testing.T) {
	h,_,cookie:=accountFixture(t);service:=&fakeSafety{};h.safety=service
	for _,path:=range []string{"/api/v1/reports/begin","/api/v1/reports","/api/v1/blocks"} {
		if rr:=request(h,"POST",path,`{}`,"wrong-csrf",cookie);rr.Code!=403 { t.Fatal("safety mutation accepted invalid CSRF") }
		if rr:=request(h,"POST",path,`{}`,"account-csrf",nil);rr.Code!=401 { t.Fatal("safety mutation accepted missing session") }
	}
	if service.calls!=0 { t.Fatal("authorization happened after safety mutation") }
}
func TestReportSelectionRejectsFabricatedTranscriptAndInvalidSequences(t *testing.T) {
	for _,body:=range []string{
		`{"handle":"opaque","submission_id":"one","category":"spam","statement":"","selected_sequences":[{"text":"fabricated"}]}`,
		`{"selected_sequences":[1,1]}`,`{"selected_sequences":[0]}`,`{"selected_sequences":[1.5]}`,`{"selected_sequences":[-1]}`,`{"selected_sequences":[null]}`,`{"selected_sequences":["1"]}`,`{"selected_sequences":[9007199254740992]}`,
		`{"selected_sequences":[1],"transcript":"fabricated"}`,`{"selected_sequences":[],"selected_sequences":[1]}`,
	} {
		h,_,cookie:=accountFixture(t);service:=&fakeSafety{};h.safety=service
		if rr:=request(h,"POST","/api/v1/reports",body,"account-csrf",cookie);rr.Code!=400 || service.calls!=0 { t.Fatal("invalid evidence reached service") }
	}
	h,_,cookie:=accountFixture(t);service:=&fakeSafety{};h.safety=service
	body:=`{"handle":"opaque","submission_id":"one","category":"spam","statement":"Allegation, not transcript","selected_sequences":[1,2,3]}`
	if rr:=request(h,"POST","/api/v1/reports",body,"account-csrf",cookie);rr.Code!=201 || len(service.input.SelectedSequences)!=3 { t.Fatal("bounded server sequence selection rejected") }
}
func TestSafetyFailureIsNotSubmittedAndExpiredDraftIsGone(t *testing.T) {
	h,_,cookie:=accountFixture(t);service:=&fakeSafety{err:safetytypes.ErrUnavailable};h.safety=service
	if rr:=request(h,"POST","/api/v1/reports",`{"selected_sequences":[]}`,"account-csrf",cookie);rr.Code!=503 || strings.Contains(rr.Body.String(),"case_ref") { t.Fatal("storage failure acknowledged report") }
	service.err=safetytypes.ErrExpired
	if rr:=request(h,"POST","/api/v1/reports",`{"selected_sequences":[]}`,"account-csrf",cookie);rr.Code!=410 { t.Fatal("expired draft not explicit") }
}
func TestBlockReferenceRoutingDoesNotAcceptArbitraryPaths(t *testing.T) {
	h,_,cookie:=accountFixture(t);service:=&fakeSafety{};h.safety=service
	ref:=strings.Repeat("opaque_",4)
	if !h.Owns("/api/v1/blocks/"+ref) || h.Owns("/api/v1/blocks/"+ref+"/nested") || h.Owns("/admin") { t.Fatal("unsafe route ownership") }
	if rr:=request(h,http.MethodDelete,"/api/v1/blocks/"+ref,`{}`,"account-csrf",cookie);rr.Code!=200 || service.ref!=ref { t.Fatal("opaque block removal not routed") }
	if rr:=request(h,http.MethodGet,"/api/v1/blocks","","",cookie);rr.Code!=200 || rr.Body.String()!="{\"blocks\":[]}\n" { t.Fatal("empty block list must be an array") }
}
