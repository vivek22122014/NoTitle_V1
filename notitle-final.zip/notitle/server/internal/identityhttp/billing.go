package identityhttp

import (
 "context"
 "net/http"
 "strings"
 "notitle/internal/billing"
 "notitle/internal/identity"
 "notitle/internal/payments"
)
type BillingService interface{
 Plans(context.Context)(payments.Catalog,error)
 Current(context.Context,identity.Principal)(payments.Premium,error)
 Orders(context.Context,identity.Principal)([]billing.Order,error)
 Order(context.Context,identity.Principal,string)(billing.Order,error)
 Receipts(context.Context,identity.Principal)([]billing.Receipt,error)
 Receipt(context.Context,identity.Principal,string)(billing.Receipt,error)
 Refunds(context.Context,identity.Principal,string)([]billing.Refund,error)
 Create(context.Context,identity.Principal,payments.CreateInput)(billing.Order,error)
 Resume(context.Context,identity.Principal,payments.ResumeInput)(billing.Order,error)
 Verify(context.Context,identity.Principal,string)(billing.Order,error)
}
func paymentReference(path string)(string,bool){prefix:="/api/v1/payments/";if !strings.HasPrefix(path,prefix){return "",false};ref:=strings.TrimPrefix(path,prefix);refunds:=strings.HasSuffix(ref,"/refunds");if refunds{ref=strings.TrimSuffix(ref,"/refunds")};if len(ref)<16||len(ref)>128{return "",false};for _,c:=range ref{if !(c>='a'&&c<='z'||c>='A'&&c<='Z'||c>='0'&&c<='9'||c=='_'||c=='-'){return "",false}};return ref,refunds}
func receiptReference(path string)string{prefix:="/api/v1/me/receipts/";if !strings.HasPrefix(path,prefix){return ""};ref,refunds:=paymentReference("/api/v1/payments/"+strings.TrimPrefix(path,prefix));if refunds{return ""};return ref}
func(h *Handler)billingRead(w http.ResponseWriter,r *http.Request)(identity.Principal,bool){p,err:=h.service.Authenticate(r.Context(),h.session(r),false);if err!=nil{h.fail(w,r,err);return p,false};if p.Kind!=identity.KindAccount{h.fail(w,r,billing.ErrUnauthorized);return p,false};if h.billing==nil{h.fail(w,r,billing.ErrDisabled);return p,false};return p,true}
func(h *Handler)billingMutation(w http.ResponseWriter,r *http.Request)(identity.Principal,bool){p,ok:=h.mutation(w,r,false);if !ok{return p,false};if p.Kind!=identity.KindAccount{h.fail(w,r,billing.ErrUnauthorized);return p,false};if h.billing==nil{h.fail(w,r,billing.ErrDisabled);return p,false};return p,true}
func(h *Handler)premiumPlans(w http.ResponseWriter,r *http.Request){if h.billing==nil{h.fail(w,r,billing.ErrDisabled);return};v,err:=h.billing.Plans(r.Context());if err!=nil{h.fail(w,r,err);return};h.json(w,200,v)}
func(h *Handler)premiumCurrent(w http.ResponseWriter,r *http.Request){p,ok:=h.billingRead(w,r);if !ok{return};v,err:=h.billing.Current(r.Context(),p);if err!=nil{h.fail(w,r,err);return};h.json(w,200,v)}
func(h *Handler)paymentOrders(w http.ResponseWriter,r *http.Request){p,ok:=h.billingRead(w,r);if !ok{return};v,err:=h.billing.Orders(r.Context(),p);if err!=nil{h.fail(w,r,err);return};if v==nil{v=[]billing.Order{}};h.json(w,200,struct{Orders []billing.Order `json:"orders"`}{v})}
func(h *Handler)paymentReceipts(w http.ResponseWriter,r *http.Request){p,ok:=h.billingRead(w,r);if !ok{return};v,err:=h.billing.Receipts(r.Context(),p);if err!=nil{h.fail(w,r,err);return};if v==nil{v=[]billing.Receipt{}};h.json(w,200,struct{Receipts []billing.Receipt `json:"receipts"`}{v})}
func(h *Handler)paymentReceipt(w http.ResponseWriter,r *http.Request){p,ok:=h.billingRead(w,r);if !ok{return};v,err:=h.billing.Receipt(r.Context(),p,receiptReference(r.URL.Path));if err!=nil{h.fail(w,r,err);return};h.json(w,200,v)}
func(h *Handler)paymentDetail(w http.ResponseWriter,r *http.Request){p,ok:=h.billingRead(w,r);if !ok{return};ref,refunds:=paymentReference(r.URL.Path);if refunds{v,err:=h.billing.Refunds(r.Context(),p,ref);if err!=nil{h.fail(w,r,err);return};if v==nil{v=[]billing.Refund{}};h.json(w,200,struct{Refunds []billing.Refund `json:"refunds"`}{v});return};v,err:=h.billing.Order(r.Context(),p,ref);if err!=nil{h.fail(w,r,err);return};h.json(w,200,v)}
func(h *Handler)paymentCreate(w http.ResponseWriter,r *http.Request){p,ok:=h.billingMutation(w,r);if !ok{return};if !h.limit(w,r,"payment-create",p.AccountSession.Account.ID){return};var in payments.CreateInput;if !h.decode(w,r,&in){return};v,err:=h.billing.Create(r.Context(),p,in);if err!=nil{h.fail(w,r,err);return};h.json(w,200,v)}
func(h *Handler)paymentResume(w http.ResponseWriter,r *http.Request){p,ok:=h.billingMutation(w,r);if !ok{return};if !h.limit(w,r,"payment-create",p.AccountSession.Account.ID){return};var in payments.ResumeInput;if !h.decode(w,r,&in){return};v,err:=h.billing.Resume(r.Context(),p,in);if err!=nil{h.fail(w,r,err);return};h.json(w,200,v)}
func(h *Handler)paymentVerify(w http.ResponseWriter,r *http.Request){p,ok:=h.billingMutation(w,r);if !ok{return};if !h.limit(w,r,"payment-verify",p.AccountSession.Account.ID){return};var in struct{PurchaseRef string `json:"purchase_ref"`};if !h.decode(w,r,&in){return};v,err:=h.billing.Verify(r.Context(),p,in.PurchaseRef);if err!=nil{h.fail(w,r,err);return};h.json(w,200,v)}
