package identityhttp

import (
    "context"
    "errors"
    "net/http"
    "net/http/httptest"
    "strings"
    "testing"

    "notitle/internal/billing"
    "notitle/internal/identity"
    "notitle/internal/payments"
)

// Unlike the general transport fixture, this identity stub checks the session
// input so a read with an absent cookie cannot accidentally authenticate.
type billingIdentity struct{*fakeService}
func(f *billingIdentity)Authenticate(ctx context.Context,token string,touch bool)(identity.Principal,error){if token!="account-cookie"{return identity.Principal{},identity.ErrUnauthorized};return f.fakeService.Authenticate(ctx,token,touch)}
type billingHTTPStub struct{calls int;operation,ref string;principal identity.Principal;create payments.CreateInput;resume payments.ResumeInput;err error}
func(b *billingHTTPStub)capture(operation string,p identity.Principal,ref string){b.calls++;b.operation=operation;b.principal=p;b.ref=ref}
func(b *billingHTTPStub)Plans(context.Context)(payments.Catalog,error){b.capture("plans",identity.Principal{},"");return payments.Catalog{Plans:[]billing.Plan{},Environment:billing.Test},b.err}
func(b *billingHTTPStub)Current(_ context.Context,p identity.Principal)(payments.Premium,error){b.capture("current",p,"");return payments.Premium{},b.err}
func(b *billingHTTPStub)Orders(_ context.Context,p identity.Principal)([]billing.Order,error){b.capture("orders",p,"");return nil,b.err}
func(b *billingHTTPStub)Order(_ context.Context,p identity.Principal,ref string)(billing.Order,error){b.capture("order",p,ref);return billing.Order{Ref:ref,Status:"processing",Environment:billing.Test},b.err}
func(b *billingHTTPStub)Receipts(_ context.Context,p identity.Principal)([]billing.Receipt,error){b.capture("receipts",p,"");return nil,b.err}
func(b *billingHTTPStub)Receipt(_ context.Context,p identity.Principal,ref string)(billing.Receipt,error){b.capture("receipt",p,ref);return billing.Receipt{PurchaseRef:ref,Status:"paid"},b.err}
func(b *billingHTTPStub)Refunds(_ context.Context,p identity.Principal,ref string)([]billing.Refund,error){b.capture("refunds",p,ref);return nil,b.err}
func(b *billingHTTPStub)Create(_ context.Context,p identity.Principal,in payments.CreateInput)(billing.Order,error){b.capture("create",p,"");b.create=in;return billing.Order{Ref:strings.Repeat("p",32),Status:"processing"},b.err}
func(b *billingHTTPStub)Resume(_ context.Context,p identity.Principal,in payments.ResumeInput)(billing.Order,error){b.capture("resume",p,in.PurchaseRef);b.resume=in;return billing.Order{Ref:in.PurchaseRef,Status:"processing"},b.err}
func(b *billingHTTPStub)Verify(_ context.Context,p identity.Principal,ref string)(billing.Order,error){b.capture("verify",p,ref);return billing.Order{Ref:ref,Status:"processing"},b.err}
func billingHTTPFixture(t *testing.T)(*Handler,*fakeService,*http.Cookie,*billingHTTPStub){t.Helper();h,f,cookie:=accountFixture(t);h.service=&billingIdentity{f};b:=&billingHTTPStub{};h.billing=b;return h,f,cookie,b}
func billingMutationCases()[]struct{path,body string}{return []struct{path,body string}{
    {"/api/v1/payments/orders",`{"plan_id":"three-day","plan_version":1,"idempotency_key":"purchase_fixture_key","customer_phone":"9876543210"}`},
    {"/api/v1/payments/checkout",`{"purchase_ref":"purchase_fixture_ref","customer_phone":"9876543210"}`},
    {"/api/v1/payments/verify",`{"purchase_ref":"purchase_fixture_ref"}`},
}}
func TestBillingMutationsAuthenticateAccountAndCSRFBeforeDispatch(t *testing.T){
    for _,tc:=range billingMutationCases(){for _,mode:=range []string{"missing_cookie","bad_csrf","guest","revoked","cross_origin","duplicate_cookie"}{
        h,f,cookie,b:=billingHTTPFixture(t);r:=httptest.NewRequest(http.MethodPost,tc.path,strings.NewReader(tc.body));r.Header.Set("Origin",h.origin);r.Header.Set("Content-Type","application/json");r.Header.Set("X-CSRF-Token","account-csrf")
        if mode!="missing_cookie"{r.AddCookie(cookie)};want:=401
        switch mode{case "bad_csrf":r.Header.Set("X-CSRF-Token","forged");want=403;case "guest":f.principal.Kind=identity.KindGuest;case "revoked":f.authErr=identity.ErrUnauthorized;case "cross_origin":r.Header.Set("Origin","https://other.example");want=403;case "duplicate_cookie":r.AddCookie(cookie);want=403}
        w:=httptest.NewRecorder();h.ServeHTTP(w,r);if w.Code!=want||b.calls!=0{t.Fatal("billing dispatched before request authority",mode,tc.path,w.Code)}
    }}
}
func TestBillingPrivateReadsRequireAccountButCatalogIsPublic(t *testing.T){
    for _,path:=range []string{"/api/v1/me/premium","/api/v1/me/orders","/api/v1/me/receipts","/api/v1/me/receipts/purchase_fixture_ref","/api/v1/payments/purchase_fixture_ref","/api/v1/payments/purchase_fixture_ref/refunds"}{for _,mode:=range []string{"absent","guest","revoked"}{
        h,f,cookie,b:=billingHTTPFixture(t);if mode=="absent"{cookie=nil};if mode=="guest"{f.principal.Kind=identity.KindGuest};if mode=="revoked"{f.authErr=identity.ErrUnauthorized}
        w:=request(h,http.MethodGet,path,"","",cookie);if w.Code!=401||b.calls!=0{t.Fatal("private financial read before account authentication")}
    }}
    h,_,_,b:=billingHTTPFixture(t);w:=request(h,http.MethodGet,"/api/v1/premium/plans","","",nil);if w.Code!=200||b.operation!="plans"||strings.Contains(w.Body.String(),"PRIVATE_ACCOUNT_ID"){t.Fatal("public plan catalog incorrectly coupled to account data")}
}
func TestBillingStrictJSONRejectsClientEconomicAuthority(t *testing.T){
    for _,tc:=range billingMutationCases(){for _,addition:=range []string{`,"amount_paise":1`,`,"currency":"USD"`,`,"premium":true`,`,"tier":"premium"`,`,"account_id":"another-account"`,`,"provider_payment_id":"forged"`}{
        h,_,cookie,b:=billingHTTPFixture(t);body:=strings.TrimSuffix(tc.body,"}")+addition+"}";w:=request(h,http.MethodPost,tc.path,body,"account-csrf",cookie);if w.Code!=400||b.calls!=0{t.Fatal("untrusted economic authority reached billing service")}
    }}
    for _,body:=range []string{`null`,`[]`,`{"purchase_ref":null}`,`{"purchase_ref":"first","purchase_ref":"second"}`,`{"purchase_ref":"purchase_fixture_ref"}{}`}{h,_,cookie,b:=billingHTTPFixture(t);w:=request(h,http.MethodPost,"/api/v1/payments/verify",body,"account-csrf",cookie);if w.Code!=400||b.calls!=0{t.Fatal("ambiguous verification input dispatched")}}
}
func TestBillingDispatchPreservesTrustedPrincipalAndScopedReference(t *testing.T){
    h,f,cookie,b:=billingHTTPFixture(t);ref:="purchase_fixture_ref"
    for _,suffix:=range []string{"","/refunds"}{w:=request(h,http.MethodGet,"/api/v1/payments/"+ref+suffix,"","",cookie);if w.Code!=200||b.ref!=ref||b.principal.AccountSession.Account.ID!=f.principal.AccountSession.Account.ID{t.Fatal("financial object scope or principal lost")};if w.Header().Get("Cache-Control")!="no-store"||strings.Contains(w.Body.String(),"PRIVATE_ACCOUNT_ID"){t.Fatal("private identifier leaked or response cacheable")}}
    b.err=billing.ErrNotFound;w:=request(h,http.MethodGet,"/api/v1/payments/"+ref,"","",cookie);if w.Code!=404||strings.Contains(w.Body.String(),"processing"){t.Fatal("foreign/missing purchase not normalized")}
    for _,tc:=range billingMutationCases(){h,_,cookie,b=billingHTTPFixture(t);w=request(h,http.MethodPost,tc.path,tc.body,"account-csrf",cookie);if w.Code!=200||b.calls!=1||b.principal.Kind!=identity.KindAccount||strings.Contains(w.Body.String(),"9876543210"){t.Fatal("valid account workflow or contact privacy failed")}}
}
func TestBillingRoutesCannotBecomePrivateAdminOrArbitraryPathLookup(t *testing.T){
    h,_,cookie,b:=billingHTTPFixture(t);ref:="purchase_fixture_ref"
    for _,path:=range []string{"/api/v1/payments/"+ref,"/api/v1/payments/"+ref+"/refunds"}{if !h.Owns(path){t.Fatal("purchase route missing")}}
    for _,path:=range []string{"/billing","/api/v1/payments/x","/api/v1/payments/"+ref+"/nested","/api/v1/payments/"+ref+"/refunds/nested","/api/v1/payments/"+strings.Repeat("x",129),"/api/v1/payments/"+ref+".invalid"}{if h.Owns(path){t.Fatal("arbitrary financial route owned")}}
    if w:=request(h,http.MethodPost,"/api/v1/payments/"+ref,`{}`,"account-csrf",cookie);w.Code!=405||b.calls!=0{t.Fatal("purchase read acquired mutation semantics")}
    if w:=request(h,http.MethodGet,"/api/v1/payments/"+ref+"?account_id=forged","","",cookie);w.Code!=400||b.calls!=0{t.Fatal("financial query-string authority accepted")}
}
func TestCheckoutCreateAndResumeShareBoundedAdmission(t *testing.T){
    h,_,cookie,b:=billingHTTPFixture(t);cases:=billingMutationCases()
    for i:=0;i<4;i++{tc:=cases[i%2];w:=request(h,http.MethodPost,tc.path,tc.body,"account-csrf",cookie);if i<3&&w.Code!=200{t.Fatal("initial bounded request failed")};if i==3&&(w.Code!=429||w.Header().Get("Retry-After")==""){t.Fatal("create/resume admission was not shared")}}
    if b.calls!=3{t.Fatal("rate-limited create reached provider service")}
}
func TestBillingBodyBoundAndDisabledStateBeforeService(t *testing.T){
    h,_,cookie,b:=billingHTTPFixture(t);w:=request(h,http.MethodPost,"/api/v1/payments/orders",strings.Repeat("x",8193),"account-csrf",cookie);if w.Code!=413||b.calls!=0{t.Fatal("unbounded checkout body")}
    h.billing=nil;for _,tc:=range billingMutationCases(){w=request(h,http.MethodPost,tc.path,tc.body,"account-csrf",cookie);if w.Code!=503||!strings.Contains(w.Body.String(),"checkout_unavailable"){t.Fatal("disabled checkout not explicit")}}
}
func TestBillingErrorsDoNotRevealProviderInputsOrClaimSuccess(t *testing.T){
    for _,tc:=range []struct{err error;code int}{{billing.ErrUnavailable,503},{billing.ErrReview,409},{billing.ErrConflict,409},{billing.ErrUnauthorized,401},{errors.New("private-provider-customer-contact"),500}}{h,_,cookie,b:=billingHTTPFixture(t);b.err=tc.err;w:=request(h,http.MethodPost,"/api/v1/payments/verify",`{"purchase_ref":"purchase_fixture_ref"}`,"account-csrf",cookie);if w.Code!=tc.code||strings.Contains(w.Body.String(),"private-provider")||strings.Contains(w.Body.String(),"processing")||strings.Contains(w.Body.String(),"premium_active"){t.Fatal("financial error leaked or falsely acknowledged")}}
}

func TestBillingDirectReceiptIsOwnedAndUsesTrustedAccountScope(t *testing.T){
    h,f,cookie,b:=billingHTTPFixture(t);ref:="purchase_fixture_ref";path:="/api/v1/me/receipts/"+ref
    if !h.Owns(path)||h.Owns(path+"/refunds")||h.Owns(path+"/nested")||h.Owns("/api/v1/me/receipts/x"){t.Fatal("receipt route scope invalid")}
    w:=request(h,http.MethodGet,path,"","",cookie)
    if w.Code!=200||b.operation!="receipt"||b.ref!=ref||b.principal.AccountSession.Account.ID!=f.principal.AccountSession.Account.ID||w.Header().Get("Cache-Control")!="no-store"{t.Fatal("direct receipt lost trusted ownership guard")}
    b.err=billing.ErrNotFound;w=request(h,http.MethodGet,path,"","",cookie)
    if w.Code!=404||strings.Contains(w.Body.String(),"paid")||strings.Contains(w.Body.String(),"PRIVATE_ACCOUNT_ID"){t.Fatal("foreign receipt exposed or falsely confirmed")}
}
