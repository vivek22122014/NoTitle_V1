package identityhttp

import (
	"crypto/hmac"
	"crypto/sha256"
	"net"
	"strings"
	"sync"
	"time"
)

const limiterCapacity = 4096
const limiterTTL = 10 * time.Minute

type bucket struct { tokens float64; updated time.Time }
type limitRule struct { key string; burst float64; perMinute float64 }
type limiter struct { mu sync.Mutex; key [32]byte; entries map[[32]byte]bucket }

func (l *limiter) digest(raw string) [32]byte {
	h := hmac.New(sha256.New, l.key[:]); _, _ = h.Write([]byte(raw))
	var out [32]byte; copy(out[:], h.Sum(nil)); return out
}

// Fixed budget and bounded, keyed ephemeral buckets. Usernames and source IPs
// never become logs, metrics, durable records or unbounded attacker-owned keys.
func (l *limiter) allow(now time.Time, category, remote, subject string) bool {
	host, _, err := net.SplitHostPort(remote)
	if err != nil { host = "unknown" }
	rules := []limitRule{{"all:"+category, 200, 600}, {"source:"+category+":"+host, 200, 600}}
	if category == "payment-create" {rules=[]limitRule{{"all:payment-create",8,30},{"account:payment-create:"+subject,3,3},{"source:payment-create:"+host,6,12}}}
 if category == "payment-verify" {rules=append(rules,limitRule{"account:payment-verify:"+subject,6,12})}
 if category == "hash" {
		rules = []limitRule{{"subject:"+strings.ToLower(strings.TrimSpace(subject)), 5, 1}, {"source:hash:"+host, 20, 60}, {"all:hash", 12, 30}}
	}
	if category == "realtime-ticket" { rules = append(rules,limitRule{"ticket:"+subject,6,6}) }
 if category == "guest" { rules = []limitRule{{"all:guest", 200, 300}, {"source:guest:"+host, 200, 300}} }
	l.mu.Lock(); defer l.mu.Unlock()
	if len(l.entries) >= limiterCapacity {
		for key, entry := range l.entries { if now.Sub(entry.updated) >= limiterTTL { delete(l.entries, key) } }
	}
	keys := make([][32]byte, len(rules)); next := make([]bucket, len(rules)); missing := 0
	for i, rule := range rules {
		keys[i] = l.digest(rule.key)
		entry, exists := l.entries[keys[i]]
		if !exists { entry = bucket{tokens:rule.burst, updated:now}; missing++ }
		elapsed := now.Sub(entry.updated).Seconds(); if elapsed < 0 { elapsed = 0 }
		entry.tokens += elapsed * rule.perMinute / 60; if entry.tokens > rule.burst { entry.tokens = rule.burst }
		if entry.tokens < 1 { return false }
		entry.tokens--; entry.updated = now; next[i] = entry
	}
	if len(l.entries)+missing > limiterCapacity { return false }
	for i, key := range keys { l.entries[key] = next[i] }
	return true
}
