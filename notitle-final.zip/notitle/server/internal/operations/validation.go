package operations

import (
 "crypto/hmac"
 "crypto/rand"
 "crypto/sha256"
 "encoding/base64"
 "encoding/hex"
 "encoding/json"
 "regexp"
 "strings"
 "time"
 "unicode"
 "unicode/utf8"
)
var referencePattern=regexp.MustCompile(`^[A-Za-z0-9_-]{22,64}$`)
var policyVersionPattern=regexp.MustCompile(`^[A-Za-z0-9_.-]{1,64}$`)
var reasonPattern=regexp.MustCompile(`^[a-z][a-z0-9_]{2,63}$`)
func validText(v string,min,max int)bool{if !utf8.ValidString(v)||len(v)>max*4||utf8.RuneCountInString(strings.TrimSpace(v))<min||utf8.RuneCountInString(v)>max{return false};for _,r:=range v{if unicode.IsControl(r)&&r!='\n'&&r!='\t'||r>=0x202a&&r<=0x202e||r>=0x2066&&r<=0x2069{return false}};return true}
func secretHash(secret string)([32]byte,error){var out [32]byte;b,err:=base64.RawURLEncoding.Strict().DecodeString(secret);if err!=nil||len(b)!=32{return out,ErrInvalid};out=sha256.Sum256(b);clear(b);return out,nil}
func validateSubmit(in SubmitInput)error{if !referencePattern.MatchString(in.SubmissionID)||!validText(in.Subject,1,160)||!validText(in.Message,5,4000){return ErrInvalid};if _,err:=secretHash(in.StatusSecret);err!=nil{return err};switch in.Kind{case "grievance","appeal","access","correction","deletion","receipt":default:return ErrInvalid};if !validCategory(in.Category){return ErrInvalid};return nil}
func validCategory(v string)bool{switch v{case "general","removal","intimate","court_order":return true};return false}
func urgency(category,message string)string{if category!="general"{return "urgent"};v:=strings.ToLower(message);for _,word:=range []string{"suicide","kill myself","kill you","death threat","immediate danger","nude","intimate image","child sexual","underage","doxxing","rape","bomb","आत्महत्या","जान से","नग्न","बलात्कार"}{if strings.Contains(v,word){return "urgent"}};return "normal"}
// Heuristics may only escalate. Operators must inspect every intake; absence
// of a keyword does not establish low risk or validate a legal direction.
func deadlines(received time.Time,ack,resolve,backup int64,severity string)(time.Time,time.Time,time.Time){if severity=="urgent"&&backup>600{backup=600};return received.Add(time.Duration(ack)*time.Second),received.Add(time.Duration(resolve)*time.Second),received.Add(time.Duration(backup)*time.Second)}
func earlier(a,b time.Time)time.Time{if a.Before(b){return a};return b}
func randomRef()(string,error){var raw[16]byte;if _,err:=rand.Read(raw[:]);err!=nil{return "",ErrUnavailable};return hex.EncodeToString(raw[:]),nil}
func uuid()(string,error){id,err:=randomRef();if err!=nil{return "",err};return id[:8]+"-"+id[8:12]+"-"+id[12:16]+"-"+id[16:20]+"-"+id[20:],nil}
func fingerprint(secret []byte,value any)[32]byte{b,_:=json.Marshal(value);h:=hmac.New(sha256.New,secret);_,_=h.Write(b);var out[32]byte;copy(out[:],h.Sum(nil));clear(b);return out}
