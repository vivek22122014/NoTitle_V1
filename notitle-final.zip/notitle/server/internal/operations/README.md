# Operations policy publication

The migration ships **unapproved draft fixtures**, not a legal determination. A public support form does not establish monitored operations. Production needs counsel-approved applicability, exact legal sources/effective dates, current retention policy, a trained primary and backup operator, and tested receivers. Keep the public launch switch off until those gates pass.

The application role can only read `legal_deadline_rules` and `rule_notices`. Publish reviewed changes through a version-controlled, hashed, transactional data-publication SQL file using the dedicated migration role. The cumulative runtime and launch tooling require schema 9: data publication inserts new immutable policy versions without changing that schema version. A new Goose schema migration requires a coordinated code/readiness/evidence update and fresh acceptance. Do not give the API migration credentials or edit old versions to rewrite an existing case's history.

1. Counsel confirms the actual business, applicable rules and corrections, trigger and jurisdiction. The supplied deadline examples reference the corrected consolidated IT Rules and the February amendment's 20 February 2026 commencement; `2026-02-19T18:30:00Z` represents midnight in India. Public selection of `court_order` requests urgent review and does not authenticate a direction or authorize removal.
2. Record a new immutable version, approval reference, approval timestamp and future `review_due` in the reviewed data-publication transaction. Publish all four categories together. `effective_at` means when that rule applies, while `published_at` orders reviewed revisions sharing the same legal effective date. Always provide the exact source, not a placeholder or this README as legal evidence.
3. Publish the counsel-approved reminder wording and its version in the same release. Notices repeat at no more than three calendar months, with month-end clamping; account deliveries and acknowledgements are durable. Guests receive the current notice without any durable guest identity.
4. Install the matching reviewed privacy manifest through the documented privacy policy command. Main passes its `cases` maximum days and version into this repository. New messages receive a policy snapshot; closure updates the whole case to its reviewed closure-based expiry. Legal holds and other applicable minima are evaluated by the separate privacy purge job.
5. Run readiness and the role/deadline/notification tests in the isolated environment. Latest effective unapproved or expired policies fail readiness; the code never falls back to an older approved version. Known unreviewed changes becoming effective within 30 days also fail the launch gate. Review later announcements operationally; the application cannot discover an unrecorded legal change.
6. Exercise an urgent complaint through delivery to the primary and backup operator, case acknowledgement, reply, appeal and closure. Verify monitoring raises an alert when delivery is dead or a deadline expires. Receiver HTTP acceptance is only transport delivery, not a person's acknowledgement.

Example data-publication transaction, with deliberately non-executable placeholders:

```sql
BEGIN;
-- Run as notitle_migrate, with the reviewed values filled by the release owner.
INSERT INTO notitle.legal_deadline_rules
 (version,category,trigger,effective_at,published_at,legal_source,
  acknowledge_seconds,resolve_seconds,backup_seconds,responsible_role,
  approved_by,approved_at,review_due)
VALUES
 (:version,'general','original_receipt',:effective_at,:published_at,:source,
  :general_ack,:general_resolution,:general_backup,'grievance_officer',
  :approval_reference,:approval_at,:review_due),
 (:version,'removal','original_receipt',:effective_at,:published_at,:source,
  :removal_ack,:removal_resolution,:urgent_backup,'grievance_officer',
  :approval_reference,:approval_at,:review_due),
 (:version,'intimate','original_receipt',:effective_at,:published_at,:source,
  :intimate_ack,:intimate_resolution,:urgent_backup,'grievance_officer',
  :approval_reference,:approval_at,:review_due),
 (:version,'court_order','original_receipt',:effective_at,:published_at,:source,
  :direction_ack,:direction_resolution,:urgent_backup,'grievance_officer',
  :approval_reference,:approval_at,:review_due);
INSERT INTO notitle.rule_notices
 (version,text,effective_at,published_at,approved_by,approved_at,review_due,repeat_months)
VALUES (:notice_version,:reviewed_plain_text,:notice_effective_at,:published_at,
        :approval_reference,:approval_at,:review_due,3);
COMMIT;
```

Do not copy example numbers as legal approval. `legal_deadline_rules` bounds currently admit at most 24-hour acknowledgement and seven-day resolution; a reviewed change requiring different bounds needs a reviewed schema/code change. Original case receipt never changes. Retry and assignment do not restart deadlines; reclassification can only tighten an existing due time. Appeals remain linked to their original case and preserve its original receipt and deadline. No automated decision treats a user's allegation as verified misconduct.

Public submissions require independent random submission ID and a 256-bit status secret generated before sending. Only the verifier is stored. A protected status lookup accepts either the returned case reference or the original submission ID plus the same secret, so a lost HTTP response is recoverable without persisting a complaint body. The frontend offers an explicit recovery file; no secret goes into a URL, analytics or automatic browser storage. A complaint bearer never proves ownership of the account or purchase mentioned in its text.

Case subject, statement, replies and operator notes use a separate mounted encryption keyring and purpose-bound AES-GCM metadata. Per-case idempotency MAC keys are encrypted too. There is no transcript retrieval, attachment upload or audio recording endpoint. Ciphertext keys must remain available for applicable retention and encrypted backup recovery; rotate the active key while retaining authorized old read keys.

Each case permits 80 incoming messages within the overall 100-message display/storage bound, reserving room for staff responses. The operator must consolidate repetitive follow-up and provide the published grievance channel if a case reaches the bound. Worklists show up to 100 prioritized items, with direct authorized case lookup available. These are resource limits, not a substitute for monitored staffing.

The active case notification worker claims one job per tick (the store API also bounds batch requests), hold 30-second leases, and stop after eight attempts with bounded retry delays. Dead jobs remain visible. Urgent intake pages the primary immediately and schedules backup escalation within ten minutes unless a human acknowledges; normal intake also has a backup. A new reply or appeal reopens attention even when the original complaint was acknowledged. A notification contains only an opaque event reference, generic code, severity and immutable event time. No case reference, account identity or message body leaves through that receiver.

Migration 8 precedes privacy migration 9. Its aggregate-expiry definer intentionally resolves the reviewed privacy policy tables at execution time; do not start expiry workers between these migrations. Rollback is only for disposable test data. Financial and privacy retention must not be reversed on retained production records.
