package operations

import (
 "context"
 "time"
 "notitle/internal/observability"
)
// AlertWorker delivers the case outbox outside the live coordinator. Transport
// acceptance never acknowledges a grievance; human ACK drives escalation state.
type AlertWorker struct { Store NotificationStore; Receiver observability.Receiver; Now func()time.Time }
func(w *AlertWorker)Run(ctx context.Context){
 if w.Now==nil{w.Now=time.Now};ticker:=time.NewTicker(time.Second);defer ticker.Stop()
 for{w.Step(ctx);select{case <-ctx.Done():return;case <-ticker.C:}}
}
func(w *AlertWorker)Step(parent context.Context){
 if w.Store==nil{return};now:=time.Now;if w.Now!=nil{now=w.Now}
 ctx,cancel:=context.WithTimeout(parent,8*time.Second);defer cancel()
 // One bounded request per tick. Claiming large batches would consume lease
 // time while requests wait behind a slow receiver.
 jobs,err:=w.Store.ClaimNotifications(ctx,now().UTC(),1);if err!=nil{return}
 for _,job:=range jobs{
  valid,err:=w.Store.ValidateNotification(ctx,job,now().UTC());if err!=nil||!valid{continue}
  severity:=job.Severity;if severity!="urgent"{severity="warning"}
  envelope:=observability.Envelope{EventRef:job.ID,Code:"case_attention",Severity:severity,OpenedAt:job.OpenedAt}
  success:=w.Receiver!=nil&&w.Receiver.Configured(job.Audience)&&w.Receiver.Send(ctx,job.Audience,envelope)==nil
  _=w.Store.FinishNotification(ctx,job,success,now().UTC())
 }
}
