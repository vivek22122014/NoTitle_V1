// Package operations contains deliberately submitted complaints and private
// operator workflows. It cannot retrieve ordinary conversations or audio.
package operations

import (
 "context"
 "errors"
 "time"
 "notitle/internal/identity"
 "notitle/internal/safety"
)

var (
 ErrInvalid=errors.New("invalid operations request")
 ErrUnauthorized=errors.New("operations access unavailable")
 ErrNotFound=errors.New("case unavailable")
 ErrConflict=errors.New("case changed; refresh and retry")
 ErrUnavailable=errors.New("operations temporarily unavailable")
)
type SubmitInput struct {
 SubmissionID string `json:"submission_id"`
 StatusSecret string `json:"status_secret"`
 Kind string `json:"kind"`
 Category string `json:"category"`
 Subject string `json:"subject"`
 Message string `json:"message"`
}
type Credential struct { CaseRef string `json:"case_ref"`; StatusSecret string `json:"status_secret"` }
type ReplyInput struct { Credential; SubmissionID string `json:"submission_id"`; Message string `json:"message"`; Appeal bool `json:"appeal"` }
type CaseSummary struct {
 Ref string `json:"case_ref"`; Kind string `json:"kind"`; Category string `json:"category"`; State string `json:"state"`; Severity string `json:"severity"`
 ReceivedAt time.Time `json:"received_at"`; AcknowledgeDue time.Time `json:"acknowledge_due"`; ResolutionDue time.Time `json:"resolution_due"`
 AcknowledgedAt *time.Time `json:"acknowledged_at,omitempty"`; ClosedAt *time.Time `json:"closed_at,omitempty"`; Version int64 `json:"version"`; PolicyVersion string `json:"policy_version"`
}
type Message struct { Ref string `json:"message_ref"`; Author string `json:"author"`; Text string `json:"text"`; CreatedAt time.Time `json:"created_at"`; Appeal bool `json:"appeal"` }
type ActionRecord struct { Action,Reason,ActorRef string; CreatedAt time.Time; ExpectedRevision int64 }
type CaseDetail struct { CaseSummary; Subject string `json:"subject"`; Messages []Message `json:"messages"`; Assignee string `json:"-"`; Actions []ActionRecord `json:"-"` }
type Receipt struct { Case CaseSummary `json:"case"`; StatusSecret string `json:"status_secret"` }
type AdminGuard struct { AdminID string; Generation int64; SessionHash [32]byte; Reason string }
type CaseAction struct { CaseRef,Action,Reason,Message,Category,Assignee,SubmissionID string; ExpectedVersion int64 }
type Notice struct { Version string `json:"version"`; Text string `json:"text"`; Audience string `json:"audience"`; DeliveredAt time.Time `json:"delivered_at"`; AcknowledgedAt *time.Time `json:"acknowledged_at,omitempty"`; NextDue time.Time `json:"next_due"` }
type Notification struct { ID,LeaseToken,Kind,Severity,CaseRef,Audience string; Attempts int; DueAt,OpenedAt time.Time }
type NotificationStore interface {
 ClaimNotifications(context.Context,time.Time,int)([]Notification,error)
 ValidateNotification(context.Context,Notification,time.Time)(bool,error)
 FinishNotification(context.Context,Notification,bool,time.Time)error
}
type Cipher interface { Encrypt([]byte,[]byte)(safety.Encrypted,error); Decrypt(safety.Encrypted,[]byte)([]byte,error) }
type Repository interface {
 Submit(context.Context,*identity.Guard,SubmitInput,time.Time)(Receipt,error)
 Status(context.Context,Credential,time.Time)(CaseDetail,error)
 Reply(context.Context,ReplyInput,time.Time)(CaseDetail,error)
 AccountReply(context.Context,identity.Guard,ReplyInput,time.Time)(CaseDetail,error)
 AccountCases(context.Context,identity.Guard,time.Time)([]CaseSummary,error)
 AccountCase(context.Context,identity.Guard,string,time.Time)(CaseDetail,error)
 AccountNotice(context.Context,identity.Guard,time.Time)(*Notice,error)
 AcknowledgeNotice(context.Context,identity.Guard,string,time.Time)error
 GuestNotice(context.Context,time.Time)(*Notice,error)
 Cases(context.Context,AdminGuard,int,time.Time)([]CaseSummary,error)
 Case(context.Context,AdminGuard,string,time.Time)(CaseDetail,error)
 Action(context.Context,AdminGuard,CaseAction,time.Time)(CaseDetail,error)
}
type Options struct { Store Repository; Ready func(context.Context)error; Now func()time.Time }
type Service struct { options Options }
func New(options Options)*Service { if options.Now==nil{options.Now=time.Now};return &Service{options:options} }
func(s *Service)ready(ctx context.Context)error { if s==nil||s.options.Store==nil{return ErrUnavailable};if s.options.Ready!=nil&&s.options.Ready(ctx)!=nil{return ErrUnavailable};return nil }
func(s *Service)Submit(ctx context.Context,g *identity.Guard,in SubmitInput)(Receipt,error){if err:=s.ready(ctx);err!=nil{return Receipt{},err};return s.options.Store.Submit(ctx,g,in,s.options.Now().UTC())}
func(s *Service)Status(ctx context.Context,in Credential)(CaseDetail,error){if err:=s.ready(ctx);err!=nil{return CaseDetail{},err};return s.options.Store.Status(ctx,in,s.options.Now().UTC())}
func(s *Service)Reply(ctx context.Context,in ReplyInput)(CaseDetail,error){if err:=s.ready(ctx);err!=nil{return CaseDetail{},err};return s.options.Store.Reply(ctx,in,s.options.Now().UTC())}
func(s *Service)AccountReply(ctx context.Context,g identity.Guard,in ReplyInput)(CaseDetail,error){if err:=s.ready(ctx);err!=nil{return CaseDetail{},err};return s.options.Store.AccountReply(ctx,g,in,s.options.Now().UTC())}
func(s *Service)AccountCases(ctx context.Context,g identity.Guard)([]CaseSummary,error){if err:=s.ready(ctx);err!=nil{return nil,err};return s.options.Store.AccountCases(ctx,g,s.options.Now().UTC())}
func(s *Service)AccountCase(ctx context.Context,g identity.Guard,ref string)(CaseDetail,error){if err:=s.ready(ctx);err!=nil{return CaseDetail{},err};return s.options.Store.AccountCase(ctx,g,ref,s.options.Now().UTC())}
func(s *Service)AccountNotice(ctx context.Context,g identity.Guard)(*Notice,error){if err:=s.ready(ctx);err!=nil{return nil,err};return s.options.Store.AccountNotice(ctx,g,s.options.Now().UTC())}
func(s *Service)GuestNotice(ctx context.Context)(*Notice,error){if err:=s.ready(ctx);err!=nil{return nil,err};return s.options.Store.GuestNotice(ctx,s.options.Now().UTC())}
func(s *Service)AcknowledgeNotice(ctx context.Context,g identity.Guard,version string)error{if err:=s.ready(ctx);err!=nil{return err};return s.options.Store.AcknowledgeNotice(ctx,g,version,s.options.Now().UTC())}
func(s *Service)Cases(ctx context.Context,g AdminGuard,limit int)([]CaseSummary,error){if err:=s.ready(ctx);err!=nil{return nil,err};return s.options.Store.Cases(ctx,g,limit,s.options.Now().UTC())}
func(s *Service)Case(ctx context.Context,g AdminGuard,ref string)(CaseDetail,error){if err:=s.ready(ctx);err!=nil{return CaseDetail{},err};return s.options.Store.Case(ctx,g,ref,s.options.Now().UTC())}
func(s *Service)Action(ctx context.Context,g AdminGuard,in CaseAction)(CaseDetail,error){if err:=s.ready(ctx);err!=nil{return CaseDetail{},err};return s.options.Store.Action(ctx,g,in,s.options.Now().UTC())}
