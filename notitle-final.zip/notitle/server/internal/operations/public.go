package operations

import (
 "context"
 "crypto/subtle"
 "errors"
 "time"
 "github.com/jackc/pgx/v5"
 "notitle/internal/identity"
)
func(s *PostgresStore)Submit(ctx context.Context,g *identity.Guard,in SubmitInput,now time.Time)(Receipt,error){
 if err:=validateSubmit(in);err!=nil{return Receipt{},err};now=now.UTC().Truncate(time.Microsecond);secret,_:=secretHash(in.StatusSecret);input:=struct{Kind,Category,Subject,Message string}{in.Kind,in.Category,in.Subject,in.Message}
 return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(Receipt,error){
  if g!=nil{if err:=accountGuard(ctx,tx,*g,now);err!=nil{return Receipt{},err}}
  // Serialize same submission before checking existence. This is a bounded
  // transaction advisory lock, not a permanent session or second owner.
  if _,err:=tx.Exec(ctx,`SELECT pg_advisory_xact_lock(hashtextextended($1,198))`,in.SubmissionID);err!=nil{return Receipt{},ErrUnavailable}
  var oldRef string;var oldSecret,oldHash []byte;var oldAccount *string
  err:=tx.QueryRow(ctx,`SELECT ref,secret_hash,submission_hash,account_id::text FROM notitle.grievances WHERE submission_id=$1`,in.SubmissionID).Scan(&oldRef,&oldSecret,&oldHash,&oldAccount)
  if err==nil{key,e:=s.fingerprintKey(ctx,tx,oldRef);if e!=nil{return Receipt{},e};defer clear(key);inputHash:=fingerprint(key,input);if subtle.ConstantTimeCompare(oldSecret,secret[:])!=1||subtle.ConstantTimeCompare(oldHash,inputHash[:])!=1||(g==nil&&oldAccount!=nil)||(g!=nil&&(oldAccount==nil||*oldAccount!=g.AccountID)){return Receipt{},ErrConflict};c,e:=summary(ctx,tx,oldRef);return Receipt{Case:c,StatusSecret:in.StatusSecret},e};if !errors.Is(err,pgx.ErrNoRows){return Receipt{},ErrUnavailable}
  rule,err:=s.rule(ctx,tx,in.Category,now);if err!=nil{return Receipt{},err};severity:=urgency(in.Category,in.Subject+" "+in.Message);ack,due,backup:=deadlines(now,rule.Ack,rule.Resolve,rule.Backup,severity)
  id,err:=randomRef();if err!=nil{return Receipt{},err};key,encryptedKey,err:=s.newFingerprintKey(id);if err!=nil{return Receipt{},err};defer clear(key);inputHash:=fingerprint(key,input);var account any;if g!=nil{account=g.AccountID}
  _,err=tx.Exec(ctx,`INSERT INTO notitle.grievances(ref,submission_id,secret_hash,submission_hash,account_id,kind,category,state,severity,received_at,acknowledge_due,resolution_due,policy_version,retention_until,fingerprint_key_id,fingerprint_nonce,fingerprint_ciphertext,retention_policy_version)VALUES($1,$2,$3,$4,$5,$6,$7,'received',$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)`,id,in.SubmissionID,secret[:],inputHash[:],account,in.Kind,in.Category,severity,now,ack,due,rule.Version,now.Add(time.Duration(s.options.RetentionDays)*24*time.Hour),encryptedKey.KeyID,encryptedKey.Nonce,encryptedKey.Ciphertext,s.options.RetentionPolicyVersion);if err!=nil{return Receipt{},ErrUnavailable}
  if err=s.insertMessage(ctx,tx,id,in.SubmissionID,"complainant",in.Subject,in.Message,true,in.Kind=="appeal",inputHash,now);err!=nil{return Receipt{},err}
  if err=enqueue(ctx,tx,id,1,"new_case",severity,now,backup);err!=nil{return Receipt{},err};c,err:=summary(ctx,tx,id);return Receipt{Case:c,StatusSecret:in.StatusSecret},err
 })
}
func(s *PostgresStore)Status(ctx context.Context,in Credential,now time.Time)(CaseDetail,error){return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(CaseDetail,error){ref,_,err:=credential(ctx,tx,in);if err!=nil{return CaseDetail{},err};return s.detail(ctx,tx,ref,false)})}
func(s *PostgresStore)AccountCases(ctx context.Context,g identity.Guard,now time.Time)([]CaseSummary,error){return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)([]CaseSummary,error){if err:=accountGuard(ctx,tx,g,now);err!=nil{return nil,err};rows,err:=tx.Query(ctx,`SELECT `+summaryColumns+` FROM notitle.grievances WHERE account_id=$1 ORDER BY received_at DESC,ref LIMIT 100`,g.AccountID);if err!=nil{return nil,ErrUnavailable};defer rows.Close();out:=[]CaseSummary{};for rows.Next(){v,err:=scanSummary(rows);if err!=nil{return nil,err};out=append(out,v)};if rows.Err()!=nil{return nil,ErrUnavailable};return out,nil})}
func ownedCase(ctx context.Context,tx pgx.Tx,g identity.Guard,ref string,now time.Time)([]byte,error){if !referencePattern.MatchString(ref){return nil,ErrNotFound};if err:=accountGuard(ctx,tx,g,now);err!=nil{return nil,err};var secret []byte;err:=tx.QueryRow(ctx,`SELECT secret_hash FROM notitle.grievances WHERE ref=$1 AND account_id=$2 FOR UPDATE`,ref,g.AccountID).Scan(&secret);if errors.Is(err,pgx.ErrNoRows){return nil,ErrNotFound};if err!=nil{return nil,ErrUnavailable};return secret,nil}
func(s *PostgresStore)AccountCase(ctx context.Context,g identity.Guard,ref string,now time.Time)(CaseDetail,error){return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(CaseDetail,error){if _,err:=ownedCase(ctx,tx,g,ref,now);err!=nil{return CaseDetail{},err};return s.detail(ctx,tx,ref,false)})}
func(s *PostgresStore)Reply(ctx context.Context,in ReplyInput,now time.Time)(CaseDetail,error){return s.reply(ctx,nil,in,now)}
func(s *PostgresStore)AccountReply(ctx context.Context,g identity.Guard,in ReplyInput,now time.Time)(CaseDetail,error){if in.StatusSecret!=""{return CaseDetail{},ErrInvalid};return s.reply(ctx,&g,in,now)}
func(s *PostgresStore)reply(ctx context.Context,g *identity.Guard,in ReplyInput,now time.Time)(CaseDetail,error){
 if !referencePattern.MatchString(in.SubmissionID)||!validText(in.Message,5,4000){return CaseDetail{},ErrInvalid};now=now.UTC().Truncate(time.Microsecond)
 return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(CaseDetail,error){
  ref:=in.CaseRef;var err error;if g==nil{ref,_,err=credential(ctx,tx,in.Credential)}else{_,err=ownedCase(ctx,tx,*g,ref,now)};if err!=nil{return CaseDetail{},err};key,err:=s.fingerprintKey(ctx,tx,ref);if err!=nil{return CaseDetail{},err};defer clear(key)
  hash:=fingerprint(key,struct{Message string;Appeal bool}{in.Message,in.Appeal});var oldHash []byte;err=tx.QueryRow(ctx,`SELECT submission_hash FROM notitle.grievance_messages WHERE case_ref=$1 AND submission_id=$2`,ref,in.SubmissionID).Scan(&oldHash);if err==nil{if subtle.ConstantTimeCompare(hash[:],oldHash)!=1{return CaseDetail{},ErrConflict};return s.detail(ctx,tx,ref,false)};if !errors.Is(err,pgx.ErrNoRows){return CaseDetail{},ErrUnavailable}
  var count int;if tx.QueryRow(ctx,`SELECT count(*) FROM notitle.grievance_messages WHERE case_ref=$1`,ref).Scan(&count)!=nil{return CaseDetail{},ErrUnavailable};if count>=80{return CaseDetail{},ErrConflict}
  c,err:=summary(ctx,tx,ref);if err!=nil{return CaseDetail{},err};if c.State=="resolved"&&!in.Appeal{return CaseDetail{},ErrConflict}
  severity:=c.Severity;if urgency(c.Category,in.Message)=="urgent"{severity="urgent"};state:=c.State;if in.Appeal{state="appealed"}
  ack,due:=c.AcknowledgeDue,c.ResolutionDue
  // A reply or appeal never grants a new legal receipt or deadline. Reopened
  // older cases can be immediately overdue and are routed for review.
  _,err=tx.Exec(ctx,`UPDATE notitle.grievances SET state=$2,severity=$3,pending_attention=true,revision=revision+1,closed_at=CASE WHEN $2='resolved' THEN closed_at ELSE NULL END,acknowledge_due=$4,resolution_due=$5 WHERE ref=$1`,ref,state,severity,ack,due);if err!=nil{return CaseDetail{},ErrUnavailable}
  if err=s.insertMessage(ctx,tx,ref,in.SubmissionID,"complainant","",in.Message,false,in.Appeal,hash,now);err!=nil{return CaseDetail{},err};kind:="reply";if in.Appeal{kind="appeal"};backup:=now.Add(time.Hour);if severity=="urgent"{backup=now.Add(10*time.Minute)};if err=enqueue(ctx,tx,ref,c.Version+1,kind,severity,now,backup);err!=nil{return CaseDetail{},err};return s.detail(ctx,tx,ref,false)
 })
}
func enqueue(ctx context.Context,tx pgx.Tx,ref string,revision int64,kind,severity string,now,backup time.Time)error{for _,audience:=range []string{"primary","backup"}{id,err:=randomRef();if err!=nil{return err};at:=now;if audience=="backup"{at=backup};_,err=tx.Exec(ctx,`INSERT INTO notitle.operations_outbox(id,case_ref,event_revision,kind,severity,audience,available_at,created_at)VALUES($1,$2,$3,$4,$5,$6,$7,$8)`,id,ref,revision,kind,severity,audience,at,now);if err!=nil{return ErrUnavailable}};return nil}
