package operations

import (
 "context"
 "encoding/binary"
 "crypto/sha256"
 "time"
 "github.com/jackc/pgx/v5"
)
func(s *PostgresStore)ClaimNotifications(ctx context.Context,now time.Time,limit int)([]Notification,error){if limit<1||limit>4{return nil,ErrInvalid};return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)([]Notification,error){
 // Expired final leases cannot remain permanently invisible. Bounded cleanup
 // runs on every claim, while dead rows remain visible to private dashboards.
 if _,err:=tx.Exec(ctx,`UPDATE notitle.operations_outbox SET state='dead',lease_token=NULL,lease_until=NULL WHERE id IN (SELECT id FROM notitle.operations_outbox WHERE state='leased' AND lease_until<=$1 AND attempts>=8 ORDER BY lease_until LIMIT 100 FOR UPDATE SKIP LOCKED)`,now);err!=nil{return nil,ErrUnavailable}
 if _,err:=tx.Exec(ctx,`UPDATE notitle.operations_outbox o SET state='cancelled',lease_token=NULL,lease_until=NULL WHERE id IN(SELECT o.id FROM notitle.operations_outbox o JOIN notitle.grievances g ON g.ref=o.case_ref WHERE o.audience='backup' AND o.state IN ('pending','leased') AND (NOT g.pending_attention OR g.acknowledged_revision>=o.event_revision) LIMIT 100 FOR UPDATE OF o SKIP LOCKED)`);err!=nil{return nil,ErrUnavailable}
 rows,err:=tx.Query(ctx,`SELECT o.id,o.case_ref,o.kind,o.severity,o.audience,o.attempts,o.available_at,o.created_at FROM notitle.operations_outbox o WHERE o.attempts<8 AND ((o.state='pending' AND o.available_at<=$1) OR (o.state='leased' AND o.lease_until<=$1)) ORDER BY (o.severity='urgent') DESC,o.available_at,o.id LIMIT $2 FOR UPDATE SKIP LOCKED`,now,limit);if err!=nil{return nil,ErrUnavailable};out:=[]Notification{};for rows.Next(){var n Notification;if rows.Scan(&n.ID,&n.CaseRef,&n.Kind,&n.Severity,&n.Audience,&n.Attempts,&n.DueAt,&n.OpenedAt)!=nil{rows.Close();return nil,ErrUnavailable};out=append(out,n)};rows.Close();if rows.Err()!=nil{return nil,ErrUnavailable}
 for i:=range out{token,err:=randomRef();if err!=nil{return nil,err};out[i].LeaseToken=token;out[i].Attempts++;if _,err=tx.Exec(ctx,`UPDATE notitle.operations_outbox SET state='leased',lease_token=$2,lease_until=$3,attempts=attempts+1 WHERE id=$1`,out[i].ID,token,now.Add(30*time.Second));err!=nil{return nil,ErrUnavailable}}
 return out,nil
})}
func(s *PostgresStore)ValidateNotification(ctx context.Context,n Notification,now time.Time)(bool,error){return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){var valid bool;err:=tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.operations_outbox o JOIN notitle.grievances g ON g.ref=o.case_ref WHERE o.id=$1 AND o.lease_token=$2 AND o.state='leased' AND o.lease_until>$3 AND (o.audience<>'backup' OR (g.pending_attention AND g.acknowledged_revision<o.event_revision)))`,n.ID,n.LeaseToken,now).Scan(&valid);if err!=nil{return false,ErrUnavailable};return valid,nil})}
func retryDelay(id string,attempt int)time.Duration{if attempt<1{attempt=1};if attempt>8{attempt=8};seconds:=30*(1<<uint(attempt-1));if seconds>900{seconds=900};h:=sha256.Sum256([]byte(id));return time.Duration(seconds+int(binary.BigEndian.Uint16(h[:2])%11))*time.Second}
func(s *PostgresStore)FinishNotification(ctx context.Context,n Notification,delivered bool,now time.Time)error{if !referencePattern.MatchString(n.ID)||!referencePattern.MatchString(n.LeaseToken)||n.Attempts<1||n.Attempts>8{return ErrInvalid};_,err:=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){state:="pending";var deliveredAt any;if delivered{state="delivered";deliveredAt=now}else if n.Attempts>=8{state="dead"};_,err:=tx.Exec(ctx,`UPDATE notitle.operations_outbox SET state=$3,available_at=$4,lease_token=NULL,lease_until=NULL,delivered_at=$5 WHERE id=$1 AND lease_token=$2 AND state='leased' AND lease_until>$6 AND attempts=$7`,n.ID,n.LeaseToken,state,now.Add(retryDelay(n.ID,n.Attempts)),deliveredAt,now,n.Attempts);if err!=nil{return false,ErrUnavailable};return true,nil});return err}
