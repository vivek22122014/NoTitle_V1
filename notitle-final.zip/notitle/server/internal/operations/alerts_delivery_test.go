package operations

import (
 "context"
 "testing"
 "time"
 "notitle/internal/observability"
)
type notificationFixture struct { job Notification; valid bool; finished bool; accepted bool }
func(f *notificationFixture)ClaimNotifications(context.Context,time.Time,int)([]Notification,error){return []Notification{f.job},nil}
func(f *notificationFixture)ValidateNotification(context.Context,Notification,time.Time)(bool,error){return f.valid,nil}
func(f *notificationFixture)FinishNotification(_ context.Context,_ Notification,success bool,_ time.Time)error{f.finished=true;f.accepted=success;return nil}
type receiverFixture struct { called bool; envelope observability.Envelope }
func(r *receiverFixture)Configured(string)bool{return true}
func(r *receiverFixture)Send(_ context.Context,_ string,e observability.Envelope)error{r.called=true;r.envelope=e;return nil}
func TestNotificationCannotSendAfterHumanAcknowledgement(t *testing.T){f:=&notificationFixture{job:Notification{ID:"0123456789abcdef0123456789abcdef",CaseRef:"private-case"},valid:false};r:=&receiverFixture{};w:=&AlertWorker{Store:f,Receiver:r};w.Step(context.Background());if r.called||f.finished{t.Fatal("invalidated lease delivered")}}
func TestNotificationProjectsOpaqueAlertAndRecordsTransportOnly(t *testing.T){now:=time.Unix(1800000000,0);f:=&notificationFixture{job:Notification{ID:"0123456789abcdef0123456789abcdef",CaseRef:"private-case",Severity:"urgent",Audience:"backup",DueAt:now,OpenedAt:now},valid:true};r:=&receiverFixture{};w:=&AlertWorker{Store:f,Receiver:r,Now:func()time.Time{return now}};w.Step(context.Background());if !r.called||!f.finished||!f.accepted||r.envelope.EventRef!=f.job.ID||r.envelope.Code!="case_attention"{t.Fatal("transport projection invalid")};if r.envelope.EventRef==f.job.CaseRef{t.Fatal("case identity leaked")}}
