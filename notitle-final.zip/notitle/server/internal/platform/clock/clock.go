// Package clock supplies wall time at domain boundaries; tests can inject a fixed clock.
package clock

import "time"

type Clock interface {
	Now() time.Time
}
type System struct{}
func (System) Now() time.Time {
	return time.Now().UTC()
}
