package identifier

import (
	"encoding/hex"
	"testing"
)

func TestCryptoIdentifier(t *testing.T) {
	generator := Crypto{}
	seen := make(map[string]bool)
	for range 1000 {
		id, err := generator.New()
		if err != nil {
			t.Fatal(err)
		}
		decoded, err := hex.DecodeString(id)
		if err != nil || len(decoded) != 16 || seen[id] {
			t.Fatal("identifier must be unique 128-bit hexadecimal")
		}
		seen[id] = true
	}
}
