// Package identifier creates opaque identifiers without a predictable fallback.
package identifier

import (
	"crypto/rand"
	"encoding/hex"
)

type Generator interface {
	New() (string, error)
}
type Crypto struct{}
func (Crypto) New() (string, error) {
	var bytes [16]byte
	if _, err := rand.Read(bytes[:]); err != nil {
		return "", err
	}
	return hex.EncodeToString(bytes[:]), nil
}
