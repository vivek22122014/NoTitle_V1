package operationshttp

import (
 "context"
 "encoding/json"
 "errors"
 "net/http"
 "net/http/httptest"
 "strings"
 "strconv"
 "testing"
 "time"
 "notitle/internal/identity"
 "notitle/internal/operations"
 "notitle/internal/privacy"
)
type fakeIdentity struct{calls int;principal identity.Principal;err error;cookie string}
func(f *fakeIdentity)Authenticate(_ context.Context,cookie string,_ bool)(identity.Principal,error){f.calls++;f.cookie=cookie;return f.principal,f.err}
type fakeCases struct{calls int;guard *identity.Guard;input operations.SubmitInput;credential operations.Credential;reply operations.ReplyInput;err error;detail operations.CaseDetail;notice *operations.Notice}
func(f *fakeCases)Submit(_ context.Context,g *identity.Guard,in operations.SubmitInput)(operations.Receipt,error){f.calls++;f.guard=g;f.input=in;return operations.Receipt{Case:f.detail.CaseSummary,StatusSecret:in.StatusSecret},f.err}
func(f *fakeCases)Status(_ context.Context,in operations.Credential)(operations.CaseDetail,error){f.calls++;f.credential=in;return f.detail,f.err}
func(f *fakeCases)Reply(_ context.Context,in operations.ReplyInput)(operations.CaseDetail,error){f.calls++;f.reply=in;return f.detail,f.err}
func(f *fakeCases)AccountCases(_ context.Context,g identity.Guard)([]operations.CaseSummary,error){f.calls++;f.guard=&g;return nil,f.err}
func(f *fakeCases)AccountCase(_ context.Context,g identity.Guard,ref string)(operations.CaseDetail,error){f.calls++;f.guard=&g;f.credential.CaseRef=ref;return f.detail,f.err}
func(f *fakeCases)AccountReply(_ context.Context,g identity.Guard,in operations.ReplyInput)(operations.CaseDetail,error){f.calls++;f.guard=&g;f.reply=in;return f.detail,f.err}
func(f *fakeCases)GuestNotice(context.Context)(*operations.Notice,error){f.calls++;return f.notice,f.err}
func(f *fakeCases)AccountNotice(_ context.Context,g identity.Guard)(*operations.Notice,error){f.calls++;f.guard=&g;return f.notice,f.err}
func(f *fakeCases)AcknowledgeNotice(_ context.Context,g identity.Guard,_ string)error{f.calls++;f.guard=&g;return f.err}
type fakePrivacy struct{calls int;guard identity.Guard;secret,ref string;err error}
func(f *fakePrivacy)Export(_ context.Context,g identity.Guard)(privacy.Export,error){f.calls++;f.guard=g;return privacy.Export{SchemaVersion:1},f.err}
func(f *fakePrivacy)ClosedReceipt(_ context.Context,secret,ref string)(privacy.ClosedReceipt,error){f.calls++;f.secret=secret;f.ref=ref;return privacy.ClosedReceipt{},f.err}
func newHandler(t *testing.T)(*Handler,*fakeCases,*fakeIdentity,*fakePrivacy){
 t.Helper();cases:=&fakeCases{detail:operations.CaseDetail{CaseSummary:operations.CaseSummary{Ref:strings.Repeat("r",32),Version:1},Subject:"private case content"}};ident:=&fakeIdentity{principal:identity.Principal{Kind:identity.KindAccount,AccountSession:identity.AccountSession{Account:identity.Account{ID:"00000000-0000-4000-8000-000000000001",Generation:3},Session:identity.SessionRecord{ID:"00000000-0000-4000-8000-000000000002"}}}};priv:=&fakePrivacy{}
 h,err:=New(Options{Identity:ident,Cases:cases,Privacy:priv,Ready:func(context.Context)error{return nil},IdentityReady:func(context.Context)error{return nil},PublicOrigin:"https://notitle.example",Now:func()time.Time{return time.Unix(1800000000,0)}});if err!=nil{t.Fatal(err)};return h,cases,ident,priv
}
func request(t *testing.T,h *Handler,method,path,body string)*http.Request{
 t.Helper();r:=httptest.NewRequest(method,"https://notitle.example"+path,strings.NewReader(body));r.RemoteAddr="192.0.2.10:54321";r.Header.Set("Origin",h.options.PublicOrigin);r.Header.Set("Content-Type","application/json")
 if method=="POST"{cookie,token,err:=h.issueCSRF();if err!=nil{t.Fatal(err)};r.AddCookie(&http.Cookie{Name:h.csrfCookie,Value:cookie});r.Header.Set("X-CSRF-Token",token)};return r
}
const submitted=`{"submission_id":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","status_secret":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA","kind":"grievance","category":"general","subject":"Help with access","message":"Account unavailable"}`
func TestAnonymousSupportSurvivesAccountReadinessFailure(t *testing.T){
 h,cases,ident,_:=newHandler(t);h.options.IdentityReady=func(context.Context)error{return errors.New("deleted account replay not ready")}
 w:=httptest.NewRecorder();r:=request(t,h,"POST","/api/v1/support/cases",submitted);r.AddCookie(&http.Cookie{Name:h.sessionCookie,Value:"obsolete-session"});h.ServeHTTP(w,r)
 if w.Code!=200||cases.calls!=1||cases.guard!=nil||ident.calls!=0{t.Fatal("anonymous support depended on account readiness",w.Code)}
}
func TestBootstrapHasDedicatedSecureCSRFAndNoAccountDependency(t *testing.T){
 h,_,ident,_:=newHandler(t);h.options.IdentityReady=func(context.Context)error{return errors.New("unavailable")};w:=httptest.NewRecorder();h.ServeHTTP(w,request(t,h,"GET","/api/v1/support/bootstrap",""));if w.Code!=200||ident.calls!=0{t.Fatal("bootstrap blocked")}
 var body struct{CSRF string `json:"csrf_token"`;Available bool `json:"available"`};if json.Unmarshal(w.Body.Bytes(),&body)!=nil||!body.Available||len(body.CSRF)!=43{t.Fatal("invalid bootstrap")}
 cookies:=w.Result().Cookies();if len(cookies)!=1{t.Fatal("unexpected cookies")};c:=cookies[0];if c.Name!=h.csrfCookie||!c.Secure||!c.HttpOnly||c.Domain!=""||c.Path!="/"||c.SameSite!=http.SameSiteLaxMode||!h.validCSRF(c.Value,body.CSRF){t.Fatal("weak support CSRF cookie")};if w.Header().Get("Cache-Control")!="no-store"{t.Fatal("bootstrap cached")}
}
func TestOriginCSRFAndAmbiguousCredentialsRejectBeforeBackend(t *testing.T){
 for _,mode:=range []string{"wrong_origin","no_origin","two_origins","cross_site","bad_csrf","two_csrf_headers","two_content_types","two_csrf_cookies","two_sessions","query","encoded_path"}{
  h,cases,ident,_:=newHandler(t);r:=request(t,h,"POST","/api/v1/support/cases",submitted)
  switch mode{case "wrong_origin":r.Header.Set("Origin","https://attacker.example");case "no_origin":r.Header.Del("Origin");case "two_origins":r.Header.Add("Origin",h.options.PublicOrigin);case "cross_site":r.Header.Set("Sec-Fetch-Site","cross-site");case "bad_csrf":r.Header.Set("X-CSRF-Token","wrong");case "two_csrf_headers":r.Header.Add("X-CSRF-Token",r.Header.Get("X-CSRF-Token"));case "two_content_types":r.Header.Add("Content-Type","application/json");case "two_csrf_cookies":r.AddCookie(&http.Cookie{Name:h.csrfCookie,Value:"another"});case "two_sessions":r.AddCookie(&http.Cookie{Name:h.sessionCookie,Value:"first"});r.AddCookie(&http.Cookie{Name:h.sessionCookie,Value:"second"});case "query":r.URL.RawQuery="secret=never-in-URL";case "encoded_path":r.URL.RawPath="/api/v1/support/%63ases"}
  w:=httptest.NewRecorder();h.ServeHTTP(w,r);if w.Code<400||cases.calls!=0||ident.calls!=0{t.Fatal("untrusted request reached backend",mode,w.Code)}
 }
}
func TestStrictJSONRejectsDuplicateNullUnknownNestedAndInvalidUnicode(t *testing.T){
 inputs:=[]string{`{"case_ref":"one","case_ref":"two","status_secret":"secret"}`,`{"case_ref":null,"status_secret":"secret"}`,`{"case_ref":{"nested":"value"},"status_secret":"secret"}`,`{"case_ref":"one","status_secret":"secret","admin_id":"forged"}`,`{"case_ref":"one","status_secret":"secret"} {}`,`{"case_ref":"\ud800","status_secret":"secret"}`,`{"case_ref":12,"status_secret":"secret"}`}
 for _,body:=range inputs{h,cases,_,_:=newHandler(t);w:=httptest.NewRecorder();h.ServeHTTP(w,request(t,h,"POST","/api/v1/support/case/access",body));if w.Code!=400||cases.calls!=0{t.Fatal("invalid JSON reached case service",body,w.Code)}}
}
func TestPrivateErrorsAndCaseBearerFailuresDoNotDiscloseContent(t *testing.T){
 for _,err:=range []error{operations.ErrNotFound,operations.ErrUnauthorized,errors.New("database secret bearer and private trace")} {h,cases,_,_:=newHandler(t);cases.err=err;w:=httptest.NewRecorder();r:=request(t,h,"POST","/api/v1/support/case/access",`{"case_ref":"opaque-ref","status_secret":"sensitive-bearer"}`);h.ServeHTTP(w,r);if w.Code<400||strings.Contains(w.Body.String(),"private")||strings.Contains(w.Body.String(),"sensitive-bearer")||strings.Contains(w.Body.String(),"database"){t.Fatal("backend details exposed")};if (errors.Is(err,operations.ErrNotFound)||errors.Is(err,operations.ErrUnauthorized))&&w.Code!=404{t.Fatal("bearer existence oracle")};if r.Pattern!="POST /api/v1/support/case/access"{t.Fatal("unsafe route pattern")}}
}
func TestAccountCasesUseAuthenticatedGuardAndRejectGuest(t *testing.T){
 h,cases,ident,_:=newHandler(t);r:=request(t,h,"GET","/api/v1/me/support/cases","");r.AddCookie(&http.Cookie{Name:h.sessionCookie,Value:"account-secret"});w:=httptest.NewRecorder();h.ServeHTTP(w,r);if w.Code!=200||cases.guard==nil||cases.guard.AccountID!=ident.principal.AccountSession.Account.ID||cases.guard.AccountGeneration!=3||ident.cookie!="account-secret"||!strings.Contains(w.Body.String(),`"cases":[]`){t.Fatal("account guard lost")}
 h,cases,ident,_=newHandler(t);ident.principal.Kind=identity.KindGuest;w=httptest.NewRecorder();h.ServeHTTP(w,request(t,h,"GET","/api/v1/me/support/cases",""));if w.Code!=401||cases.calls!=0{t.Fatal("guest read durable account cases")}
}
func TestAccountReadinessAndPrivacyReauthenticationFailClosed(t *testing.T){
 h,cases,ident,priv:=newHandler(t);h.options.IdentityReady=func(context.Context)error{return errors.New("unready")};w:=httptest.NewRecorder();h.ServeHTTP(w,request(t,h,"POST","/api/v1/privacy/export",`{}`));if w.Code!=503||priv.calls!=0||cases.calls!=0||ident.calls!=0{t.Fatal("unready identity exported")}
 h,_,ident,priv=newHandler(t);priv.err=identity.ErrReauthentication;w=httptest.NewRecorder();h.ServeHTTP(w,request(t,h,"POST","/api/v1/privacy/export",`{}`));if w.Code!=403||!strings.Contains(w.Body.String(),"reauthentication_required")||!priv.guard.RequireRecent||priv.guard.AccountID!=ident.principal.AccountSession.Account.ID{t.Fatal("privacy export lost recent-auth boundary")}
}
func TestClosedReceiptUsesIndependentProofWithoutIdentity(t *testing.T){
 h,_,ident,priv:=newHandler(t);h.options.IdentityReady=func(context.Context)error{return errors.New("account deleted")};w:=httptest.NewRecorder();h.ServeHTTP(w,request(t,h,"POST","/api/v1/privacy/closed-receipt",`{"deletion_receipt":"independent-secret","purchase_ref":"retained-purchase"}`));if w.Code!=200||priv.secret!="independent-secret"||priv.ref!="retained-purchase"||ident.calls!=0{t.Fatal("closed receipt depends on active account")};if strings.Contains(w.Body.String(),"independent-secret"){t.Fatal("receipt proof echoed")}
}
func TestBodyAndAdmissionBudgetsAreBounded(t *testing.T){
 h,cases,_,_:=newHandler(t);w:=httptest.NewRecorder();h.ServeHTTP(w,request(t,h,"POST","/api/v1/support/cases",`{"message":"`+strings.Repeat("a",17<<10)+`"}`));if w.Code!=413||cases.calls!=0{t.Fatal("body bound failed")}
 h,cases,_,_=newHandler(t);cookie,token,err:=h.issueCSRF();if err!=nil{t.Fatal(err)};sameVisitor:=func()*http.Request{r:=request(t,h,"POST","/api/v1/support/cases",submitted);r.Header.Set("Cookie",h.csrfCookie+"="+cookie);r.Header.Set("X-CSRF-Token",token);return r};for i:=0;i<10;i++{w=httptest.NewRecorder();h.ServeHTTP(w,sameVisitor());if w.Code!=200{t.Fatal("expected create budget",i,w.Code)}};w=httptest.NewRecorder();h.ServeHTTP(w,sameVisitor());if w.Code!=429||cases.calls!=10||w.Header().Get("Retry-After")==""{t.Fatal("unbounded intake")}
}
func TestAccountReplyNeverAcceptsBearerOrActorOverride(t *testing.T){
 h,cases,_,_:=newHandler(t);w:=httptest.NewRecorder();h.ServeHTTP(w,request(t,h,"POST","/api/v1/me/support/case/reply",`{"case_ref":"ref","submission_id":"id","message":"appeal","appeal":true,"status_secret":"borrowed"}`));if w.Code!=400||cases.calls!=0{t.Fatal("account route accepted bearer override")}
}
func TestCSRFExpiryAndProcessRestartInvalidateOldPermit(t *testing.T){
 h,_,_,_:=newHandler(t);cookie,token,err:=h.issueCSRF();if err!=nil{t.Fatal(err)};other,_,_,_:=newHandler(t);if other.validCSRF(cookie,token){t.Fatal("crossprocess token accepted")};now:=h.options.Now();h.options.Now=func()time.Time{return now.Add(30*time.Minute)};if h.validCSRF(cookie,token){t.Fatal("expired token accepted")}
}
func TestUnsupportedMethodsAndUnknownRoutesCannotReachBackend(t *testing.T){
 for _,pair:=range [][2]string{{"GET","/api/v1/support/cases"},{"PUT","/api/v1/support/case/access"},{"POST","/api/v1/support/unknown"}}{h,cases,_,_:=newHandler(t);w:=httptest.NewRecorder();h.ServeHTTP(w,request(t,h,pair[0],pair[1],`{}`));if w.Code<400||cases.calls!=0{t.Fatal("unsupported route")}}
}
func TestExpiredIntakePolicyDoesNotHideExistingCase(t *testing.T){
 h,cases,_,_:=newHandler(t);h.options.IntakeReady=func(context.Context)error{return errors.New("policy review expired")}
 w:=httptest.NewRecorder();h.ServeHTTP(w,request(t,h,"GET","/api/v1/support/status",""));if w.Code!=200||!strings.Contains(w.Body.String(),`"available":false`){t.Fatal("intake status concealed expired policy")}
 w=httptest.NewRecorder();h.ServeHTTP(w,request(t,h,"POST","/api/v1/support/case/access",`{"case_ref":"opaque-ref","status_secret":"existing-private-proof"}`));if w.Code!=200||cases.calls!=1||cases.credential.StatusSecret!="existing-private-proof"{t.Fatal("policy expiry stranded existing requester",w.Code)}
 w=httptest.NewRecorder();h.ServeHTTP(w,request(t,h,"POST","/api/v1/support/case/reply",`{"case_ref":"opaque-ref","status_secret":"existing-private-proof","submission_id":"request-key","message":"New information","appeal":false}`));if w.Code!=200||cases.calls!=2{t.Fatal("policy expiry prevented existing reply",w.Code)}
 w=httptest.NewRecorder();h.ServeHTTP(w,request(t,h,"POST","/api/v1/support/cases",submitted));if w.Code!=503||cases.calls!=2{t.Fatal("expired intake policy admitted a new case",w.Code)}
}

func TestTwoHundredVisitorsCanBootstrapAndReadNoticesBehindOneProxy(t *testing.T){
 h,cases,_,_:=newHandler(t)
 for i:=0;i<200;i++{
  w:=httptest.NewRecorder();h.ServeHTTP(w,request(t,h,"GET","/api/v1/support/bootstrap",""));if w.Code!=200{t.Fatal("shared proxy blocked bootstrap",i,w.Code)}
  cookies:=w.Result().Cookies();if len(cookies)!=1{t.Fatal("missing visitor cookie")};var payload struct{CSRF string `json:"csrf_token"`};if json.Unmarshal(w.Body.Bytes(),&payload)!=nil{t.Fatal("bootstrap response")}
  r:=request(t,h,"POST","/api/v1/notices/current",`{}`);r.Header.Set("Cookie",cookies[0].Name+"="+cookies[0].Value);r.Header.Set("X-CSRF-Token",payload.CSRF);w=httptest.NewRecorder();h.ServeHTTP(w,r);if w.Code!=200{t.Fatal("shared proxy blocked signed visitor",i,w.Code)}
 }
 if cases.calls!=200{t.Fatal("notice service call count")}
}
func TestSignedVisitorsHaveIsolatedBucketsButSharedCreateBudget(t *testing.T){
 h,cases,_,_:=newHandler(t);cookie,token,err:=h.issueCSRF();if err!=nil{t.Fatal(err)}
 for i:=0;i<11;i++{r:=request(t,h,"POST","/api/v1/support/cases",submitted);r.Header.Set("Cookie",h.csrfCookie+"="+cookie);r.Header.Set("X-CSRF-Token",token);r.Header.Set("X-Forwarded-For","198.51.100."+strconv.Itoa(i+1));w:=httptest.NewRecorder();h.ServeHTTP(w,r);if i<10&&w.Code!=200||i==10&&w.Code!=429{t.Fatal("spoofed forwarding changed visitor bucket",i,w.Code)}}
 // New signed cookies represent separate visitor buckets; they cannot expand
 // the process-wide limit when an attacker continually creates new visitors.
 for i:=0;i<21;i++{w:=httptest.NewRecorder();h.ServeHTTP(w,request(t,h,"POST","/api/v1/support/cases",submitted));if i<20&&w.Code!=200||i==20&&w.Code!=429{t.Fatal("global create budget bypass",i,w.Code)}}
 if cases.calls!=30{t.Fatal("global create count",cases.calls)}
}
func TestUnsignedBootstrapStillHasGlobalAdmissionLimit(t *testing.T){
 h,_,_,_:=newHandler(t);for i:=0;i<301;i++{r:=request(t,h,"GET","/api/v1/support/bootstrap","");r.Header.Set("X-Forwarded-For","198.51.100.200");w:=httptest.NewRecorder();h.ServeHTTP(w,r);if i<300&&w.Code!=200||i==300&&w.Code!=429{t.Fatal("unbounded bootstrap minting",i,w.Code)}}
}
