package operationshttp

import (
 "bytes"
 "crypto/hmac"
 "crypto/rand"
 "crypto/sha256"
 "crypto/subtle"
 "encoding/base64"
 "encoding/json"
 "errors"
 "io"
 "mime"
 "net/http"
 "strconv"
 "strings"
 "time"
 "unicode/utf8"
 "notitle/internal/httpserver/apierror"
 "notitle/internal/realtime"
)
func(h *Handler)mac(purpose,value string)string{m:=hmac.New(sha256.New,h.key[:]);_,_=m.Write([]byte(purpose));_,_=m.Write([]byte(value));return base64.RawURLEncoding.EncodeToString(m.Sum(nil))}
func(h *Handler)issueCSRF()(string,string,error){var random [32]byte;if _,err:=rand.Read(random[:]);err!=nil{return "","",err};value:=base64.RawURLEncoding.EncodeToString(random[:])+"."+strconv.FormatInt(h.options.Now().Add(30*time.Minute).Unix(),10);value+="."+h.mac("cookie:",value);return value,h.mac("header:",value),nil}
func(h *Handler)validCSRF(cookie,token string)bool{if len(cookie)>128||len(token)!=43{return false};parts:=strings.Split(cookie,".");if len(parts)!=3||len(parts[0])!=43{return false};raw,err:=base64.RawURLEncoding.DecodeString(parts[0]);if err!=nil||len(raw)!=32{return false};expires,err:=strconv.ParseInt(parts[1],10,64);if err!=nil||expires<=h.options.Now().Unix()||expires>h.options.Now().Add(30*time.Minute).Unix(){return false};return subtle.ConstantTimeCompare([]byte(parts[2]),[]byte(h.mac("cookie:",parts[0]+"."+parts[1])))==1&&subtle.ConstantTimeCompare([]byte(token),[]byte(h.mac("header:",cookie)))==1}
func(h *Handler)decode(w http.ResponseWriter,r *http.Request,dst any)bool{
 media,params,err:=mime.ParseMediaType(r.Header.Get("Content-Type"));if err!=nil||media!="application/json"||(params["charset"]!=""&&!strings.EqualFold(params["charset"],"utf-8")){h.fail(w,r,apierror.UnsupportedMedia);return false}
 r.Body=http.MaxBytesReader(w,r.Body,16<<10);data,err:=io.ReadAll(r.Body);if err!=nil{var limit *http.MaxBytesError;if errors.As(err,&limit){h.fail(w,r,apierror.TooLarge)}else{h.fail(w,r,apierror.Invalid)};return false};defer clear(data)
 if !utf8.Valid(data)||!realtime.ValidJSONUnicode(data)||!flatObject(data){h.fail(w,r,apierror.Invalid);return false};decoder:=json.NewDecoder(bytes.NewReader(data));decoder.DisallowUnknownFields();if decoder.Decode(dst)!=nil{h.fail(w,r,apierror.Invalid);return false};return true
}
// Operations requests contain only explicit scalar fields. Reject duplicate
// keys, null, nested payloads and trailing JSON before typed decoding.
func flatObject(data []byte)bool{d:=json.NewDecoder(bytes.NewReader(data));d.UseNumber();first,e:=d.Token();if e!=nil||first!=json.Delim('{'){return false};seen:=map[string]bool{};for d.More(){key,e:=d.Token();if e!=nil{return false};name,ok:=key.(string);if !ok||seen[name]{return false};seen[name]=true;if len(seen)>12{return false};value,e:=d.Token();if e!=nil||value==nil{return false};if _,nested:=value.(json.Delim);nested{return false}};last,e:=d.Token();if e!=nil||last!=json.Delim('}'){return false};_,e=d.Token();return errors.Is(e,io.EOF)}
