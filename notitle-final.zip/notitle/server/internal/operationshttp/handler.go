// Package operationshttp serves deliberately submitted support information.
// Public case access remains independent of account/realtime availability.
package operationshttp

import (
 "context"
 "crypto/rand"
 "encoding/json"
 "errors"
 "net/http"
 "net/url"
 "strings"
 "time"
 "notitle/internal/httpserver/apierror"
 "notitle/internal/httpserver/middleware"
 "notitle/internal/identity"
 "notitle/internal/operations"
 "notitle/internal/privacy"
)
type Identity interface { Authenticate(context.Context,string,bool)(identity.Principal,error) }
type Cases interface {
 Submit(context.Context,*identity.Guard,operations.SubmitInput)(operations.Receipt,error)
 Status(context.Context,operations.Credential)(operations.CaseDetail,error)
 Reply(context.Context,operations.ReplyInput)(operations.CaseDetail,error)
 AccountCases(context.Context,identity.Guard)([]operations.CaseSummary,error)
 AccountCase(context.Context,identity.Guard,string)(operations.CaseDetail,error)
 AccountReply(context.Context,identity.Guard,operations.ReplyInput)(operations.CaseDetail,error)
 GuestNotice(context.Context)(*operations.Notice,error)
 AccountNotice(context.Context,identity.Guard)(*operations.Notice,error)
 AcknowledgeNotice(context.Context,identity.Guard,string)error
}
type Privacy interface {
 Export(context.Context,identity.Guard)(privacy.Export,error)
 ClosedReceipt(context.Context,string,string)(privacy.ClosedReceipt,error)
}
type Options struct {
 Identity Identity; Cases Cases; Privacy Privacy
 Ready,IdentityReady,IntakeReady func(context.Context)error
 PublicOrigin string;AllowInsecureLocalhost bool;Now func()time.Time
}
type Handler struct { options Options;key [32]byte;secure bool;csrfCookie,sessionCookie string;slots chan struct{};limits *limiter }
func New(o Options)(*Handler,error){
 u,err:=url.Parse(o.PublicOrigin);if err!=nil||u.Hostname()==""||u.User!=nil||u.Path!=""||u.RawQuery!=""||u.ForceQuery||u.Fragment!=""||u.Opaque!=""||strings.Contains(o.PublicOrigin,"#"){return nil,operations.ErrInvalid}
 secure:=u.Scheme=="https";local:=u.Hostname()=="localhost"||u.Hostname()=="127.0.0.1"||u.Hostname()=="::1"
 if !secure&&!(o.AllowInsecureLocalhost&&local&&u.Scheme=="http"){return nil,operations.ErrInvalid};if o.Now==nil{o.Now=time.Now}
 h:=&Handler{options:o,secure:secure,csrfCookie:"__Host-notitle-support",sessionCookie:"__Host-session",slots:make(chan struct{},16)}
 if !secure{h.csrfCookie="notitle_dev_support";h.sessionCookie="notitle_dev_session"};if _,err=rand.Read(h.key[:]);err!=nil{return nil,operations.ErrUnavailable};h.limits=newLimiter(h.key);return h,nil
}
var routes=map[string]string{
 "/api/v1/support/status":"GET", "/api/v1/support/bootstrap":"GET",
 "/api/v1/support/cases":"POST", "/api/v1/support/case/access":"POST", "/api/v1/support/case/reply":"POST",
 "/api/v1/me/support/cases":"GET, POST", "/api/v1/me/support/case/access":"POST", "/api/v1/me/support/case/reply":"POST",
 "/api/v1/notices/current":"POST", "/api/v1/notices/ack":"POST",
 "/api/v1/privacy/export":"POST", "/api/v1/privacy/closed-receipt":"POST",
}
func(h *Handler)Owns(path string)bool{_,ok:=routes[path];return ok}
func(h *Handler)serviceAvailable(ctx context.Context)bool{return h.options.Cases!=nil&&h.options.Ready!=nil&&h.options.Ready(ctx)==nil}
func(h *Handler)available(ctx context.Context)bool{return h.serviceAvailable(ctx)&&(h.options.IntakeReady==nil||h.options.IntakeReady(ctx)==nil)}
func(h *Handler)ServeHTTP(w http.ResponseWriter,r *http.Request){
 w.Header().Set("Cache-Control","no-store");w.Header().Set("Content-Type","application/json; charset=utf-8");w.Header().Set("Vary","Cookie, Origin")
 methods,ok:=routes[r.URL.Path];if !ok{h.fail(w,r,apierror.NotFound);return};r.Pattern=r.Method+" "+r.URL.Path
 if r.URL.RawQuery!=""||r.URL.ForceQuery||r.URL.EscapedPath()!=r.URL.Path{h.fail(w,r,apierror.Invalid);return}
 if !strings.Contains(", "+methods+",",", "+r.Method+","){w.Header().Set("Allow",methods);h.fail(w,r,apierror.MethodNotAllowed);return}
 if len(r.Header.Values("Origin"))>1||r.Header.Get("Sec-Fetch-Site")=="cross-site"{h.fail(w,r,apierror.Forbidden);return}
 if origin:=r.Header.Get("Origin");(origin!=""&&origin!=h.options.PublicOrigin)||(r.Method=="POST"&&origin!=h.options.PublicOrigin){h.fail(w,r,apierror.Forbidden);return}
 if r.Method=="POST"&&(len(r.Header.Values("X-CSRF-Token"))!=1||len(r.Header.Values("Content-Type"))!=1){h.fail(w,r,apierror.Forbidden);return}
 for _,name:=range []string{h.csrfCookie,h.sessionCookie}{count:=0;for _,cookie:=range r.Cookies(){if cookie.Name==name{count++}};if count>1{h.fail(w,r,apierror.Forbidden);return}}
 select{case h.slots<-struct{}{}:defer func(){<-h.slots}();default:h.fail(w,r,apierror.Unavailable);return}
 ctx,cancel:=context.WithTimeout(r.Context(),5*time.Second);defer cancel();r=r.WithContext(ctx)
 // Caddy is the immediate peer for every visitor. A verified server-issued
 // cookie gives each visitor a bounded bucket without trusting forwarded IPs.
 // Independent global budgets still constrain attackers minting new cookies.
 category,source:="request",r.RemoteAddr
 cookie:=h.cookie(r,h.csrfCookie)
 if h.validCSRF(cookie,h.mac("header:",cookie)){source="visitor:"+cookie}else if r.URL.Path=="/api/v1/support/bootstrap"||r.URL.Path=="/api/v1/support/status"{category="bootstrap"}
 if !h.limits.allow(h.options.Now(),category,source){w.Header().Set("Retry-After","60");h.fail(w,r,apierror.RateLimited);return}
 switch r.URL.Path{
 case "/api/v1/support/status":h.json(w,struct{Available bool `json:"available"`}{h.available(ctx)});return
 case "/api/v1/support/bootstrap":cookie:=h.cookie(r,h.csrfCookie);token:=h.mac("header:",cookie);if !h.validCSRF(cookie,token){var err error;cookie,token,err=h.issueCSRF();if err!=nil{h.fail(w,r,err);return};http.SetCookie(w,&http.Cookie{Name:h.csrfCookie,Value:cookie,Path:"/",Secure:h.secure,HttpOnly:true,SameSite:http.SameSiteLaxMode,MaxAge:1800,Expires:h.options.Now().Add(30*time.Minute)})};h.json(w,struct{CSRF string `json:"csrf_token"`;Available bool `json:"available"`}{token,h.available(ctx)});return
 }
 if r.Method=="POST"&&!h.validCSRF(h.cookie(r,h.csrfCookie),r.Header.Get("X-CSRF-Token")){h.fail(w,r,apierror.Forbidden);return}
 account:=strings.HasPrefix(r.URL.Path,"/api/v1/me/")||r.URL.Path=="/api/v1/privacy/export"||r.URL.Path=="/api/v1/notices/ack"
 var guard identity.Guard
 if account{var err error;guard,err=h.account(r,r.URL.Path=="/api/v1/privacy/export");if err!=nil{h.fail(w,r,err);return}}
 if !h.serviceAvailable(ctx){h.fail(w,r,apierror.Unavailable);return}
 if r.URL.Path=="/api/v1/support/cases"||r.URL.Path=="/api/v1/me/support/cases"&&r.Method=="POST"{if !h.available(ctx){h.fail(w,r,apierror.Unavailable);return};if !h.limits.allow(h.options.Now(),"create",source){w.Header().Set("Retry-After","60");h.fail(w,r,apierror.RateLimited);return}}
 switch r.URL.Path{
 case "/api/v1/support/cases":var in operations.SubmitInput;if !h.decode(w,r,&in){return};out,err:=h.options.Cases.Submit(ctx,nil,in);h.result(w,r,out,err)
 case "/api/v1/me/support/cases":if r.Method=="GET"{rows,err:=h.options.Cases.AccountCases(ctx,guard);if rows==nil{rows=[]operations.CaseSummary{}};h.result(w,r,struct{Cases []operations.CaseSummary `json:"cases"`}{rows},err);return};var in operations.SubmitInput;if !h.decode(w,r,&in){return};out,err:=h.options.Cases.Submit(ctx,&guard,in);h.result(w,r,out,err)
 case "/api/v1/support/case/access":var in operations.Credential;if !h.decode(w,r,&in){return};out,err:=h.options.Cases.Status(ctx,in);h.result(w,r,out,err)
 case "/api/v1/support/case/reply":var in operations.ReplyInput;if !h.decode(w,r,&in){return};out,err:=h.options.Cases.Reply(ctx,in);h.result(w,r,out,err)
 case "/api/v1/me/support/case/access":var in struct{Ref string `json:"case_ref"`};if !h.decode(w,r,&in){return};out,err:=h.options.Cases.AccountCase(ctx,guard,in.Ref);h.result(w,r,out,err)
 case "/api/v1/me/support/case/reply":var in struct{Ref string `json:"case_ref"`;SubmissionID string `json:"submission_id"`;Message string `json:"message"`;Appeal bool `json:"appeal"`};if !h.decode(w,r,&in){return};out,err:=h.options.Cases.AccountReply(ctx,guard,operations.ReplyInput{Credential:operations.Credential{CaseRef:in.Ref},SubmissionID:in.SubmissionID,Message:in.Message,Appeal:in.Appeal});h.result(w,r,out,err)
 case "/api/v1/notices/current":var in struct{};if !h.decode(w,r,&in){return};var out *operations.Notice;var err error
  if h.cookie(r,h.sessionCookie)!=""&&h.options.Identity!=nil{p,authErr:=h.options.Identity.Authenticate(ctx,h.cookie(r,h.sessionCookie),false);if authErr==nil&&p.Kind==identity.KindAccount{if h.options.IdentityReady==nil||h.options.IdentityReady(ctx)!=nil{h.fail(w,r,apierror.Unavailable);return};out,err=h.options.Cases.AccountNotice(ctx,p.Guard(h.options.Now().UTC(),false))}else if authErr!=nil&&!errors.Is(authErr,identity.ErrUnauthorized)&&!errors.Is(authErr,identity.ErrStale){h.fail(w,r,authErr);return}else{out,err=h.options.Cases.GuestNotice(ctx)}}else{out,err=h.options.Cases.GuestNotice(ctx)}
  h.result(w,r,struct{Notice *operations.Notice `json:"notice"`}{out},err)
 case "/api/v1/notices/ack":var in struct{Version string `json:"version"`};if !h.decode(w,r,&in){return};if err:=h.options.Cases.AcknowledgeNotice(ctx,guard,in.Version);err!=nil{h.fail(w,r,err);return};w.WriteHeader(http.StatusNoContent)
 case "/api/v1/privacy/export":if h.options.Privacy==nil{h.fail(w,r,apierror.Unavailable);return};if !h.limits.allow(h.options.Now(),"export",guard.AccountID){w.Header().Set("Retry-After","60");h.fail(w,r,apierror.RateLimited);return};var in struct{};if !h.decode(w,r,&in){return};out,err:=h.options.Privacy.Export(ctx,guard);h.result(w,r,out,err)
 case "/api/v1/privacy/closed-receipt":if h.options.Privacy==nil{h.fail(w,r,apierror.Unavailable);return};var in struct{Receipt string `json:"deletion_receipt"`;Ref string `json:"purchase_ref"`};if !h.decode(w,r,&in){return};out,err:=h.options.Privacy.ClosedReceipt(ctx,in.Receipt,in.Ref);h.result(w,r,out,err)
 }
}
func(h *Handler)account(r *http.Request,recent bool)(identity.Guard,error){if h.options.Identity==nil{return identity.Guard{},identity.ErrUnauthorized};if h.options.IdentityReady==nil||h.options.IdentityReady(r.Context())!=nil{return identity.Guard{},identity.ErrUnavailable};p,err:=h.options.Identity.Authenticate(r.Context(),h.cookie(r,h.sessionCookie),false);if err!=nil{return identity.Guard{},err};if p.Kind!=identity.KindAccount{return identity.Guard{},identity.ErrUnauthorized};return p.Guard(h.options.Now().UTC(),recent),nil}
func(h *Handler)cookie(r *http.Request,name string)string{for _,c:=range r.Cookies(){if c.Name==name&&len(c.Value)<=256{return c.Value}};return ""}
func(h *Handler)json(w http.ResponseWriter,v any){w.WriteHeader(http.StatusOK);_ =json.NewEncoder(w).Encode(v)}
func(h *Handler)result(w http.ResponseWriter,r *http.Request,v any,err error){if err!=nil{h.fail(w,r,err);return};h.json(w,v)}
func(h *Handler)fail(w http.ResponseWriter,r *http.Request,err error){out:=apierror.Unavailable;var known apierror.Error;switch{
 case errors.As(err,&known):out=known
 case errors.Is(err,identity.ErrUnauthorized),errors.Is(err,privacy.ErrUnauthorized):out=apierror.Unauthorized
 case errors.Is(err,identity.ErrReauthentication):out=apierror.Reauthentication
 case errors.Is(err,operations.ErrUnauthorized),errors.Is(err,operations.ErrNotFound):out=apierror.NotFound
 case errors.Is(err,privacy.ErrForbidden):out=apierror.Forbidden
 case errors.Is(err,operations.ErrInvalid),errors.Is(err,privacy.ErrInvalid):out=apierror.Invalid
 case errors.Is(err,operations.ErrConflict),errors.Is(err,privacy.ErrConflict):out=apierror.SupportConflict
 };apierror.Write(w,middleware.RequestIDFromContext(r.Context()),out)}
