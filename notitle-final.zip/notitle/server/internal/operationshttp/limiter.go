package operationshttp
import("crypto/hmac";"crypto/sha256";"net";"sync";"time")
type bucket struct{tokens float64;at,last time.Time}
type limiter struct{mu sync.Mutex;key [32]byte;entries map[[32]byte]bucket;global map[string]bucket}
func newLimiter(key [32]byte)*limiter{return &limiter{key:key,entries:map[[32]byte]bucket{},global:map[string]bucket{}}}
func(l *limiter)allow(now time.Time,category,source string)bool{
 l.mu.Lock();defer l.mu.Unlock();capacity,rate,globalCap,globalRate:=60.0,2.0,300.0,20.0
 if category=="bootstrap"{capacity,rate,globalCap,globalRate=300,20,300,20}
 if category=="create"{capacity,rate,globalCap,globalRate=10,1.0/60,30,1.0/6};if category=="export"{capacity,rate,globalCap,globalRate=2,1.0/300,10,1.0/30}
 host,_,err:=net.SplitHostPort(source);if err==nil{source=host};m:=hmac.New(sha256.New,l.key[:]);_,_=m.Write([]byte(category+"\x00"+source));var key [32]byte;copy(key[:],m.Sum(nil))
 if len(l.entries)>=8192{for k,b:=range l.entries{if now.Sub(b.last)>time.Hour{delete(l.entries,k)}};if _,ok:=l.entries[key];!ok&&len(l.entries)>=8192{return false}}
 b,ok:=l.entries[key];if !ok{b=bucket{tokens:capacity,at:now}};g,ok:=l.global[category];if !ok{g=bucket{tokens:globalCap,at:now}}
 refill:=func(b *bucket,cap,rate float64){elapsed:=now.Sub(b.at).Seconds();if elapsed>0{b.tokens+=elapsed*rate;if b.tokens>cap{b.tokens=cap};b.at=now};b.last=now};refill(&b,capacity,rate);refill(&g,globalCap,globalRate)
 allowed:=b.tokens>=1&&g.tokens>=1;if allowed{b.tokens--;g.tokens--};l.entries[key]=b;l.global[category]=g;return allowed
}
