package coordinator

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"sync"
	"testing"
	"time"

	"notitle/internal/identity"
	rt "notitle/internal/realtime"
)

func rtNow() time.Time { return time.Date(2026, 10, 9, 10, 0, 0, 0, time.UTC) }
func accountAuth(n int, now time.Time) rt.AuthSnapshot {
	g := guestFixture(n, now)
	return rt.AuthSnapshot{Kind: identity.KindAccount, IdentityID: g.ID, IdentityGeneration: 1, SessionID: fmt.Sprintf("session_%08d", n), SessionVerifier: g.Verifier, Profile: g.Profile, Preferences: rt.DefaultPreferences(), SafetyVersion: 1, AuthorizedAt: now, ValidUntil: now.Add(30*time.Second)}
}
func memoryFixture() *liveMemory { var secret [32]byte; secret[0] = 7; return newLiveMemory(secret, newGuestMemory()) }
func attachFixture(t *testing.T, m *liveMemory, n int, now time.Time) (rt.Connection, *liveParticipant) {
	t.Helper(); auth := accountAuth(n, now); auth.Fence = m.fence
	result := m.attach(rt.AttachRequest{Auth: auth}, fmt.Sprintf("test_resume_secret_has_32_bytes_%08d", n), now)
	if result.err != nil { t.Fatal(result.err) }
	return result.connection, m.byConnection(result.connection.Ref)
}
func cmdFixture(ref rt.ConnectionRef, typ, id string, p *liveParticipant, m *liveMemory) rt.ClientEnvelope {
	command := rt.ClientEnvelope{V: 1, ID: id, Type: typ, Generation: ref.Generation, Payload: json.RawMessage(`{}`)}
	if typ == "match.end" || typ == "match.next" { interaction := m.interactions[p.interactionID]; if interaction != nil { command.InteractionID, command.Epoch = interaction.id, interaction.epoch } }
	return command
}
func doCommand(t *testing.T, m *liveMemory, connection rt.Connection, p *liveParticipant, typ, id string, now time.Time) rt.ClientEnvelope {
	t.Helper(); command := cmdFixture(connection.Ref, typ, id, p, m)
	if err := m.command(connection.Ref, command, now); err != nil { t.Fatalf("%s: %v",typ,err) }
	return command
}
func drain(connection rt.Connection) { for { select { case _, ok := <-connection.Events: if !ok { return }; default: return } } }

func TestRealtimeNextEndDedupeAndStaleEpoch(t *testing.T) {
	m := memoryFixture(); now := rtNow()
	a, pa := attachFixture(t,m,1,now); b,pb := attachFixture(t,m,2,now); c,pc := attachFixture(t,m,3,now)
	doCommand(t,m,a,pa,"queue.join","a_join",now)
	doCommand(t,m,b,pb,"queue.join","b_join",now)
	if pa.state != rt.Matched || pb.state != rt.Matched || len(m.interactions) != 1 { t.Fatal("one shared-pool match was not committed") }
	old := doCommand(t,m,a,pa,"match.next","a_next",now.Add(time.Second))
	if pa.state != rt.Waiting || pb.state != rt.Idle { t.Fatal("Next must queue only the initiator") }
	if err := m.command(a.Ref,old,now.Add(time.Second)); err != nil { t.Fatal("identical command retry was not deduplicated") }
	doCommand(t,m,c,pc,"queue.join","c_join",now.Add(time.Second))
	if pa.interactionID == "" || pa.interactionID != pc.interactionID || pb.interactionID != "" { t.Fatal("third participant did not match current waiting user") }
	old.ID = "a_stale_next"
	if err := m.command(a.Ref,old,now.Add(time.Second)); !errors.Is(err,rt.ErrStaleEpoch) { t.Fatal("old epoch could affect a new pair") }
	doCommand(t,m,a,pa,"match.end","a_end",now.Add(2*time.Second))
	if pa.state != rt.Idle || pc.state != rt.Idle || len(m.waiting) != 0 || len(m.interactions) != 0 { t.Fatal("End must leave both idle") }
}

func TestRealtimeReconnectRequiresMemorySecretInstanceEpochAndSession(t *testing.T) {
	m := memoryFixture(); now := rtNow()
	a,pa := attachFixture(t,m,1,now); b,pb := attachFixture(t,m,2,now)
	doCommand(t,m,a,pa,"queue.join","a_join",now); doCommand(t,m,b,pb,"queue.join","b_join",now)
	view := m.state(pa); oldRef := a.Ref
	m.disconnect(pa,now.Add(time.Second),"network")
	if m.state(pb).Interaction.PeerConnected || len(m.interactions) != 1 || m.connected() != 1 { t.Fatal("disconnected peer state was not frozen") }
	resume := rt.Resume{Token:view.ResumeToken,ServerInstance:view.ServerInstance,Generation:view.Generation,InteractionID:view.Interaction.ID,Epoch:view.Interaction.Epoch}
	auth := accountAuth(1,now.Add(2*time.Second)); auth.Fence = m.fence
	bad := resume; bad.Token = "different_random_secret_not_same_browser"
	if result := m.attach(rt.AttachRequest{Auth:auth,Resume:&bad},"replacement_secret",now.Add(2*time.Second)); !errors.Is(result.err,rt.ErrTakeoverRequired) { t.Fatal("same-cookie unrelated tab resumed match") }
	bad = resume; bad.Epoch++
	if result := m.attach(rt.AttachRequest{Auth:auth,Resume:&bad},"replacement_secret",now.Add(2*time.Second)); result.err == nil { t.Fatal("wrong epoch resumed") }
	result := m.attach(rt.AttachRequest{Auth:auth,Resume:&resume},"replacement_secret",now.Add(2*time.Second))
	if result.err != nil || pa.interactionID != pb.interactionID || result.connection.Ref.Generation == oldRef.Generation { t.Fatal("valid resume did not preserve exact match and rotate generation") }
	if err := m.command(oldRef,rt.ClientEnvelope{V:1,ID:"stale",Type:"heartbeat",Generation:oldRef.Generation,Payload:json.RawMessage(`{}`)},now); !errors.Is(err,rt.ErrStaleGeneration) { t.Fatal("old socket generation retained authority") }
	m.apply(realtimeRequest{op:opDetach,ref:oldRef},now)
	if pa.connection == nil { t.Fatal("late old-socket detach killed replacement") }
}

func TestRealtimeDisconnectQueueAndGraceExpiry(t *testing.T) {
	m := memoryFixture(); now := rtNow()
	a,pa := attachFixture(t,m,1,now)
	doCommand(t,m,a,pa,"queue.join","a_join",now)
	m.disconnect(pa,now,"network")
	if len(m.waiting) != 0 || len(m.participants) != 0 { t.Fatal("waiting disconnect retained queue/admission") }
	a,pa = attachFixture(t,m,1,now)
	b,pb := attachFixture(t,m,2,now)
	doCommand(t,m,a,pa,"queue.join","a_join_new",now); doCommand(t,m,b,pb,"queue.join","b_join",now)
	m.disconnect(pa,now,"network")
	m.maintain(now.Add(rt.ReconnectGrace-time.Nanosecond))
	if len(m.interactions) != 1 { t.Fatal("grace expired early") }
	m.maintain(now.Add(rt.ReconnectGrace))
	if len(m.interactions) != 0 || pb.state != rt.Idle || len(m.participants) != 1 { t.Fatal("grace boundary did not end/purge") }
}

func TestRealtimeExplicitTakeoverEndsPriorInteraction(t *testing.T) {
	m := memoryFixture(); now := rtNow()
	a,pa := attachFixture(t,m,1,now); b,pb := attachFixture(t,m,2,now)
	doCommand(t,m,a,pa,"queue.join","a_join",now); doCommand(t,m,b,pb,"queue.join","b_join",now)
	auth := accountAuth(1,now); auth.Fence = m.fence
	if result := m.attach(rt.AttachRequest{Auth:auth},"different_secret",now); !errors.Is(result.err,rt.ErrTakeoverRequired) { t.Fatal("second tab silently replaced live socket") }
	result := m.attach(rt.AttachRequest{Auth:auth,Takeover:true},"different_secret",now)
	if result.err != nil || pa.state != rt.Idle || pb.state != rt.Idle || len(m.interactions) != 0 { t.Fatal("takeover continued prior interaction") }
	select { case <-a.Closed: default: t.Fatal("old transport was not signaled closed") }
	if m.byConnection(a.Ref) != nil { t.Fatal("old socket still owns participant") }
}

func TestRealtimeFourSecondRematchAndStrictExpiryPause(t *testing.T) {
	m := memoryFixture(); now := rtNow()
	a,pa := attachFixture(t,m,1,now); b,pb := attachFixture(t,m,2,now)
	doCommand(t,m,a,pa,"queue.join","a_join",now); doCommand(t,m,b,pb,"queue.join","b_join",now)
	doCommand(t,m,a,pa,"match.next","a_next",now)
	doCommand(t,m,b,pb,"queue.join","b_again",now)
	m.maintain(now.Add(4*time.Second-time.Nanosecond))
	if len(m.interactions) != 0 { t.Fatal("rematched before cooldown") }
	m.maintain(now.Add(4*time.Second))
	if len(m.interactions) != 1 { t.Fatal("sole compatible peer remained hidden after cooldown") }
	drain(a); drain(b)
	doCommand(t,m,a,pa,"match.next","a_next_again",now.Add(4*time.Second))
	if !pa.advisory || !pb.advisory { t.Fatal("repeated skip advisory missing") }
	m.pause(pa,"test_setup")
	pa.auth.Preferences.Gender = rt.PreferFemale
	pa.auth.Entitlement = rt.Entitlement{Premium:true,Version:1,ExpiresAt:now.Add(6*time.Second)}
	doCommand(t,m,a,pa,"queue.join","a_strict",now.Add(5*time.Second))
	m.maintain(now.Add(6*time.Second))
	if pa.state != rt.Idle || pa.auth.Preferences.Gender != rt.PreferFemale { t.Fatal("expiry must pause without changing saved gender preference") }
	command := cmdFixture(a.Ref,"queue.join","a_expired",pa,m)
	if err := m.command(a.Ref,command,now.Add(6*time.Second)); !errors.Is(err,rt.ErrPremiumRequired) { t.Fatal("expired specific filter silently relaxed") }
	command.ID = "a_explicit_everyone"; command.Payload = json.RawMessage(`{"continue_with_everyone":true}`)
	if err := m.command(a.Ref,command,now.Add(6*time.Second)); err != nil || pa.queueAuth.Preferences.Gender != rt.Everyone || pa.auth.Preferences.Gender != rt.PreferFemale { t.Fatal("explicit Everyone fallback must retain saved preference") }
}

func TestRealtimeAdmissionAndSlowReaderBounds(t *testing.T) {
	m := memoryFixture(); now := rtNow()
	var first rt.Connection; var firstParticipant *liveParticipant
	for n:=1; n<=200; n++ {
		connection,p := attachFixture(t,m,n,now)
		if n==1 { first,firstParticipant=connection,p }
		p.auth.Profile.Gender=identity.GenderMale; p.auth.Preferences.Gender=rt.PreferFemale; p.auth.Entitlement=rt.Entitlement{Premium:true,Version:1,ExpiresAt:now.Add(time.Hour)}
		if n<=100 { doCommand(t,m,connection,p,"queue.join",fmt.Sprintf("join_%d",n),now) }
		if n==101 { if err:=m.command(connection.Ref,cmdFixture(connection.Ref,"queue.join","overqueue",p,m),now); !errors.Is(err,rt.ErrCapacity) { t.Fatal("101st waiting entry admitted") } }
	}
	if result:=m.attach(rt.AttachRequest{Auth:accountAuth(201,now)},"overflow_secret",now); !errors.Is(result.err,rt.ErrCapacity) { t.Fatal("201st participant admitted") }
	for n:=0; n<rt.OutboundCapacity+1; n++ { m.emit(firstParticipant,"test.event",rt.StatusPayload{},"") }
	select { case <-first.Closed: default: t.Fatal("slow writer was not closed") }
	if len(m.waiting)!=99 || m.connected()!=199 { t.Fatal("slow writer retained waiting ownership") }
}

func TestRealtimeProfileSnapshotAndAuthorizationFence(t *testing.T) {
	m:=memoryFixture(); now:=rtNow(); a,pa:=attachFixture(t,m,1,now); b,pb:=attachFixture(t,m,2,now)
	doCommand(t,m,a,pa,"queue.join","a_join",now); doCommand(t,m,b,pb,"queue.join","b_join",now)
	old:=m.state(pb).Interaction.Peer
	profile:=pa.auth.Profile; profile.Version++; profile.Gender=identity.GenderFemale
	result:=m.apply(realtimeRequest{op:opProfile,account:identity.Account{ID:pa.auth.IdentityID,Generation:1,Status:"active",Profile:profile}},now)
	if result.err!=nil || pa.auth.Profile.Gender!=identity.GenderFemale || m.state(pb).Interaction.Peer!=old { t.Fatal("profile change rewrote active peer snapshot") }
	stale:=accountAuth(3,now)
	if result:=m.attach(rt.AttachRequest{Auth:stale},"stale_auth_secret",now); !errors.Is(result.err,rt.ErrUnavailable) { t.Fatal("pre-change authorization fence published after mutation") }
	stale.Fence=m.fence
	if result:=m.attach(rt.AttachRequest{Auth:stale},"fresh_auth_secret",now); result.err!=nil { t.Fatal("fresh authorization was rejected") }
}

func TestRealtimeConcurrentJoinAndRevocationFence(t *testing.T) {
	c,clock:=startGuestOwner(t); ctx:=context.Background()
	connections:=make([]rt.Connection,40)
	for i:=range connections { auth:=accountAuth(i+1,clock.Now()); fence,err:=c.AuthFence(ctx); if err!=nil { t.Fatal(err) }; auth.Fence=fence; connections[i],err=c.Attach(ctx,rt.AttachRequest{Auth:auth}); if err!=nil { t.Fatal(err) } }
	var wg sync.WaitGroup
	for i,connection:=range connections { wg.Add(1); go func(i int, connection rt.Connection) { defer wg.Done(); command:=rt.ClientEnvelope{V:1,ID:fmt.Sprintf("join_%d",i),Type:"queue.join",Generation:connection.Ref.Generation,Payload:json.RawMessage(`{}`)}; if err:=c.Command(ctx,connection.Ref,command); err!=nil { t.Errorf("join: %v",err) } }(i,connection) }
	wg.Wait(); snapshot,err:=c.Snapshot(ctx)
	if err!=nil || snapshot.Connected!=40 || snapshot.Interactions!=20 || snapshot.Waiting!=0 { t.Fatal("concurrent joins violated single ownership") }
	fence,err:=c.AuthFence(ctx); if err!=nil { t.Fatal(err) }
	auth:=accountAuth(100,clock.Now()); auth.Fence=fence
	if err:=c.InvalidateAccount(ctx,auth.IdentityID,clock.Now()); err!=nil { t.Fatal(err) }
	if _,err:=c.Attach(ctx,rt.AttachRequest{Auth:auth}); !errors.Is(err,rt.ErrUnavailable) { t.Fatal("external auth result revived revoked identity") }
}

func TestRealtimeNoResurrectionOnSessionChangeAndOutage(t *testing.T) {
	m:=memoryFixture(); now:=rtNow(); a,pa:=attachFixture(t,m,1,now); b,pb:=attachFixture(t,m,2,now)
	doCommand(t,m,a,pa,"queue.join","a_join",now); doCommand(t,m,b,pb,"queue.join","b_join",now)
	m.apply(realtimeRequest{op:opOutage,outage:true},now)
	if err:=m.command(a.Ref,cmdFixture(a.Ref,"match.next","during_outage",pa,m),now); !errors.Is(err,rt.ErrUnavailable) { t.Fatal("new matching continued through failed safety authority") }
	m.maintain(now.Add(5*time.Second))
	if len(m.participants)!=0 || len(m.interactions)!=0 { t.Fatal("outage did not stop established state after bounded grace") }
}

func TestRealtimeIdleReattachCannotReuseOldConnectionGeneration(t *testing.T) {
	m:=memoryFixture(); now:=rtNow(); old,p:=attachFixture(t,m,1,now)
	m.disconnect(p,now,"network")
	current,p:=attachFixture(t,m,1,now)
	if current.Ref.Handle!=old.Ref.Handle || current.Ref.Generation<=old.Ref.Generation { t.Fatal("stable slot reused an old connection reference") }
	m.apply(realtimeRequest{op:opDetach,ref:old.Ref},now)
	if m.byConnection(current.Ref)!=p { t.Fatal("delayed old detach removed successor") }
	if err:=m.command(old.Ref,cmdFixture(old.Ref,"queue.join","old_join",p,m),now); !errors.Is(err,rt.ErrStaleGeneration) { t.Fatal("delayed old command controlled successor") }
}

func TestRealtimeEveryoneContinuesWhenSoftPremiumExpires(t *testing.T) {
	m:=memoryFixture(); now:=rtNow(); a,p:=attachFixture(t,m,1,now)
	p.auth.Entitlement=rt.Entitlement{Premium:true,Version:1,ExpiresAt:now.Add(time.Second)}
	p.auth.Preferences.Professional.NoPreference=false
	p.auth.Preferences.Professional.Topics=rt.CategoryPreference{Choices:[]string{"work_culture"}}
	doCommand(t,m,a,p,"queue.join","search",now)
	m.maintain(now.Add(time.Second))
	if p.state!=rt.Waiting || !p.expiryNotified || p.auth.Preferences.Professional.NoPreference { t.Fatal("Everyone search must continue with saved soft preferences inactive") }
	_,professional:=rt.RelevanceBonuses(m.entry(p,now.Add(time.Second)),m.entry(p,now.Add(time.Second)),now.Add(time.Second))
	if professional!=0 { t.Fatal("expired professional ranking remained active") }
}

func TestRealtimeGuestHandoffPreservesOnlyStillLiveEpoch(t *testing.T) {
	for _,peerLeaves:=range []bool{false,true} {
		t.Run(fmt.Sprint(peerLeaves),func(t *testing.T){
			m:=memoryFixture(); now:=rtNow(); guest:=guestFixture(1,now)
			if result:=m.guests.apply(guestRequest{op:guestCreate,guest:guest},now);result.err!=nil{t.Fatal(result.err)}
			auth:=accountAuth(1,now);auth.Kind=identity.KindGuest;auth.SessionID=guest.ID
			result:=m.attach(rt.AttachRequest{Auth:auth},"guest_resume_secret_32_bytes_long",now);if result.err!=nil{t.Fatal(result.err)}
			a:=result.connection;pa:=m.byConnection(a.Ref);b,pb:=attachFixture(t,m,2,now)
			doCommand(t,m,a,pa,"queue.join","guest_join",now);doCommand(t,m,b,pb,"queue.join","peer_join",now)
			view:=m.state(pa)
			lease:=m.guests.apply(guestRequest{op:guestPrepare,verifier:guest.Verifier,generation:guest.Generation,reservationID:"handoff_12345678"},now)
			if lease.err!=nil{t.Fatal(lease.err)}
			if peerLeaves{doCommand(t,m,b,pb,"match.end","peer_left",now)}
			binding:=bindingFor(guest)
			req:=guestRequest{op:guestCommit,reservation:lease.reservation,commit:binding}
			committed:=m.guests.apply(req,now);m.identityChange(req,committed,now);m.maintain(now)
			if !committed.committed || pa.slot.id!=guest.ID{t.Fatal("handoff did not rebind stable slot")}
			fresh:=accountAuth(3,now);fresh.IdentityID=binding.AccountID;fresh.SessionID=binding.SessionID;fresh.Fence=m.fence
			if peerLeaves{
				if len(m.interactions)!=0{t.Fatal("handoff resurrected departed peer")}
				result=m.attach(rt.AttachRequest{Auth:fresh},"new_account_secret",now)
				if result.err!=nil||m.byConnection(result.connection.Ref).state!=rt.Idle{t.Fatal("completed registration did not continue idle")}
			}else{
				resume:=rt.Resume{Token:view.ResumeToken,ServerInstance:view.ServerInstance,Generation:view.Generation,InteractionID:view.Interaction.ID,Epoch:view.Interaction.Epoch}
				result=m.attach(rt.AttachRequest{Auth:fresh,Resume:&resume},"new_account_secret",now)
				if result.err!=nil||pa.interactionID!=pb.interactionID||pa.interactionID!=view.Interaction.ID{t.Fatal("valid account cookie and original resume token lost live match")}
			}
		})
	}
}

func TestRealtimeFailClosedLatchCannotBeClearedByHealthProbe(t *testing.T) {
	c,clock:=startGuestOwner(t);ctx:=context.Background()
	auth:=accountAuth(1,clock.Now());fence,err:=c.AuthFence(ctx);if err!=nil{t.Fatal(err)};auth.Fence=fence
	connection,err:=c.Attach(ctx,rt.AttachRequest{Auth:auth});if err!=nil{t.Fatal(err)}
	c.FailClosed()
	if err:=c.HealthOutage(ctx,false);!errors.Is(err,rt.ErrUnavailable){t.Fatal("healthy probe cleared lost-invalidation barrier")}
	if err:=c.Ready(ctx);err==nil{t.Fatal("lost-invalidation process remained ready")}
	select{case <-connection.Closed:default:t.Fatal("latched owner retained live socket")}
	auth.Fence,err=c.AuthFence(ctx);if err!=nil{t.Fatal(err)}
	if _,err:=c.Attach(ctx,rt.AttachRequest{Auth:auth});!errors.Is(err,rt.ErrUnavailable){t.Fatal("latched owner admitted a new socket")}
}

func TestRealtimeHalfOpenTransportResumeRotatesProofWithoutEndingMatch(t *testing.T) {
	m:=memoryFixture();now:=rtNow();a,pa:=attachFixture(t,m,1,now);b,pb:=attachFixture(t,m,2,now)
	doCommand(t,m,a,pa,"queue.join","a_join",now);doCommand(t,m,b,pb,"queue.join","b_join",now)
	view:=m.state(pa)
	resume:=rt.Resume{Token:view.ResumeToken,ServerInstance:view.ServerInstance,Generation:view.Generation,InteractionID:view.Interaction.ID,Epoch:view.Interaction.Epoch}
	oldNext:=cmdFixture(a.Ref,"match.next","old_next",pa,m)
	auth:=accountAuth(1,now);auth.Fence=m.fence
	result:=m.attach(rt.AttachRequest{Auth:auth,Resume:&resume},"new_rotating_resume_proof",now)
	if result.err!=nil||pa.interactionID!=pb.interactionID||pa.interactionID!=view.Interaction.ID{t.Fatal("half-open transport prevented valid same-browser resume")}
	select{case <-a.Closed:default:t.Fatal("half-open old transport remained attached")}
	if err:=m.command(a.Ref,oldNext,now);!errors.Is(err,rt.ErrStaleGeneration){t.Fatal("old transport ended preserved match")}
	m.apply(realtimeRequest{op:opDetach,ref:a.Ref},now)
	if m.byConnection(result.connection.Ref)!=pa||pa.interactionID==""{t.Fatal("old detach removed resumed ownership")}
	if replay:=m.attach(rt.AttachRequest{Auth:auth,Resume:&resume},"replay_proof",now);!errors.Is(replay.err,rt.ErrTakeoverRequired){t.Fatal("consumed resume proof replayed")}
}

func TestRealtimeExplicitTakeoverOfDisconnectedMatchRebindsOwnedSlot(t *testing.T) {
	m:=memoryFixture();now:=rtNow();a,pa:=attachFixture(t,m,1,now);b,pb:=attachFixture(t,m,2,now)
	doCommand(t,m,a,pa,"queue.join","a_join",now);doCommand(t,m,b,pb,"queue.join","b_join",now)
	m.disconnect(pa,now,"network")
	auth:=accountAuth(1,now);auth.Fence=m.fence;auth.SessionID="new_session_for_takeover"
	result:=m.attach(rt.AttachRequest{Auth:auth,Takeover:true},"new_browser_resume_secret",now)
	if result.err!=nil||m.byConnection(result.connection.Ref)!=pa||pa.state!=rt.Idle||pb.state!=rt.Idle||len(m.interactions)!=0||m.connected()!=2{t.Fatal("explicit takeover lost disconnected slot ownership")}
	doCommand(t,m,result.connection,pa,"queue.join","takeover_search",now)
}
