package coordinator

import (
	"crypto/sha256"
	"time"

	rt "notitle/internal/realtime"
)

// Message content is confined to the current interaction and independently
// expiring user-initiated report drafts. A receipt contains no message body.
type chatRecord struct {
	sequence uint64
	clientSendID string
	sender string
	text string
	sentAt time.Time
	delivered bool
}
type chatReceipt struct {
	sequence uint64
	digest [32]byte
	delivered bool
}

func chatKey(slot, sendID string) [32]byte { return sha256.Sum256([]byte(slot + ":" + sendID)) }

func (m *liveMemory) sendChat(p *liveParticipant, command rt.ClientEnvelope, now time.Time) error {
	payload, err := rt.DecodeChatSend(command)
	if err != nil { return err }
	interaction := m.interactions[p.interactionID]
	peer := m.peer(p)
	if interaction == nil { return rt.ErrStaleEpoch }
	if !p.auth.TextEnabled || peer == nil || !peer.auth.TextEnabled { return rt.ErrUnavailable }
	if peer == nil || peer.connection == nil || p.connection == nil || !now.Before(peer.auth.ValidUntil) { return rt.ErrUnavailable }
	if m.blocked(p, peer) { return rt.ErrBlocked }
	key := chatKey(p.slot.id, payload.ClientSendID)
	digest := sha256.Sum256([]byte(payload.Text))
	if receipt, ok := interaction.sendIDs[key]; ok {
		if receipt.digest != digest { return rt.ErrProtocol }
		status := "accepted"; if receipt.delivered { status = "delivered" }
		m.emit(p, "chat.ack", rt.ChatAck{ClientSendID: payload.ClientSendID, ServerSequence: receipt.sequence, Status: status}, command.ID)
		return nil
	}
	// Never forget an accepted send ID during its epoch and then deliver a retry
	// as a new message. A full finite receipt ledger rejects further new sends.
	if len(interaction.sendIDs) >= rt.MaxSendDedupe { return rt.ErrCapacity }
	if p.textRefill.IsZero() { p.textTokens = rt.TextBurst; p.textRefill = now }
	elapsed := now.Sub(p.textRefill).Seconds()
	if elapsed > 0 { p.textTokens += elapsed * rt.TextPerSecond; if p.textTokens > rt.TextBurst { p.textTokens = rt.TextBurst }; p.textRefill = now }
	if p.textTokens < 1 { return rt.ErrRateLimited }
	p.textTokens--
	interaction.textSequence++
	message := chatRecord{sequence: interaction.textSequence, clientSendID: payload.ClientSendID, sender: p.slot.id, text: payload.Text, sentAt: now}
	if interaction.sendIDs == nil { interaction.sendIDs = make(map[[32]byte]chatReceipt) }
	interaction.sendIDs[key] = chatReceipt{sequence: message.sequence, digest: digest}
	interaction.messages = append(interaction.messages, message)
	interaction.messageBytes += len(message.text)
	for len(interaction.messages) > rt.MaxMessages || interaction.messageBytes > rt.MaxMessageBufferBytes {
		interaction.messageBytes -= len(interaction.messages[0].text)
		interaction.messages[0] = chatRecord{}
		interaction.messages = interaction.messages[1:]
	}
	m.emit(peer, "chat.message", chatProjection(message, peer.slot.id), "")
	m.emit(p, "chat.message", chatProjection(message, p.slot.id), command.ID)
	m.emit(p, "chat.ack", rt.ChatAck{ClientSendID: payload.ClientSendID, ServerSequence: message.sequence, Status: "accepted"}, command.ID)
	return nil
}

func (m *liveMemory) deliveryAck(p *liveParticipant, command rt.ClientEnvelope, now time.Time) error {
	payload, err := rt.DecodeChatDeliveryAck(command)
	if err != nil { return err }
	interaction := m.interactions[p.interactionID]
	if interaction == nil { return rt.ErrStaleEpoch }
	peer := m.peer(p)
	if !p.auth.TextEnabled || peer == nil || !peer.auth.TextEnabled || peer.connection == nil || !now.Before(peer.auth.ValidUntil) { return rt.ErrUnavailable }
	if m.blocked(p, peer) { return rt.ErrBlocked }
	for index := range interaction.messages {
		message := &interaction.messages[index]
		if message.sequence != payload.ServerSequence { continue }
		if message.sender == p.slot.id { return rt.ErrProtocol }
		if message.delivered { return nil }
		message.delivered = true
		key := chatKey(message.sender, message.clientSendID)
		receipt := interaction.sendIDs[key]; receipt.delivered = true; interaction.sendIDs[key] = receipt
		if sender := m.participants[message.sender]; sender != nil { m.emit(sender, "chat.ack", rt.ChatAck{ClientSendID: message.clientSendID, ServerSequence: message.sequence, Status: "delivered"}, "") }
		return nil
	}
	// An evicted message cannot be proven rendered from this bounded buffer.
	// Do not turn a forged/late sequence into a delivery claim.
	return rt.ErrUnavailable
}

func chatProjection(message chatRecord, viewer string) rt.ChatMessage {
	sender := "peer"; if message.sender == viewer { sender = "self" }
	return rt.ChatMessage{ServerSequence: message.sequence, ClientSendID: message.clientSendID, Sender: sender, Text: message.text, SentAt: message.sentAt, Delivered: message.delivered}
}
func (m *liveMemory) chatMessages(p *liveParticipant, interaction *liveInteraction) []rt.ChatMessage {
	messages := make([]rt.ChatMessage, 0, len(interaction.messages))
	for _, message := range interaction.messages { messages = append(messages, chatProjection(message, p.slot.id)) }
	return messages
}

func (m *liveMemory) replayChat(p *liveParticipant) {
	interaction := m.interactions[p.interactionID]
	if interaction == nil { return }
	for _, message := range interaction.messages { projection := chatProjection(message, p.slot.id); projection.Replay = true; m.emit(p, "chat.message", projection, "") }
}

func (m *liveMemory) purgeInteractionEvents(interaction *liveInteraction) {
    for _, slot := range []string{interaction.a, interaction.b} {
        p := m.participants[slot]; if p == nil || p.connection == nil { continue }
        queue := p.connection.events; kept := make([]rt.ServerEvent, 0, rt.OutboundCapacity)
        for { select { case event := <-queue:
            if event.InteractionID != interaction.id || event.Epoch != interaction.epoch || (event.Type != "chat.message" && event.Type != "chat.ack") { kept = append(kept, event) }
        default: goto drained } }
        drained:
        for _, event := range kept { queue <- event }
    }
}
