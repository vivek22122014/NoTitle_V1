package coordinator

import (
 "testing"
 "time"
 rt "notitle/internal/realtime"
)
func TestPrivateMetricsSuppressSmallPreferenceCohorts(t *testing.T){m:=&liveMemory{};m.metrics.ProfessionalMatches=19;m.metrics.ProfessionalOverlap=18;m.metrics.ProfessionalWaitHistogram[0]=38;m.metrics.StrictWaitHistogram[1]=19;v:=m.aggregateMetrics();if v.ProfessionalMatches!=0||v.ProfessionalOverlap!=0||v.ProfessionalWaitHistogram[0]!=0||v.StrictWaitHistogram[1]!=0{t.Fatal("small cohort exposed")};if m.metrics.ProfessionalMatches!=19{t.Fatal("publication mutated owner")};m.metrics.ProfessionalMatches=20;v=m.aggregateMetrics();if v.ProfessionalMatches!=20{t.Fatal("coarse cohort missing")}}
func TestMatchWaitAndProcessingTimeAreSeparate(t *testing.T){now:=time.Unix(1800000000,0);a:=rt.QueueEntry{QueuedAt:now.Add(-20*time.Second)};b:=rt.QueueEntry{QueuedAt:now.Add(-time.Second)};m:=&liveMemory{};m.observeMatch(a,b,rt.PairHistory{},now,50*time.Microsecond);if m.metrics.Matches!=1||m.metrics.WaitHistogram[6]!=1||m.metrics.WaitHistogram[2]!=1||m.metrics.CompatibleSearchHistogram[0]!=1{t.Fatal("user wait confused with processing latency")}}
