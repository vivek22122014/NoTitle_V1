package coordinator

import (
 "context"
 "encoding/json"
 "sort"
 "time"

 at "notitle/internal/audiotypes"
 ft "notitle/internal/friendtypes"
 "notitle/internal/identity"
 rt "notitle/internal/realtime"
 st "notitle/internal/safetytypes"
)

type friendOperation uint8
const (
 friendList friendOperation = iota
 friendRemove
 friendClaim
 friendFinish
 friendCompensate
 friendReject
)
type friendRequest struct { ctx context.Context; op friendOperation; guard ft.Guard; snapshot ft.Snapshot; relation *ft.Relation; ref string; limit int; persisted bool; reply chan friendResult }
type friendResult struct { views []ft.View; mutation ft.Mutation; mutations []ft.Mutation; published bool; err error }
type friendLink struct {
 mutation ft.Mutation
 aSlot,bSlot string
 aName,bName string
 durable bool
 removed bool
 revisionsCaptured bool
 aNeedsRevision,bNeedsRevision bool
 lease ft.Mutation
 compensating bool
 removalLease ft.Mutation
 removalCommitted bool
 aPresence,bPresence string
 audioCooldownUntil time.Time
}
type connectionRequest struct { ref,interactionID,a,b string; aConsent,bConsent time.Time; declined bool; withdrawn bool }
type friendInvitation struct { ref,friendRef,from,to,kind string; expiresAt time.Time }
type friendMemory struct { links map[string]*friendLink; pairs map[string]string; indexes map[string]map[string]struct{}; requests map[string]*connectionRequest; invitations map[string]*friendInvitation; lookup bool; slots map[string]*participantSlot; participants map[string]*liveParticipant }
func newFriendMemory() *friendMemory { return &friendMemory{links:map[string]*friendLink{},pairs:map[string]string{},indexes:map[string]map[string]struct{}{},requests:map[string]*connectionRequest{},invitations:map[string]*friendInvitation{}} }
var _ ft.Owner = (*Coordinator)(nil)
func (c *Coordinator) friendCommand(ctx context.Context, req friendRequest) (friendResult,error) {
 if err:=ctx.Err(); err!=nil { return friendResult{},err }; if !c.running.Load() { return friendResult{},ErrNotRunning }
 req.ctx=ctx; req.reply=make(chan friendResult,1); req.snapshot.Relations=append([]ft.Relation(nil),req.snapshot.Relations...); if req.relation!=nil { copy:=*req.relation; req.relation=&copy }
 req.guard.Principal.Guest=cloneGuest(req.guard.Principal.Guest); req.guard.Principal.AccountSession.Account.Profile=cloneProfile(req.guard.Principal.AccountSession.Account.Profile)
 select { case <-ctx.Done():return friendResult{},ctx.Err();case <-c.done:return friendResult{},ErrNotRunning;case c.friendRequests<-req:default:return friendResult{},ErrOverloaded }
 select { case <-ctx.Done():return friendResult{},ctx.Err();case <-c.done:return friendResult{},ErrNotRunning;case result:=<-req.reply:return result,result.err }
}
func (c *Coordinator) applyFriend(guests *guestMemory,m *liveMemory,req friendRequest) { if err:=req.ctx.Err();err!=nil {req.reply<-friendResult{err:err};return};now:=c.clock.Now();guests.expire(now);m.now=now;if c.failClosed.Load(){m.latchClosed(now)};m.maintainFriends(now);req.reply<-m.applyFriend(req,now);m.maintain(now) }
func (c *Coordinator) ListFriends(ctx context.Context,guard ft.Guard,snapshot ft.Snapshot)([]ft.View,error){r,e:=c.friendCommand(ctx,friendRequest{op:friendList,guard:guard,snapshot:snapshot});return r.views,e}
func (c *Coordinator) PrepareFriendRemove(ctx context.Context,guard ft.Guard,ref string,relation *ft.Relation)(ft.Mutation,error){r,e:=c.friendCommand(ctx,friendRequest{op:friendRemove,guard:guard,ref:ref,relation:relation});return r.mutation,e}
func (c *Coordinator) ClaimFriendMutations(ctx context.Context,limit int)([]ft.Mutation,error){r,e:=c.friendCommand(ctx,friendRequest{op:friendClaim,limit:limit});return r.mutations,e}
func (c *Coordinator) FinishFriendMutation(ctx context.Context,leaseID string,persisted bool)(bool,error){r,e:=c.friendCommand(ctx,friendRequest{op:friendFinish,ref:leaseID,persisted:persisted});return r.published,e}
func (c *Coordinator) FinishFriendCompensation(ctx context.Context,leaseID string,persisted bool)error{_,e:=c.friendCommand(ctx,friendRequest{op:friendCompensate,ref:leaseID,persisted:persisted});return e}
func (c *Coordinator) RejectFriendMutation(ctx context.Context,leaseID string)error{_,e:=c.friendCommand(ctx,friendRequest{op:friendReject,ref:leaseID});return e}
func friendSubject(slot *participantSlot) ft.Subject {s:=slotSubject(slot);return ft.Subject{Kind:s.Kind,ID:s.ID,Generation:s.Generation}}
func friendKey(s ft.Subject)string{return subjectKey(s.Kind,s.ID)}
func sameFriend(a,b ft.Subject)bool{return a.Kind==b.Kind&&a.ID==b.ID}
func friendPair(a,b ft.Subject)string{return pairKey(friendKey(a),friendKey(b))}
func (m *liveMemory) friendParticipant(subject ft.Subject)*liveParticipant{if m.friends.lookup{return m.friends.participants[friendKey(subject)]};for _,p:=range m.participants{if p.auth.Kind==subject.Kind&&p.auth.IdentityID==subject.ID{return p}};return nil}
func (m *liveMemory) friendSlot(subject ft.Subject)*participantSlot{if m.friends.lookup{return m.friends.slots[friendKey(subject)]};for _,slot:=range m.guests.slots{if sameFriend(friendSubject(slot),subject){return slot}};return nil}
func (m *liveMemory) friendGuard(guard ft.Guard,now time.Time)(ft.Subject,*participantSlot,error){s,slot,e:=m.safetyPrincipal(st.Guard{Principal:guard.Principal,Fence:guard.Fence},now,false);if e!=nil{return ft.Subject{},nil,ft.ErrUnavailable};return ft.Subject{Kind:s.Kind,ID:s.ID,Generation:s.Generation},slot,nil}
func (m *liveMemory) friendBlocked(a,b ft.Subject)bool {
 if m.subjectRestricted(a.Kind,a.ID)||m.subjectRestricted(b.Kind,b.ID){return true}
 if _,ok:=m.safety.edges[friendKey(a)][friendKey(b)];ok{return true}
 pa,pb:=m.friendParticipant(a),m.friendParticipant(b)
 if pa!=nil {if pa.auth.Restricted||len(pa.slot.carry.restrictions)>0{return true};for _,id:=range pa.auth.BlockedIdentities{if id==b.ID{return true}}}
 if pb!=nil {if pb.auth.Restricted||len(pb.slot.carry.restrictions)>0{return true};for _,id:=range pb.auth.BlockedIdentities{if id==a.ID{return true}}}
 return false
}
func (m *liveMemory) indexFriend(link *friendLink){a,b:=link.mutation.A,link.mutation.B;m.friends.pairs[friendPair(a,b)]=link.mutation.Ref;for _,s:=range []ft.Subject{a,b}{key:=friendKey(s);if m.friends.indexes[key]==nil{m.friends.indexes[key]=map[string]struct{}{}};m.friends.indexes[key][link.mutation.Ref]=struct{}{}};m.bindFriendSlots(link)}
func (m *liveMemory) bindFriendSlots(link *friendLink){a,b:=m.friendSlot(link.mutation.A),m.friendSlot(link.mutation.B);if a!=nil{link.aSlot=a.id;link.aName=a.profile.DisplayName};if b!=nil{link.bSlot=b.id;link.bName=b.profile.DisplayName};if !link.removed&&a!=nil&&b!=nil{if a.carry.acceptedLinks==nil{a.carry.acceptedLinks=map[string]string{}};if b.carry.acceptedLinks==nil{b.carry.acceptedLinks=map[string]string{}};a.carry.acceptedLinks[b.id]=link.mutation.Ref;b.carry.acceptedLinks[a.id]=link.mutation.Ref}}
func (m *liveMemory) forgetFriend(link *friendLink){delete(m.friends.links,link.mutation.Ref);delete(m.friends.pairs,friendPair(link.mutation.A,link.mutation.B));for _,s:=range []ft.Subject{link.mutation.A,link.mutation.B}{key:=friendKey(s);delete(m.friends.indexes[key],link.mutation.Ref);if len(m.friends.indexes[key])==0{delete(m.friends.indexes,key)}};if a:=m.guests.slots[link.aSlot];a!=nil{delete(a.carry.acceptedLinks,link.bSlot)};if b:=m.guests.slots[link.bSlot];b!=nil{delete(b.carry.acceptedLinks,link.aSlot)}}
func (m *liveMemory) friendPresence(s ft.Subject,now time.Time)string{p:=m.friendParticipant(s);if p==nil||p.connection==nil||p.handoff||!p.auth.FriendsEnabled||!now.Before(p.auth.ValidUntil)||p.auth.Restricted||m.subjectRestricted(s.Kind,s.ID){return "offline"};if p.state!=rt.Idle{return "busy"};return "online"}
func (m *liveMemory) friendView(link *friendLink,subject ft.Subject,now time.Time)ft.View{peer,name:=link.mutation.B,link.bName;if sameFriend(subject,link.mutation.B){peer,name=link.mutation.A,link.aName};return ft.View{Ref:link.mutation.Ref,DisplayName:name,CreatedAt:link.mutation.CreatedAt,Durable:link.durable,Pending:!link.durable&&link.mutation.A.Kind==identity.KindAccount&&link.mutation.B.Kind==identity.KindAccount,Presence:ft.Presence(m.friendVisiblePresence(subject,peer,now))}}
func (m *liveMemory) emitFriend(link *friendLink,typ string,now time.Time){for _,s:=range []ft.Subject{link.mutation.A,link.mutation.B}{if p:=m.friendParticipant(s);p!=nil{scoped:=false;if peer:=m.peer(p);peer!=nil{scoped=friendPair(friendSubject(p.slot),friendSubject(peer.slot))==friendPair(link.mutation.A,link.mutation.B)};m.emitEvent(p,typ,map[string]any{"friend":m.friendView(link,s,now)},"",scoped)}}}
func (m *liveMemory) emitFriendRemoved(link *friendLink,typ string){for _,s:=range []ft.Subject{link.mutation.A,link.mutation.B}{if p:=m.friendParticipant(s);p!=nil{m.emit(p,typ,map[string]string{"friend_ref":link.mutation.Ref},"")}}}
func (m *liveMemory) applyFriend(req friendRequest,now time.Time)friendResult{
 switch req.op{case friendClaim:return friendResult{mutations:m.claimFriends(req.limit,now)};case friendFinish:return m.finishFriend(req.ref,req.persisted,now);case friendCompensate:return m.compensateFriend(req.ref,req.persisted,now);case friendReject:for _,link:=range m.friends.links{if link.lease.LeaseID==req.ref{wasRemoved:=link.removed;m.removeFriend(link,now,"friend.removed");link.lease=ft.Mutation{};link.mutation.LeaseID="";if !wasRemoved||link.removalCommitted{m.forgetFriend(link)};m.fence++;return friendResult{}}};return friendResult{err:ft.ErrUnavailable}}
 if m.stopped(now)||m.outage{return friendResult{err:ft.ErrUnavailable}}
 subject,_,err:=m.friendGuard(req.guard,now);if err!=nil{return friendResult{err:err}}
 switch req.op{
 case friendList:
  if err:=m.hydrateFriendRelations(subject,req.snapshot.Relations,now);err!=nil{return friendResult{err:err}}
  views:=make([]ft.View,0);for ref:=range m.friends.indexes[friendKey(subject)]{link:=m.friends.links[ref];if link!=nil&&!link.removed&&!m.friendHardBlocked(link.mutation.A,link.mutation.B){views=append(views,m.friendView(link,subject,now))}};sort.Slice(views,func(i,j int)bool{if views[i].CreatedAt.Equal(views[j].CreatedAt){return views[i].Ref<views[j].Ref};return views[i].CreatedAt.Before(views[j].CreatedAt)});return friendResult{views:views}
 case friendRemove:
  link:=m.friends.links[req.ref]
  if link==nil&&req.relation!=nil {if req.relation.Ref!=req.ref||!sameFriend(req.relation.Self,subject){return friendResult{err:ft.ErrUnavailable}};if err:=m.hydrateOneFriend(*req.relation,now);err!=nil{return friendResult{err:err}};link=m.friends.links[req.ref]}
  if link==nil||(!sameFriend(link.mutation.A,subject)&&!sameFriend(link.mutation.B,subject)){return friendResult{err:ft.ErrNotFound}}
  m.removeFriend(link,now,"friend.removed")
  if link.mutation.A.Kind!=identity.KindAccount||link.mutation.B.Kind!=identity.KindAccount{mutation:=link.mutation;mutation.Remove=true;m.forgetFriend(link);return friendResult{mutation:mutation}}
  if link.removalLease.LeaseID!=""{return friendResult{err:ft.ErrBusy}}
  if link.removalCommitted{return friendResult{mutation:ft.Mutation{Ref:link.mutation.Ref,A:link.mutation.A,B:link.mutation.B,Remove:true}}}
  mutation:=link.mutation;mutation.Remove=true;mutation.LeaseID=m.opaque("friend-remove");link.removalLease=mutation;return friendResult{mutation:mutation}
 }
 return friendResult{err:ft.ErrUnavailable}
}
func (m *liveMemory) hydrateFriends(auth rt.AuthSnapshot,now time.Time)error{if !auth.FriendsEnabled{return nil};m.captureFriendRevision(ft.Subject{Kind:auth.Kind,ID:auth.IdentityID,Generation:auth.IdentityGeneration},auth.FriendRevision);return m.hydrateFriendRelations(ft.Subject{Kind:auth.Kind,ID:auth.IdentityID,Generation:auth.IdentityGeneration},auth.FriendLinks,now)}
func (m *liveMemory) hydrateFriendRelations(subject ft.Subject,relations []ft.Relation,now time.Time)error{
 if len(relations)>ft.MaxFriendsPerIdentity{return rt.ErrCapacity};present:=map[string]bool{}
 for _,r:=range relations{if !sameFriend(r.Self,subject){return rt.ErrProtocol};present[r.Ref]=true;if err:=m.hydrateOneFriend(r,now);err!=nil{return err}}
 for ref:=range m.friends.indexes[friendKey(subject)]{link:=m.friends.links[ref];if link!=nil&&link.durable&&!link.removed&&!present[ref]{m.removeFriend(link,now,"friend.removed");if link.lease.LeaseID==""{m.forgetFriend(link)}}}
 return nil
}
func (m *liveMemory) hydrateOneFriend(r ft.Relation,now time.Time)error{
 if r.Self.Kind!=identity.KindAccount||r.Peer.Kind!=identity.KindAccount||sameFriend(r.Self,r.Peer)||!validInternalID(r.Ref)||!validInternalID(r.Self.ID)||!validInternalID(r.Peer.ID){return rt.ErrProtocol}
 if ref:=m.friends.pairs[friendPair(r.Self,r.Peer)];ref!=""{link:=m.friends.links[ref];if link==nil||link.removed{return nil};if ref!=r.Ref{return nil};if sameFriend(link.mutation.A,r.Peer){link.aName=r.PeerDisplayName}else{link.bName=r.PeerDisplayName};m.bindFriendSlots(link);return nil}
 if len(m.friends.links)>=ft.MaxLocalRelationships||len(m.friends.indexes[friendKey(r.Self)])>=ft.MaxFriendsPerIdentity||len(m.friends.indexes[friendKey(r.Peer)])>=ft.MaxFriendsPerIdentity{return rt.ErrCapacity}
 link:=&friendLink{mutation:ft.Mutation{Ref:r.Ref,A:r.Self,B:r.Peer,CreatedAt:r.CreatedAt,Version:1},durable:true,bName:r.PeerDisplayName};m.friends.links[r.Ref]=link;m.indexFriend(link);if m.friendHardBlocked(r.Self,r.Peer){m.removeFriend(link,now,"friend.removed")};return nil
}

func accountFriendGuard(p *liveParticipant,now time.Time)identity.Guard{return identity.Guard{AccountID:p.auth.IdentityID,AccountGeneration:p.auth.IdentityGeneration,SessionID:p.auth.SessionID,TokenHash:p.auth.SessionVerifier,Now:now}}
func (m *liveMemory) friendCommand(p *liveParticipant,command rt.ClientEnvelope,now time.Time)error{
 if !p.auth.FriendsEnabled||p.handoff||m.outage||m.subjectRestricted(p.auth.Kind,p.auth.IdentityID)||p.auth.Restricted{return rt.ErrUnavailable}
 switch command.Type{
 case "friend.request","friend.accept","friend.decline","friend.withdraw":
  interaction:=m.interactions[p.interactionID];peer:=m.peer(p)
  if interaction==nil||peer==nil||peer.connection==nil||peer.handoff||!peer.auth.FriendsEnabled||!now.Before(peer.auth.ValidUntil)||m.blocked(p,peer){return rt.ErrUnavailable}
  sa,sb:=friendSubject(p.slot),friendSubject(peer.slot)
  if m.friends.pairs[friendPair(sa,sb)]!=""{return rt.ErrUnavailable}
  request:=m.friends.requests[interaction.id]
  if command.Type=="friend.request"{
   if request==nil{if len(m.friends.requests)>=ft.MaxPendingRequests{return rt.ErrCapacity};request=&connectionRequest{ref:m.opaque("friend-request"),interactionID:interaction.id,a:p.slot.id,b:peer.slot.id,aConsent:now};m.friends.requests[interaction.id]=request;m.emit(p,"friend.request.sent",ft.RequestView{Ref:request.ref,Direction:"outgoing"},command.ID);m.emit(peer,"friend.request.received",ft.RequestView{Ref:request.ref,Direction:"incoming"},"");return nil}
   if request.withdrawn{return rt.ErrUnavailable};if request.a==p.slot.id{return nil};if request.declined{return rt.ErrUnavailable};request.bConsent=now;return m.acceptFriendRequest(request,now)
  }
  var input rt.FriendResponse;if json.Unmarshal(command.Payload,&input)!=nil{return rt.ErrProtocol};if request==nil||request.ref!=input.RequestRef{return rt.ErrStaleEpoch}
  if command.Type=="friend.withdraw"{if request.a!=p.slot.id{return rt.ErrUnavailable};request.withdrawn=true;for _,member:=range []*liveParticipant{p,peer}{m.emit(member,"friend.request.closed",rt.FriendRequestClosed{RequestRef:request.ref},"")};return nil}
  if request.b!=p.slot.id||request.declined||request.withdrawn{return rt.ErrUnavailable}
  if command.Type=="friend.decline"{request.declined=true;m.emit(p,"friend.request.closed",rt.FriendRequestClosed{RequestRef:request.ref},command.ID);return nil}
  request.bConsent=now;return m.acceptFriendRequest(request,now)
 case "friend.invite":
  var input rt.FriendInvite;if json.Unmarshal(command.Payload,&input)!=nil{return rt.ErrProtocol};if input.Kind=="audio"&&!m.audioAvailable(p,now){return rt.ErrUnavailable}
  link:=m.friends.links[input.FriendRef];own:=friendSubject(p.slot)
  if link==nil||link.removed||(!sameFriend(own,link.mutation.A)&&!sameFriend(own,link.mutation.B))||m.friendBlocked(link.mutation.A,link.mutation.B){return rt.ErrUnavailable}
  peerSubject:=link.mutation.B;if sameFriend(own,peerSubject){peerSubject=link.mutation.A};peer:=m.friendParticipant(peerSubject)
  if !m.friendAvailable(p,now)||!m.friendAvailable(peer,now)||m.hasInvitation(p.slot.id)||m.hasInvitation(peer.slot.id){return rt.ErrUnavailable}
  if input.Kind=="audio"{if now.Before(link.audioCooldownUntil){return rt.ErrRateLimited};if !m.audioAvailable(peer,now){return rt.ErrUnavailable};if !m.audioCapacity(){return rt.ErrCapacity}}
  if len(m.friends.invitations)>=ft.MaxInvitations{return rt.ErrCapacity}
  invite:=&friendInvitation{ref:m.opaque("friend-invitation"),friendRef:link.mutation.Ref,from:p.slot.id,to:peer.slot.id,kind:input.Kind,expiresAt:now.Add(ft.InvitationTTL)};m.friends.invitations[invite.ref]=invite
  m.emit(p,"friend.invitation.sent",m.invitationView(invite,p),command.ID);m.emit(peer,"friend.invitation.incoming",m.invitationView(invite,peer),"");return nil
 case "friend.accept_invite","friend.decline_invite":
  var input rt.FriendInviteResponse;if json.Unmarshal(command.Payload,&input)!=nil{return rt.ErrProtocol};invite:=m.friends.invitations[input.InvitationRef]
  if invite==nil||invite.to!=p.slot.id||!now.Before(invite.expiresAt){return rt.ErrUnavailable}
  if command.Type=="friend.decline_invite"{if invite.kind=="audio"{if link:=m.friends.links[invite.friendRef];link!=nil{link.audioCooldownUntil=now.Add(at.DeclineCooldown)}};m.closeInvitation(invite,"ended");return nil}
  link:=m.friends.links[invite.friendRef];peer:=m.participants[invite.from]
  if link==nil||link.removed||!m.friendAvailable(p,now)||!m.friendAvailable(peer,now)||m.blocked(p,peer){m.closeInvitation(invite,"ended");return rt.ErrUnavailable}
  if _,exists:=m.history[pairKey(p.slot.id,peer.slot.id)];!exists&&len(m.history)>=10000{return rt.ErrCapacity}
  if invite.kind=="audio"{if !m.audioAvailable(p,now)||!m.audioAvailable(peer,now){m.closeInvitation(invite,"ended");return rt.ErrUnavailable};if !m.audioCapacity(){return rt.ErrCapacity}}
  m.closeInvitation(invite,"accepted");m.allocateInteraction(peer,p,link.mutation.Ref,now)
  if invite.kind=="audio"{if !m.audioAvailable(p,now)||!m.audioAvailable(peer,now){return rt.ErrUnavailable};call:=m.newCall(peer,p,now);if err:=m.acceptCall(call,now);err!=nil{m.endCall(call,now,"not_available");return err}};return nil
 }
 return rt.ErrProtocol
}
func (m *liveMemory) acceptFriendRequest(request *connectionRequest,now time.Time)error{
 a,b:=m.participants[request.a],m.participants[request.b]
 if a==nil||b==nil||a.interactionID!=request.interactionID||b.interactionID!=request.interactionID||request.aConsent.IsZero()||request.bConsent.IsZero()||m.blocked(a,b){return rt.ErrUnavailable}
 sa,sb:=friendSubject(a.slot),friendSubject(b.slot);if m.friends.pairs[friendPair(sa,sb)]!=""{return rt.ErrUnavailable}
 if len(m.friends.links)>=ft.MaxLocalRelationships||len(m.friends.indexes[friendKey(sa)])>=m.friendLimit||len(m.friends.indexes[friendKey(sb)])>=m.friendLimit{return rt.ErrCapacity}
 link:=&friendLink{mutation:ft.Mutation{Ref:m.opaque("friend"),A:sa,B:sb,CreatedAt:now,Version:1,AConsentAt:request.aConsent,BConsentAt:request.bConsent},aSlot:a.slot.id,bSlot:b.slot.id,aName:a.auth.Profile.DisplayName,bName:b.auth.Profile.DisplayName}
 if sa.Kind==identity.KindAccount{if a.auth.FriendRevision<1{return rt.ErrUnavailable};link.mutation.ARevision=a.auth.FriendRevision};if sb.Kind==identity.KindAccount{if b.auth.FriendRevision<1{return rt.ErrUnavailable};link.mutation.BRevision=b.auth.FriendRevision}
 if sa.Kind==identity.KindAccount&&sb.Kind==identity.KindAccount{if a.auth.FriendRevision<1||b.auth.FriendRevision<1{return rt.ErrUnavailable};link.mutation.ARevision,link.mutation.BRevision=a.auth.FriendRevision,b.auth.FriendRevision;link.mutation.AGuard,link.mutation.BGuard=accountFriendGuard(a,now),accountFriendGuard(b,now);link.revisionsCaptured=true}
 m.friends.links[link.mutation.Ref]=link;m.indexFriend(link);delete(m.friends.requests,request.interactionID);m.emitFriend(link,"friend.created",now);return nil
}
func (m *liveMemory) friendAvailable(p *liveParticipant,now time.Time)bool{
 if p==nil||p.connection==nil||p.state!=rt.Idle||p.interactionID!=""||p.handoff||!p.auth.FriendsEnabled||!p.auth.TextEnabled||!now.Before(p.auth.ValidUntil)||p.auth.Restricted||m.subjectRestricted(p.auth.Kind,p.auth.IdentityID)||len(p.slot.carry.restrictions)>0{return false}
 if p.auth.Kind==identity.KindGuest{entry:=m.guests.byVerifier[p.auth.SessionVerifier];if entry==nil||entry.reservation!=nil{return false}}
 return true
}
func (m *liveMemory) hasInvitation(slot string)bool{for _,invite:=range m.friends.invitations{if invite.from==slot||invite.to==slot{return true}};return false}
func (m *liveMemory) invitationView(invite *friendInvitation,p *liveParticipant)ft.InvitationView{direction,peerID:="incoming",invite.from;if invite.from==p.slot.id{direction,peerID="outgoing",invite.to};name:="";if peer:=m.guests.slots[peerID];peer!=nil{name=peer.profile.DisplayName};return ft.InvitationView{Ref:invite.ref,FriendRef:invite.friendRef,Kind:invite.kind,ExpiresAt:invite.expiresAt,DisplayName:name,Direction:direction}}
func (m *liveMemory) closeInvitation(invite *friendInvitation,reason string){delete(m.friends.invitations,invite.ref);for _,id:=range []string{invite.from,invite.to}{if p:=m.participants[id];p!=nil{m.emit(p,"friend.invitation.closed",rt.FriendInvitationClosed{InvitationRef:invite.ref,Reason:reason},"")}}}
func (m *liveMemory) closeFriendRequests(interactionID string){if request:=m.friends.requests[interactionID];request!=nil{delete(m.friends.requests,interactionID);for _,id:=range []string{request.a,request.b}{if p:=m.participants[id];p!=nil{m.emit(p,"friend.request.closed",rt.FriendRequestClosed{RequestRef:request.ref},"")}}}}
func (m *liveMemory) friendState(p *liveParticipant,state *rt.StateSnapshot){state.FriendInvitations=make([]ft.InvitationView,0,1);if request:=m.friends.requests[p.interactionID];request!=nil&&!request.withdrawn{direction:="outgoing";if request.b==p.slot.id{direction="incoming"};if !(request.declined&&direction=="incoming"){state.FriendRequest=&ft.RequestView{Ref:request.ref,Direction:direction}}};for _,invite:=range m.friends.invitations{if invite.from==p.slot.id||invite.to==p.slot.id{state.FriendInvitations=append(state.FriendInvitations,m.invitationView(invite,p))}}}
// Random matching and friend invitation acceptance share this sole allocator.
// Callers establish consent/eligibility; allocation cannot interleave with any
// other command because it is performed entirely within one owner turn.
func (m *liveMemory) allocateInteraction(a,b *liveParticipant,friendRef string,now time.Time){
 m.unqueue(a);m.unqueue(b);m.epoch++;interaction:=&liveInteraction{startedAt:now,id:m.opaque("interaction"),epoch:m.epoch,a:a.slot.id,b:b.slot.id,aProfile:a.auth.Profile.PublicPeer(),bProfile:b.auth.Profile.PublicPeer(),friendRef:friendRef};m.interactions[interaction.id]=interaction
 if _,ok:=m.history[pairKey(a.slot.id,b.slot.id)];!ok{m.history[pairKey(a.slot.id,b.slot.id)]=rt.PairHistory{}}
 a.state,b.state=rt.Matched,rt.Matched;a.interactionID,b.interactionID=interaction.id,interaction.id
 for _,invite:=range m.friends.invitations{if invite.from==a.slot.id||invite.to==a.slot.id||invite.from==b.slot.id||invite.to==b.slot.id{m.closeInvitation(invite,"ended")}}
 m.emit(a,"match.found",m.state(a),"");m.emit(b,"match.found",m.state(b),"")
}
func (m *liveMemory) removeFriend(link *friendLink,now time.Time,event string){
 if link.removed{return};link.removed=true;link.mutation.Remove=true;link.mutation.Version++;m.fence++
 if a:=m.guests.slots[link.aSlot];a!=nil{delete(a.carry.acceptedLinks,link.bSlot)};if b:=m.guests.slots[link.bSlot];b!=nil{delete(b.carry.acceptedLinks,link.aSlot)}
 for _,invite:=range m.friends.invitations{if invite.friendRef==link.mutation.Ref{m.closeInvitation(invite,"ended")}}
 for _,p:=range m.participants{if interaction:=m.interactions[p.interactionID];interaction!=nil&&interaction.friendRef==link.mutation.Ref{m.endMatch(p,now,"connection_removed",false)}}
 m.emitFriendRemoved(link,event)
}
func (m *liveMemory) removeFriendPair(a,b ft.Subject,now time.Time){if ref:=m.friends.pairs[friendPair(a,b)];ref!=""{if link:=m.friends.links[ref];link!=nil{m.removeFriend(link,now,"friend.removed");if link.mutation.A.Kind!=identity.KindAccount||link.mutation.B.Kind!=identity.KindAccount{m.forgetFriend(link)}}};for id,request:=range m.friends.requests{sa,sb:=m.guests.slots[request.a],m.guests.slots[request.b];if sa!=nil&&sb!=nil&&friendPair(friendSubject(sa),friendSubject(sb))==friendPair(a,b){m.closeFriendRequests(id)}}}
func (m *liveMemory) removeSubjectFriends(subject ft.Subject,now time.Time){for ref:=range m.friends.indexes[friendKey(subject)]{link:=m.friends.links[ref];if link!=nil{m.removeFriend(link,now,"friend.removed");if link.lease.LeaseID==""&&(link.mutation.A.Kind==identity.KindGuest||link.mutation.B.Kind==identity.KindGuest){m.forgetFriend(link)}}}}
func (m *liveMemory) promoteFriendSubject(slotID string,now time.Time){slot:=m.guests.slots[slotID];if slot==nil{return};old:=ft.Subject{Kind:identity.KindGuest,ID:slotID};updated:=friendSubject(slot);refs:=make([]string,0);for ref:=range m.friends.indexes[friendKey(old)]{refs=append(refs,ref)};for _,ref:=range refs{link:=m.friends.links[ref];if link==nil{continue};m.forgetFriend(link);if sameFriend(link.mutation.A,old){link.mutation.A=updated;link.mutation.ARevision=0;link.aNeedsRevision=true;link.aName=slot.profile.DisplayName};if sameFriend(link.mutation.B,old){link.mutation.B=updated;link.mutation.BRevision=0;link.bNeedsRevision=true;link.bName=slot.profile.DisplayName};link.mutation.Version++;link.mutation.Promotion=true;link.revisionsCaptured=link.mutation.ARevision>=1&&link.mutation.BRevision>=1;m.friends.links[ref]=link;m.indexFriend(link);if m.friendHardBlocked(link.mutation.A,link.mutation.B){m.removeFriend(link,now,"friend.removed")}else{m.emitFriend(link,"friend.created",now)}}}
func (m *liveMemory) maintainFriends(now time.Time){
 m.beginFriendLookup();defer func(){m.friends.lookup=false}();changed:=map[string]*liveParticipant{}
 for _,link:=range m.friends.links{
  guestExpired:=(link.mutation.A.Kind==identity.KindGuest&&m.friendSlot(link.mutation.A)==nil)||(link.mutation.B.Kind==identity.KindGuest&&m.friendSlot(link.mutation.B)==nil)
  if guestExpired{m.removeFriend(link,now,"friend.expired");if link.lease.LeaseID==""{m.forgetFriend(link)};continue}
  if link.removed{continue};if m.friendHardBlocked(link.mutation.A,link.mutation.B){m.removeFriend(link,now,"friend.removed");continue}
  oldA,oldB:=link.aName,link.bName;m.bindFriendSlots(link)
  if oldA!=link.aName{if p:=m.friendParticipant(link.mutation.B);p!=nil{changed[p.slot.id]=p}};if oldB!=link.bName{if p:=m.friendParticipant(link.mutation.A);p!=nil{changed[p.slot.id]=p}}
  ap,bp:=m.friendPresence(link.mutation.A,now),m.friendPresence(link.mutation.B,now)
  if ap!=link.aPresence{link.aPresence=ap;if p:=m.friendParticipant(link.mutation.B);p!=nil{changed[p.slot.id]=p}}
  if bp!=link.bPresence{link.bPresence=bp;if p:=m.friendParticipant(link.mutation.A);p!=nil{changed[p.slot.id]=p}}
  if link.durable&&link.lease.LeaseID==""&&m.friendParticipant(link.mutation.A)==nil&&m.friendParticipant(link.mutation.B)==nil{m.forgetFriend(link)}
 }
 for _,p:=range changed{m.emit(p,"friends.changed",struct{}{},"")}
 for _,invite:=range m.friends.invitations{if !now.Before(invite.expiresAt){m.closeInvitation(invite,"expired");continue};from,to:=m.participants[invite.from],m.participants[invite.to];if from==nil||to==nil||from.connection==nil||to.connection==nil||from.state!=rt.Idle||to.state!=rt.Idle||m.blocked(from,to){m.closeInvitation(invite,"ended")}}
}
func (m *liveMemory) capturePromotion(link *friendLink,now time.Time)bool{
 if link.aNeedsRevision||link.bNeedsRevision||!link.revisionsCaptured||link.mutation.ARevision<1||link.mutation.BRevision<1{return false}
 if link.mutation.Promotion{return true}
 return link.mutation.AGuard.TokenHash!=(identity.Verifier{})&&link.mutation.BGuard.TokenHash!=(identity.Verifier{})
}
func (m *liveMemory) claimFriends(limit int,now time.Time)[]ft.Mutation{
 m.beginFriendLookup();defer func(){m.friends.lookup=false}()
 if limit<1||m.outage||m.stopped(now){return nil};if limit>16{limit=16};out:=make([]ft.Mutation,0,limit)
 for _,remove:=range []bool{true,false}{for _,link:=range m.friends.links{
  if len(out)==limit{return out};if link.removed!=remove||link.mutation.A.Kind!=identity.KindAccount||link.mutation.B.Kind!=identity.KindAccount{continue}
  if remove{if link.removalLease.LeaseID!=""||link.removalCommitted{continue};mutation:=link.mutation;mutation.Remove=true;mutation.LeaseID=m.opaque("friend-remove");link.removalLease=mutation;out=append(out,mutation);continue}
  if link.lease.LeaseID!=""||link.compensating||link.durable{continue}
  if m.friendHardBlocked(link.mutation.A,link.mutation.B){m.removeFriend(link,now,"friend.removed");continue}
  if m.friendBlocked(link.mutation.A,link.mutation.B)||!m.capturePromotion(link,now){continue}
  link.mutation.Remove=false;link.mutation.LeaseID=m.opaque("friend-write");link.lease=link.mutation;out=append(out,link.lease)
 }};return out
}
func (m *liveMemory) finishFriend(leaseID string,persisted bool,now time.Time)friendResult{
 if leaseID==""{return friendResult{err:ft.ErrInvalid}}
 for _,link:=range m.friends.links{
  if link.removalLease.LeaseID==leaseID{link.removalLease=ft.Mutation{};if !persisted{return friendResult{}};m.fence++;link.removalCommitted=true;if link.lease.LeaseID==""{m.forgetFriend(link)};return friendResult{published:true}}
  if link.lease.LeaseID!=leaseID{continue};lease:=link.lease
  if !persisted{link.lease=ft.Mutation{};link.mutation.LeaseID="";if link.removed&&link.removalCommitted{m.forgetFriend(link)};return friendResult{}}
  m.fence++
  if link.removed||lease.Version!=link.mutation.Version||m.friendHardBlocked(link.mutation.A,link.mutation.B){link.compensating=true;return friendResult{published:false}}
  link.durable=true;link.lease=ft.Mutation{};link.mutation.LeaseID="";m.emitFriend(link,"friend.persisted",now);return friendResult{published:true}
 };return friendResult{published:false}
}
func (m *liveMemory) compensateFriend(leaseID string,persisted bool,now time.Time)friendResult{for _,link:=range m.friends.links{if link.lease.LeaseID!=leaseID||!link.compensating{continue};if !persisted{return friendResult{}};m.fence++;link.compensating=false;link.lease=ft.Mutation{};link.mutation.LeaseID="";if link.removed&&link.removalCommitted{m.forgetFriend(link)};return friendResult{published:true}};return friendResult{err:ft.ErrUnavailable}}
func (m *liveMemory) friendHardBlocked(a,b ft.Subject)bool{
 if _,ok:=m.safety.edges[friendKey(a)][friendKey(b)];ok{return true}
 for _,pair:=range [][2]ft.Subject{{a,b},{b,a}}{if p:=m.friendParticipant(pair[0]);p!=nil{for _,id:=range p.auth.BlockedIdentities{if id==pair[1].ID{return true}}}}
 return false
}

func (m *liveMemory) beginFriendLookup(){m.friends.slots=make(map[string]*participantSlot,len(m.guests.slots));m.friends.participants=make(map[string]*liveParticipant,len(m.participants));for _,slot:=range m.guests.slots{m.friends.slots[friendKey(friendSubject(slot))]=slot};for _,p:=range m.participants{m.friends.participants[subjectKey(p.auth.Kind,p.auth.IdentityID)]=p};m.friends.lookup=true}

func (m *liveMemory) friendVisiblePresence(viewer,peer ft.Subject,now time.Time)string{if m.subjectRestricted(viewer.Kind,viewer.ID){return "offline"};if p:=m.friendParticipant(viewer);p!=nil&&(p.auth.Restricted||len(p.slot.carry.restrictions)>0){return "offline"};return m.friendPresence(peer,now)}
// Only a fenced, post-safety-handoff authorization may establish a newly
// registered endpoint revision. An existing account's accepted revision is
// frozen and must never be refreshed after a removal or block.
func (m *liveMemory) captureFriendRevision(subject ft.Subject,revision int64){if subject.Kind!=identity.KindAccount||revision<1{return};for ref:=range m.friends.indexes[friendKey(subject)]{link:=m.friends.links[ref];if link==nil||link.removed{continue};if sameFriend(link.mutation.A,subject)&&link.aNeedsRevision{link.mutation.ARevision=revision;link.aNeedsRevision=false};if sameFriend(link.mutation.B,subject)&&link.bNeedsRevision{link.mutation.BRevision=revision;link.bNeedsRevision=false};link.revisionsCaptured=!link.aNeedsRevision&&!link.bNeedsRevision&&link.mutation.ARevision>=1&&link.mutation.BRevision>=1}}
