package coordinator

import (
    "encoding/json"
    "errors"
    "testing"
    "time"

    rt "notitle/internal/realtime"
    st "notitle/internal/safetytypes"
)

// These regressions examine externally meaningful lifecycle boundaries. They
// supplement the feature owner's tests; they have not run without the Go toolchain.
func TestReviewEndingConversationPurgesQueuedText(t *testing.T) {
    now := rtNow()
    memory := memoryFixture()
    a, pa := attachFixture(t, memory, 1, now)
    b, pb := attachFixture(t, memory, 2, now)
    pa.auth.TextEnabled = true
    pb.auth.TextEnabled = true
    doCommand(t, memory, a, pa, "queue.join", "review_join_a", now)
    doCommand(t, memory, b, pb, "queue.join", "review_join_b", now)
    drain(a); drain(b)
    interaction := memory.interactions[pa.interactionID]
    payload, err := json.Marshal(rt.ChatSend{ClientSendID: "review_message_0001", Text: "Synthetic ordinary chat that must be purged"})
    if err != nil { t.Fatal(err) }
    send := rt.ClientEnvelope{V: 1, ID: "review_send_0001", Type: "chat.send", Generation: a.Ref.Generation,
        InteractionID: interaction.id, Epoch: interaction.epoch, Payload: payload}
    if err := memory.command(a.Ref, send, now); err != nil { t.Fatal(err) }
    // Neither recipient drains its messages before End is committed.
    doCommand(t, memory, a, pa, "match.end", "review_end_0001", now)
    if len(memory.interactions) != 0 || len(interaction.messages) != 0 || len(interaction.sendIDs) != 0 {
        t.Fatal("terminal turn retained ordinary conversation content or retry state")
    }
    for _, connection := range []rt.Connection{a, b} {
        ended := false
        draining := true
        for draining {
            select {
            case event := <-connection.Events:
                if event.Type == "chat.message" { t.Fatal("terminal outbox retained an ordinary chat payload") }
                if event.Type == "match.ended" { ended = true }
            default:
                draining = false
            }
        }
        if !ended { t.Fatal("terminal notification was discarded while clearing text") }
    }
}

func TestReviewTimedRestrictionExpiresAfterParticipantWasTerminated(t *testing.T) {
    now := rtNow()
    for _, explicit := range []bool{false, true} {
        memory := memoryFixture()
        _, participant := attachFixture(t, memory, 1, now)
        subject := slotSubject(participant.slot)
        result := memory.applySafety(safetyRequest{op: safetyTimedRestrict, subject: subject, until: now.Add(time.Minute)}, now)
        if result.err != nil { t.Fatal(result.err) }
        if memory.participants[participant.slot.id] != nil { t.Fatal("restriction retained live participant") }
        auth := accountAuth(1, now.Add(time.Second)); auth.Fence = memory.fence
        if attempt := memory.attach(rt.AttachRequest{Auth: auth}, "review_restricted_resume_secret", now.Add(time.Second)); !errors.Is(attempt.err, rt.ErrBlocked) {
            t.Fatal("restricted identity reconnected")
        }
        at := now.Add(time.Minute)
        if explicit {
            at = now.Add(2*time.Second)
            if err := memory.restrictSubject(st.Subject{Kind: subject.Kind, ID: subject.ID, Generation: subject.Generation}, false, at); err != nil { t.Fatal(err) }
        } else {
            memory.expireSafety(at)
        }
        auth = accountAuth(1, at); auth.Fence = memory.fence
        resultAttach := memory.attach(rt.AttachRequest{Auth: auth}, "review_post_restriction_resume_secret", at)
        if resultAttach.err != nil { t.Fatal("restriction ended but identity still cannot reconnect", resultAttach.err) }
        current := memory.byConnection(resultAttach.connection.Ref)
        if current == nil || len(current.slot.carry.restrictions) != 0 { t.Fatal("terminated participant slot kept stale restriction") }
        doCommand(t, memory, resultAttach.connection, current, "queue.join", "review_after_restriction", at)
    }
}
