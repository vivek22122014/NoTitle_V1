package coordinator

import (
	"context"
	"bytes"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"strings"
	"time"

	"notitle/internal/identity"
 "notitle/internal/performance"
	ft "notitle/internal/friendtypes"
	rt "notitle/internal/realtime"
 st "notitle/internal/safetytypes"
)

const (
	opFence uint8 = iota
	opAttach
	opCommand
	opDetach
	opRefresh
	opOutage
	opProfile
	opPreferences
	opGetGuestPreferences
	opSetGuestPreferences
	opPremiumBegin
	opPremiumFinish
	opPremiumClaim
	opPremiumUsageFinish
 opAdmission
)

type realtimeRequest struct {
	ctx context.Context
 receivedAt time.Time
	op uint8
	attach rt.AttachRequest
	ref rt.ConnectionRef
	command rt.ClientEnvelope
	auth rt.AuthSnapshot
	account identity.Account
	preferences rt.Preferences
	identityID string
	verifier identity.Verifier
	generation int64
	outage bool
 maintenance bool
 drainDeadline time.Time
	reason string
	resumeToken string
	premiumToken string
	premiumLimit int
	entitlement rt.Entitlement
	premiumUsage rt.PremiumUsageResult
	reply chan realtimeResult
}
type realtimeResult struct { connection rt.Connection; fence uint64; preferences rt.Preferences; premiumToken string; premiumJobs []rt.PremiumUsageJob; published bool; err error }
type liveConnection struct {
	ref rt.ConnectionRef
	events chan rt.ServerEvent
	closed chan struct{}
	lastSeen time.Time
	dedupe map[string][32]byte
	dedupeOrder []string
	sequence uint64
}
type liveParticipant struct {
	slot *participantSlot
	auth rt.AuthSnapshot
	state rt.ParticipantState
	connection *liveConnection
	connectionGeneration uint64
	resumeHash [32]byte
	resumeToken string
	queuedAt time.Time
 queueRequestedAt time.Time
	queueAuth rt.AuthSnapshot
	interactionID string
	graceUntil time.Time
	pauseStrict bool
	everyoneOverride bool
	handoff bool
	expiryNotified bool
	premiumJob string
	tieBreak uint64
	advisory bool
	textTokens float64
	textRefill time.Time
	endedRef string
}
type liveInteraction struct {
	id string
	epoch uint64
	a string
	b string
	aProfile identity.PublicPeer
	bProfile identity.PublicPeer
	startedAt time.Time
	textSequence uint64
	messages []chatRecord
	messageBytes int
	sendIDs map[[32]byte]chatReceipt
	friendRef string
	callRef string
	callCooldownUntil time.Time
 callMetadata *st.CallMetadata
}
type liveMemory struct {
 processing *performance.Recorder
 operationStarted time.Time
	guests *guestMemory
	participants map[string]*liveParticipant
	waiting map[string]*liveParticipant
	gender map[identity.Gender]map[string]*liveParticipant
	interactions map[string]*liveInteraction
	history map[string]rt.PairHistory
	guestPreferences map[string]rt.Preferences
	secret [32]byte
	instance string
	serial uint64
	epoch uint64
	connectionSerial uint64
	fence uint64
	outage bool
 maintenance bool
 drainDeadline time.Time
	latched bool
	outageUntil time.Time
	now time.Time
	stop func() bool
	safety *safetyMemory
	safetyEnabled bool
	friends *friendMemory
	friendLimit int
	audio *audioMemory
	premium *premiumMemory
 metrics MatchMetrics
}

var _ rt.Actor = (*Coordinator)(nil)

func newLiveMemory(secret [32]byte, guests *guestMemory) *liveMemory {
	m := &liveMemory{guests: guests, secret: secret, participants: make(map[string]*liveParticipant), waiting: make(map[string]*liveParticipant), interactions: make(map[string]*liveInteraction), history: make(map[string]rt.PairHistory), guestPreferences: make(map[string]rt.Preferences), gender: map[identity.Gender]map[string]*liveParticipant{identity.GenderMale: {}, identity.GenderFemale: {}, identity.GenderOther: {}}}
	m.instance = m.opaque("instance")
	m.safety = newSafetyMemory()
	m.friends = newFriendMemory()
	m.friendLimit = ft.MaxFriendsPerIdentity
	m.audio = newAudioMemory()
	m.premium = newPremiumMemory()
	return m
}
// IDs use a startup random key and an actor-owned monotonic counter. The loop
// never waits for an entropy source, network, database or socket writer.
func (m *liveMemory) opaque(label string) string {
	m.serial++
	mac := hmac.New(sha256.New, m.secret[:]); mac.Write([]byte(label))
	var counter [8]byte; binary.BigEndian.PutUint64(counter[:], m.serial); mac.Write(counter[:])
	return base64.RawURLEncoding.EncodeToString(mac.Sum(nil)[:18])
}
func cloneAuth(auth rt.AuthSnapshot) rt.AuthSnapshot {
	auth.Profile = cloneProfile(auth.Profile)
	auth.Preferences = rt.ClonePreferences(auth.Preferences)
	auth.BlockedIdentities = append([]string(nil), auth.BlockedIdentities...)
	auth.FriendLinks = append([]ft.Relation(nil), auth.FriendLinks...)
	return auth
}
func (c *Coordinator) realtimeCommand(ctx context.Context, req realtimeRequest) (realtimeResult, error) {
	if err := ctx.Err(); err != nil { return realtimeResult{}, err }
	if !c.running.Load() { return realtimeResult{}, ErrNotRunning }
	req.ctx = ctx; req.reply = make(chan realtimeResult, 1);req.receivedAt=time.Now()
	req.auth = cloneAuth(req.auth); req.attach.Auth = cloneAuth(req.attach.Auth)
	if req.attach.Resume != nil { resume := *req.attach.Resume; req.attach.Resume = &resume }
	req.account.Profile = cloneProfile(req.account.Profile)
	req.preferences = rt.ClonePreferences(req.preferences)
	req.command.Payload = append(json.RawMessage(nil), req.command.Payload...)
	mailbox := c.realtimeRequests
	if req.op == opAdmission || req.op == opOutage || req.op == opProfile || req.op == opPreferences || req.op == opRefresh || req.op == opSetGuestPreferences || isPremiumOperation(req.op) { mailbox = c.controlRequests }
	select { case <-ctx.Done(): return realtimeResult{}, ctx.Err(); case <-c.done: return realtimeResult{}, ErrNotRunning; case mailbox <- req: default: return realtimeResult{}, ErrOverloaded }
	if req.op == opAttach || req.op == opPremiumBegin || req.op == opPremiumFinish { select { case <-c.done: return realtimeResult{}, ErrNotRunning; case result := <-req.reply: return result, result.err } }
	select { case <-ctx.Done(): return realtimeResult{}, ctx.Err(); case <-c.done: return realtimeResult{}, ErrNotRunning; case result := <-req.reply: return result, result.err }
}
func (c *Coordinator) AuthFence(ctx context.Context) (uint64, error) { result, err := c.realtimeCommand(ctx, realtimeRequest{op: opFence}); return result.fence, err }
func (c *Coordinator) Attach(ctx context.Context, request rt.AttachRequest) (rt.Connection, error) {
	var token [32]byte
	if _, err := rand.Read(token[:]); err != nil { return rt.Connection{}, rt.ErrUnavailable }
	result, err := c.realtimeCommand(ctx, realtimeRequest{op: opAttach, attach: request, resumeToken: base64.RawURLEncoding.EncodeToString(token[:])})
	if err == nil && ctx.Err() != nil {
		cleanup, cancel := context.WithTimeout(context.WithoutCancel(ctx), 2*time.Second)
		_ = c.Detach(cleanup, result.connection.Ref, "request_canceled"); cancel()
		return rt.Connection{}, ctx.Err()
	}
	return result.connection, err
}
func (c *Coordinator) Command(ctx context.Context, ref rt.ConnectionRef, command rt.ClientEnvelope) error { _, err := c.realtimeCommand(ctx, realtimeRequest{op: opCommand, ref: ref, command: command}); return err }
func (c *Coordinator) Detach(ctx context.Context, ref rt.ConnectionRef, reason string) error { _, err := c.realtimeCommand(ctx, realtimeRequest{op: opDetach, ref: ref, reason: reason}); return err }
func (c *Coordinator) Refresh(ctx context.Context, auth rt.AuthSnapshot) error { _, err := c.realtimeCommand(ctx, realtimeRequest{op: opRefresh, auth: auth}); return err }
func (c *Coordinator) HealthOutage(ctx context.Context, outage bool) error { _, err := c.realtimeCommand(ctx, realtimeRequest{op: opOutage, outage: outage}); return err }
func (c *Coordinator) ProfileChanged(ctx context.Context, account identity.Account, _ time.Time) error { _, err := c.realtimeCommand(ctx, realtimeRequest{op: opProfile, account: account}); return err }
func (c *Coordinator) PreferencesChanged(ctx context.Context, accountID string, generation int64, preferences rt.Preferences, _ time.Time) error { _, err := c.realtimeCommand(ctx, realtimeRequest{op: opPreferences, identityID: accountID, generation: generation, preferences: preferences}); return err }
func (c *Coordinator) GetGuestPreferences(ctx context.Context, id string, verifier identity.Verifier, _ time.Time) (rt.Preferences, error) { result, err := c.realtimeCommand(ctx, realtimeRequest{op: opGetGuestPreferences, identityID: id, verifier: verifier}); return result.preferences, err }
func (c *Coordinator) UpdateGuestPreferences(ctx context.Context, id string, verifier identity.Verifier, preferences rt.Preferences, _ time.Time) (rt.Preferences, error) { result, err := c.realtimeCommand(ctx, realtimeRequest{op: opSetGuestPreferences, identityID: id, verifier: verifier, preferences: preferences}); return result.preferences, err }

func (m *liveMemory) apply(req realtimeRequest, now time.Time) realtimeResult {
	if isPremiumOperation(req.op) { return m.applyPremium(req, now) }
	switch req.op {
 case opAdmission: return realtimeResult{err:m.changeAdmission(req.maintenance,req.drainDeadline,now)}
	case opFence: return realtimeResult{fence: m.fence}
	case opAttach: return m.attach(req.attach, req.resumeToken, now)
	case opCommand: return realtimeResult{err: m.command(req.ref, req.command, now)}
	case opDetach:
		if p := m.byConnection(req.ref); p != nil { m.disconnect(p, now, "connection_lost") }
		return realtimeResult{}
	case opRefresh: return realtimeResult{err: m.refresh(req.auth, now)}
	case opOutage:
		if m.latched { return realtimeResult{err: rt.ErrUnavailable} }
		if req.outage && !m.outage {
			m.outage = true; m.outageUntil = now.Add(5 * time.Second); m.fence++
			m.endAllCalls(now, "service_unavailable")
			for _, p := range m.participants { if p.state == rt.Waiting { m.unqueue(p); p.state = rt.Idle; m.emit(p, "queue.paused", m.stateReason(p, "service_unavailable"), "") }; m.emit(p, "service.unavailable", rt.StatusPayload{Reason: "service_unavailable"}, "") }
		} else if !req.outage { m.outage = false; m.outageUntil = time.Time{} }
		return realtimeResult{}
	case opProfile:
		if identity.ValidateProfile(req.account.Profile) != nil { return realtimeResult{err: identity.ErrInvalid} }
		m.fence++
		for _, p := range m.participants {
			if p.auth.Kind != identity.KindAccount || p.auth.IdentityID != req.account.ID { continue }
			if req.account.Generation < p.auth.IdentityGeneration { continue }
			if req.account.Status != "active" || req.account.Generation != p.auth.IdentityGeneration { m.terminate(p, now, "session_ended"); continue }
			if req.account.Profile.Version <= p.auth.Profile.Version { continue }
			p.auth.Profile = cloneProfile(req.account.Profile); p.slot.profile = cloneProfile(req.account.Profile); p.slot.generation++
			m.reindex(p)
		}
		m.match(now); return realtimeResult{}
	case opPreferences:
		m.fence++
		for _, p := range m.participants {
			if p.auth.Kind != identity.KindAccount || p.auth.IdentityID != req.identityID { continue }
			if p.auth.IdentityGeneration != req.generation { return realtimeResult{err: rt.ErrUnauthorized} }
			if req.preferences.Version <= p.auth.Preferences.Version { continue }
			p.auth.Preferences = rt.ClonePreferences(req.preferences); p.everyoneOverride = false; m.reindex(p)
			if p.state == rt.Waiting && p.queueAuth.Preferences.Gender != rt.Everyone && !p.auth.Entitlement.Active(now) { m.pause(p, "premium_expired") }
		}
		m.match(now); return realtimeResult{}
	case opGetGuestPreferences, opSetGuestPreferences:
		entry := m.guests.byVerifier[req.verifier]
		if entry == nil || entry.guest.ID != req.identityID || entry.reservation != nil { return realtimeResult{err: identity.ErrUnauthorized} }
		preferences, exists := m.guestPreferences[req.identityID]
		if !exists { preferences = rt.DefaultPreferences() }
		if req.op == opSetGuestPreferences {
			if err := rt.ValidatePreferences(req.preferences); err != nil { return realtimeResult{err: err} }
			if needsPremium(req.preferences) { return realtimeResult{err: rt.ErrPremiumRequired} }
			if req.preferences.Version != preferences.Version { return realtimeResult{err: identity.ErrStale} }
			preferences = rt.ClonePreferences(req.preferences); preferences.Version++; m.fence++
			m.guestPreferences[req.identityID] = preferences
			if p := m.participants[entry.slot.id]; p != nil { p.auth.Preferences = rt.ClonePreferences(preferences); p.everyoneOverride = false; m.reindex(p) }
			m.match(now)
		}
		return realtimeResult{preferences: rt.ClonePreferences(preferences)}
	}
	return realtimeResult{err: rt.ErrProtocol}
}

func needsPremium(p rt.Preferences) bool {
	if p.Gender != rt.Everyone { return true }
	if p.Professional.NoPreference { return false }
	for _, category := range []rt.CategoryPreference{p.Professional.Industry, p.Professional.Profession, p.Professional.Experience, p.Professional.Interests, p.Professional.Topics} { if !category.NoPreference && len(category.Choices) != 0 { return true } }
	return false
}
func (m *liveMemory) validateAuth(auth rt.AuthSnapshot, now time.Time) error {
	if auth.Fence != m.fence { return rt.ErrUnavailable }
	if m.outage { return rt.ErrUnavailable }
	if !now.Before(auth.ValidUntil) || auth.AuthorizedAt.After(now) || auth.ValidUntil.Sub(auth.AuthorizedAt) > 30*time.Second || auth.IdentityGeneration < 1 || !validInternalID(auth.IdentityID) || auth.SessionVerifier == (identity.Verifier{}) { return rt.ErrUnauthorized }
	if auth.Kind == identity.KindAccount { if _, pending := m.safety.handoffs[auth.IdentityID]; pending { return rt.ErrUnavailable } }
	if auth.Restricted || m.subjectRestricted(auth.Kind, auth.IdentityID) { return rt.ErrBlocked }
	if auth.Profile.Gender != identity.GenderMale && auth.Profile.Gender != identity.GenderFemale && auth.Profile.Gender != identity.GenderOther { return rt.ErrGenderRequired }
	if identity.ValidateProfile(auth.Profile) != nil || rt.ValidatePreferences(auth.Preferences) != nil || len(auth.BlockedIdentities) > rt.MaxBlockedIdentities { return rt.ErrProtocol }
	if auth.Kind == identity.KindGuest {
		entry := m.guests.byVerifier[auth.SessionVerifier]
		if entry == nil || entry.reservation != nil || entry.guest.ID != auth.IdentityID || entry.guest.Generation != auth.IdentityGeneration || entry.guest.Profile.Version != auth.Profile.Version { return rt.ErrUnauthorized }
	} else if auth.Kind != identity.KindAccount || !validInternalID(auth.SessionID) { return rt.ErrUnauthorized }
	return nil
}
func (m *liveMemory) identitySlot(auth rt.AuthSnapshot, now time.Time) (*participantSlot, error) {
	if auth.Kind == identity.KindGuest { return m.guests.byVerifier[auth.SessionVerifier].slot, nil }
	for _, slot := range m.guests.slots { if slot.accountID == auth.IdentityID { return slot, nil } }
	if len(m.guests.slots) >= ParticipantSlotCapacity { return nil, rt.ErrCapacity }
	slot := &participantSlot{id: m.opaque("slot"), accountID: auth.IdentityID, accountGeneration: auth.IdentityGeneration, sessionID: auth.SessionID, generation: 1, profile: cloneProfile(auth.Profile), lastSeenAt: now}
	m.guests.slots[slot.id] = slot
	return slot, nil
}
func (m *liveMemory) attach(request rt.AttachRequest, resumeToken string, now time.Time) realtimeResult {
	if m.stopped(now) { return realtimeResult{err: rt.ErrUnavailable} }
 // Existing matched transports may resume during the grace window so safety
 // controls remain reachable; no new participant or takeover enters a drain.
 if m.maintenance && (request.Resume==nil || request.Takeover || !now.Before(m.drainDeadline)) { return realtimeResult{err:rt.ErrUnavailable} }
	if err := m.validateAuth(request.Auth, now); err != nil { return realtimeResult{err: err} }
	if err := m.hydrateFriends(request.Auth, now); err != nil { return realtimeResult{err: err} }
	slot, err := m.identitySlot(request.Auth, now)
	if err != nil { return realtimeResult{err: err} }
	p := m.participants[slot.id]
	resuming := false
	if p != nil {
		if request.Takeover {
			m.endMatch(p, now, "connection_replaced", false)
			m.closeConnection(p, "session.replaced", "connection_replaced")
			m.unqueue(p); p.state = rt.Idle; p.graceUntil = time.Time{}; m.participants[slot.id] = p
		} else {
			resume := request.Resume
			if resume != nil && resume.ServerInstance == m.instance && resume.Generation == p.connectionGeneration && (m.sameSession(p.auth, request.Auth) || (p.handoff && request.Auth.Kind == identity.KindAccount && p.auth.IdentityID == request.Auth.IdentityID && p.auth.SessionID == request.Auth.SessionID && p.auth.IdentityGeneration == request.Auth.IdentityGeneration)) {
				digest := sha256.Sum256([]byte(resume.Token))
				resuming = subtle.ConstantTimeCompare(digest[:], p.resumeHash[:]) == 1
				if p.interactionID != "" { interaction := m.interactions[p.interactionID]; resuming = resuming && interaction != nil && resume.InteractionID == interaction.id && resume.Epoch == interaction.epoch && (p.connection != nil || now.Before(p.graceUntil)) } else { resuming = resuming && resume.InteractionID == "" && resume.Epoch == 0 }
			}
			if !resuming { return realtimeResult{err: rt.ErrTakeoverRequired} }
			// The rotating RAM-only proof also permits replacement of a half-open
			// transport. A second tab with only the cookie has no such proof.
			if p.connection != nil { m.closeConnection(p, "session.closed", "connection_resumed") }
			if p.interactionID == "" { m.unqueue(p) }
		}
	} else {
		if request.Resume != nil { return realtimeResult{err: rt.ErrStaleEpoch} }
		if len(m.participants) >= LaunchLimits().Connected { return realtimeResult{err: rt.ErrCapacity} }
		p = &liveParticipant{slot: slot, state: rt.Idle}; m.participants[slot.id] = p
	}
	p.auth = cloneAuth(request.Auth); p.handoff = false; p.slot.lastSeenAt = now
	p.slot.sessionID = request.Auth.SessionID; p.slot.accountGeneration = request.Auth.IdentityGeneration
	m.connectionSerial++; p.connectionGeneration = m.connectionSerial; p.resumeToken = resumeToken; p.resumeHash = sha256.Sum256([]byte(resumeToken)); p.graceUntil = time.Time{}
	connection := &liveConnection{ref: rt.ConnectionRef{Handle: slot.id, Generation: p.connectionGeneration}, events: make(chan rt.ServerEvent, rt.OutboundCapacity), closed: make(chan struct{}), dedupe: make(map[string][32]byte), lastSeen: now}
	p.connection = connection
	if p.interactionID == "" { p.state = rt.Idle } else { p.state = rt.Matched }
	m.emit(p, "session.ready", m.state(p), "")
	if resuming { m.replayChat(p) }
	if resuming && p.interactionID != "" { if peer := m.peer(p); peer != nil { m.emit(peer, "peer.reconnected", m.state(peer), "") } }
	return realtimeResult{connection: rt.Connection{Ref: connection.ref, Events: connection.events, Closed: connection.closed}}
}
func (m *liveMemory) sameSession(a, b rt.AuthSnapshot) bool { return a.Kind == b.Kind && a.IdentityID == b.IdentityID && a.IdentityGeneration == b.IdentityGeneration && a.SessionID == b.SessionID && a.SessionVerifier == b.SessionVerifier }
func (m *liveMemory) byConnection(ref rt.ConnectionRef) *liveParticipant { p := m.participants[ref.Handle]; if p == nil || p.connection == nil || p.connection.ref != ref { return nil }; return p }
func (m *liveMemory) refresh(auth rt.AuthSnapshot, now time.Time) error {
	if auth.Fence == m.fence && auth.Restricted { for _, p := range m.participants { if p.auth.Kind == auth.Kind && p.auth.IdentityID == auth.IdentityID { m.terminate(p, now, "not_available") } }; m.fence++; return rt.ErrBlocked }
	if err := m.validateAuth(auth, now); err != nil { return err }
	for _, p := range m.participants {
		if !m.sameSession(p.auth, auth) { continue }
		if auth.Profile.Version < p.auth.Profile.Version || auth.Preferences.Version < p.auth.Preferences.Version || auth.SafetyVersion < p.auth.SafetyVersion || auth.Entitlement.Version < p.auth.Entitlement.Version { return rt.ErrUnavailable }
		if err := m.hydrateFriends(auth, now); err != nil { return err }
		priorEntitlement := p.auth.Entitlement
		p.auth = cloneAuth(auth); if auth.Entitlement.Active(now) { p.expiryNotified = false }; p.slot.lastSeenAt = now; m.reindex(p)
		if p.state == rt.Waiting && p.queueAuth.Preferences.Gender != rt.Everyone && !auth.Entitlement.Active(now) { m.pause(p, "premium_expired") }
		if priorEntitlement.Premium != auth.Entitlement.Premium || priorEntitlement.Version != auth.Entitlement.Version || !priorEntitlement.ExpiresAt.Equal(auth.Entitlement.ExpiresAt) { m.emit(p, "premium.changed", m.stateReason(p, "premium_changed"), "") }
		if peer := m.peer(p); peer != nil && m.blocked(p, peer) { m.endMatch(p, now, "not_available", false) }
	}
	m.match(now); return nil
}
func (m *liveMemory) command(ref rt.ConnectionRef, command rt.ClientEnvelope, now time.Time) error {
	if m.stopped(now) { return rt.ErrUnavailable }
	p := m.byConnection(ref)
	if p == nil || command.Generation != ref.Generation { return rt.ErrStaleGeneration }
	if command.V != rt.ProtocolVersion { return rt.ErrVersion }
	if command.ID == "" || len(command.ID) > 64 { return rt.ErrProtocol }
	var encoded bytes.Buffer; encoder := json.NewEncoder(&encoded); encoder.SetEscapeHTML(false)
	if encoder.Encode(command) != nil { return rt.ErrProtocol }; wire := encoded.Bytes(); if _, err := rt.DecodeEnvelope(wire); err != nil { return err }
	if previous, exists := p.connection.dedupe[command.ID]; exists {
		if previous != sha256.Sum256(wire) { return rt.ErrProtocol }
		if command.Type != "chat.send" { m.emit(p, "command.ack", rt.StatusPayload{Reason: "duplicate"}, command.ID); return nil }
	}
	if p.auth.Kind == identity.KindGuest { entry := m.guests.byVerifier[p.auth.SessionVerifier]; if entry == nil || entry.reservation != nil { return rt.ErrUnauthorized } }
	if !now.Before(p.auth.ValidUntil) { return rt.ErrUnavailable }
 if m.maintenance && admissionCommand(command.Type) { return rt.ErrUnavailable }
	if m.outage && command.Type != "match.end" && command.Type != "queue.leave" && command.Type != "heartbeat" { return rt.ErrUnavailable }
	if command.Type == "match.next" || command.Type == "match.end" || command.Type == "chat.send" || command.Type == "chat.delivery_ack" || command.Type == "friend.request" || command.Type == "friend.accept" || command.Type == "friend.decline" || command.Type == "friend.withdraw" || strings.HasPrefix(command.Type,"call.") || strings.HasPrefix(command.Type,"webrtc.") {
		interaction := m.interactions[p.interactionID]
		if interaction == nil || command.InteractionID != interaction.id || command.Epoch != interaction.epoch { return rt.ErrStaleEpoch }
	} else if command.Epoch != 0 || command.InteractionID != "" { return rt.ErrStaleEpoch }
	switch command.Type {
	case "state.sync":
		m.emit(p, "session.state", m.state(p), command.ID)
	case "heartbeat":
		p.connection.lastSeen = now
		m.emit(p, "pong", rt.StatusPayload{}, command.ID)
	case "queue.join":
		if p.state != rt.Idle { return rt.ErrUnavailable }
		options, err := rt.DecodeQueueJoin(command)
		if err != nil { return err }
		if err := m.enqueue(p, options.ContinueWithEveryone, now); err != nil { return err }
	case "queue.leave":
		if p.state != rt.Waiting && p.state != rt.Idle { return rt.ErrUnavailable }
		m.unqueue(p); p.state = rt.Idle; m.emit(p, "queue.paused", m.stateReason(p, "left_queue"), command.ID)
	case "chat.send":
		if err := m.sendChat(p, command, now); err != nil { return err }
	case "chat.delivery_ack":
		if err := m.deliveryAck(p, command, now); err != nil { return err }
	case "friend.request", "friend.accept", "friend.decline", "friend.withdraw", "friend.invite", "friend.accept_invite", "friend.decline_invite":
		if err := m.friendCommand(p, command, now); err != nil { return err }
	case "call.request", "call.accept", "call.decline", "call.end", "call.connected", "webrtc.offer", "webrtc.answer", "webrtc.ice":
		if err := m.audioCommand(p, command, now); err != nil { return err }
	case "match.end": m.endMatch(p, now, "ended", false)
	case "match.next":
		// Teardown is committed first; a full queue never resurrects the match.
		m.endMatch(p, now, "next", true)
		if err := m.enqueue(p, false, now); err != nil { m.emit(p, "queue.paused", m.stateReason(p, rt.PublicError(err).Code), command.ID) }
	default: return rt.ErrProtocol
	}
	if p.connection != nil {
		p.connection.lastSeen = now; m.touchGuest(p, now)
		p.connection.dedupe[command.ID] = sha256.Sum256(wire); p.connection.dedupeOrder = append(p.connection.dedupeOrder, command.ID)
		if len(p.connection.dedupeOrder) > rt.MaxCommandDedupe { delete(p.connection.dedupe, p.connection.dedupeOrder[0]); p.connection.dedupeOrder = p.connection.dedupeOrder[1:] }
		m.emit(p, "command.ack", rt.StatusPayload{}, command.ID)
	}
	m.match(now); return nil
}

func (m *liveMemory) enqueue(p *liveParticipant, everyone bool, now time.Time) error {
	if m.maintenance { return rt.ErrUnavailable }
	if m.outage || p.connection == nil || !now.Before(p.auth.ValidUntil) || p.auth.Restricted || len(p.slot.carry.restrictions) > 0 { return rt.ErrUnavailable }
	if len(m.waiting) >= LaunchLimits().Waiting { return rt.ErrCapacity }
	preferences := rt.ClonePreferences(p.auth.Preferences)
	if everyone { preferences.Gender = rt.Everyone; preferences.Professional.NoPreference = true }
	if preferences.Gender != rt.Everyone && m.premiumBlocked(p.auth.IdentityID) { return rt.ErrUnavailable }
	if preferences.Gender != rt.Everyone && !p.auth.Entitlement.Active(now) { p.pauseStrict = true; return rt.ErrPremiumRequired }
	p.pauseStrict = false; p.everyoneOverride = everyone; p.state = rt.Waiting; p.queuedAt = now; p.queueAuth = cloneAuth(p.auth); p.queueAuth.Preferences = preferences
 p.queueRequestedAt=m.operationStarted;if p.queueRequestedAt.IsZero(){p.queueRequestedAt=time.Now()}
	m.serial++; p.tieBreak = binary.BigEndian.Uint64(sha256Sum(m.secret, m.serial)[:8])
	m.waiting[p.slot.id] = p; m.gender[p.queueAuth.Profile.Gender][p.slot.id] = p
 m.metrics.QueueJoins++
	m.ensurePremiumUsage(p, now)
	m.emit(p, "queue.joined", m.state(p), "")
	return nil
}
func sha256Sum(secret [32]byte, serial uint64) []byte { var value [8]byte; binary.BigEndian.PutUint64(value[:], serial); hash := hmac.New(sha256.New, secret[:]); hash.Write(value[:]); return hash.Sum(nil) }
func (m *liveMemory) unqueue(p *liveParticipant) { if m.waiting[p.slot.id] == p && p.state != rt.Reserved { m.metrics.QueueDepartures++ }; m.cancelPremiumUsage(p); delete(m.waiting, p.slot.id); for _, index := range m.gender { delete(index, p.slot.id) }; p.queuedAt = time.Time{} }
func (m *liveMemory) reindex(p *liveParticipant) {
	if p.state != rt.Waiting { return }
	// Preserve an explicit per-search Everyone override while refreshing all
	// authoritative profile, safety and entitlement versions.
	p.queueAuth = cloneAuth(p.auth)
	if p.everyoneOverride { p.queueAuth.Preferences.Gender = rt.Everyone; p.queueAuth.Preferences.Professional.NoPreference = true }
	for _, index := range m.gender { delete(index, p.slot.id) }
	if index := m.gender[p.queueAuth.Profile.Gender]; index != nil { index[p.slot.id] = p }
}
func (m *liveMemory) pause(p *liveParticipant, reason string) { m.unqueue(p); p.state = rt.Idle; p.pauseStrict = true; m.emit(p, "queue.paused", m.stateReason(p, reason), "") }
func (m *liveMemory) entry(p *liveParticipant, now time.Time) rt.QueueEntry {
	auth := cloneAuth(p.queueAuth)
	auth.Restricted = auth.Restricted || len(p.slot.carry.restrictions) != 0
	own := slotSubject(p.slot)
	for _, blocked := range m.safety.edges[subjectKey(own.Kind, own.ID)] { auth.BlockedIdentities = append(auth.BlockedIdentities, blocked.ID) }
	for id := range p.slot.carry.blocks { if peer := m.participants[id]; peer != nil { auth.BlockedIdentities = append(auth.BlockedIdentities, peer.auth.IdentityID) } }
	available := p.state == rt.Waiting && now.Before(p.auth.ValidUntil)
	if auth.Kind == identity.KindAccount && m.premiumBlocked(auth.IdentityID) { auth.Entitlement.Premium = false; if auth.Preferences.Gender != rt.Everyone { available = false } }
	if m.premium.enabled && auth.Entitlement.Active(now) && rt.UsesPaidMatching(auth) && !auth.Entitlement.PaidUseAuthorized(now) { available = false }
	if p.auth.Kind == identity.KindGuest { entry := m.guests.byVerifier[p.auth.SessionVerifier]; available = available && entry != nil && entry.reservation == nil }
	return rt.QueueEntry{SlotID: p.slot.id, Auth: auth, QueuedAt: p.queuedAt, Connected: p.connection != nil, Available: available, TieBreak: p.tieBreak}
}
func pairKey(a, b string) string { if a > b { a, b = b, a }; return a + ":" + b }
func (m *liveMemory) match(now time.Time) {
	if m.stopped(now) { return }
	if m.maintenance { return }
	if m.outage { return }
	for len(m.waiting) >= 2 {
		for _, p := range m.waiting { m.ensurePremiumUsage(p, now) }
		entries := make([]rt.QueueEntry, 0, len(m.waiting))
		// All gender indexes belong to the same authoritative pool. Include all
		// indexes; profession and payment status never partition population.
		for _, gender := range []identity.Gender{identity.GenderMale, identity.GenderFemale, identity.GenderOther} { for id, p := range m.gender[gender] { if m.waiting[id] == p { entries = append(entries, m.entry(p, now)) } } }
		lookup := func(a, b rt.QueueEntry) (rt.PairHistory, bool) { value, ok := m.history[pairKey(a.SlotID, b.SlotID)]; return value, ok }
		searchStarted := time.Now()
 pair, ok := rt.SelectPair(entries, now, lookup)
 searchElapsed := time.Since(searchStarted)
		if !ok { return }
		a, b := m.waiting[pair.Anchor.SlotID], m.waiting[pair.Candidate.SlotID]
		if a == nil || b == nil { return }
		// Reservation and final commit occur within this owner turn. No I/O or
		// external callback can interleave with these generation-bound reads.
		a.state, b.state = rt.Reserved, rt.Reserved
		aa, bb := pair.Anchor, pair.Candidate
		history, _ := lookup(aa, bb)
		if !rt.HardCompatible(aa, bb, now, history) || m.blocked(a, b) { a.state, b.state = rt.Waiting, rt.Waiting; return }
		if m.stopped(now) { return }
		key := pairKey(a.slot.id, b.slot.id)
		if _, exists := m.history[key]; !exists {
			if len(m.history) >= 10000 { a.state, b.state = rt.Waiting, rt.Waiting; m.pause(a, "recent_pair_capacity"); m.pause(b, "recent_pair_capacity"); continue }
			m.history[key] = rt.PairHistory{} // reserve history capacity before admission
		}
		m.observeMatch(aa, bb, history, now, searchElapsed)
 commitStart:=pairReadyUpperBound(a,b,history)
 m.allocateInteraction(a, b, "", now)
 if !commitStart.IsZero(){m.processing.Match(time.Since(commitStart))}
	}
}

func (m *liveMemory) peer(p *liveParticipant) *liveParticipant { interaction := m.interactions[p.interactionID]; if interaction == nil { return nil }; if interaction.a == p.slot.id { return m.participants[interaction.b] }; return m.participants[interaction.a] }
func (m *liveMemory) blocked(a, b *liveParticipant) bool {
	sa, sb := slotSubject(a.slot), slotSubject(b.slot)
	if _, blocked := m.safety.edges[subjectKey(sa.Kind, sa.ID)][subjectKey(sb.Kind, sb.ID)]; blocked { return true }
	if a.auth.Restricted || b.auth.Restricted || len(a.slot.carry.restrictions) != 0 || len(b.slot.carry.restrictions) != 0 { return true }
	if _, ok := a.slot.carry.blocks[b.slot.id]; ok { return true }; if _, ok := b.slot.carry.blocks[a.slot.id]; ok { return true }
	for _, id := range a.auth.BlockedIdentities { if id == b.auth.IdentityID { return true } }; for _, id := range b.auth.BlockedIdentities { if id == a.auth.IdentityID { return true } }
	return false
}
func (m *liveMemory) endMatch(p *liveParticipant, now time.Time, reason string, skip bool) {
	interaction := m.interactions[p.interactionID]
	if interaction == nil { return }
	m.endInteractionCall(interaction, now, reason)
	key := pairKey(interaction.a, interaction.b); history := m.history[key]; history.EndedAt = now
	kept := history.Skips[:0]; for _, at := range history.Skips { if now.Sub(at) < time.Minute { kept = append(kept, at) } }; history.Skips = kept
	if skip { history.Skips = append(history.Skips, now); if len(history.Skips) > 2 { history.Skips = history.Skips[len(history.Skips)-2:] } }
	m.history[key] = history
	m.closeFriendRequests(interaction.id)
	m.purgeInteractionEvents(interaction)
	m.rememberEnded(interaction, now)
	interaction.messages = nil; interaction.messageBytes = 0; interaction.sendIDs = nil
	delete(m.interactions, interaction.id)
	for _, id := range []string{interaction.a, interaction.b} {
		member := m.participants[id]; if member == nil { continue }
		member.interactionID = ""; member.graceUntil = time.Time{}; member.advisory = len(history.Skips) >= 2
		if member.connection != nil { member.state = rt.Idle; m.emit(member, "match.ended", m.stateReason(member, reason), "") } else { member.state = rt.Offline; delete(m.participants, id) }
	}
}
func (m *liveMemory) stateReason(p *liveParticipant, reason string) rt.StateSnapshot { state := m.state(p); state.Reason = reason; return state }
func (m *liveMemory) state(p *liveParticipant) rt.StateSnapshot {
	state := rt.StateSnapshot{FriendsEnabled: p.auth.FriendsEnabled, TextEnabled: p.auth.TextEnabled, EndedReportRef: p.endedRef, State: p.state, ServerInstance: m.instance, ResumeToken: p.resumeToken, Generation: p.connectionGeneration, RepeatAdvisory: p.advisory, HeartbeatSeconds: int(rt.HeartbeatInterval/time.Second), ReconnectSeconds: int(rt.ReconnectGrace/time.Second)}
 if m.maintenance { state.Maintenance=&rt.MaintenanceView{Deadline:m.drainDeadline} }
	m.friendState(p, &state)
	m.audioState(p, &state)
	m.premiumState(p, &state, m.now)
	if p.state == rt.Waiting { queued := p.queuedAt; state.QueuedAt = &queued }
	if ended := m.safety.ended[p.endedRef]; ended != nil { until := ended.expiresAt; state.EndedReportExpiresAt = &until }
	if interaction := m.interactions[p.interactionID]; interaction != nil {
		peer := m.peer(p); public := interaction.bProfile; own := interaction.aProfile
		if interaction.b == p.slot.id { public, own = interaction.aProfile, interaction.bProfile }
		kind := "random"; friendRef := interaction.friendRef; if interaction.friendRef != "" { kind = "friend" } else if peer != nil { if ref := m.friends.pairs[friendPair(friendSubject(p.slot), friendSubject(peer.slot))]; ref != "" { if link := m.friends.links[ref]; link != nil && !link.removed { friendRef = ref } } }
		state.Interaction = &rt.InteractionView{Kind: kind, FriendRef: friendRef, ID: interaction.id, Epoch: interaction.epoch, Peer: public, OwnTopic: own.Topic, PeerConnected: peer != nil && peer.connection != nil}
		if peer != nil && !peer.graceUntil.IsZero() { until := peer.graceUntil; state.Interaction.ReconnectUntil = &until }
	}
	return state
}
func (m *liveMemory) emit(p *liveParticipant, eventType string, payload any, replyTo string) { m.emitEvent(p,eventType,payload,replyTo,true) }
func (m *liveMemory) emitEvent(p *liveParticipant, eventType string, payload any, replyTo string, scoped bool) {
	if p.connection == nil { return }
	connection := p.connection; connection.sequence++
	event := rt.ServerEvent{V: rt.ProtocolVersion, ID: m.opaque("event"), Type: eventType, Generation: connection.ref.Generation, ReplyTo: replyTo, Payload: payload}
	if interaction := m.interactions[p.interactionID]; interaction != nil && scoped { event.InteractionID, event.Epoch = interaction.id, interaction.epoch }
	select { case connection.events <- event: default:
		// Reclaim a slow writer without blocking the owner. Its matched peer
		// enters the same bounded disconnected state as a network failure.
		m.disconnect(p, m.now, "slow_consumer")
	}
}
func (m *liveMemory) closeConnection(p *liveParticipant, eventType, reason string) {
	connection := p.connection; if connection == nil { return }
	p.connection = nil
	if interaction := m.interactions[p.interactionID]; interaction != nil { m.endInteractionCall(interaction, m.now, "signaling_lost") }
	for { select { case <-connection.events: default: goto drained } }
	drained:
	connection.events <- rt.ServerEvent{V: rt.ProtocolVersion, ID: m.opaque("closed"), Type: eventType, Generation: connection.ref.Generation, Payload: rt.StatusPayload{Reason: reason}}
	close(connection.closed); close(connection.events)
}
func (m *liveMemory) disconnect(p *liveParticipant, now time.Time, reason string) {
	if p.connection == nil { return }
	m.closeConnection(p, "session.closed", reason); m.unqueue(p)
	if p.interactionID != "" { p.state = rt.Offline; p.graceUntil = now.Add(rt.ReconnectGrace); if peer := m.peer(p); peer != nil { m.emit(peer, "peer.disconnected", m.state(peer), "") } } else { p.state = rt.Offline; delete(m.participants, p.slot.id) }
}
func (m *liveMemory) terminate(p *liveParticipant, now time.Time, reason string) { m.endMatch(p, now, reason, false); m.unqueue(p); m.closeConnection(p, "session.closed", reason); p.state = rt.Offline; delete(m.participants, p.slot.id) }
func (m *liveMemory) touchGuest(p *liveParticipant, now time.Time) { p.slot.lastSeenAt = now; if p.auth.Kind == identity.KindGuest { if entry := m.guests.byVerifier[p.auth.SessionVerifier]; entry != nil { entry.guest.LastSeenAt = now } } }
func (m *liveMemory) maintain(now time.Time) {
	m.now = now
 m.maintainAdmission(now)
	m.expireSafety(now)
	m.maintainFriends(now)
	m.maintainAudio(now)
	m.maintainPremium(now)
	if m.stopped(now) { return }
	for id := range m.guestPreferences { if slot := m.guests.slots[id]; slot == nil || slot.guestID == "" { delete(m.guestPreferences, id) } }
	for _, p := range m.participants {
		if m.guests.slots[p.slot.id] != p.slot || (p.auth.Kind == identity.KindGuest && p.slot.guestID == "") || (p.auth.Kind == identity.KindAccount && (p.slot.sessionID != p.auth.SessionID || p.slot.accountGeneration != p.auth.IdentityGeneration)) { m.terminate(p, now, "session_ended"); continue }
		if p.auth.Restricted || len(p.slot.carry.restrictions) != 0 { m.terminate(p, now, "not_available"); continue }
		if p.connection != nil && !now.Before(p.connection.lastSeen.Add(rt.DeadConnectionTimeout)) { m.disconnect(p, now, "heartbeat_timeout"); continue }
		if !p.graceUntil.IsZero() && !now.Before(p.graceUntil) { m.terminate(p, now, "reconnect_expired"); continue }
		if p.connection != nil && !now.Before(p.auth.ValidUntil) { if p.state == rt.Waiting { m.pause(p, "authorization_refresh_required") }; if !now.Before(p.auth.ValidUntil.Add(5*time.Second)) { m.terminate(p, now, "authorization_expired") }; continue }
	}
	if m.outage && !now.Before(m.outageUntil) { for _, p := range m.participants { m.terminate(p, now, "service_unavailable") } }
	activePairs := make(map[string]bool, len(m.interactions))
	for _, interaction := range m.interactions { activePairs[pairKey(interaction.a, interaction.b)] = true }
	for key, history := range m.history { if !activePairs[key] && !history.EndedAt.IsZero() && !now.Before(history.EndedAt.Add(rt.RecentPairTTL)) { delete(m.history, key) } }
	// Each match reserves its pair record before commit. This hard 10,000
	// record bound preserves the complete five-minute window without evicting
	// an active cooldown; excess churn pauses new searches visibly.
	m.match(now)
}
func (m *liveMemory) stopped(now time.Time) bool { if m.stop != nil && m.stop() { m.latchClosed(now) }; return m.latched }
func (m *liveMemory) latchClosed(now time.Time) { if m.latched { return }; m.latched = true; m.outage = true; m.outageUntil = now; m.fence++; for _, p := range m.participants { m.terminate(p, now, "authorization_unavailable") } }
func (m *liveMemory) connected() int { n := 0; for _, p := range m.participants { if p.connection != nil { n++ } }; return n }
func (m *liveMemory) shutdown() { m.endAllCalls(m.now,"server_restart"); for _, p := range m.participants { m.closeConnection(p, "session.closed", "server_restart") } }

func (m *liveMemory) identityChange(req guestRequest, result guestResult, now time.Time) {
	if result.err != nil { return }
	switch req.op {
	case guestUpdate:
		if entry := m.guests.byVerifier[req.verifier]; entry != nil { if p := m.participants[entry.slot.id]; p != nil { p.auth.Profile = cloneProfile(entry.guest.Profile); p.auth.IdentityGeneration = entry.guest.Generation; m.reindex(p) } }
	case guestCommit:
		if !result.committed { return }
		m.promoteSafetySubject(req.reservation.Guest.ID, now)
		m.promoteFriendSubject(req.reservation.Guest.ID, now)
		if m.safetyEnabled { m.queueHandoffFinalization(req.commit.AccountID, req.commit.AccountGeneration) }
		if p := m.participants[req.reservation.Guest.ID]; p != nil {
			// Rebind the SAME slot before maintenance sees the vanished guest.
			// Freeze until a fresh cookie proves the new account session.
			p.auth.Kind = identity.KindAccount; p.auth.IdentityID = req.commit.AccountID; p.auth.IdentityGeneration = req.commit.AccountGeneration; p.auth.SessionID = req.commit.SessionID; p.auth.SessionVerifier = identity.Verifier{}; p.auth.Profile = cloneProfile(req.commit.Profile)
			p.auth.ValidUntil = now.Add(rt.ReconnectGrace); p.handoff = true
			m.emit(p, "identity.changed", m.state(p), "")
			m.disconnect(p, now, "identity_changed")
		}
	case accountInvalidate, sessionInvalidate, accountRemove:
		if req.op == accountRemove { m.removeSubjectFriends(ft.Subject{Kind: identity.KindAccount, ID: req.accountID}, now) }
		for _, p := range m.participants { if p.auth.Kind == identity.KindAccount && p.auth.IdentityID == req.accountID && (req.op != sessionInvalidate || p.auth.SessionID == req.sessionID) { m.terminate(p, now, "session_ended") } }
	}
}
