package coordinator

import (
    "errors"
    "testing"
    "time"

    at "notitle/internal/audiotypes"
    rt "notitle/internal/realtime"
)

func TestDrainPreservesExistingTextAndAcceptedAudioUntilDeadline(t *testing.T){
    m,a,pa,b,pb,now:=audioPairFixture(t);call:=acceptAudio(t,m,pa,pb,now);provisionAudio(t,m,call,now);drain(a);drain(b)
    deadline:=now.Add(10*time.Second)
    if err:=m.changeAdmission(true,deadline,now);err!=nil{t.Fatal(err)}
    if len(m.interactions)!=1||call.state!=at.Connecting||m.state(pa).Maintenance==nil{t.Fatal("drain prematurely ended an accepted interaction")}
    event:=<-a.Events;if event.Type!="server.draining"||!event.Payload.(rt.MaintenanceView).Deadline.Equal(deadline){t.Fatal("restart deadline was not announced")}
    if err:=m.command(a.Ref,chatCommand(pa,m,"draining_text","draining_send","still connected"),now.Add(time.Second));err!=nil{t.Fatal("existing text disabled during drain",err)}
    if err:=m.command(a.Ref,audioEnvelope(m,pa,"call.request","new_during_drain",struct{}{}),now.Add(time.Second));!errors.Is(err,rt.ErrUnavailable){t.Fatal("new call admitted")}
    m.maintain(deadline)
    if len(m.participants)!=0||len(m.interactions)!=0||call.state!=at.Ended{t.Fatal("deadline did not end all interactions")}
    _,cleanup:=m.audioCounts();if cleanup!=1{t.Fatal("unconfirmed relay cleanup lost capacity reservation")}
    if err:=m.changeAdmission(false,time.Time{},deadline);!errors.Is(err,rt.ErrUnavailable){t.Fatal("opened before old media revocation")}
    jobs:=m.claimAudioJobs(50,deadline);if len(jobs)!=1||jobs[0].Action!="revoke"{t.Fatal("terminal media revocation not scheduled")}
    m.finishAudioJob(jobs[0].LeaseID,at.JobResult{Success:true,Revoked:true},deadline)
    if err:=m.changeAdmission(false,time.Time{},deadline);err!=nil||m.maintenance{t.Fatal("clean drained owner could not reopen",err)}
}

func TestDrainRemovesWaitingAndRejectsNewParticipant(t *testing.T){
    m:=memoryFixture();now:=rtNow();a,pa:=attachFixture(t,m,1,now);doCommand(t,m,a,pa,"queue.join","queue_before",now);drain(a)
    deadline:=now.Add(20*time.Second);if err:=m.changeAdmission(true,deadline,now);err!=nil{t.Fatal(err)}
    if len(m.waiting)!=0||pa.state!=rt.Idle{t.Fatal("drain retained waiting admission")}
    if err:=m.command(a.Ref,cmdFixture(a.Ref,"queue.join","queue_after",pa,m),now);!errors.Is(err,rt.ErrUnavailable){t.Fatal("queue bypassed maintenance")}
    auth:=accountAuth(2,now);auth.Fence=m.fence;if result:=m.attach(rt.AttachRequest{Auth:auth},"synthetic_resume_secret_with_32_bytes",now);!errors.Is(result.err,rt.ErrUnavailable){t.Fatal("new transport entered drain")}
    if err:=m.changeAdmission(false,time.Time{},now.Add(time.Second));!errors.Is(err,rt.ErrUnavailable){t.Fatal("announced deadline could be silently canceled")}
    if err:=m.changeAdmission(true,now.Add(120*time.Second),now.Add(time.Second));err!=nil||!m.drainDeadline.Equal(deadline){t.Fatal("retry extended drain deadline")}
}

func TestDrainCancelsRingingButRetainsSafetyAndEnd(t *testing.T){
    m,a,pa,b,_,now:=audioPairFixture(t);call:=requestAudio(t,m,pa,now);drain(a);drain(b)
    if err:=m.changeAdmission(true,now.Add(time.Minute),now);err!=nil{t.Fatal(err)}
    if call.state!=at.Ended||len(m.audio.calls)!=0{t.Fatal("ringing call survived closed admission")}
    doCommand(t,m,a,pa,"match.end","end_during_drain",now)
    if len(m.interactions)!=0{t.Fatal("End blocked by maintenance")}
}
