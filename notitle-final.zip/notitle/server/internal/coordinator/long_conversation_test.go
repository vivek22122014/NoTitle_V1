package coordinator

import (
    "fmt"
    "testing"
    "time"
)

// Logical fake-clock boundary only: this does not measure six-hour runtime,
// socket throughput, RSS, browser behavior or the 200/25 real-media capacity.
func TestSixHourMessageCadenceRetainsEarlyIdempotencyWithoutContentArchive(t *testing.T){
    m,a,pa,b,pb,now:=friendPairFixture(t)
    pa.auth.TextEnabled=true;pb.auth.TextEnabled=true
    interaction:=m.interactions[pa.interactionID]
    first:=chatCommand(pa,m,"long_frame_0","long_send_0","synthetic")
    for i:=0;i<8640;i++{
        at:=now.Add(time.Duration(i)*2500*time.Millisecond)
        pa.auth.ValidUntil=at.Add(30*time.Second);pb.auth.ValidUntil=pa.auth.ValidUntil
        sender:=pa;if i%2!=0{sender=pb}
        command:=chatCommand(sender,m,fmt.Sprintf("long_frame_%d",i),fmt.Sprintf("long_send_%d",i),"synthetic")
        if err:=m.sendChat(sender,command,at);err!=nil{t.Fatalf("logical send %d failed: %v",i,err)}
        drain(a);drain(b)
    }
    if interaction.textSequence!=8640||len(interaction.sendIDs)!=8640{t.Fatal("six-hour cadence lost accepted receipts")}
    if len(interaction.messages)>30||interaction.messageBytes>64<<10{t.Fatal("long conversation expanded ordinary content retention")}
    before:=interaction.textSequence
    if err:=m.sendChat(pa,first,now.Add(6*time.Hour));err!=nil||interaction.textSequence!=before{t.Fatal("early accepted retry became a new message",err)}
}
