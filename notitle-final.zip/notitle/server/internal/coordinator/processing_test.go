package coordinator

import (
    "testing"
    "time"
    "notitle/internal/performance"
    rt "notitle/internal/realtime"
)
func TestMatchUpperBoundExcludesMissingCandidateWaitAndKeepsAsyncDelay(t *testing.T){
    m:=memoryFixture();m.processing=performance.New();now:=rtNow();a,pa:=attachFixture(t,m,1,now);b,pb:=attachFixture(t,m,2,now)
    firstArrival:=time.Now().Add(-time.Hour);candidateArrival:=time.Now().Add(-400*time.Millisecond)
    m.operationStarted=firstArrival;doCommand(t,m,a,pa,"queue.join","old_waiter",now)
    if !pa.queueRequestedAt.Equal(firstArrival){t.Fatal("queue request timestamp lost")}
    m.operationStarted=candidateArrival;doCommand(t,m,b,pb,"queue.join","new_candidate",now)
    result:=m.processing.Snapshot().Match
    if !laterQueueRequest(pa,pb).Equal(candidateArrival){t.Fatal("no-candidate hour included in the observation base")}
    if result.Samples!=1||result.Buckets[8]+result.Buckets[9]!=1{t.Fatal("mailbox delay omitted",result)}
}
func TestMatchUpperBoundExcludesOnlyMandatoryCooldownAndRetainsMailbox(t *testing.T){
    wall:=rtNow();received:=time.Now();a:=&liveParticipant{queueRequestedAt:received.Add(-time.Hour),queuedAt:wall.Add(-time.Hour)}
    b:=&liveParticipant{queueRequestedAt:received,queuedAt:wall.Add(500*time.Millisecond)}
    history:=rt.PairHistory{EndedAt:wall}
    start:=pairReadyUpperBound(a,b,history)
    // Hard eligibility starts at wall+4s. The request spent0.5s in the owner
    // mailbox; retain that overhead by starting the observation at3.5s.
    if !start.Equal(received.Add(3500*time.Millisecond)){t.Fatal("cooldown calculation subtracted mailbox processing or included known ineligible wait")}
    history.EndedAt=wall.Add(-time.Minute)
    if !pairReadyUpperBound(a,b,history).Equal(received){t.Fatal("expired cooldown shortened an eligible wait")}
}
func TestPaidUseWaitDoesNotResetMatchUpperBound(t *testing.T){
    m:=memoryFixture();m.processing=performance.New();m.premium.enabled=true;now:=rtNow();a,pa:=attachFixture(t,m,1,now);b,pb:=attachFixture(t,m,2,now);paidFixture(pa,now,false)
    arrived:=time.Now().Add(-1500*time.Millisecond);m.operationStarted=arrived;doCommand(t,m,a,pa,"queue.join","paid_latency",now);doCommand(t,m,b,pb,"queue.join","free_latency",now)
    job:=claimUsageFixture(t,m,now);if m.processing.Snapshot().Match.Samples!=0{t.Fatal("uncommitted pending paid pair measured as completed")}
    e:=pa.auth.Entitlement;e.PaidControlsUsed=true;m.operationStarted=time.Now();ackUsageFixture(m,job,e,now)
    result:=m.processing.Snapshot().Match;if result.Samples!=1||result.Buckets[9]!=1{t.Fatal("paid-use callback reset elapsed queue/authorization time",result)}
}
