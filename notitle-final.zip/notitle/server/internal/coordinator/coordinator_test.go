package coordinator

import (
	"context"
	"errors"
	"runtime"
	"sync"
	"testing"
	"time"
)

type fixedClock struct {
	value time.Time
}
func (c fixedClock) Now() time.Time {
	return c.value
}

func start(t *testing.T) (*Coordinator, context.CancelFunc) {
	t.Helper()
	ctx, cancel := context.WithCancel(context.Background())
	c := New(fixedClock{time.Date(2026, 1, 2, 3, 4, 5, 0, time.UTC)})
	go func() {
		_ = c.Run(ctx)
	}()
	deadline := time.Now().Add(time.Second)
	for !c.Running() {
		if time.Now().After(deadline) {
			cancel()
			t.Fatal("owner failed to start")
		}
		runtime.Gosched()
	}
	t.Cleanup(func() {
		cancel()
		select {
		case <-c.Done():
		case <-time.After(time.Second):
			t.Error("owner did not stop")
		}
	})
	return c, cancel
}

func TestLifecycleCapacityAndSingleOwner(t *testing.T) {
	c := New(fixedClock{})
	if err := c.Ready(context.Background()); !errors.Is(err, ErrNotRunning) {
		t.Fatal("unstarted owner was ready")
	}
	c, cancel := start(t)
	state, err := c.Snapshot(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if state.Limits != (Limits{Connected: 200, Waiting: 100, AudioCalls: 25}) {
		t.Fatalf("unexpected launch limits: %+v", state.Limits)
	}
	if state.StartedAt.Year() != 2026 {
		t.Fatal("injected clock not used")
	}
	if err := c.Run(context.Background()); !errors.Is(err, ErrAlreadyStarted) {
		t.Fatal("second owner accepted")
	}
	cancel()
	select {
	case <-c.Done():
	case <-time.After(time.Second):
		t.Fatal("owner did not cancel")
	}
	if err := c.Ready(context.Background()); !errors.Is(err, ErrNotRunning) {
		t.Fatal("stopped owner was ready")
	}
}

func TestCanceledRequestDoesNotBlockOwner(t *testing.T) {
	c, _ := start(t)
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := c.Snapshot(ctx); !errors.Is(err, context.Canceled) {
		t.Fatalf("got %v", err)
	}
	var wg sync.WaitGroup
	for range 100 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			ctx, cancel := context.WithTimeout(context.Background(), time.Second)
			defer cancel()
			_, err := c.Snapshot(ctx)
			if err != nil && !errors.Is(err, ErrOverloaded) {
				t.Errorf("snapshot: %v", err)
			}
		}()
	}
	wg.Wait()
	ctx, cancel = context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if err := c.Ready(ctx); err != nil {
		t.Fatal(err)
	}
}

func TestMailboxRejectsOverflowWithoutWaiting(t *testing.T) {
	// Deliberately no owner; fill the finite mailbox to test admission directly.
	c := New(fixedClock{})
	c.running.Store(true)
	for range MailboxCapacity {
		c.requests <- request{}
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if _, err := c.Snapshot(ctx); !errors.Is(err, ErrOverloaded) {
		t.Fatalf("got %v", err)
	}
	if cap(c.requests) != MailboxCapacity {
		t.Fatal("mailbox is not bounded")
	}
}

func TestCanceledStartupClosesLifecycle(t *testing.T) {
	c := New(fixedClock{})
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err := c.Run(ctx); !errors.Is(err, context.Canceled) {
		t.Fatalf("canceled startup: %v", err)
	}
	select {
	case <-c.Done():
	default:
		t.Fatal("canceled owner did not close lifecycle")
	}
	if c.Running() {
		t.Fatal("canceled owner became ready")
	}
}
