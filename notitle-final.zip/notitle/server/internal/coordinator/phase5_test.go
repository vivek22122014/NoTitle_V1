package coordinator

import (
	"encoding/json"
	"bytes"
	"errors"
	"fmt"
	"strings"
	"testing"
	"time"

	"notitle/internal/identity"
	rt "notitle/internal/realtime"
	st "notitle/internal/safetytypes"
)

func textPair(t *testing.T) (*liveMemory, rt.Connection, *liveParticipant, rt.Connection, *liveParticipant, time.Time) {
	t.Helper(); m := memoryFixture(); now := rtNow()
	a, pa := attachFixture(t, m, 1, now); b, pb := attachFixture(t, m, 2, now)
	pa.auth.TextEnabled, pb.auth.TextEnabled = true, true
	doCommand(t, m, a, pa, "queue.join", "phase5_join_a", now); doCommand(t, m, b, pb, "queue.join", "phase5_join_b", now)
	drain(a); drain(b)
	return m, a, pa, b, pb, now
}
func chatCommand(p *liveParticipant, m *liveMemory, id, sendID, text string) rt.ClientEnvelope {
	interaction := m.interactions[p.interactionID]
	var encoded bytes.Buffer; encoder := json.NewEncoder(&encoded); encoder.SetEscapeHTML(false); _ = encoder.Encode(rt.ChatSend{ClientSendID: sendID, Text: text}); payload := json.RawMessage(encoded.Bytes())
	return rt.ClientEnvelope{V: 1, ID: id, Type: "chat.send", Generation: p.connectionGeneration, InteractionID: interaction.id, Epoch: interaction.epoch, Payload: payload}
}
func safetyGuard(m *liveMemory, p *liveParticipant, now time.Time) st.Guard {
	principal := identity.Principal{Kind: p.auth.Kind, TokenHash: p.auth.SessionVerifier}
	if p.auth.Kind == identity.KindGuest { principal.Guest = m.guests.byVerifier[p.auth.SessionVerifier].guest } else {
		principal.AccountSession = identity.AccountSession{Account: identity.Account{ID: p.auth.IdentityID, Generation: p.auth.IdentityGeneration, Status: "active", Profile: p.auth.Profile}, Session: identity.SessionRecord{ID: p.auth.SessionID, AccountID: p.auth.IdentityID, AccountGeneration: p.auth.IdentityGeneration, TokenHash: p.auth.SessionVerifier, LastSeenAt: now, AbsoluteExpiresAt: now.Add(time.Hour)}}
	}
	return st.Guard{Principal: principal, Fence: m.fence}
}
func beginRequest(m *liveMemory, p *liveParticipant, block bool) st.BeginReportRequest { interaction := m.interactions[p.interactionID]; return st.BeginReportRequest{Generation: p.connectionGeneration, InteractionID: interaction.id, Epoch: interaction.epoch, Block: block} }

func TestTextSequenceDeliveryAndRetryAcrossConnectionGeneration(t *testing.T) {
	m, a, pa, b, pb, now := textPair(t)
	command := chatCommand(pa, m, "send_1", "stable_send_1", "<script>alert('synthetic')</script> 👨‍👩‍👧")
	if err := m.command(a.Ref, command, now); err != nil { t.Fatal(err) }
	interaction := m.interactions[pa.interactionID]
	if interaction.textSequence != 1 || interaction.messages[0].text != "<script>alert('synthetic')</script> 👨‍👩‍👧" { t.Fatal("text meaning or sequence changed") }
	if err := m.command(a.Ref, command, now); err != nil || len(interaction.messages) != 1 { t.Fatal("exact transport retry was not idempotent") }
	ack := rt.ClientEnvelope{V: 1, ID: "delivery_1", Type: "chat.delivery_ack", Generation: b.Ref.Generation, InteractionID: interaction.id, Epoch: interaction.epoch, Payload: json.RawMessage(`{"server_sequence":1}`)}
	if err := m.command(b.Ref, ack, now); err != nil || !interaction.messages[0].delivered { t.Fatal("recipient delivery ACK missing") }
	drain(a); drain(b)
	view := m.state(pa); m.disconnect(pa, now, "synthetic_network")
	resume := rt.Resume{Token: view.ResumeToken, ServerInstance: view.ServerInstance, Generation: view.Generation, InteractionID: interaction.id, Epoch: interaction.epoch}
	auth := pa.auth; auth.Fence = m.fence
	resumed := m.attach(rt.AttachRequest{Auth: auth, Resume: &resume}, "rotated_reconnect_secret_32_bytes", now)
	if resumed.err != nil { t.Fatal(resumed.err) }
	replayed := 0
	for len(resumed.connection.Events) > 0 { event := <-resumed.connection.Events; if event.Type == "chat.message" { message := event.Payload.(rt.ChatMessage); if !message.Replay || !message.Delivered { t.Fatal("same-epoch replay lost delivery state") }; replayed++ } }
	if replayed != 1 { t.Fatal("bounded reconnect replay missing") }
	command.Generation = resumed.connection.Ref.Generation; command.ID = "retry_new_socket"
	if err := m.command(resumed.connection.Ref, command, now); err != nil || interaction.textSequence != 1 { t.Fatal("new generation duplicate delivered twice") }
	command.ID = "bad_reuse"; command.Payload = json.RawMessage(`{"client_send_id":"stable_send_1","text":"changed"}`)
	if err := m.command(resumed.connection.Ref, command, now); !errors.Is(err, rt.ErrProtocol) { t.Fatal("same send ID accepted changed content") }
	_ = pb
}

func TestTextBoundsFloodOfflineAndFeatureGate(t *testing.T) {
	m, a, pa, b, pb, now := textPair(t)
	for n := 0; n < 8; n++ { command := chatCommand(pa, m, fmt.Sprintf("frame_%d", n), fmt.Sprintf("send_%d", n), "synthetic"); if err := m.command(a.Ref, command, now); err != nil { t.Fatal(err) }; drain(a); drain(b) }
	if err := m.command(a.Ref, chatCommand(pa, m, "flood", "flood_id", "synthetic"), now); !errors.Is(err, rt.ErrRateLimited) { t.Fatal("text burst was not bounded") }
	drain(a); drain(b)
	if err := m.command(a.Ref, chatCommand(pa, m, "refill", "refill_id", strings.Repeat("<", 2000)), now.Add(time.Second)); err != nil { t.Fatal("valid HTML-looking plain text failed due encoder expansion", err) }
	drain(a); drain(b)
	pb.auth.TextEnabled = false
	if err := m.command(a.Ref, chatCommand(pa, m, "gate", "gate_id", "synthetic"), now.Add(2*time.Second)); !errors.Is(err, rt.ErrUnavailable) { t.Fatal("unmoderated peer accepted text") }
	pb.auth.TextEnabled = true; m.disconnect(pb, now.Add(2*time.Second), "network")
	if err := m.command(a.Ref, chatCommand(pa, m, "offline", "offline_id", "synthetic"), now.Add(3*time.Second)); !errors.Is(err, rt.ErrUnavailable) { t.Fatal("text accepted while peer offline") }
}

func TestTextBufferAndDedupeCapacityDoNotForgetOldSendID(t *testing.T) {
	m, a, pa, b, _, now := textPair(t)
	interaction := m.interactions[pa.interactionID]
	for n := 0; n < 40; n++ {
		at := now.Add(time.Duration(n)*time.Second)
		pa.auth.ValidUntil = at.Add(30*time.Second); m.peer(pa).auth.ValidUntil = at.Add(30*time.Second)
		if err := m.command(a.Ref, chatCommand(pa, m, fmt.Sprintf("frame_%d", n), fmt.Sprintf("send_%d", n), strings.Repeat("😀", 1500)), at); err != nil { t.Fatal(err) }
		drain(a); drain(b)
	}
	if len(interaction.messages) > rt.MaxMessages || interaction.messageBytes > rt.MaxMessageBufferBytes { t.Fatal("ordinary message buffer exceeded bound") }
	if _, exists := interaction.sendIDs[chatKey(pa.slot.id, "send_0")]; !exists { t.Fatal("evicted content incorrectly evicted receipt") }
	for len(interaction.sendIDs) < rt.MaxSendDedupe { key := chatKey(pa.slot.id, fmt.Sprintf("reserved_%d", len(interaction.sendIDs))); interaction.sendIDs[key] = chatReceipt{} }
	if err := m.command(a.Ref, chatCommand(pa, m, "cap", "new_after_cap", "synthetic"), now.Add(41*time.Second)); !errors.Is(err, rt.ErrCapacity) { t.Fatal("full dedupe ledger silently forgot IDs") }
	doCommand(t, m, a, pa, "match.end", "end_text", now.Add(41*time.Second))
	if interaction.messages != nil || interaction.sendIDs != nil || interaction.messageBytes != 0 { t.Fatal("normal end retained text or receipts") }
}

func TestReportFreezeSurvivesNextRejectsFabricationAndExpires(t *testing.T) {
	m, a, pa, b, _, now := textPair(t)
	if err := m.command(a.Ref, chatCommand(pa, m, "evidence_frame", "evidence_send", "synthetic evidence"), now); err != nil { t.Fatal(err) }
	drain(a); drain(b)
	guard := safetyGuard(m, pa, now)
	begun := m.applySafety(safetyRequest{op: safetyBegin, guard: guard, begin: beginRequest(m, pa, false)}, now)
	if begun.err != nil || len(begun.draft.Messages) != 1 { t.Fatal("report snapshot was not frozen", begun.err) }
	doCommand(t, m, a, pa, "match.next", "next_after_report", now)
	request := st.SubmitReportRequest{Handle: begun.draft.Handle, SubmissionID: "synthetic_submit_0001", Category: "harassment", Statement: "synthetic statement", SelectedSequences: []uint64{999}}
	guard.Fence = m.fence
	if result := m.applySafety(safetyRequest{op: safetyPrepare, guard: guard, submit: request}, now); !errors.Is(result.err, st.ErrInvalid) { t.Fatal("fabricated sequence accepted") }
	request.SelectedSequences = []uint64{1}
	prepared := m.applySafety(safetyRequest{op: safetyPrepare, guard: guard, submit: request}, now)
	if prepared.err != nil || len(prepared.prepared.Evidence) != 1 || prepared.prepared.Evidence[0].Text != "synthetic evidence" { t.Fatal("peer Next destroyed user snapshot", prepared.err) }
	completion := st.ReportCompletion{Handle: request.Handle, SubmissionID: request.SubmissionID, Persisted: true, CaseRef: "synthetic_case_ref", Receipt: &st.ReportReceipt{CaseRef: "synthetic_case_ref", SubmittedAt: now}}
	if result := m.applySafety(safetyRequest{op: safetyFinish, guard: guard, completion: completion}, now); result.err != nil { t.Fatal(result.err) }
	guard.Fence = m.fence
	if result := m.applySafety(safetyRequest{op: safetyPrepare, guard: guard, submit: request}, now); result.err != nil { t.Fatal("successful submission could not retry idempotently", result.err) }
	m.expireSafety(now.Add(st.ReportDraftTTL))
	if len(m.safety.drafts) != 0 { t.Fatal("temporary evidence survived hard expiry") }
}

func TestReportAndBlockFailureStopsInteractionAndBlocksReciprocally(t *testing.T) {
	m, a, pa, b, pb, now := textPair(t)
	if err := m.command(a.Ref, chatCommand(pa, m, "evidence_frame", "evidence_send", "synthetic evidence"), now); err != nil { t.Fatal(err) }; drain(a); drain(b)
	guard := safetyGuard(m, pa, now)
	result := m.applySafety(safetyRequest{op: safetyBegin, guard: guard, begin: beginRequest(m, pa, true)}, now)
	if result.err != nil || !result.draft.Blocked || pa.interactionID != "" || pb.interactionID != "" { t.Fatal("combined report/block did not end atomically", result.err) }
	if len(result.draft.Messages) != 1 || !m.blocked(pa, pb) || !m.blocked(pb, pa) { t.Fatal("evidence or reciprocal restriction lost") }
	guard.Fence = m.fence
	request := st.SubmitReportRequest{Handle: result.draft.Handle, SubmissionID: "synthetic_submit_0001", Category: "threats", Statement: "synthetic", SelectedSequences: []uint64{1}}
	prepared := m.applySafety(safetyRequest{op: safetyPrepare, guard: guard, submit: request}, now)
	if prepared.err != nil || prepared.prepared.Block == nil { t.Fatal(prepared.err) }
	completion := st.ReportCompletion{Handle: request.Handle, SubmissionID: request.SubmissionID, Persisted: false}
	if result := m.applySafety(safetyRequest{op: safetyFinish, guard: guard, completion: completion}, now); result.err != nil { t.Fatal(result.err) }
	if !m.blocked(pa, pb) { t.Fatal("failed storage released local block") }
	doCommand(t, m, a, pa, "queue.join", "blocked_join_a", now.Add(5*time.Second)); doCommand(t, m, b, pb, "queue.join", "blocked_join_b", now.Add(5*time.Second))
	if len(m.interactions) != 0 { t.Fatal("blocked pair rematched") }
	m.expireSafety(now.Add(st.ReportDraftTTL))
	if len(m.safety.drafts) != 0 || !m.blocked(pa, pb) { t.Fatal("snapshot expiry released restriction") }
}

func TestEndedReferencesAreOwnerScopedMetadataOnly(t *testing.T) {
	m, a, pa, _, pb, now := textPair(t)
	doCommand(t, m, a, pa, "match.end", "ended_metadata", now)
	if pa.endedRef == "" || pb.endedRef == "" || pa.endedRef == pb.endedRef { t.Fatal("scoped metadata references absent") }
	guard := safetyGuard(m, pa, now)
	if result := m.applySafety(safetyRequest{op: safetyBegin, guard: guard, begin: st.BeginReportRequest{EndedRef: pb.endedRef}}, now); !errors.Is(result.err, st.ErrExpired) { t.Fatal("another participant reference accepted") }
	result := m.applySafety(safetyRequest{op: safetyBegin, guard: guard, begin: st.BeginReportRequest{EndedRef: pa.endedRef}}, now)
	if result.err != nil || !result.draft.MetadataOnly || len(result.draft.Messages) != 0 { t.Fatal("ended report fabricated transcript", result.err) }
	m.expireSafety(now.Add(st.EndedReferenceTTL))
	if len(m.safety.ended) != 0 || pa.endedRef != "" { t.Fatal("metadata reference survived ten minutes") }
}

func TestBlockPromotionAndUnblockLeaseFence(t *testing.T) {
	m, _, pa, _, pb, now := textPair(t)
	target := &endedReference{ownerSlot: pa.slot.id, peerSlot: pb.slot.id, reporter: slotSubject(pa.slot), subject: slotSubject(pb.slot)}
	block, err := m.blockTarget(target, now, ""); if err != nil { t.Fatal(err) }
	claims := m.claimPromotions(1, now)
	if len(claims) != 1 { t.Fatal("durable pending block not claimed") }
	guard := safetyGuard(m, pa, now)
	if result := m.applySafety(safetyRequest{op: safetyPrepareUnblock, guard: guard, ref: block.mutation.Ref}, now); !errors.Is(result.err, st.ErrBusy) { t.Fatal("unblock raced an active storage write") }
	fence := m.fence
	if err := m.finishPromotion(claims[0].LeaseID, true); err != nil || !block.durable || m.fence <= fence { t.Fatal("durable promotion did not publish fence") }
	guard.Fence = m.fence
	unblock := m.applySafety(safetyRequest{op: safetyPrepareUnblock, guard: guard, ref: block.mutation.Ref}, now)
	if unblock.err != nil { t.Fatal(unblock.err) }
	if len(m.claimPromotions(1, now)) != 0 || !m.blocked(pa, pb) { t.Fatal("unblock lease failed to hold restriction") }
	if err := m.completeUnblock(guard, unblock.block.LeaseID, true); err != nil || m.blocked(pa, pb) { t.Fatal("successful durable removal retained own block") }
	if len(pa.slot.carry.acceptedLinks) != 0 { t.Fatal("unblocking recreated relationships") }
}

func TestGuestBlockUpgradeDuringReportWriteRequiresLaterPromotion(t *testing.T) {
	m := memoryFixture(); now := rtNow()
	var connections []rt.Connection; var participants []*liveParticipant
	for n := 1; n <= 2; n++ {
		guest := guestFixture(n, now)
		if result := m.guests.apply(guestRequest{op: guestCreate, guest: guest}, now); result.err != nil { t.Fatal(result.err) }
		auth := rt.AuthSnapshot{Kind: identity.KindGuest, IdentityID: guest.ID, IdentityGeneration: guest.Generation, SessionVerifier: guest.Verifier, Profile: guest.Profile, Preferences: rt.DefaultPreferences(), AuthorizedAt: now, ValidUntil: now.Add(30*time.Second), TextEnabled: true}
		result := m.attach(rt.AttachRequest{Auth: auth}, fmt.Sprintf("guest_upgrade_resume_secret_%08d", n), now)
		if result.err != nil { t.Fatal(result.err) }
		connections = append(connections, result.connection); participants = append(participants, m.byConnection(result.connection.Ref))
	}
	pa, pb := participants[0], participants[1]
	doCommand(t, m, connections[0], pa, "queue.join", "guest_join_a", now); doCommand(t, m, connections[1], pb, "queue.join", "guest_join_b", now)
	guard := safetyGuard(m, pa, now)
	begun := m.applySafety(safetyRequest{op: safetyBegin, guard: guard, begin: beginRequest(m, pa, true)}, now)
	if begun.err != nil { t.Fatal(begun.err) }
	guard.Fence = m.fence
	request := st.SubmitReportRequest{Handle: begun.draft.Handle, SubmissionID: "guest_upgrade_submission", Category: "spam", Statement: "synthetic statement", SelectedSequences: []uint64{}}
	prepared := m.applySafety(safetyRequest{op: safetyPrepare, guard: guard, submit: request}, now)
	if prepared.err != nil || prepared.prepared.Block == nil { t.Fatal(prepared.err) }
	block := m.safety.blocks[prepared.prepared.Block.Ref]
	for n, p := range participants {
		delete(m.guests.byVerifier, p.auth.SessionVerifier)
		p.slot.accountID = fmt.Sprintf("upgraded_account_%08d", n); p.slot.accountGeneration = 1; p.slot.guestID = ""
		m.promoteSafetySubject(p.slot.id, now)
	}
	// The original write only knew guest endpoints and did not insert a durable
	// account block. Its internal completion still works after cookie rotation.
	completion := st.ReportCompletion{Handle: request.Handle, SubmissionID: request.SubmissionID, Persisted: true, BlockVersion: prepared.prepared.Block.Version, DurableBlockPersisted: false}
	if result := m.applySafety(safetyRequest{op: safetyFinish, guard: guard, completion: completion}, now); result.err != nil { t.Fatal("old authorized completion could not settle after upgrade", result.err) }
	if block.durable { t.Fatal("guest report write falsely marked upgraded block durable") }
	claims := m.claimPromotions(1, now)
	if len(claims) != 1 || claims[0].Blocker.Kind != identity.KindAccount || claims[0].Blocked.Kind != identity.KindAccount { t.Fatal("upgraded block was not promoted") }
	if err := m.finishPromotion(claims[0].LeaseID, true); err != nil || !block.durable { t.Fatal("durable account promotion failed") }
}

func TestRestrictionOnOriginalGuestCaseFollowsLiveUpgrade(t *testing.T) {
	m := memoryFixture(); now := rtNow()
	guest := guestFixture(1, now)
	if result := m.guests.apply(guestRequest{op: guestCreate, guest: guest}, now); result.err != nil { t.Fatal(result.err) }
	slot := m.guests.slots[guest.ID]
	slot.accountID = "upgraded_account_0001"; slot.accountGeneration = 1; slot.guestID = ""
	until := now.Add(time.Hour)
	result := m.applySafety(safetyRequest{op: safetyTimedRestrict, subject: st.Subject{Kind: identity.KindGuest, ID: guest.ID, Generation: 1}, until: until}, now)
	if result.err != nil || !m.subjectRestricted(identity.KindAccount, slot.accountID) || len(slot.carry.restrictions) == 0 { t.Fatal("case restriction missed in-session upgraded identity") }
	claims := m.claimRestrictionPromotions(4, now)
	if len(claims) != 1 || claims[0].Subject.ID != slot.accountID || !claims[0].Until.Equal(until) { t.Fatal("restriction persistence lost identity or original expiry") }
	if err := m.finishRestrictionPromotion(claims[0].LeaseID, true); err != nil || len(m.safety.restrictionPromotions) != 0 { t.Fatal("restriction promotion did not settle") }
}

func TestHandoffFenceFlushCapturesSafetyBeforeRealtimeAdmission(t *testing.T) {
	m, _, pa, _, pb, now := textPair(t)
	target := &endedReference{ownerSlot: pa.slot.id, peerSlot: pb.slot.id, reporter: slotSubject(pa.slot), subject: slotSubject(pb.slot)}
	block, err := m.blockTarget(target, now, ""); if err != nil { t.Fatal(err) }
	m.queueHandoffFinalization(pa.auth.IdentityID, pa.auth.IdentityGeneration)
	auth := pa.auth; auth.Fence = m.fence
	if err := m.validateAuth(auth, now); !errors.Is(err, rt.ErrUnavailable) { t.Fatal("handoff pending account acquired realtime authority") }
	claims := m.claimHandoffFinalizations(2, now)
	if len(claims) != 1 || len(claims[0].Blocks) != 1 || claims[0].Blocks[0].Ref != block.mutation.Ref { t.Fatal("handoff flush omitted existing block") }
	guard := safetyGuard(m, pa, now)
	if result := m.applySafety(safetyRequest{op: safetyPrepareUnblock, guard: guard, ref: block.mutation.Ref}, now); !errors.Is(result.err, st.ErrBusy) { t.Fatal("unblock bypassed handoff persistence lease") }
	if err := m.finishHandoffFinalization(claims[0].LeaseID, false); err != nil { t.Fatal(err) }
	if len(m.safety.handoffs) != 1 || block.durable { t.Fatal("failed flush cleared durable fence intent") }
	claims = m.claimHandoffFinalizations(2, now)
	if err := m.finishHandoffFinalization(claims[0].LeaseID, true); err != nil { t.Fatal(err) }
	if len(m.safety.handoffs) != 0 || !block.durable { t.Fatal("successful flush did not publish durable safety") }
	auth.Fence = m.fence
	if err := m.validateAuth(auth, now); err != nil { t.Fatal("settled handoff remained unavailable", err) }
}
