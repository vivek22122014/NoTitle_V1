package coordinator

import (
    "context"
    "time"

    at "notitle/internal/audiotypes"
    rt "notitle/internal/realtime"
)

// ChangeAdmission is used only by trusted deployment/operator controls. Its
// state transition is serialized with matching, safety and call ownership.
func(c *Coordinator)ChangeAdmission(ctx context.Context,closed bool,deadline time.Time)error {
    _,err:=c.realtimeCommand(ctx,realtimeRequest{op:opAdmission,maintenance:closed,drainDeadline:deadline})
    return err
}

func admissionCommand(kind string)bool {
    switch kind {case "queue.join","friend.invite","friend.accept_invite","call.request","call.accept":return true}
    return false
}

func(m *liveMemory)changeAdmission(closed bool,deadline,now time.Time)error {
    if m.stopped(now){return rt.ErrUnavailable}
    if !closed {
        m.maintainAdmission(now)
        // Do not cancel an announced active drain halfway through. It must
        // finish and revoke media before an operator can reopen admission.
        if m.maintenance&&now.Before(m.drainDeadline){return rt.ErrUnavailable}
        active,cleanup:=m.audioCounts();if active!=0||cleanup!=0{return rt.ErrUnavailable}
        m.maintenance=false;m.drainDeadline=time.Time{}
        return nil
    }
    if deadline.IsZero()||deadline.Before(now.Add(-time.Second))&&!(m.maintenance&&deadline.Equal(m.drainDeadline))||deadline.After(now.Add(120*time.Second)){return rt.ErrProtocol}
    if m.maintenance&&!m.drainDeadline.IsZero()&&deadline.After(m.drainDeadline){deadline=m.drainDeadline}
    m.maintenance=true;m.drainDeadline=deadline
    // A new call needs consent from both people; only already accepted calls
    // can continue their negotiation/media during the drain window.
    for _,call:=range m.audio.calls{if call.state==at.Requested||call.state==at.Ringing{m.endCall(call,now,"server_restart")}}
    for _,invite:=range m.friends.invitations{m.closeInvitation(invite,"server_restart")}
    for _,p:=range m.participants {
        if p.state==rt.Waiting{m.unqueue(p);p.state=rt.Idle;m.emit(p,"queue.paused",m.stateReason(p,"server_restart"),"")}
        m.emit(p,"server.draining",rt.MaintenanceView{Deadline:deadline},"")
    }
    m.maintainAdmission(now)
    return nil
}

func(m *liveMemory)maintainAdmission(now time.Time) {
    if !m.maintenance||now.Before(m.drainDeadline){return}
    for _,p:=range m.participants{m.terminate(p,now,"server_restart")}
}
