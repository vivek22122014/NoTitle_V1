package coordinator

import (
 "context"
 "time"
 "notitle/internal/identity"
 rt "notitle/internal/realtime"
)

const premiumMutationCapacity=1024
type premiumMemory struct {
 enabled bool
 mutations map[string]string
 jobs map[string]*premiumUsage
}
type premiumUsage struct {
 job rt.PremiumUsageJob
 slotID string
 generation uint64
 retryAt time.Time
}
func newPremiumMemory()*premiumMemory{return &premiumMemory{mutations:make(map[string]string),jobs:make(map[string]*premiumUsage)}}
func isPremiumOperation(op uint8)bool{return op>=opPremiumBegin&&op<=opPremiumUsageFinish}
func(c *Coordinator)EnablePremium(){if !c.started.Load(){c.premiumEnabled.Store(true)}}
var _ rt.PremiumMutationOwner=(*Coordinator)(nil)
var _ rt.PremiumUsageOwner=(*Coordinator)(nil)
func(c *Coordinator)BeginPremiumMutation(ctx context.Context,accountID string)(string,error){r,e:=c.realtimeCommand(ctx,realtimeRequest{op:opPremiumBegin,identityID:accountID});return r.premiumToken,e}
func(c *Coordinator)FinishPremiumMutation(ctx context.Context,accountID,token string,e rt.Entitlement)error{_,err:=c.realtimeCommand(ctx,realtimeRequest{op:opPremiumFinish,identityID:accountID,premiumToken:token,entitlement:e});return err}
func(c *Coordinator)ClaimPremiumUsageJobs(ctx context.Context,limit int)([]rt.PremiumUsageJob,error){r,e:=c.realtimeCommand(ctx,realtimeRequest{op:opPremiumClaim,premiumLimit:limit});return r.premiumJobs,e}
func(c *Coordinator)FinishPremiumUsage(ctx context.Context,id string,result rt.PremiumUsageResult)(bool,error){r,e:=c.realtimeCommand(ctx,realtimeRequest{op:opPremiumUsageFinish,premiumToken:id,premiumUsage:result});return r.published,e}

func validPremiumProjection(e rt.Entitlement)bool{
 if e.Version<1{return false}
 if !e.Premium{return true}
 return !e.ExpiresAt.IsZero()&&e.UsageLotID!=""&&!e.UsageUntil.IsZero()&&!e.UsageUntil.After(e.ExpiresAt)
}
func(m *liveMemory)premiumBlocked(accountID string)bool{return m.premium.mutations[accountID]!=""}
func(m *liveMemory)applyPremium(req realtimeRequest,now time.Time)realtimeResult{
 switch req.op{
 case opPremiumBegin:
  if !m.premium.enabled||m.latched||!validInternalID(req.identityID){return realtimeResult{err:rt.ErrUnavailable}}
  if m.premiumBlocked(req.identityID)||len(m.premium.mutations)>=premiumMutationCapacity{return realtimeResult{err:rt.ErrUnavailable}}
  token:=m.opaque("premium_mutation");m.premium.mutations[req.identityID]=token;m.fence++
  for _,p:=range m.participants{if p.auth.Kind!=identity.KindAccount||p.auth.IdentityID!=req.identityID{continue};m.cancelPremiumUsage(p)
   // Keep the search and its age, but entry() freezes strict eligibility.
   // A duplicate capture or money-only refund must not require a new search.
   // Publication pauses only if the authoritative entitlement was lost.
   m.emit(p,"premium.changed",m.stateReason(p,"premium_update_pending"),"")
  }
  return realtimeResult{premiumToken:token}
 case opPremiumFinish:
  if req.premiumToken==""||m.premium.mutations[req.identityID]!=req.premiumToken||!validPremiumProjection(req.entitlement){return realtimeResult{err:rt.ErrUnavailable}}
  for _,p:=range m.participants{if p.auth.Kind==identity.KindAccount&&p.auth.IdentityID==req.identityID&&req.entitlement.Version<p.auth.Entitlement.Version{return realtimeResult{err:rt.ErrUnavailable}}}
  delete(m.premium.mutations,req.identityID);m.fence++
  for _,p:=range m.participants{if p.auth.Kind!=identity.KindAccount||p.auth.IdentityID!=req.identityID{continue};m.installPremium(p,req.entitlement,now,true)}
  m.match(now);return realtimeResult{}
 case opPremiumClaim:
  if !m.premium.enabled||m.latched||m.outage{return realtimeResult{}}
  limit:=req.premiumLimit;if limit<1||limit>16{limit=16};jobs:=make([]rt.PremiumUsageJob,0,limit)
  for id,usage:=range m.premium.jobs{
   if !m.validPremiumJob(usage,now){delete(m.premium.jobs,id);if p:=m.participants[usage.slotID];p!=nil&&p.premiumJob==id{p.premiumJob=""};continue}
   if now.Before(usage.retryAt){continue};usage.retryAt=now.Add(5*time.Second);job:=usage.job;job.Guard.Now=now;jobs=append(jobs,job);if len(jobs)>=limit{break}
  };return realtimeResult{premiumJobs:jobs}
 case opPremiumUsageFinish:
  usage:=m.premium.jobs[req.premiumToken];if usage==nil{return realtimeResult{}}
  p:=m.participants[usage.slotID]
  if !m.validPremiumJob(usage,now){delete(m.premium.jobs,req.premiumToken);if p!=nil&&p.premiumJob==req.premiumToken{p.premiumJob=""};return realtimeResult{}}
  if !req.premiumUsage.Trusted||!validPremiumProjection(req.premiumUsage.Entitlement){usage.retryAt=now.Add(time.Second);return realtimeResult{}}
  e:=req.premiumUsage.Entitlement;if e.Version<p.auth.Entitlement.Version{return realtimeResult{}}
  m.cancelPremiumUsage(p);m.installPremium(p,e,now,false);m.match(now);return realtimeResult{published:true}
 }
 return realtimeResult{err:rt.ErrProtocol}
}
func(m *liveMemory)cancelPremiumUsage(p *liveParticipant){if p.premiumJob!=""{delete(m.premium.jobs,p.premiumJob);p.premiumJob=""}}
func(m *liveMemory)validPremiumJob(usage *premiumUsage,now time.Time)bool{
 p:=m.participants[usage.slotID]
 return p!=nil&&p.state==rt.Waiting&&p.connection!=nil&&p.connectionGeneration==usage.generation&&p.premiumJob==usage.job.ID&&
  p.auth.Kind==identity.KindAccount&&p.auth.IdentityID==usage.job.Guard.AccountID&&p.auth.IdentityGeneration==usage.job.Guard.AccountGeneration&&
  p.auth.SessionID==usage.job.Guard.SessionID&&p.auth.SessionVerifier==usage.job.Guard.TokenHash&&now.Before(p.auth.ValidUntil)&&
  p.auth.Entitlement.Version==usage.job.EntitlementVersion&&p.auth.Entitlement.UsageLotID==usage.job.LotID&&
  !m.premiumBlocked(p.auth.IdentityID)&&rt.UsesPaidMatching(p.queueAuth)&&p.auth.Entitlement.Active(now)
}
func(m *liveMemory)ensurePremiumUsage(p *liveParticipant,now time.Time){
 if !m.premium.enabled||p.state!=rt.Waiting||p.connection==nil||p.auth.Kind!=identity.KindAccount||!now.Before(p.auth.ValidUntil)||m.premiumBlocked(p.auth.IdentityID){m.cancelPremiumUsage(p);return}
 if !p.auth.Entitlement.Active(now)||!rt.UsesPaidMatching(p.queueAuth)||p.auth.Entitlement.PaidUseAuthorized(now){m.cancelPremiumUsage(p);return}
 if p.premiumJob!=""{if job:=m.premium.jobs[p.premiumJob];job!=nil&&m.validPremiumJob(job,now){return};m.cancelPremiumUsage(p)}
 if !validPremiumProjection(p.auth.Entitlement){return}
 id:=m.opaque("premium_use");p.premiumJob=id;e:=p.auth.Entitlement
 m.premium.jobs[id]=&premiumUsage{job:rt.PremiumUsageJob{ID:id,Guard:identity.Guard{AccountID:p.auth.IdentityID,AccountGeneration:p.auth.IdentityGeneration,SessionID:p.auth.SessionID,TokenHash:p.auth.SessionVerifier,Now:now},EntitlementVersion:e.Version,LotID:e.UsageLotID},slotID:p.slot.id,generation:p.connectionGeneration}
}
func(m *liveMemory)installPremium(p *liveParticipant,e rt.Entitlement,now time.Time,notify bool){
 old:=p.auth.Entitlement;p.auth.Entitlement=e
 if e.Active(now){p.expiryNotified=false};m.reindex(p)
 if p.state==rt.Waiting&&p.queueAuth.Preferences.Gender!=rt.Everyone&&!e.Active(now){m.pause(p,"premium_expired")}
 if notify||old.Premium!=e.Premium||old.Version!=e.Version||!old.ExpiresAt.Equal(e.ExpiresAt){reason:="premium_changed";if p.state==rt.Waiting&&p.queueAuth.Preferences.Gender==rt.Everyone&&!e.Active(now){reason="premium_changed_everyone_continues"};m.emit(p,"premium.changed",m.stateReason(p,reason),"")}
 m.ensurePremiumUsage(p,now)
}
func(m *liveMemory)premiumState(p *liveParticipant,state *rt.StateSnapshot,now time.Time){
 active:=p.auth.Kind==identity.KindAccount&&p.auth.Entitlement.Active(now)&&!m.premiumBlocked(p.auth.IdentityID)
 state.PremiumActive=active
 if p.auth.Entitlement.Premium&&!p.auth.Entitlement.ExpiresAt.IsZero(){expiry:=p.auth.Entitlement.ExpiresAt;state.PremiumExpiresAt=&expiry}
 state.RequiresEveryoneConfirmation=p.auth.Preferences.Gender!=rt.Everyone&&!active&&!p.everyoneOverride
}
func(m *liveMemory)maintainPremium(now time.Time){
 for _,p:=range m.participants{
  if p.state==rt.Waiting&&p.queueAuth.Preferences.Gender!=rt.Everyone&&!p.auth.Entitlement.Active(now){m.pause(p,"premium_expired")}
  if !p.expiryNotified&&p.auth.Entitlement.Premium&&!p.auth.Entitlement.Active(now){p.expiryNotified=true;reason:="premium_expired";if p.state==rt.Waiting{reason="premium_expired_everyone_continues"};m.emit(p,"premium.expired",m.stateReason(p,reason),"")}
  m.ensurePremiumUsage(p,now)
 }
}
