package coordinator

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"sort"
	"time"

	"notitle/internal/identity"
	ft "notitle/internal/friendtypes"
	st "notitle/internal/safetytypes"
)

type safetyOperation uint8
const (
	safetyBegin safetyOperation = iota
	safetyPrepare
	safetyFinish
	safetyBlock
	safetyListBlocks
	safetyPrepareUnblock
	safetyFinishUnblock
	safetyPrepareDurableUnblock
	safetyRestrict
	safetyTimedRestrict
	safetyClaimPromotions
	safetyFinishPromotion
	safetyClaimRestrictionPromotions
	safetyFinishRestrictionPromotion
	safetyClaimHandoffs
	safetyFinishHandoff
	safetyResolveSubject
)
type safetyRequest struct {
	ctx context.Context
	op safetyOperation
	guard st.Guard
	begin st.BeginReportRequest
	submit st.SubmitReportRequest
	completion st.ReportCompletion
	block st.BlockRequest
	mutation st.BlockMutation
	subject st.Subject
	ref string
	flag bool
	limit int
	until time.Time
	reply chan safetyResult
}
type safetyResult struct { subject st.Subject; draft st.DraftView; prepared st.PreparedReport; block st.BlockMutation; blocks []st.BlockView; promotions []st.BlockMutation; restrictionPromotions []st.RestrictionMutation; handoffs []st.HandoffFinalization; err error }
type reportDraft struct {
	handle string
	ownerSlot string
	peerSlot string
	reporter st.Subject
	subject st.Subject
	interactionID string
	epoch uint64
	startedAt time.Time
 call *st.CallMetadata
	endedAt *time.Time
	expiresAt time.Time
	evidence []st.Evidence
	blockRef string
	submissionID string
	submissionDigest [32]byte
	completed bool
	inFlight bool
	completionToken identity.Verifier
	receipt *st.ReportReceipt
}
type endedReference struct {
	ownerSlot string
	peerSlot string
	reporter st.Subject
	subject st.Subject
	interactionID string
	epoch uint64
	startedAt time.Time
 call *st.CallMetadata
	endedAt time.Time
	expiresAt time.Time
}
type localBlock struct {
	mutation st.BlockMutation
	blockerSlot string
	blockedSlot string
	displayName string
	durable bool
	reportHandle string
	deleting bool
	leaseStarted time.Time
	leaseMutation st.BlockMutation
	leaseToken identity.Verifier
}
type restrictionPromotion struct { mutation st.RestrictionMutation; leasedUntil time.Time; leasedDecision time.Time }
type handoffFinalization struct { mutation st.HandoffFinalization }
type safetyMemory struct {
	handoffs map[string]*handoffFinalization
	restrictionPromotions map[string]*restrictionPromotion
	drafts map[string]*reportDraft
	ended map[string]*endedReference
	blocks map[string]*localBlock
	edges map[string]map[string]st.Subject
	restrictionDecided map[string]time.Time
	restrictions map[string]time.Time
}
func newSafetyMemory() *safetyMemory { return &safetyMemory{handoffs: make(map[string]*handoffFinalization), restrictionPromotions: make(map[string]*restrictionPromotion), drafts: make(map[string]*reportDraft), ended: make(map[string]*endedReference), blocks: make(map[string]*localBlock), edges: make(map[string]map[string]st.Subject), restrictionDecided: make(map[string]time.Time), restrictions: make(map[string]time.Time)} }
var _ st.Owner = (*Coordinator)(nil)

func (c *Coordinator) safetyCommand(ctx context.Context, req safetyRequest) (safetyResult, error) {
	if err := ctx.Err(); err != nil { return safetyResult{}, err }
	if !c.running.Load() { return safetyResult{}, ErrNotRunning }
	req.ctx = ctx; req.reply = make(chan safetyResult, 1)
	req.submit.SelectedSequences = append([]uint64(nil), req.submit.SelectedSequences...)
	req.guard.Principal.Guest = cloneGuest(req.guard.Principal.Guest)
	req.guard.Principal.AccountSession.Account.Profile = cloneProfile(req.guard.Principal.AccountSession.Account.Profile)
	select { case <-ctx.Done(): return safetyResult{}, ctx.Err(); case <-c.done: return safetyResult{}, ErrNotRunning; case c.safetyRequests <- req: default: return safetyResult{}, ErrOverloaded }
	select { case <-ctx.Done(): return safetyResult{}, ctx.Err(); case <-c.done: return safetyResult{}, ErrNotRunning; case result := <-req.reply: return result, result.err }
}
func (c *Coordinator) applySafety(guests *guestMemory, live *liveMemory, req safetyRequest) {
	if err := req.ctx.Err(); err != nil { req.reply <- safetyResult{err: err}; return }
	now := c.clock.Now(); guests.expire(now); live.now = now; live.expireSafety(now)
	if c.failClosed.Load() { live.latchClosed(now) }
	req.reply <- live.applySafety(req, now)
	live.maintain(now)
}
func (c *Coordinator) BeginReport(ctx context.Context, guard st.Guard, request st.BeginReportRequest) (st.DraftView, error) { result, err := c.safetyCommand(ctx, safetyRequest{op: safetyBegin, guard: guard, begin: request}); return result.draft, err }
func (c *Coordinator) PrepareReport(ctx context.Context, guard st.Guard, request st.SubmitReportRequest) (st.PreparedReport, error) { result, err := c.safetyCommand(ctx, safetyRequest{op: safetyPrepare, guard: guard, submit: request}); return result.prepared, err }
func (c *Coordinator) FinishReport(ctx context.Context, guard st.Guard, completion st.ReportCompletion) error { _, err := c.safetyCommand(ctx, safetyRequest{op: safetyFinish, guard: guard, completion: completion}); return err }
func (c *Coordinator) BlockPeer(ctx context.Context, guard st.Guard, request st.BlockRequest) (st.BlockMutation, error) { result, err := c.safetyCommand(ctx, safetyRequest{op: safetyBlock, guard: guard, block: request}); return result.block, err }
func (c *Coordinator) ListLocalBlocks(ctx context.Context, guard st.Guard) ([]st.BlockView, error) { result, err := c.safetyCommand(ctx, safetyRequest{op: safetyListBlocks, guard: guard}); return result.blocks, err }
func (c *Coordinator) PrepareUnblock(ctx context.Context, guard st.Guard, ref string) (st.BlockMutation, error) { result, err := c.safetyCommand(ctx, safetyRequest{op: safetyPrepareUnblock, guard: guard, ref: ref}); return result.block, err }
func (c *Coordinator) PrepareDurableUnblock(ctx context.Context, guard st.Guard, block st.BlockMutation) (st.BlockMutation, error) { result, err := c.safetyCommand(ctx, safetyRequest{op: safetyPrepareDurableUnblock, guard: guard, mutation: block}); return result.block, err }
func (c *Coordinator) FinishUnblock(ctx context.Context, guard st.Guard, leaseID string, persisted bool) error { _, err := c.safetyCommand(ctx, safetyRequest{op: safetyFinishUnblock, guard: guard, ref: leaseID, flag: persisted}); return err }
func (c *Coordinator) ApplyRestriction(ctx context.Context, subject st.Subject, restricted bool) error { _, err := c.safetyCommand(ctx, safetyRequest{op: safetyRestrict, subject: subject, flag: restricted}); return err }
func (c *Coordinator) ApplyTimedRestriction(ctx context.Context, subject st.Subject, until time.Time) error { _, err := c.safetyCommand(ctx, safetyRequest{op: safetyTimedRestrict, subject: subject, until: until}); return err }
func (c *Coordinator) ResolveSafetySubject(ctx context.Context, subject st.Subject) (st.Subject, error) { result, err := c.safetyCommand(ctx, safetyRequest{op: safetyResolveSubject, subject: subject}); return result.subject, err }
func (c *Coordinator) ClaimHandoffFinalizations(ctx context.Context, limit int) ([]st.HandoffFinalization, error) { result, err := c.safetyCommand(ctx, safetyRequest{op: safetyClaimHandoffs, limit: limit}); return result.handoffs, err }
func (c *Coordinator) FinishHandoffFinalization(ctx context.Context, leaseID string, persisted bool) error { _, err := c.safetyCommand(ctx, safetyRequest{op: safetyFinishHandoff, ref: leaseID, flag: persisted}); return err }
func (c *Coordinator) ClaimRestrictionPromotions(ctx context.Context, limit int) ([]st.RestrictionMutation, error) { result, err := c.safetyCommand(ctx, safetyRequest{op: safetyClaimRestrictionPromotions, limit: limit}); return result.restrictionPromotions, err }
func (c *Coordinator) FinishRestrictionPromotion(ctx context.Context, leaseID string, persisted bool) error { _, err := c.safetyCommand(ctx, safetyRequest{op: safetyFinishRestrictionPromotion, ref: leaseID, flag: persisted}); return err }
func (c *Coordinator) ClaimBlockPromotions(ctx context.Context, limit int) ([]st.BlockMutation, error) { result, err := c.safetyCommand(ctx, safetyRequest{op: safetyClaimPromotions, limit: limit}); return result.promotions, err }
func (c *Coordinator) FinishBlockPromotion(ctx context.Context, leaseID string, persisted bool) error { _, err := c.safetyCommand(ctx, safetyRequest{op: safetyFinishPromotion, ref: leaseID, flag: persisted}); return err }

func subjectKey(kind identity.Kind, id string) string { return string(kind) + ":" + id }
func (m *liveMemory) subjectRestricted(kind identity.Kind, id string) bool { _, exists := m.safety.restrictions[subjectKey(kind, id)]; return exists }
func slotSubject(slot *participantSlot) st.Subject { if slot.accountID != "" { return st.Subject{Kind: identity.KindAccount, ID: slot.accountID, Generation: slot.accountGeneration} }; return st.Subject{Kind: identity.KindGuest, ID: slot.guestID, Generation: slot.generation} }
func sameSubject(a, b st.Subject) bool { return a.Kind == b.Kind && a.ID == b.ID }

func (m *liveMemory) safetyPrincipal(guard st.Guard, now time.Time, completion bool) (st.Subject, *participantSlot, error) {
	if !completion && guard.Fence != m.fence { return st.Subject{}, nil, st.ErrUnavailable }
	p := guard.Principal
	if p.TokenHash == (identity.Verifier{}) { return st.Subject{}, nil, st.ErrUnauthorized }
	if p.Kind == identity.KindGuest {
		entry := m.guests.byVerifier[p.TokenHash]
		if entry == nil || entry.reservation != nil || entry.guest.ID != p.Guest.ID || entry.guest.Generation != p.Guest.Generation { return st.Subject{}, nil, st.ErrUnauthorized }
		return slotSubject(entry.slot), entry.slot, nil
	}
	if p.Kind != identity.KindAccount { return st.Subject{}, nil, st.ErrUnauthorized }
	a, session := p.AccountSession.Account, p.AccountSession.Session
	if !validInternalID(a.ID) || a.Status != "active" || a.Generation < 1 || session.AccountID != a.ID || session.AccountGeneration != a.Generation || session.TokenHash != p.TokenHash || !validInternalID(session.ID) || !now.Before(session.AbsoluteExpiresAt) || !now.Before(session.LastSeenAt.Add(identity.SessionIdleTTL)) { return st.Subject{}, nil, st.ErrUnauthorized }
	subject := st.Subject{Kind: identity.KindAccount, ID: a.ID, Generation: a.Generation}
	for _, slot := range m.guests.slots { if slot.accountID == a.ID { if slot.accountGeneration != a.Generation { return st.Subject{}, nil, st.ErrUnauthorized }; return subject, slot, nil } }
	return subject, nil, nil
}

func (m *liveMemory) applySafety(req safetyRequest, now time.Time) safetyResult {
	if req.op == safetyResolveSubject { if !validInternalID(req.subject.ID) || (req.subject.Kind != identity.KindAccount && req.subject.Kind != identity.KindGuest) { return safetyResult{err: st.ErrInvalid} }; return safetyResult{subject: m.currentSubject(req.subject)} }
	if req.op == safetyClaimHandoffs { return safetyResult{handoffs: m.claimHandoffFinalizations(req.limit, now)} }
	if req.op == safetyFinishHandoff { return safetyResult{err: m.finishHandoffFinalization(req.ref, req.flag)} }
	if req.op == safetyClaimRestrictionPromotions { return safetyResult{restrictionPromotions: m.claimRestrictionPromotions(req.limit, now)} }
    if req.op == safetyFinishRestrictionPromotion { return safetyResult{err: m.finishRestrictionPromotion(req.ref, req.flag)} }
    if req.op == safetyTimedRestrict {
        original := req.subject
        req.subject = m.currentSubject(req.subject)
        if req.until.IsZero() || !now.Before(req.until) { err := m.restrictSubject(req.subject, false, now); if err == nil && original.Kind == identity.KindGuest && req.subject.Kind == identity.KindAccount { m.queueRestrictionPromotion(req.subject, time.Time{}); m.safety.restrictionPromotions[subjectKey(req.subject.Kind, req.subject.ID)].mutation.DecidedAt = now }; return safetyResult{err: err} }
        err := m.restrictSubject(req.subject, true, now)
        if err == nil { m.safety.restrictions[subjectKey(req.subject.Kind, req.subject.ID)] = req.until; if original.Kind == identity.KindGuest && req.subject.Kind == identity.KindAccount { m.queueRestrictionPromotion(req.subject, req.until) } }
        return safetyResult{err: err}
    }
    if req.op == safetyRestrict { return safetyResult{err: m.restrictSubject(req.subject, req.flag, now)} }
	if req.op == safetyClaimPromotions { return safetyResult{promotions: m.claimPromotions(req.limit, now)} }
	if req.op == safetyFinishPromotion { return safetyResult{err: m.finishPromotion(req.ref, req.flag)} }
	if req.op == safetyFinish { return safetyResult{err: m.completeReport(req.guard, req.completion)} }
    if req.op == safetyFinishUnblock { return safetyResult{err: m.completeUnblock(req.guard, req.ref, req.flag)} }
    subject, slot, err := m.safetyPrincipal(req.guard, now, false)
	if err != nil { return safetyResult{err: err} }
	switch req.op {
	case safetyBegin: return m.beginReport(subject, slot, req.begin, now)
	case safetyPrepare:
		result := m.prepareReport(subject, slot, req.submit, now)
		if result.err == nil { draft := m.safety.drafts[req.submit.Handle]; draft.completionToken = req.guard.Principal.TokenHash; if block := m.safety.blocks[draft.blockRef]; block != nil { block.leaseToken = draft.completionToken } }
		return result
	case safetyBlock:
		if err := st.ValidateBlock(req.block); err != nil { return safetyResult{err: err} }
		var target *endedReference
		var err error
		if req.block.FriendRef != "" { target, err = m.friendBlockTarget(subject, slot, req.block.FriendRef) } else { target, err = m.reportTarget(subject, slot, st.BeginReportRequest{Generation: req.block.Generation, InteractionID: req.block.InteractionID, Epoch: req.block.Epoch, EndedRef: req.block.EndedRef}, now) }
		if err != nil { return safetyResult{err: err} }
		block, err := m.blockTarget(target, now, "")
		if err != nil { return safetyResult{err: err} }
		if block.mutation.LeaseID == "" && !block.durable { block.mutation.LeaseID = m.opaque("block-write"); block.leaseStarted = now; block.leaseMutation = block.mutation }
		return safetyResult{block: block.mutation}
	case safetyListBlocks:
		views := make([]st.BlockView, 0)
		for _, block := range m.safety.blocks { if sameSubject(block.mutation.Blocker, subject) { views = append(views, st.BlockView{Ref: block.mutation.Ref, DisplayName: block.displayName, CreatedAt: block.mutation.CreatedAt, Durable: block.durable, Pending: block.mutation.LeaseID != "" || block.reportHandle != ""}) } }
		sort.Slice(views, func(i, j int) bool { return views[i].CreatedAt.Before(views[j].CreatedAt) })
		return safetyResult{blocks: views}
	case safetyPrepareDurableUnblock:
        mutation := req.mutation
        if mutation.Ref == "" || !sameSubject(mutation.Blocker, subject) || mutation.Blocker.Kind != identity.KindAccount || mutation.Blocked.Kind != identity.KindAccount || !validInternalID(mutation.Blocked.ID) { return safetyResult{err: st.ErrInvalid} }
        block := m.safety.blocks[mutation.Ref]
        if block == nil {
            if len(m.safety.blocks) >= st.MaxLocalBlocks { return safetyResult{err: st.ErrCapacity} }
            mutation.LeaseID = ""; block = &localBlock{mutation: mutation, durable: true}
            if slot != nil { block.blockerSlot = slot.id }
            for _, peer := range m.guests.slots { if peer.accountID == mutation.Blocked.ID { block.blockedSlot = peer.id } }
            m.safety.blocks[mutation.Ref] = block; m.rebuildSafetyEdges()
        }
        req.ref = mutation.Ref
        fallthrough
    case safetyPrepareUnblock:
        block := m.safety.blocks[req.ref]
		if block == nil || !sameSubject(block.mutation.Blocker, subject) { return safetyResult{err: st.ErrExpired} }
		if block.mutation.LeaseID != "" || block.reportHandle != "" { return safetyResult{err: st.ErrBusy} }
		block.deleting = true; block.mutation.LeaseID = m.opaque("unblock"); block.leaseStarted = now; block.leaseMutation = block.mutation; block.leaseToken = req.guard.Principal.TokenHash
		return safetyResult{block: block.mutation}
	}
	return safetyResult{err: st.ErrInvalid}
}

func (m *liveMemory) reportTarget(subject st.Subject, slot *participantSlot, request st.BeginReportRequest, now time.Time) (*endedReference, error) {
	if slot == nil { return nil, st.ErrExpired }
	if request.EndedRef != "" {
		if request.Generation != 0 || request.InteractionID != "" || request.Epoch != 0 { return nil, st.ErrInvalid }
		target := m.safety.ended[request.EndedRef]
		if target == nil || target.ownerSlot != slot.id || !sameSubject(target.reporter, subject) || !now.Before(target.expiresAt) { return nil, st.ErrExpired }
		copy := *target; return &copy, nil
	}
	p := m.participants[slot.id]
	if p == nil || p.connection == nil || request.Generation != p.connectionGeneration { return nil, st.ErrStale }
	interaction := m.interactions[p.interactionID]
	if interaction == nil || request.InteractionID != interaction.id || request.Epoch != interaction.epoch { return nil, st.ErrStale }
	peer := m.peer(p)
	if peer == nil { return nil, st.ErrStale }
	return &endedReference{ownerSlot: slot.id, peerSlot: peer.slot.id, reporter: subject, subject: slotSubject(peer.slot), interactionID: interaction.id, epoch: interaction.epoch, startedAt: interaction.startedAt,call:cloneCallMetadata(interaction.callMetadata)}, nil
}
func (m *liveMemory) beginReport(subject st.Subject, slot *participantSlot, request st.BeginReportRequest, now time.Time) safetyResult {
	if err := st.ValidateBeginReport(request); err != nil { return safetyResult{err: err} }
	target, err := m.reportTarget(subject, slot, request, now)
	if err != nil { return safetyResult{err: err} }
	count := 0; for _, draft := range m.safety.drafts { if sameSubject(draft.reporter, subject) && !draft.completed { count++ } }
	if len(m.safety.drafts) >= st.MaxDrafts || count >= st.MaxDraftsPerIdentity { return safetyResult{err: st.ErrCapacity} }
	draft := &reportDraft{handle: m.opaque("report-draft"), ownerSlot: target.ownerSlot, peerSlot: target.peerSlot, reporter: subject, subject: target.subject, interactionID: target.interactionID, epoch: target.epoch, startedAt: target.startedAt, call:cloneCallMetadata(target.call), expiresAt: now.Add(st.ReportDraftTTL)}
	if !target.endedAt.IsZero() { ended := target.endedAt; draft.endedAt = &ended }
	if request.EndedRef == "" { if interaction := m.interactions[target.interactionID]; interaction != nil { for _, message := range interaction.messages { sender := draft.reporter; if message.sender != draft.ownerSlot { sender = draft.subject }; draft.evidence = append(draft.evidence, st.Evidence{ServerSequence: message.sequence, Sender: sender, Text: message.text, SentAt: message.sentAt}) } } }
	if request.Block { block, err := m.blockTarget(target, now, draft.handle); if err != nil { return safetyResult{err: err} }; draft.blockRef = block.mutation.Ref }
	m.safety.drafts[draft.handle] = draft
	view := st.DraftView{Handle: draft.handle, ExpiresAt: draft.expiresAt, Messages: make([]st.EvidenceView, 0, len(draft.evidence)), MetadataOnly: request.EndedRef != "", Blocked: request.Block}
	for _, message := range draft.evidence { speaker := "peer"; if sameSubject(message.Sender, draft.reporter) { speaker = "self" }; view.Messages = append(view.Messages, st.EvidenceView{ServerSequence: message.ServerSequence, Speaker: speaker, Text: message.Text, SentAt: message.SentAt}) }
	return safetyResult{draft: view}
}
func (m *liveMemory) prepareReport(subject st.Subject, slot *participantSlot, request st.SubmitReportRequest, now time.Time) safetyResult {
	draft := m.safety.drafts[request.Handle]
	if slot == nil || draft == nil || draft.ownerSlot != slot.id || !sameSubject(draft.reporter, subject) || !now.Before(draft.expiresAt) { return safetyResult{err: st.ErrExpired} }
	if err := st.ValidateSubmitReport(request); err != nil { return safetyResult{err: err} }
	if draft.inFlight { return safetyResult{err: st.ErrBusy} }
	wire, _ := json.Marshal(request); digest := sha256.Sum256(wire)
	if draft.submissionID != "" && (draft.submissionID != request.SubmissionID || draft.submissionDigest != digest) { return safetyResult{err: st.ErrConflict} }
	if draft.completed && draft.receipt != nil { receipt := *draft.receipt; return safetyResult{prepared: st.PreparedReport{Handle: draft.handle, SubmissionID: draft.submissionID, CompletedReceipt: &receipt}} }
	selected := make([]st.Evidence, 0, len(request.SelectedSequences)); seen := make(map[uint64]bool)
	for _, sequence := range request.SelectedSequences { if sequence == 0 || seen[sequence] { return safetyResult{err: st.ErrInvalid} }; seen[sequence] = true; found := false; for _, message := range draft.evidence { if message.ServerSequence == sequence { selected = append(selected, message); found = true; break } }; if !found { return safetyResult{err: st.ErrInvalid} } }
	draft.submissionID, draft.submissionDigest = request.SubmissionID, digest
	draft.inFlight = true
	prepared := st.PreparedReport{Handle: draft.handle, SubmissionID: request.SubmissionID, Reporter: draft.reporter, Subject: draft.subject, InteractionID: draft.interactionID, Epoch: draft.epoch, StartedAt: draft.startedAt, Call:cloneCallMetadata(draft.call), Evidence: selected, Category: request.Category, Statement: request.Statement}
	if draft.endedAt != nil { ended := *draft.endedAt; prepared.EndedAt = &ended }
	if block := m.safety.blocks[draft.blockRef]; block != nil { if block.mutation.LeaseID != "" { draft.inFlight = false; return safetyResult{err: st.ErrBusy} }; block.reportHandle = draft.handle; block.mutation.LeaseID = m.opaque("report-block-write"); block.leaseStarted = now; block.leaseMutation = block.mutation; mutation := block.mutation; prepared.Block = &mutation }
	return safetyResult{prepared: prepared}
}

func (m *liveMemory) blockTarget(target *endedReference, now time.Time, reportHandle string) (*localBlock, error) {
	for _, block := range m.safety.blocks { if sameSubject(block.mutation.Blocker, target.reporter) && sameSubject(block.mutation.Blocked, target.subject) { if block.deleting || block.mutation.LeaseID != "" || (reportHandle != "" && block.reportHandle != "" && block.reportHandle != reportHandle) { return nil, st.ErrBusy }; if reportHandle != "" { block.reportHandle = reportHandle }; m.endBlockedPair(target.ownerSlot, target.peerSlot, now); return block, nil } }
	count := 0; for _, block := range m.safety.blocks { if sameSubject(block.mutation.Blocker, target.reporter) { count++ } }
	if len(m.safety.blocks) >= st.MaxLocalBlocks || count >= st.MaxBlocksPerIdentity { return nil, st.ErrCapacity }
	block := &localBlock{mutation: st.BlockMutation{Ref: m.opaque("block"), Blocker: target.reporter, Blocked: target.subject, CreatedAt: now, Version: 1}, blockerSlot: target.ownerSlot, blockedSlot: target.peerSlot, reportHandle: reportHandle}
	if peer := m.guests.slots[target.peerSlot]; peer != nil { block.displayName = peer.profile.DisplayName }
	m.safety.blocks[block.mutation.Ref] = block
	m.removeFriendPair(ft.Subject{Kind:target.reporter.Kind,ID:target.reporter.ID,Generation:target.reporter.Generation}, ft.Subject{Kind:target.subject.Kind,ID:target.subject.ID,Generation:target.subject.Generation}, now)
	m.rebuildSafetyEdges()
	if owner := m.guests.slots[target.ownerSlot]; owner != nil { if owner.carry.blocks == nil { owner.carry.blocks = make(map[string]struct{}) }; owner.carry.blocks[target.peerSlot] = struct{}{}; delete(owner.carry.acceptedLinks, target.peerSlot) }
	if peer := m.guests.slots[target.peerSlot]; peer != nil { delete(peer.carry.acceptedLinks, target.ownerSlot) }
	m.fence++; m.endBlockedPair(target.ownerSlot, target.peerSlot, now)
	return block, nil
}
func (m *liveMemory) endBlockedPair(a, b string, now time.Time) { if sa,sb := m.guests.slots[a],m.guests.slots[b]; sa != nil && sb != nil { m.removeFriendPair(friendSubject(sa), friendSubject(sb), now) }; if p := m.participants[a]; p != nil { if peer := m.peer(p); peer != nil && peer.slot.id == b { m.endMatch(p, now, "not_available", false) } }; for _, p := range m.waiting { m.reindex(p) } }
func (m *liveMemory) removeLocalBlock(ref string) { block := m.safety.blocks[ref]; if block == nil { return }; if owner := m.guests.slots[block.blockerSlot]; owner != nil { delete(owner.carry.blocks, block.blockedSlot) }; delete(m.safety.blocks, ref) }

func (m *liveMemory) rememberEnded(interaction *liveInteraction, now time.Time) {
	for _, ownerID := range []string{interaction.a, interaction.b} {
		p := m.participants[ownerID]; if p == nil { continue }
		peerID := interaction.a; if ownerID == interaction.a { peerID = interaction.b }; peer := m.guests.slots[peerID]; if peer == nil { continue }
		if len(m.safety.ended) >= st.MaxEndedReferences { p.endedRef = ""; continue }
		ref := m.opaque("ended-report"); m.safety.ended[ref] = &endedReference{ownerSlot: ownerID, peerSlot: peerID, reporter: slotSubject(p.slot), subject: slotSubject(peer), interactionID: interaction.id, epoch: interaction.epoch, startedAt: interaction.startedAt, call:cloneCallMetadata(interaction.callMetadata), endedAt: now, expiresAt: now.Add(st.EndedReferenceTTL)}; p.endedRef = ref
	}
}
func (m *liveMemory) expireSafety(now time.Time) {
	for handle, draft := range m.safety.drafts { if !now.Before(draft.expiresAt) || m.guests.slots[draft.ownerSlot] == nil { draft.evidence = nil; delete(m.safety.drafts, handle); if block := m.safety.blocks[draft.blockRef]; block != nil && block.reportHandle == handle && block.mutation.LeaseID == "" { block.reportHandle = "" } } }
	for ref, ended := range m.safety.ended { if !now.Before(ended.expiresAt) || m.guests.slots[ended.ownerSlot] == nil { delete(m.safety.ended, ref); if p := m.participants[ended.ownerSlot]; p != nil && p.endedRef == ref { p.endedRef = "" } } }
	removedBlock := false
    for ref, block := range m.safety.blocks {
        guestExpired := (block.mutation.Blocker.Kind == identity.KindGuest && m.guests.slots[block.blockerSlot] == nil) || (block.mutation.Blocked.Kind == identity.KindGuest && m.guests.slots[block.blockedSlot] == nil)
        // Durable history is reloaded by fresh cookie authorization. Once both
        // endpoints are offline it need not consume the finite temporary set.
        dormantDurable := block.durable && block.mutation.LeaseID == "" && block.reportHandle == "" && m.participants[block.blockerSlot] == nil && m.participants[block.blockedSlot] == nil
        if guestExpired || dormantDurable { m.removeLocalBlock(ref); removedBlock = true }
    }
    if removedBlock { m.rebuildSafetyEdges() }
	for key, until := range m.safety.restrictions {
        if !until.IsZero() && !now.Before(until) { delete(m.safety.restrictions, key); delete(m.safety.restrictionDecided, key); for _, slot := range m.guests.slots { subject := slotSubject(slot); if subjectKey(subject.Kind, subject.ID) == key { delete(slot.carry.restrictions, "moderation") } }; m.fence++; continue }
        if len(key) > 6 && key[:6] == "guest:" { id := key[6:]; if m.guests.slots[id] == nil { delete(m.safety.restrictions, key); delete(m.safety.restrictionDecided, key) } }
    }
}
func (m *liveMemory) promoteSafetySubject(slotID string, now time.Time) {
	slot := m.guests.slots[slotID]; if slot == nil { return }; updated := slotSubject(slot)
	old := st.Subject{Kind: identity.KindGuest, ID: slotID}
	if until, restricted := m.safety.restrictions[subjectKey(old.Kind, old.ID)]; restricted { delete(m.safety.restrictions, subjectKey(old.Kind, old.ID)); m.safety.restrictions[subjectKey(updated.Kind, updated.ID)] = until; m.safety.restrictionDecided[subjectKey(updated.Kind, updated.ID)] = m.safety.restrictionDecided[subjectKey(old.Kind, old.ID)]; delete(m.safety.restrictionDecided, subjectKey(old.Kind, old.ID)); if updated.Kind == identity.KindAccount && !until.IsZero() { m.queueRestrictionPromotion(updated, until) } }
	for _, draft := range m.safety.drafts { if draft.ownerSlot == slotID { draft.reporter = updated }; if draft.peerSlot == slotID { draft.subject = updated }; for index := range draft.evidence { if sameSubject(draft.evidence[index].Sender, old) { draft.evidence[index].Sender = updated } } }
	for _, ended := range m.safety.ended { if ended.ownerSlot == slotID { ended.reporter = updated }; if ended.peerSlot == slotID { ended.subject = updated } }
	for _, block := range m.safety.blocks { if block.blockerSlot == slotID { block.mutation.Blocker = updated; block.mutation.Version++ }; if block.blockedSlot == slotID { block.mutation.Blocked = updated; block.mutation.Version++ } }
	m.rebuildSafetyEdges()
	_ = now // promotion is claimed by a bounded worker outside this owner.
}
func (m *liveMemory) claimPromotions(limit int, now time.Time) []st.BlockMutation {
	if limit < 1 { return nil }; if limit > 16 { limit = 16 }
	result := make([]st.BlockMutation, 0, limit)
	for _, block := range m.safety.blocks { if len(result) == limit { break }; if block.durable || block.deleting || block.reportHandle != "" || block.mutation.LeaseID != "" || block.mutation.Blocker.Kind != identity.KindAccount || block.mutation.Blocked.Kind != identity.KindAccount { continue }; block.mutation.LeaseID = m.opaque("block-promotion"); block.leaseStarted = now; block.leaseMutation = block.mutation; result = append(result, block.mutation) }
	return result
}
func (m *liveMemory) finishPromotion(leaseID string, persisted bool) error {
	if leaseID == "" { return st.ErrInvalid }
	if persisted { m.fence++ }
	for _, block := range m.safety.blocks { if block.mutation.LeaseID == leaseID && !block.deleting { if persisted { block.durable = durableLease(block) }; block.mutation.LeaseID = ""; return nil } }
	return st.ErrExpired
}
func (m *liveMemory) restrictSubject(subject st.Subject, restricted bool, now time.Time) error {
	subject = m.currentSubject(subject)
	if (subject.Kind != identity.KindAccount && subject.Kind != identity.KindGuest) || !validInternalID(subject.ID) { return st.ErrInvalid }
	key := subjectKey(subject.Kind, subject.ID)
	if restricted { if len(m.safety.restrictions) >= ParticipantSlotCapacity && !m.subjectRestricted(subject.Kind, subject.ID) { return st.ErrCapacity }; m.safety.restrictions[key] = time.Time{}; m.safety.restrictionDecided[key] = now } else { delete(m.safety.restrictions, key); delete(m.safety.restrictionDecided, key); if pending := m.safety.restrictionPromotions[key]; pending != nil && pending.mutation.LeaseID == "" { delete(m.safety.restrictionPromotions, key) } }
	m.fence++
	for _, slot := range m.guests.slots { if sameSubject(slotSubject(slot), subject) { if restricted { if slot.carry.restrictions == nil { slot.carry.restrictions = make(map[string]struct{}) }; slot.carry.restrictions["moderation"] = struct{}{} } else { delete(slot.carry.restrictions, "moderation") } } }
	for _, p := range m.participants { if p.auth.Kind == subject.Kind && p.auth.IdentityID == subject.ID { if restricted { if p.slot.carry.restrictions == nil { p.slot.carry.restrictions = make(map[string]struct{}) }; p.slot.carry.restrictions["moderation"] = struct{}{}; m.terminate(p, now, "account_restricted") } else { delete(p.slot.carry.restrictions, "moderation") } } }
	return nil
}

// Reciprocal eligibility index avoids scanning every block on each chat send
// or candidate comparison. Rebuilt only on bounded low-rate safety mutations.
func (m *liveMemory) rebuildSafetyEdges() {
	edges := make(map[string]map[string]st.Subject)
	for _, block := range m.safety.blocks {
		a, b := block.mutation.Blocker, block.mutation.Blocked
		ka, kb := subjectKey(a.Kind, a.ID), subjectKey(b.Kind, b.ID)
		if edges[ka] == nil { edges[ka] = make(map[string]st.Subject) }; if edges[kb] == nil { edges[kb] = make(map[string]st.Subject) }
		edges[ka][kb], edges[kb][ka] = b, a
	}
	m.safety.edges = edges
}

func durableLease(block *localBlock) bool { return block.leaseMutation.Version == block.mutation.Version && block.leaseMutation.Blocker.Kind == identity.KindAccount && block.leaseMutation.Blocked.Kind == identity.KindAccount }
// Completion is a trusted internal publication, not a new user action. Its
// opaque handle/lease and the token captured at Prepare remain valid through
// cookie rotation or logout, so an already completed database write can settle.
func (m *liveMemory) completeReport(guard st.Guard, completion st.ReportCompletion) error {
	if completion.Handle == "" || completion.SubmissionID == "" || guard.Principal.TokenHash == (identity.Verifier{}) { return st.ErrInvalid }
	if completion.Persisted { m.fence++ }
    draft := m.safety.drafts[completion.Handle]
    if draft == nil {
        for _, block := range m.safety.blocks { if block.reportHandle == completion.Handle && block.leaseToken == guard.Principal.TokenHash && block.mutation.LeaseID != "" { if completion.Persisted { block.durable = completion.DurableBlockPersisted && completion.BlockVersion == block.mutation.Version && durableLease(block) }; block.reportHandle = ""; block.mutation.LeaseID = ""; return nil } }
        return st.ErrExpired
    }
    if draft.submissionID != completion.SubmissionID || draft.completionToken != guard.Principal.TokenHash || guard.Principal.TokenHash == (identity.Verifier{}) { return st.ErrUnauthorized }
    draft.inFlight = false
    if completion.Persisted { draft.completed = true; if completion.Receipt != nil { receipt := *completion.Receipt; draft.receipt = &receipt; draft.evidence = nil } }
    if block := m.safety.blocks[draft.blockRef]; block != nil { if completion.Persisted { block.durable = completion.DurableBlockPersisted && completion.BlockVersion == block.mutation.Version && durableLease(block); block.reportHandle = "" }; block.mutation.LeaseID = "" }
    return nil
}
func (m *liveMemory) completeUnblock(guard st.Guard, leaseID string, persisted bool) error {
	if leaseID == "" { return st.ErrInvalid }
    for ref, block := range m.safety.blocks { if block.mutation.LeaseID == leaseID && block.deleting && block.leaseToken == guard.Principal.TokenHash && guard.Principal.TokenHash != (identity.Verifier{}) { if persisted { m.removeLocalBlock(ref); m.rebuildSafetyEdges(); m.fence++ } else { block.deleting = false; block.mutation.LeaseID = "" }; return nil } }
    return st.ErrExpired
}

func (m *liveMemory) currentSubject(subject st.Subject) st.Subject {
    if subject.Kind == identity.KindGuest { if slot := m.guests.slots[subject.ID]; slot != nil && slot.accountID != "" { return slotSubject(slot) } }
    return subject
}
func (m *liveMemory) queueRestrictionPromotion(subject st.Subject, until time.Time) {
    key := subjectKey(subject.Kind, subject.ID)
    pending := m.safety.restrictionPromotions[key]
    if pending == nil { pending = &restrictionPromotion{}; m.safety.restrictionPromotions[key] = pending }
    pending.mutation.Subject, pending.mutation.Until = subject, until
	pending.mutation.DecidedAt = m.safety.restrictionDecided[key]
}
func (m *liveMemory) claimRestrictionPromotions(limit int, now time.Time) []st.RestrictionMutation {
    if limit < 1 { return nil }; if limit > 16 { limit = 16 }
    result := make([]st.RestrictionMutation, 0, limit)
    for key, pending := range m.safety.restrictionPromotions {
        if pending.mutation.LeaseID != "" { continue }
        if !pending.mutation.Until.IsZero() && (!now.Before(pending.mutation.Until) || !m.subjectRestricted(pending.mutation.Subject.Kind, pending.mutation.Subject.ID)) { delete(m.safety.restrictionPromotions, key); continue }
        if len(result) == limit { break }
        pending.mutation.LeaseID = m.opaque("restriction-promotion"); pending.leasedUntil = pending.mutation.Until; pending.leasedDecision = pending.mutation.DecidedAt
        result = append(result, pending.mutation)
    }
    return result
}
func (m *liveMemory) finishRestrictionPromotion(leaseID string, persisted bool) error {
	if leaseID == "" { return st.ErrInvalid }
	if persisted { m.fence++ }
    for key, pending := range m.safety.restrictionPromotions { if pending.mutation.LeaseID == leaseID { if persisted && pending.leasedUntil.Equal(pending.mutation.Until) && pending.leasedDecision.Equal(pending.mutation.DecidedAt) { delete(m.safety.restrictionPromotions, key) } else { pending.mutation.LeaseID = "" }; return nil } }
    return st.ErrExpired
}

func (m *liveMemory) queueHandoffFinalization(accountID string, generation int64) {
    m.safety.handoffs[accountID] = &handoffFinalization{mutation: st.HandoffFinalization{Subject: st.Subject{Kind: identity.KindAccount, ID: accountID, Generation: generation}, Version: m.fence}}
}
func (m *liveMemory) claimHandoffFinalizations(limit int, now time.Time) []st.HandoffFinalization {
    if limit < 1 { return nil }; if limit > 16 { limit = 16 }
    result := make([]st.HandoffFinalization, 0, limit)
    for _, job := range m.safety.handoffs {
        if len(result) == limit { break }; if job.mutation.LeaseID != "" { continue }
        subject := job.mutation.Subject
        var blocks []*localBlock; busy := false
        for _, block := range m.safety.blocks {
            if !sameSubject(block.mutation.Blocker, subject) && !sameSubject(block.mutation.Blocked, subject) { continue }
            if block.mutation.Blocker.Kind != identity.KindAccount || block.mutation.Blocked.Kind != identity.KindAccount { continue }
            if block.mutation.LeaseID != "" || block.deleting { busy = true; break }
            blocks = append(blocks, block)
        }
        if busy { continue }
        job.mutation.LeaseID = m.opaque("handoff-finalization"); job.mutation.Version = m.fence
        job.mutation.Blocks = make([]st.BlockMutation, 0, len(blocks))
        for _, block := range blocks { block.mutation.LeaseID = job.mutation.LeaseID; block.leaseMutation = block.mutation; block.leaseStarted = now; job.mutation.Blocks = append(job.mutation.Blocks, block.mutation) }
        key := subjectKey(subject.Kind, subject.ID)
        job.mutation.RestrictionUntil = m.safety.restrictions[key]; job.mutation.RestrictionDecidedAt = m.safety.restrictionDecided[key]
        snapshot := job.mutation; snapshot.Blocks = append([]st.BlockMutation(nil), job.mutation.Blocks...)
        result = append(result, snapshot)
    }
    return result
}
func (m *liveMemory) finishHandoffFinalization(leaseID string, persisted bool) error {
	if leaseID == "" { return st.ErrInvalid }
    for id, job := range m.safety.handoffs {
        if job.mutation.LeaseID != leaseID { continue }
        for _, captured := range job.mutation.Blocks { if block := m.safety.blocks[captured.Ref]; block != nil && block.mutation.LeaseID == leaseID { if persisted { block.durable = durableLease(block) }; block.mutation.LeaseID = "" } }
        if persisted { delete(m.safety.handoffs, id); m.fence++ } else { job.mutation.LeaseID = ""; job.mutation.Blocks = nil }
        return nil
    }
    return st.ErrExpired
}

func (m *liveMemory) friendBlockTarget(subject st.Subject,slot *participantSlot,ref string)(*endedReference,error){
 link:=m.friends.links[ref];own:=ft.Subject{Kind:subject.Kind,ID:subject.ID,Generation:subject.Generation}
 if link==nil||link.removed||(!sameFriend(own,link.mutation.A)&&!sameFriend(own,link.mutation.B)){return nil,st.ErrExpired}
 peer,peerSlot:=link.mutation.B,link.bSlot;if sameFriend(own,peer){peer,peerSlot=link.mutation.A,link.aSlot};ownerSlot:="";if slot!=nil{ownerSlot=slot.id}
 return &endedReference{ownerSlot:ownerSlot,peerSlot:peerSlot,reporter:subject,subject:st.Subject{Kind:peer.Kind,ID:peer.ID,Generation:peer.Generation}},nil
}
