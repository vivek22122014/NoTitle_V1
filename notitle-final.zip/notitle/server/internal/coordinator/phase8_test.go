package coordinator

import (
 "context"
 "encoding/json"
 "errors"
 "strings"
 "testing"
 "time"
 "notitle/internal/identity"
 rt "notitle/internal/realtime"
)

func paidFixture(p *liveParticipant,now time.Time,used bool){
 p.auth.Entitlement=rt.Entitlement{Premium:true,Version:3,ExpiresAt:now.Add(time.Hour),UsageLotID:"private_purchase_lot",UsageUntil:now.Add(time.Minute),PaidControlsUsed:used}
 p.auth.Preferences.Gender=rt.PreferOther
}
func claimUsageFixture(t *testing.T,m *liveMemory,now time.Time)rt.PremiumUsageJob{
 t.Helper();r:=m.applyPremium(realtimeRequest{op:opPremiumClaim,premiumLimit:8},now)
 if r.err!=nil||len(r.premiumJobs)!=1{t.Fatalf("expected one paid-use job, got %d: %v",len(r.premiumJobs),r.err)}
 return r.premiumJobs[0]
}
func ackUsageFixture(m *liveMemory,job rt.PremiumUsageJob,e rt.Entitlement,now time.Time)realtimeResult{return m.applyPremium(realtimeRequest{op:opPremiumUsageFinish,premiumToken:job.ID,premiumUsage:rt.PremiumUsageResult{Entitlement:e,Trusted:true}},now)}

func TestPremiumPaidUseMustBeDurableBeforeSharedPoolCommit(t *testing.T){
 m:=memoryFixture();m.premium.enabled=true;now:=rtNow();a,pa:=attachFixture(t,m,1,now);b,pb:=attachFixture(t,m,2,now);paidFixture(pa,now,false)
 doCommand(t,m,a,pa,"queue.join","paid_join",now);doCommand(t,m,b,pb,"queue.join","free_join",now)
 if len(m.interactions)!=0||pa.state!=rt.Waiting||pb.state!=rt.Waiting{t.Fatal("paid controls were used before durable attribution")}
 job:=claimUsageFixture(t,m,now)
 if job.Guard.AccountID!=pa.auth.IdentityID||job.Guard.TokenHash!=pa.auth.SessionVerifier||job.LotID!=pa.auth.Entitlement.UsageLotID||job.EntitlementVersion!=3{t.Fatal("usage was not bound to current authoritative purchase and session")}
 e:=pa.auth.Entitlement;e.PaidControlsUsed=true;r:=ackUsageFixture(m,job,e,now)
 if !r.published||len(m.interactions)!=1||pa.interactionID!=pb.interactionID||len(m.premium.jobs)!=0{t.Fatal("durable paid use did not unlock compatible Free participant")}
 if ackUsageFixture(m,job,e,now).published||len(m.interactions)!=1{t.Fatal("duplicate acknowledgement repeated admission")}
}
func TestPremiumUsageFailureAndLostAcknowledgementFailClosed(t *testing.T){
 m:=memoryFixture();m.premium.enabled=true;now:=rtNow();a,pa:=attachFixture(t,m,1,now);b,pb:=attachFixture(t,m,2,now);paidFixture(pa,now,false)
 doCommand(t,m,a,pa,"queue.join","paid_join",now);doCommand(t,m,b,pb,"queue.join","free_join",now);job:=claimUsageFixture(t,m,now)
 r:=m.applyPremium(realtimeRequest{op:opPremiumUsageFinish,premiumToken:job.ID},now)
 if r.published||len(m.interactions)!=0{t.Fatal("operational failure granted paid use")}
 if jobs:=m.applyPremium(realtimeRequest{op:opPremiumClaim,premiumLimit:8},now.Add(time.Second)).premiumJobs;len(jobs)!=1||jobs[0].ID!=job.ID{t.Fatal("failed attribution did not retry idempotently")}
 doCommand(t,m,a,pa,"queue.leave","leave_while_pending",now.Add(time.Second))
 e:=pa.auth.Entitlement;e.PaidControlsUsed=true
 if ackUsageFixture(m,job,e,now.Add(time.Second)).published||len(m.interactions)!=0{t.Fatal("late result resurrected a withdrawn search")}
}
func TestPremiumRefundFenceRejectsStaleReadsAndUsage(t *testing.T){
 m:=memoryFixture();m.premium.enabled=true;now:=rtNow();a,pa:=attachFixture(t,m,1,now);paidFixture(pa,now,false)
 stale:=cloneAuth(pa.auth);stale.Fence=m.fence
 doCommand(t,m,a,pa,"queue.join","paid_join",now);job:=claimUsageFixture(t,m,now)
 begin:=m.applyPremium(realtimeRequest{op:opPremiumBegin,identityID:pa.auth.IdentityID},now)
 if begin.err!=nil||begin.premiumToken==""||pa.state!=rt.Waiting||m.entry(pa,now).Available||pa.auth.Preferences.Gender!=rt.PreferOther{t.Fatal("refund did not freeze strict eligibility without erasing search intent")}
 if !errors.Is(m.refresh(stale,now),rt.ErrUnavailable){t.Fatal("pre-refund authorization was published")}
 if m.applyPremium(realtimeRequest{op:opPremiumBegin,identityID:pa.auth.IdentityID},now).err==nil{t.Fatal("concurrent account mutation was not serialized")}
 e:=pa.auth.Entitlement;e.PaidControlsUsed=true
 if ackUsageFixture(m,job,e,now).published{t.Fatal("in-flight usage result crossed refund fence")}
 bad:=m.applyPremium(realtimeRequest{op:opPremiumFinish,identityID:pa.auth.IdentityID,premiumToken:"wrong_token",entitlement:rt.Entitlement{Version:4}},now)
 if bad.err==nil||!m.premiumBlocked(pa.auth.IdentityID){t.Fatal("wrong mutation token cleared restriction")}
 finish:=m.applyPremium(realtimeRequest{op:opPremiumFinish,identityID:pa.auth.IdentityID,premiumToken:begin.premiumToken,entitlement:rt.Entitlement{Version:4}},now)
 if finish.err!=nil||m.premiumBlocked(pa.auth.IdentityID)||pa.state!=rt.Idle{t.Fatal("authoritative refund was not published and strict search paused")}
 command:=cmdFixture(a.Ref,"queue.join","try_saved_specific",pa,m)
 if !errors.Is(m.command(a.Ref,command,now),rt.ErrPremiumRequired){t.Fatal("refunded specific preference became Everyone silently")}
 command.ID="explicit_everyone";command.Payload=json.RawMessage(`{"continue_with_everyone":true}`)
 if err:=m.command(a.Ref,command,now);err!=nil||pa.queueAuth.Preferences.Gender!=rt.Everyone||pa.auth.Preferences.Gender!=rt.PreferOther{t.Fatal("explicit Everyone did not preserve saved strict choice",err)}
}
func TestPremiumFIFOHeadRolloverRequiresNewDurableMarker(t *testing.T){
 m:=memoryFixture();m.premium.enabled=true;now:=rtNow();a,pa:=attachFixture(t,m,1,now);paidFixture(pa,now,true);pa.auth.Entitlement.UsageUntil=now.Add(time.Second)
 doCommand(t,m,a,pa,"queue.join","paid_join",now)
 b,pb:=attachFixture(t,m,2,now.Add(time.Second));doCommand(t,m,b,pb,"queue.join","free_join",now.Add(time.Second))
 if len(m.interactions)!=0{t.Fatal("previous lot use marker authorized a later lot")}
 oldJob:=claimUsageFixture(t,m,now.Add(time.Second));fresh:=pa.auth.Entitlement;fresh.UsageLotID="next_purchase_lot";fresh.UsageUntil=now.Add(time.Hour);fresh.PaidControlsUsed=false
 if !ackUsageFixture(m,oldJob,fresh,now.Add(time.Second)).published||len(m.interactions)!=0{t.Fatal("fresh conflict projection did not re-arm FIFO head authorization")}
 next:=claimUsageFixture(t,m,now.Add(time.Second));if next.LotID!=fresh.UsageLotID||next.ID==oldJob.ID{t.Fatal("head change reused old intent")}
 fresh.PaidControlsUsed=true;ackUsageFixture(m,next,fresh,now.Add(time.Second))
 if len(m.interactions)!=1{t.Fatal("verified current lot did not allow match")}
}
func TestPremiumTimeCheckedAtCommitWithoutExpirationWorker(t *testing.T){
 m:=memoryFixture();m.premium.enabled=true;now:=rtNow();a,pa:=attachFixture(t,m,1,now);paidFixture(pa,now,true);pa.auth.Entitlement.ExpiresAt=now.Add(time.Second);pa.auth.Entitlement.UsageUntil=now.Add(time.Second)
 doCommand(t,m,a,pa,"queue.join","paid_join",now)
 b,pb:=attachFixture(t,m,2,now.Add(time.Second));doCommand(t,m,b,pb,"queue.join","free_join",now.Add(time.Second))
 if len(m.interactions)!=0{t.Fatal("commit depended on cron advancing expiry")}
 m.maintain(now.Add(time.Second));if pa.state!=rt.Idle||pa.auth.Preferences.Gender!=rt.PreferOther{t.Fatal("strict expiry did not pause saved choice")}
}
func TestPremiumPendingMutationAllowsEveryoneWithoutPaidScoring(t *testing.T){
 m:=memoryFixture();m.premium.enabled=true;now:=rtNow();a,pa:=attachFixture(t,m,1,now);paidFixture(pa,now,true);pa.auth.Preferences.Gender=rt.Everyone;pa.auth.Preferences.Professional.NoPreference=false;pa.auth.Preferences.Professional.Profession=rt.CategoryPreference{Choices:[]string{"engineering"}}
 doCommand(t,m,a,pa,"queue.join","everyone_join",now)
 begin:=m.applyPremium(realtimeRequest{op:opPremiumBegin,identityID:pa.auth.IdentityID},now)
 if begin.err!=nil||pa.state!=rt.Waiting||m.entry(pa,now).Auth.Entitlement.Active(now){t.Fatal("pending financial mutation retained paid scoring or stopped Everyone")}
 b,pb:=attachFixture(t,m,2,now);doCommand(t,m,b,pb,"queue.join","free_join",now)
 if len(m.interactions)!=1{t.Fatal("Everyone could not continue in shared pool")}
}
func TestPremiumMutationPreservesExistingConversationAndPrivacy(t *testing.T){
 m:=memoryFixture();m.premium.enabled=true;now:=rtNow();m.now=now;a,pa:=attachFixture(t,m,1,now);b,pb:=attachFixture(t,m,2,now);paidFixture(pa,now,true)
 doCommand(t,m,a,pa,"queue.join","paid_join",now);doCommand(t,m,b,pb,"queue.join","free_join",now);interaction:=pa.interactionID
 drain(a);drain(b);begin:=m.applyPremium(realtimeRequest{op:opPremiumBegin,identityID:pa.auth.IdentityID},now)
 result:=m.applyPremium(realtimeRequest{op:opPremiumFinish,identityID:pa.auth.IdentityID,premiumToken:begin.premiumToken,entitlement:rt.Entitlement{Version:4}},now)
 if result.err!=nil||pa.interactionID!=interaction||pb.interactionID!=interaction||len(m.interactions)!=1{t.Fatal("refund interrupted existing conversation")}
 select{case event:=<-b.Events:t.Fatalf("peer received private entitlement event %s",event.Type);default:}
 state:=m.state(pa);if state.PremiumActive||!state.RequiresEveryoneConfirmation{t.Fatal("own expiry projection missing")}
 wire,err:=json.Marshal(state);if err!=nil{t.Fatal(err)}
 for _,private:=range []string{"private_purchase_lot","PaidControlsUsed","UsageUntil",pa.auth.IdentityID,pa.auth.SessionID}{if strings.Contains(string(wire),private){t.Fatalf("private billing context reached state: %s",private)}}
}
func TestPremiumSavedAndGeneralTalkPreferencesDoNotMarkFutureUse(t *testing.T){
 m:=memoryFixture();m.premium.enabled=true;now:=rtNow();a,pa:=attachFixture(t,m,1,now);paidFixture(pa,now,false)
 m.maintain(now);if len(m.premium.jobs)!=0{t.Fatal("idle saved preferences were marked as used")}
 pa.auth.Preferences.Gender=rt.Everyone;pa.auth.Profile.Topic="general_talk";pa.auth.Preferences.Professional.NoPreference=false;pa.auth.Preferences.Professional.Profession=rt.CategoryPreference{Choices:[]string{"engineering"}}
 doCommand(t,m,a,pa,"queue.join","general_join",now);if len(m.premium.jobs)!=0||!m.entry(pa,now).Available{t.Fatal("General Talk opt-out required paid attribution")}
}
func TestPremiumRevocationFenceCoversOfflineAuthorization(t *testing.T){
 m:=memoryFixture();m.premium.enabled=true;now:=rtNow();auth:=accountAuth(1,now);auth.Entitlement=rt.Entitlement{Premium:true,Version:3,ExpiresAt:now.Add(time.Hour),UsageLotID:"old_lot",UsageUntil:now.Add(time.Hour),PaidControlsUsed:true};auth.Fence=m.fence
 begin:=m.applyPremium(realtimeRequest{op:opPremiumBegin,identityID:auth.IdentityID},now)
 if begin.err!=nil{t.Fatal(begin.err)}
 m.applyPremium(realtimeRequest{op:opPremiumFinish,identityID:auth.IdentityID,premiumToken:begin.premiumToken,entitlement:rt.Entitlement{Version:4}},now)
 result:=m.attach(rt.AttachRequest{Auth:auth},"test_resume_secret",now)
 if !errors.Is(result.err,rt.ErrUnavailable)||len(m.participants)!=0{t.Fatal("offline stale paid authorization survived completed refund")}
}
func TestPremiumGuestCannotCreateDurableUsageJob(t *testing.T){
 m:=memoryFixture();m.premium.enabled=true;now:=rtNow();_,pa:=attachFixture(t,m,1,now);paidFixture(pa,now,false);pa.auth.Kind=identity.KindGuest;pa.state=rt.Waiting;pa.queueAuth=cloneAuth(pa.auth)
 m.ensurePremiumUsage(pa,now);if len(m.premium.jobs)!=0{t.Fatal("guest generated a paid ledger mutation")}
}
func TestPremiumUnchangedPublicationPreservesStrictSearchAge(t *testing.T){
 m:=memoryFixture();m.premium.enabled=true;now:=rtNow();a,pa:=attachFixture(t,m,1,now);paidFixture(pa,now,true)
 doCommand(t,m,a,pa,"queue.join","paid_join",now);queued:=pa.queuedAt
 begin:=m.applyPremium(realtimeRequest{op:opPremiumBegin,identityID:pa.auth.IdentityID},now.Add(time.Second))
 if begin.err!=nil||m.entry(pa,now.Add(time.Second)).Available{t.Fatal("pending mutation did not freeze paid eligibility")}
 m.maintain(now.Add(time.Second));if pa.state!=rt.Waiting{t.Fatal("short mutation forced unnecessary user rejoin")}
 e:=pa.auth.Entitlement;e.Version++
 finish:=m.applyPremium(realtimeRequest{op:opPremiumFinish,identityID:pa.auth.IdentityID,premiumToken:begin.premiumToken,entitlement:e},now.Add(time.Second))
 if finish.err!=nil||pa.state!=rt.Waiting||!pa.queuedAt.Equal(queued)||!m.entry(pa,now.Add(time.Second)).Available{t.Fatal("money-only or additive mutation destroyed existing strict search")}
}
func TestPremiumMutationAcknowledgementCannotBeLostAfterOwnerProcessing(t *testing.T){
 for _,operation:=range []uint8{opPremiumBegin,opPremiumFinish}{t.Run(string(rune('A'+operation)),func(t *testing.T){
  c:=&Coordinator{controlRequests:make(chan realtimeRequest,1),done:make(chan struct{})};c.running.Store(true)
  ctx,cancel:=context.WithCancel(context.Background());defer cancel();finished:=make(chan error,1)
  go func(){_,err:=c.realtimeCommand(ctx,realtimeRequest{op:operation});finished<-err}()
  var request realtimeRequest
  select{case request=<-c.controlRequests:case<-time.After(time.Second):t.Fatal("mutation was not delivered")}
  // Model cancellation after the owner received the control message, while
  // its completed result is about to be published. A canceled caller must
  // still learn whether Begin installed or Finish released its exact token.
  cancel()
  select{case err:=<-finished:t.Fatal("caller lost definitive mutation acknowledgement",err);case<-time.After(20*time.Millisecond):}
  request.reply<-realtimeResult{}
  select{case err:=<-finished:if err!=nil{t.Fatal(err)};case<-time.After(time.Second):t.Fatal("mutation acknowledgement was not returned")}
 })}
}
