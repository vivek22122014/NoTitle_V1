package coordinator

import (
    "time"
    rt "notitle/internal/realtime"
)

// The final pair cannot have been jointly available before both queue commands
// reached the coordinator boundary. Starting at the later request includes
// mailbox delay, matching, and pending durable paid-use authorization. Waiting
// for the second person to arrive is excluded. A later profile/authorization
// change can make this an overestimate, never a shorter
// selected-pair scan substituted for the full interval. The observation is a
// conservative upper bound; no additional pair scan or identity label exists.
func laterQueueRequest(a,b *liveParticipant)time.Time{
    if a.queueRequestedAt.IsZero()||b.queueRequestedAt.IsZero(){return time.Time{}}
    start:=a.queueRequestedAt;if b.queueRequestedAt.After(start){start=b.queueRequestedAt};return start
}
func pairReadyUpperBound(a,b *liveParticipant,history rt.PairHistory)time.Time{
    start:=laterQueueRequest(a,b);if start.IsZero()||history.EndedAt.IsZero(){return start}
    // Only the deterministic mandatory rematch interval is excluded. Use the
    // later queue processing time to calculate its remaining duration, while
    // retaining the earlier request-receipt base. Any mailbox delay therefore
    // stays in the upper bound; no measured asynchronous work is subtracted.
    queued:=a.queuedAt;if b.queuedAt.After(queued){queued=b.queuedAt}
    remaining:=history.EndedAt.Add(rt.RematchCooldown).Sub(queued)
    if remaining>0{start=start.Add(remaining)}
    return start
}
