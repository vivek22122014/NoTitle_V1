package coordinator

import (
	"context"
	"crypto/sha256"
	"errors"
	"fmt"
	"runtime"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"notitle/internal/identity"
)

type guestClock struct { nanos atomic.Int64 }
func (c *guestClock) Now() time.Time { return time.Unix(0, c.nanos.Load()).UTC() }
func (c *guestClock) set(value time.Time) { c.nanos.Store(value.UnixNano()) }
func guestFixture(number int, now time.Time) identity.Guest {
	id := fmt.Sprintf("00000000-0000-4000-8000-%012d", number)
	return identity.Guest{
		ID: id, Generation: 1, Verifier: sha256.Sum256([]byte(id)),
		Profile: identity.Profile{DisplayName: "Guest Cedar", Gender: identity.GenderOther, Topic: "work_culture", Version: 1},
		Consent: identity.Consent{AdultConfirmed: true, Policies: identity.PolicyVersions{Terms: "v1", Privacy: "v1", Community: "v1"}},
		CreatedAt: now, LastSeenAt: now, AbsoluteExpiresAt: now.Add(identity.GuestAbsoluteTTL),
	}
}
func startGuestOwner(t *testing.T) (*Coordinator, *guestClock) {
	t.Helper()
	source := &guestClock{}
	source.set(time.Date(2026, 1, 2, 3, 4, 5, 0, time.UTC))
	ctx, cancel := context.WithCancel(context.Background())
	c := New(source)
	go func() { _ = c.Run(ctx) }()
	deadline := time.Now().Add(time.Second)
	for !c.Running() { if time.Now().After(deadline) { cancel(); t.Fatal("owner did not start") }; runtime.Gosched() }
	t.Cleanup(func() { cancel(); select { case <-c.Done(): case <-time.After(time.Second): t.Error("owner did not stop") } })
	return c, source
}
func bindingFor(g identity.Guest) identity.GuestCommit {
	return identity.GuestCommit{AccountID: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", AccountGeneration: 1, SessionID: "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb", Profile: g.Profile}
}

func TestGuestEntryValidationAndOptimisticProfileChange(t *testing.T) {
	c, clock := startGuestOwner(t)
	ctx := context.Background()
	for _, mutate := range []func(*identity.Guest){
		func(g *identity.Guest) { g.Profile.Gender = "" },
		func(g *identity.Guest) { g.Profile.Gender = "everyone" },
		func(g *identity.Guest) { g.Profile.DisplayName = "" },
		func(g *identity.Guest) { g.Consent.AdultConfirmed = false },
		func(g *identity.Guest) { g.Consent.Policies.Terms = "" },
		func(g *identity.Guest) { g.Verifier = identity.Verifier{} },
		func(g *identity.Guest) { g.AbsoluteExpiresAt = g.AbsoluteExpiresAt.Add(time.Minute) },
	} {
		g := guestFixture(1, clock.Now()); mutate(&g)
		if _, err := c.CreateGuest(ctx, g); !errors.Is(err, identity.ErrInvalid) { t.Fatalf("invalid guest accepted: %v", err) }
	}
	g := guestFixture(1, clock.Now())
	if _, err := c.CreateGuest(ctx, g); err != nil { t.Fatal(err) }
	if _, err := c.CreateGuest(ctx, g); !errors.Is(err, identity.ErrConflict) { t.Fatal("duplicate guest was accepted") }
	profile := g.Profile; profile.Bio = "A changed public bio"
	updated, err := c.UpdateGuest(ctx, g.Verifier, g.Generation, profile, clock.Now())
	if err != nil { t.Fatal(err) }
	if updated.Profile.Version != 2 || updated.Generation != 2 || updated.Profile.Gender != g.Profile.Gender { t.Fatal("profile did not preserve gender and advance guards") }
	if _, err := c.UpdateGuest(ctx, g.Verifier, updated.Generation, profile, clock.Now()); !errors.Is(err, identity.ErrStale) { t.Fatal("stale profile version overwrote an update") }
	profile = updated.Profile; profile.Gender = ""
	if _, err := c.UpdateGuest(ctx, g.Verifier, updated.Generation, profile, clock.Now()); !errors.Is(err, identity.ErrInvalid) { t.Fatal("gender was cleared") }
}

func TestGuestIdleExpiryActivityAndAbsoluteLimit(t *testing.T) {
	for _, touch := range []bool{false, true} {
		t.Run(fmt.Sprint(touch), func(t *testing.T) {
			c, clock := startGuestOwner(t); ctx := context.Background(); initial := clock.Now()
			g := guestFixture(1, initial)
			if _, err := c.CreateGuest(ctx, g); err != nil { t.Fatal(err) }
			clock.set(initial.Add(29 * time.Minute))
			if _, err := c.AuthenticateGuest(ctx, g.Verifier, clock.Now(), touch); err != nil { t.Fatal(err) }
			clock.set(initial.Add(identity.GuestIdleTTL))
			_, err := c.AuthenticateGuest(ctx, g.Verifier, clock.Now(), false)
			if !touch && !errors.Is(err, identity.ErrUnauthorized) { t.Fatal("a read extended the idle lease") }
			if touch && err != nil { t.Fatal("authorized activity did not extend the idle lease") }
		})
	}
	c, clock := startGuestOwner(t); ctx := context.Background(); initial := clock.Now(); g := guestFixture(2, initial)
	if _, err := c.CreateGuest(ctx, g); err != nil { t.Fatal(err) }
	for elapsed := 29 * time.Minute; elapsed < identity.GuestAbsoluteTTL; elapsed += 29 * time.Minute {
		clock.set(initial.Add(elapsed))
		if _, err := c.AuthenticateGuest(ctx, g.Verifier, clock.Now(), true); err != nil { t.Fatal(err) }
	}
	clock.set(initial.Add(identity.GuestAbsoluteTTL))
	if _, err := c.AuthenticateGuest(ctx, g.Verifier, clock.Now(), true); !errors.Is(err, identity.ErrUnauthorized) { t.Fatal("activity exceeded the absolute lifetime") }
	state, err := c.Snapshot(ctx)
	if err != nil || state.Guests != 0 || state.ParticipantSlots != 0 { t.Fatal("expired guest state was not removed") }
}

func TestGuestHandoffActorFreezesRotatesAndRejectsStaleCompletion(t *testing.T) {
	c, clock := startGuestOwner(t); ctx := context.Background(); g := guestFixture(1, clock.Now())
	if _, err := c.CreateGuest(ctx, g); err != nil { t.Fatal(err) }
	lease, err := c.PrepareGuestHandoff(ctx, g.Verifier, g.Generation, clock.Now())
	if err != nil { t.Fatal(err) }
	if _, err := c.AuthenticateGuest(ctx, g.Verifier, clock.Now(), true); !errors.Is(err, identity.ErrBusy) { t.Fatal("reserved guest was not frozen") }
	if _, err := c.UpdateGuest(ctx, g.Verifier, g.Generation, g.Profile, clock.Now()); !errors.Is(err, identity.ErrBusy) { t.Fatal("reserved guest profile changed") }
	if ok, err := c.CommitGuestHandoff(ctx, lease, bindingFor(g), clock.Now()); err != nil || !ok { t.Fatalf("handoff failed: %v", err) }
	if _, err := c.AuthenticateGuest(ctx, g.Verifier, clock.Now(), false); !errors.Is(err, identity.ErrUnauthorized) { t.Fatal("guest credential survived registration") }
	if err := c.AbortGuestHandoff(ctx, lease, true, clock.Now()); err != nil { t.Fatal(err) }
	state, err := c.Snapshot(ctx)
	if err != nil || state.Guests != 0 || state.Handoffs != 0 || state.ParticipantSlots != 1 { t.Fatal("stale abort changed committed identity") }
	if ok, err := c.CommitGuestHandoff(ctx, lease, bindingFor(g), clock.Now()); err != nil || ok { t.Fatal("stale commit created an identity") }
}

func TestGuestHandoffRollbackEndAndExpiryCannotResurrect(t *testing.T) {
	for _, outcome := range []string{"safe_abort", "ambiguous_abort", "end", "lease_expiry"} {
		t.Run(outcome, func(t *testing.T) {
			c, clock := startGuestOwner(t); ctx := context.Background(); g := guestFixture(1, clock.Now())
			if _, err := c.CreateGuest(ctx, g); err != nil { t.Fatal(err) }
			lease, err := c.PrepareGuestHandoff(ctx, g.Verifier, g.Generation, clock.Now()); if err != nil { t.Fatal(err) }
			switch outcome {
			case "safe_abort": err = c.AbortGuestHandoff(ctx, lease, true, clock.Now())
			case "ambiguous_abort": err = c.AbortGuestHandoff(ctx, lease, false, clock.Now())
			case "end": err = c.EndGuest(ctx, g.Verifier, clock.Now())
			case "lease_expiry": clock.set(lease.ExpiresAt)
			}
			if err != nil { t.Fatal(err) }
			_, err = c.AuthenticateGuest(ctx, g.Verifier, clock.Now(), false)
			if outcome == "safe_abort" { if err != nil { t.Fatal("known rollback did not preserve guest") } } else if !errors.Is(err, identity.ErrUnauthorized) { t.Fatal("ended guest remained authorized") }
			if ok, err := c.CommitGuestHandoff(ctx, lease, bindingFor(g), clock.Now()); err != nil || ok { t.Fatal("late database completion resurrected a slot") }
		})
	}
}

func TestGuestCarryIndexesStayOnSameSlotAndGuestExpiryPurgesReverseIndexes(t *testing.T) {
	// Synthetic indexes test ownership only. Phase 3 does not implement friend,
	// block, matchmaking, or durable relationship admission.
	m := newGuestMemory(); now := time.Date(2026, 1, 2, 3, 4, 5, 0, time.UTC)
	a, b, blocked := guestFixture(1, now), guestFixture(2, now), guestFixture(3, now)
	for _, guest := range []identity.Guest{a, b, blocked} { if r := m.apply(guestRequest{op: guestCreate, guest: guest}, now); r.err != nil { t.Fatal(r.err) } }
	slot := m.slots[a.ID]
	slot.carry = slotCarry{acceptedLinks: map[string]string{b.ID: "temporary-reference"}, blocks: map[string]struct{}{blocked.ID: {}}, restrictions: map[string]struct{}{"safety-hold": {}}, recentPairs: map[string]time.Time{b.ID: now}}
	m.slots[b.ID].carry.acceptedLinks = map[string]string{a.ID: "temporary-reference"}
	lease := m.apply(guestRequest{op: guestPrepare, verifier: a.Verifier, generation: a.Generation, reservationID: "opaque-lease"}, now).reservation
	if r := m.apply(guestRequest{op: guestCommit, reservation: lease, commit: bindingFor(a)}, now); r.err != nil || !r.committed { t.Fatal("handoff failed") }
	if m.slots[a.ID] != slot || slot.guestID != "" || slot.carry.acceptedLinks[b.ID] != "temporary-reference" || len(slot.carry.blocks) != 1 || len(slot.carry.restrictions) != 1 || len(slot.carry.recentPairs) != 1 || m.slots[b.ID].carry.acceptedLinks[a.ID] == "" { t.Fatal("rebind lost slot identity or carry state") }
	// An accepted link alone never extends b's TTL. The account slot is kept
	// recently active here solely to inspect reverse-index removal afterward.
	slot.lastSeenAt = now.Add(29 * time.Minute)
	m.expire(now.Add(identity.GuestIdleTTL))
	if len(m.byVerifier) != 0 || len(slot.carry.acceptedLinks) != 0 || len(slot.carry.blocks) != 0 || len(slot.carry.recentPairs) != 0 { t.Fatal("guest expiry left stale peer references") }
}

func TestLogoutPreservesTemporaryLinksButDeletionRemovesThem(t *testing.T) {
	m := newGuestMemory(); now := time.Date(2026, 1, 2, 3, 4, 5, 0, time.UTC)
	a, b := guestFixture(1, now), guestFixture(2, now)
	for _, g := range []identity.Guest{a, b} { if r := m.apply(guestRequest{op: guestCreate, guest: g}, now); r.err != nil { t.Fatal(r.err) } }
	slot := m.slots[a.ID]
	slot.carry.acceptedLinks = map[string]string{b.ID: "temporary-reference"}
	m.slots[b.ID].carry.acceptedLinks = map[string]string{a.ID: "temporary-reference"}
	lease := m.apply(guestRequest{op: guestPrepare, verifier: a.Verifier, generation: 1, reservationID: "lease"}, now).reservation
	binding := bindingFor(a)
	if r := m.apply(guestRequest{op: guestCommit, reservation: lease, commit: binding}, now); !r.committed { t.Fatal("registration failed") }
	if r := m.apply(guestRequest{op: sessionInvalidate, accountID: binding.AccountID, sessionID: "unrelated-session"}, now); r.err != nil || slot.sessionID == "" { t.Fatal("unrelated logout replaced the active session") }
	if r := m.apply(guestRequest{op: sessionInvalidate, accountID: binding.AccountID, sessionID: binding.SessionID}, now); r.err != nil { t.Fatal(r.err) }
	if slot.sessionID != "" || slot.carry.acceptedLinks[b.ID] == "" || m.slots[b.ID].carry.acceptedLinks[a.ID] == "" { t.Fatal("logout removed consented temporary links") }
	// The guest remains active, so the account's unbound slot may continue to
	// own its temporary link without granting an authenticated session.
	bEntry := m.byVerifier[b.Verifier]
	bEntry.guest.LastSeenAt = now.Add(29 * time.Minute)
	bEntry.slot.lastSeenAt = bEntry.guest.LastSeenAt
	m.expire(now.Add(31 * time.Minute))
	if m.slots[a.ID] != slot { t.Fatal("dormant account discarded a living guest dependency") }
	if r := m.apply(guestRequest{op: accountRemove, accountID: binding.AccountID}, now.Add(31 * time.Minute)); r.err != nil { t.Fatal(r.err) }
	if m.slots[a.ID] != nil || len(m.slots[b.ID].carry.acceptedLinks) != 0 { t.Fatal("deletion left an account slot or peer link") }
}

func TestGuestCapacityAndReservationBound(t *testing.T) {
	m := newGuestMemory(); now := time.Date(2026, 1, 2, 3, 4, 5, 0, time.UTC)
	for i := 1; i <= GuestCapacity; i++ {
		if r := m.apply(guestRequest{op: guestCreate, guest: guestFixture(i, now)}, now); r.err != nil { t.Fatal(r.err) }
	}
	if r := m.apply(guestRequest{op: guestCreate, guest: guestFixture(GuestCapacity + 1, now)}, now); !errors.Is(r.err, identity.ErrCapacity) { t.Fatal("unbounded guest admission") }
	for i := 1; i <= HandoffCapacity; i++ {
		g := guestFixture(i, now)
		if r := m.apply(guestRequest{op: guestPrepare, verifier: g.Verifier, generation: g.Generation, reservationID: fmt.Sprintf("lease-%d", i)}, now); r.err != nil { t.Fatal(r.err) }
	}
	g := guestFixture(HandoffCapacity + 1, now)
	if r := m.apply(guestRequest{op: guestPrepare, verifier: g.Verifier, generation: g.Generation, reservationID: "one-too-many"}, now); !errors.Is(r.err, identity.ErrCapacity) { t.Fatal("unbounded handoff admission") }
	m.expire(now.Add(identity.HandoffTTL))
	if m.handoffs != 0 || len(m.byVerifier) != GuestCapacity-HandoffCapacity { t.Fatal("lease expiry did not free bounded memory") }
	if LaunchLimits() != (Limits{Connected: 200, Waiting: 100, AudioCalls: 25}) { t.Fatal("identity capacity changed connected/call targets") }
}

func TestGuestCommandsRejectCanceledStoppedAndOverflow(t *testing.T) {
	c := New(fixedClock{})
	if _, err := c.CreateGuest(context.Background(), identity.Guest{}); !errors.Is(err, ErrNotRunning) { t.Fatal("unstarted owner admitted identity") }
	c.running.Store(true)
	for range MailboxCapacity { c.guestRequests <- guestRequest{} }
	if _, err := c.CreateGuest(context.Background(), identity.Guest{}); !errors.Is(err, ErrOverloaded) { t.Fatal("identity mailbox overflow did not fail promptly") }
	ctx, cancel := context.WithCancel(context.Background()); cancel()
	if _, err := c.CreateGuest(ctx, identity.Guest{}); !errors.Is(err, context.Canceled) { t.Fatal("canceled command was admitted") }
}

func TestConcurrentGuestEditsHaveOneWinner(t *testing.T) {
	c, clock := startGuestOwner(t); ctx := context.Background(); g := guestFixture(1, clock.Now())
	if _, err := c.CreateGuest(ctx, g); err != nil { t.Fatal(err) }
	var workers sync.WaitGroup
	var successes atomic.Int64
	for range 32 {
		workers.Add(1)
		go func() {
			defer workers.Done()
			profile := g.Profile; profile.Bio = "One concurrent change"
			_, err := c.UpdateGuest(ctx, g.Verifier, g.Generation, profile, clock.Now())
			if err == nil { successes.Add(1) } else if !errors.Is(err, identity.ErrStale) { t.Errorf("unexpected edit error: %v", err) }
		}()
	}
	workers.Wait()
	if successes.Load() != 1 { t.Fatalf("expected one guarded write, got %d", successes.Load()) }
	updated, err := c.AuthenticateGuest(ctx, g.Verifier, clock.Now(), false)
	if err != nil || updated.Profile.Version != 2 { t.Fatal("concurrent requests lost version serialization") }
}

func TestInvalidHandoffAndRestartDoNotReviveGuest(t *testing.T) {
	c, clock := startGuestOwner(t); ctx := context.Background(); g := guestFixture(1, clock.Now())
	if _, err := c.CreateGuest(ctx, g); err != nil { t.Fatal(err) }
	lease, err := c.PrepareGuestHandoff(ctx, g.Verifier, g.Generation, clock.Now()); if err != nil { t.Fatal(err) }
	stale := lease; stale.Guest.Generation++
	if err := c.AbortGuestHandoff(ctx, stale, true, clock.Now()); err != nil { t.Fatal(err) }
	if _, err := c.AuthenticateGuest(ctx, g.Verifier, clock.Now(), false); !errors.Is(err, identity.ErrBusy) { t.Fatal("stale abort released another reservation") }
	binding := bindingFor(g); binding.Profile.Gender = identity.GenderMale
	if ok, err := c.CommitGuestHandoff(ctx, lease, binding, clock.Now()); ok || !errors.Is(err, identity.ErrInvalid) { t.Fatal("registration changed the confirmed guest gender") }
	if _, err := c.AuthenticateGuest(ctx, g.Verifier, clock.Now(), false); !errors.Is(err, identity.ErrUnauthorized) { t.Fatal("invalid handoff left guest access active") }
	freshOwner, _ := startGuestOwner(t)
	if _, err := freshOwner.AuthenticateGuest(ctx, g.Verifier, clock.Now(), false); !errors.Is(err, identity.ErrUnauthorized) { t.Fatal("fresh process reconstructed guest memory") }
}

func TestProfessionalInterestSlicesCannotEscapeCoordinatorOwnership(t *testing.T) {
	c, clock := startGuestOwner(t)
	ctx := context.Background()
	choices := identity.Vocabularies().Interests
	if len(choices) < 2 { t.Fatal("controlled interests require independent fixture choices") }
	first, second := choices[0].Value, choices[1].Value
	g := guestFixture(1, clock.Now())
	g.Profile.Professional.Interests = []string{first}
	created, err := c.CreateGuest(ctx, g)
	if err != nil { t.Fatal(err) }
	// Input and output slices must each be detached from the actor.
	g.Profile.Professional.Interests[0] = second
	created.Profile.Professional.Interests[0] = second
	current, err := c.AuthenticateGuest(ctx, g.Verifier, clock.Now(), false)
	if err != nil || current.Profile.Professional.Interests[0] != first { t.Fatal("creation leaked an interest slice") }
	current.Profile.Professional.Interests[0] = second
	unchanged, err := c.AuthenticateGuest(ctx, g.Verifier, clock.Now(), false)
	if err != nil || unchanged.Profile.Professional.Interests[0] != first { t.Fatal("authentication returned actor-owned memory") }
	updated, err := c.UpdateGuest(ctx, g.Verifier, current.Generation, current.Profile, clock.Now())
	if err != nil { t.Fatal(err) }
	current.Profile.Professional.Interests[0] = first
	updated.Profile.Professional.Interests[0] = first
	stored, err := c.AuthenticateGuest(ctx, g.Verifier, clock.Now(), false)
	if err != nil || stored.Profile.Professional.Interests[0] != second { t.Fatal("profile mutation shared a slice with the actor") }
	lease, err := c.PrepareGuestHandoff(ctx, g.Verifier, stored.Generation, clock.Now())
	if err != nil { t.Fatal(err) }
	lease.Guest.Profile.Professional.Interests[0] = first
	if err := c.AbortGuestHandoff(ctx, lease, true, clock.Now()); err != nil { t.Fatal(err) }
	resumed, err := c.AuthenticateGuest(ctx, g.Verifier, clock.Now(), false)
	if err != nil || resumed.Profile.Professional.Interests[0] != second { t.Fatal("reservation exposed actor-owned profile memory") }
	// Commit input and reservation input cross the same mailbox boundary.
	// Check both nested objects, including preserving an explicit empty slice.
	binding := bindingFor(g)
	req := cloneGuestRequest(guestRequest{commit: binding, reservation: lease})
	binding.Profile.Professional.Interests[0] = first
	lease.Guest.Profile.Professional.Interests[0] = second
	if req.commit.Profile.Professional.Interests[0] != second || req.reservation.Guest.Profile.Professional.Interests[0] != first { t.Fatal("handoff mailbox retained caller-owned interest slices") }
	empty := cloneProfile(identity.Profile{Professional: identity.ProfessionalProfile{Interests: []string{}}})
	if empty.Professional.Interests == nil { t.Fatal("explicitly cleared interests lost their empty representation") }
}
