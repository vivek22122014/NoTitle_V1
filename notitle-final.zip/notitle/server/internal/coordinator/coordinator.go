// Package coordinator owns all temporary identities and realtime matching in
// one bounded control loop, including text, connections and accepted audio.
// Configured limits are required targets, not measured capacity.
package coordinator

import (
	"context"
	"crypto/rand"
	"errors"
	"net/netip"
	"sync/atomic"
	"time"

	"notitle/internal/platform/clock"
	"notitle/internal/identity"
 "notitle/internal/performance"
)

const MailboxCapacity = 128
var (
	ErrNotRunning = errors.New("coordinator is not running")
	ErrOverloaded = errors.New("coordinator mailbox is full")
	ErrAlreadyStarted = errors.New("coordinator has already started")
)

type Limits struct {
	Connected int
	Waiting int
	AudioCalls int
}

// Waiting users and both parties in audio calls count within Connected.
// These limits are required load-test targets, not measured capacity claims.
func LaunchLimits() Limits {
	return Limits{Connected: 200, Waiting: 100, AudioCalls: 25}
}

type Snapshot struct {
	Limits Limits
	StartedAt time.Time
	Guests int
	Handoffs int
	ParticipantSlots int
	Connected int
	Retained int
	Waiting int
	Interactions int
	AuthorizationFence uint64
	AudioCalls int
	AudioCleanup int
 Processing performance.Snapshot
 Maintenance bool
 DrainDeadline time.Time
 MatchMetrics MatchMetrics
}

type request struct {
	ctx context.Context
	reply chan Snapshot
}

type Coordinator struct {
	clock clock.Clock
 processing *performance.Recorder
	requests chan request
	guestRequests chan guestRequest
	realtimeRequests chan realtimeRequest
	controlRequests chan realtimeRequest
	priorityRequests chan guestRequest
	safetyRequests chan safetyRequest
	friendRequests chan friendRequest
	audioRequests chan audioRequest
	audioAddresses []netip.Addr
	instanceSecret [32]byte
	initErr error
	started atomic.Bool
	running atomic.Bool
	failClosed atomic.Bool
 maintenanceStartup atomic.Bool
	safetyEnabled atomic.Bool
	premiumEnabled atomic.Bool
	friendLimit atomic.Int64
	done chan struct{}
}

func New(source clock.Clock) *Coordinator {
	c := &Coordinator{audioRequests: make(chan audioRequest, MailboxCapacity), friendRequests: make(chan friendRequest, MailboxCapacity), safetyRequests: make(chan safetyRequest, MailboxCapacity), clock: source, requests: make(chan request, MailboxCapacity), guestRequests: make(chan guestRequest, MailboxCapacity), priorityRequests: make(chan guestRequest, MailboxCapacity), realtimeRequests: make(chan realtimeRequest, MailboxCapacity), controlRequests: make(chan realtimeRequest, MailboxCapacity), done: make(chan struct{})}
	_, c.initErr = rand.Read(c.instanceSecret[:])
 c.processing=performance.New()
	return c
}

// Run must have exactly one owner. All future ephemeral state transitions belong
// in this select loop. Never perform database, network, or provider IO here.
func (c *Coordinator) Run(ctx context.Context) error {
	if !c.started.CompareAndSwap(false, true) {
		return ErrAlreadyStarted
	}
	defer close(c.done)
	if c.initErr != nil { return c.initErr }
	if err := ctx.Err(); err != nil {
		return err
	}
	snapshot := Snapshot{Limits: LaunchLimits(), StartedAt: c.clock.Now()}
	guests := newGuestMemory()
	live := newLiveMemory(c.instanceSecret, guests)
 live.processing=c.processing
	live.stop = c.failClosed.Load
 live.maintenance = c.maintenanceStartup.Load()
 if live.maintenance { live.drainDeadline = c.clock.Now() }
	live.safetyEnabled = c.safetyEnabled.Load()
	live.premium.enabled = c.premiumEnabled.Load()
	live.audio.addresses = append([]netip.Addr(nil), c.audioAddresses...)
	live.audio.enabled = len(live.audio.addresses) > 0
	if limit := c.friendLimit.Load(); limit > 0 && limit <= 100 { live.friendLimit = int(limit) }
	defer live.shutdown()
	ticker := time.NewTicker(100 * time.Millisecond)
	defer ticker.Stop()
	c.running.Store(true)
	defer c.running.Store(false)
	for {
		// Prefer stopping over accepting more commands after cancellation.
		if err := ctx.Err(); err != nil {
			return err
		}
		if c.failClosed.Load() { live.latchClosed(c.clock.Now()) }
		// Safety revocation cannot sit behind a burst of queue/Next commands.
		select { case req := <-c.safetyRequests: c.applySafety(guests, live, req); continue; default: }
		select { case req := <-c.priorityRequests: c.applyGuest(guests, live, req); continue; default: }
		select { case req := <-c.audioRequests: c.applyAudio(live, req); continue; default: }
		select { case req := <-c.friendRequests: c.applyFriend(guests, live, req); continue; default: }
		select { case req := <-c.controlRequests: c.applyRealtime(guests, live, req); continue; default: }
		select {
		case <-ctx.Done():
			return ctx.Err()
		case req := <-c.safetyRequests:
			c.applySafety(guests, live, req)
		case req := <-c.friendRequests:
			c.applyFriend(guests, live, req)
		case req := <-c.audioRequests:
			c.applyAudio(live, req)
		case req := <-c.requests:
			if req.ctx.Err() != nil {
				continue
			}
			guests.expire(c.clock.Now())
			if c.failClosed.Load() { live.latchClosed(c.clock.Now()) }
			live.maintain(c.clock.Now())
			snapshot.Guests = len(guests.byVerifier)
			snapshot.Handoffs = guests.handoffs
			snapshot.ParticipantSlots = len(guests.slots)
			snapshot.Connected = live.connected()
			snapshot.Retained = len(live.participants)
			snapshot.Waiting = len(live.waiting)
			snapshot.Interactions = len(live.interactions)
			snapshot.AuthorizationFence = live.fence
			snapshot.AudioCalls, snapshot.AudioCleanup = live.audioCounts()
   snapshot.Maintenance, snapshot.DrainDeadline = live.maintenance, live.drainDeadline
 snapshot.MatchMetrics = live.aggregateMetrics()
 snapshot.Processing = c.processing.Snapshot()
			req.reply <- snapshot // one-element reply channel: owner never blocks
		case req := <-c.guestRequests:
			c.applyGuest(guests, live, req)
		case req := <-c.priorityRequests:
			c.applyGuest(guests, live, req)
		case req := <-c.realtimeRequests:
			c.applyRealtime(guests, live, req)
		case req := <-c.controlRequests:
			c.applyRealtime(guests, live, req)
		case <-ticker.C:
			guests.expire(c.clock.Now())
			if c.failClosed.Load() { live.latchClosed(c.clock.Now()) }
			live.maintain(c.clock.Now())
		}
	}
}

func (c *Coordinator) applyRealtime(guests *guestMemory, live *liveMemory, req realtimeRequest) {
	if err := req.ctx.Err(); err != nil { req.reply <- realtimeResult{err: err}; return }
 live.operationStarted=req.receivedAt;defer func(){live.operationStarted=time.Time{}}()
	now := c.clock.Now()
	if c.failClosed.Load() { live.latchClosed(now) }
	guests.expire(now)
	live.now = now
	if req.op == opOutage || req.op == opProfile || req.op == opPreferences || req.op == opRefresh || req.op == opSetGuestPreferences || isPremiumOperation(req.op) {
		result := live.apply(req, now)
		live.maintain(now)
		req.reply <- result
		return
	}
	live.maintain(now)
 result:=live.apply(req, now)
 if req.op==opCommand&&req.command.Type=="chat.send"&&result.err==nil&&!req.receivedAt.IsZero(){c.processing.Message(time.Since(req.receivedAt))}
 req.reply <- result
}

func (c *Coordinator) applyGuest(guests *guestMemory, live *liveMemory, req guestRequest) {
	if req.ctx.Err() != nil { return }
	now := c.clock.Now()
	if c.failClosed.Load() { live.latchClosed(now) }
	guests.expire(now)
	// Advance before an invalidation, even when no live slot exists. External
	// authorization begun earlier may never publish after this point.
	if req.op != guestAuthenticate && req.op != guestCreate { live.fence++ }
	if c.safetyEnabled.Load() && req.op == guestPrepare && (guests.handoffs != 0 || len(live.safety.handoffs) >= HandoffCapacity) { req.reply <- guestResult{err: identity.ErrBusy}; return }
    result := guests.apply(req, now)
	live.identityChange(req, result, now)
	live.maintain(now)
	req.reply <- cloneGuestResult(result)
}

func (c *Coordinator) Snapshot(ctx context.Context) (Snapshot, error) {
	if err := ctx.Err(); err != nil {
		return Snapshot{}, err
	}
	if !c.running.Load() {
		return Snapshot{}, ErrNotRunning
	}
	req := request{ctx: ctx, reply: make(chan Snapshot, 1)}
	select {
	case <-ctx.Done():
		return Snapshot{}, ctx.Err()
	case <-c.done:
		return Snapshot{}, ErrNotRunning
	case c.requests <- req:
	default:
		return Snapshot{}, ErrOverloaded
	}
	select {
	case <-ctx.Done():
		return Snapshot{}, ctx.Err()
	case <-c.done:
		return Snapshot{}, ErrNotRunning
	case state := <-req.reply:
		return state, nil
	}
}

func (c *Coordinator) Ready(ctx context.Context) error {
	if c.failClosed.Load() { return ErrNotRunning }
	_, err := c.Snapshot(ctx)
	return err
}

// FailClosed is the last-resort invalidation barrier. It cannot fail because a
// mailbox is full, and a healthy database probe cannot clear it. Restart after
// the durable state has been reconciled is the only recovery path.
func (c *Coordinator) FailClosed() { c.failClosed.Store(true) }
func (c *Coordinator) Running() bool {
	return c.running.Load()
}
func (c *Coordinator) Done() <-chan struct{} {
	return c.done
}
func(c *Coordinator)ProcessingRecorder()*performance.Recorder{return c.processing}
func(c *Coordinator)ProcessingSnapshot(ctx context.Context)(performance.Export,error){if err:=ctx.Err();err!=nil{return performance.Export{},err};if !c.running.Load(){return performance.Export{},ErrNotRunning};return c.processing.Export(),nil}

// EnableSafety is a trusted startup setting, never a user-controlled capability.
func (c *Coordinator) EnableSafety() { c.safetyEnabled.Store(true) }
// StartInMaintenance is startup-only. Opening admission later requires the
// separately audited private operator workflow and current launch evidence.
func (c *Coordinator) StartInMaintenance() { if !c.started.Load() { c.maintenanceStartup.Store(true) } }
func (c *Coordinator) SafetyHandoffRequired() bool { return c.safetyEnabled.Load() }

// EnableFriends sets the trusted startup cap for new mutual connections.
func (c *Coordinator) EnableFriends(limit int) { if !c.started.Load() && limit >= 1 && limit <= 100 { c.friendLimit.Store(int64(limit)) } }

// EnableAudio is startup-only; supervisor readiness is a separate live gate.
func (c *Coordinator) EnableAudio(addresses []netip.Addr) { if !c.started.Load() { c.audioAddresses = append([]netip.Addr(nil), addresses...) } }
