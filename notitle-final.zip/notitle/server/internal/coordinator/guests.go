package coordinator

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"time"

	"notitle/internal/identity"
)

// Memory sessions are separate from connected participants: creating a guest
// does not open a socket or consume one of the 200 future connection slots.
const GuestCapacity = 1000
const HandoffCapacity = 64
const ParticipantSlotCapacity = 1000

type guestOperation uint8
const (
	guestCreate guestOperation = iota
	guestAuthenticate
	guestUpdate
	guestEnd
	guestPrepare
	guestCommit
	guestAbort
	accountInvalidate
	sessionInvalidate
	accountRemove
)

type guestRequest struct {
	ctx context.Context
	op guestOperation
	guest identity.Guest
	verifier identity.Verifier
	generation int64
	profile identity.Profile
	reservation identity.GuestReservation
	commit identity.GuestCommit
	accountID string
	sessionID string
	touch bool
	safeToResume bool
	reservationID string
	reply chan guestResult
}
type guestResult struct {
	guest identity.Guest
	reservation identity.GuestReservation
	committed bool
	err error
}

// participantSlot is identity-independent ownership. Rebinding this object in
// place preserves safety/relationship indexes when their later phases attach
// them. No relationship, matching, or media operation is exposed in Phase 3.
type participantSlot struct {
	id string
	generation int64
	guestID string
	accountID string
	accountGeneration int64
	sessionID string
	lastSeenAt time.Time
	profile identity.Profile
	carry slotCarry
}
type slotCarry struct {
	// These indexes have no production admission path until the relationship
	// and safety phases. They are keyed by stable slot ID, never by cookie.
	acceptedLinks map[string]string
	blocks map[string]struct{}
	restrictions map[string]struct{}
	recentPairs map[string]time.Time
}
type guestEntry struct {
	guest identity.Guest
	slot *participantSlot
	reservation *identity.GuestReservation
}
type guestMemory struct {
	byVerifier map[identity.Verifier]*guestEntry
	slots map[string]*participantSlot
	handoffs int
}
func newGuestMemory() *guestMemory {
	return &guestMemory{byVerifier: make(map[identity.Verifier]*guestEntry), slots: make(map[string]*participantSlot)}
}

var _ identity.GuestRegistry = (*Coordinator)(nil)

func (c *Coordinator) guestCommand(ctx context.Context, req guestRequest) (guestResult, error) {
	if err := ctx.Err(); err != nil { return guestResult{}, err }
	if !c.running.Load() { return guestResult{}, ErrNotRunning }
	// Copy mutable input before it crosses the mailbox. The caller may reuse
	// its slices after this command returns without changing actor state.
	req = cloneGuestRequest(req)
	req.ctx = ctx
	req.reply = make(chan guestResult, 1)
	mailbox := c.guestRequests
	if req.op == accountInvalidate || req.op == sessionInvalidate || req.op == accountRemove || req.op == guestEnd { mailbox = c.priorityRequests }
	select {
	case <-ctx.Done(): return guestResult{}, ctx.Err()
	case <-c.done: return guestResult{}, ErrNotRunning
	case mailbox <- req:
	default: return guestResult{}, ErrOverloaded
	}
	select {
	case <-ctx.Done(): return guestResult{}, ctx.Err()
	case <-c.done: return guestResult{}, ErrNotRunning
	case result := <-req.reply: return result, result.err
	}
}

func cloneProfile(profile identity.Profile) identity.Profile {
	if profile.Professional.Interests != nil {
		interests := make([]string, len(profile.Professional.Interests))
		copy(interests, profile.Professional.Interests)
		profile.Professional.Interests = interests
	}
	return profile
}
func cloneGuest(guest identity.Guest) identity.Guest {
	guest.Profile = cloneProfile(guest.Profile)
	return guest
}
func cloneReservation(reservation identity.GuestReservation) identity.GuestReservation {
	reservation.Guest = cloneGuest(reservation.Guest)
	return reservation
}
func cloneGuestRequest(req guestRequest) guestRequest {
	req.guest = cloneGuest(req.guest)
	req.profile = cloneProfile(req.profile)
	req.reservation = cloneReservation(req.reservation)
	req.commit.Profile = cloneProfile(req.commit.Profile)
	return req
}
func cloneGuestResult(result guestResult) guestResult {
	result.guest = cloneGuest(result.guest)
	result.reservation = cloneReservation(result.reservation)
	return result
}
func (c *Coordinator) CreateGuest(ctx context.Context, guest identity.Guest) (identity.Guest, error) {
	r, err := c.guestCommand(ctx, guestRequest{op: guestCreate, guest: guest})
	return r.guest, err
}
func (c *Coordinator) AuthenticateGuest(ctx context.Context, hash identity.Verifier, _ time.Time, touch bool) (identity.Guest, error) {
	r, err := c.guestCommand(ctx, guestRequest{op: guestAuthenticate, verifier: hash, touch: touch})
	return r.guest, err
}
func (c *Coordinator) UpdateGuest(ctx context.Context, hash identity.Verifier, generation int64, profile identity.Profile, _ time.Time) (identity.Guest, error) {
	r, err := c.guestCommand(ctx, guestRequest{op: guestUpdate, verifier: hash, generation: generation, profile: profile})
	return r.guest, err
}
func (c *Coordinator) EndGuest(ctx context.Context, hash identity.Verifier, _ time.Time) error {
	_, err := c.guestCommand(ctx, guestRequest{op: guestEnd, verifier: hash})
	return err
}
func (c *Coordinator) PrepareGuestHandoff(ctx context.Context, hash identity.Verifier, generation int64, _ time.Time) (identity.GuestReservation, error) {
	var random [16]byte
	if _, err := rand.Read(random[:]); err != nil { return identity.GuestReservation{}, identity.ErrUnavailable }
	r, err := c.guestCommand(ctx, guestRequest{op: guestPrepare, verifier: hash, generation: generation, reservationID: hex.EncodeToString(random[:])})
	return r.reservation, err
}
func (c *Coordinator) CommitGuestHandoff(ctx context.Context, reservation identity.GuestReservation, commit identity.GuestCommit, _ time.Time) (bool, error) {
	r, err := c.guestCommand(ctx, guestRequest{op: guestCommit, reservation: reservation, commit: commit})
	return r.committed, err
}
func (c *Coordinator) AbortGuestHandoff(ctx context.Context, reservation identity.GuestReservation, safeToResume bool, _ time.Time) error {
	_, err := c.guestCommand(ctx, guestRequest{op: guestAbort, reservation: reservation, safeToResume: safeToResume})
	return err
}
func (c *Coordinator) InvalidateAccount(ctx context.Context, accountID string, _ time.Time) error {
	_, err := c.guestCommand(ctx, guestRequest{op: accountInvalidate, accountID: accountID})
	return err
}
func (c *Coordinator) InvalidateSession(ctx context.Context, accountID, sessionID string, _ time.Time) error {
	_, err := c.guestCommand(ctx, guestRequest{op: sessionInvalidate, accountID: accountID, sessionID: sessionID})
	return err
}
func (c *Coordinator) RemoveAccount(ctx context.Context, accountID string, _ time.Time) error {
	_, err := c.guestCommand(ctx, guestRequest{op: accountRemove, accountID: accountID})
	return err
}

func (m *guestMemory) apply(req guestRequest, now time.Time) guestResult {
	switch req.op {
	case guestCreate:
		g := req.guest
		if !validGuestRecord(g, now) { return guestResult{err: identity.ErrInvalid} }
		if _, ok := m.byVerifier[g.Verifier]; ok { return guestResult{err: identity.ErrConflict} }
		if _, ok := m.slots[g.ID]; ok { return guestResult{err: identity.ErrConflict} }
		if len(m.byVerifier) >= GuestCapacity || len(m.slots) >= ParticipantSlotCapacity { return guestResult{err: identity.ErrCapacity} }
		slot := &participantSlot{id: g.ID, generation: g.Generation, guestID: g.ID, lastSeenAt: g.LastSeenAt, profile: g.Profile}
		m.byVerifier[g.Verifier] = &guestEntry{guest: g, slot: slot}
		m.slots[slot.id] = slot
		return guestResult{guest: g}
	case guestAuthenticate, guestUpdate, guestPrepare:
		entry, ok := m.byVerifier[req.verifier]
		if !ok { return guestResult{err: identity.ErrUnauthorized} }
		if entry.reservation != nil { return guestResult{err: identity.ErrBusy} }
		if req.op != guestAuthenticate && entry.guest.Generation != req.generation { return guestResult{err: identity.ErrStale} }
		switch req.op {
		case guestAuthenticate:
			if req.touch { entry.guest.LastSeenAt = now; entry.slot.lastSeenAt = now }
			return guestResult{guest: entry.guest}
		case guestUpdate:
			if err := identity.ValidateProfile(req.profile); err != nil { return guestResult{err: err} }
			if req.profile.Version != entry.guest.Profile.Version { return guestResult{err: identity.ErrStale} }
			req.profile.Version++
			entry.guest.Profile = req.profile
			entry.guest.Generation++
			entry.guest.LastSeenAt = now
			entry.slot.profile = req.profile
			entry.slot.generation = entry.guest.Generation
			entry.slot.lastSeenAt = now
			return guestResult{guest: entry.guest}
		case guestPrepare:
			if m.handoffs >= HandoffCapacity { return guestResult{err: identity.ErrCapacity} }
			lease := identity.GuestReservation{ID: req.reservationID, Guest: entry.guest, ExpiresAt: now.Add(identity.HandoffTTL)}
			entry.reservation = &lease
			m.handoffs++
			return guestResult{reservation: lease}
		}
	case guestEnd:
		if entry, ok := m.byVerifier[req.verifier]; ok { m.removeGuest(entry, true) }
		return guestResult{}
	case guestCommit:
		entry := m.reservationEntry(req.reservation)
		if entry == nil { return guestResult{} } // committed account may continue at idle
		binding := req.commit
		if !validInternalID(binding.AccountID) || !validInternalID(binding.SessionID) || binding.AccountGeneration < 1 || binding.Profile.Version != 1 || identity.ValidateProfile(binding.Profile) != nil || binding.Profile.Gender != entry.guest.Profile.Gender {
			m.removeGuest(entry, true)
			return guestResult{err: identity.ErrInvalid}
		}
		slot := entry.slot
		// Only the reserved slot may be rebound. A vanished/replaced owner can
		// never be recreated by a delayed HTTP completion.
		if m.slots[slot.id] != slot || slot.generation != req.reservation.Guest.Generation || slot.guestID != entry.guest.ID {
			m.removeGuest(entry, true)
			return guestResult{}
		}
		m.removeGuest(entry, false)
		slot.guestID = ""
		slot.accountID = binding.AccountID
		slot.accountGeneration = binding.AccountGeneration
		slot.sessionID = binding.SessionID
		slot.generation++
		slot.profile = binding.Profile
		slot.lastSeenAt = now
		return guestResult{committed: true}
	case guestAbort:
		entry := m.reservationEntry(req.reservation)
		if entry == nil { return guestResult{} } // stale abort must not affect a later identity
		if !req.safeToResume { m.removeGuest(entry, true); return guestResult{} }
		entry.reservation = nil
		m.handoffs--
		return guestResult{}
	case accountInvalidate, sessionInvalidate, accountRemove:
		if !validInternalID(req.accountID) || (req.op == sessionInvalidate && !validInternalID(req.sessionID)) { return guestResult{err: identity.ErrInvalid} }
		for _, slot := range m.slots {
			if slot.accountID != req.accountID || (req.op == sessionInvalidate && slot.sessionID != req.sessionID) { continue }
			if req.op == accountRemove { m.removeSlot(slot.id); continue }
			// Logout ends the current binding, not the account's accepted
			// friendships. Phase 4 adds its socket/interaction teardown here.
			slot.sessionID = ""
			slot.generation++
			slot.lastSeenAt = now
		}
		return guestResult{}
	}
	return guestResult{err: identity.ErrInvalid}
}

func (m *guestMemory) reservationEntry(lease identity.GuestReservation) *guestEntry {
	entry := m.byVerifier[lease.Guest.Verifier]
	if entry == nil || entry.reservation == nil { return nil }
	current := entry.reservation
	if lease.ID != current.ID || lease.Guest.ID != current.Guest.ID || lease.Guest.Generation != current.Guest.Generation || !lease.ExpiresAt.Equal(current.ExpiresAt) { return nil }
	return entry
}
func (m *guestMemory) removeGuest(entry *guestEntry, removeSlot bool) {
	delete(m.byVerifier, entry.guest.Verifier)
	if entry.reservation != nil { entry.reservation = nil; m.handoffs-- }
	if removeSlot { m.removeSlot(entry.slot.id) }
}
func (m *guestMemory) removeSlot(id string) {
	delete(m.slots, id)
	// The finite slot set bounds cleanup work. Later friendship admission will
	// add its own per-identity caps and persistence; no guest index is durable.
	for _, peer := range m.slots {
		delete(peer.carry.acceptedLinks, id)
		delete(peer.carry.blocks, id)
		delete(peer.carry.recentPairs, id)
	}
}
func (m *guestMemory) expire(now time.Time) {
	for _, entry := range m.byVerifier {
		g := entry.guest
		if !now.Before(g.LastSeenAt.Add(identity.GuestIdleTTL)) || !now.Before(g.AbsoluteExpiresAt) || (entry.reservation != nil && !now.Before(entry.reservation.ExpiresAt)) {
			// An expired handoff is ambiguous: end the guest, never thaw a
			// credential whose account transaction may already have committed.
			m.removeGuest(entry, true)
		}
	}
	for _, slot := range m.slots {
		// A dormant account slot is only useful while it owns a temporary
		// reference to a living guest. Such a reference never renews that
		// guest's TTL. Persistent account relationships belong in PostgreSQL.
		if slot.accountID != "" && !now.Before(slot.lastSeenAt.Add(identity.GuestIdleTTL)) && !m.hasGuestDependencies(slot) { m.removeSlot(slot.id) }
		for peer, seen := range slot.carry.recentPairs { if !now.Before(seen.Add(5 * time.Minute)) { delete(slot.carry.recentPairs, peer) } }
	}
}
func (m *guestMemory) hasGuestDependencies(slot *participantSlot) bool {
	for id := range slot.carry.acceptedLinks { if peer := m.slots[id]; peer != nil && peer.guestID != "" { return true } }
	for id := range slot.carry.blocks { if peer := m.slots[id]; peer != nil && peer.guestID != "" { return true } }
	return false
}
func validGuestRecord(g identity.Guest, now time.Time) bool {
	if !validInternalID(g.ID) || g.Generation != 1 || g.Profile.Version != 1 || g.Verifier == (identity.Verifier{}) || identity.ValidateProfile(g.Profile) != nil || !g.Consent.AdultConfirmed { return false }
	p := g.Consent.Policies
	if !identity.ValidPolicyVersions(p) { return false }
	return !g.CreatedAt.IsZero() && !g.CreatedAt.After(now) && !g.LastSeenAt.Before(g.CreatedAt) && !g.LastSeenAt.After(now) && g.AbsoluteExpiresAt.Equal(g.CreatedAt.Add(identity.GuestAbsoluteTTL)) && now.Before(g.AbsoluteExpiresAt) && now.Before(g.LastSeenAt.Add(identity.GuestIdleTTL))
}
func validInternalID(value string) bool {
	if len(value) < 8 || len(value) > 64 { return false }
	for _, r := range value { if !((r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9') || r == '-' || r == '_') { return false } }
	return true
}
