package coordinator

import (
 "time"
 rt "notitle/internal/realtime"
)
// MatchMetrics is fixed-size and private. No user, topic, gender, industry,
// country, case, or relationship key can become a metric label. Counters reset
// with the sole owner process; hourly aggregation must account for restarts.
type MatchMetrics struct {
 QueueJoins,QueueDepartures,Matches,RecentRepeats uint64
 WaitHistogram [8]uint64
 StrictWaitHistogram [8]uint64
 CompatibleSearchHistogram [7]uint64
 ProfessionalMatches,ProfessionalOverlap,NoPreferenceMatches uint64
 ProfessionalWaitHistogram,NoPreferenceWaitHistogram [8]uint64
}
// Wait bounds <=0.1,0.5,1,2,5,10,30,+Inf seconds, separate from search time.
func observeWait(hist *[8]uint64,d time.Duration){i:=7;for n,b:=range []time.Duration{100*time.Millisecond,500*time.Millisecond,time.Second,2*time.Second,5*time.Second,10*time.Second,30*time.Second}{if d<=b{i=n;break}};hist[i]++}
// CompatibleSearch bounds <=100,250,500,1000,5000,10000,+Inf microseconds.
func(m *liveMemory)observeMatch(a,b rt.QueueEntry,history rt.PairHistory,now time.Time,elapsed time.Duration){
 m.metrics.Matches++;if !history.EndedAt.IsZero()&&now.Sub(history.EndedAt)<rt.RecentPairTTL{m.metrics.RecentRepeats++}
 i:=6;for n,b:=range []time.Duration{100*time.Microsecond,250*time.Microsecond,500*time.Microsecond,time.Millisecond,5*time.Millisecond,10*time.Millisecond}{if elapsed<=b{i=n;break}};m.metrics.CompatibleSearchHistogram[i]++
 professional:=func(e rt.QueueEntry)bool{p:=e.Auth.Preferences;p.Gender=rt.Everyone;return e.Auth.Entitlement.Active(now)&&rt.RequiresPremium(p)}
 enabled:=professional(a)||professional(b)
 if enabled{m.metrics.ProfessionalMatches++;aa,bb:=a,b;aa.QueuedAt=now;bb.QueuedAt=now;_,score:=rt.RelevanceBonuses(aa,bb,now);if score>0{m.metrics.ProfessionalOverlap++}}else{m.metrics.NoPreferenceMatches++}
 for _,e:=range []rt.QueueEntry{a,b}{wait:=now.Sub(e.QueuedAt);observeWait(&m.metrics.WaitHistogram,wait);if e.Auth.Preferences.Gender!=rt.Everyone{observeWait(&m.metrics.StrictWaitHistogram,wait)};if enabled{observeWait(&m.metrics.ProfessionalWaitHistogram,wait)}else{observeWait(&m.metrics.NoPreferenceWaitHistogram,wait)}}
}
func(m *liveMemory)aggregateMetrics()MatchMetrics{
 v:=m.metrics
 // Coarse preference-only cohorts are hidden below 20 completed pairs. No
 // demographic cohort is collected at all, including the hard-filter label.
 if v.ProfessionalMatches<20{v.ProfessionalMatches=0;v.ProfessionalOverlap=0;v.ProfessionalWaitHistogram=[8]uint64{}}
 if v.NoPreferenceMatches<20{v.NoPreferenceMatches=0;v.NoPreferenceWaitHistogram=[8]uint64{}}
 var strict uint64;for _,n:=range v.StrictWaitHistogram{strict+=n};if strict<20{v.StrictWaitHistogram=[8]uint64{}}
 return v
}
