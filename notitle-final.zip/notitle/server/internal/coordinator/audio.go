package coordinator

import (
 "context"
 "encoding/json"
 "net/netip"
 "strings"
 "time"

 at "notitle/internal/audiotypes"
 rt "notitle/internal/realtime"
 st "notitle/internal/safetytypes"
)

// All call and job mutation belongs to the same owner as interactions. A call
// awaiting relay revocation continues to reserve capacity after the text pair
// has gone. No external work or goroutine is started from this state machine.
const audioClockSkew = 2*time.Second

type audioMemory struct {
 enabled,ready bool
 bootID string
 addresses []netip.Addr
 calls map[string]*audioCall
}
type audioCall struct {
 ref,interactionID,a,b string
 epoch,aGeneration,bGeneration,negotiation uint64
 state at.State
 requestedAt,expiresAt,renewAt,refreshAt,relayUntil time.Time
 reserved,provisioned,revoked bool
 offered,answered bool
 connected [2]bool
 candidates [2]int
 credentials [2]at.Credentials
 version uint64
 job,revokeJob at.Job
 jobRetryAt,revokeRetryAt time.Time
}
type audioOperation uint8
const(audioClaim audioOperation=iota; audioFinish; audioReady; audioInstance)
type audioRequest struct {ctx context.Context; op audioOperation; limit int; leaseID string; result at.JobResult; ready bool; bootID string; reply chan audioResult}
type audioResult struct {jobs []at.Job; published bool; instance string; err error}
var _ at.Owner=(*Coordinator)(nil)
func newAudioMemory()*audioMemory{return &audioMemory{calls:make(map[string]*audioCall)}}
func cloneAudioCredentials(value at.Credentials)at.Credentials{value.URLs=append([]string(nil),value.URLs...);value.RelayAddresses=append([]string(nil),value.RelayAddresses...);return value}
func(c *Coordinator)audioControl(ctx context.Context,req audioRequest)(audioResult,error){
 if err:=ctx.Err();err!=nil{return audioResult{},err};if !c.running.Load(){return audioResult{},ErrNotRunning};req.ctx=ctx;req.reply=make(chan audioResult,1)
 for index:=range req.result.Credentials{req.result.Credentials[index]=cloneAudioCredentials(req.result.Credentials[index])}
 select{case <-ctx.Done():return audioResult{},ctx.Err();case <-c.done:return audioResult{},ErrNotRunning;case c.audioRequests<-req:default:return audioResult{},ErrOverloaded}
 select{case <-ctx.Done():return audioResult{},ctx.Err();case <-c.done:return audioResult{},ErrNotRunning;case result:=<-req.reply:return result,result.err}
}
func(c *Coordinator)AudioServerInstance(ctx context.Context)(string,error){r,e:=c.audioControl(ctx,audioRequest{op:audioInstance});return r.instance,e}
func(c *Coordinator)ClaimAudioJobs(ctx context.Context,limit int)([]at.Job,error){r,e:=c.audioControl(ctx,audioRequest{op:audioClaim,limit:limit});return r.jobs,e}
func(c *Coordinator)FinishAudioJob(ctx context.Context,leaseID string,result at.JobResult)(bool,error){r,e:=c.audioControl(ctx,audioRequest{op:audioFinish,leaseID:leaseID,result:result});return r.published,e}
func(c *Coordinator)SetAudioRelayReady(ctx context.Context,ready bool,bootID string)error{_,e:=c.audioControl(ctx,audioRequest{op:audioReady,ready:ready,bootID:bootID});return e}
func(c *Coordinator)applyAudio(m *liveMemory,req audioRequest){
 if err:=req.ctx.Err();err!=nil{req.reply<-audioResult{err:err};return};now:=c.clock.Now();m.now=now;m.guests.expire(now);if c.failClosed.Load(){m.latchClosed(now)};m.maintainAudio(now)
 switch req.op{
 case audioInstance:req.reply<-audioResult{instance:m.instance}
 case audioClaim:req.reply<-audioResult{jobs:m.claimAudioJobs(req.limit,now)}
 case audioFinish:req.reply<-m.finishAudioJob(req.leaseID,req.result,now)
 case audioReady:
  if req.ready&&(!at.ValidRef(req.bootID)||!m.audio.enabled||m.latched){req.reply<-audioResult{err:rt.ErrUnavailable};return}
  if !req.ready||(m.audio.bootID!=""&&req.bootID!=m.audio.bootID){m.endAllCalls(now,"relay_unavailable")}
  changed:=m.audio.ready!=req.ready||m.audio.bootID!=req.bootID;m.audio.ready=req.ready;if req.ready{m.audio.bootID=req.bootID}
  if changed{for _,p:=range m.participants{m.emit(p,"session.state",m.state(p),"")}}
  req.reply<-audioResult{}
 }
}
func(m *liveMemory)audioCounts()(active,cleanup int){for _,call:=range m.audio.calls{if call.reserved{if call.state==at.Ended{cleanup++}else{active++}}};return}
func(m *liveMemory)audioCapacity()bool{active,cleanup:=m.audioCounts();return active+cleanup<at.MaxCalls}
func(m *liveMemory)audioAvailable(p *liveParticipant,now time.Time)bool{return m.audio.enabled&&m.audio.ready&&!m.outage&&!m.latched&&p!=nil&&p.auth.AudioEnabled&&p.connection!=nil&&m.guests.slots[p.slot.id]==p.slot&&!p.handoff&&now.Before(p.auth.ValidUntil)&&!p.auth.Restricted&&!m.subjectRestricted(p.auth.Kind,p.auth.IdentityID)&&len(p.slot.carry.restrictions)==0}
func(m *liveMemory)callMembers(call *audioCall,now time.Time)(*liveParticipant,*liveParticipant,bool){
 interaction:=m.interactions[call.interactionID];a,b:=m.participants[call.a],m.participants[call.b]
 if interaction==nil||interaction.epoch!=call.epoch||interaction.callRef!=call.ref||a==nil||b==nil||a.interactionID!=call.interactionID||b.interactionID!=call.interactionID||a.connectionGeneration!=call.aGeneration||b.connectionGeneration!=call.bGeneration||!m.audioAvailable(a,now)||!m.audioAvailable(b,now)||m.blocked(a,b){return a,b,false};return a,b,true
}
func(m *liveMemory)audioView(call *audioCall,p *liveParticipant)at.View{direction,offerOwner:="incoming","peer";if p.slot.id==call.a{direction,offerOwner="outgoing","self"};state:=call.state;if state==at.Requested&&p.slot.id==call.b{state=at.Ringing};return at.View{CallRef:call.ref,State:state,Direction:direction,OfferOwner:offerOwner,ExpiresAt:call.expiresAt}}
func(m *liveMemory)audioState(p *liveParticipant,state *rt.StateSnapshot){state.AudioEnabled=m.audioAvailable(p,m.now);if interaction:=m.interactions[p.interactionID];interaction!=nil{if call:=m.audio.calls[interaction.callRef];call!=nil&&call.state!=at.Ended{view:=m.audioView(call,p);state.Call=&view}}}
func(m *liveMemory)emitCall(call *audioCall){for _,id:=range []string{call.a,call.b}{if p:=m.participants[id];p!=nil&&p.interactionID==call.interactionID&&call.state!=at.Ended{m.emit(p,"call.state",m.audioView(call,p),"")}}}
func(m *liveMemory)newCall(a,b *liveParticipant,now time.Time)*audioCall{interaction:=m.interactions[a.interactionID];call:=&audioCall{ref:m.opaque("call"),interactionID:interaction.id,epoch:interaction.epoch,a:a.slot.id,b:b.slot.id,aGeneration:a.connectionGeneration,bGeneration:b.connectionGeneration,state:at.Requested,requestedAt:now,expiresAt:now.Add(at.RingTimeout)};interaction.callRef=call.ref;m.audio.calls[call.ref]=call;return call}
func(m *liveMemory)acceptCall(call *audioCall,now time.Time)error{if _,_,ok:=m.callMembers(call,now);!ok{return rt.ErrUnavailable};if !m.audioCapacity(){return rt.ErrCapacity};call.reserved=true;call.state=at.Accepted;accepted:=now;m.interactions[call.interactionID].callMetadata=&st.CallMetadata{CallRef:call.ref,RequestedAt:call.requestedAt,AcceptedAt:&accepted};call.expiresAt=now.Add(at.ConnectTimeout);m.emitCall(call);return nil}
func(m *liveMemory)audioCommand(p *liveParticipant,command rt.ClientEnvelope,now time.Time)error{
 interaction:=m.interactions[p.interactionID];peer:=m.peer(p);if interaction==nil{return rt.ErrStaleEpoch}
 call:=m.audio.calls[interaction.callRef]
 if command.Type=="call.request"{
  if !m.audioAvailable(p,now)||!m.audioAvailable(peer,now)||m.blocked(p,peer){return rt.ErrUnavailable}
  if call!=nil{
   // First request owns the offer. A crossing Call click is affirmative consent
   // to that same request, never a second call or renegotiation owner.
   if call.state==at.Requested&&p.slot.id==call.b&&now.Before(call.expiresAt){return m.acceptCall(call,now)}
   if call.state==at.Requested&&p.slot.id==call.a{return nil};return rt.ErrUnavailable
  }
  if m.audioCoolingDown(interaction,p,peer,now){return rt.ErrRateLimited};if !m.audioCapacity(){return rt.ErrCapacity}
  call=m.newCall(p,peer,now);m.emitCall(call);return nil
 }
 var input at.RefPayload;if json.Unmarshal(command.Payload,&input)!=nil||call==nil||input.CallRef!=call.ref{return rt.ErrStaleEpoch}
 if command.Type=="call.end"{m.endCall(call,now,"ended");return nil}
 if _,_,ok:=m.callMembers(call,now);!ok{return rt.ErrUnavailable}
 switch command.Type{
 case "call.accept":if call.state!=at.Requested||p.slot.id!=call.b||!now.Before(call.expiresAt){return rt.ErrUnavailable};return m.acceptCall(call,now)
 case "call.decline":if call.state!=at.Requested||p.slot.id!=call.b{return rt.ErrUnavailable};interaction.callCooldownUntil=now.Add(at.DeclineCooldown);if ref:=m.friends.pairs[friendPair(friendSubject(p.slot),friendSubject(peer.slot))];ref!=""{if link:=m.friends.links[ref];link!=nil{link.audioCooldownUntil=interaction.callCooldownUntil}};m.endCall(call,now,"declined");return nil
 case "call.connected":var connected at.ConnectedPayload;if json.Unmarshal(command.Payload,&connected)!=nil||connected.Negotiation!=call.negotiation{return rt.ErrStaleEpoch};if !call.provisioned||!call.offered||!call.answered||(call.state!=at.Connecting&&call.state!=at.Connected){return rt.ErrUnavailable};index:=0;if p.slot.id==call.b{index=1};call.connected[index]=true;if call.connected[0]&&call.connected[1]{call.state=at.Connected;call.expiresAt=time.Time{};m.emitCall(call)};return nil
 case "webrtc.offer","webrtc.answer","webrtc.ice":
  if !call.provisioned||(call.state!=at.Connecting&&call.state!=at.Connected){return rt.ErrUnavailable}
  index:=0;if p.slot.id==call.b{index=1};if !now.Before(call.credentials[index].ExpiresAt){m.endCall(call,now,"credentials_expired");return rt.ErrUnavailable}
  if command.Type=="webrtc.ice"{if call.candidates[index]>=at.MaxCandidates{return rt.ErrRateLimited};var payload at.ICEPayload;if json.Unmarshal(command.Payload,&payload)!=nil{return rt.ErrProtocol};if payload.Negotiation!=call.negotiation{return rt.ErrStaleEpoch};if payload.SDPMLineIndex!=0||payload.SDPMid!="0"||at.ValidateCandidate(payload.Candidate,m.audio.addresses)!=nil{return rt.ErrProtocol};call.candidates[index]++;m.emit(peer,command.Type,payload,"");return nil}
  var payload at.SDPPayload;if json.Unmarshal(command.Payload,&payload)!=nil{return rt.ErrProtocol};if payload.Negotiation!=call.negotiation{return rt.ErrStaleEpoch};kind:=strings.TrimPrefix(command.Type,"webrtc.");if kind=="offer"{if p.slot.id!=call.a||call.offered{return rt.ErrUnavailable}}else if p.slot.id!=call.b||!call.offered||call.answered{return rt.ErrUnavailable};if at.ValidateSDP(payload.SDP,kind,m.audio.addresses)!=nil{return rt.ErrProtocol}
  if kind=="offer"{call.offered=true}else{call.answered=true};m.emit(peer,command.Type,payload,"");return nil
 }
 return rt.ErrProtocol
}
func(m *liveMemory)endInteractionCall(interaction *liveInteraction,now time.Time,reason string){if call:=m.audio.calls[interaction.callRef];call!=nil{m.endCall(call,now,reason)}}
func(m *liveMemory)endAllCalls(now time.Time,reason string){for _,call:=range m.audio.calls{m.endCall(call,now,reason)};for _,invite:=range m.friends.invitations{if invite.kind=="audio"{m.closeInvitation(invite,"ended")}}}
func(m *liveMemory)endCall(call *audioCall,now time.Time,reason string){
 if call.state==at.Ended{return};call.state=at.Ended;call.credentials=[2]at.Credentials{};call.expiresAt=time.Time{}
 if interaction:=m.interactions[call.interactionID];interaction!=nil&&interaction.callRef==call.ref{interaction.callRef="";if interaction.callMetadata!=nil&&interaction.callMetadata.CallRef==call.ref{ended:=now;interaction.callMetadata.EndedAt=&ended}}
 for _,id:=range []string{call.a,call.b}{if p:=m.participants[id];p!=nil&&p.interactionID==call.interactionID{m.purgeAudioEvents(p,call.ref);m.emit(p,"call.ended",at.EndedPayload{CallRef:call.ref,Reason:reason},"")}}
 if !call.reserved{delete(m.audio.calls,call.ref)}else if call.job.LeaseID==""&&!call.provisioned{delete(m.audio.calls,call.ref)}
}
func(m *liveMemory)purgeAudioEvents(p *liveParticipant,callRef string){if p.connection==nil{return};events:=p.connection.events;n:=len(events);kept:=make([]rt.ServerEvent,0,n);for i:=0;i<n;i++{select{case event:=<-events:if strings.HasPrefix(event.Type,"call.")||strings.HasPrefix(event.Type,"webrtc."){continue};kept=append(kept,event);default:i=n}};for _,event:=range kept{events<-event}}
func(m *liveMemory)maintainAudio(now time.Time){
 for _,call:=range m.audio.calls{
  if call.state==at.Ended{continue};if _,_,ok:=m.callMembers(call,now);!ok{m.endCall(call,now,"not_available");continue}
  if !call.expiresAt.IsZero()&&!now.Before(call.expiresAt){m.endCall(call,now,"expired");continue}
  if call.provisioned&&!now.Before(call.relayUntil){m.endCall(call,now,"relay_unavailable");continue}
  if call.provisioned{for _,credentials:=range call.credentials{if !now.Before(credentials.ExpiresAt){m.endCall(call,now,"credentials_expired");break}}}
 }
}
func(m *liveMemory)newAudioJob(call *audioCall,action string,now time.Time)at.Job{call.version++;return at.Job{LeaseID:m.opaque("audio-job"),CallRef:call.ref,Version:call.version,Action:action,ServerInstance:m.instance,LeaseUntil:now.Add(at.LeaseDuration),CredentialExpiresAt:now.Add(at.CredentialLifetime)}}
func(m *liveMemory)claimAudioJobs(limit int,now time.Time)[]at.Job{
 if limit<1{return nil};if limit>at.MaxCalls*2{limit=at.MaxCalls*2};jobs:=make([]at.Job,0,limit)
 // Revocation is claimable independently of a slow create/renew completion.
 // The supervisor must make revocation terminal for the call reference.
 for _,call:=range m.audio.calls{if call.state!=at.Ended||!call.reserved||call.revoked{continue};if len(jobs)==limit{return jobs};if call.revokeJob.LeaseID==""{call.revokeJob=m.newAudioJob(call,"revoke",now)};if !now.Before(call.revokeRetryAt){jobs=append(jobs,call.revokeJob);call.revokeRetryAt=now.Add(5*time.Second)}}
 if !m.audio.ready||m.outage||m.latched{return jobs}
 for _,call:=range m.audio.calls{
  if len(jobs)==limit{return jobs};if call.state==at.Ended||!call.reserved{continue};if _,_,ok:=m.callMembers(call,now);!ok{m.endCall(call,now,"not_available");continue}
  if call.job.LeaseID!=""{if !now.Before(call.jobRetryAt){jobs=append(jobs,call.job);call.jobRetryAt=now.Add(5*time.Second)};continue}
  action:="";if !call.provisioned{action="create"}else if !now.Before(call.refreshAt){action="refresh"}else if !now.Before(call.renewAt){action="renew"};if action==""{continue}
  call.job=m.newAudioJob(call,action,now);call.jobRetryAt=now.Add(5*time.Second);jobs=append(jobs,call.job)
 };return jobs
}
func(m *liveMemory)validAudioCredentials(value at.Credentials,now time.Time)bool{
 if len(value.URLs)<1||len(value.URLs)>4||len(value.Username)<16||len(value.Username)>256||len(value.Credential)<16||len(value.Credential)>256||!value.ExpiresAt.After(now.Add(at.CredentialRefreshInterval))||value.ExpiresAt.After(now.Add(at.CredentialLifetime+audioClockSkew))||!now.Before(value.RefreshAt)||value.RefreshAt.After(now.Add(at.CredentialRefreshInterval+audioClockSkew))||!value.RefreshAt.Before(value.ExpiresAt)||value.RelayMinPort!=at.RelayMinPort||value.RelayMaxPort!=at.RelayMaxPort||len(value.RelayAddresses)==0||len(value.RelayAddresses)>len(m.audio.addresses){return false}
 for _,text:=range value.RelayAddresses{address,err:=netip.ParseAddr(text);if err!=nil{return false};found:=false;for _,approved:=range m.audio.addresses{if address==approved{found=true;break}};if !found{return false}}
 for _,url:=range value.URLs{if len(url)>256||(!strings.HasPrefix(url,"turn:")&&!strings.HasPrefix(url,"turns:")){return false}}
 return true
}
func(m *liveMemory)finishAudioJob(leaseID string,result at.JobResult,now time.Time)audioResult{
 if !at.ValidRef(leaseID){return audioResult{err:rt.ErrProtocol}}
 for _,call:=range m.audio.calls{
  if call.revokeJob.LeaseID==leaseID{
   if !result.Success||!result.Revoked{call.revokeRetryAt=now.Add(time.Second);return audioResult{}}
   call.revoked=true;call.revokeJob=at.Job{};delete(m.audio.calls,call.ref);return audioResult{published:true}
  }
  if call.job.LeaseID!=leaseID{continue}
  if result.Revoked&&result.Success{call.revoked=true;call.job=at.Job{};if call.state!=at.Ended{m.endCall(call,now,"relay_unavailable")};delete(m.audio.calls,call.ref);return audioResult{published:true}}
  job:=call.job
  if call.state==at.Ended||!result.Success||result.RelayBootID!=m.audio.bootID||!m.audio.ready{
   m.endCall(call,now,"relay_unavailable")
   // Keep the original job pinned until compensation or its independent
   // revocation finishes. An ambiguous create must never free capacity.
   if call.revoked{call.job=at.Job{};delete(m.audio.calls,call.ref);return audioResult{}}
   return audioResult{published:false}
  }
  if _,_,ok:=m.callMembers(call,now);!ok{m.endCall(call,now,"not_available");return audioResult{}}
  if !now.Before(job.LeaseUntil){m.endCall(call,now,"relay_unavailable");return audioResult{}}
  if job.Action=="create"||job.Action=="refresh"{
   if !m.validAudioCredentials(result.Credentials[0],now)||!m.validAudioCredentials(result.Credentials[1],now)||result.Credentials[0].Username==result.Credentials[1].Username||(job.Action=="refresh"&&(result.Credentials[0].Username==call.credentials[0].Username||result.Credentials[1].Username==call.credentials[1].Username)){m.endCall(call,now,"relay_unavailable");return audioResult{}}
   call.credentials[0]=boundedAudioCredentials(result.Credentials[0],now);call.credentials[1]=boundedAudioCredentials(result.Credentials[1],now);call.refreshAt=call.credentials[0].RefreshAt;if call.credentials[1].RefreshAt.Before(call.refreshAt){call.refreshAt=call.credentials[1].RefreshAt};call.provisioned=true;call.negotiation++;call.offered=false;call.answered=false;call.connected=[2]bool{};call.candidates=[2]int{}
   call.state=at.Connecting;call.expiresAt=now.Add(at.ConnectTimeout);m.emitCall(call)
   for index,id:=range []string{call.a,call.b}{if call.state==at.Ended{break};if p:=m.participants[id];p!=nil{m.emit(p,"call.credentials",at.CredentialsPayload{CallRef:call.ref,Negotiation:call.negotiation,Credentials:cloneAudioCredentials(call.credentials[index])},"")}}
  }
  if call.state==at.Ended{return audioResult{published:false}};call.job=at.Job{};call.relayUntil=job.LeaseUntil;call.renewAt=job.LeaseUntil.Add(-at.LeaseDuration+at.LeaseRenewInterval);return audioResult{published:true}
 }
 return audioResult{published:false}
}

func cloneCallMetadata(value *st.CallMetadata)*st.CallMetadata{if value==nil{return nil};copy:=*value;if value.AcceptedAt!=nil{accepted:=*value.AcceptedAt;copy.AcceptedAt=&accepted};if value.EndedAt!=nil{ended:=*value.EndedAt;copy.EndedAt=&ended};return &copy}

// Separate hosts may differ by at most the documented two-second clock budget.
// Schedule refresh five minutes after local receipt, which cannot precede the
// relay's five-minute issuance interval even when its clock is behind ours.
// Expiry stays conservative; validation guarantees it remains after refresh.
func boundedAudioCredentials(value at.Credentials,now time.Time)at.Credentials{value=cloneAudioCredentials(value);if ceiling:=now.Add(at.CredentialLifetime);value.ExpiresAt.After(ceiling){value.ExpiresAt=ceiling};value.RefreshAt=now.Add(at.CredentialRefreshInterval);return value}

func(m *liveMemory)audioCoolingDown(interaction *liveInteraction,a,b *liveParticipant,now time.Time)bool{if now.Before(interaction.callCooldownUntil){return true};if ref:=m.friends.pairs[friendPair(friendSubject(a.slot),friendSubject(b.slot))];ref!=""{if link:=m.friends.links[ref];link!=nil&&!link.removed&&now.Before(link.audioCooldownUntil){return true}};return false}
