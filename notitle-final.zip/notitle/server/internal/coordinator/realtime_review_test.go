package coordinator

import (
    "errors"
    "testing"
    "time"

    "notitle/internal/identity"
    rt "notitle/internal/realtime"
)

// These independent regressions cover continuity boundaries rather than a
// second implementation of the scoring policy. Run with go test -race.
func TestRealtimeRestartCannotResumePreviousProcessInteraction(t *testing.T) {
    now := rtNow()
    old := memoryFixture()
    a, pa := attachFixture(t, old, 1, now)
    b, pb := attachFixture(t, old, 2, now)
    doCommand(t, old, a, pa, "queue.join", "restart_a", now)
    doCommand(t, old, b, pb, "queue.join", "restart_b", now)
    view := old.state(pa)
    previous := rt.Resume{Token:view.ResumeToken, ServerInstance:view.ServerInstance, Generation:view.Generation, InteractionID:view.Interaction.ID, Epoch:view.Interaction.Epoch}
    old.shutdown()

    var freshKey [32]byte
    freshKey[0] = 83
    fresh := newLiveMemory(freshKey, newGuestMemory())
    if fresh.instance == previous.ServerInstance { t.Fatal("restart reused server instance") }
    auth := accountAuth(1, now)
    result := fresh.attach(rt.AttachRequest{Auth:auth, Resume:&previous}, "fresh_random_resume_secret_32_bytes", now)
    if !errors.Is(result.err, rt.ErrStaleEpoch) { t.Fatal("prior process interaction was resumed") }
    result = fresh.attach(rt.AttachRequest{Auth:auth}, "fresh_random_resume_secret_32_bytes", now)
    if result.err != nil { t.Fatal(result.err) }
    current := fresh.byConnection(result.connection.Ref)
    if current == nil || current.state != rt.Idle || current.interactionID != "" || len(fresh.waiting) != 0 || len(fresh.interactions) != 0 {
        t.Fatal("restart reconstructed live state instead of requiring an explicit search")
    }
    // An otherwise well-formed old guest snapshot has no surviving memory
    // identity in the new process and cannot enter via the account path.
    guest := accountAuth(3, now)
    guest.Kind = identity.KindGuest
    guest.SessionID = guest.IdentityID
    result = fresh.attach(rt.AttachRequest{Auth:guest}, "guest_random_resume_secret_32_bytes", now)
    if !errors.Is(result.err, rt.ErrUnauthorized) { t.Fatal("restart restored a lost guest identity") }
}

func TestRealtimeResumeRejectsOtherSessionAndInstanceWithoutTakingOwnership(t *testing.T) {
    now := rtNow()
    memory := memoryFixture()
    a, pa := attachFixture(t, memory, 1, now)
    b, pb := attachFixture(t, memory, 2, now)
    doCommand(t, memory, a, pa, "queue.join", "resume_a", now)
    doCommand(t, memory, b, pb, "queue.join", "resume_b", now)
    view := memory.state(pa)
    memory.disconnect(pa, now, "connection_lost")
    original := rt.Resume{Token:view.ResumeToken, ServerInstance:view.ServerInstance, Generation:view.Generation, InteractionID:view.Interaction.ID, Epoch:view.Interaction.Epoch}
    auth := accountAuth(1, now.Add(time.Second))
    for _, kind := range []string{"instance", "session", "verifier", "generation"} {
        t.Run(kind, func(t *testing.T) {
            attempt, candidate := original, auth
            switch kind {
            case "instance": attempt.ServerInstance = "other_server_instance"
            case "session": candidate.SessionID = "other_session_1234"
            case "verifier": candidate.SessionVerifier[0] ^= 1
            case "generation": candidate.IdentityGeneration++
            }
            result := memory.attach(rt.AttachRequest{Auth:candidate, Resume:&attempt}, "new_random_resume_secret_32_bytes", now.Add(time.Second))
            if !errors.Is(result.err, rt.ErrTakeoverRequired) { t.Fatal("unrelated authority resumed a retained interaction") }
            if pa.connection != nil || pa.interactionID != view.Interaction.ID || pb.interactionID != view.Interaction.ID {
                t.Fatal("failed resume changed existing interaction ownership")
            }
        })
    }
}

func TestRealtimeConnectedPeerCanEndDuringReconnectGrace(t *testing.T) {
    now := rtNow()
    memory := memoryFixture()
    a, pa := attachFixture(t, memory, 1, now)
    b, pb := attachFixture(t, memory, 2, now)
    doCommand(t, memory, a, pa, "queue.join", "grace_a", now)
    doCommand(t, memory, b, pb, "queue.join", "grace_b", now)
    before := memory.state(pa)
    memory.disconnect(pa, now, "connection_lost")
    doCommand(t, memory, b, pb, "match.end", "peer_ends", now.Add(time.Second))
    if len(memory.interactions) != 0 || pb.state != rt.Idle || memory.participants[pa.slot.id] != nil {
        t.Fatal("End could not terminate a disconnected peer's retained interaction")
    }
    stale := rt.Resume{Token:before.ResumeToken, ServerInstance:before.ServerInstance, Generation:before.Generation, InteractionID:before.Interaction.ID, Epoch:before.Interaction.Epoch}
    result := memory.attach(rt.AttachRequest{Auth:accountAuth(1, now.Add(2*time.Second)), Resume:&stale}, "new_random_resume_secret_32_bytes", now.Add(2*time.Second))
    if !errors.Is(result.err, rt.ErrStaleEpoch) { t.Fatal("late reconnect resurrected explicitly ended interaction") }
}
