package coordinator

import (
 "errors"
 "fmt"
 "testing"
 "time"

 ft "notitle/internal/friendtypes"
 "notitle/internal/identity"
 rt "notitle/internal/realtime"
)

// Independent adversarial ordering checks supplement the owner's feature
// matrix. They require Go; authored tests are not proof of execution.
func TestReviewPendingFriendRequestCannotCrossInteractionEpoch(t *testing.T){
 m,a,pa,b,pb,now:=friendPairFixture(t)
 runFriend(t,m,pa,"friend.request","review_pending_request",struct{}{},now)
 request:=m.friends.requests[pa.interactionID]
 stale:=friendEnvelope(pb,m,"friend.accept","review_stale_accept",rt.FriendResponse{RequestRef:request.ref})
 drain(a);drain(b);doCommand(t,m,a,pa,"match.end","review_end_pending",now)
 if len(m.friends.requests)!=0{t.Fatal("End retained pending consent")}
 later:=now.Add(4*time.Second)
 doCommand(t,m,a,pa,"queue.join","review_new_queue_a",later)
 doCommand(t,m,b,pb,"queue.join","review_new_queue_b",later)
 if pa.interactionID==""||pa.interactionID==stale.InteractionID{t.Fatal("fixture did not create a successor interaction")}
 if err:=m.command(b.Ref,stale,later);!errors.Is(err,rt.ErrStaleEpoch){t.Fatal("old request accepted in a successor interaction",err)}
 if len(m.friends.links)!=0{t.Fatal("stale request created a relationship")}
}

func TestReviewRandomMatchWinsOverPreviouslyReceivedFriendInvite(t *testing.T){
 m,a,pa,b,pb,now:=friendPairFixture(t);link:=connectPair(t,m,pa,pb,now)
 drain(a);drain(b);doCommand(t,m,a,pa,"match.end","review_end_random",now)
 runFriend(t,m,pa,"friend.invite","review_waiting_invite",rt.FriendInvite{FriendRef:link.mutation.Ref,Kind:"text"},now)
 var invitation *friendInvitation;for _,value:=range m.friends.invitations{invitation=value}
 if invitation==nil{t.Fatal("fixture has no incoming invitation")}
 accept:=friendEnvelope(pb,m,"friend.accept_invite","review_late_invite_accept",rt.FriendInviteResponse{InvitationRef:invitation.ref})
 c,pc:=attachFixture(t,m,3,now)
 doCommand(t,m,c,pc,"queue.join","review_third_queue",now)
 doCommand(t,m,b,pb,"queue.join","review_recipient_queue",now)
 if pb.interactionID==""||pb.interactionID!=pc.interactionID||pa.interactionID!=""{t.Fatal("random allocation did not preserve one owner per interaction")}
 active:=pb.interactionID
 if err:=m.command(b.Ref,accept,now);!errors.Is(err,rt.ErrUnavailable){t.Fatal("stale invitation interrupted a random match",err)}
 if len(m.interactions)!=1||pb.interactionID!=active||pc.interactionID!=active||len(m.friends.invitations)!=0{t.Fatal("late friend acceptance changed the already allocated match")}
}

func TestReviewForeignRemovalAndStaleHydrationCannotResurrectConsent(t *testing.T){
 m,_,pa,_,pb,now:=friendPairFixture(t);link:=connectPair(t,m,pa,pb,now)
 insert:=m.claimFriends(1,now)[0];if !m.finishFriend(insert.LeaseID,true,now).published{t.Fatal("fixture did not commit relationship")}
 _,pc:=attachFixture(t,m,3,now)
 foreign:=m.applyFriend(friendRequest{op:friendRemove,guard:friendOwnerGuard(m,pc,now),ref:link.mutation.Ref},now)
 if !errors.Is(foreign.err,ft.ErrNotFound)||link.removed{t.Fatal("possession of another pair's handle authorized removal",foreign.err)}
 staleGuard:=friendOwnerGuard(m,pa,now)
 staleSnapshot:=ft.Snapshot{Revision:1,Relations:[]ft.Relation{{Ref:link.mutation.Ref,Self:link.mutation.A,Peer:link.mutation.B,PeerDisplayName:link.bName,PeerRevision:1,CreatedAt:now}}}
 removal:=m.applyFriend(friendRequest{op:friendRemove,guard:friendOwnerGuard(m,pa,now),ref:link.mutation.Ref},now)
 if removal.err!=nil{t.Fatal(removal.err)}
 if !m.finishFriend(removal.mutation.LeaseID,true,now).published{t.Fatal("durable removal did not complete")}
 stale:=m.applyFriend(friendRequest{op:friendList,guard:staleGuard,snapshot:staleSnapshot},now)
 if stale.err==nil||m.friends.links[link.mutation.Ref]!=nil{t.Fatal("a SQL snapshot obtained before Remove resurrected consent")}
 current:=m.applyFriend(friendRequest{op:friendList,guard:friendOwnerGuard(m,pa,now),snapshot:ft.Snapshot{Revision:2,Relations:[]ft.Relation{}}},now)
 if current.err!=nil||len(current.views)!=0{t.Fatal("current empty snapshot did not preserve removal",current.err)}
}

func TestReviewTwoHundredConnectedAccountsRetainHundredDistinctOfflineFriendsEach(t *testing.T){
 m:=memoryFixture();now:=rtNow();connections:=make([]rt.Connection,0,LaunchLimits().Connected)
 for n:=1;n<=LaunchLimits().Connected;n++{
  auth:=accountAuth(n,now);auth.FriendsEnabled=true;auth.TextEnabled=true;auth.FriendRevision=1;auth.Fence=m.fence
  own:=ft.Subject{Kind:identity.KindAccount,ID:auth.IdentityID,Generation:1}
  for index:=0;index<ft.MaxFriendsPerIdentity;index++{
   peer:=accountAuth(1000+n*ft.MaxFriendsPerIdentity+index,now)
   auth.FriendLinks=append(auth.FriendLinks,ft.Relation{Ref:fmt.Sprintf("review_dense_%04d_%04d",n,index),Self:own,Peer:ft.Subject{Kind:identity.KindAccount,ID:peer.IdentityID,Generation:1},PeerRevision:1,PeerDisplayName:"Offline accepted friend",CreatedAt:now})
  }
  attached:=m.attach(rt.AttachRequest{Auth:auth},fmt.Sprintf("review_resume_secret_%08d",n),now)
  if attached.err!=nil{t.Fatalf("friend density rejected connected participant %d: %v",n,attached.err)}
  m.maintainFriends(now)
  if len(attached.connection.Events)>2||m.byConnection(attached.connection.Ref)==nil{t.Fatal("cold hydration exceeded the bounded event budget")}
  drain(attached.connection);connections=append(connections,attached.connection)
 }
 if m.connected()!=LaunchLimits().Connected||len(m.friends.links)!=LaunchLimits().Connected*ft.MaxFriendsPerIdentity{t.Fatal("relationship cache silently reduced the connected-user or friend limits")}
 for _,connection:=range connections{select{case <-connection.Closed:t.Fatal("dense accepted graph disconnected a healthy participant");default:}}
 // This deterministic admission check is not a CPU, RSS, latency or audio
 // benchmark. Deployment acceptance still requires measurements on the host.
}
