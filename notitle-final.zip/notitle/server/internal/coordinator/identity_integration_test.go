package coordinator

import (
	"context"
	"errors"
	"testing"

	"notitle/internal/identity"
)

// The embedded interfaces intentionally fail if this narrow integration starts
// making unrelated durable calls. Only account creation is needed to exercise
// the real service/coordinator transaction boundary.
type handoffStore struct {
	identity.Store
	err error
	cancel context.CancelFunc
}
func (s *handoffStore) CreateAccount(_ context.Context, record identity.CreateAccountRecord) (identity.AccountSession, error) {
	if s.cancel != nil { s.cancel() }
	if s.err != nil { return identity.AccountSession{}, s.err }
	return identity.AccountSession{Account: record.Account, Session: record.Session}, nil
}
type unusedHandoffJournal struct { identity.TombstoneJournal }
type handoffHasher struct{}
func (handoffHasher) Hash(context.Context, string) (string, error) { return "test-only-hash", nil }
func (handoffHasher) Verify(context.Context, string, string) (bool, error) { return false, errors.New("unexpected password verification in registration") }

func TestIdentityServiceHandoffDistinguishesRollbackFromUncertainCommit(t *testing.T) {
	for _, test := range []struct {
		name string
		databaseError error
		cancelDuringDatabase bool
		guestSurvives bool
	}{
		{name: "unique_conflict_rolled_back", databaseError: identity.ErrConflict, guestSurvives: true},
		{name: "invalid_input_rolled_back", databaseError: identity.ErrInvalid, guestSurvives: true},
		{name: "commit_response_lost", databaseError: errors.New("synthetic uncertain commit")},
		{name: "request_canceled_during_database", databaseError: context.Canceled, cancelDuringDatabase: true},
		{name: "successful_registration"},
	} {
		t.Run(test.name, func(t *testing.T) {
			coordinator, clock := startGuestOwner(t)
			request, cancel := context.WithCancel(context.Background())
			defer cancel()
			store := &handoffStore{err: test.databaseError}
			if test.cancelDuringDatabase { store.cancel = cancel }
			policies := identity.PolicyVersions{Terms: "v1", Privacy: "v1", Community: "v1"}
			service, err := identity.New(identity.Options{Clock: clock, Store: store, Guests: coordinator, Journal: unusedHandoffJournal{}, Hasher: handoffHasher{}, Policies: policies})
			if err != nil { t.Fatal(err) }
			consent := identity.Consent{AdultConfirmed: true, Policies: policies}
			profile := identity.Profile{Gender: identity.GenderOther, Topic: "work_culture"}
			guest, err := service.StartGuest(context.Background(), identity.GuestInput{Profile: profile, Consent: consent})
			if err != nil { t.Fatal(err) }
			profile.DisplayName = "Workplace Cedar"
			registered, err := service.Register(request, guest.CookieToken, identity.RegisterInput{Username: "cedar_user", Password: "correct horse battery staple", Profile: profile, Consent: consent})
			if test.databaseError == nil {
				if err != nil || registered.CookieToken == "" || registered.HandoffState != "preserved" { t.Fatalf("registration handoff failed: %v", err) }
			} else if err == nil { t.Fatal("database failure returned an authenticated account") }
			_, guestErr := service.Authenticate(context.Background(), guest.CookieToken, false)
			if test.guestSurvives {
				if guestErr != nil { t.Fatalf("definite rollback lost original guest: %v", guestErr) }
			} else if !errors.Is(guestErr, identity.ErrUnauthorized) { t.Fatalf("uncertain/successful commit retained old guest access: %v", guestErr) }
			state, err := coordinator.Snapshot(context.Background())
			if err != nil || state.Handoffs != 0 { t.Fatal("transaction outcome left a frozen handoff") }
			if test.databaseError != nil && !test.guestSurvives && (state.Guests != 0 || state.ParticipantSlots != 0) { t.Fatal("uncertain commit retained a guest slot") }
		})
	}
}
