package identity

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base32"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"strconv"
	"strings"

	"golang.org/x/crypto/argon2"
)

// Argon2Hasher has a process-wide two-job budget when one instance is injected
// into Service. Admission fails fast instead of accumulating password waiters.
// Benchmark these starting parameters on the actual target before launch.
type Argon2Hasher struct { slots chan struct{} }

func NewArgon2Hasher() *Argon2Hasher { return &Argon2Hasher{slots: make(chan struct{}, 2)} }

func (h *Argon2Hasher) enter(ctx context.Context) error {
	if err := ctx.Err(); err != nil { return err }
	select {
	case h.slots <- struct{}{}: return nil
	default: return ErrBusy
	}
}

func (h *Argon2Hasher) Hash(ctx context.Context, password string) (string, error) {
	if err := ValidatePassword(password); err != nil { return "", err }
	if err := h.enter(ctx); err != nil { return "", err }
	defer func() { <-h.slots }()
	salt := make([]byte, 16)
	if _, err := rand.Read(salt); err != nil { return "", ErrUnavailable }
	key := argon2.IDKey([]byte(password), salt, 3, 64*1024, 1, 32)
	if err := ctx.Err(); err != nil { return "", err }
	return "$argon2id$v=19$m=65536,t=3,p=1$" + base64.RawStdEncoding.EncodeToString(salt) + "$" + base64.RawStdEncoding.EncodeToString(key), nil
}

func (h *Argon2Hasher) Verify(ctx context.Context, encoded, password string) (bool, error) {
	if err := ValidatePassword(password); err != nil { return false, ErrCredentials }
	params, salt, expected, err := parseArgon2(encoded)
	if err != nil { return false, ErrUnavailable }
	if err := h.enter(ctx); err != nil { return false, err }
	defer func() { <-h.slots }()
	actual := argon2.IDKey([]byte(password), salt, params.iterations, params.memory, params.threads, 32)
	if err := ctx.Err(); err != nil { return false, err }
	return subtle.ConstantTimeCompare(actual, expected) == 1, nil
}

type argonParameters struct { memory uint32; iterations uint32; threads uint8 }

func parseArgon2(encoded string) (argonParameters, []byte, []byte, error) {
	bad := func() (argonParameters, []byte, []byte, error) { return argonParameters{}, nil, nil, ErrInvalid }
	if len(encoded) > 256 { return bad() }
	parts := strings.Split(encoded, "$")
	if len(parts) != 6 || parts[0] != "" || parts[1] != "argon2id" || parts[2] != "v=19" { return bad() }
	costs := strings.Split(parts[3], ",")
	if len(costs) != 3 { return bad() }
	values := make([]uint64, 3)
	for i, prefix := range []string{"m=", "t=", "p="} {
		if !strings.HasPrefix(costs[i], prefix) { return bad() }
		s := strings.TrimPrefix(costs[i], prefix)
		if s == "" || len(s) > 6 { return bad() }
		for _, c := range s { if c < '0' || c > '9' { return bad() } }
		n, err := strconv.ParseUint(s, 10, 32)
		if err != nil { return bad() }
		values[i] = n
	}
	// Bounds are enforced before allocating Argon2 memory, including for hashes
	// read from storage. They cannot be overridden by an untrusted hash string.
	if values[0] < 19*1024 || values[0] > 64*1024 || values[1] < 1 || values[1] > 3 || values[2] < 1 || values[2] > 4 { return bad() }
	salt, err := base64.RawStdEncoding.Strict().DecodeString(parts[4])
	if err != nil || len(salt) != 16 { return bad() }
	key, err := base64.RawStdEncoding.Strict().DecodeString(parts[5])
	if err != nil || len(key) != 32 { return bad() }
	return argonParameters{memory: uint32(values[0]), iterations: uint32(values[1]), threads: uint8(values[2])}, salt, key, nil
}

func randomUUID() (string, error) {
	var value [16]byte
	if _, err := rand.Read(value[:]); err != nil { return "", ErrUnavailable }
	value[6] = value[6]&0x0f | 0x40
	value[8] = value[8]&0x3f | 0x80
	encoded := hex.EncodeToString(value[:])
	return fmt.Sprintf("%s-%s-%s-%s-%s", encoded[0:8], encoded[8:12], encoded[12:16], encoded[16:20], encoded[20:32]), nil
}

func randomSecret() (string, error) {
	var value [32]byte
	if _, err := rand.Read(value[:]); err != nil { return "", ErrUnavailable }
	return base64.RawURLEncoding.EncodeToString(value[:]), nil
}

func newSessionToken(kind Kind) (string, Verifier, error) {
	raw, err := randomSecret()
	if err != nil { return "", Verifier{}, err }
	prefix := "a."
	if kind == KindGuest { prefix = "g." }
	token := prefix + raw
	return token, digest("session", token), nil
}

func parseSessionToken(token string) (Kind, Verifier, error) {
	if len(token) != 45 || (token[:2] != "g." && token[:2] != "a.") { return "", Verifier{}, ErrUnauthorized }
	decoded, err := base64.RawURLEncoding.Strict().DecodeString(token[2:])
	if err != nil || len(decoded) != 32 { return "", Verifier{}, ErrUnauthorized }
	kind := KindAccount
	if token[:2] == "g." { kind = KindGuest }
	return kind, digest("session", token), nil
}

func digest(purpose, value string) Verifier {
	return sha256.Sum256([]byte("notitle:" + purpose + ":" + value))
}

func csrfForToken(token string) string {
	value := digest("csrf", token)
	return base64.RawURLEncoding.EncodeToString(value[:])
}

func newRecoveryCode() (string, Verifier, error) {
	var value [20]byte // 160 bits; no low-entropy human-selected recovery secret.
	if _, err := rand.Read(value[:]); err != nil { return "", Verifier{}, ErrUnavailable }
	code := base32.StdEncoding.WithPadding(base32.NoPadding).EncodeToString(value[:])
	groups := make([]string, 0, 8)
	for i := 0; i < len(code); i += 4 { groups = append(groups, code[i:i+4]) }
	return strings.Join(groups, "-"), digest("recovery", code), nil
}

func recoveryVerifier(code string) (Verifier, error) {
	if len(code) > 80 { return Verifier{}, ErrCredentials }
	code = strings.ToUpper(strings.NewReplacer("-", "", " ", "").Replace(code))
	if len(code) != 32 { return Verifier{}, ErrCredentials }
	decoded, err := base32.StdEncoding.WithPadding(base32.NoPadding).DecodeString(code)
	if err != nil || len(decoded) != 20 { return Verifier{}, ErrCredentials }
	return digest("recovery", code), nil
}

func receiptVerifier(receipt string) (Verifier, error) {
	if len(receipt) != 43 { return Verifier{}, ErrUnauthorized }
	decoded, err := base64.RawURLEncoding.Strict().DecodeString(receipt)
	if err != nil || len(decoded) != 32 { return Verifier{}, ErrUnauthorized }
	return digest("deletion", receipt), nil
}
