// Package identity defines Phase 3 identity contracts. Domain records are never
// serialized directly; only the explicit owner and peer DTOs cross the API.
package identity

import (
	"errors"
	"time"
)

type Kind string
const (
	KindGuest Kind = "guest"
	KindAccount Kind = "account"
)

type Gender string
const (
	GenderMale Gender = "male"
	GenderFemale Gender = "female"
	GenderOther Gender = "other"
)

const (
	GuestIdleTTL = 30 * time.Minute
	GuestAbsoluteTTL = 24 * time.Hour
	SessionIdleTTL = 7 * 24 * time.Hour
	SessionAbsoluteTTL = 30 * 24 * time.Hour
	RecentAuthenticationTTL = 5 * time.Minute
	HandoffTTL = 30 * time.Second
)

var (
	ErrInvalid = errors.New("invalid input")
	ErrUnauthorized = errors.New("authentication required")
	ErrCredentials = errors.New("credentials could not be verified")
	ErrConflict = errors.New("requested identity is unavailable")
	ErrUnavailable = errors.New("identity service is temporarily unavailable")
	ErrCapacity = errors.New("identity capacity reached")
	ErrBusy = errors.New("please retry shortly")
	ErrReauthentication = errors.New("recent authentication required")
	ErrStale = errors.New("identity changed; authenticate again")
	ErrHandoff = errors.New("registration finished; sign in to continue")
)

type ValidationError struct { Field string; Message string }
func (e *ValidationError) Error() string { return e.Field + ": " + e.Message }
func (e *ValidationError) Unwrap() error { return ErrInvalid }

// Verifier is a SHA-256 digest of a cryptographically random bearer secret.
// It must never enter JSON, logs, metrics labels, or a peer DTO.
type Verifier [32]byte

type PolicyVersions struct {
	Terms string `json:"terms"`
	Privacy string `json:"privacy"`
	Community string `json:"community"`
}
type Consent struct {
	AdultConfirmed bool `json:"adult_confirmed"`
	Policies PolicyVersions `json:"policies"`
}
type ProfessionalProfile struct {
	Profession string `json:"profession"`
	Industry string `json:"industry"`
	Experience string `json:"experience"`
	Interests []string `json:"interests"`
}
type Profile struct {
	Version int64 `json:"version"`
	DisplayName string `json:"display_name"`
	Gender Gender `json:"gender"`
	Bio string `json:"bio"`
	Topic string `json:"topic"`
	Professional ProfessionalProfile `json:"professional"`
}

// PublicPeer is the complete allowed peer projection. No username, internal ID,
// professional attributes, session details, or entitlement belongs here.
type PublicPeer struct {
	DisplayName string `json:"display_name"`
	Gender Gender `json:"gender"`
	Bio string `json:"bio"`
	Topic string `json:"topic"`
}
func (p Profile) PublicPeer() PublicPeer {
	return PublicPeer{DisplayName: p.DisplayName, Gender: p.Gender, Bio: p.Bio, Topic: p.Topic}
}

type OwnerDTO struct {
	Kind Kind `json:"kind"`
	Username string `json:"username,omitempty"`
	Profile Profile `json:"profile"`
	ExpiresAt time.Time `json:"expires_at"`
	AbsoluteExpiresAt time.Time `json:"absolute_expires_at"`
	ReauthenticationUntil *time.Time `json:"reauthentication_until,omitempty"`
}
type SessionDTO struct {
	Identity OwnerDTO `json:"identity"`
	CSRFToken string `json:"csrf_token"`
}
type AuthResult struct {
	Session SessionDTO
	CookieToken string `json:"-"`
	RecoveryCode string
	HandoffState string
}

type Guest struct {
	ID string
	Generation int64
	Verifier Verifier
	Profile Profile
	Consent Consent
	CreatedAt time.Time
	LastSeenAt time.Time
	AbsoluteExpiresAt time.Time
}
type GuestReservation struct {
	ID string
	Guest Guest
	ExpiresAt time.Time
}
type GuestCommit struct {
	AccountID string
	AccountGeneration int64
	SessionID string
	Profile Profile
}

type Account struct {
	ID string
	Username string
	Generation int64
	Status string
	Profile Profile
}
type Credentials struct {
	Account Account
	PasswordHash string
	RecoveryHash Verifier
}
type SessionRecord struct {
	ID string
	TokenHash Verifier
	AccountID string
	AccountGeneration int64
	CreatedAt time.Time
	LastSeenAt time.Time
	AbsoluteExpiresAt time.Time
	AuthenticatedAt time.Time
}
type AccountSession struct {
	Account Account
	Session SessionRecord
}
// Guard is checked inside every sensitive mutation transaction, together with
// active account status, unrevoked session, and both expiry deadlines.
type Guard struct {
	AccountID string
	AccountGeneration int64
	SessionID string
	TokenHash Verifier
	Now time.Time
	RequireRecent bool
}
type Principal struct {
	Kind Kind
	Guest Guest
	AccountSession AccountSession
	TokenHash Verifier
	CSRFToken string
}
func (p Principal) Guard(now time.Time, recent bool) Guard {
	return Guard{AccountID: p.AccountSession.Account.ID, AccountGeneration: p.AccountSession.Account.Generation, SessionID: p.AccountSession.Session.ID, TokenHash: p.TokenHash, Now: now, RequireRecent: recent}
}

type CreateAccountRecord struct {
	Account Account
	PasswordHash string
	RecoveryHash Verifier
	Consent Consent
	CreatedAt time.Time
	Session SessionRecord
	// GuestHandoff requires the durable safety fence to survive a crash between
	// account creation and the coordinator's relationship/restriction flush.
	GuestHandoff bool
}
type CredentialMutation struct {
	PasswordHash string
	RecoveryHash Verifier
	ReplacePassword bool
	ReplaceRecovery bool
	NewSession SessionRecord
}
type RecoveryMutation struct {
	AccountID string
	ExpectedGeneration int64
	ExpectedRecoveryHash Verifier
	PasswordHash string
	RecoveryHash Verifier
	NewSession SessionRecord
	Now time.Time
}
type DeletionRecord struct {
	ID string
	AccountID string
	AccountGeneration int64
	ReceiptHash Verifier
	RequestedAt time.Time
	TombstoneDurable bool
	State string
}
type Tombstone struct {
	DeletionID string `json:"deletion_id"`
	AccountID string `json:"account_id"`
	AccountGeneration int64 `json:"account_generation"`
	RequestedAt time.Time `json:"requested_at"`
}
type DeletionReceipt struct {
	Receipt string `json:"receipt,omitempty"`
	AccessDisabled bool `json:"access_disabled"`
	TombstoneDurable bool `json:"tombstone_durable"`
	State string `json:"state"`
	RequestedAt time.Time `json:"requested_at"`
}

type GuestInput struct { Profile Profile `json:"profile"`; Consent Consent `json:"consent"` }
type RegisterInput struct {
	Username string `json:"username"`
	Password string `json:"password"`
	Profile Profile `json:"profile"`
	Consent Consent `json:"consent"`
}
type LoginInput struct { Username string `json:"username"`; Password string `json:"password"` }
type RecoveryInput struct { Username string `json:"username"`; RecoveryCode string `json:"recovery_code"`; NewPassword string `json:"new_password"` }
type PasswordInput struct { NewPassword string `json:"new_password"` }
type ReauthenticateInput struct { Password string `json:"password"` }
type DeleteInput struct { Confirm bool `json:"confirm"` }
