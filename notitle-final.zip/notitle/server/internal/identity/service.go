package identity

import (
	"context"
	"crypto/subtle"
	"errors"
	"strings"
	"time"
)

type Service struct {
	clock Clock
	store Store
	guests GuestRegistry
	journal TombstoneJournal
	hasher PasswordHasher
	policies PolicyVersions
}

func New(options Options) (*Service, error) {
	if options.Clock == nil || options.Store == nil || options.Guests == nil || options.Journal == nil || options.Hasher == nil || !ValidPolicyVersions(options.Policies) {
		return nil, errors.New("identity dependencies and valid policy versions are required")
	}
	return &Service{clock: options.Clock, store: options.Store, guests: options.Guests, journal: options.Journal, hasher: options.Hasher, policies: options.Policies}, nil
}

func (s *Service) Policies() PolicyVersions { return s.policies }

func (s *Service) StartGuest(ctx context.Context, input GuestInput) (AuthResult, error) {
	if err := ValidateConsent(input.Consent, s.policies); err != nil { return AuthResult{}, err }
	id, err := randomUUID()
	if err != nil { return AuthResult{}, err }
	input.Profile.DisplayName = "Guest " + strings.ToUpper(strings.ReplaceAll(id, "-", "")[:8])
	input.Profile.Version = 1
	if input.Profile.Topic == "" { input.Profile.Topic = "general_talk" }
	if err := ValidateProfile(input.Profile); err != nil { return AuthResult{}, err }
	token, verifier, err := newSessionToken(KindGuest)
	if err != nil { return AuthResult{}, err }
	now := s.clock.Now().UTC()
	guest, err := s.guests.CreateGuest(ctx, Guest{ID: id, Generation: 1, Verifier: verifier, Profile: input.Profile, Consent: input.Consent, CreatedAt: now, LastSeenAt: now, AbsoluteExpiresAt: now.Add(GuestAbsoluteTTL)})
	if err != nil { return AuthResult{}, safeError(err) }
	return guestResult(guest, token), nil
}

func (s *Service) Authenticate(ctx context.Context, token string, touch bool) (Principal, error) {
	kind, verifier, err := parseSessionToken(token)
	if err != nil { return Principal{}, err }
	now := s.clock.Now().UTC()
	if kind == KindGuest {
		guest, err := s.guests.AuthenticateGuest(ctx, verifier, now, touch)
		if err != nil { return Principal{}, safeError(err) }
		return Principal{Kind: KindGuest, Guest: guest, TokenHash: verifier, CSRFToken: csrfForToken(token)}, nil
	}
	account, err := s.store.Authenticate(ctx, verifier, now, touch)
	if err != nil { return Principal{}, safeError(err) }
	if account.Account.Status != "active" || account.Account.Generation != account.Session.AccountGeneration {
		return Principal{}, ErrUnauthorized
	}
	return Principal{Kind: KindAccount, AccountSession: account, TokenHash: verifier, CSRFToken: csrfForToken(token)}, nil
}

// RefreshPrincipal validates a verifier already obtained from an authenticated
// cookie. Realtime never stores or reconstructs bearer cookie secrets. A cached
// Principal is not authorization: revocation, expiry and profile changes are
// fetched again before returning this new value.
func (s *Service) RefreshPrincipal(ctx context.Context, previous Principal, touch bool) (Principal, error) {
    now := s.clock.Now().UTC()
    if previous.TokenHash == (Verifier{}) { return Principal{}, ErrUnauthorized }
    switch previous.Kind {
    case KindGuest:
        guest, err := s.guests.AuthenticateGuest(ctx, previous.TokenHash, now, touch)
        if err != nil { return Principal{}, safeError(err) }
        if guest.ID != previous.Guest.ID { return Principal{}, ErrUnauthorized }
        return Principal{Kind: KindGuest, Guest: guest, TokenHash: previous.TokenHash}, nil
    case KindAccount:
        account, err := s.store.Authenticate(ctx, previous.TokenHash, now, touch)
        if err != nil { return Principal{}, safeError(err) }
        if account.Account.Status != "active" || account.Account.Generation != account.Session.AccountGeneration || account.Account.ID != previous.AccountSession.Account.ID || account.Session.ID != previous.AccountSession.Session.ID {
            return Principal{}, ErrUnauthorized
        }
        return Principal{Kind: KindAccount, AccountSession: account, TokenHash: previous.TokenHash}, nil
    default:
        return Principal{}, ErrUnauthorized
    }
}

func (s *Service) Current(ctx context.Context, token string) (SessionDTO, error) {
	principal, err := s.Authenticate(ctx, token, true)
	if err != nil { return SessionDTO{}, err }
	return SessionDTO{Identity: owner(principal), CSRFToken: principal.CSRFToken}, nil
}

func (s *Service) Register(ctx context.Context, currentCookie string, input RegisterInput) (AuthResult, error) {
	if input.Profile.Topic == "" { input.Profile.Topic = "general_talk" }
	username, err := NormalizeUsername(input.Username)
	if err != nil { return AuthResult{}, err }
	if err := ValidatePassword(input.Password); err != nil { return AuthResult{}, err }
	if err := ValidateProfile(input.Profile); err != nil { return AuthResult{}, err }
	if err := ValidateConsent(input.Consent, s.policies); err != nil { return AuthResult{}, err }
	var guest *Guest
	if currentCookie != "" {
		principal, err := s.Authenticate(ctx, currentCookie, false)
		if err != nil { return AuthResult{}, err }
		if principal.Kind != KindGuest { return AuthResult{}, ErrConflict }
		if principal.Guest.Profile.Gender != input.Profile.Gender {
			return AuthResult{}, &ValidationError{Field: "gender", Message: "confirm the gender selected for this guest; update your guest profile first if needed"}
		}
		guest = &principal.Guest
	}
	passwordHash, err := s.hasher.Hash(ctx, input.Password)
	if err != nil { return AuthResult{}, safeError(err) }
	recovery, recoveryHash, err := newRecoveryCode()
	if err != nil { return AuthResult{}, err }
	accountID, err := randomUUID()
	if err != nil { return AuthResult{}, err }
	now := s.clock.Now().UTC()
	token, session, err := makeSession(accountID, 1, now)
	if err != nil { return AuthResult{}, err }
	var reservation *GuestReservation
	if guest != nil {
		reserved, err := s.guests.PrepareGuestHandoff(ctx, guest.Verifier, guest.Generation, now)
		if err != nil { return AuthResult{}, safeError(err) }
		reservation = &reserved
	}
	input.Profile.Version = 1
	handoffSafety := false
	if reservation != nil { if registry, ok := s.guests.(interface{ SafetyHandoffRequired() bool }); ok { handoffSafety = registry.SafetyHandoffRequired() } }
	created, err := s.store.CreateAccount(ctx, CreateAccountRecord{Account: Account{ID: accountID, Username: username, Generation: 1, Status: "active", Profile: input.Profile}, PasswordHash: passwordHash, RecoveryHash: recoveryHash, Consent: input.Consent, CreatedAt: now, Session: session, GuestHandoff: handoffSafety})
	if err != nil {
		if reservation != nil {
			// Only deterministic validation/conflict failures establish noncommit.
			// An interrupted transaction may have committed: safely end the guest.
			safeToResume := errors.Is(err, ErrConflict) || errors.Is(err, ErrInvalid)
			s.abortHandoff(ctx, *reservation, safeToResume)
		}
		return AuthResult{}, safeError(err)
	}
	result := accountResult(created, token)
	result.RecoveryCode = recovery
	result.HandoffState = "idle"
	if reservation != nil {
		continued, commitErr := s.guests.CommitGuestHandoff(ctx, *reservation, GuestCommit{AccountID: created.Account.ID, AccountGeneration: created.Account.Generation, SessionID: created.Session.ID, Profile: created.Account.Profile}, s.clock.Now().UTC())
		if commitErr != nil {
			s.abortHandoff(ctx, *reservation, false)
			cleanup, cancel := cleanupContext(ctx)
			defer cancel()
			_ = s.store.RevokeSession(cleanup, principalForAccount(created, token).Guard(s.clock.Now().UTC(), false))
			return AuthResult{}, ErrHandoff
		}
		if continued { result.HandoffState = "preserved" }
	}
	return result, nil
}

func (s *Service) Login(ctx context.Context, currentCookie string, input LoginInput) (AuthResult, error) {
	username, err := NormalizeUsername(input.Username)
	if err != nil { return AuthResult{}, ErrCredentials }
	if err := ValidatePassword(input.Password); err != nil { return AuthResult{}, ErrCredentials }
	credentials, err := s.store.FindCredentials(ctx, username)
	if err != nil {
		if errors.Is(err, ErrCredentials) || errors.Is(err, ErrUnauthorized) {
			// Equal expensive work for a missing/disabled username; HTTP rate limits
			// run first and the hasher bounds concurrent memory use.
			if _, hashErr := s.hasher.Hash(ctx, input.Password); hashErr != nil { return AuthResult{}, safeError(hashErr) }
			return AuthResult{}, ErrCredentials
		}
		return AuthResult{}, safeError(err)
	}
	valid, err := s.hasher.Verify(ctx, credentials.PasswordHash, input.Password)
	if err != nil { return AuthResult{}, safeError(err) }
	if !valid || credentials.Account.Status != "active" { return AuthResult{}, ErrCredentials }
	// Logging into an existing account never transfers a guest's connections or
	// safety state. End that identity before switching the browser credential.
	if err := s.endPreviousIdentity(ctx, currentCookie); err != nil { return AuthResult{}, err }
	now := s.clock.Now().UTC()
	token, session, err := makeSession(credentials.Account.ID, credentials.Account.Generation, now)
	if err != nil { return AuthResult{}, err }
	created, err := s.store.CreateSession(ctx, credentials.Account.ID, credentials.Account.Generation, session, now)
	if err != nil { return AuthResult{}, safeError(err) }
	return accountResult(created, token), nil
}

func (s *Service) Recover(ctx context.Context, currentCookie string, input RecoveryInput) (AuthResult, error) {
	username, err := NormalizeUsername(input.Username)
	if err != nil { return AuthResult{}, ErrCredentials }
	if err := ValidatePassword(input.NewPassword); err != nil { return AuthResult{}, err }
	provided, err := recoveryVerifier(input.RecoveryCode)
	if err != nil { return AuthResult{}, ErrCredentials }
	credentials, err := s.store.FindCredentials(ctx, username)
	if err != nil { return AuthResult{}, credentialError(err) }
	if credentials.Account.Status != "active" || subtle.ConstantTimeCompare(provided[:], credentials.RecoveryHash[:]) != 1 { return AuthResult{}, ErrCredentials }
	passwordHash, err := s.hasher.Hash(ctx, input.NewPassword)
	if err != nil { return AuthResult{}, safeError(err) }
	recovery, recoveryHash, err := newRecoveryCode()
	if err != nil { return AuthResult{}, err }
	now := s.clock.Now().UTC()
	token, session, err := makeSession(credentials.Account.ID, credentials.Account.Generation+1, now)
	if err != nil { return AuthResult{}, err }
	if err := s.endPreviousIdentity(ctx, currentCookie); err != nil { return AuthResult{}, err }
	// The verifier is compared again under the database account lock. Concurrent
	// recovery requests cannot both consume the same code.
	created, err := s.store.Recover(ctx, RecoveryMutation{AccountID: credentials.Account.ID, ExpectedGeneration: credentials.Account.Generation, ExpectedRecoveryHash: provided, PasswordHash: passwordHash, RecoveryHash: recoveryHash, NewSession: session, Now: now})
	if err != nil { return AuthResult{}, credentialError(err) }
	cleanup, cancel := cleanupContext(ctx)
	defer cancel()
	if err := s.guests.InvalidateAccount(cleanup, credentials.Account.ID, now); err != nil {
        s.failClosed()
		_ = s.store.RevokeSession(cleanup, principalForAccount(created, token).Guard(now, false))
		return AuthResult{}, ErrUnavailable
	}
	result := accountResult(created, token)
	result.RecoveryCode = recovery
	return result, nil
}

func (s *Service) UpdateProfile(ctx context.Context, principal Principal, profile Profile) (OwnerDTO, error) {
	if profile.Version < 1 { return OwnerDTO{}, &ValidationError{Field: "version", Message: "refresh the profile and retry with its current version"} }
	if err := ValidateProfile(profile); err != nil { return OwnerDTO{}, err }
	now := s.clock.Now().UTC()
	if principal.Kind == KindGuest {
		// A guest retains the stable generated pseudonym for this identity.
		if profile.DisplayName != principal.Guest.Profile.DisplayName { return OwnerDTO{}, &ValidationError{Field: "display_name", Message: "guest pseudonyms remain fixed for this session"} }
		guest, err := s.guests.UpdateGuest(ctx, principal.TokenHash, principal.Guest.Generation, profile, now)
		if err != nil { return OwnerDTO{}, safeError(err) }
		principal.Guest = guest
		return owner(principal), nil
	}
	if principal.Kind != KindAccount { return OwnerDTO{}, ErrUnauthorized }
	account, err := s.store.UpdateProfile(ctx, principal.Guard(now, false), profile)
	if err != nil { return OwnerDTO{}, safeError(err) }
    // A successful profile response means the owner has already reindexed any
    // waiting participant. Existing interactions keep their original peer DTO.
    if observer, ok := s.guests.(ProfileObserver); ok {
        cleanup, cancel := cleanupContext(ctx)
        defer cancel()
        if err := observer.ProfileChanged(cleanup, account, now); err != nil {
            emergency, stop := cleanupContext(ctx)
            invalidateErr := s.guests.InvalidateAccount(emergency, account.ID, now)
            stop()
            if invalidateErr != nil {
                s.failClosed()
                if stopper, ok := s.guests.(interface{ HealthOutage(context.Context, bool) error }); ok {
                    emergency, stop = cleanupContext(ctx)
                    _ = stopper.HealthOutage(emergency, true)
                    stop()
                }
            }
            return OwnerDTO{}, ErrUnavailable
        }
    }
	principal.AccountSession.Account = account
	if now.After(principal.AccountSession.Session.LastSeenAt) { principal.AccountSession.Session.LastSeenAt = now }
	return owner(principal), nil
}

func (s *Service) Reauthenticate(ctx context.Context, principal Principal, input ReauthenticateInput) (time.Time, error) {
	if principal.Kind != KindAccount { return time.Time{}, ErrUnauthorized }
	if err := ValidatePassword(input.Password); err != nil { return time.Time{}, ErrCredentials }
	credentials, err := s.store.FindCredentials(ctx, principal.AccountSession.Account.Username)
	if err != nil { return time.Time{}, credentialError(err) }
	if credentials.Account.Generation != principal.AccountSession.Account.Generation { return time.Time{}, ErrStale }
	valid, err := s.hasher.Verify(ctx, credentials.PasswordHash, input.Password)
	if err != nil { return time.Time{}, safeError(err) }
	if !valid { return time.Time{}, ErrCredentials }
	now := s.clock.Now().UTC()
	if err := s.store.Reauthenticate(ctx, principal.Guard(now, false)); err != nil { return time.Time{}, safeError(err) }
	return now.Add(RecentAuthenticationTTL), nil
}

func (s *Service) ChangePassword(ctx context.Context, principal Principal, input PasswordInput) (AuthResult, error) {
	if err := requireRecent(principal, s.clock.Now()); err != nil { return AuthResult{}, err }
	if err := ValidatePassword(input.NewPassword); err != nil { return AuthResult{}, err }
	hash, err := s.hasher.Hash(ctx, input.NewPassword)
	if err != nil { return AuthResult{}, safeError(err) }
	return s.changeCredentials(ctx, principal, CredentialMutation{PasswordHash: hash, ReplacePassword: true}, "")
}

func (s *Service) RotateRecovery(ctx context.Context, principal Principal) (AuthResult, error) {
	if err := requireRecent(principal, s.clock.Now()); err != nil { return AuthResult{}, err }
	code, hash, err := newRecoveryCode()
	if err != nil { return AuthResult{}, err }
	return s.changeCredentials(ctx, principal, CredentialMutation{RecoveryHash: hash, ReplaceRecovery: true}, code)
}

func (s *Service) changeCredentials(ctx context.Context, principal Principal, mutation CredentialMutation, recovery string) (AuthResult, error) {
	now := s.clock.Now().UTC()
	token, session, err := makeSession(principal.AccountSession.Account.ID, principal.AccountSession.Account.Generation+1, now)
	if err != nil { return AuthResult{}, err }
	mutation.NewSession = session
	created, err := s.store.ChangeCredentials(ctx, principal.Guard(now, true), mutation)
	if err != nil { return AuthResult{}, safeError(err) }
	cleanup, cancel := cleanupContext(ctx)
	defer cancel()
	if err := s.guests.InvalidateAccount(cleanup, principal.AccountSession.Account.ID, now); err != nil {
        s.failClosed()
		_ = s.store.RevokeSession(cleanup, principalForAccount(created, token).Guard(now, false))
		return AuthResult{}, ErrUnavailable
	}
	result := accountResult(created, token)
	result.RecoveryCode = recovery
	return result, nil
}

func (s *Service) Logout(ctx context.Context, principal Principal) error {
	now := s.clock.Now().UTC()
	if principal.Kind == KindGuest { return safeError(s.guests.EndGuest(ctx, principal.TokenHash, now)) }
	if principal.Kind != KindAccount { return ErrUnauthorized }
	if err := s.store.RevokeSession(ctx, principal.Guard(now, false)); err != nil { return safeError(err) }
	cleanup, cancel := cleanupContext(ctx)
	defer cancel()
	if err := s.guests.InvalidateSession(cleanup, principal.AccountSession.Account.ID, principal.AccountSession.Session.ID, now); err != nil {
        s.failClosed()
        return safeError(err)
    }
    return nil
}

func (s *Service) LogoutAll(ctx context.Context, principal Principal) error {
	if principal.Kind != KindAccount { return ErrUnauthorized }
	now := s.clock.Now().UTC()
	if err := s.store.RevokeAllSessions(ctx, principal.Guard(now, false)); err != nil { return safeError(err) }
	cleanup, cancel := cleanupContext(ctx)
	defer cancel()
	if err := s.guests.InvalidateAccount(cleanup, principal.AccountSession.Account.ID, now); err != nil {
        s.failClosed()
        return safeError(err)
    }
    return nil
}

func (s *Service) Delete(ctx context.Context, principal Principal, input DeleteInput) (DeletionReceipt, error) {
	if !input.Confirm { return DeletionReceipt{}, &ValidationError{Field: "confirm", Message: "explicitly confirm account deletion"} }
	if err := requireRecent(principal, s.clock.Now()); err != nil { return DeletionReceipt{}, err }
	id, err := randomUUID()
	if err != nil { return DeletionReceipt{}, err }
	receipt, err := randomSecret()
	if err != nil { return DeletionReceipt{}, err }
	now := s.clock.Now().UTC().Truncate(time.Microsecond)
	record, err := s.store.BeginDeletion(ctx, principal.Guard(now, true), DeletionRecord{ID: id, AccountID: principal.AccountSession.Account.ID, AccountGeneration: principal.AccountSession.Account.Generation+1, ReceiptHash: digest("deletion", receipt), RequestedAt: now, State: "awaiting_retention_review"})
	if err != nil { return DeletionReceipt{}, safeError(err) }
	cleanup, cancel := cleanupContext(ctx)
	defer cancel()
	// Durable access revocation has already committed. A coordinator failure
	// never rolls it back; Phase 4 must end sockets when revocation is uncertain.
	if err := s.guests.RemoveAccount(cleanup, record.AccountID, now); err != nil { s.failClosed() }
	if s.journal.Append(cleanup, tombstone(record)) == nil {
		// A crash between append and DB acknowledgement is repaired by idempotent
		// retry/startup replay. Only the independent journal establishes durability.
		record.TombstoneDurable = true
		_ = s.store.MarkTombstoneDurable(cleanup, record.ID, now)
	}
	result := deletionReceipt(record)
	result.Receipt = receipt
	return result, nil
}

func (s *Service) DeletionStatus(ctx context.Context, receipt string) (DeletionReceipt, error) {
	verifier, err := receiptVerifier(receipt)
	if err != nil { return DeletionReceipt{}, err }
	record, err := s.store.DeletionByReceipt(ctx, verifier)
	if err != nil { return DeletionReceipt{}, safeError(err) }
	return deletionReceipt(record), nil
}

func (s *Service) RetryTombstones(ctx context.Context, limit int) error {
	if limit < 1 || limit > 100 { return ErrInvalid }
	records, err := s.store.PendingTombstones(ctx, limit)
	if err != nil { return safeError(err) }
	for _, record := range records {
		if err := s.journal.Append(ctx, tombstone(record)); err != nil { return ErrUnavailable }
		if err := s.store.MarkTombstoneDurable(ctx, record.ID, s.clock.Now().UTC()); err != nil { return safeError(err) }
	}
	return nil
}

func (s *Service) PruneSessions(ctx context.Context, limit int) error {
	if limit < 1 || limit > 1000 { return ErrInvalid }
	return safeError(s.store.PruneExpiredSessions(ctx, s.clock.Now().UTC(), limit))
}

func (s *Service) endPreviousIdentity(ctx context.Context, token string) error {
	if token == "" { return nil }
	principal, err := s.Authenticate(ctx, token, false)
	if errors.Is(err, ErrUnauthorized) || errors.Is(err, ErrStale) { return nil }
	if err != nil { return err }
	return s.Logout(ctx, principal)
}

func (s *Service) abortHandoff(ctx context.Context, reservation GuestReservation, safeToResume bool) {
	cleanup, cancel := cleanupContext(ctx)
	defer cancel()
	if err := s.guests.AbortGuestHandoff(cleanup, reservation, safeToResume, s.clock.Now().UTC()); err != nil && !safeToResume { s.failClosed() }
}

// A committed security mutation that cannot reach the live owner is a global
// trust failure. The realtime owner implements an atomic, sticky latch; routine
// database recovery must never clear it. Phase 3-only test registries omit it.
func (s *Service) failClosed() {
    if stopper, ok := s.guests.(interface{ FailClosed() }); ok { stopper.FailClosed() }
}

func makeSession(accountID string, generation int64, now time.Time) (string, SessionRecord, error) {
	token, hash, err := newSessionToken(KindAccount)
	if err != nil { return "", SessionRecord{}, err }
	id, err := randomUUID()
	if err != nil { return "", SessionRecord{}, err }
	return token, SessionRecord{ID: id, TokenHash: hash, AccountID: accountID, AccountGeneration: generation, CreatedAt: now, LastSeenAt: now, AbsoluteExpiresAt: now.Add(SessionAbsoluteTTL), AuthenticatedAt: now}, nil
}

func principalForAccount(account AccountSession, token string) Principal {
	return Principal{Kind: KindAccount, AccountSession: account, TokenHash: account.Session.TokenHash, CSRFToken: csrfForToken(token)}
}
func accountResult(account AccountSession, token string) AuthResult {
	principal := principalForAccount(account, token)
	return AuthResult{Session: SessionDTO{Identity: owner(principal), CSRFToken: principal.CSRFToken}, CookieToken: token}
}
func guestResult(guest Guest, token string) AuthResult {
	principal := Principal{Kind: KindGuest, Guest: guest, TokenHash: guest.Verifier, CSRFToken: csrfForToken(token)}
	return AuthResult{Session: SessionDTO{Identity: owner(principal), CSRFToken: principal.CSRFToken}, CookieToken: token}
}
func owner(principal Principal) OwnerDTO {
	if principal.Kind == KindGuest {
		g := principal.Guest
		return OwnerDTO{Kind: KindGuest, Profile: ownerProfile(g.Profile), ExpiresAt: earliest(g.LastSeenAt.Add(GuestIdleTTL), g.AbsoluteExpiresAt), AbsoluteExpiresAt: g.AbsoluteExpiresAt}
	}
	a := principal.AccountSession
	reauthenticationUntil := a.Session.AuthenticatedAt.Add(RecentAuthenticationTTL)
	return OwnerDTO{Kind: KindAccount, Username: a.Account.Username, Profile: ownerProfile(a.Account.Profile), ExpiresAt: earliest(a.Session.LastSeenAt.Add(SessionIdleTTL), a.Session.AbsoluteExpiresAt), AbsoluteExpiresAt: a.Session.AbsoluteExpiresAt, ReauthenticationUntil: &reauthenticationUntil}
}
func ownerProfile(profile Profile) Profile {
	profile.Professional.Interests = append([]string{}, profile.Professional.Interests...)
	return profile
}
func earliest(a, b time.Time) time.Time { if a.Before(b) { return a }; return b }
func requireRecent(principal Principal, now time.Time) error {
	if principal.Kind != KindAccount { return ErrUnauthorized }
	authenticated := principal.AccountSession.Session.AuthenticatedAt
	if authenticated.IsZero() || authenticated.After(now) || !now.Before(authenticated.Add(RecentAuthenticationTTL)) { return ErrReauthentication }
	return nil
}
func tombstone(record DeletionRecord) Tombstone {
	return Tombstone{DeletionID: record.ID, AccountID: record.AccountID, AccountGeneration: record.AccountGeneration, RequestedAt: record.RequestedAt}
}
func deletionReceipt(record DeletionRecord) DeletionReceipt {
	return DeletionReceipt{AccessDisabled: true, TombstoneDurable: record.TombstoneDurable, State: record.State, RequestedAt: record.RequestedAt}
}
func cleanupContext(parent context.Context) (context.Context, context.CancelFunc) {
	return context.WithTimeout(context.WithoutCancel(parent), 3*time.Second)
}
func credentialError(err error) error {
	if errors.Is(err, ErrUnauthorized) || errors.Is(err, ErrStale) || errors.Is(err, ErrConflict) || errors.Is(err, ErrCredentials) { return ErrCredentials }
	return safeError(err)
}
func safeError(err error) error {
	if err == nil { return nil }
	var validation *ValidationError
	if errors.As(err, &validation) { return validation }
	for _, allowed := range []error{ErrInvalid, ErrUnauthorized, ErrCredentials, ErrConflict, ErrUnavailable, ErrCapacity, ErrBusy, ErrReauthentication, ErrStale, ErrHandoff} {
		if errors.Is(err, allowed) { return allowed }
	}
	return ErrUnavailable
}
