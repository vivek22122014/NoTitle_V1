package identity

import (
	"context"
	"errors"
	"fmt"
	"testing"
	"time"
)

type testClock struct { now time.Time }
func (c *testClock) Now() time.Time { return c.now }

type testHasher struct { calls int }
func (h *testHasher) Hash(_ context.Context, password string) (string, error) { h.calls++; return "test-only:" + password, nil }
func (h *testHasher) Verify(_ context.Context, hash, password string) (bool, error) { h.calls++; return hash == "test-only:" + password, nil }

type fakeGuests struct {
	GuestRegistry
	guest Guest
	prepareCalls int
	abortCalls int
	abortEnded bool
	commitErr error
	preserved bool
	endCalls int
	invalidations int
	invalidatedSessions int
	removals int
}
func (g *fakeGuests) CreateGuest(_ context.Context, guest Guest) (Guest, error) { g.guest = guest; return guest, nil }
func (g *fakeGuests) AuthenticateGuest(_ context.Context, verifier Verifier, now time.Time, touch bool) (Guest, error) {
	if verifier != g.guest.Verifier || g.guest.ID == "" || !now.Before(g.guest.AbsoluteExpiresAt) || !now.Before(g.guest.LastSeenAt.Add(GuestIdleTTL)) { return Guest{}, ErrUnauthorized }
	if touch { g.guest.LastSeenAt = now }
	return g.guest, nil
}
func (g *fakeGuests) PrepareGuestHandoff(_ context.Context, verifier Verifier, generation int64, now time.Time) (GuestReservation, error) {
	if verifier != g.guest.Verifier || generation != g.guest.Generation { return GuestReservation{}, ErrStale }
	g.prepareCalls++
	return GuestReservation{ID: "reservation", Guest: g.guest, ExpiresAt: now.Add(HandoffTTL)}, nil
}
func (g *fakeGuests) CommitGuestHandoff(_ context.Context, _ GuestReservation, _ GuestCommit, _ time.Time) (bool, error) { return g.preserved, g.commitErr }
func (g *fakeGuests) AbortGuestHandoff(_ context.Context, _ GuestReservation, safeToResume bool, _ time.Time) error { g.abortCalls++; g.abortEnded = !safeToResume; return nil }
func (g *fakeGuests) EndGuest(_ context.Context, _ Verifier, _ time.Time) error { g.endCalls++; g.guest = Guest{}; return nil }
func (g *fakeGuests) InvalidateAccount(_ context.Context, _ string, _ time.Time) error { g.invalidations++; return nil }
func (g *fakeGuests) InvalidateSession(_ context.Context, _, _ string, _ time.Time) error { g.invalidatedSessions++; return nil }
func (g *fakeGuests) RemoveAccount(_ context.Context, _ string, _ time.Time) error { g.removals++; return nil }

type fakeStore struct {
	Store
	createErr error
	credentials Credentials
	created CreateAccountRecord
	revoked int
	recoveryCalls int
	deletion DeletionRecord
	marked bool
	disabled bool
	previousSession AccountSession
}
func (f *fakeStore) Authenticate(_ context.Context, hash Verifier, _ time.Time, _ bool) (AccountSession, error) {
	if f.previousSession.Session.TokenHash != hash || hash == (Verifier{}) { return AccountSession{}, ErrUnauthorized }
	return f.previousSession, nil
}
func (f *fakeStore) CreateAccount(_ context.Context, record CreateAccountRecord) (AccountSession, error) {
	f.created = record
	if f.createErr != nil { return AccountSession{}, f.createErr }
	f.credentials = Credentials{Account: record.Account, PasswordHash: record.PasswordHash, RecoveryHash: record.RecoveryHash}
	return AccountSession{Account: record.Account, Session: record.Session}, nil
}
func (f *fakeStore) FindCredentials(_ context.Context, username string) (Credentials, error) {
	if f.credentials.Account.Username != username || f.disabled { return Credentials{}, ErrCredentials }
	return f.credentials, nil
}
func (f *fakeStore) CreateSession(_ context.Context, id string, generation int64, session SessionRecord, _ time.Time) (AccountSession, error) {
	if id != f.credentials.Account.ID || generation != f.credentials.Account.Generation { return AccountSession{}, ErrStale }
	return AccountSession{Account: f.credentials.Account, Session: session}, nil
}
func (f *fakeStore) RevokeSession(_ context.Context, _ Guard) error { f.revoked++; return nil }
func (f *fakeStore) Recover(_ context.Context, mutation RecoveryMutation) (AccountSession, error) {
	f.recoveryCalls++
	if mutation.ExpectedGeneration != f.credentials.Account.Generation || mutation.ExpectedRecoveryHash != f.credentials.RecoveryHash { return AccountSession{}, ErrCredentials }
	f.credentials.Account.Generation++
	f.credentials.RecoveryHash = mutation.RecoveryHash
	f.credentials.PasswordHash = mutation.PasswordHash
	return AccountSession{Account: f.credentials.Account, Session: mutation.NewSession}, nil
}
func (f *fakeStore) BeginDeletion(_ context.Context, _ Guard, record DeletionRecord) (DeletionRecord, error) { f.disabled = true; f.deletion = record; return record, nil }
func (f *fakeStore) MarkTombstoneDurable(_ context.Context, _ string, _ time.Time) error { f.marked = true; f.deletion.TombstoneDurable = true; return nil }

type fakeJournal struct { err error; appended []Tombstone }
func (j *fakeJournal) Append(_ context.Context, tombstone Tombstone) error { if j.err != nil { return j.err }; j.appended = append(j.appended, tombstone); return nil }

func testService(t *testing.T) (*Service, *fakeStore, *fakeGuests, *fakeJournal, *testClock) {
	t.Helper()
	clock := &testClock{now: time.Date(2026, 10, 9, 12, 0, 0, 0, time.UTC)}
	store := &fakeStore{}
	guests := &fakeGuests{}
	journal := &fakeJournal{}
	service, err := New(Options{Clock: clock, Store: store, Guests: guests, Journal: journal, Hasher: &testHasher{}, Policies: PolicyVersions{Terms: "terms-v1", Privacy: "privacy-v1", Community: "rules-v1"}})
	if err != nil { t.Fatal(err) }
	return service, store, guests, journal, clock
}
func registerInput(service *Service) RegisterInput {
	return RegisterInput{Username: "sparrow_42", Password: "a password manager phrase", Profile: validProfile(), Consent: Consent{AdultConfirmed: true, Policies: service.Policies()}}
}

func TestRegistrationHandoffFailureStates(t *testing.T) {
	for _, tc := range []struct { name string; databaseError error; commitError error; expectEnd bool; expectRevoke bool }{
		{"duplicate keeps guest", ErrConflict, nil, false, false},
		{"uncertain database ends guest", errors.New("connection interrupted during commit"), nil, true, false},
		{"coordinator failure revokes new session", nil, ErrStale, true, true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			service, store, guests, _, _ := testService(t)
			guest, err := service.StartGuest(context.Background(), GuestInput{Profile: validProfile(), Consent: registerInput(service).Consent})
			if err != nil { t.Fatal(err) }
			store.createErr = tc.databaseError
			guests.commitErr = tc.commitError
			_, err = service.Register(context.Background(), guest.CookieToken, registerInput(service))
			if err == nil { t.Fatal("expected safe registration failure") }
			if guests.prepareCalls != 1 || guests.abortCalls != 1 || guests.abortEnded != tc.expectEnd { t.Fatalf("wrong reservation cleanup: %+v", guests) }
			if (store.revoked == 1) != tc.expectRevoke { t.Fatalf("wrong new-session revocation count %d", store.revoked) }
		})
	}
}

func TestRegistrationRotatesCookieAndConfirmsGuestGender(t *testing.T) {
	service, _, guests, _, _ := testService(t)
	guest, err := service.StartGuest(context.Background(), GuestInput{Profile: validProfile(), Consent: registerInput(service).Consent})
	if err != nil { t.Fatal(err) }
	input := registerInput(service)
	input.Profile.Gender = GenderFemale
	if _, err := service.Register(context.Background(), guest.CookieToken, input); !errors.Is(err, ErrInvalid) { t.Fatalf("unconfirmed gender accepted: %v", err) }
	if guests.prepareCalls != 0 { t.Fatal("invalid registration reserved guest") }
	created, err := service.Register(context.Background(), guest.CookieToken, registerInput(service))
	if err != nil { t.Fatal(err) }
	if created.CookieToken == guest.CookieToken || created.RecoveryCode == "" || created.Session.Identity.Kind != KindAccount || created.HandoffState != "idle" { t.Fatal("registration did not rotate into honest idle account") }
}

func TestRecoveryConsumesCodeAndRotatesAllCredentials(t *testing.T) {
	service, store, guests, _, _ := testService(t)
	registered, err := service.Register(context.Background(), "", registerInput(service))
	if err != nil { t.Fatal(err) }
	input := RecoveryInput{Username: "SPARROW_42", RecoveryCode: registered.RecoveryCode, NewPassword: "a different recovery password"}
	recovered, err := service.Recover(context.Background(), "", input)
	if err != nil { t.Fatal(err) }
	if recovered.RecoveryCode == registered.RecoveryCode || recovered.CookieToken == registered.CookieToken || store.credentials.Account.Generation != 2 || guests.invalidations != 1 { t.Fatal("recovery did not rotate identity credentials") }
	if _, err := service.Recover(context.Background(), "", input); !errors.Is(err, ErrCredentials) { t.Fatalf("replayed recovery code accepted: %v", err) }
	if store.recoveryCalls != 1 { t.Fatal("replayed code reached mutation") }
}

func TestRecoveryEndsUnrelatedBrowserAccountBeforeSwitching(t *testing.T) {
	service, store, guests, _, clock := testService(t)
	registered, err := service.Register(context.Background(), "", registerInput(service))
	if err != nil { t.Fatal(err) }
	otherToken, otherSession, err := makeSession("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", 1, clock.Now())
	if err != nil { t.Fatal(err) }
	store.previousSession = AccountSession{Account: Account{ID: otherSession.AccountID, Username: "different_person", Status: "active", Generation: 1, Profile: validProfile()}, Session: otherSession}
	_, err = service.Recover(context.Background(), otherToken, RecoveryInput{Username: "sparrow_42", RecoveryCode: registered.RecoveryCode, NewPassword: "a different recovery password"})
	if err != nil { t.Fatal(err) }
	if store.revoked != 1 || guests.invalidatedSessions != 1 || guests.invalidations != 1 { t.Fatal("switching recovered account left previous browser identity active") }
}

func TestDeletionDisablesBeforeTombstoneAcknowledgement(t *testing.T) {
	for _, durable := range []bool{false, true} {
		t.Run(fmt.Sprint(durable), func(t *testing.T) {
			service, store, guests, journal, _ := testService(t)
			registered, err := service.Register(context.Background(), "", registerInput(service))
			if err != nil { t.Fatal(err) }
			principal := principalForAccount(AccountSession{Account: store.created.Account, Session: store.created.Session}, registered.CookieToken)
			if !durable { journal.err = errors.New("independent volume unavailable") }
			receipt, err := service.Delete(context.Background(), principal, DeleteInput{Confirm: true})
			if err != nil { t.Fatal(err) }
			if !store.disabled || !receipt.AccessDisabled || receipt.Receipt == "" || receipt.TombstoneDurable != durable || store.marked != durable || guests.removals != 1 || receipt.State != "awaiting_retention_review" { t.Fatalf("wrong deletion acknowledgement: %+v", receipt) }
		})
	}
}

func TestSensitiveActionReauthenticationDeadline(t *testing.T) {
	service, store, _, _, clock := testService(t)
	registered, err := service.Register(context.Background(), "", registerInput(service))
	if err != nil { t.Fatal(err) }
	principal := principalForAccount(AccountSession{Account: store.created.Account, Session: store.created.Session}, registered.CookieToken)
	clock.now = clock.now.Add(RecentAuthenticationTTL)
	if _, err := service.RotateRecovery(context.Background(), principal); !errors.Is(err, ErrReauthentication) { t.Fatalf("expired reauthentication accepted: %v", err) }
	if _, err := service.Delete(context.Background(), principal, DeleteInput{Confirm: true}); !errors.Is(err, ErrReauthentication) { t.Fatalf("expired reauthentication allowed deletion: %v", err) }
	if store.disabled { t.Fatal("invalid request disabled account") }
}

func TestWrappedInternalErrorNeverLeaksDetails(t *testing.T) {
	err := fmt.Errorf("postgres credential=private: %w", ErrUnavailable)
	if safeError(err) != ErrUnavailable { t.Fatal("wrapped internal details escaped safe mapping") }
}
