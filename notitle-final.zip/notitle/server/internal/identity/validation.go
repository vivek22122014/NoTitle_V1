package identity

import (
	"regexp"
	"strings"
	"unicode"
	"unicode/utf8"
)

var usernamePattern = regexp.MustCompile(`^[a-z0-9_-]{4,24}$`)
var policyVersionPattern = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$`)

// Choice is a stable controlled vocabulary code and an English presentation label.
type Choice struct {
	Value string `json:"value"`
	Label string `json:"label"`
}
type Vocabulary struct {
	Professions []Choice `json:"professions"`
	Industries []Choice `json:"industries"`
	Experience []Choice `json:"experience"`
	Topics []Choice `json:"topics"`
	Interests []Choice `json:"interests"`
}

// Vocabularies returns fresh slices so callers cannot alter global validation.
func Vocabularies() Vocabulary {
	return Vocabulary{
		Professions: []Choice{{"", "Prefer not to share"}, {"engineering", "Engineering"}, {"product", "Product"}, {"design", "Design"}, {"data", "Data and analytics"}, {"operations", "Operations"}, {"sales", "Sales"}, {"marketing", "Marketing"}, {"hr", "Human resources"}, {"finance", "Finance"}, {"legal", "Legal"}, {"education", "Education"}, {"healthcare", "Healthcare"}, {"student", "Student"}, {"other", "Other"}},
		Industries: []Choice{{"", "Prefer not to share"}, {"technology", "Technology"}, {"finance", "Finance"}, {"healthcare", "Healthcare"}, {"education", "Education"}, {"manufacturing", "Manufacturing"}, {"retail", "Retail"}, {"consulting", "Consulting"}, {"public_service", "Public service"}, {"media", "Media"}, {"other", "Other"}},
		Experience: []Choice{{"", "Prefer not to share"}, {"student", "Student"}, {"0_2", "0–2 years"}, {"3_5", "3–5 years"}, {"6_10", "6–10 years"}, {"11_plus", "11+ years"}},
		Topics: []Choice{{"general_talk", "General Talk"}, {"work_culture", "Work culture"}, {"career_growth", "Career growth"}, {"managers", "Managers"}, {"salaries", "Salaries"}, {"hiring", "Hiring"}, {"office_politics", "Office politics"}, {"industry_experiences", "Industry experiences"}},
		Interests: []Choice{{"career_growth", "Career growth"}, {"leadership", "Leadership"}, {"work_life_balance", "Work–life balance"}, {"interview_prep", "Interview preparation"}, {"learning_skills", "Learning new skills"}, {"compensation", "Compensation"}, {"workplace_culture", "Workplace culture"}, {"entrepreneurship", "Entrepreneurship"}},
	}
}

func NormalizeUsername(value string) (string, error) {
	value = strings.TrimSpace(value)
	for _, r := range value {
		if r > 127 { return "", &ValidationError{Field: "username", Message: "use only ASCII letters, numbers, underscores or hyphens"} }
	}
	value = strings.ToLower(value)
	if !usernamePattern.MatchString(value) {
		return "", &ValidationError{Field: "username", Message: "use 4–24 ASCII letters, numbers, underscores or hyphens"}
	}
	// Reserve obvious staff impersonation aliases, including punctuation variants.
	compact := strings.NewReplacer("_", "", "-", "").Replace(value)
	for _, reserved := range []string{"admin", "administrator", "moderator", "modteam", "support", "staff", "notitle", "official", "system", "security", "helpdesk", "grievance", "privacy", "root"} {
		if compact == reserved || strings.HasPrefix(compact, reserved) {
			return "", &ValidationError{Field: "username", Message: "this username is reserved"}
		}
	}
	return value, nil
}

func ValidatePassword(value string) error {
	if !utf8.ValidString(value) || strings.ContainsRune(value, '\x00') || len(value) > 512 || utf8.RuneCountInString(value) < 12 || utf8.RuneCountInString(value) > 128 {
		return &ValidationError{Field: "password", Message: "use 12–128 characters; spaces and paste are allowed"}
	}
	return nil
}

func ValidateProfile(profile Profile) error {
	if profile.Gender != GenderMale && profile.Gender != GenderFemale && profile.Gender != GenderOther {
		return &ValidationError{Field: "gender", Message: "explicitly select Male, Female or Other / Non-binary"}
	}
	if !safeText(profile.DisplayName) || strings.TrimSpace(profile.DisplayName) != profile.DisplayName || utf8.RuneCountInString(profile.DisplayName) < 2 || utf8.RuneCountInString(profile.DisplayName) > 24 {
		return &ValidationError{Field: "display_name", Message: "use 2–24 visible characters without leading or trailing spaces"}
	}
	if strings.TrimSpace(profile.DisplayName) == "" {
		return &ValidationError{Field: "display_name", Message: "enter a public display name"}
	}
	if !safeText(profile.Bio) || utf8.RuneCountInString(profile.Bio) > 160 {
		return &ValidationError{Field: "bio", Message: "use at most 160 characters without control or direction-override characters"}
	}
	v := Vocabularies()
	for _, field := range []struct { name string; value string; choices []Choice }{
		{"profession", profile.Professional.Profession, v.Professions},
		{"industry", profile.Professional.Industry, v.Industries},
		{"experience", profile.Professional.Experience, v.Experience},
		{"topic", profile.Topic, v.Topics},
	} {
		found := false
		for _, choice := range field.choices { if choice.Value == field.value { found = true; break } }
		if !found { return &ValidationError{Field: field.name, Message: "select a supported option"} }
	}
	if len(profile.Professional.Interests) > 10 { return &ValidationError{Field: "interests", Message: "select at most ten interests"} }
	seen := make(map[string]bool, len(profile.Professional.Interests))
	for _, interest := range profile.Professional.Interests {
		if seen[interest] { return &ValidationError{Field: "interests", Message: "select each interest only once"} }
		seen[interest] = true
		found := false
		for _, choice := range v.Interests { if choice.Value == interest { found = true; break } }
		if !found { return &ValidationError{Field: "interests", Message: "select supported interests"} }
	}
	return nil
}

func ValidateConsent(consent Consent, required PolicyVersions) error {
	if !consent.AdultConfirmed { return &ValidationError{Field: "adult_confirmed", Message: "confirm that you are at least 18 years old"} }
	if !ValidPolicyVersions(consent.Policies) || consent.Policies != required {
		return &ValidationError{Field: "policies", Message: "read and accept the current Terms, Privacy notice and Community Guidelines"}
	}
	return nil
}

func ValidPolicyVersions(versions PolicyVersions) bool {
	return policyVersionPattern.MatchString(versions.Terms) && policyVersionPattern.MatchString(versions.Privacy) && policyVersionPattern.MatchString(versions.Community)
}

func safeText(value string) bool {
	if !utf8.ValidString(value) { return false }
	for _, r := range value {
		if unicode.IsControl(r) || unicode.Is(unicode.Cf, r) || r == '\u2028' || r == '\u2029' {
			return false
		}
	}
	return true
}
