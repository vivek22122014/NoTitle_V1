package identity

import (
	"context"
	"errors"
	"strings"
	"testing"
)

func TestBearerEntropyFormatsAndDomainSeparation(t *testing.T) {
	first, firstHash, err := newSessionToken(KindGuest)
	if err != nil { t.Fatal(err) }
	second, secondHash, err := newSessionToken(KindGuest)
	if err != nil { t.Fatal(err) }
	if first == second || firstHash == secondHash { t.Fatal("session secret repeated") }
	kind, parsed, err := parseSessionToken(first)
	if err != nil || kind != KindGuest || parsed != firstHash { t.Fatal("session round trip failed") }
	if csrfForToken(first) == first || digest("csrf", first) == firstHash { t.Fatal("CSRF token not domain-separated") }
	for _, value := range []string{"", "x", first + "=", "a." + strings.Repeat("!", 43)} {
		if _, _, err := parseSessionToken(value); err == nil { t.Fatal("malformed cookie accepted") }
	}
	code, hash, err := newRecoveryCode()
	if err != nil { t.Fatal(err) }
	parsedRecovery, err := recoveryVerifier(strings.ToLower(code))
	if err != nil || parsedRecovery != hash { t.Fatal("recovery round trip failed") }
	other, otherHash, err := newRecoveryCode()
	if err != nil || other == code || otherHash == hash { t.Fatal("recovery secret repeated") }
}

func TestArgon2BoundsBeforeAllocation(t *testing.T) {
	valid := "$argon2id$v=19$m=65536,t=3,p=1$" + strings.Repeat("A", 22) + "$" + strings.Repeat("A", 43)
	if _, _, _, err := parseArgon2(valid); err != nil { t.Fatalf("bounded hash rejected: %v", err) }
	for _, value := range []string{
		strings.Replace(valid, "m=65536", "m=999999", 1),
		strings.Replace(valid, "t=3", "t=4294967295", 1),
		strings.Replace(valid, "p=1", "p=0", 1),
		strings.Replace(valid, "v=19", "v=18", 1),
		strings.Replace(valid, "argon2id", "argon2i", 1),
		valid + "garbage",
		strings.Repeat("a", 1000),
	} {
		if _, _, _, err := parseArgon2(value); err == nil { t.Fatal("unbounded/malformed hash accepted") }
	}
}

func TestArgon2WorkAdmissionAndRoundTrip(t *testing.T) {
	hasher := NewArgon2Hasher()
	hasher.slots <- struct{}{}
	hasher.slots <- struct{}{}
	if _, err := hasher.Hash(context.Background(), "a password manager phrase"); !errors.Is(err, ErrBusy) { t.Fatalf("capacity should fail fast: %v", err) }
	<-hasher.slots
	<-hasher.slots
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := hasher.Hash(ctx, "a password manager phrase"); !errors.Is(err, context.Canceled) { t.Fatalf("cancelled hash admitted: %v", err) }
	encoded, err := hasher.Hash(context.Background(), "a password manager phrase")
	if err != nil { t.Fatal(err) }
	ok, err := hasher.Verify(context.Background(), encoded, "a password manager phrase")
	if err != nil || !ok { t.Fatal("valid password rejected") }
	ok, err = hasher.Verify(context.Background(), encoded, "different password phrase")
	if err != nil || ok { t.Fatal("wrong password accepted") }
}
