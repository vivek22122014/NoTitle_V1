package identity

import (
    "context"
    "errors"
    "testing"
    "time"
)

func TestRefreshPrincipalRechecksVerifierAndCurrentIdentity(t *testing.T){
    service,store,_,_,clock:=testService(t)
    token,session,err:=makeSession("account",1,clock.Now());if err!=nil{t.Fatal(err)}
    account:=Account{ID:"account",Generation:1,Status:"active",Profile:validProfile()}
    store.previousSession=AccountSession{Account:account,Session:session}
    principal:=principalForAccount(store.previousSession,token)
    updated:=validProfile();updated.Version=2;updated.Gender=GenderFemale
    store.previousSession.Account.Profile=updated
    refreshed,err:=service.RefreshPrincipal(context.Background(),principal,true)
    if err!=nil||refreshed.AccountSession.Account.Profile.Version!=2||refreshed.AccountSession.Account.Profile.Gender!=GenderFemale{t.Fatal("realtime kept cached profile",err)}
    if refreshed.CSRFToken!=""{t.Fatal("realtime unnecessarily retained browser CSRF secret")}
    store.previousSession.Account.Status="deletion_pending"
    if _,err:=service.RefreshPrincipal(context.Background(),principal,false);!errors.Is(err,ErrUnauthorized){t.Fatal("disabled identity refreshed",err)}
    store.previousSession.Account.Status="active";store.previousSession.Session.TokenHash=Verifier{}
    if _,err:=service.RefreshPrincipal(context.Background(),principal,false);!errors.Is(err,ErrUnauthorized){t.Fatal("revoked verifier refreshed",err)}
}
func TestRefreshGuestUsesAbsoluteExpiryAndFreshGeneration(t *testing.T){
    service,_,guests,_,clock:=testService(t)
    start,err:=service.StartGuest(context.Background(),GuestInput{Profile:validProfile(),Consent:registerInput(service).Consent});if err!=nil{t.Fatal(err)}
    principal,err:=service.Authenticate(context.Background(),start.CookieToken,false);if err!=nil{t.Fatal(err)}
    guests.guest.Generation++;guests.guest.Profile.Version++
    refreshed,err:=service.RefreshPrincipal(context.Background(),principal,true)
    if err!=nil||refreshed.Guest.Generation!=guests.guest.Generation{t.Fatal("guest retained stale generation",err)}
    clock.now=guests.guest.AbsoluteExpiresAt
    if _,err:=service.RefreshPrincipal(context.Background(),principal,true);!errors.Is(err,ErrUnauthorized){t.Fatal("expired guest revived by activity",err)}
}

type profileHookStore struct { *fakeStore; account Account }
func (f *profileHookStore) UpdateProfile(_ context.Context,_ Guard,p Profile)(Account,error){p.Version++;f.account.Profile=p;return f.account,nil}
type profileHookGuests struct { *fakeGuests; observed Account; err error; calls int }
func (g *profileHookGuests) ProfileChanged(_ context.Context,a Account,_ time.Time)error{g.observed=a;g.calls++;return g.err}
func TestProfileObserverCompletesBeforeSuccessAndFailureInvalidates(t *testing.T){
    service,base,guests,_,clock:=testService(t)
    _,session,err:=makeSession("account",1,clock.Now());if err!=nil{t.Fatal(err)}
    a:=Account{ID:"account",Generation:1,Status:"active",Profile:validProfile()}
    store:=&profileHookStore{fakeStore:base,account:a};hooks:=&profileHookGuests{fakeGuests:guests}
    service.store=store;service.guests=hooks
    principal:=Principal{Kind:KindAccount,TokenHash:session.TokenHash,AccountSession:AccountSession{Account:a,Session:session}}
    profile:=a.Profile;profile.Version=1
    result,err:=service.UpdateProfile(context.Background(),principal,profile)
    if err!=nil||hooks.calls!=1||result.Profile.Version!=2||hooks.observed.Profile.Version!=2{t.Fatal("profile returned before live update",err)}
    hooks.err=ErrUnavailable
    if _,err:=service.UpdateProfile(context.Background(),principal,profile);!errors.Is(err,ErrUnavailable)||hooks.invalidations!=1{t.Fatal("failed live update did not invalidate",err)}
}

type failedLifecycleGuests struct { *fakeGuests; closed bool }
func (g *failedLifecycleGuests) FailClosed(){g.closed=true}
func (g *failedLifecycleGuests) InvalidateSession(context.Context,string,string,time.Time)error{return ErrUnavailable}
func (g *failedLifecycleGuests) RemoveAccount(context.Context,string,time.Time)error{return ErrUnavailable}
func TestCommittedLogoutLatchesOwnerWhenInvalidationFails(t *testing.T){
    service,store,guests,_,clock:=testService(t)
    token,session,err:=makeSession("account",1,clock.Now());if err!=nil{t.Fatal(err)}
    account:=Account{ID:"account",Generation:1,Status:"active",Profile:validProfile()}
    current:=AccountSession{Account:account,Session:session}
    lifecycle:=&failedLifecycleGuests{fakeGuests:guests};service.guests=lifecycle
    if err:=service.Logout(context.Background(),principalForAccount(current,token));!errors.Is(err,ErrUnavailable){t.Fatal(err)}
    if store.revoked!=1||!lifecycle.closed{t.Fatal("committed logout did not latch failed live invalidation")}
}
func TestDeletionLatchesOwnerOnFailedLiveRemoval(t *testing.T){
    service,store,guests,_,clock:=testService(t)
    token,session,err:=makeSession("account",1,clock.Now());if err!=nil{t.Fatal(err)}
    current:=AccountSession{Account:Account{ID:"account",Generation:1,Status:"active",Profile:validProfile()},Session:session}
    lifecycle:=&failedLifecycleGuests{fakeGuests:guests};service.guests=lifecycle
    receipt,err:=service.Delete(context.Background(),principalForAccount(current,token),DeleteInput{Confirm:true})
    if err!=nil||!receipt.AccessDisabled||!store.disabled||!lifecycle.closed{t.Fatal("deletion could leave live identity after committed revocation",err)}
}
