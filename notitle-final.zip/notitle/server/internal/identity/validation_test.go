package identity

import (
	"encoding/json"
	"errors"
	"strings"
	"testing"
)

func validProfile() Profile {
	return Profile{Version: 1, DisplayName: "Quiet Sparrow", Gender: GenderOther, Bio: "Here to talk about careers", Topic: "career_growth", Professional: ProfessionalProfile{Profession: "engineering", Industry: "technology", Experience: "3_5"}}
}

func TestExplicitGenderAndPublicTextValidation(t *testing.T) {
	for _, gender := range []Gender{"", "everyone", "undisclosed", "Male"} {
		profile := validProfile()
		profile.Gender = gender
		if !errors.Is(ValidateProfile(profile), ErrInvalid) { t.Errorf("gender %q accepted", gender) }
	}
	for _, gender := range []Gender{GenderMale, GenderFemale, GenderOther} {
		profile := validProfile()
		profile.Gender = gender
		if err := ValidateProfile(profile); err != nil { t.Errorf("valid gender rejected: %v", err) }
	}
	for _, name := range []string{"", " ", "A", " leading", "trailing ", "bad\nname", "a\u202ename", "a\u2066name", "\u200d\u200d", "\u2060\u2060", string([]byte{0xff, 'x'}), strings.Repeat("x", 25)} {
		profile := validProfile()
		profile.DisplayName = name
		if ValidateProfile(profile) == nil { t.Errorf("invalid display name accepted: %q", name) }
	}
	profile := validProfile()
	profile.DisplayName = "विवेक कुमार"
	if err := ValidateProfile(profile); err != nil { t.Fatalf("Unicode display name rejected: %v", err) }
	profile.Bio = strings.Repeat("a", 161)
	if ValidateProfile(profile) == nil { t.Fatal("oversize bio accepted") }
	profile = validProfile()
	profile.Professional.Profession = "arbitrary free text"
	if ValidateProfile(profile) == nil { t.Fatal("unknown profession accepted") }
	for _, interests := range [][]string{{"career_growth", "career_growth"}, {"arbitrary"}, {""}, {"career_growth", "leadership", "work_life_balance", "interview_prep", "learning_skills", "compensation", "workplace_culture", "entrepreneurship", "career_growth", "leadership", "compensation"}} {
		profile = validProfile()
		profile.Professional.Interests = interests
		if ValidateProfile(profile) == nil { t.Fatal("invalid/duplicate/oversize interests accepted") }
	}
	profile = validProfile()
	profile.Professional.Interests = []string{"career_growth", "leadership"}
	if err := ValidateProfile(profile); err != nil { t.Fatalf("valid optional interests rejected: %v", err) }
}

func TestPrivateUsernameNormalizationAndReservation(t *testing.T) {
	got, err := NormalizeUsername("  Sparrow_42  ")
	if err != nil || got != "sparrow_42" { t.Fatalf("normalization failed: %q %v", got, err) }
	for _, value := range []string{"abc", strings.Repeat("x", 25), "éclair", "Kate", "space name", "admin", "Ad_min", "notitle-team", "support4"} {
		if _, err := NormalizeUsername(value); err == nil { t.Errorf("invalid/reserved username accepted: %q", value) }
	}
}

func TestPasswordAllowsPasteSpacesAndDoesNotTrim(t *testing.T) {
	for _, value := range []string{"correct horse battery", "            ", "पासवर्डपासवर्डपासवर्ड", strings.Repeat("x", 128)} {
		if err := ValidatePassword(value); err != nil { t.Errorf("valid password rejected: %v", err) }
	}
	for _, value := range []string{"short", strings.Repeat("x", 129), "longpassword\x00bad", string([]byte{0xff})} {
		if ValidatePassword(value) == nil { t.Errorf("invalid password accepted") }
	}
}

func TestConsentRequiresAdultAndCurrentVersions(t *testing.T) {
	versions := PolicyVersions{Terms: "terms-v1", Privacy: "privacy-v1", Community: "rules-v1"}
	if ValidateConsent(Consent{AdultConfirmed: true, Policies: versions}, versions) != nil { t.Fatal("valid consent rejected") }
	if ValidateConsent(Consent{Policies: versions}, versions) == nil { t.Fatal("minor/nonconfirmation accepted") }
	stale := versions
	stale.Terms = "terms-v0"
	if ValidateConsent(Consent{AdultConfirmed: true, Policies: stale}, versions) == nil { t.Fatal("stale policies accepted") }
}

func TestPeerProjectionExcludesPrivateFields(t *testing.T) {
	profile := validProfile()
	encoded, err := json.Marshal(profile.PublicPeer())
	if err != nil { t.Fatal(err) }
	var result map[string]any
	if err := json.Unmarshal(encoded, &result); err != nil { t.Fatal(err) }
	if len(result) != 4 { t.Fatalf("unexpected peer fields: %s", encoded) }
	for _, field := range []string{"display_name", "gender", "bio", "topic"} {
		if _, ok := result[field]; !ok { t.Fatalf("missing peer field %s", field) }
	}
	for _, private := range []string{"username", "account_id", "version", "professional", "interests", "premium", "engineering", "technology"} {
		if strings.Contains(string(encoded), private) { t.Errorf("private field leaked: %s", private) }
	}
}
