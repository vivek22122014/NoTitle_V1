package identity

import (
	"context"
	"time"
)

type Clock interface { Now() time.Time }

// Store methods must never return database details as client-facing errors.
// Mutation methods are single transactions. Expected generation/session checks
// belong in the same transaction as the write, not only in service middleware.
type Store interface {
	FindCredentials(context.Context, string) (Credentials, error)
	CreateAccount(context.Context, CreateAccountRecord) (AccountSession, error)
	CreateSession(context.Context, string, int64, SessionRecord, time.Time) (AccountSession, error)
	Authenticate(context.Context, Verifier, time.Time, bool) (AccountSession, error)
	UpdateProfile(context.Context, Guard, Profile) (Account, error)
	Reauthenticate(context.Context, Guard) error
	ChangeCredentials(context.Context, Guard, CredentialMutation) (AccountSession, error)
	Recover(context.Context, RecoveryMutation) (AccountSession, error)
	RevokeSession(context.Context, Guard) error
	RevokeAllSessions(context.Context, Guard) error
	BeginDeletion(context.Context, Guard, DeletionRecord) (DeletionRecord, error)
	MarkTombstoneDurable(context.Context, string, time.Time) error
	DeletionByReceipt(context.Context, Verifier) (DeletionRecord, error)
	PendingTombstones(context.Context, int) ([]DeletionRecord, error)
	PruneExpiredSessions(context.Context, time.Time, int) error
	ApplyTombstone(context.Context, Tombstone) error
}

// GuestRegistry is implemented by the one coordinator. It owns every ephemeral
// guest, reservation, participant-slot and later relationship index. All maps
// and mailboxes must be bounded. A guest is frozen for a short handoff lease.
// Authenticate(..., true) counts authorized activity only; friends never do.
type GuestRegistry interface {
	CreateGuest(context.Context, Guest) (Guest, error)
	AuthenticateGuest(context.Context, Verifier, time.Time, bool) (Guest, error)
	UpdateGuest(context.Context, Verifier, int64, Profile, time.Time) (Guest, error)
	EndGuest(context.Context, Verifier, time.Time) error
	PrepareGuestHandoff(context.Context, Verifier, int64, time.Time) (GuestReservation, error)
	CommitGuestHandoff(context.Context, GuestReservation, GuestCommit, time.Time) (bool, error)
	// safeToResume is true ONLY after a deterministic precommit failure. False
	// destroys the guest on an uncertain commit or a failed account rebind.
	AbortGuestHandoff(ctx context.Context, reservation GuestReservation, safeToResume bool, now time.Time) error
	InvalidateSession(context.Context, string, string, time.Time) error
	InvalidateAccount(context.Context, string, time.Time) error
	RemoveAccount(context.Context, string, time.Time) error
}

// Append returns nil only after durable persistence independently of the normal
// database backup stream. Implementations must be idempotent by DeletionID.
type TombstoneJournal interface { Append(context.Context, Tombstone) error }

type PasswordHasher interface {
	Hash(context.Context, string) (string, error)
	Verify(context.Context, string, string) (bool, error)
}

type Options struct {
	Clock Clock
	Store Store
	Guests GuestRegistry
	Journal TombstoneJournal
	Hasher PasswordHasher
	Policies PolicyVersions
}

// ProfileObserver is the realtime lifecycle extension implemented by the one
// coordinator. Profile versions must be compared monotonically on delivery.
type ProfileObserver interface {
    ProfileChanged(context.Context, Account, time.Time) error
}
