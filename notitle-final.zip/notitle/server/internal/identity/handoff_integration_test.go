package identity_test

import (
	"context"
	"runtime"
	"sync/atomic"
	"testing"
	"time"

	"notitle/internal/coordinator"
	"notitle/internal/identity"
)

// These tests exercise the actual actor adapter, not a fake with a duplicated
// interpretation of the safeToResume boolean. No database/network is required.
type actorClock struct { nanos atomic.Int64 }
func (c *actorClock) Now() time.Time { return time.Unix(0, c.nanos.Load()).UTC() }
func (c *actorClock) advance(d time.Duration) { c.nanos.Add(int64(d)) }
type actorStore struct {
	identity.Store
	err error
	beforeReturn func()
}
func (s *actorStore) CreateAccount(_ context.Context, record identity.CreateAccountRecord) (identity.AccountSession, error) {
	if s.beforeReturn != nil { s.beforeReturn() }
	if s.err != nil { return identity.AccountSession{}, s.err }
	return identity.AccountSession{Account: record.Account, Session: record.Session}, nil
}
func (s *actorStore) RevokeSession(context.Context, identity.Guard) error { return nil }
type actorHasher struct{}
func (actorHasher) Hash(context.Context, string) (string, error) { return "test-only-hash", nil }
func (actorHasher) Verify(context.Context, string, string) (bool, error) { return true, nil }
type actorJournal struct{}
func (actorJournal) Append(context.Context, identity.Tombstone) error { return nil }

func TestServiceCommittedAccountAfterExpiredLeaseReturnsIdle(t *testing.T) {
	clock := &actorClock{}
	clock.nanos.Store(time.Date(2026, 10, 9, 12, 0, 0, 0, time.UTC).UnixNano())
	actorContext, stopActor := context.WithCancel(context.Background())
	actor := coordinator.New(clock)
	go func() { _ = actor.Run(actorContext) }()
	deadline := time.Now().Add(time.Second)
	for !actor.Running() {
		if time.Now().After(deadline) { stopActor(); t.Fatal("coordinator did not start") }
		runtime.Gosched()
	}
	t.Cleanup(func() { stopActor(); select { case <-actor.Done(): case <-time.After(time.Second): t.Error("coordinator did not stop") } })
	store := &actorStore{beforeReturn: func() { clock.advance(identity.HandoffTTL) }}
	policies := identity.PolicyVersions{Terms: "v1", Privacy: "v1", Community: "v1"}
	service, err := identity.New(identity.Options{Clock: clock, Store: store, Guests: actor, Journal: actorJournal{}, Hasher: actorHasher{}, Policies: policies})
	if err != nil { t.Fatal(err) }
	profile := identity.Profile{DisplayName: "Quiet Sparrow", Gender: identity.GenderOther, Topic: "general_talk", Version: 1}
	consent := identity.Consent{AdultConfirmed: true, Policies: policies}
	guest, err := service.StartGuest(context.Background(), identity.GuestInput{Profile: profile, Consent: consent})
	if err != nil { t.Fatal(err) }
	result, err := service.Register(context.Background(), guest.CookieToken, identity.RegisterInput{Username: "sparrow_42", Password: "a password manager phrase", Profile: profile, Consent: consent})
	if err != nil || result.CookieToken == guest.CookieToken || result.Session.Identity.Kind != identity.KindAccount { t.Fatalf("registration did not finish safely: %v", err) }
	if _, err := service.Authenticate(context.Background(), guest.CookieToken, false); err == nil { t.Fatal("expired guest credential survived") }
	state, err := actor.Snapshot(context.Background())
	if err != nil { t.Fatal(err) }
	if state.ParticipantSlots != 0 || result.HandoffState != "idle" { t.Fatal("expired lease resurrected participant state") }
}
