package billing

import (
	"context"
	"net/http"
	"time"
	"notitle/internal/cashfree"
)

// IngestWebhook returns success only after a verified event and its job commit
// together. The HTTP caller must return a retryable failure on store errors.
func IngestWebhook(ctx context.Context,store Repository,verifier *cashfree.WebhookVerifier,headers http.Header,raw []byte,now time.Time)error{
	if store==nil||verifier==nil{return ErrUnavailable};event,err:=verifier.Verify(headers,raw);if err!=nil{return err}
	return store.EnqueueWebhook(ctx,WebhookEvent{EventKey:event.Fingerprint,Kind:event.Type,OrderRef:event.OrderID,PaymentID:event.PaymentID,RefundID:event.RefundID,ProviderDisputeID:event.DisputeID,MerchantID:verifier.MerchantID(),DisputeStatus:event.DisputeStatus,Environment:Environment(verifier.Environment()),ReceivedAt:now.UTC(),ResponseDue:event.ResponseDue},now.UTC())
}
