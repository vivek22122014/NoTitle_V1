package billing

import (
 "context"
 "errors"
 "time"
 "github.com/jackc/pgx/v5"
 "notitle/internal/identity"
)

// Lot is a private accounting projection. Conservation is enforced both here
// and by SQL: granted = available + held + consumed + revoked.
type Lot struct { Ref,OrderRef,PaymentID string; Duration,Remaining,Held,Consumed,Revoked int64; Used bool; GrantedAt time.Time }
type Balance struct { Checkpoint time.Time; Revision int64; Lots []Lot }
type Consumption struct { LotRef string; Seconds int64 }
func AccountElapsed(b *Balance,now time.Time)([]Consumption,error){
 if now.Before(b.Checkpoint.Add(-5*time.Second)){return nil,ErrUnavailable}
 if now.Before(b.Checkpoint){return nil,nil};elapsed:=int64(now.Sub(b.Checkpoint)/time.Second);changes:=[]Consumption{}
 var total int64;for _,l:=range b.Lots{if l.Remaining<0||l.Held<0||l.Consumed<0||l.Revoked<0||l.Duration!=l.Remaining+l.Held+l.Consumed+l.Revoked{return nil,ErrUnavailable};total+=l.Remaining}
 consume:=elapsed;if consume>total{consume=total};left:=consume
 for i:=range b.Lots{take:=b.Lots[i].Remaining;if take>left{take=left};if take>0{b.Lots[i].Remaining-=take;b.Lots[i].Consumed+=take;changes=append(changes,Consumption{b.Lots[i].Ref,take});left-=take}}
 // Retain fractional elapsed time while service is available. Empty and
 // fully-held accounts start any later grant/restore at its resolution time.
 if elapsed>=total{b.Checkpoint=now}else{b.Checkpoint=b.Checkpoint.Add(time.Duration(elapsed)*time.Second)}
 return changes,nil
}
func (b Balance) Entitlement(now time.Time)Entitlement{
 e:=Entitlement{Revision:b.Revision};for _,l:=range b.Lots{e.RemainingSeconds+=l.Remaining;if e.LotID==""&&l.Remaining>0{e.LotID=l.Ref;e.PaidControlsUsed=l.Used;end:=b.Checkpoint.Add(time.Duration(l.Remaining)*time.Second);e.UsageUntil=&end}}
 if e.RemainingSeconds>0{expiry:=b.Checkpoint.Add(time.Duration(e.RemainingSeconds)*time.Second);e.ExpiresAt=&expiry;e.Active=now.Before(expiry)};return e
}
func(s *PostgresStore) loadBalance(ctx context.Context,tx pgx.Tx,account string,now time.Time)(Balance,error){
 b:=Balance{};if _,err:=tx.Exec(ctx,`INSERT INTO notitle.premium_accounts(account_id,checkpoint_at,environment) VALUES($1,$2,$3) ON CONFLICT(account_id,environment) DO NOTHING`,account,now,s.options.Environment);err!=nil{return b,ErrUnavailable}
 if tx.QueryRow(ctx,`SELECT checkpoint_at,revision FROM notitle.premium_accounts WHERE account_id=$1 AND environment=$2 FOR UPDATE`,account,s.options.Environment).Scan(&b.Checkpoint,&b.Revision)!=nil{return b,ErrUnavailable}
 rows,err:=tx.Query(ctx,`SELECT ref,order_ref,payment_id,duration_seconds,remaining_seconds,held_seconds,consumed_seconds,revoked_seconds,paid_controls_used,granted_at FROM notitle.premium_lots WHERE account_id=$1 AND environment=$2 AND (remaining_seconds>0 OR held_seconds>0) ORDER BY grant_sequence FOR UPDATE`,account,s.options.Environment);if err!=nil{return b,ErrUnavailable};defer rows.Close();for rows.Next(){var l Lot;if rows.Scan(&l.Ref,&l.OrderRef,&l.PaymentID,&l.Duration,&l.Remaining,&l.Held,&l.Consumed,&l.Revoked,&l.Used,&l.GrantedAt)!=nil{return b,ErrUnavailable};b.Lots=append(b.Lots,l)};if rows.Err()!=nil{return b,ErrUnavailable};return b,nil
}
func(s *PostgresStore) event(ctx context.Context,tx pgx.Tx,account,lot,kind string,seconds,revision int64,reference string,now time.Time)error{var l any;if lot!=""{l=lot};_,err:=tx.Exec(ctx,`INSERT INTO notitle.premium_adjustments(account_id,lot_ref,kind,seconds,revision,reference,created_at,environment) VALUES($1,$2,$3,$4,$5,$6,$7,$8)`,account,l,kind,seconds,revision,reference,now,s.options.Environment);if err!=nil{return ErrUnavailable};return nil}
func(s *PostgresStore) saveBalance(ctx context.Context,tx pgx.Tx,account string,b Balance)error{
 for _,l:=range b.Lots{if _,err:=tx.Exec(ctx,`UPDATE notitle.premium_lots SET remaining_seconds=$2,held_seconds=$3,consumed_seconds=$4,revoked_seconds=$5,paid_controls_used=$6 WHERE ref=$1`,l.Ref,l.Remaining,l.Held,l.Consumed,l.Revoked,l.Used);err!=nil{return ErrUnavailable}}
 if _,err:=tx.Exec(ctx,`UPDATE notitle.premium_accounts SET checkpoint_at=$2,revision=$3 WHERE account_id=$1 AND environment=$4`,account,b.Checkpoint,b.Revision,s.options.Environment);err!=nil{return ErrUnavailable};return nil
}
func(s *PostgresStore) checkpoint(ctx context.Context,tx pgx.Tx,account string,now time.Time)(Balance,error){
 b,err:=s.loadBalance(ctx,tx,account,now);if err!=nil{return b,err};old:=b.Checkpoint;consumed,err:=AccountElapsed(&b,now);if err!=nil{return b,err}
 for _,c:=range consumed{if err=s.event(ctx,tx,account,c.LotRef,"consume",c.Seconds,b.Revision,"",now);err!=nil{return b,err}}
 if !old.Equal(b.Checkpoint)&&len(consumed)>0{if err=s.event(ctx,tx,account,"","checkpoint",0,b.Revision,"",b.Checkpoint);err!=nil{return b,err}}
 return b,s.saveBalance(ctx,tx,account,b)
}
func(s *PostgresStore)Entitlement(ctx context.Context,g identity.Guard,now time.Time)(Entitlement,error){return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(Entitlement,error){if err:=guardSession(ctx,tx,g,now);err!=nil{return Entitlement{},err};b,err:=s.loadBalance(ctx,tx,g.AccountID,now);if err==nil{_,err=AccountElapsed(&b,now)};return b.Entitlement(now),err})}
func(s *PostgresStore)AccountEntitlement(ctx context.Context,id string,now time.Time)(Entitlement,error){return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(Entitlement,error){status,_,err:=lockAccount(ctx,tx,id);if errors.Is(err,ErrUnauthorized){return Entitlement{},nil};if err!=nil{return Entitlement{},err};b,err:=s.loadBalance(ctx,tx,id,now);if err!=nil{return Entitlement{},err};if _,err=AccountElapsed(&b,now);err!=nil{return Entitlement{},err};if status!="active"{return Entitlement{Revision:b.Revision},nil};return b.Entitlement(now),nil})}
func(s *PostgresStore)MarkPaidUse(ctx context.Context,g identity.Guard,expectedRevision int64,expectedLot string,now time.Time)(Entitlement,error){
 var stale bool;e,err:=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(Entitlement,error){if err:=guardSession(ctx,tx,g,now);err!=nil{return Entitlement{},err};b,err:=s.checkpoint(ctx,tx,g.AccountID,now);if err!=nil{return Entitlement{},err};e:=b.Entitlement(now)
 if !e.Active||e.Revision!=expectedRevision||e.LotID!=expectedLot{stale=true;return e,nil}
 for i:=range b.Lots{if b.Lots[i].Ref==e.LotID&&!b.Lots[i].Used{b.Lots[i].Used=true;if err=s.event(ctx,tx,g.AccountID,e.LotID,"paid_use",0,b.Revision,"",now);err!=nil{return Entitlement{},err};if err=s.saveBalance(ctx,tx,g.AccountID,b);err!=nil{return Entitlement{},err}}};return b.Entitlement(now),nil});if err==nil&&stale{return e,ErrConflict};return e,err
}
func(s *PostgresStore) review(ctx context.Context,tx pgx.Tx,kind,order,payment string,now time.Time)error{r,err:=ref();if err!=nil{return err};_,err=tx.Exec(ctx,`INSERT INTO notitle.billing_review_cases(ref,kind,order_ref,payment_id,created_at,environment) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(environment,kind,order_ref,payment_id) DO NOTHING`,r,kind,order,payment,now,s.options.Environment);if err!=nil{return ErrUnavailable};return nil}
func validStatus(s string)bool{switch s{case"SUCCESS","PENDING","FAILED","USER_DROPPED","CANCELLED","VOID","NOT_ATTEMPTED":return true};return false}
func(s *PostgresStore)ApplyCapture(ctx context.Context,c VerifiedCapture,now time.Time)(GrantResult,error){
 if !validReference.MatchString(c.OrderRef)||!providerReference.MatchString(c.PaymentID)||!providerReference.MatchString(c.ProviderOrderID)||!validStatus(c.Status)||c.Environment!=s.options.Environment||c.MerchantID!=s.options.MerchantID{return GrantResult{},ErrInvalid}
 existing,err:=s.StoredOrder(ctx,c.OrderRef);if errors.Is(err,ErrNotFound){_,e:=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){return false,s.review(ctx,tx,"unknown_capture",c.OrderRef,c.PaymentID,now)});if e!=nil{return GrantResult{},e};return GrantResult{OrderRef:c.OrderRef,Outcome:"financial_review"},nil};if err!=nil{return GrantResult{},err}
 fenceAccount:=existing.AccountID
 if c.Status!="SUCCESS"{fenceAccount=""}else{var granted bool;if s.pool.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.premium_lots WHERE order_ref=$1 AND environment=$2)`,c.OrderRef,c.Environment).Scan(&granted)!=nil{return GrantResult{},ErrUnavailable};if granted{fenceAccount=""}}
 var result GrantResult;err=s.mutate(ctx,fenceAccount,now,func()error{var inner error;result,inner=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(GrantResult,error){
  result:=GrantResult{OrderRef:c.OrderRef,AccountID:existing.AccountID};status:="deleted"
  if existing.AccountID!=""{var e error;status,_,e=lockAccount(ctx,tx,existing.AccountID);if e!=nil{return result,e}}
  o,e:=scanOrder(tx.QueryRow(ctx,`SELECT `+orderColumns+` FROM notitle.purchase_orders WHERE ref=$1 AND environment=$2 FOR UPDATE`,c.OrderRef,s.options.Environment));if e!=nil{return result,e}
  if o.Order.Environment!=c.Environment||o.MerchantID!=c.MerchantID||o.Order.Plan.Currency!=c.Currency||o.Order.Plan.AmountPaise!=c.AmountPaise||(o.ProviderOrderID!=""&&o.ProviderOrderID!=c.ProviderOrderID)||c.AmountPaise<=0||(c.Status=="SUCCESS"&&(c.PaidAt.IsZero()||c.PaidAt.After(now.Add(5*time.Minute))||c.PaidAt.Before(o.Order.CreatedAt.Add(-5*time.Minute)))){result.Outcome="financial_review";return result,s.review(ctx,tx,"capture_mismatch",c.OrderRef,c.PaymentID,now)}
  var oldOrder,oldStatus string;e=tx.QueryRow(ctx,`SELECT order_ref,status FROM notitle.payment_attempts WHERE environment=$1 AND payment_id=$2 FOR UPDATE`,c.Environment,c.PaymentID).Scan(&oldOrder,&oldStatus);if e==nil&&oldOrder!=c.OrderRef{result.Outcome="financial_review";return result,s.review(ctx,tx,"payment_association",c.OrderRef,c.PaymentID,now)};if e!=nil&&!errors.Is(e,pgx.ErrNoRows){return result,ErrUnavailable}
  var paid any;if c.Status=="SUCCESS"&&!c.PaidAt.IsZero(){paid=c.PaidAt};_,e=tx.Exec(ctx,`INSERT INTO notitle.payment_attempts(environment,payment_id,order_ref,amount_paise,currency,status,paid_at,observed_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT(environment,payment_id) DO UPDATE SET status=CASE WHEN notitle.payment_attempts.status='SUCCESS' THEN 'SUCCESS' ELSE EXCLUDED.status END,paid_at=COALESCE(notitle.payment_attempts.paid_at,EXCLUDED.paid_at),observed_at=CASE WHEN notitle.payment_attempts.status='SUCCESS' THEN notitle.payment_attempts.observed_at ELSE EXCLUDED.observed_at END`,c.Environment,c.PaymentID,c.OrderRef,c.AmountPaise,c.Currency,c.Status,paid,now);if e!=nil{return result,ErrUnavailable}
  if c.Status!="SUCCESS"{result.Outcome="attempt_recorded";return result,nil};if e=s.materializeDisputes(ctx,tx,c.OrderRef,c.PaymentID,now);e!=nil{return result,e}
  if _,e=tx.Exec(ctx,`UPDATE notitle.purchase_orders SET provider_order_id=COALESCE(provider_order_id,$2),paid_at=COALESCE(paid_at,$3) WHERE ref=$1`,c.OrderRef,c.ProviderOrderID,c.PaidAt);e!=nil{return result,ErrUnavailable}
  var capturedPayment string;e=tx.QueryRow(ctx,`SELECT payment_id FROM notitle.premium_lots WHERE order_ref=$1`,c.OrderRef).Scan(&capturedPayment);if e==nil{result.Outcome="already_granted";if capturedPayment!=c.PaymentID{result.Outcome="duplicate_capture";if e=s.review(ctx,tx,"duplicate_capture",c.OrderRef,c.PaymentID,now);e!=nil{return result,e}};b,e:=s.checkpoint(ctx,tx,existing.AccountID,now);result.Entitlement=b.Entitlement(now);return result,e};if !errors.Is(e,pgx.ErrNoRows){return result,ErrUnavailable}
  var refunded int64;if tx.QueryRow(ctx,`SELECT COALESCE(sum(amount_paise),0) FROM notitle.refunds WHERE environment=$1 AND payment_id=$2 AND state IN ('pending','processed','review')`,c.Environment,c.PaymentID).Scan(&refunded)!=nil{return result,ErrUnavailable}
  if c.WithholdGrant||refunded>=c.AmountPaise{if _,e=tx.Exec(ctx,`UPDATE notitle.purchase_orders SET state='financial_review' WHERE ref=$1`,c.OrderRef);e!=nil{return result,ErrUnavailable};result.Outcome="financial_review";return result,s.review(ctx,tx,"capture_refund_before_grant",c.OrderRef,c.PaymentID,now)}
  if status!="active"{_,e=tx.Exec(ctx,`UPDATE notitle.purchase_orders SET state='financial_review' WHERE ref=$1`,c.OrderRef);if e!=nil{return result,ErrUnavailable};result.Outcome="deleted_account_capture";return result,s.review(ctx,tx,"deleted_account_capture",c.OrderRef,c.PaymentID,now)}
  b,e:=s.checkpoint(ctx,tx,existing.AccountID,now);if e!=nil{return result,e};total:=b.Entitlement(now).RemainingSeconds;for _,lot:=range b.Lots{total+=lot.Held};if total>315360000-o.Order.Plan.DurationSeconds{if _,e=tx.Exec(ctx,`UPDATE notitle.purchase_orders SET state='financial_review' WHERE ref=$1`,c.OrderRef);e!=nil{return result,ErrUnavailable};result.Outcome="financial_review";return result,s.review(ctx,tx,"duration_capacity",c.OrderRef,c.PaymentID,now)}
  lot,e:=ref();if e!=nil{return result,e};b.Revision++;_,e=tx.Exec(ctx,`INSERT INTO notitle.premium_lots(ref,account_id,order_ref,environment,payment_id,duration_seconds,remaining_seconds,granted_at) VALUES($1,$2,$3,$4,$5,$6,$6,$7)`,lot,existing.AccountID,c.OrderRef,c.Environment,c.PaymentID,o.Order.Plan.DurationSeconds,now);if e!=nil{return result,ErrUnavailable};b.Lots=append(b.Lots,Lot{Ref:lot,OrderRef:c.OrderRef,PaymentID:c.PaymentID,Duration:o.Order.Plan.DurationSeconds,Remaining:o.Order.Plan.DurationSeconds,GrantedAt:now})
  if e=s.event(ctx,tx,existing.AccountID,lot,"grant",o.Order.Plan.DurationSeconds,b.Revision,c.OrderRef,now);e!=nil{return result,e};if e=s.saveBalance(ctx,tx,existing.AccountID,b);e!=nil{return result,e}
  if _,e=tx.Exec(ctx,`UPDATE notitle.purchase_orders SET state='paid' WHERE ref=$1`,c.OrderRef);e!=nil{return result,ErrUnavailable};result.Outcome="granted";result.Entitlement=b.Entitlement(now);return result,nil
 });return inner});return result,err
}
