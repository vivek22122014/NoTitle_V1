package billing

import "time"

// LedgerEvent is an internal append-only journal projection. Replay never
// consults a combined expiry or current catalogue economics.
type LedgerEvent struct { Sequence int64; LotRef,Kind,Reference string; Seconds,Revision int64; At time.Time }
func Replay(events []LedgerEvent)(Balance,error){
 b:=Balance{Revision:1};index:=map[string]int{};var previous int64
 for _,e:=range events{
  if e.Sequence<=previous||e.Seconds<0||e.Revision<b.Revision||e.At.IsZero(){return Balance{},ErrInvalid};previous=e.Sequence
  available:=int64(0);for _,l:=range b.Lots{available+=l.Remaining}
  if e.Revision>b.Revision{b.Revision=e.Revision}
  if e.Kind=="checkpoint"{if e.At.Before(b.Checkpoint){return Balance{},ErrInvalid};b.Checkpoint=e.At;continue}
  i,exists:=index[e.LotRef]
  if e.Kind=="grant"{if exists||e.LotRef==""||e.Seconds<=0{return Balance{},ErrInvalid};if available==0{if e.At.Before(b.Checkpoint){return Balance{},ErrInvalid};b.Checkpoint=e.At};index[e.LotRef]=len(b.Lots);b.Lots=append(b.Lots,Lot{Ref:e.LotRef,OrderRef:e.Reference,Duration:e.Seconds,Remaining:e.Seconds,GrantedAt:e.At});continue}
  if !exists{return Balance{},ErrInvalid};l:=&b.Lots[i]
  switch e.Kind{
  case "consume":if e.Seconds>l.Remaining{return Balance{},ErrInvalid};l.Remaining-=e.Seconds;l.Consumed+=e.Seconds
  case "hold":if e.Seconds>l.Remaining{return Balance{},ErrInvalid};l.Remaining-=e.Seconds;l.Held+=e.Seconds
  case "restore":if e.Seconds>l.Held{return Balance{},ErrInvalid};if available==0{if e.At.Before(b.Checkpoint){return Balance{},ErrInvalid};b.Checkpoint=e.At};l.Held-=e.Seconds;l.Remaining+=e.Seconds
  case "revoke":if l.Held>=e.Seconds{l.Held-=e.Seconds}else if l.Held==0&&l.Remaining>=e.Seconds{l.Remaining-=e.Seconds}else{return Balance{},ErrInvalid};l.Revoked+=e.Seconds
  case "paid_use":if e.Seconds!=0{return Balance{},ErrInvalid};l.Used=true
  default:return Balance{},ErrInvalid
  }
  if l.Duration!=l.Remaining+l.Held+l.Consumed+l.Revoked{return Balance{},ErrInvalid}
 }
 return b,nil
}
