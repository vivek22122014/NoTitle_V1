package billing

import (
    "context"
    "errors"
    "strings"
    "time"
    "unicode"
    "unicode/utf8"

    "github.com/jackc/pgx/v5"
)

// These projections are used only by the separate authenticated operations
// listener. They deliberately omit identity/contact details and checkout keys.
type AdminAttempt struct { PaymentID,Status,Currency string; AmountPaise int64; PaidAt *time.Time; ObservedAt time.Time }
type AdminDispute struct { ProviderDisputeID,OrderRef,PaymentID,Status,Reason string; ResponseDue time.Time; HeldSeconds,Revision int64 }
type AdminReview struct { ReviewCase; PaymentID,Reason string; Revision int64 }
type AdminOrderDetail struct { Order Order; Attempts []AdminAttempt; Refunds []Refund; Disputes []AdminDispute; Reviews []AdminReview; Reconciliation []Reconciliation }
type AdminReviewAction struct { ActorID string; AdminGeneration int64; AdminSessionHash [32]byte; Ref,Action,Reason,IdempotencyKey string; ExpectedVersion int64 }

const adminOrderColumns=`ref,state,environment,plan_id,plan_version,plan_name,amount_paise,currency,duration_seconds,tax_treatment,tax_paise,created_at,paid_at`
func scanAdminOrder(row interface{Scan(...any)error})(Order,error){
    var o Order
    err:=row.Scan(&o.Ref,&o.Status,&o.Environment,&o.Plan.ID,&o.Plan.Version,&o.Plan.Name,&o.Plan.AmountPaise,&o.Plan.Currency,&o.Plan.DurationSeconds,&o.Plan.TaxTreatment,&o.Plan.TaxPaise,&o.CreatedAt,&o.PaidAt)
    return o,err
}
func(s *PostgresStore)AdminOrders(ctx context.Context,limit int)([]Order,error){
    if limit<1||limit>100{return nil,ErrInvalid}
    rows,err:=s.pool.Query(ctx,`SELECT `+adminOrderColumns+` FROM notitle.purchase_orders WHERE environment=$2 ORDER BY created_at DESC,ref LIMIT $1`,limit,s.options.Environment);if err!=nil{return nil,ErrUnavailable};defer rows.Close()
    result:=[]Order{};for rows.Next(){o,e:=scanAdminOrder(rows);if e!=nil{return nil,ErrUnavailable};result=append(result,o)};if rows.Err()!=nil{return nil,ErrUnavailable};return result,nil
}
func(s *PostgresStore)ListReview(ctx context.Context,limit int)([]AdminReview,error){
    if limit<1||limit>100{return nil,ErrInvalid}
    rows,err:=s.pool.Query(ctx,`SELECT ref,kind,order_ref,state,created_at,payment_id,reason,revision FROM notitle.billing_review_cases WHERE environment=$2 ORDER BY (state='open') DESC,created_at,ref LIMIT $1`,limit,s.options.Environment);if err!=nil{return nil,ErrUnavailable};defer rows.Close()
    result:=[]AdminReview{};for rows.Next(){var v AdminReview;if rows.Scan(&v.Ref,&v.Kind,&v.OrderRef,&v.State,&v.CreatedAt,&v.PaymentID,&v.Reason,&v.Revision)!=nil{return nil,ErrUnavailable};result=append(result,v)};if rows.Err()!=nil{return nil,ErrUnavailable};return result,nil
}
func(s *PostgresStore)AdminDisputes(ctx context.Context,limit int)([]AdminDispute,error){
    if limit<1||limit>100{return nil,ErrInvalid}
    rows,err:=s.pool.Query(ctx,`SELECT provider_dispute_id,order_ref,payment_id,state,reason,response_due,held_seconds,revision FROM notitle.disputes WHERE environment=$1 AND state IN ('open','review') ORDER BY response_due,provider_dispute_id LIMIT $2`,s.options.Environment,limit);if err!=nil{return nil,ErrUnavailable};defer rows.Close()
    result:=[]AdminDispute{};for rows.Next(){var v AdminDispute;if rows.Scan(&v.ProviderDisputeID,&v.OrderRef,&v.PaymentID,&v.Status,&v.Reason,&v.ResponseDue,&v.HeldSeconds,&v.Revision)!=nil{return nil,ErrUnavailable};result=append(result,v)};if rows.Err()!=nil{return nil,ErrUnavailable};return result,nil
}
func(s *PostgresStore)AdminOrder(ctx context.Context,ref string)(AdminOrderDetail,error){
    var result AdminOrderDetail
    if !adminReference(ref,16,128){return result,ErrInvalid}
    // Repeatable read presents a coherent financial snapshot without locking
    // the owner or exposing a mixture of refund states from different commits.
    tx,err:=s.pool.BeginTx(ctx,pgx.TxOptions{IsoLevel:pgx.RepeatableRead,AccessMode:pgx.ReadOnly});if err!=nil{return result,ErrUnavailable};defer tx.Rollback(context.Background())
    result.Order,err=scanAdminOrder(tx.QueryRow(ctx,`SELECT `+adminOrderColumns+` FROM notitle.purchase_orders WHERE ref=$1 AND environment=$2`,ref,s.options.Environment));if errors.Is(err,pgx.ErrNoRows){return result,ErrNotFound};if err!=nil{return result,ErrUnavailable}
    rows,err:=tx.Query(ctx,`SELECT payment_id,status,currency,amount_paise,paid_at,observed_at FROM notitle.payment_attempts WHERE order_ref=$1 AND environment=$2 ORDER BY observed_at DESC,payment_id LIMIT 100`,ref,s.options.Environment);if err!=nil{return result,ErrUnavailable}
    for rows.Next(){var v AdminAttempt;if rows.Scan(&v.PaymentID,&v.Status,&v.Currency,&v.AmountPaise,&v.PaidAt,&v.ObservedAt)!=nil{rows.Close();return AdminOrderDetail{},ErrUnavailable};result.Attempts=append(result.Attempts,v)};rows.Close();if rows.Err()!=nil{return AdminOrderDetail{},ErrUnavailable}
    rows,err=tx.Query(ctx,`SELECT ref,order_ref,payment_id,COALESCE(provider_refund_id,''),amount_paise,treatment,held_seconds,state,created_at,processed_at FROM notitle.refunds WHERE order_ref=$1 AND environment=$2 ORDER BY created_at DESC,ref LIMIT 100`,ref,s.options.Environment);if err!=nil{return result,ErrUnavailable}
    for rows.Next(){var v Refund;if rows.Scan(&v.Ref,&v.OrderRef,&v.PaymentID,&v.ProviderRefundID,&v.AmountPaise,&v.Treatment,&v.HoldSeconds,&v.Status,&v.CreatedAt,&v.ProcessedAt)!=nil{rows.Close();return AdminOrderDetail{},ErrUnavailable};result.Refunds=append(result.Refunds,v)};rows.Close();if rows.Err()!=nil{return AdminOrderDetail{},ErrUnavailable}
    rows,err=tx.Query(ctx,`SELECT provider_dispute_id,payment_id,state,reason,response_due,held_seconds,revision FROM notitle.disputes WHERE order_ref=$1 AND environment=$2 ORDER BY response_due,provider_dispute_id LIMIT 100`,ref,s.options.Environment);if err!=nil{return result,ErrUnavailable}
    for rows.Next(){var v AdminDispute;if rows.Scan(&v.ProviderDisputeID,&v.PaymentID,&v.Status,&v.Reason,&v.ResponseDue,&v.HeldSeconds,&v.Revision)!=nil{rows.Close();return AdminOrderDetail{},ErrUnavailable};v.OrderRef=ref;result.Disputes=append(result.Disputes,v)};rows.Close();if rows.Err()!=nil{return AdminOrderDetail{},ErrUnavailable}
    rows,err=tx.Query(ctx,`SELECT ref,kind,order_ref,state,created_at,payment_id,reason,revision FROM notitle.billing_review_cases WHERE order_ref=$1 AND environment=$2 ORDER BY created_at DESC,ref LIMIT 100`,ref,s.options.Environment);if err!=nil{return result,ErrUnavailable}
    for rows.Next(){var v AdminReview;if rows.Scan(&v.Ref,&v.Kind,&v.OrderRef,&v.State,&v.CreatedAt,&v.PaymentID,&v.Reason,&v.Revision)!=nil{rows.Close();return AdminOrderDetail{},ErrUnavailable};result.Reviews=append(result.Reviews,v)};rows.Close();if rows.Err()!=nil{return AdminOrderDetail{},ErrUnavailable}
    rows,err=tx.Query(ctx,`SELECT ref,kind,order_ref,payment_id,refund_id,state,amount_paise,fee_paise,tax_paise,net_paise,period_start,period_end FROM notitle.settlement_reconciliation WHERE order_ref=$1 AND environment=$2 ORDER BY recorded_at DESC,ref LIMIT 100`,ref,s.options.Environment);if err!=nil{return result,ErrUnavailable}
    for rows.Next(){var v Reconciliation;if rows.Scan(&v.Ref,&v.Kind,&v.OrderRef,&v.PaymentID,&v.RefundID,&v.State,&v.AmountPaise,&v.FeePaise,&v.TaxPaise,&v.NetPaise,&v.PeriodStart,&v.PeriodEnd)!=nil{rows.Close();return AdminOrderDetail{},ErrUnavailable};result.Reconciliation=append(result.Reconciliation,v)};rows.Close();if rows.Err()!=nil{return AdminOrderDetail{},ErrUnavailable}
    if tx.Commit(ctx)!=nil{return AdminOrderDetail{},ErrUnavailable};return result,nil
}

func(s *PostgresStore)ReviewAction(ctx context.Context,in AdminReviewAction,now time.Time)error{
    if in.ActorID==""||in.AdminGeneration<1||in.ExpectedVersion<1||!adminReference(in.Ref,16,128)||!adminReference(in.IdempotencyKey,16,128)||!adminReason(in.Reason){return ErrInvalid}
    switch in.Action{case "note","resolve","reopen":default:return ErrInvalid}
    tx,err:=s.pool.Begin(ctx);if err!=nil{return ErrUnavailable};defer tx.Rollback(context.Background())
    // This lock is also used by logout/role revocation and money mutations.
    if err=adminGuard(ctx,tx,in.ActorID,in.AdminGeneration,in.AdminSessionHash,now);err!=nil{return err}
    var oldRef,oldAction,oldReason string;var oldVersion int64
    err=tx.QueryRow(ctx,`SELECT a.case_ref,a.action,a.reason,a.expected_revision FROM notitle.billing_review_actions a JOIN notitle.billing_review_cases c ON c.ref=a.case_ref WHERE a.actor_id=$1 AND a.idempotency_key=$2 AND c.environment=$3`,in.ActorID,in.IdempotencyKey,s.options.Environment).Scan(&oldRef,&oldAction,&oldReason,&oldVersion)
    if err==nil{if oldRef!=in.Ref||oldAction!=in.Action||oldReason!=in.Reason||oldVersion!=in.ExpectedVersion{return ErrConflict};if tx.Commit(ctx)!=nil{return ErrUnavailable};return nil};if !errors.Is(err,pgx.ErrNoRows){return ErrUnavailable}
    var current int64;var state string
    err=tx.QueryRow(ctx,`SELECT revision,state FROM notitle.billing_review_cases WHERE ref=$1 AND environment=$2 FOR UPDATE`,in.Ref,s.options.Environment).Scan(&current,&state);if errors.Is(err,pgx.ErrNoRows){return ErrNotFound};if err!=nil{return ErrUnavailable};if current!=in.ExpectedVersion{return ErrConflict}
    next:=state;if in.Action=="resolve"{next="resolved"};if in.Action=="reopen"{next="open"}
    if _,err=tx.Exec(ctx,`UPDATE notitle.billing_review_cases SET state=$2,reason=$3,revision=revision+1,resolved_at=CASE WHEN $2='resolved' THEN $4 ELSE NULL END WHERE ref=$1`,in.Ref,next,in.Reason,now);err!=nil{return ErrUnavailable}
    if _,err=tx.Exec(ctx,`INSERT INTO notitle.billing_review_actions(case_ref,actor_id,idempotency_key,expected_revision,action,reason,created_at) VALUES($1,$2,$3,$4,$5,$6,$7)`,in.Ref,in.ActorID,in.IdempotencyKey,in.ExpectedVersion,in.Action,in.Reason,now);err!=nil{return ErrUnavailable}
    // Closing a work item never creates money, changes a grant, suppresses
    // provider reconciliation, or asserts a customer's bank has credited funds.
    if err=audit(ctx,tx,in.ActorID,"billing_review_"+in.Action,in.Ref,in.Reason,now);err!=nil{return err}
    if tx.Commit(ctx)!=nil{return ErrUnavailable};return nil
}
func adminReference(v string,min,max int)bool{if len(v)<min||len(v)>max{return false};for _,r:=range v{if !(r>='a'&&r<='z'||r>='A'&&r<='Z'||r>='0'&&r<='9'||r=='_'||r=='-'){return false}};return true}
func adminReason(v string)bool{if !utf8.ValidString(v)||len(v)>4000||utf8.RuneCountInString(v)>1000||len(strings.TrimSpace(v))<5{return false};for _,r:=range v{if unicode.IsControl(r)&&r!='\n'&&r!='\t'||r>=0x202a&&r<=0x202e||r>=0x2066&&r<=0x2069{return false}};return true}
