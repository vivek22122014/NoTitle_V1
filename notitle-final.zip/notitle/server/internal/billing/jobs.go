package billing

import (
 "context"
 "crypto/sha256"
 "encoding/hex"
 "errors"
 "fmt"
 "strings"
 "time"
 "github.com/jackc/pgx/v5"
)

func queueJob(ctx context.Context,tx pgx.Tx,env Environment,kind,order,refund,event,key string,runAt,now,start,end time.Time)error{
 if kind=="order_poll"||kind=="refund_poll"{var pending bool;var err error;if kind=="order_poll"{err=tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.billing_jobs WHERE environment=$1 AND order_ref=$2 AND state IN ('ready','leased') AND kind IN ('order','order_poll','verify_order','webhook'))`,env,order).Scan(&pending)}else{err=tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.billing_jobs WHERE environment=$1 AND refund_ref=$2 AND state IN ('ready','leased') AND kind IN ('refund','refund_poll'))`,env,refund).Scan(&pending)};if err!=nil{return ErrUnavailable};if pending{return nil}}
 var a,b any;if !start.IsZero(){a=start};if !end.IsZero(){b=end}
 _,err:=tx.Exec(ctx,`INSERT INTO notitle.billing_jobs(environment,kind,order_ref,refund_ref,event_key,dedupe_key,run_at,created_at,period_start,period_end) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) ON CONFLICT(dedupe_key) DO NOTHING`,env,kind,order,refund,event,string(env)+":"+key,runAt,now,a,b);if err!=nil{return ErrUnavailable};return nil
}
// A confirmed provider 404 can expire an old, never-associated intent locally.
// This is not financial truth and never prevents a later verified capture.
func(s *PostgresStore)OrderAbsent(ctx context.Context,ref string,now time.Time)(bool,error){return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){o,err:=scanOrder(tx.QueryRow(ctx,`SELECT `+orderColumns+` FROM notitle.purchase_orders WHERE ref=$1 AND environment=$2 FOR UPDATE`,ref,s.options.Environment));if err!=nil{return false,err};if o.Order.Status=="expired"{return true,nil};if o.ProviderOrderID!=""||now.Sub(o.Order.CreatedAt)<24*time.Hour||(o.Order.Status!="intent"&&o.Order.Status!="processing"){return false,nil};if _,err=tx.Exec(ctx,`UPDATE notitle.purchase_orders SET state='expired',checkout_session=NULL WHERE ref=$1`,ref);err!=nil{return false,ErrUnavailable};return true,nil})}
func(s *PostgresStore)materializeDisputes(ctx context.Context,tx pgx.Tx,order,payment string,now time.Time)error{
 _,err:=tx.Exec(ctx,`INSERT INTO notitle.disputes(environment,provider_dispute_id,order_ref,payment_id,state,response_due,reason,created_at,updated_at) SELECT environment,dispute_id,order_ref,payment_id,'review',min(response_due),'Signed provider dispute requires review',min(received_at),$4 FROM notitle.payment_webhook_inbox WHERE environment=$1 AND order_ref=$2 AND payment_id=$3 AND dispute_id<>'' AND response_due IS NOT NULL GROUP BY environment,dispute_id,order_ref,payment_id ON CONFLICT(environment,provider_dispute_id) DO UPDATE SET response_due=LEAST(notitle.disputes.response_due,EXCLUDED.response_due),updated_at=EXCLUDED.updated_at WHERE notitle.disputes.order_ref=EXCLUDED.order_ref AND notitle.disputes.payment_id=EXCLUDED.payment_id`,s.options.Environment,order,payment,now);if err!=nil{return ErrUnavailable};return nil
}
func(s *PostgresStore)EnqueueWebhook(ctx context.Context,e WebhookEvent,now time.Time)error{
 if e.Environment!=s.options.Environment||e.MerchantID!=s.options.MerchantID||len(e.EventKey)<16||len(e.EventKey)>256||len(e.Kind)<1||len(e.Kind)>100||len(e.OrderRef)>128||len(e.PaymentID)>200||len(e.RefundID)>200||len(e.ProviderDisputeID)>200{return ErrInvalid}
 _,err:=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){var due any;if !e.ResponseDue.IsZero(){due=e.ResponseDue};tag,err:=tx.Exec(ctx,`INSERT INTO notitle.payment_webhook_inbox(environment,event_key,kind,order_ref,payment_id,refund_id,dispute_id,dispute_status,response_due,received_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) ON CONFLICT(environment,event_key) DO NOTHING`,e.Environment,e.EventKey,e.Kind,e.OrderRef,e.PaymentID,e.RefundID,e.ProviderDisputeID,e.DisputeStatus,due,now);if err!=nil{return false,ErrUnavailable};if tag.RowsAffected()==0{return true,nil}
  if e.ProviderDisputeID!=""{if err=s.review(ctx,tx,"provider_dispute",e.OrderRef,e.PaymentID,now);err!=nil{return false,err}
   // Preserve signed deadlines immediately; later financial association is
   // reconciled, never inferred from amount/contact. No automatic account ban.
   var known bool;if tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.payment_attempts WHERE environment=$1 AND payment_id=$2 AND order_ref=$3 AND status='SUCCESS')`,e.Environment,e.PaymentID,e.OrderRef).Scan(&known)!=nil{return false,ErrUnavailable}
   if known&&!e.ResponseDue.IsZero(){_,err=tx.Exec(ctx,`INSERT INTO notitle.disputes(environment,provider_dispute_id,order_ref,payment_id,state,response_due,reason,created_at,updated_at) VALUES($1,$2,$3,$4,'review',$5,'Signed provider dispute requires review',$6,$6) ON CONFLICT(environment,provider_dispute_id) DO UPDATE SET response_due=LEAST(notitle.disputes.response_due,EXCLUDED.response_due),updated_at=EXCLUDED.updated_at,revision=notitle.disputes.revision+1`,e.Environment,e.ProviderDisputeID,e.OrderRef,e.PaymentID,e.ResponseDue,now);if err!=nil{return false,ErrUnavailable}}
  }
  if e.OrderRef==""{if err=s.review(ctx,tx,"unassociated_webhook","",e.EventKey,now);err!=nil{return false,err};return true,nil}
  return true,queueJob(ctx,tx,e.Environment,"webhook",e.OrderRef,"",e.EventKey,"webhook:"+e.EventKey,now,now,time.Time{},time.Time{})
 });return err
}
func(s *PostgresStore)ClaimJobs(ctx context.Context,worker string,limit int,now time.Time)([]Job,error){
 if !validReference.MatchString(worker)||limit<1||limit>16{return nil,ErrInvalid};lease,err:=ref();if err!=nil{return nil,err}
 return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)([]Job,error){rows,err:=tx.Query(ctx,`WITH due AS (SELECT id FROM notitle.billing_jobs WHERE environment=$1 AND ((state='ready' AND run_at<=$2) OR (state='leased' AND lease_until<=$2)) ORDER BY run_at,id FOR UPDATE SKIP LOCKED LIMIT $3) UPDATE notitle.billing_jobs j SET state='leased',lease_owner=$4,lease_until=$2+interval '30 seconds',attempts=j.attempts+1 FROM due WHERE j.id=due.id RETURNING j.id,j.kind,j.order_ref,j.refund_ref,j.event_key,j.lease_owner,j.attempts,j.environment,COALESCE(j.period_start,'epoch'::timestamptz),COALESCE(j.period_end,'epoch'::timestamptz),j.cursor`,s.options.Environment,now,limit,lease);if err!=nil{return nil,ErrUnavailable};defer rows.Close();out:=[]Job{};for rows.Next(){var j Job;if rows.Scan(&j.ID,&j.Kind,&j.OrderRef,&j.RefundRef,&j.EventKey,&j.LeaseOwner,&j.Attempts,&j.Environment,&j.PeriodStart,&j.PeriodEnd,&j.Cursor)!=nil{return nil,ErrUnavailable};out=append(out,j)};if rows.Err()!=nil{return nil,ErrUnavailable};return out,nil})
}
func(s *PostgresStore)FinishJob(ctx context.Context,r JobResult,now time.Time)error{
 if r.ID<1||!validReference.MatchString(r.LeaseOwner)||len(r.Cursor)>4096||len(r.ReviewKind)>100||(r.Continue&&(!r.Success||r.Cursor=="")){return ErrInvalid}
 _,err:=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){var order,payment string;var attempts,pages int;err:=tx.QueryRow(ctx,`SELECT order_ref,event_key,attempts,page_count FROM notitle.billing_jobs WHERE id=$1 AND environment=$2 AND state='leased' AND lease_owner=$3 AND lease_until>$4 FOR UPDATE`,r.ID,s.options.Environment,r.LeaseOwner,now).Scan(&order,&payment,&attempts,&pages);if errors.Is(err,pgx.ErrNoRows){return false,ErrConflict};if err!=nil{return false,ErrUnavailable}
  state:="ready";run:=r.RetryAt;var finished any;if r.Success{state="done";finished=now};if r.Continue{pages++;if pages>=1000{state="dead";finished=now;if err=s.review(ctx,tx,"reconciliation_page_limit",order,payment,now);err!=nil{return false,err}}else{state="ready";run=now;finished=nil;attempts=0}};if !r.Success&&(r.ReviewKind!=""||attempts>=12){state="dead";finished=now;kind:=r.ReviewKind;if kind==""{kind="worker_retries_exhausted"};if err=s.review(ctx,tx,kind,order,payment,now);err!=nil{return false,err}};if state=="ready"&&run.Before(now){run=now.Add(5*time.Second)}
  _,err=tx.Exec(ctx,`UPDATE notitle.billing_jobs SET state=$2,run_at=$3,lease_owner=NULL,lease_until=NULL,finished_at=$4,cursor=$5,attempts=$6,page_count=$7 WHERE id=$1`,r.ID,state,run,finished,r.Cursor,attempts,pages);if err!=nil{return false,ErrUnavailable};return true,nil
 });return err
}
func(s *PostgresStore)ScheduleReconciliation(ctx context.Context,now time.Time)error{
 _,err:=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){bucket:=now.UTC().Truncate(5*time.Minute).Format(time.RFC3339)
  rows,err:=tx.Query(ctx,`SELECT ref FROM notitle.purchase_orders WHERE environment=$1 AND (state IN ('intent','checkout_ready','processing') OR (state='paid' AND created_at>$2-interval '2 days') OR EXISTS(SELECT 1 FROM notitle.refunds r WHERE r.order_ref=notitle.purchase_orders.ref AND r.state IN ('pending','review'))) ORDER BY last_reconciled_at NULLS FIRST,created_at LIMIT 500`,s.options.Environment,now);if err!=nil{return false,ErrUnavailable};orders:=[]string{};for rows.Next(){var ref string;if rows.Scan(&ref)!=nil{rows.Close();return false,ErrUnavailable};orders=append(orders,ref)};rows.Close();if rows.Err()!=nil{return false,ErrUnavailable}
  for _,order:=range orders{if _,err=tx.Exec(ctx,`UPDATE notitle.purchase_orders SET last_reconciled_at=$2 WHERE ref=$1`,order,now);err!=nil{return false,ErrUnavailable};if err=queueJob(ctx,tx,s.options.Environment,"order_poll",order,"","","poll:"+bucket+":"+order,now,now,time.Time{},time.Time{});err!=nil{return false,err}}
  rows,err=tx.Query(ctx,`SELECT ref,order_ref FROM notitle.refunds WHERE environment=$1 AND state IN ('pending','review') AND NOT external ORDER BY last_reconciled_at NULLS FIRST,created_at LIMIT 500`,s.options.Environment);if err!=nil{return false,ErrUnavailable};refunds:=[][2]string{};for rows.Next(){var r [2]string;if rows.Scan(&r[0],&r[1])!=nil{rows.Close();return false,ErrUnavailable};refunds=append(refunds,r)};rows.Close();if rows.Err()!=nil{return false,ErrUnavailable};for _,r:=range refunds{if _,err=tx.Exec(ctx,`UPDATE notitle.refunds SET last_reconciled_at=$2 WHERE ref=$1`,r[0],now);err!=nil{return false,ErrUnavailable};if err=queueJob(ctx,tx,s.options.Environment,"refund_poll",r[1],r[0],"","refundpoll:"+bucket+":"+r[0],now,now,time.Time{},time.Time{});err!=nil{return false,err}}
  // UTC daily windows are immutable job inputs. Every restart resumes cursors;
  // the previous three days overlap to catch late settlement/report posting.
  end:=now.UTC().Truncate(24*time.Hour);for day:=1;day<=3;day++{start:=end.Add(-time.Duration(day)*24*time.Hour);finish:=start.Add(24*time.Hour);for _,kind:=range []string{"daily_pg","daily_settlement"}{if err=queueJob(ctx,tx,s.options.Environment,kind,"","","",kind+":"+start.Format("2006-01-02")+":seen:"+end.Format("2006-01-02"),now,now,start,finish);err!=nil{return false,err}}}
  // Durable scheduling watermark catches outages longer than the overlap.
  // Jobs are committed atomically with advancing it, so a crash loses neither.
  for _,kind:=range []string{"daily_pg","daily_settlement"}{
   if _,err=tx.Exec(ctx,`INSERT INTO notitle.billing_reconciliation_watermarks(environment,kind,next_period) SELECT $1,$2,COALESCE(date_trunc('day',min(created_at) AT TIME ZONE 'UTC') AT TIME ZONE 'UTC',$3) FROM notitle.purchase_orders WHERE environment=$1 ON CONFLICT(environment,kind) DO NOTHING`,s.options.Environment,kind,end.Add(-24*time.Hour));err!=nil{return false,ErrUnavailable}
   var next time.Time;if tx.QueryRow(ctx,`SELECT next_period FROM notitle.billing_reconciliation_watermarks WHERE environment=$1 AND kind=$2 FOR UPDATE`,s.options.Environment,kind).Scan(&next)!=nil{return false,ErrUnavailable}
   for day:=0;day<7&&next.Before(end);day++{finish:=next.Add(24*time.Hour);if err=queueJob(ctx,tx,s.options.Environment,kind,"","","",kind+":catchup:"+next.Format("2006-01-02"),now,now,next,finish);err!=nil{return false,err};next=finish}
   if _,err=tx.Exec(ctx,`UPDATE notitle.billing_reconciliation_watermarks SET next_period=$3 WHERE environment=$1 AND kind=$2`,s.options.Environment,kind,next);err!=nil{return false,ErrUnavailable}
  }
  // Known successful but ungranted captures are never silently lost.
  rows,err=tx.Query(ctx,`SELECT p.order_ref,p.payment_id FROM notitle.payment_attempts p WHERE p.environment=$1 AND p.status='SUCCESS' AND p.observed_at<=$2-interval '5 minutes' AND NOT EXISTS(SELECT 1 FROM notitle.premium_lots l WHERE l.order_ref=p.order_ref) LIMIT 100`,s.options.Environment,now);if err!=nil{return false,ErrUnavailable};missing:=[][2]string{};for rows.Next(){var r [2]string;if rows.Scan(&r[0],&r[1])!=nil{rows.Close();return false,ErrUnavailable};missing=append(missing,r)};rows.Close();if rows.Err()!=nil{return false,ErrUnavailable};for _,r:=range missing{if err=s.review(ctx,tx,"successful_ungranted",r[0],r[1],now);err!=nil{return false,err}}
  return true,nil
 });if err!=nil{return err};return s.expireBalances(ctx,now)
}
func(s *PostgresStore)expireBalances(ctx context.Context,now time.Time)error{
 rows,err:=s.pool.Query(ctx,`SELECT a.account_id::text FROM notitle.premium_accounts a JOIN notitle.premium_lots l ON l.account_id=a.account_id AND l.environment=a.environment WHERE a.environment=$1 AND l.remaining_seconds>0 GROUP BY a.account_id,a.checkpoint_at HAVING a.checkpoint_at+sum(l.remaining_seconds)*interval '1 second'<=$2 ORDER BY a.account_id LIMIT 100`,s.options.Environment,now);if err!=nil{return ErrUnavailable};ids:=[]string{};for rows.Next(){var id string;if rows.Scan(&id)!=nil{rows.Close();return ErrUnavailable};ids=append(ids,id)};rows.Close();if rows.Err()!=nil{return ErrUnavailable};for _,id:=range ids{_,err=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){if _,_,err:=lockAccount(ctx,tx,id);err!=nil{return false,err};_,err:=s.checkpoint(ctx,tx,id,now);return true,err});if err!=nil{return err}};return nil
}
func(s *PostgresStore)RecordReconciliation(ctx context.Context,r Reconciliation,now time.Time)error{
 if !providerReference.MatchString(r.Ref)||len(r.Kind)<1||len(r.Kind)>100||len(r.OrderRef)>128||r.AmountPaise<0||r.FeePaise<0||r.TaxPaise<0||r.PeriodEnd.Before(r.PeriodStart){return ErrInvalid}
 if r.Currency!="INR"||r.ProviderStatus==""||(!NonCaptureObservation(r)&&!r.MoneyComplete){r.State="review"}
 _,err:=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){observation:=sha256.Sum256([]byte(fmt.Sprintf("%s|%s|%s|%s|%s|%s|%s|%t|%d|%d|%d|%d",r.Ref,r.Kind,r.OrderRef,r.PaymentID,r.RefundID,r.ProviderStatus,r.Currency,r.MoneyComplete,r.AmountPaise,r.FeePaise,r.TaxPaise,r.NetPaise)));key:=string(s.options.Environment)+":"+hex.EncodeToString(observation[:]);_,err:=tx.Exec(ctx,`INSERT INTO notitle.settlement_reconciliation(ref,environment,kind,order_ref,payment_id,refund_id,state,amount_paise,fee_paise,tax_paise,net_paise,period_start,period_end,recorded_at,provider_status,currency,money_complete) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17) ON CONFLICT(ref) DO NOTHING`,key,s.options.Environment,r.Kind,r.OrderRef,r.PaymentID,r.RefundID,r.State,r.AmountPaise,r.FeePaise,r.TaxPaise,r.NetPaise,r.PeriodStart,r.PeriodEnd,now,r.ProviderStatus,r.Currency,r.MoneyComplete);if err!=nil{return false,ErrUnavailable}
  if r.State=="review"{if err=s.review(ctx,tx,"reconciliation_exception",r.OrderRef,r.PaymentID,now);err!=nil{return false,err}}
  if r.OrderRef==""{return true,s.review(ctx,tx,"unassociated_settlement","",r.Ref,now)}
  o,err:=scanOrder(tx.QueryRow(ctx,`SELECT `+orderColumns+` FROM notitle.purchase_orders WHERE ref=$1 AND environment=$2`,r.OrderRef,s.options.Environment));if errors.Is(err,ErrNotFound){return true,s.review(ctx,tx,"unknown_reconciliation_order",r.OrderRef,r.PaymentID,now)};if err!=nil{return false,err}
  if strings.Contains(r.Kind,"PAYMENT")&&!NonCaptureObservation(r)&&r.AmountPaise!=o.Order.Plan.AmountPaise{if err=s.review(ctx,tx,"reconciliation_amount",r.OrderRef,r.PaymentID,now);err!=nil{return false,err}}
  if strings.HasPrefix(r.Kind,"daily_settlement:")&&r.NetPaise!=r.AmountPaise-r.FeePaise-r.TaxPaise{if err=s.review(ctx,tx,"settlement_arithmetic",r.OrderRef,r.PaymentID,now);err!=nil{return false,err}}
  return true,queueJob(ctx,tx,s.options.Environment,"verify_order",r.OrderRef,"","","recon:"+key+":seen:"+now.UTC().Format("2006-01-02"),now,now,time.Time{},time.Time{})
 });return err
}
