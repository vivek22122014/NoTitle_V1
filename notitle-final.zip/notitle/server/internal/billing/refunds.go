package billing

import (
 "context"
 "errors"
 "time"
 "github.com/jackc/pgx/v5"
 "notitle/internal/identity"
)

const refundColumns=`ref,order_ref,payment_id,COALESCE(provider_refund_id,''),amount_paise,treatment,held_seconds,state,created_at,processed_at`
func scanRefund(row pgx.Row)(Refund,error){var r Refund;err:=row.Scan(&r.Ref,&r.OrderRef,&r.PaymentID,&r.ProviderRefundID,&r.AmountPaise,&r.Treatment,&r.HoldSeconds,&r.Status,&r.CreatedAt,&r.ProcessedAt);if errors.Is(err,pgx.ErrNoRows){return r,ErrNotFound};if err!=nil{return r,ErrUnavailable};return r,nil}
func refundBalance(ctx context.Context,tx pgx.Tx,env Environment,order,payment string)(captured,reserved int64,paid time.Time,err error){
 e:=tx.QueryRow(ctx,`SELECT amount_paise,paid_at FROM notitle.payment_attempts WHERE environment=$1 AND payment_id=$2 AND order_ref=$3 AND status='SUCCESS'`,env,payment,order).Scan(&captured,&paid);if errors.Is(e,pgx.ErrNoRows){err=ErrNotFound;return};if e!=nil{err=ErrUnavailable;return};e=tx.QueryRow(ctx,`SELECT COALESCE(sum(amount_paise),0) FROM notitle.refunds WHERE environment=$1 AND payment_id=$2 AND state IN ('pending','processed','review')`,env,payment).Scan(&reserved);if e!=nil{err=ErrUnavailable};return
}
func(s *PostgresStore)PreviewRefund(ctx context.Context,order,payment string,now time.Time)(RefundPreview,error){
 stored,err:=s.StoredOrder(ctx,order);if err!=nil{return RefundPreview{},err};return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(RefundPreview,error){
  out:=RefundPreview{OrderRef:order,PaymentID:payment};var b Balance
  if stored.AccountID!=""{if _,_,err:=lockAccount(ctx,tx,stored.AccountID);err!=nil{return out,err};var err error;b,err=s.checkpoint(ctx,tx,stored.AccountID,now);if err!=nil{return out,err};out.Revision=b.Revision}
  capture,reserved,paid,err:=refundBalance(ctx,tx,s.options.Environment,order,payment);if err!=nil{return out,err};out.CapturedPaise=capture;out.RefundablePaise=capture-reserved;out.Within24Hours=!now.Before(paid)&&now.Sub(paid)<=24*time.Hour
  for _,l:=range b.Lots{if l.OrderRef==order&&l.PaymentID==payment{out.AvailableSeconds=l.Remaining}};if tx.QueryRow(ctx,`SELECT COALESCE((SELECT paid_controls_used FROM notitle.premium_lots WHERE order_ref=$1 AND payment_id=$2 AND environment=$3),false)`,order,payment,s.options.Environment).Scan(&out.UsedPaidControls)!=nil{return out,ErrUnavailable};return out,nil
 })
}
func(s *PostgresStore)PendingRefund(ctx context.Context,ref string)(Refund,error){return scanRefund(s.pool.QueryRow(ctx,`SELECT `+refundColumns+` FROM notitle.refunds WHERE ref=$1 AND environment=$2`,ref,s.options.Environment))}
func(s *PostgresStore)Refunds(ctx context.Context,g identity.Guard,order string,now time.Time)([]Refund,error){return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)([]Refund,error){if err:=guardSession(ctx,tx,g,now);err!=nil{return nil,err};var owned bool;if tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.purchase_orders WHERE ref=$1 AND account_id=$2 AND environment=$3)`,order,g.AccountID,s.options.Environment).Scan(&owned)!=nil{return nil,ErrUnavailable};if !owned{return nil,ErrNotFound};rows,err:=tx.Query(ctx,`SELECT `+refundColumns+` FROM notitle.refunds WHERE order_ref=$1 ORDER BY created_at DESC,ref LIMIT 100`,order);if err!=nil{return nil,ErrUnavailable};defer rows.Close();out:=[]Refund{};for rows.Next(){r,e:=scanRefund(rows);if e!=nil{return nil,e};out=append(out,r)};if rows.Err()!=nil{return nil,ErrUnavailable};return out,nil})}
func(s *PostgresStore)CreateRefund(ctx context.Context,in RefundRequest,now time.Time)(Refund,error){
 if in.Treatment==""{in.Treatment="money_only"};if !validReference.MatchString(in.IdempotencyKey)||!validReference.MatchString(in.OrderRef)||!providerReference.MatchString(in.PaymentID)||in.AmountPaise<=0||!adminReason(in.Reason)||(in.Treatment!="full"&&in.Treatment!="money_only"&&in.Treatment!="duration")||in.ReduceSeconds<0||(in.Treatment!="duration"&&in.ReduceSeconds!=0)||(in.Treatment=="duration"&&in.ReduceSeconds==0){return Refund{},ErrInvalid}
 stored,err:=s.StoredOrder(ctx,in.OrderRef);if err!=nil{return Refund{},err};var out Refund
 err=s.mutate(ctx,stored.AccountID,now,func()error{var inner error;out,inner=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(Refund,error){
  if err:=adminGuard(ctx,tx,in.ActorID,in.AdminGeneration,in.AdminSessionHash,now);err!=nil{return Refund{},err}
  var b Balance;if stored.AccountID!=""{if _,_,err:=lockAccount(ctx,tx,stored.AccountID);err!=nil{return Refund{},err};var err error;b,err=s.checkpoint(ctx,tx,stored.AccountID,now);if err!=nil{return Refund{},err}}
  // Lock the purchase before examining reservations. This serializes refunds
  // for duplicate captures too, even when a deleted account has no live row.
  if _,err:=scanOrder(tx.QueryRow(ctx,`SELECT `+orderColumns+` FROM notitle.purchase_orders WHERE ref=$1 FOR UPDATE`,in.OrderRef));err!=nil{return Refund{},err}
  old,err:=scanRefund(tx.QueryRow(ctx,`SELECT `+refundColumns+` FROM notitle.refunds WHERE idempotency_key=$1`,in.IdempotencyKey));if err==nil{var actor,reason string;if tx.QueryRow(ctx,`SELECT COALESCE(actor_id::text,''),reason FROM notitle.refunds WHERE ref=$1`,old.Ref).Scan(&actor,&reason)!=nil{return Refund{},ErrUnavailable};if old.OrderRef!=in.OrderRef||old.PaymentID!=in.PaymentID||old.AmountPaise!=in.AmountPaise||old.Treatment!=in.Treatment||actor!=in.ActorID||reason!=in.Reason||(in.Treatment=="duration"&&old.HoldSeconds!=in.ReduceSeconds){return Refund{},ErrConflict};return old,nil};if !errors.Is(err,ErrNotFound){return Refund{},err}
  if b.Revision!=in.ExpectedRevision{return Refund{},ErrConflict};captured,reserved,_,err:=refundBalance(ctx,tx,s.options.Environment,in.OrderRef,in.PaymentID);if err!=nil{return Refund{},err};if in.AmountPaise>captured-reserved{return Refund{},ErrConflict};if in.Treatment=="full"&&(reserved!=0||in.AmountPaise!=captured){return Refund{},ErrConflict}
  hold:=int64(0);lot:=-1;for i:=range b.Lots{if b.Lots[i].OrderRef==in.OrderRef&&b.Lots[i].PaymentID==in.PaymentID{lot=i;break}}
  if in.Treatment!="money_only"&&lot>=0{if b.Lots[lot].Held!=0{return Refund{},ErrConflict};if in.Treatment=="full"{hold=b.Lots[lot].Remaining}else{hold=in.ReduceSeconds;if hold>b.Lots[lot].Remaining{return Refund{},ErrConflict}}}else if in.Treatment=="duration"{return Refund{},ErrConflict}
  refundRef,err:=ref();if err!=nil{return Refund{},err};r:=Refund{Ref:refundRef,OrderRef:in.OrderRef,PaymentID:in.PaymentID,AmountPaise:in.AmountPaise,Treatment:in.Treatment,HoldSeconds:hold,Status:"pending",CreatedAt:now}
  _,err=tx.Exec(ctx,`INSERT INTO notitle.refunds(ref,order_ref,environment,payment_id,idempotency_key,amount_paise,treatment,held_seconds,state,actor_id,reason,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,'pending',$9,$10,$11)`,r.Ref,r.OrderRef,s.options.Environment,r.PaymentID,in.IdempotencyKey,r.AmountPaise,r.Treatment,hold,in.ActorID,in.Reason,now);if err!=nil{return Refund{},ErrUnavailable}
  if hold>0{b.Revision++;b.Lots[lot].Remaining-=hold;b.Lots[lot].Held+=hold;if err=s.event(ctx,tx,stored.AccountID,b.Lots[lot].Ref,"hold",hold,b.Revision,r.Ref,now);err!=nil{return Refund{},err};if err=s.saveBalance(ctx,tx,stored.AccountID,b);err!=nil{return Refund{},err}}
  if err=audit(ctx,tx,in.ActorID,"billing_refund_requested",r.Ref,in.Reason,now);err!=nil{return Refund{},err};if err=queueJob(ctx,tx,s.options.Environment,"refund",r.OrderRef,r.Ref,"","refund:"+r.Ref,now,now,time.Time{},time.Time{});err!=nil{return Refund{},err};return r,nil
 });return inner});return out,err
}
func(s *PostgresStore)ResolveRefund(ctx context.Context,in RefundResolution,now time.Time)(GrantResult,error){
 if in.Environment!=s.options.Environment||!providerReference.MatchString(in.ProviderRefundID)||(in.Status!="processed"&&in.Status!="failed"&&in.Status!="cancelled"&&in.Status!="pending")||in.AmountPaise<=0{return GrantResult{},ErrInvalid}
 refund,err:=s.PendingRefund(ctx,in.RefundRef);if err!=nil{return GrantResult{},err};stored,err:=s.StoredOrder(ctx,refund.OrderRef);if err!=nil{return GrantResult{},err};var out GrantResult
 err=s.mutate(ctx,stored.AccountID,now,func()error{var inner error;out,inner=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(GrantResult,error){
  result:=GrantResult{OrderRef:stored.Order.Ref,AccountID:stored.AccountID};var b Balance
  if stored.AccountID!=""{if _,_,err:=lockAccount(ctx,tx,stored.AccountID);err!=nil{return result,err};var err error;b,err=s.checkpoint(ctx,tx,stored.AccountID,now);if err!=nil{return result,err}}
  if _,err:=scanOrder(tx.QueryRow(ctx,`SELECT `+orderColumns+` FROM notitle.purchase_orders WHERE ref=$1 FOR UPDATE`,stored.Order.Ref));err!=nil{return result,err}
  r,err:=scanRefund(tx.QueryRow(ctx,`SELECT `+refundColumns+` FROM notitle.refunds WHERE ref=$1 FOR UPDATE`,in.RefundRef));if err!=nil{return result,err}
  if in.OrderRef!=r.OrderRef||in.PaymentID!=r.PaymentID||in.AmountPaise!=r.AmountPaise||(r.ProviderRefundID!=""&&r.ProviderRefundID!=in.ProviderRefundID){return result,ErrConflict}
  if r.Status=="processed"||r.Status=="failed"||r.Status=="cancelled"{if r.Status!=in.Status&&in.Status!="pending"{if err=s.review(ctx,tx,"refund_terminal_conflict",r.OrderRef,r.PaymentID,now);err!=nil{return result,err};if r.Status!="processed"&&in.Status=="processed"{for i:=range b.Lots{l:=&b.Lots[i];if l.OrderRef==r.OrderRef&&l.PaymentID==r.PaymentID&&r.HoldSeconds>0{if l.Held>0{return result,ErrReview};seconds:=r.HoldSeconds;if seconds>l.Remaining{seconds=l.Remaining};l.Remaining-=seconds;l.Revoked+=seconds;b.Revision++;if err=s.event(ctx,tx,stored.AccountID,l.Ref,"revoke",seconds,b.Revision,r.Ref,now);err!=nil{return result,err}}};if stored.AccountID!=""{if err=s.saveBalance(ctx,tx,stored.AccountID,b);err!=nil{return result,err}};if _,err=tx.Exec(ctx,`UPDATE notitle.refunds SET state='processed',processed_at=$2 WHERE ref=$1`,r.Ref,now);err!=nil{return result,ErrUnavailable};result.Outcome="processed";result.Entitlement=b.Entitlement(now);return result,nil}};result.Outcome=r.Status;result.Entitlement=b.Entitlement(now);return result,nil}
  if in.Status=="pending"{_,err=tx.Exec(ctx,`UPDATE notitle.refunds SET provider_refund_id=$2 WHERE ref=$1`,r.Ref,in.ProviderRefundID);if err!=nil{return result,ErrUnavailable};result.Outcome="pending";return result,nil}
  if r.HoldSeconds>0{found:=false;for i:=range b.Lots{l:=&b.Lots[i];if l.OrderRef==r.OrderRef&&l.PaymentID==r.PaymentID{found=true;if l.Held<r.HoldSeconds{return result,ErrConflict};b.Revision++;l.Held-=r.HoldSeconds;kind:="restore";if in.Status=="processed"{l.Revoked+=r.HoldSeconds;kind="revoke"}else{l.Remaining+=r.HoldSeconds};if err=s.event(ctx,tx,stored.AccountID,l.Ref,kind,r.HoldSeconds,b.Revision,r.Ref,now);err!=nil{return result,err}}};if !found{return result,ErrConflict};if err=s.saveBalance(ctx,tx,stored.AccountID,b);err!=nil{return result,err}}
  _,err=tx.Exec(ctx,`UPDATE notitle.refunds SET provider_refund_id=$2,state=$3,processed_at=$4 WHERE ref=$1`,r.Ref,in.ProviderRefundID,in.Status,now);if err!=nil{return result,ErrUnavailable};if in.Status=="failed"||in.Status=="cancelled"{if err=queueJob(ctx,tx,s.options.Environment,"verify_order",r.OrderRef,"","","refund-restored:"+r.Ref+":"+in.ProviderRefundID,now,now,time.Time{},time.Time{});err!=nil{return result,err}};result.Outcome=in.Status;result.Entitlement=b.Entitlement(now);return result,nil
 });return inner});return out,err
}
// Dashboard refunds enter the same ledger only after server-side verification.
// Missing association and conflicting internal holds go to review, never a
// guessed user. A partial compensation is money-only unless an operator acts.
func(s *PostgresStore)ImportProviderRefund(ctx context.Context,in RefundResolution,now time.Time)(GrantResult,error){
 if (in.Status!="processed"&&in.Status!="pending"&&in.Status!="failed"&&in.Status!="cancelled")||in.Environment!=s.options.Environment||!providerReference.MatchString(in.ProviderRefundID)||in.AmountPaise<=0{return GrantResult{},ErrInvalid}
 var existing string;err:=s.pool.QueryRow(ctx,`SELECT ref FROM notitle.refunds WHERE environment=$1 AND (provider_refund_id=$2 OR ref=$3)`,in.Environment,in.ProviderRefundID,in.RefundRef).Scan(&existing);if err==nil{in.RefundRef=existing;return s.ResolveRefund(ctx,in,now)};if !errors.Is(err,pgx.ErrNoRows){return GrantResult{},ErrUnavailable}
 stored,err:=s.StoredOrder(ctx,in.OrderRef);if err!=nil{return GrantResult{},err};var out GrantResult
 err=s.mutate(ctx,stored.AccountID,now,func()error{var inner error;out,inner=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(GrantResult,error){
  result:=GrantResult{OrderRef:in.OrderRef,AccountID:stored.AccountID};var b Balance;if stored.AccountID!=""{if _,_,err:=lockAccount(ctx,tx,stored.AccountID);err!=nil{return result,err};var err error;b,err=s.checkpoint(ctx,tx,stored.AccountID,now);if err!=nil{return result,err}}
  if _,err:=scanOrder(tx.QueryRow(ctx,`SELECT `+orderColumns+` FROM notitle.purchase_orders WHERE ref=$1 FOR UPDATE`,in.OrderRef));err!=nil{return result,err}
  var count int;if tx.QueryRow(ctx,`SELECT count(*) FROM notitle.refunds WHERE environment=$1 AND provider_refund_id=$2`,in.Environment,in.ProviderRefundID).Scan(&count)!=nil{return result,ErrUnavailable};if count>0{result.Outcome="already_imported";return result,nil}
  captured,reserved,_,err:=refundBalance(ctx,tx,in.Environment,in.OrderRef,in.PaymentID);if err!=nil{return result,err};if in.AmountPaise>captured-reserved{result.Outcome="financial_review";return result,s.review(ctx,tx,"dashboard_refund_balance",in.OrderRef,in.PaymentID,now)}
  r,err:=ref();if err!=nil{return result,err};treatment:="money_only";held:=int64(0)
  if in.AmountPaise==captured&&reserved==0{treatment="full";for i:=range b.Lots{l:=&b.Lots[i];if l.OrderRef==in.OrderRef&&l.PaymentID==in.PaymentID{if l.Held>0{result.Outcome="financial_review";return result,s.review(ctx,tx,"dashboard_refund_hold",in.OrderRef,in.PaymentID,now)};if in.Status=="processed"||in.Status=="pending"{seconds:=l.Remaining;l.Remaining=0;b.Revision++;kind:="revoke";if in.Status=="processed"{l.Revoked+=seconds}else{l.Held+=seconds;held=seconds;kind="hold"};if err=s.event(ctx,tx,stored.AccountID,l.Ref,kind,seconds,b.Revision,r,now);err!=nil{return result,err}}}};if stored.AccountID!=""{if err=s.saveBalance(ctx,tx,stored.AccountID,b);err!=nil{return result,err}}}
  var processed any;if in.Status!="pending"{processed=now}
  _,err=tx.Exec(ctx,`INSERT INTO notitle.refunds(ref,order_ref,environment,payment_id,idempotency_key,provider_refund_id,amount_paise,treatment,held_seconds,state,external,reason,created_at,processed_at) VALUES($1,$2,$3,$4,$1,$5,$6,$7,$8,$9,true,'Verified provider dashboard refund',$10,$11)`,r,in.OrderRef,in.Environment,in.PaymentID,in.ProviderRefundID,in.AmountPaise,treatment,held,in.Status,now,processed);if err!=nil{return result,ErrUnavailable};if err=s.review(ctx,tx,"dashboard_refund",in.OrderRef,in.PaymentID,now);err!=nil{return result,err};result.Outcome=in.Status;result.Entitlement=b.Entitlement(now);return result,nil
 });return inner});return out,err
}
