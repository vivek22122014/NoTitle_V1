package billing

import (
 "context"
 "crypto/rand"
 "encoding/hex"
 "errors"
 "regexp"
 "sync"
 "time"
 "github.com/jackc/pgx/v5"
 "github.com/jackc/pgx/v5/pgxpool"
 "notitle/internal/identity"
)

type MutationFence interface { Begin(context.Context,string)(string,error); Finish(context.Context,string,string,Entitlement)error }
type Options struct { Environment Environment; MerchantID string; Mutations MutationFence }
type pendingMutation struct { token string; finished bool }
type PostgresStore struct { pool *pgxpool.Pool; options Options; mutationMu sync.Mutex; pending map[string]pendingMutation }
var _ Repository=(*PostgresStore)(nil)
func NewPostgresStore(pool *pgxpool.Pool,options Options)*PostgresStore{return &PostgresStore{pool:pool,options:options}}
var validReference=regexp.MustCompile(`^[A-Za-z0-9_-]{16,128}$`)
var providerReference=regexp.MustCompile(`^[A-Za-z0-9_.:-]{1,200}$`)
func ref()(string,error){var b[16]byte;if _,err:=rand.Read(b[:]);err!=nil{return "",ErrUnavailable};return hex.EncodeToString(b[:]),nil}
func transaction[T any](ctx context.Context,s *PostgresStore,fn func(context.Context,pgx.Tx)(T,error))(T,error){
 var zero T;if s==nil||s.pool==nil||(s.options.Environment!=Test&&s.options.Environment!=Live)||s.options.MerchantID==""{return zero,ErrUnavailable}
 ctx,cancel:=context.WithTimeout(ctx,5*time.Second);defer cancel();tx,err:=s.pool.BeginTx(ctx,pgx.TxOptions{IsoLevel:pgx.ReadCommitted});if err!=nil{return zero,ErrUnavailable}
 defer func(){cleanup,stop:=context.WithTimeout(context.Background(),time.Second);defer stop();_ = tx.Rollback(cleanup)}()
 out,err:=fn(ctx,tx);if err!=nil{return out,err};if tx.Commit(ctx)!=nil{return zero,ErrUnavailable};return out,nil
}
func lockAccount(ctx context.Context,tx pgx.Tx,id string)(string,int64,error){var state string;var generation int64;err:=tx.QueryRow(ctx,`SELECT status,generation FROM notitle.accounts WHERE id=$1 FOR UPDATE`,id).Scan(&state,&generation);if errors.Is(err,pgx.ErrNoRows){return "",0,ErrUnauthorized};if err!=nil{return "",0,ErrUnavailable};return state,generation,nil}
func guardSession(ctx context.Context,tx pgx.Tx,g identity.Guard,now time.Time)error{
 state,generation,err:=lockAccount(ctx,tx,g.AccountID);if err!=nil{return err};if state!="active"||generation!=g.AccountGeneration{return ErrUnauthorized}
 var valid bool;err=tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.sessions WHERE id=$1 AND account_id=$2 AND token_hash=$3 AND account_generation=$4 AND revoked_at IS NULL AND created_at<=$5 AND absolute_expires_at>$5 AND last_seen_at>$5-interval '7 days' AND (NOT $6 OR authenticated_at>$5-interval '5 minutes'))`,g.SessionID,g.AccountID,g.TokenHash[:],generation,now,g.RequireRecent).Scan(&valid);if err!=nil{return ErrUnavailable};if !valid{return ErrUnauthorized};return nil
}
func adminGuard(ctx context.Context,tx pgx.Tx,id string,generation int64,hash [32]byte,now time.Time)error{
 var active bool;err:=tx.QueryRow(ctx,`SELECT NOT disabled AND generation=$2 AND roles && ARRAY['owner','billing_operator']::text[] FROM notitle.admin_users WHERE id=$1 FOR UPDATE`,id,generation).Scan(&active);if err!=nil||!active{return ErrUnauthorized}
 err=tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.admin_sessions WHERE token_hash=$1 AND admin_id=$2 AND admin_generation=$3 AND created_at<=$4 AND absolute_expires_at>$4 AND last_seen_at>$4-interval '15 minutes')`,hash[:],id,generation,now).Scan(&active);if err!=nil{return ErrUnavailable};if !active{return ErrUnauthorized};return nil
}
func audit(ctx context.Context,tx pgx.Tx,actor,action,subject,reason string,now time.Time)error{
 id,err:=ref();if err!=nil{return err};id=id[:8]+"-"+id[8:12]+"-"+id[12:16]+"-"+id[16:20]+"-"+id[20:32]
 _,err=tx.Exec(ctx,`INSERT INTO notitle.admin_audit(id,admin_id,action,subject_ref,reason,result,created_at) VALUES($1,$2,$3,$4,$5,'success',$6)`,id,actor,action,subject,reason,now);if err!=nil{return ErrUnavailable};return nil
}
func(s *PostgresStore) mutate(ctx context.Context,account string,now time.Time,fn func()error)error{
 if account==""||s.options.Mutations==nil{return fn()}
 s.mutationMu.Lock();if s.pending==nil{s.pending=map[string]pendingMutation{}};_,busy:=s.pending[account];if busy||len(s.pending)>=256{s.mutationMu.Unlock();return ErrUnavailable};s.pending[account]=pendingMutation{};s.mutationMu.Unlock()
 token,err:=s.options.Mutations.Begin(ctx,account);if err!=nil{s.mutationMu.Lock();delete(s.pending,account);s.mutationMu.Unlock();return ErrUnavailable}
 s.mutationMu.Lock();s.pending[account]=pendingMutation{token:token};s.mutationMu.Unlock();operationErr:=fn()
 // Recovery cannot release the owner fence until the SQL function has returned.
 // A timeout is ambiguous: read committed truth using a fresh bounded context.
 s.mutationMu.Lock();s.pending[account]=pendingMutation{token:token,finished:true};s.mutationMu.Unlock()
 cleanup,cancel:=context.WithTimeout(context.WithoutCancel(ctx),4*time.Second);defer cancel();if err=s.recoverFence(cleanup,account,token,now);err!=nil{return ErrUnavailable};return operationErr
}
func(s *PostgresStore)recoverFence(ctx context.Context,account,token string,now time.Time)error{current,err:=s.AccountEntitlement(ctx,account,now);if err!=nil{return err};if err=s.options.Mutations.Finish(ctx,account,token,current);err!=nil{return err};s.mutationMu.Lock();if p,ok:=s.pending[account];ok&&p.token==token&&p.finished{delete(s.pending,account)};s.mutationMu.Unlock();return nil}
func(s *PostgresStore)RecoverMutationFences(ctx context.Context,now time.Time)error{if s.options.Mutations==nil{return nil};s.mutationMu.Lock();pending:=map[string]string{};for id,p:=range s.pending{if p.finished&&p.token!=""{pending[id]=p.token};if len(pending)>=16{break}};s.mutationMu.Unlock();for id,token:=range pending{if err:=s.recoverFence(ctx,id,token,now);err!=nil{return err}};return nil}
const orderColumns=`ref,COALESCE(account_id::text,''),merchant_id,COALESCE(provider_order_id,''),COALESCE(checkout_session,''),environment,plan_id,plan_version,plan_name,amount_paise,currency,duration_seconds,tax_treatment,tax_paise,state,created_at,paid_at`
func scanOrder(row pgx.Row)(StoredOrder,error){var o StoredOrder;err:=row.Scan(&o.Order.Ref,&o.AccountID,&o.MerchantID,&o.ProviderOrderID,&o.Order.CheckoutSession,&o.Order.Environment,&o.Order.Plan.ID,&o.Order.Plan.Version,&o.Order.Plan.Name,&o.Order.Plan.AmountPaise,&o.Order.Plan.Currency,&o.Order.Plan.DurationSeconds,&o.Order.Plan.TaxTreatment,&o.Order.Plan.TaxPaise,&o.Order.Status,&o.Order.CreatedAt,&o.Order.PaidAt);if errors.Is(err,pgx.ErrNoRows){return o,ErrNotFound};if err!=nil{return o,ErrUnavailable};return o,nil}
func(s *PostgresStore)Catalog(ctx context.Context)([]Plan,error){
 out:=[]Plan{};rows,err:=s.pool.Query(ctx,`SELECT id,version,name,amount_paise,currency,duration_seconds,tax_treatment,tax_paise,enabled FROM notitle.premium_plans WHERE enabled ORDER BY duration_seconds`);if err!=nil{return nil,ErrUnavailable};defer rows.Close();for rows.Next(){var p Plan;if rows.Scan(&p.ID,&p.Version,&p.Name,&p.AmountPaise,&p.Currency,&p.DurationSeconds,&p.TaxTreatment,&p.TaxPaise,&p.Enabled)!=nil{return nil,ErrUnavailable};out=append(out,p)};if rows.Err()!=nil{return nil,ErrUnavailable};return out,nil
}
func(s *PostgresStore)CreateIntent(ctx context.Context,g identity.Guard,in CreateOrderInput,now time.Time)(Order,error){
 if !validReference.MatchString(in.IdempotencyKey)||in.PlanVersion<1{return Order{},ErrInvalid}
 return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(Order,error){
  if err:=guardSession(ctx,tx,g,now);err!=nil{return Order{},err}
  existing,err:=scanOrder(tx.QueryRow(ctx,`SELECT `+orderColumns+` FROM notitle.purchase_orders WHERE environment=$1 AND account_id=$2 AND idempotency_key=$3`,s.options.Environment,g.AccountID,in.IdempotencyKey));if err==nil{if existing.Order.Plan.ID!=in.PlanID||existing.Order.Plan.Version!=in.PlanVersion{return Order{},ErrConflict};return existing.Order,nil};if !errors.Is(err,ErrNotFound){return Order{},err}
  var p Plan;err=tx.QueryRow(ctx,`SELECT id,version,name,amount_paise,currency,duration_seconds,tax_treatment,tax_paise,enabled FROM notitle.premium_plans WHERE id=$1 AND version=$2 AND enabled`,in.PlanID,in.PlanVersion).Scan(&p.ID,&p.Version,&p.Name,&p.AmountPaise,&p.Currency,&p.DurationSeconds,&p.TaxTreatment,&p.TaxPaise,&p.Enabled);if errors.Is(err,pgx.ErrNoRows){return Order{},ErrDisabled};if err!=nil{return Order{},ErrUnavailable}
  // Bound abandoned intent growth. Genuine captures remain eligible forever.
  var pending int;if tx.QueryRow(ctx,`SELECT count(*) FROM notitle.purchase_orders WHERE account_id=$1 AND state IN ('intent','checkout_ready','processing') AND created_at>$2-interval '1 day'`,g.AccountID,now).Scan(&pending)!=nil{return Order{},ErrUnavailable};if pending>=10{return Order{},ErrConflict}
  purchase,err:=ref();if err!=nil{return Order{},err};_,err=tx.Exec(ctx,`INSERT INTO notitle.purchase_orders(ref,account_id,financial_subject,idempotency_key,environment,merchant_id,plan_id,plan_version,plan_name,amount_paise,currency,duration_seconds,tax_treatment,tax_paise,state,created_at) VALUES($1,$2::uuid,$2::text,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,'intent',$14)`,purchase,g.AccountID,in.IdempotencyKey,s.options.Environment,s.options.MerchantID,p.ID,p.Version,p.Name,p.AmountPaise,p.Currency,p.DurationSeconds,p.TaxTreatment,p.TaxPaise,now);if err!=nil{return Order{},ErrUnavailable}
  if err=queueJob(ctx,tx,s.options.Environment,"order",purchase,"","","initial:"+purchase,now,now,time.Time{},time.Time{});err!=nil{return Order{},err}
  return Order{Ref:purchase,Status:"intent",Plan:p,CreatedAt:now,Environment:s.options.Environment},nil
 })
}
func(s *PostgresStore)FindIntent(ctx context.Context,g identity.Guard,key string,now time.Time)(Order,error){if !validReference.MatchString(key){return Order{},ErrInvalid};return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(Order,error){if err:=guardSession(ctx,tx,g,now);err!=nil{return Order{},err};o,err:=scanOrder(tx.QueryRow(ctx,`SELECT `+orderColumns+` FROM notitle.purchase_orders WHERE account_id=$1 AND environment=$2 AND idempotency_key=$3`,g.AccountID,s.options.Environment,key));return o.Order,err})}
func(s *PostgresStore)StoredOrder(ctx context.Context,id string)(StoredOrder,error){if !validReference.MatchString(id){return StoredOrder{},ErrNotFound};return scanOrder(s.pool.QueryRow(ctx,`SELECT `+orderColumns+` FROM notitle.purchase_orders WHERE ref=$1 AND environment=$2`,id,s.options.Environment))}
func(s *PostgresStore)AttachCheckout(ctx context.Context,id string,p ProviderOrder,now time.Time)(Order,error){
 switch p.Status{case "ACTIVE","PAID","EXPIRED","TERMINATED","TERMINATION_REQUESTED":default:return Order{},ErrInvalid}
 return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(Order,error){o,err:=scanOrder(tx.QueryRow(ctx,`SELECT `+orderColumns+` FROM notitle.purchase_orders WHERE ref=$1 AND environment=$2 FOR UPDATE`,id,s.options.Environment));if err!=nil{return Order{},err}
 if p.Ref!=id||p.Environment!=o.Order.Environment||p.MerchantID!=o.MerchantID||p.AmountPaise!=o.Order.Plan.AmountPaise||p.Currency!=o.Order.Plan.Currency||!providerReference.MatchString(p.ProviderOrderID)||(p.CheckoutSession!=""&&len(p.CheckoutSession)<8)||len(p.CheckoutSession)>2048{return Order{},ErrInvalid};if o.ProviderOrderID!=""&&o.ProviderOrderID!=p.ProviderOrderID{return Order{},ErrConflict}
 state:=o.Order.Status;session:=""
 if state!="paid"&&state!="financial_review"{switch p.Status{case "ACTIVE":state="processing";if p.CheckoutSession!=""{session=p.CheckoutSession;state="checkout_ready"};case "PAID":state="processing";default:state="expired"}}
 _,err=tx.Exec(ctx,`UPDATE notitle.purchase_orders SET provider_order_id=$2,checkout_session=NULLIF($3,''),state=$4 WHERE ref=$1`,id,p.ProviderOrderID,session,state);if err!=nil{return Order{},ErrUnavailable};o.Order.Status=state;o.Order.CheckoutSession=session;return o.Order,nil})
}

func(s *PostgresStore)GetOrder(ctx context.Context,g identity.Guard,id string,now time.Time)(Order,error){return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(Order,error){if err:=guardSession(ctx,tx,g,now);err!=nil{return Order{},err};o,err:=scanOrder(tx.QueryRow(ctx,`SELECT `+orderColumns+` FROM notitle.purchase_orders WHERE ref=$1 AND account_id=$2 AND environment=$3`,id,g.AccountID,s.options.Environment));return o.Order,err})}
func(s *PostgresStore)Orders(ctx context.Context,g identity.Guard,now time.Time)([]Order,error){return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)([]Order,error){if err:=guardSession(ctx,tx,g,now);err!=nil{return nil,err};rows,err:=tx.Query(ctx,`SELECT `+orderColumns+` FROM notitle.purchase_orders WHERE account_id=$1 AND environment=$2 ORDER BY created_at DESC,ref LIMIT 100`,g.AccountID,s.options.Environment);if err!=nil{return nil,ErrUnavailable};defer rows.Close();out:=[]Order{};for rows.Next(){o,e:=scanOrder(rows);if e!=nil{return nil,e};out=append(out,o.Order)};if rows.Err()!=nil{return nil,ErrUnavailable};return out,nil})}
func(s *PostgresStore)Receipts(ctx context.Context,g identity.Guard,now time.Time)([]Receipt,error){return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)([]Receipt,error){if err:=guardSession(ctx,tx,g,now);err!=nil{return nil,err};rows,err:=tx.Query(ctx,`SELECT `+orderColumns+` FROM notitle.purchase_orders WHERE account_id=$1 AND environment=$2 AND paid_at IS NOT NULL ORDER BY paid_at DESC,ref LIMIT 100`,g.AccountID,s.options.Environment);if err!=nil{return nil,ErrUnavailable};orders:=[]Order{};for rows.Next(){o,e:=scanOrder(rows);if e!=nil{rows.Close();return nil,e};orders=append(orders,o.Order)};rows.Close();if rows.Err()!=nil{return nil,ErrUnavailable};out:=[]Receipt{};for _,o:=range orders{var amount,captured int64;if tx.QueryRow(ctx,`SELECT COALESCE(sum(amount_paise),0) FROM notitle.refunds WHERE order_ref=$1 AND state='processed'`,o.Ref).Scan(&amount)!=nil{return nil,ErrUnavailable};if tx.QueryRow(ctx,`SELECT COALESCE(sum(amount_paise),0) FROM notitle.payment_attempts WHERE order_ref=$1 AND status='SUCCESS'`,o.Ref).Scan(&captured)!=nil{return nil,ErrUnavailable};out=append(out,Receipt{CapturedPaise:captured,PurchaseRef:o.Ref,Plan:o.Plan,PaidAt:*o.PaidAt,Status:o.Status,RefundedPaise:amount})};return out,nil})}
func(s *PostgresStore)Receipt(ctx context.Context,g identity.Guard,ref string,now time.Time)(Receipt,error){return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(Receipt,error){if err:=guardSession(ctx,tx,g,now);err!=nil{return Receipt{},err};o,err:=scanOrder(tx.QueryRow(ctx,`SELECT `+orderColumns+` FROM notitle.purchase_orders WHERE ref=$1 AND account_id=$2 AND environment=$3 AND paid_at IS NOT NULL`,ref,g.AccountID,s.options.Environment));if err!=nil{return Receipt{},err};r:=Receipt{PurchaseRef:o.Order.Ref,Plan:o.Order.Plan,PaidAt:*o.Order.PaidAt,Status:o.Order.Status};if tx.QueryRow(ctx,`SELECT COALESCE(sum(amount_paise),0) FROM notitle.payment_attempts WHERE order_ref=$1 AND status='SUCCESS'`,ref).Scan(&r.CapturedPaise)!=nil{return Receipt{},ErrUnavailable};if tx.QueryRow(ctx,`SELECT COALESCE(sum(amount_paise),0) FROM notitle.refunds WHERE order_ref=$1 AND state='processed'`,ref).Scan(&r.RefundedPaise)!=nil{return Receipt{},ErrUnavailable};return r,nil})}
