package billing

import (
 "context"
 "time"
 "github.com/jackc/pgx/v5"
)

// AuditLedger replays the immutable journal under the same account lock and
// compares it to every lot, including spent/refunded history. It never repairs
// financial records silently. A false result requires restricted review before
// reopening paid access after a restore. The bound makes operator work explicit.
func(s *PostgresStore)AuditLedger(ctx context.Context,account string,now time.Time)(bool,error){
 return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){if _,_,err:=lockAccount(ctx,tx,account);err!=nil{return false,err}
  b,err:=s.loadBalance(ctx,tx,account,now);if err!=nil{return false,err}
  rows,err:=tx.Query(ctx,`SELECT id,COALESCE(lot_ref,''),kind,reference,seconds,revision,created_at FROM notitle.premium_adjustments WHERE account_id=$1 AND environment=$2 ORDER BY id LIMIT 100001`,account,s.options.Environment);if err!=nil{return false,ErrUnavailable};events:=[]LedgerEvent{};for rows.Next(){var e LedgerEvent;if rows.Scan(&e.Sequence,&e.LotRef,&e.Kind,&e.Reference,&e.Seconds,&e.Revision,&e.At)!=nil{rows.Close();return false,ErrUnavailable};events=append(events,e)};rows.Close();if rows.Err()!=nil{return false,ErrUnavailable};if len(events)>100000{return false,ErrReview}
  replayed,err:=Replay(events);if err!=nil{return false,err};if _,err=AccountElapsed(&replayed,now);err!=nil{return false,err};if _,err=AccountElapsed(&b,now);err!=nil{return false,err};if b.Revision!=replayed.Revision||b.Entitlement(now).RemainingSeconds!=replayed.Entitlement(now).RemainingSeconds{return false,nil}
  // Compare event conservation against all stored lots at the durable
  // checkpoint, before the hypothetical read-time elapsed projection.
  original,err:=Replay(events);if err!=nil{return false,err};byRef:=map[string]Lot{};for _,l:=range original.Lots{byRef[l.Ref]=l}
  rows,err=tx.Query(ctx,`SELECT ref,duration_seconds,remaining_seconds,held_seconds,consumed_seconds,revoked_seconds,paid_controls_used FROM notitle.premium_lots WHERE account_id=$1 AND environment=$2`,account,s.options.Environment);if err!=nil{return false,ErrUnavailable};defer rows.Close();count:=0
  for rows.Next(){var l Lot;if rows.Scan(&l.Ref,&l.Duration,&l.Remaining,&l.Held,&l.Consumed,&l.Revoked,&l.Used)!=nil{return false,ErrUnavailable};other,ok:=byRef[l.Ref];if !ok||l.Duration!=other.Duration||l.Remaining!=other.Remaining||l.Held!=other.Held||l.Consumed!=other.Consumed||l.Revoked!=other.Revoked||l.Used!=other.Used{return false,nil};count++};if rows.Err()!=nil{return false,ErrUnavailable};return count==len(byRef),nil
 })
}
