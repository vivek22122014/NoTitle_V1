package billing

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"strings"
	"time"

	"notitle/internal/cashfree"
)

// Provider is deliberately small, and has no generic URL or unbounded request
// method. Only this background worker and the checkout service perform IO.
type Provider interface {
	Environment() string
	MerchantID() string
	GetOrder(context.Context,string)(cashfree.Order,error)
	Payments(context.Context,string)([]cashfree.Payment,error)
	Refunds(context.Context,string)([]cashfree.Refund,error)
	GetRefund(context.Context,string,string)(cashfree.Refund,error)
	CreateRefund(context.Context,string,string,int64)(cashfree.Refund,error)
	Reconciliation(context.Context,bool,time.Time,time.Time,string)(cashfree.ReconPage,error)
}
type WorkerOptions struct { Store Repository; Provider Provider; Ready func(context.Context)error; Now func()time.Time; OnChange func(context.Context,GrantResult) }
type Worker struct { store Repository; provider Provider; ready func(context.Context)error; now func()time.Time; onChange func(context.Context,GrantResult); lease string }
func NewWorker(o WorkerOptions)(*Worker,error){if o.Store==nil||o.Provider==nil||o.Ready==nil||(o.Provider.Environment()!=string(Test)&&o.Provider.Environment()!=string(Live))||o.Provider.MerchantID()==""{return nil,ErrInvalid};if o.Now==nil{o.Now=time.Now};var id [16]byte;if _,e:=rand.Read(id[:]);e!=nil{return nil,ErrUnavailable};return &Worker{store:o.Store,provider:o.Provider,ready:o.Ready,now:o.Now,onChange:o.OnChange,lease:hex.EncodeToString(id[:])},nil}
func(w *Worker)changed(ctx context.Context,r GrantResult){if r.AccountID!=""&&w.onChange!=nil{w.onChange(ctx,r)}}

// Run resumes expired durable leases after a crash. Neither provider requests
// nor sleeps occur inside a SQL transaction or the realtime coordinator.
func(w *Worker)Run(ctx context.Context){tick:=time.NewTicker(time.Second);defer tick.Stop();var scheduled time.Time
	for {c,cancel:=context.WithTimeout(ctx,3*time.Second);ready:=w.ready(c);cancel();if ready!=nil{select{case<-ctx.Done():return;case<-tick.C:continue}};now:=w.now().UTC();if scheduled.IsZero()||!now.Before(scheduled){c,cancel:=context.WithTimeout(ctx,3*time.Second);e:=w.store.ScheduleReconciliation(c,now);cancel();if e==nil{scheduled=now.Add(5*time.Minute)}}
		c,cancel=context.WithTimeout(ctx,3*time.Second);jobs,e:=w.store.ClaimJobs(c,w.lease,1,now);cancel();if e==nil&&len(jobs)>0{job:=jobs[0];c,cancel=context.WithTimeout(ctx,25*time.Second);next,err:=w.process(c,job);cancel();result:=JobResult{ID:job.ID,LeaseOwner:job.LeaseOwner,Success:err==nil,Cursor:next,Continue:err==nil&&next!=""};if err!=nil{result.RetryAt=w.now().UTC().Add(retryDelay(job.Attempts));if errors.Is(err,ErrReview)||errors.Is(err,ErrInvalid)||errors.Is(err,ErrNotFound)||errors.Is(err,cashfree.ErrInvalid)||errors.Is(err,cashfree.ErrRejected)||job.Attempts>=12{result.ReviewKind="provider_job_review";result.RetryAt=time.Time{}}};c,cancel=context.WithTimeout(ctx,3*time.Second);_ = w.store.FinishJob(c,result,w.now().UTC());cancel()}
		select{case<-ctx.Done():return;case<-tick.C:}
	}
}
func retryDelay(attempt int)time.Duration{if attempt<1{attempt=1};if attempt>6{attempt=6};return time.Duration(1<<attempt)*5*time.Second}
func(w *Worker)process(ctx context.Context,j Job)(string,error){if j.Environment!=Environment(w.provider.Environment()){return "",ErrReview};switch j.Kind{case "order","order_poll","verify_order","webhook":if j.OrderRef==""{return "",ErrReview};return "",w.VerifyOrder(ctx,j.OrderRef);case "refund","refund_poll":return "",w.ProcessRefund(ctx,j.RefundRef);case "daily_pg","daily_settlement":return w.reconcilePage(ctx,j);default:return "",ErrReview}}

// VerifyOrder is shared by return-page verification, inbox jobs and reconciler.
// A redirect, signed webhook status, browser amount or catalogue rename cannot
// grant time: all financial fields are fetched using the bound merchant key.
func(w *Worker)VerifyOrder(ctx context.Context,ref string)error{
	if w.ready(ctx)!=nil{return ErrUnavailable}
	s,e:=w.store.StoredOrder(ctx,ref);if e!=nil{return e};if s.Order.Environment!=Environment(w.provider.Environment())||s.MerchantID!=w.provider.MerchantID(){return ErrReview}
	p,e:=w.provider.GetOrder(ctx,ref)
	if errors.Is(e,cashfree.ErrNotFound){
		// Expire only a provider-confirmed absent, old uncreated intent. A known
		// provider order or a timeout remains pending for reconciliation.
		if absent,ok:=w.store.(interface{OrderAbsent(context.Context,string,time.Time)(bool,error)});ok{
			if w.ready(ctx)!=nil{return ErrUnavailable};expired,recordErr:=absent.OrderAbsent(ctx,ref,w.now().UTC());if recordErr!=nil{return recordErr};if expired{return nil}
		}
	}
	if e!=nil{return e};if e=CheckProviderOrder(s,p,w.provider.Environment(),w.provider.MerchantID());e!=nil{return e}
	if w.ready(ctx)!=nil{return ErrUnavailable}
	_,e=w.store.AttachCheckout(ctx,ref,ProviderOrder{Ref:ref,ProviderOrderID:string(p.ProviderID),CheckoutSession:p.Session,Status:p.Status,MerchantID:s.MerchantID,Environment:s.Order.Environment,AmountPaise:int64(p.Amount),Currency:p.Currency},w.now().UTC());if e!=nil{return e}
	payments,e:=w.provider.Payments(ctx,ref);if e!=nil{return e};refunds,e:=w.provider.Refunds(ctx,ref);if e!=nil{return e}
	if w.ready(ctx)!=nil{return ErrUnavailable}
	withheld,e:=checkSnapshot(s,payments,refunds,w.now().UTC());if e!=nil{return e}
	for _,pmt:=range payments{if e=w.applyPayment(ctx,s,p,pmt,withheld[pmt.ID]);e!=nil{return e}}
	for _,r:=range refunds{status,e:=refundStatus(r.Status);if e!=nil{return e};if w.ready(ctx)!=nil{return ErrUnavailable};result,e:=w.store.ImportProviderRefund(ctx,RefundResolution{RefundRef:r.ID,ProviderRefundID:string(r.ProviderID),Status:status,PaymentID:string(r.PaymentID),OrderRef:ref,Environment:s.Order.Environment,AmountPaise:int64(r.Amount)},w.now().UTC());if e!=nil{return e};w.changed(ctx,result)}
	return nil
}
// CheckProviderOrder binds the immutable purchase to the exact merchant and
// environment, including our opaque per-purchase customer ID (not a phone).
func CheckProviderOrder(s StoredOrder,p cashfree.Order,environment,merchant string)error{
	if s.Order.Environment!=Environment(environment)||s.MerchantID!=merchant||p.ID!=s.Order.Ref||p.Customer.ID!=s.Order.Ref||p.ProviderID==""||(s.ProviderOrderID!=""&&s.ProviderOrderID!=string(p.ProviderID))||int64(p.Amount)!=s.Order.Plan.AmountPaise||p.Currency!=s.Order.Plan.Currency||p.Currency!="INR"{return ErrReview}
	switch p.Status{case "ACTIVE","PAID","EXPIRED","TERMINATED","TERMINATION_REQUESTED":return nil;default:return ErrReview}
}
func checkPayment(s StoredOrder,p cashfree.Payment,now time.Time)(time.Time,error){
	if p.OrderID!=s.Order.Ref||p.ID==""||p.Currency!="INR"||p.OrderCurrency!="INR"||int64(p.Amount)!=s.Order.Plan.AmountPaise||int64(p.OrderAmount)!=s.Order.Plan.AmountPaise{return time.Time{},ErrReview}
	switch p.Status{case "SUCCESS","NOT_ATTEMPTED","FAILED","USER_DROPPED","VOID","CANCELLED","PENDING":default:return time.Time{},ErrReview}
	var paid time.Time;if p.Status=="SUCCESS"{if !p.Captured{return paid,ErrReview};var e error;paid,e=time.Parse(time.RFC3339Nano,p.CompletedAt);if e!=nil||paid.Before(s.Order.CreatedAt.Add(-5*time.Minute))||paid.After(now.Add(5*time.Minute)){return time.Time{},ErrReview}}
	return paid,nil
}
// Validate the complete fetched snapshot before applying any financial state.
// A provider response cannot attach another order's refund or use a duplicate
// row to inflate reservations. Pending and completed refunds both reserve money.
func checkSnapshot(s StoredOrder,payments []cashfree.Payment,refunds []cashfree.Refund,now time.Time)(map[cashfree.Identifier]bool,error){
	withheld:=map[cashfree.Identifier]bool{};captures:=map[cashfree.Identifier]cashfree.Payment{}
	if len(payments)>256||len(refunds)>256{return nil,ErrReview}
	for _,p:=range payments{if _,duplicate:=captures[p.ID];duplicate{return nil,ErrReview};if _,e:=checkPayment(s,p,now);e!=nil{return nil,e};captures[p.ID]=p}
	seen:=map[cashfree.Identifier]bool{};reserved:=map[cashfree.Identifier]int64{}
	for _,r:=range refunds{
		p,known:=captures[r.PaymentID];auto:=r.Type=="PAYMENT_AUTO_REFUND"||r.Type=="UNRECONCILED_AUTO_REFUND"
		if !known||p.Status!="SUCCESS"||!p.Captured||r.OrderID!=s.Order.Ref||r.Currency!="INR"||r.ProviderID==""||seen[r.ProviderID]||(r.ID==""&&!auto)||r.Amount<=0||r.Amount>p.Amount{return nil,ErrReview};seen[r.ProviderID]=true
		status,e:=refundStatus(r.Status);if e!=nil{return nil,e};if status=="pending"||status=="processed"{amount:=int64(r.Amount);if amount>s.Order.Plan.AmountPaise-reserved[r.PaymentID]{return nil,ErrReview};reserved[r.PaymentID]+=amount;if reserved[r.PaymentID]>=s.Order.Plan.AmountPaise{withheld[r.PaymentID]=true}}
	}
	return withheld,nil
}
func(w *Worker)applyPayment(ctx context.Context,s StoredOrder,o cashfree.Order,p cashfree.Payment,withhold bool)error{
	paid,e:=checkPayment(s,p,w.now().UTC());if e!=nil{return e}
	if w.ready(ctx)!=nil{return ErrUnavailable};r,e:=w.store.ApplyCapture(ctx,VerifiedCapture{OrderRef:s.Order.Ref,ProviderOrderID:string(o.ProviderID),PaymentID:string(p.ID),MerchantID:s.MerchantID,Status:p.Status,Environment:s.Order.Environment,AmountPaise:int64(p.Amount),Currency:p.Currency,PaidAt:paid,WithholdGrant:withhold},w.now().UTC());if e==nil{w.changed(ctx,r)};return e
}
func(w *Worker)ProcessRefund(ctx context.Context,ref string)error{
	if w.ready(ctx)!=nil{return ErrUnavailable}
	r,e:=w.store.PendingRefund(ctx,ref);if e!=nil{return e};if r.Status=="processed"||r.Status=="failed"||r.Status=="cancelled"{return nil};s,e:=w.store.StoredOrder(ctx,r.OrderRef);if e!=nil{return e};if s.MerchantID!=w.provider.MerchantID()||s.Order.Environment!=Environment(w.provider.Environment()){return ErrReview}
	// Always fetch the stable refund reference first, including after any timeout
	// or lease loss. No new reference is invented for an unknown outcome.
	var pr cashfree.Refund
	if r.ProviderRefundID!=""{
		// Imported dashboard refunds have a local reference distinct from the
		// merchant's original refund_id. Resolve by immutable cf_refund_id and
		// never turn a missing known refund into a second disbursement.
		all,lookupErr:=w.provider.Refunds(ctx,r.OrderRef);if lookupErr!=nil{return lookupErr};found:=false;for _,candidate:=range all{if string(candidate.ProviderID)==r.ProviderRefundID{if found{return ErrReview};pr=candidate;found=true}};if !found{return ErrUnavailable}
	}else{pr,e=w.provider.GetRefund(ctx,r.OrderRef,r.Ref)}
	if errors.Is(e,cashfree.ErrNotFound){
		if s.Order.PaidAt==nil||w.now().Sub(*s.Order.PaidAt)>=180*24*time.Hour{return ErrReview}
		// Cashfree's standard refund API targets an order, not a selectable
		// payment attempt. Never guess which instrument a duplicate capture used.
		o,fetchErr:=w.provider.GetOrder(ctx,r.OrderRef);if fetchErr!=nil{return fetchErr};if fetchErr=CheckProviderOrder(s,o,w.provider.Environment(),w.provider.MerchantID());fetchErr!=nil{return fetchErr}
		payments,fetchErr:=w.provider.Payments(ctx,r.OrderRef);if fetchErr!=nil{return fetchErr};successes:=0
		for _,p:=range payments{if p.Status!="SUCCESS"{continue};successes++;if string(p.ID)!=r.PaymentID||p.OrderID!=r.OrderRef||p.Currency!="INR"||p.OrderCurrency!="INR"||!p.Captured||int64(p.Amount)!=s.Order.Plan.AmountPaise||int64(p.OrderAmount)!=s.Order.Plan.AmountPaise||r.AmountPaise>int64(p.Amount){return ErrReview}}
		if successes!=1{return ErrReview};if w.ready(ctx)!=nil{return ErrUnavailable};pr,e=w.provider.CreateRefund(ctx,r.OrderRef,r.Ref,r.AmountPaise)
	}
	if e!=nil{return e};if pr.OrderID!=r.OrderRef||(r.ProviderRefundID==""&&pr.ID!=r.Ref)||(r.ProviderRefundID!=""&&string(pr.ProviderID)!=r.ProviderRefundID)||string(pr.PaymentID)!=r.PaymentID||int64(pr.Amount)!=r.AmountPaise||pr.Currency!="INR"||pr.ProviderID==""{return ErrReview};status,e:=refundStatus(pr.Status);if e!=nil{return e}
	if w.ready(ctx)!=nil{return ErrUnavailable};result,e:=w.store.ResolveRefund(ctx,RefundResolution{RefundRef:r.Ref,ProviderRefundID:string(pr.ProviderID),Status:status,PaymentID:r.PaymentID,OrderRef:r.OrderRef,Environment:s.Order.Environment,AmountPaise:r.AmountPaise},w.now().UTC());if e==nil{w.changed(ctx,result)};return e
}
func refundStatus(status string)(string,error){switch status{case "SUCCESS":return "processed",nil;case "FAILED","REJECTED","CANCELLED":return "failed",nil;case "PENDING","PENDING_APPROVAL","ONHOLD","ACTIVE":return "pending",nil;default:return "",ErrReview}}
// NonCaptureObservation identifies only documented payment attempts that do
// not establish collected money. PG reports may omit fees and net amounts for
// these states; the stored observation still schedules authoritative verification.
// Settlement rows and unknown statuses never qualify for this exception.
func NonCaptureObservation(r Reconciliation)bool{
	if r.Kind!="daily_pg:PAYMENT"{return false}
	switch r.ProviderStatus{case "PENDING","FAILED","CANCELLED","USER_DROPPED","VOID","NOT_ATTEMPTED":return true;default:return false}
}
func(w *Worker)reconcilePage(ctx context.Context,j Job)(string,error){
	page,e:=w.provider.Reconciliation(ctx,j.Kind=="daily_settlement",j.PeriodStart,j.PeriodEnd,j.Cursor);if e!=nil{return "",e};if page.Cursor!=""&&page.Cursor==j.Cursor{return "",ErrReview}
	for _,v:=range page.Data{r:=Reconciliation{Ref:string(v.Event.ID),Kind:j.Kind+":"+v.Event.Type,OrderRef:v.Order.ID,PaymentID:string(v.Payment.ID),State:"observed",ProviderStatus:v.Event.Status,Currency:v.Event.Currency,MoneyComplete:v.Event.Amount!=nil&&v.Event.Fee!=nil&&v.Event.Tax!=nil&&v.Event.Net!=nil,PeriodStart:j.PeriodStart,PeriodEnd:j.PeriodEnd};if v.Event.Amount!=nil{r.AmountPaise=int64(*v.Event.Amount)};if v.Event.Fee!=nil{r.FeePaise=int64(*v.Event.Fee)};if v.Event.Tax!=nil{r.TaxPaise=int64(*v.Event.Tax)};if v.Event.Net!=nil{r.NetPaise=int64(*v.Event.Net)}
		if r.Currency!="INR"||(!NonCaptureObservation(r)&&!r.MoneyComplete){r.State="review"};if strings.Contains(v.Event.Type,"REFUND")||strings.Contains(v.Event.Type,"DISPUTE"){r.State="review"};if e=w.store.RecordReconciliation(ctx,r,w.now().UTC());e!=nil{return "",e}}
	return page.Cursor,nil
}
