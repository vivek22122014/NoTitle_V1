// Package billing owns the durable, integer-paise purchase ledger. Only DTOs
// cross public boundaries; provider confirmations are trusted server inputs.
package billing

import (
 "context"
 "errors"
 "time"
 "notitle/internal/identity"
)

var (
 ErrInvalid=errors.New("invalid billing request")
 ErrUnavailable=errors.New("billing temporarily unavailable")
 ErrUnauthorized=identity.ErrUnauthorized
 ErrNotFound=errors.New("purchase not found")
 ErrConflict=errors.New("billing request conflicts with existing state")
 ErrDisabled=errors.New("checkout is not enabled")
 ErrReview=errors.New("financial review required")
)
type Environment string
const(Test Environment="sandbox"; Live Environment="production")
type Plan struct {
 ID string `json:"id"`; Version int64 `json:"version"`; Name string `json:"name"`
 AmountPaise int64 `json:"amount_paise"`; Currency string `json:"currency"`; DurationSeconds int64 `json:"duration_seconds"`
 TaxTreatment string `json:"tax_treatment"`; TaxPaise int64 `json:"tax_paise"`; Enabled bool `json:"enabled"`
}
type CreateOrderInput struct { PlanID string `json:"plan_id"`; PlanVersion int64 `json:"plan_version"`; IdempotencyKey string `json:"idempotency_key"` }
type Order struct {
 Ref string `json:"purchase_ref"`; Status string `json:"status"`; Plan Plan `json:"plan"`
 CreatedAt time.Time `json:"created_at"`; PaidAt *time.Time `json:"paid_at,omitempty"`
 CheckoutSession string `json:"payment_session_id,omitempty"`; Environment Environment `json:"environment"`
}
// StoredOrder is private working state. Never serialize it or provider inputs.
type StoredOrder struct { Order Order; AccountID,MerchantID,ProviderOrderID string }
func(StoredOrder)MarshalJSON()([]byte,error){return nil,errors.New("private billing record")}
type ProviderOrder struct { Ref,ProviderOrderID,CheckoutSession,MerchantID,Status string; Environment Environment; AmountPaise int64; Currency string }
type VerifiedCapture struct { OrderRef,ProviderOrderID,PaymentID,MerchantID,Status string; Environment Environment; AmountPaise int64; Currency string; PaidAt time.Time; WithholdGrant bool }
type GrantResult struct { OrderRef,AccountID,Outcome string; Entitlement Entitlement }
type Entitlement struct { Active bool `json:"active"`; ExpiresAt *time.Time `json:"expires_at,omitempty"`; RemainingSeconds int64 `json:"remaining_seconds"`; Revision int64 `json:"revision"`; LotID string `json:"-"`; UsageUntil *time.Time `json:"-"`; PaidControlsUsed bool `json:"-"` }
type Receipt struct { PurchaseRef string `json:"purchase_ref"`; Plan Plan `json:"plan"`; PaidAt time.Time `json:"paid_at"`; Status string `json:"status"`; RefundedPaise int64 `json:"refunded_paise"`; CapturedPaise int64 `json:"captured_paise"` }
type RefundRequest struct { OrderRef,PaymentID,IdempotencyKey,ActorID,Reason,Treatment string; AmountPaise,ReduceSeconds int64; ExpectedRevision,AdminGeneration int64; AdminSessionHash [32]byte }
type Refund struct { Ref string `json:"refund_ref"`; OrderRef string `json:"purchase_ref"`; PaymentID string `json:"-"`; ProviderRefundID string `json:"-"`; AmountPaise int64 `json:"amount_paise"`; Treatment string `json:"treatment"`; HoldSeconds int64 `json:"held_seconds"`; Status string `json:"status"`; CreatedAt time.Time `json:"created_at"`; ProcessedAt *time.Time `json:"processed_at,omitempty"` }
type RefundResolution struct { RefundRef,ProviderRefundID,Status,PaymentID,OrderRef string; Environment Environment; AmountPaise int64 }
type RefundPreview struct { OrderRef string `json:"purchase_ref"`; PaymentID string `json:"payment_id"`; CapturedPaise int64 `json:"captured_paise"`; RefundablePaise int64 `json:"refundable_paise"`; AvailableSeconds int64 `json:"available_seconds"`; UsedPaidControls bool `json:"used_paid_controls"`; Within24Hours bool `json:"within_24_hours"`; Revision int64 `json:"revision"` }
type DisputeInput struct { ProviderDisputeID,OrderRef,PaymentID,ActorID,Reason,Status,IdempotencyKey string; ResponseDue time.Time; HoldAccess bool; AdminGeneration,ExpectedRevision int64; AdminSessionHash [32]byte }
type ReviewCase struct { Ref string `json:"reference"`; Kind string `json:"kind"`; OrderRef string `json:"purchase_ref"`; State string `json:"state"`; CreatedAt time.Time `json:"created_at"` }
// WebhookEvent is a signature-verified minimal projection. No customer contact,
// raw payload, credentials, card or bank data enters this durable inbox.
type WebhookEvent struct { EventKey,Kind,OrderRef,PaymentID,RefundID,ProviderDisputeID,MerchantID,DisputeStatus string; Environment Environment; ReceivedAt,ResponseDue time.Time }
type Job struct { ID int64; Kind,OrderRef,RefundRef,EventKey,LeaseOwner,Cursor string; Attempts int; Environment Environment; PeriodStart,PeriodEnd time.Time }
type JobResult struct { ID int64; LeaseOwner string; Success bool; RetryAt time.Time; ReviewKind,Cursor string; Continue bool }
type Reconciliation struct { Ref,Kind,OrderRef,PaymentID,RefundID,State,ProviderStatus,Currency string; MoneyComplete bool; AmountPaise,FeePaise,TaxPaise,NetPaise int64; PeriodStart,PeriodEnd time.Time }
type Repository interface {
 Catalog(context.Context)([]Plan,error)
 CreateIntent(context.Context,identity.Guard,CreateOrderInput,time.Time)(Order,error)
 AttachCheckout(context.Context,string,ProviderOrder,time.Time)(Order,error)
 StoredOrder(context.Context,string)(StoredOrder,error)
 ApplyCapture(context.Context,VerifiedCapture,time.Time)(GrantResult,error)
 EnqueueWebhook(context.Context,WebhookEvent,time.Time)error
 ClaimJobs(context.Context,string,int,time.Time)([]Job,error)
 FinishJob(context.Context,JobResult,time.Time)error
 ScheduleReconciliation(context.Context,time.Time)error
 PendingRefund(context.Context,string)(Refund,error)
 ResolveRefund(context.Context,RefundResolution,time.Time)(GrantResult,error)
 RecordReconciliation(context.Context,Reconciliation,time.Time)error
 ImportProviderRefund(context.Context,RefundResolution,time.Time)(GrantResult,error)
}
