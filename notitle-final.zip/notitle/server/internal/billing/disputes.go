package billing

import (
 "context"
 "errors"
 "time"
 "github.com/jackc/pgx/v5"
)

func(s *PostgresStore)RecordDispute(ctx context.Context,in DisputeInput,now time.Time)error{
 if !providerReference.MatchString(in.ProviderDisputeID)||!validReference.MatchString(in.IdempotencyKey)||!validReference.MatchString(in.OrderRef)||!providerReference.MatchString(in.PaymentID)||in.ExpectedRevision<0||in.ResponseDue.IsZero()||!adminReason(in.Reason)||(in.Status!="open"&&in.Status!="won"&&in.Status!="lost"&&in.Status!="review"){return ErrInvalid}
 stored,err:=s.StoredOrder(ctx,in.OrderRef);if err!=nil{return err}
 return s.mutate(ctx,stored.AccountID,now,func()error{_,err:=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){
  if err:=adminGuard(ctx,tx,in.ActorID,in.AdminGeneration,in.AdminSessionHash,now);err!=nil{return false,err}
  var b Balance;if stored.AccountID!=""{if _,_,err:=lockAccount(ctx,tx,stored.AccountID);err!=nil{return false,err};var err error;b,err=s.checkpoint(ctx,tx,stored.AccountID,now);if err!=nil{return false,err}}
  if _,err:=scanOrder(tx.QueryRow(ctx,`SELECT `+orderColumns+` FROM notitle.purchase_orders WHERE ref=$1 AND environment=$2 FOR UPDATE`,in.OrderRef,s.options.Environment));err!=nil{return false,err}
  var old DisputeInput;err:=tx.QueryRow(ctx,`SELECT provider_dispute_id,order_ref,payment_id,expected_revision,status,hold_access,response_due,reason FROM notitle.billing_dispute_actions WHERE actor_id=$1 AND idempotency_key=$2`,in.ActorID,in.IdempotencyKey).Scan(&old.ProviderDisputeID,&old.OrderRef,&old.PaymentID,&old.ExpectedRevision,&old.Status,&old.HoldAccess,&old.ResponseDue,&old.Reason)
  if err==nil{if old.ProviderDisputeID!=in.ProviderDisputeID||old.OrderRef!=in.OrderRef||old.PaymentID!=in.PaymentID||old.ExpectedRevision!=in.ExpectedRevision||old.Status!=in.Status||old.HoldAccess!=in.HoldAccess||!old.ResponseDue.Equal(in.ResponseDue)||old.Reason!=in.Reason{return false,ErrConflict};return true,nil};if !errors.Is(err,pgx.ErrNoRows){return false,ErrUnavailable}
  if _,_,_,err=refundBalance(ctx,tx,s.options.Environment,in.OrderRef,in.PaymentID);err!=nil{return false,err}
  var revision,held int64;var state,order,payment string;err=tx.QueryRow(ctx,`SELECT revision,held_seconds,state,order_ref,payment_id FROM notitle.disputes WHERE environment=$1 AND provider_dispute_id=$2 FOR UPDATE`,s.options.Environment,in.ProviderDisputeID).Scan(&revision,&held,&state,&order,&payment);if err!=nil&&!errors.Is(err,pgx.ErrNoRows){return false,ErrUnavailable};if revision!=in.ExpectedRevision||(revision>0&&(order!=in.OrderRef||payment!=in.PaymentID)){return false,ErrConflict};if (state=="won"||state=="lost")&&state!=in.Status{return false,ErrConflict}
  lot:=-1;for i:=range b.Lots{if b.Lots[i].OrderRef==in.OrderRef&&b.Lots[i].PaymentID==in.PaymentID{lot=i;break}}
  if in.Status=="lost"&&lot>=0&&b.Lots[lot].Held>held{return false,ErrReview}
  if held>0{if lot<0||b.Lots[lot].Held<held{return false,ErrConflict};if in.Status=="won"||in.Status=="lost"||!in.HoldAccess{b.Revision++;b.Lots[lot].Held-=held;kind:="restore";if in.Status=="lost"{b.Lots[lot].Revoked+=held;kind="revoke"}else{b.Lots[lot].Remaining+=held};if err=s.event(ctx,tx,stored.AccountID,b.Lots[lot].Ref,kind,held,b.Revision,in.ProviderDisputeID,now);err!=nil{return false,err};held=0}}
  if held==0&&in.HoldAccess&&(in.Status=="open"||in.Status=="review")&&lot>=0{if b.Lots[lot].Held>0{return false,ErrConflict};held=b.Lots[lot].Remaining;b.Lots[lot].Remaining=0;b.Lots[lot].Held+=held;b.Revision++;if err=s.event(ctx,tx,stored.AccountID,b.Lots[lot].Ref,"hold",held,b.Revision,in.ProviderDisputeID,now);err!=nil{return false,err}}
  // A lost case may arrive without an earlier hold. Revoke only that capture's
  // remaining lot, never a later independent purchase or the account itself.
  if in.Status=="lost"&&lot>=0&&b.Lots[lot].Remaining>0{seconds:=b.Lots[lot].Remaining;b.Lots[lot].Remaining=0;b.Lots[lot].Revoked+=seconds;b.Revision++;if err=s.event(ctx,tx,stored.AccountID,b.Lots[lot].Ref,"revoke",seconds,b.Revision,in.ProviderDisputeID,now);err!=nil{return false,err}}
  if stored.AccountID!=""{if err=s.saveBalance(ctx,tx,stored.AccountID,b);err!=nil{return false,err}}
  _,err=tx.Exec(ctx,`INSERT INTO notitle.disputes(environment,provider_dispute_id,order_ref,payment_id,state,response_due,held_seconds,reason,created_at,updated_at,revision) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$9,1) ON CONFLICT(environment,provider_dispute_id) DO UPDATE SET state=EXCLUDED.state,response_due=EXCLUDED.response_due,held_seconds=EXCLUDED.held_seconds,reason=EXCLUDED.reason,updated_at=EXCLUDED.updated_at,revision=notitle.disputes.revision+1`,s.options.Environment,in.ProviderDisputeID,in.OrderRef,in.PaymentID,in.Status,in.ResponseDue,held,in.Reason,now);if err!=nil{return false,ErrUnavailable}
  _,err=tx.Exec(ctx,`INSERT INTO notitle.billing_dispute_actions(actor_id,idempotency_key,provider_dispute_id,order_ref,payment_id,expected_revision,status,hold_access,response_due,reason,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,in.ActorID,in.IdempotencyKey,in.ProviderDisputeID,in.OrderRef,in.PaymentID,in.ExpectedRevision,in.Status,in.HoldAccess,in.ResponseDue,in.Reason,now);if err!=nil{return false,ErrUnavailable};return true,audit(ctx,tx,in.ActorID,"billing_dispute_action",in.ProviderDisputeID,in.Reason,now)
 });return err})
}
