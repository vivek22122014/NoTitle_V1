package payments

import (
 "context"
 "errors"
 "testing"
 "time"
 "notitle/internal/billing"
 "notitle/internal/cashfree"
 "notitle/internal/identity"
)

// These fakes model only the application boundary. Ledger atomicity and
// authorization under row locks have separate real-PostgreSQL regressions.
type checkoutStore struct {
 Store
 order billing.Order
 plans []billing.Plan
 exists,revoked bool
 creates,attaches,reads,entitlements int
 entitlement billing.Entitlement
}
func(f *checkoutStore)Catalog(context.Context)([]billing.Plan,error){return f.plans,nil}
func(f *checkoutStore)FindIntent(context.Context,identity.Guard,string,time.Time)(billing.Order,error){if !f.exists{return billing.Order{},billing.ErrNotFound};return f.order,nil}
func(f *checkoutStore)CreateIntent(_ context.Context,_ identity.Guard,in billing.CreateOrderInput,_ time.Time)(billing.Order,error){if in.PlanID!=f.order.Plan.ID||in.PlanVersion!=f.order.Plan.Version{return billing.Order{},billing.ErrInvalid};f.exists=true;f.creates++;return f.order,nil}
func(f *checkoutStore)GetOrder(context.Context,identity.Guard,string,time.Time)(billing.Order,error){f.reads++;if f.revoked{return billing.Order{},billing.ErrUnauthorized};return f.order,nil}
func(f *checkoutStore)AttachCheckout(_ context.Context,_ string,in billing.ProviderOrder,_ time.Time)(billing.Order,error){f.attaches++;f.order.Status="checkout_ready";f.order.CheckoutSession=in.CheckoutSession;return f.order,nil}
func(f *checkoutStore)Entitlement(context.Context,identity.Guard,time.Time)(billing.Entitlement,error){f.entitlements++;return f.entitlement,nil}
func(f *checkoutStore)Orders(context.Context,identity.Guard,time.Time)([]billing.Order,error){return []billing.Order{f.order},nil}
type checkoutProvider struct{get func(context.Context,string)(cashfree.Order,error);create func(context.Context,cashfree.CreateOrder)(cashfree.Order,error);gets,creates int}
func(*checkoutProvider)Environment()string{return "sandbox"}
func(*checkoutProvider)MerchantID()string{return "merchant-test"}
func(f *checkoutProvider)GetOrder(c context.Context,r string)(cashfree.Order,error){f.gets++;return f.get(c,r)}
func(f *checkoutProvider)CreateOrder(c context.Context,in cashfree.CreateOrder)(cashfree.Order,error){f.creates++;return f.create(c,in)}
type checkoutVerifier struct{calls int;err error}
func(f *checkoutVerifier)VerifyOrder(context.Context,string)error{f.calls++;return f.err}
func checkoutFixture(t *testing.T)(*Service,*checkoutStore,*checkoutProvider,*checkoutVerifier,identity.Principal,CreateInput){
 t.Helper();now:=time.Date(2026,10,9,12,0,0,0,time.UTC)
 plan:=billing.Plan{ID:"three-day",Version:1,Name:"3 days",AmountPaise:9900,Currency:"INR",DurationSeconds:72*3600,Enabled:true,TaxTreatment:"inclusive",TaxPaise:1510}
 store:=&checkoutStore{order:billing.Order{Ref:"purchase_reference_123",Status:"intent",Plan:plan,CreatedAt:now,Environment:billing.Test},plans:[]billing.Plan{plan}}
 provider:=&checkoutProvider{};verifier:=&checkoutVerifier{}
 service,err:=New(Options{Store:store,Provider:provider,Verifier:verifier,Ready:func(context.Context)error{return nil},Now:func()time.Time{return now},CheckoutEnabled:true,Environment:billing.Test,MerchantID:"merchant-test"});if err!=nil{t.Fatal(err)}
 principal:=identity.Principal{Kind:identity.KindAccount,AccountSession:identity.AccountSession{Account:identity.Account{ID:"account",Generation:1},Session:identity.SessionRecord{ID:"session"}}}
 return service,store,provider,verifier,principal,CreateInput{PlanID:plan.ID,PlanVersion:1,IdempotencyKey:"idempotency_key_123",Phone:"9876543210"}
}
func remoteOrder(store *checkoutStore)cashfree.Order{var out cashfree.Order;out.ID=store.order.Ref;out.ProviderID=cashfree.Identifier("provider-order-123");out.Amount=cashfree.Amount(store.order.Plan.AmountPaise);out.Currency="INR";out.Status="ACTIVE";out.Session="payment-session-for-test";out.Customer.ID=store.order.Ref;return out}

func TestUnknownCheckoutOutcomeReusesCommittedIntentAndProviderReference(t *testing.T){
 service,store,provider,_,p,in:=checkoutFixture(t)
 provider.get=func(context.Context,string)(cashfree.Order,error){if provider.gets==1{return cashfree.Order{},cashfree.ErrNotFound};return remoteOrder(store),nil}
 provider.create=func(_ context.Context,request cashfree.CreateOrder)(cashfree.Order,error){if !store.exists||store.creates!=1{t.Fatal("provider called before durable intent")};if request.Ref!=store.order.Ref||request.CustomerID!=request.Ref||request.AmountPaise!=9900||request.Currency!="INR"{t.Fatal("provider economics or reference changed")};return cashfree.Order{},context.DeadlineExceeded}
 first,err:=service.Create(context.Background(),p,in);if err!=nil||first.Status!="intent"||first.CheckoutSession!=""{t.Fatalf("unknown response: %+v %v",first,err)}
 in.Phone="" // A browser retry does not need to retain personal contact data.
 second,err:=service.Create(context.Background(),p,in);if err!=nil||second.Status!="checkout_ready"||second.Ref!=first.Ref{t.Fatalf("retry: %+v %v",second,err)}
 if store.creates!=1||provider.creates!=1||store.attaches!=1{t.Fatal("ambiguous create was repeated instead of fetched")}
}
func TestCheckoutCannotChangePlanUsingExistingIdempotencyKey(t *testing.T){service,store,provider,_,p,in:=checkoutFixture(t);store.exists=true;in.PlanVersion++;_,err:=service.Create(context.Background(),p,in);if !errors.Is(err,billing.ErrConflict)||provider.gets!=0||provider.creates!=0{t.Fatal("reused key changed the purchase")}}
func TestRemoteOrderMismatchNeverPublishesCheckoutSession(t *testing.T){
 for _,field:=range []string{"amount","customer","currency","reference","provider-id"}{t.Run(field,func(t *testing.T){service,store,provider,verify,p,in:=checkoutFixture(t);store.exists=true;remote:=remoteOrder(store);switch field{case"amount":remote.Amount++;case"customer":remote.Customer.ID="someone-else";case"currency":remote.Currency="USD";case"reference":remote.ID="another-purchase";case"provider-id":remote.ProviderID=""};provider.get=func(context.Context,string)(cashfree.Order,error){return remote,nil};_,err:=service.Create(context.Background(),p,in);if !errors.Is(err,billing.ErrReview)||store.attaches!=0||verify.calls!=0{t.Fatal("untrusted order accepted")}})}
}
func TestRevokedSessionAfterProviderIOCannotReceiveCheckoutSecret(t *testing.T){service,store,provider,_,p,in:=checkoutFixture(t);store.exists=true;provider.get=func(context.Context,string)(cashfree.Order,error){store.revoked=true;return remoteOrder(store),nil};out,err:=service.Create(context.Background(),p,in);if !errors.Is(err,billing.ErrUnauthorized)||out.CheckoutSession!=""{t.Fatal("post-I/O session check bypassed")}}
func TestVerificationRequiresOwnedOrderAndDoesNotTrustProviderFailure(t *testing.T){service,store,_,verify,p,_:=checkoutFixture(t);store.revoked=true;if _,err:=service.Verify(context.Background(),p,store.order.Ref);!errors.Is(err,billing.ErrUnauthorized)||verify.calls!=0{t.Fatal("unowned order reached provider")};store.revoked=false;verify.err=context.DeadlineExceeded;out,err:=service.Verify(context.Background(),p,store.order.Ref);if err!=nil||out.Status!="intent"||verify.calls!=1{t.Fatal("verification timeout invented a payment outcome")}}
func TestDisabledCheckoutPreservesLedgerReadsAndHidesPaymentSession(t *testing.T){service,store,provider,_,p,in:=checkoutFixture(t);service.options.CheckoutEnabled=false;store.order.Status="checkout_ready";store.order.CheckoutSession="private";expiry:=service.options.Now().Add(time.Hour);store.entitlement=billing.Entitlement{Active:true,ExpiresAt:&expiry,RemainingSeconds:3600,Revision:4};if _,err:=service.Create(context.Background(),p,in);!errors.Is(err,billing.ErrDisabled)||provider.gets!=0{t.Fatal("disabled checkout called provider")};orders,err:=service.Orders(context.Background(),p);if err!=nil||len(orders)!=1||orders[0].CheckoutSession!=""{t.Fatal("read did not redact disabled checkout session")};current,err:=service.Current(context.Background(),p);if err!=nil||!current.Active||current.Version!=4{t.Fatal("checkout disable discarded existing Premium")}}
func TestProviderSaturationReturnsDurableOrderWithoutExternalWork(t *testing.T){service,store,provider,_,p,in:=checkoutFixture(t);store.exists=true;for i:=0;i<cap(service.slots);i++{service.slots<-struct{}{}};out,err:=service.Create(context.Background(),p,in);if err!=nil||out.Ref!=store.order.Ref||provider.gets!=0||provider.creates!=0{t.Fatal("saturated provider path was not bounded")}}
func TestGuestCannotPurchaseOrAcquirePremium(t *testing.T){service,store,provider,_,_,in:=checkoutFixture(t);guest:=identity.Principal{Kind:identity.KindGuest};if _,err:=service.Create(context.Background(),guest,in);!errors.Is(err,billing.ErrUnauthorized){t.Fatal("guest purchase allowed")};out,err:=service.Entitlement(context.Background(),guest);if err!=nil||out.Premium||store.entitlements!=0||provider.gets!=0{t.Fatal("guest obtained ledger privileges")}}
func TestCatalogOmitsUnapprovedAnnualAndDisabledVersions(t *testing.T){service,store,_,_,_,_:=checkoutFixture(t);annual:=store.plans[0];annual.ID="annual";disabled:=store.plans[0];disabled.ID="retired";disabled.Enabled=false;store.plans=append(store.plans,annual,disabled);out,err:=service.Plans(context.Background());if err!=nil||len(out.Plans)!=1||out.Plans[0].ID!="three-day"||out.Version==""{t.Fatal("unapproved catalog leaked")};service.options.Ready=func(context.Context)error{return errors.New("not ready")};if _,err=service.Plans(context.Background());!errors.Is(err,billing.ErrUnavailable){t.Fatal("catalog ignored readiness")}}

func TestMaintenanceClosesCheckoutButPreservesOwnedVerificationAndPremium(t *testing.T){
 service,store,provider,verify,p,in:=checkoutFixture(t);service.options.AdmissionClosed=func()bool{return true}
 store.order.Status="checkout_ready";store.order.CheckoutSession="private-checkout-session";store.entitlement=billing.Entitlement{Active:true,RemainingSeconds:3600,Revision:3}
 if _,err:=service.Create(context.Background(),p,in);!errors.Is(err,billing.ErrDisabled)||provider.gets!=0{t.Fatal("new purchase entered maintenance")}
 if _,err:=service.Resume(context.Background(),p,ResumeInput{PurchaseRef:store.order.Ref});!errors.Is(err,billing.ErrDisabled){t.Fatal("checkout resume bypassed maintenance")}
 plans,err:=service.Plans(context.Background());if err!=nil||plans.CheckoutEnabled{t.Fatal("catalog advertised maintenance checkout")}
 order,err:=service.Verify(context.Background(),p,store.order.Ref);if err!=nil||verify.calls!=1||order.CheckoutSession!=""{t.Fatal("committed payment verification stopped or checkout secret leaked")}
 current,err:=service.Current(context.Background(),p);if err!=nil||!current.Active{t.Fatal("drain discarded paid entitlement")}
}
