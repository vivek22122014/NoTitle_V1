package payments
import("errors";"io";"os";"strings")
func ReadSecretFile(path string)(string,error){
 invalid:=errors.New("payment credential file unavailable")
 info,err:=os.Lstat(path);if err!=nil||!info.Mode().IsRegular()||info.Mode().Perm()&0077!=0{return "",invalid}
 f,err:=os.Open(path);if err!=nil{return "",invalid};defer f.Close();actual,err:=f.Stat();if err!=nil||!os.SameFile(info,actual)||!actual.Mode().IsRegular()||actual.Mode().Perm()&0077!=0{return "",invalid}
 raw,err:=io.ReadAll(io.LimitReader(f,1025));if err!=nil||len(raw)>1024{return "",invalid};value:=strings.TrimSpace(string(raw));clear(raw);if value==""||strings.ContainsAny(value,"\r\n\x00"){return "",invalid};return value,nil
}
