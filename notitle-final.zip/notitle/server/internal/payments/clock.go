package payments

import (
 "context"
 "errors"
 "sync"
 "time"
)

// ClockGuard detects process-local wall-clock steps relative to elapsed
// monotonic time. It cannot establish NTP accuracy or cross-host clock offset.
// A detected step latches readiness closed until an operator corrects time and
// restarts. UTC payment duration must never silently run backward or jump.
type ClockGuard struct{mu sync.Mutex;failed bool;last time.Time}
func NewClockGuard()*ClockGuard{return &ClockGuard{last:time.Now()}}
func(g *ClockGuard) observe(wall,elapsed time.Duration){g.mu.Lock();defer g.mu.Unlock();delta:=wall-elapsed;if delta>2*time.Second||delta< -2*time.Second{g.failed=true}}
func(g *ClockGuard) Run(ctx context.Context){ticker:=time.NewTicker(time.Second);defer ticker.Stop();for{select{case<-ctx.Done():return;case<-ticker.C:now:=time.Now();g.observe(now.UTC().Sub(g.last.UTC()),now.Sub(g.last));g.last=now}}}
func(g *ClockGuard)Ready(context.Context)error{g.mu.Lock();defer g.mu.Unlock();if g.failed{return errors.New("clock health requires operator review")};return nil}
