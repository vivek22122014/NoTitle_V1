package payments

import(
 "context"
 "errors"
 "io"
 "mime"
 "net/http"
 "time"
 "notitle/internal/billing"
 "notitle/internal/cashfree"
 "notitle/internal/httpserver/apierror"
 "notitle/internal/httpserver/middleware"
)
// Webhooks deliberately do not use browser sessions/CSRF or identity readiness.
// Signature verification and a durable inbox commit precede acknowledgement.
func Webhook(store billing.Repository,verifier *cashfree.WebhookVerifier,ready func(context.Context)error)http.Handler{
 slots:=make(chan struct{},8)
 return http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){
  fail:=func(err apierror.Error){apierror.Write(w,middleware.RequestIDFromContext(r.Context()),err)}
  w.Header().Set("Cache-Control","no-store")
  if r.Method!=http.MethodPost{w.Header().Set("Allow","POST");fail(apierror.MethodNotAllowed);return}
  if r.URL.RawQuery!=""||r.URL.ForceQuery||r.URL.EscapedPath()!=r.URL.Path{fail(apierror.Invalid);return}
  if store==nil||verifier==nil{fail(apierror.CheckoutUnavailable);return}
  select{case slots<-struct{}{}:defer func(){<-slots}();default:fail(apierror.Unavailable);return}
  media,_,err:=mime.ParseMediaType(r.Header.Get("Content-Type"));if err!=nil||media!="application/json"{fail(apierror.UnsupportedMedia);return}
  r.Body=http.MaxBytesReader(w,r.Body,cashfree.MaxWebhookBytes);raw,err:=io.ReadAll(r.Body);if err!=nil{var tooLarge *http.MaxBytesError;if errors.As(err,&tooLarge){fail(apierror.TooLarge)}else{fail(apierror.Invalid)};return};defer clear(raw)
  ctx,cancel:=context.WithTimeout(r.Context(),5*time.Second);defer cancel()
  if ready==nil||ready(ctx)!=nil{fail(apierror.Unavailable);return}
  if err=billing.IngestWebhook(ctx,store,verifier,r.Header,raw,time.Now().UTC());err!=nil{if errors.Is(err,cashfree.ErrSignature){fail(apierror.Forbidden)}else if errors.Is(err,cashfree.ErrInvalid){fail(apierror.Invalid)}else{fail(apierror.Unavailable)};return}
  // Cashfree's retry contract requires HTTP 200. A generic successful 2xx
  // acknowledgement such as 204 can leave a committed event being retried.
  w.WriteHeader(http.StatusOK)
 })
}
