// Package payments joins authenticated HTTP workflows to the durable ledger.
// Provider calls run outside transactions and outside the live coordinator.
package payments

import (
 "context"
 "crypto/sha256"
 "encoding/hex"
 "encoding/json"
 "errors"
 "time"
 "notitle/internal/billing"
 "notitle/internal/cashfree"
 "notitle/internal/identity"
 "notitle/internal/realtime"
)
type Store interface {
 Catalog(context.Context)([]billing.Plan,error)
 FindIntent(context.Context,identity.Guard,string,time.Time)(billing.Order,error)
 CreateIntent(context.Context,identity.Guard,billing.CreateOrderInput,time.Time)(billing.Order,error)
 GetOrder(context.Context,identity.Guard,string,time.Time)(billing.Order,error)
 AttachCheckout(context.Context,string,billing.ProviderOrder,time.Time)(billing.Order,error)
 Orders(context.Context,identity.Guard,time.Time)([]billing.Order,error)
 Receipts(context.Context,identity.Guard,time.Time)([]billing.Receipt,error)
 Receipt(context.Context,identity.Guard,string,time.Time)(billing.Receipt,error)
 Refunds(context.Context,identity.Guard,string,time.Time)([]billing.Refund,error)
 Entitlement(context.Context,identity.Guard,time.Time)(billing.Entitlement,error)
 MarkPaidUse(context.Context,identity.Guard,int64,string,time.Time)(billing.Entitlement,error)
}
type Provider interface {
 Environment()string;MerchantID()string
 GetOrder(context.Context,string)(cashfree.Order,error)
 CreateOrder(context.Context,cashfree.CreateOrder)(cashfree.Order,error)
}
type Verifier interface{VerifyOrder(context.Context,string)error}
type Options struct {Store Store;Provider Provider;Verifier Verifier;Ready func(context.Context)error;AdmissionClosed func()bool;Now func()time.Time;CheckoutEnabled,AnnualApproved bool;Environment billing.Environment;MerchantID string}
type Service struct{options Options;slots chan struct{}}
type Catalog struct{Plans []billing.Plan `json:"plans"`;CheckoutEnabled bool `json:"checkout_enabled"`;Environment billing.Environment `json:"environment"`;Version string `json:"catalog_version"`;PhoneRequired bool `json:"phone_required"`}
type Premium struct{Active bool `json:"premium_active"`;ExpiresAt *time.Time `json:"expires_at,omitempty"`;RemainingSeconds int64 `json:"remaining_seconds"`;Version int64 `json:"version"`}
type CreateInput struct{PlanID string `json:"plan_id"`;PlanVersion int64 `json:"plan_version"`;IdempotencyKey string `json:"idempotency_key"`;Phone string `json:"customer_phone"`}
type ResumeInput struct{PurchaseRef string `json:"purchase_ref"`;Phone string `json:"customer_phone"`}
func New(o Options)(*Service,error){if o.Store==nil||o.Ready==nil||(o.Environment!=billing.Test&&o.Environment!=billing.Live)||o.MerchantID==""{return nil,billing.ErrInvalid};if o.CheckoutEnabled&&(o.Provider==nil||o.Verifier==nil){return nil,billing.ErrInvalid};if o.Provider!=nil&&(o.Provider.Environment()!=string(o.Environment)||o.Provider.MerchantID()!=o.MerchantID){return nil,billing.ErrInvalid};if o.Now==nil{o.Now=time.Now};return &Service{options:o,slots:make(chan struct{},4)},nil}
func(s *Service)ready(ctx context.Context)error{if s.options.Ready(ctx)!=nil{return billing.ErrUnavailable};return nil}
func(s *Service)checkoutEnabled()bool{return s.options.CheckoutEnabled&&(s.options.AdmissionClosed==nil||!s.options.AdmissionClosed())}
func(s *Service)guard(ctx context.Context,p identity.Principal)(identity.Guard,error){if err:=s.ready(ctx);err!=nil{return identity.Guard{},err};if p.Kind!=identity.KindAccount{return identity.Guard{},billing.ErrUnauthorized};return p.Guard(s.options.Now().UTC(),false),nil}
func(s *Service)Plans(ctx context.Context)(Catalog,error){out:=Catalog{Plans:[]billing.Plan{},Environment:s.options.Environment,PhoneRequired:true,CheckoutEnabled:s.checkoutEnabled()&&s.options.Provider!=nil};if err:=s.ready(ctx);err!=nil{return out,err};plans,err:=s.options.Store.Catalog(ctx);if err!=nil{return out,err};for _,p:=range plans{if !p.Enabled||p.ID=="annual"&&!s.options.AnnualApproved{continue};out.Plans=append(out.Plans,p)};raw,_:=json.Marshal(out.Plans);hash:=sha256.Sum256(raw);out.Version=hex.EncodeToString(hash[:]);return out,nil}
func(s *Service)Current(ctx context.Context,p identity.Principal)(Premium,error){g,e:=s.guard(ctx,p);if e!=nil{return Premium{},e};v,e:=s.options.Store.Entitlement(ctx,g,s.options.Now().UTC());return Premium{v.Active,v.ExpiresAt,v.RemainingSeconds,v.Revision},e}
func(s *Service)Order(ctx context.Context,p identity.Principal,ref string)(billing.Order,error){g,e:=s.guard(ctx,p);if e!=nil{return billing.Order{},e};o,e:=s.options.Store.GetOrder(ctx,g,ref,s.options.Now().UTC());return s.presentOrder(o),e}
func(s *Service)Orders(ctx context.Context,p identity.Principal)([]billing.Order,error){g,e:=s.guard(ctx,p);if e!=nil{return nil,e};rows,e:=s.options.Store.Orders(ctx,g,s.options.Now().UTC());for i:=range rows{rows[i]=s.presentOrder(rows[i])};return rows,e}
func(s *Service)Receipts(ctx context.Context,p identity.Principal)([]billing.Receipt,error){g,e:=s.guard(ctx,p);if e!=nil{return nil,e};return s.options.Store.Receipts(ctx,g,s.options.Now().UTC())}
func(s *Service)Receipt(ctx context.Context,p identity.Principal,ref string)(billing.Receipt,error){g,e:=s.guard(ctx,p);if e!=nil{return billing.Receipt{},e};return s.options.Store.Receipt(ctx,g,ref,s.options.Now().UTC())}
func(s *Service)Refunds(ctx context.Context,p identity.Principal,ref string)([]billing.Refund,error){g,e:=s.guard(ctx,p);if e!=nil{return nil,e};return s.options.Store.Refunds(ctx,g,ref,s.options.Now().UTC())}
func(s *Service)presentOrder(o billing.Order)billing.Order{if !s.checkoutEnabled()||o.Status!="checkout_ready"||o.Environment!=s.options.Environment{o.CheckoutSession=""};return o}
func(s *Service)Create(ctx context.Context,p identity.Principal,in CreateInput)(billing.Order,error){
 g,err:=s.guard(ctx,p);if err!=nil{return billing.Order{},err};if !s.checkoutEnabled(){return billing.Order{},billing.ErrDisabled};if in.PlanID=="annual"&&!s.options.AnnualApproved{return billing.Order{},billing.ErrDisabled}
 existing,err:=s.options.Store.FindIntent(ctx,g,in.IdempotencyKey,s.options.Now().UTC())
 if err==nil{if existing.Plan.ID!=in.PlanID||existing.Plan.Version!=in.PlanVersion{return billing.Order{},billing.ErrConflict};return s.checkout(ctx,p,existing,in.Phone)}
 if !errors.Is(err,billing.ErrNotFound){return billing.Order{},err};if !cashfree.ValidPhone(in.Phone){return billing.Order{},billing.ErrInvalid}
 order,err:=s.options.Store.CreateIntent(ctx,g,billing.CreateOrderInput{PlanID:in.PlanID,PlanVersion:in.PlanVersion,IdempotencyKey:in.IdempotencyKey},s.options.Now().UTC());if err!=nil{return billing.Order{},err};return s.checkout(ctx,p,order,in.Phone)
}
func(s *Service)Resume(ctx context.Context,p identity.Principal,in ResumeInput)(billing.Order,error){g,err:=s.guard(ctx,p);if err!=nil{return billing.Order{},err};if !s.checkoutEnabled(){return billing.Order{},billing.ErrDisabled};o,err:=s.options.Store.GetOrder(ctx,g,in.PurchaseRef,s.options.Now().UTC());if err!=nil{return billing.Order{},err};if o.Plan.ID=="annual"&&!s.options.AnnualApproved{return billing.Order{},billing.ErrDisabled};return s.checkout(ctx,p,o,in.Phone)}
func(s *Service)checkout(ctx context.Context,p identity.Principal,o billing.Order,phone string)(billing.Order,error){
 if !s.checkoutEnabled(){return billing.Order{},billing.ErrDisabled}
 if o.Status!="intent"&&o.Status!="processing"&&o.Status!="checkout_ready"{return s.Order(ctx,p,o.Ref)}
 if phone!=""&&!cashfree.ValidPhone(phone){return billing.Order{},billing.ErrInvalid}
 select{case s.slots<-struct{}{}:defer func(){<-s.slots}();default:return s.Order(ctx,p,o.Ref)}
 work,cancel:=context.WithTimeout(ctx,10*time.Second);defer cancel()
 remote,err:=s.options.Provider.GetOrder(work,o.Ref)
 if errors.Is(err,cashfree.ErrNotFound)&&phone!=""&&s.checkoutEnabled(){remote,err=s.options.Provider.CreateOrder(work,cashfree.CreateOrder{Ref:o.Ref,CustomerID:o.Ref,Phone:phone,AmountPaise:o.Plan.AmountPaise,Currency:o.Plan.Currency})}
 // An unknown outcome is represented by the existing durable order. Retrying
 // that reference or the worker's reconciliation cannot create another intent.
 if err!=nil{return s.Order(ctx,p,o.Ref)}
 // The guarded public DTO deliberately excludes the stored provider ID. The
 // attach transaction also validates that immutable association under lock.
 if billing.CheckProviderOrder(billing.StoredOrder{Order:o,MerchantID:s.options.MerchantID},remote,s.options.Provider.Environment(),s.options.Provider.MerchantID())!=nil{return billing.Order{},billing.ErrReview}
 _,err=s.options.Store.AttachCheckout(work,o.Ref,billing.ProviderOrder{Ref:o.Ref,ProviderOrderID:string(remote.ProviderID),CheckoutSession:remote.Session,Status:remote.Status,MerchantID:s.options.MerchantID,Environment:s.options.Environment,AmountPaise:int64(remote.Amount),Currency:remote.Currency},s.options.Now().UTC());if err!=nil{return billing.Order{},err}
 if remote.Status=="PAID"&&s.options.Verifier!=nil{_ =s.options.Verifier.VerifyOrder(work,o.Ref)}
 // Session/generation/ownership are checked again after all external work.
 return s.Order(ctx,p,o.Ref)
}
func(s *Service)Verify(ctx context.Context,p identity.Principal,ref string)(billing.Order,error){g,err:=s.guard(ctx,p);if err!=nil{return billing.Order{},err};if _,err=s.options.Store.GetOrder(ctx,g,ref,s.options.Now().UTC());err!=nil{return billing.Order{},err};if s.options.Verifier!=nil{select{case s.slots<-struct{}{}:defer func(){<-s.slots}();work,cancel:=context.WithTimeout(ctx,10*time.Second);defer cancel();_ =s.options.Verifier.VerifyOrder(work,ref);default:}};return s.Order(ctx,p,ref)}
func projection(v billing.Entitlement)realtime.Entitlement{out:=realtime.Entitlement{Premium:v.Active,Version:v.Revision,UsageLotID:v.LotID,PaidControlsUsed:v.PaidControlsUsed};if out.Version<1{out.Version=1};if v.ExpiresAt!=nil{out.ExpiresAt=*v.ExpiresAt};if v.UsageUntil!=nil{out.UsageUntil=*v.UsageUntil};return out}
func(s *Service)Entitlement(ctx context.Context,p identity.Principal)(realtime.Entitlement,error){if p.Kind==identity.KindGuest{return realtime.Entitlement{Version:1},nil};g,err:=s.guard(ctx,p);if err!=nil{return realtime.Entitlement{},err};v,err:=s.options.Store.Entitlement(ctx,g,s.options.Now().UTC());return projection(v),err}
func(s *Service)MarkPaidUse(ctx context.Context,g identity.Guard,revision int64,lot string,now time.Time)(realtime.Entitlement,error){if err:=s.ready(ctx);err!=nil{return realtime.Entitlement{},err};v,err:=s.options.Store.MarkPaidUse(ctx,g,revision,lot,now);if errors.Is(err,billing.ErrConflict){fresh,readErr:=s.options.Store.Entitlement(ctx,g,s.options.Now().UTC());if readErr!=nil{return realtime.Entitlement{},realtime.ErrUnavailable};return projection(fresh),realtime.ErrUnavailable};if err!=nil{return realtime.Entitlement{},err};return projection(v),nil}
type PremiumOwner interface{BeginPremiumMutation(context.Context,string)(string,error);FinishPremiumMutation(context.Context,string,string,realtime.Entitlement)error}
type Fence struct{Owner PremiumOwner}
func(f Fence)Begin(ctx context.Context,account string)(string,error){return f.Owner.BeginPremiumMutation(ctx,account)}
func(f Fence)Finish(ctx context.Context,account,token string,v billing.Entitlement)error{return f.Owner.FinishPremiumMutation(ctx,account,token,projection(v))}

// Failed post-commit publication stays closed until an authoritative retry.
// Recovery continues when new checkout admission or the provider is disabled.
func(s *Service)Run(ctx context.Context){ticker:=time.NewTicker(time.Second);defer ticker.Stop();for{select{case<-ctx.Done():return;case<-ticker.C:if s.ready(ctx)!=nil{continue};if recovery,ok:=s.options.Store.(interface{RecoverMutationFences(context.Context,time.Time)error});ok{work,cancel:=context.WithTimeout(ctx,3*time.Second);_ =recovery.RecoverMutationFences(work,s.options.Now().UTC());cancel()}}}}
