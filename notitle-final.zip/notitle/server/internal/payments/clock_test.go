package payments
import("context";"testing";"time")
func TestClockStepLatchesReadinessUntilRestart(t *testing.T){for _,step:=range []time.Duration{-3*time.Second,3*time.Second}{g:=NewClockGuard();g.observe(time.Second,time.Second);if g.Ready(context.Background())!=nil{t.Fatal("stable clock rejected")};g.observe(time.Second+step,time.Second);if g.Ready(context.Background())==nil{t.Fatal("large wall clock step accepted")};g.observe(time.Second,time.Second);if g.Ready(context.Background())==nil{t.Fatal("unsafe clock silently recovered")}}}
