package payments

import (
    "context"
    "crypto/hmac"
    "crypto/sha256"
    "encoding/base64"
    "encoding/json"
    "errors"
    "net/http"
    "net/http/httptest"
    "strconv"
    "strings"
    "sync"
    "testing"
    "time"

    "notitle/internal/billing"
    "notitle/internal/cashfree"
)

// Only ingestion is implemented: an accidental capture/grant/provider call in
// the webhook HTTP path reaches an unimplemented method and fails the test.
type webhookRepository struct {
    billing.Repository
    mu sync.Mutex
    calls int
    events map[string]billing.WebhookEvent
    err error
    beforeCommit func()
}
func(s *webhookRepository)EnqueueWebhook(_ context.Context,event billing.WebhookEvent,_ time.Time)error{
    s.mu.Lock();defer s.mu.Unlock();s.calls++
    if s.beforeCommit!=nil{s.beforeCommit()};if s.err!=nil{return s.err}
    if s.events==nil{s.events=map[string]billing.WebhookEvent{}}
    s.events[event.EventKey]=event;return nil
}
func(s *webhookRepository)snapshot()(int,[]billing.WebhookEvent){s.mu.Lock();defer s.mu.Unlock();events:=[]billing.WebhookEvent{};for _,v:=range s.events{events=append(events,v)};return s.calls,events}
var httpWebhookBody=[]byte(`{"type":"PAYMENT_SUCCESS_WEBHOOK","data":{"order":{"order_id":"purchase_fixture_ref"},"payment":{"cf_payment_id":9007199254740991999},"customer_details":{"customer_phone":"private-contact-canary","customer_email":"private-contact-canary@example.invalid"}}}`)
func webhookVerifier(t *testing.T)*cashfree.WebhookVerifier{
    t.Helper();v,err:=cashfree.NewWebhookVerifier(cashfree.WebhookOptions{Environment:"sandbox",MerchantID:"merchant_fixture",Secret:strings.Repeat("k",32),Now:func()time.Time{return time.Unix(1800000000,0)}});if err!=nil{t.Fatal(err)};return v
}
func webhookRequest(raw []byte)*http.Request{
    r:=httptest.NewRequest(http.MethodPost,"/api/v1/webhooks/cashfree",strings.NewReader(string(raw)));r.Header.Set("Content-Type","application/json")
    ts:=strconv.FormatInt(1800000000000,10);mac:=hmac.New(sha256.New,[]byte(strings.Repeat("k",32)));_,_=mac.Write([]byte(ts));_,_=mac.Write(raw)
    r.Header.Set("x-webhook-timestamp",ts);r.Header.Set("x-webhook-signature",base64.StdEncoding.EncodeToString(mac.Sum(nil)));return r
}
func webhookReady(context.Context)error{return nil}

// httptest.NewRecorder starts with Code 200 even before a response is written.
// Track actual writes so the durability assertion still detects an early 200.
type webhookWriteRecorder struct {
    *httptest.ResponseRecorder
    wrote bool
}
func(w *webhookWriteRecorder)WriteHeader(status int){w.wrote=true;w.ResponseRecorder.WriteHeader(status)}
func(w *webhookWriteRecorder)Write(body []byte)(int,error){w.wrote=true;return w.ResponseRecorder.Write(body)}

func TestWebhookHTTPCommitsBeforeAcknowledgementWithoutBrowserCredentials(t *testing.T){
    store:=&webhookRepository{};w:=&webhookWriteRecorder{ResponseRecorder:httptest.NewRecorder()};store.beforeCommit=func(){if w.wrote||w.Body.Len()!=0{t.Fatal("webhook acknowledged before durable commit")}}
    h:=Webhook(store,webhookVerifier(t),webhookReady);r:=webhookRequest(httpWebhookBody)
    // Gateway requests have no NoTitle account cookie, Origin or browser CSRF.
    h.ServeHTTP(w,r);calls,events:=store.snapshot();if !w.wrote||w.Code!=http.StatusOK||w.Body.Len()!=0||calls!=1||len(events)!=1{t.Fatal("durable webhook acknowledgement failed")}
    event:=events[0];if event.PaymentID!="9007199254740991999"||event.OrderRef!="purchase_fixture_ref"||event.Environment!=billing.Test||event.MerchantID!="merchant_fixture"||event.ReceivedAt.IsZero(){t.Fatal("verified financial projection changed")}
    encoded,err:=json.Marshal(event);if err!=nil||strings.Contains(string(encoded),"private-contact-canary"){t.Fatal("payment-only contact entered durable webhook projection")}
    if w.Header().Get("Cache-Control")!="no-store"{t.Fatal("webhook response cacheable")}
}
func TestWebhookHTTPDurableFailureReturnsRetryableStatus(t *testing.T){
    store:=&webhookRepository{err:errors.New("private-database-connection-canary")};h:=Webhook(store,webhookVerifier(t),webhookReady)
    w:=httptest.NewRecorder();h.ServeHTTP(w,webhookRequest(httpWebhookBody));calls,events:=store.snapshot();if w.Code!=503||calls!=1||len(events)!=0||strings.Contains(w.Body.String(),"private-database"){t.Fatal("uncommitted event acknowledged or internal failure disclosed")}
    store.err=nil;w=httptest.NewRecorder();h.ServeHTTP(w,webhookRequest(httpWebhookBody));calls,events=store.snapshot();if w.Code!=http.StatusOK||calls!=2||len(events)!=1{t.Fatal("retry could not durably ingest the same event")}
}
func TestWebhookHTTPRawSignatureHeadersAndTimestampFailBeforeStorage(t *testing.T){
    for _,mode:=range []string{"raw_whitespace","body_change","missing_signature","duplicate_signature","duplicate_timestamp","changed_timestamp"}{
        store:=&webhookRepository{};h:=Webhook(store,webhookVerifier(t),webhookReady);r:=webhookRequest(httpWebhookBody)
        switch mode{case "raw_whitespace":r.Body=http.NoBody;changed:=append(append([]byte{},httpWebhookBody...),byte(' '));r=httptest.NewRequest(http.MethodPost,"/api/v1/webhooks/cashfree",strings.NewReader(string(changed)));signed:=webhookRequest(httpWebhookBody);r.Header=signed.Header.Clone();case "body_change":r=httptest.NewRequest(http.MethodPost,"/api/v1/webhooks/cashfree",strings.NewReader(strings.Replace(string(httpWebhookBody),"purchase_fixture_ref","purchase_different_ref",1)));r.Header=webhookRequest(httpWebhookBody).Header.Clone();case "missing_signature":r.Header.Del("x-webhook-signature");case "duplicate_signature":r.Header.Add("x-webhook-signature",r.Header.Get("x-webhook-signature"));case "duplicate_timestamp":r.Header.Add("x-webhook-timestamp",r.Header.Get("x-webhook-timestamp"));case "changed_timestamp":r.Header.Set("x-webhook-timestamp","1800000000001")}
        w:=httptest.NewRecorder();h.ServeHTTP(w,r);calls,_:=store.snapshot();if w.Code!=403||calls!=0{t.Fatal("signature rejection occurred after storage",mode,w.Code)}
    }
}
func TestWebhookHTTPBoundsAndStrictParsingBeforeInbox(t *testing.T){
    for _,tc:=range []struct{body []byte;code int}{{[]byte(strings.Repeat("x",cashfree.MaxWebhookBytes+1)),413},{[]byte(`{"type":"FIRST","type":"SECOND"}`),400},{[]byte(`{"type":"PAYMENT_SUCCESS_WEBHOOK","data":{}}`),400},{[]byte(`{"type":"PAYMENT_SUCCESS_WEBHOOK"} {}`),400}}{
        store:=&webhookRepository{};h:=Webhook(store,webhookVerifier(t),webhookReady);w:=httptest.NewRecorder();h.ServeHTTP(w,webhookRequest(tc.body));calls,_:=store.snapshot();if w.Code!=tc.code||calls!=0{t.Fatal("invalid or oversized webhook reached inbox",w.Code)}
    }
}
func TestWebhookHTTPDisabledStartupAndMethodGates(t *testing.T){
    for _,mode:=range []string{"nil_store","nil_verifier","nil_ready","not_ready","wrong_method","query","media"}{
        store:=&webhookRepository{};var repository billing.Repository=store;verifier:=webhookVerifier(t);ready:=webhookReady;r:=webhookRequest(httpWebhookBody);want:=503
        switch mode{case "nil_store":repository=nil;case "nil_verifier":verifier=nil;case "nil_ready":ready=nil;case "not_ready":ready=func(context.Context)error{return errors.New("private startup barrier")};case "wrong_method":r.Method=http.MethodGet;want=405;case "query":r.URL.RawQuery="token=forged";want=400;case "media":r.Header.Set("Content-Type","text/plain");want=415}
        w:=httptest.NewRecorder();Webhook(repository,verifier,ready).ServeHTTP(w,r);calls,_:=store.snapshot();if w.Code!=want||calls!=0||strings.Contains(w.Body.String(),"private startup"){t.Fatal("webhook boundary failed",mode,w.Code)}
    }
}
func TestWebhookHTTPRedeliveryKeepsStableInboxIdentity(t *testing.T){
    store:=&webhookRepository{};h:=Webhook(store,webhookVerifier(t),webhookReady)
    for i:=0;i<2;i++{w:=httptest.NewRecorder();h.ServeHTTP(w,webhookRequest(httpWebhookBody));if w.Code!=http.StatusOK{t.Fatal("verified repeat not acknowledged")}}
    calls,events:=store.snapshot();if calls!=2||len(events)!=1||events[0].EventKey==""{t.Fatal("HTTP redelivery changed durable dedupe identity")}
}
func TestWebhookHTTPConcurrentAdmissionIsBounded(t *testing.T){
    store:=&webhookRepository{};entered:=make(chan struct{},8);release:=make(chan struct{});var once sync.Once;var wg sync.WaitGroup
    defer func(){once.Do(func(){close(release)});wg.Wait()}()
    ready:=func(ctx context.Context)error{entered<-struct{}{};select{case<-release:return nil;case<-ctx.Done():return ctx.Err()}}
    h:=Webhook(store,webhookVerifier(t),ready)
    for i:=0;i<8;i++{wg.Add(1);go func(){defer wg.Done();w:=httptest.NewRecorder();h.ServeHTTP(w,webhookRequest(httpWebhookBody))}()}
    for i:=0;i<8;i++{select{case<-entered:case<-time.After(2*time.Second):t.Fatal("webhook admission fixture timed out")}}
    w:=httptest.NewRecorder();h.ServeHTTP(w,webhookRequest(httpWebhookBody));calls,_:=store.snapshot();if w.Code!=503||calls!=0{t.Fatal("overload admitted a ninth webhook or acknowledged blocked work")}
    once.Do(func(){close(release)});wg.Wait();calls,events:=store.snapshot();if calls!=8||len(events)!=1{t.Fatal("bounded admitted requests failed to ingest")}
}
