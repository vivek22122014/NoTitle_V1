package payments

import (
 "os"
 "path/filepath"
 "strings"
 "testing"
)
func TestPaymentCredentialsRequireProtectedRegularBoundedFiles(t *testing.T){
 directory:=t.TempDir();path:=filepath.Join(directory,"client-secret")
 if err:=os.WriteFile(path,[]byte("  test-secret-value\n"),0600);err!=nil{t.Fatal(err)}
 if value,err:=ReadSecretFile(path);err!=nil||value!="test-secret-value"{t.Fatal("protected file refused")}
 link:=filepath.Join(directory,"link");if err:=os.Symlink(path,link);err!=nil{t.Fatal(err)};if _,err:=ReadSecretFile(link);err==nil{t.Fatal("credential symlink accepted")}
 if err:=os.Chmod(path,0644);err!=nil{t.Fatal(err)};if _,err:=ReadSecretFile(path);err==nil{t.Fatal("world-readable credential accepted")}
 if err:=os.Chmod(path,0600);err!=nil{t.Fatal(err)}
 for _,bad:=range []string{"", "first\nsecond", "first\x00second",strings.Repeat("x",1025)}{if err:=os.WriteFile(path,[]byte(bad),0600);err!=nil{t.Fatal(err)};if _,err:=ReadSecretFile(path);err==nil{t.Fatal("invalid credential accepted")}}
 if _,err:=ReadSecretFile(directory);err==nil{t.Fatal("directory accepted")}
}
