// Package matchingauth assembles fresh server-only matchmaking authority outside
// the coordinator. It never accepts tier, safety or account IDs from a client.
package matchingauth

import (
    "context"
    "errors"
    "time"

    "notitle/internal/identity"
    "notitle/internal/friendtypes"
    "notitle/internal/realtime"
)

const AuthorizationTTL = 30 * time.Second

type Identity interface { RefreshPrincipal(context.Context,identity.Principal,bool)(identity.Principal,error) }
type Owner interface {
    AuthFence(context.Context)(uint64,error)
    GetGuestPreferences(context.Context,string,identity.Verifier,time.Time)(realtime.Preferences,error)
    UpdateGuestPreferences(context.Context,string,identity.Verifier,realtime.Preferences,time.Time)(realtime.Preferences,error)
    PreferencesChanged(context.Context,string,int64,realtime.Preferences,time.Time) error
    InvalidateAccount(context.Context,string,time.Time) error
    HealthOutage(context.Context,bool) error
}
// EntitlementSource is implemented by trusted payment-ledger reads. Free is the
// explicit disabled-checkout fallback, never a browser-selected payment tier.
type EntitlementSource interface { Entitlement(context.Context,identity.Principal)(realtime.Entitlement,error) }
type FreeEntitlements struct{}
func (FreeEntitlements) Entitlement(context.Context,identity.Principal)(realtime.Entitlement,error){ return realtime.Entitlement{Version:1},nil }

type SafetySnapshot struct { Version int64; Restricted bool; BlockedIdentities []string }
type SafetySource interface { Safety(context.Context,identity.Principal)(SafetySnapshot,error) }
type FriendsSource interface { Friends(context.Context,identity.Principal)(friendtypes.Snapshot,error) }
// NoModerationYet is an explicit Phase 4 boundary, not a durable block store.
// Account status/session checks are active. Public access stays disabled until
// Phase 5 provides persistent restrictions, reporting and operator coverage.
type NoModerationYet struct{}
func (NoModerationYet) Safety(context.Context,identity.Principal)(SafetySnapshot,error){ return SafetySnapshot{Version:1},nil }

type Options struct {
    TextEnabled bool
    FriendsEnabled bool
    AudioEnabled bool
    Friends FriendsSource
    Clock realtime.Clock
    Identity Identity
    Store PreferenceRepository
    Actor Owner
    Entitlements EntitlementSource
    Safety SafetySource
    Ready func(context.Context) error
}
type Service struct { options Options }
func New(options Options)(*Service,error){
    if options.Clock==nil || options.Identity==nil || options.Store==nil || options.Actor==nil || options.Ready==nil { return nil,errors.New("matching authorization requires trusted dependencies and readiness") }
    if options.Entitlements==nil { options.Entitlements=FreeEntitlements{} }
    if options.Safety==nil { options.Safety=NoModerationYet{} }
    if options.FriendsEnabled && options.Friends==nil { return nil,errors.New("enabled friendships require a trusted relationship source") }
    if options.AudioEnabled && !options.TextEnabled { return nil,errors.New("enabled audio requires text and safety controls") }
    return &Service{options:options},nil
}
var _ realtime.Authorizer = (*Service)(nil)
var _ realtime.PreferenceStore = (*Service)(nil)

func (s *Service) refresh(ctx context.Context,previous identity.Principal,touch bool)(identity.Principal,error){
    if err:=s.options.Ready(ctx);err!=nil { return identity.Principal{},realtime.ErrUnavailable }
    p,err:=s.options.Identity.RefreshPrincipal(ctx,previous,touch)
    if err!=nil { return identity.Principal{},safeError(err) }
    return p,nil
}
func (s *Service) preferences(ctx context.Context,p identity.Principal,now time.Time)(realtime.Preferences,error){
    if p.Kind==identity.KindGuest { return s.options.Actor.GetGuestPreferences(ctx,p.Guest.ID,p.TokenHash,now) }
    if p.Kind!=identity.KindAccount { return realtime.Preferences{},identity.ErrUnauthorized }
    return s.options.Store.Read(ctx,p.Guard(now,false))
}
func (s *Service) Authorize(ctx context.Context,previous identity.Principal)(realtime.AuthSnapshot,error){
    // A revocation/profile/preference event during any external reads changes
    // this fence. Actor.Attach/Refresh then refuses to publish the stale result.
    fence,err:=s.options.Actor.AuthFence(ctx)
    if err!=nil { return realtime.AuthSnapshot{},realtime.ErrUnavailable }
    started:=s.options.Clock.Now().UTC()
    p,err:=s.refresh(ctx,previous,true)
    if err!=nil { return realtime.AuthSnapshot{},err }
    prefs,err:=s.preferences(ctx,p,started)
    if err!=nil { return realtime.AuthSnapshot{},safeError(err) }
    entitlement,err:=s.options.Entitlements.Entitlement(ctx,p)
    if err!=nil || !validEntitlement(entitlement) { return realtime.AuthSnapshot{},realtime.ErrUnavailable }
    safety,err:=s.options.Safety.Safety(ctx,p)
    if errors.Is(err,identity.ErrBusy) { return realtime.AuthSnapshot{},identity.ErrBusy }
    if err!=nil || safety.Version<1 || len(safety.BlockedIdentities)>realtime.MaxBlockedIdentities { return realtime.AuthSnapshot{},realtime.ErrUnavailable }
    var friends friendtypes.Snapshot
    if s.options.FriendsEnabled {
        friends,err=s.options.Friends.Friends(ctx,p)
        if err!=nil { return realtime.AuthSnapshot{},safeError(err) }
        if len(friends.Relations)>friendtypes.MaxFriendsPerIdentity || (p.Kind==identity.KindAccount && friends.Revision<1) { return realtime.AuthSnapshot{},realtime.ErrUnavailable }
    }
    auth:=realtime.AuthSnapshot{Fence:fence,Kind:p.Kind,SessionVerifier:p.TokenHash,TextEnabled:s.options.TextEnabled,FriendsEnabled:s.options.FriendsEnabled,AudioEnabled:s.options.AudioEnabled,FriendRevision:friends.Revision,FriendLinks:append([]friendtypes.Relation(nil),friends.Relations...),
        Preferences:realtime.ClonePreferences(prefs),Entitlement:entitlement,SafetyVersion:safety.Version,
        Restricted:safety.Restricted,BlockedIdentities:append([]string(nil),safety.BlockedIdentities...),
        AuthorizedAt:started,ValidUntil:started.Add(AuthorizationTTL)}
    switch p.Kind {
    case identity.KindGuest:
        auth.IdentityID=p.Guest.ID; auth.SessionID=p.Guest.ID; auth.IdentityGeneration=p.Guest.Generation; auth.Profile=p.Guest.Profile
        auth.ValidUntil=earliest(auth.ValidUntil,p.Guest.AbsoluteExpiresAt,p.Guest.LastSeenAt.Add(identity.GuestIdleTTL))
        // Guests cannot acquire paid authorization even from a miswired source.
        auth.Entitlement=realtime.Entitlement{Version:1}
    case identity.KindAccount:
        auth.IdentityID=p.AccountSession.Account.ID; auth.SessionID=p.AccountSession.Session.ID
        auth.IdentityGeneration=p.AccountSession.Account.Generation; auth.Profile=p.AccountSession.Account.Profile
        auth.ValidUntil=earliest(auth.ValidUntil,p.AccountSession.Session.AbsoluteExpiresAt,p.AccountSession.Session.LastSeenAt.Add(identity.SessionIdleTTL))
    default: return realtime.AuthSnapshot{},realtime.ErrUnauthorized
    }
    auth.Profile.Professional.Interests=append([]string(nil),auth.Profile.Professional.Interests...)
    if !s.options.Clock.Now().Before(auth.ValidUntil) { return realtime.AuthSnapshot{},realtime.ErrUnauthorized }
    // Reject structurally invalid trusted state rather than inferring gender.
    if err:=identity.ValidateProfile(auth.Profile);err!=nil { return realtime.AuthSnapshot{},realtime.ErrGenderRequired }
    if err:=realtime.ValidatePreferences(auth.Preferences);err!=nil { return realtime.AuthSnapshot{},realtime.ErrUnavailable }
    if auth.Entitlement.Version<1 { return realtime.AuthSnapshot{},realtime.ErrUnavailable }
    return auth,nil
}
func validEntitlement(e realtime.Entitlement)bool { return e.Version>=1 && (!e.Premium || !e.ExpiresAt.IsZero()) }
func earliest(first time.Time,others ...time.Time)time.Time { for _,other:=range others { if other.Before(first) { first=other } }; return first }
func safeError(err error)error {
    // A guest handoff freezes its verifier briefly. Preserve this typed,
    // content-free sentinel so the transport retries within its existing
    // authorization lease instead of falsely treating it as a lost session.
    // HTTP/socket presentation still maps it to bounded retry/rate-limit errors.
    if errors.Is(err,identity.ErrBusy){ return identity.ErrBusy }
    if errors.Is(err,identity.ErrUnauthorized)||errors.Is(err,identity.ErrStale){ return realtime.ErrUnauthorized }
    if errors.Is(err,identity.ErrInvalid){ return identity.ErrInvalid }
    var public *realtime.Error
    if errors.As(err,&public) { return public }
    return realtime.ErrUnavailable
}
func (s *Service) GetPreferences(ctx context.Context,previous identity.Principal)(realtime.PreferenceView,error){
    p,err:=s.refresh(ctx,previous,false);if err!=nil{return realtime.PreferenceView{},err}
    now:=s.options.Clock.Now().UTC()
    prefs,err:=s.preferences(ctx,p,now);if err!=nil{return realtime.PreferenceView{},safeError(err)}
    entitlement,err:=s.options.Entitlements.Entitlement(ctx,p);if err!=nil||!validEntitlement(entitlement){return realtime.PreferenceView{},realtime.ErrUnavailable}
    return preferenceView(prefs,entitlement,p.Kind,now),nil
}
func preferenceView(p realtime.Preferences,e realtime.Entitlement,kind identity.Kind,now time.Time)realtime.PreferenceView{
    active:=kind==identity.KindAccount && e.Active(now)
    view:=realtime.PreferenceView{Preferences:realtime.ClonePreferences(p),PremiumActive:active,RequiresEveryoneConfirmation:p.Gender!=realtime.Everyone&&!active}
    if e.Premium && !e.ExpiresAt.IsZero() { expiry:=e.ExpiresAt; view.PremiumExpiresAt=&expiry }
    return view
}
func normalize(p realtime.Preferences)realtime.Preferences{
    p=realtime.ClonePreferences(p)
    for _,category:=range []*realtime.CategoryPreference{&p.Professional.Industry,&p.Professional.Profession,&p.Professional.Experience,&p.Professional.Interests,&p.Professional.Topics}{
        if category.NoPreference { category.Choices=[]string{} }
    }
    return p
}
func (s *Service) UpdatePreferences(ctx context.Context,previous identity.Principal,input realtime.Preferences)(realtime.PreferenceView,error){
    // Validate before normalization so excessive/unknown disabled choices cannot
    // be smuggled through a supposedly inactive category.
    if err:=realtime.ValidatePreferences(input);err!=nil{return realtime.PreferenceView{},identity.ErrInvalid}
    p,err:=s.refresh(ctx,previous,false);if err!=nil{return realtime.PreferenceView{},err}
    now:=s.options.Clock.Now().UTC()
    entitlement,err:=s.options.Entitlements.Entitlement(ctx,p);if err!=nil||!validEntitlement(entitlement){return realtime.PreferenceView{},realtime.ErrUnavailable}
    input=normalize(input)
    if realtime.RequiresPremium(input) && (p.Kind!=identity.KindAccount || !entitlement.Active(now)) { return realtime.PreferenceView{},realtime.ErrPremiumRequired }
    var saved realtime.Preferences
    if p.Kind==identity.KindGuest {
        saved,err=s.options.Actor.UpdateGuestPreferences(ctx,p.Guest.ID,p.TokenHash,input,now)
    }else if p.Kind==identity.KindAccount{
        saved,err=s.options.Store.Write(ctx,p.Guard(now,false),input)
        if err==nil{
            cleanup,cancel:=context.WithTimeout(context.WithoutCancel(ctx),2*time.Second)
            defer cancel()
            if notifyErr:=s.options.Actor.PreferencesChanged(cleanup,p.AccountSession.Account.ID,p.AccountSession.Account.Generation,saved,now);notifyErr!=nil{
                // Notification may have exhausted its deadline. Emergency
                // controls need independent deadlines to remain deliverable.
                emergency, stop := context.WithTimeout(context.WithoutCancel(ctx),2*time.Second)
                invalidateErr := s.options.Actor.InvalidateAccount(emergency,p.AccountSession.Account.ID,now)
                stop()
                if invalidateErr!=nil {
                    if stopper, ok := s.options.Actor.(interface{ FailClosed() }); ok { stopper.FailClosed() }
                    emergency, stop = context.WithTimeout(context.WithoutCancel(ctx),2*time.Second)
                    _=s.options.Actor.HealthOutage(emergency,true)
                    stop()
                }
                return realtime.PreferenceView{},realtime.ErrUnavailable
            }
        }
    }else{return realtime.PreferenceView{},realtime.ErrUnauthorized}
    if err!=nil{
        if errors.Is(err,identity.ErrStale){return realtime.PreferenceView{},identity.ErrStale}
        return realtime.PreferenceView{},safeError(err)
    }
    return preferenceView(saved,entitlement,p.Kind,s.options.Clock.Now().UTC()),nil
}
