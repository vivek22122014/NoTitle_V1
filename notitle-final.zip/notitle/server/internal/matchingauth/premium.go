package matchingauth

import (
 "context"
 "errors"
 "time"
 "notitle/internal/identity"
 "notitle/internal/realtime"
)

// PaidUsageSource accounts elapsed time and marks only the exact current FIFO
// lot under the same guarded ledger row lock. A stale lot/revision may return a
// fresh authoritative projection plus an error; operational/authorization
// failures must return a zero Entitlement. It must never persist this session
// guard, peer identity, queue job, or conversation as a purchase usage history.
type PaidUsageSource interface {
 MarkPaidUse(context.Context,identity.Guard,int64,string,time.Time)(realtime.Entitlement,error)
}

// RunPremiumUsage performs bounded database work outside the live coordinator.
// No paid preference can influence a match until its minimal usage flag is
// durable. Retrying a committed flag is idempotent; losing RAM jobs on restart
// never grants access because the next queue admission reads the ledger again.
func(s *Service)RunPremiumUsage(ctx context.Context)error{
 source,ok:=s.options.Entitlements.(PaidUsageSource);if !ok{return errors.New("paid matching requires a durable usage source")}
 owner,ok:=s.options.Actor.(realtime.PremiumUsageOwner);if !ok{return errors.New("paid matching requires its live usage owner")}
 ticker:=time.NewTicker(100*time.Millisecond);defer ticker.Stop()
 for{
  if err:=ctx.Err();err!=nil{return err}
  s.flushPremiumUsage(ctx,source,owner)
  select{case<-ctx.Done():return ctx.Err();case<-ticker.C:}
 }
}
func(s *Service)flushPremiumUsage(ctx context.Context,source PaidUsageSource,owner realtime.PremiumUsageOwner){
 if s.options.Ready(ctx)!=nil{return}
 claimCtx,cancel:=context.WithTimeout(ctx,time.Second);jobs,err:=owner.ClaimPremiumUsageJobs(claimCtx,8);cancel();if err!=nil{return}
 for _,job:=range jobs{
  if ctx.Err()!=nil{return}
  work,cancel:=context.WithTimeout(ctx,2*time.Second)
  now:=s.options.Clock.Now().UTC();job.Guard.Now=now
  e,_:=source.MarkPaidUse(work,job.Guard,job.EntitlementVersion,job.LotID,now);cancel()
  trusted:=validEntitlement(e)
  publish,cancel:=context.WithTimeout(ctx,time.Second)
  _,_=owner.FinishPremiumUsage(publish,job.ID,realtime.PremiumUsageResult{Entitlement:e,Trusted:trusted});cancel()
 }
}
