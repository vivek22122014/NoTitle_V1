package matchingauth

import (
	"context"
	"testing"

	"notitle/internal/friendtypes"
	"notitle/internal/identity"
	"notitle/internal/realtime"
)

type fixedFriends struct {value friendtypes.Snapshot;err error;calls int}
func (f *fixedFriends) Friends(context.Context,identity.Principal)(friendtypes.Snapshot,error) {f.calls++;return f.value,f.err}

func TestFriendAuthorizationUsesPrivateRevisionAndCopiesRelations(t *testing.T) {
	s,id,_,_,_:=setup(t)
	f:=&fixedFriends{value:friendtypes.Snapshot{Revision:3,Relations:[]friendtypes.Relation{{Ref:"opaque_friend_reference"}}}}
	s.options.FriendsEnabled=true;s.options.Friends=f
	auth,err:=s.Authorize(context.Background(),id.principal)
	if err!=nil || !auth.FriendsEnabled || auth.FriendRevision!=3 || len(auth.FriendLinks)!=1 {t.Fatal("private friendship authority not propagated",err)}
	f.value.Relations[0].Ref="changed"
	if auth.FriendLinks[0].Ref=="changed" {t.Fatal("mutable repository relation aliased into authorization")}
	f.value.Revision=0
	if _,err:=s.Authorize(context.Background(),id.principal);err!=realtime.ErrUnavailable {t.Fatal("unversioned durable relationship source accepted")}
	f.value.Revision=3;f.err=friendtypes.ErrUnavailable
	if _,err:=s.Authorize(context.Background(),id.principal);err!=realtime.ErrUnavailable {t.Fatal("friendship read failure did not close authorization")}
	s.options.FriendsEnabled=false;f.calls=0
	if auth,err:=s.Authorize(context.Background(),id.principal);err!=nil || auth.FriendsEnabled || len(auth.FriendLinks)!=0 || f.calls!=0 {t.Fatal("disabled capability read or disclosed relationships")}
}
