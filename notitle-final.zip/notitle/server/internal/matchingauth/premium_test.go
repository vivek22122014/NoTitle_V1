package matchingauth

import (
 "context"
 "errors"
 "testing"
 "time"
 "notitle/internal/identity"
 "notitle/internal/realtime"
)
type usageOwner struct{*testOwner;jobs []realtime.PremiumUsageJob;claims int;finished []realtime.PremiumUsageResult;ids []string}
func(o *usageOwner)ClaimPremiumUsageJobs(context.Context,int)([]realtime.PremiumUsageJob,error){o.claims++;return o.jobs,nil}
func(o *usageOwner)FinishPremiumUsage(_ context.Context,id string,r realtime.PremiumUsageResult)(bool,error){o.ids=append(o.ids,id);o.finished=append(o.finished,r);return true,nil}
type usageSource struct{fixedEntitlement;guard identity.Guard;revision int64;lot string;calls int}
func(s *usageSource)MarkPaidUse(_ context.Context,g identity.Guard,version int64,lot string,_ time.Time)(realtime.Entitlement,error){s.guard=g;s.revision=version;s.lot=lot;s.calls++;return s.value,s.err}

func TestPremiumUsageWorkerPreservesGuardLotAndPublishesOnlyTrustedSnapshot(t *testing.T){
 service,id,base,_,clock:=setup(t)
 job:=realtime.PremiumUsageJob{ID:"job_private",Guard:id.principal.Guard(clock.now,false),EntitlementVersion:7,LotID:"oldest_purchase_lot"}
 owner:=&usageOwner{testOwner:base,jobs:[]realtime.PremiumUsageJob{job}}
 source:=&usageSource{fixedEntitlement:fixedEntitlement{value:realtime.Entitlement{Premium:true,Version:7,ExpiresAt:clock.now.Add(time.Hour),UsageLotID:job.LotID,UsageUntil:clock.now.Add(time.Hour),PaidControlsUsed:true}}}
 service.flushPremiumUsage(context.Background(),source,owner)
 if source.calls!=1||source.guard.TokenHash!=job.Guard.TokenHash||source.guard.AccountID!=job.Guard.AccountID||source.revision!=7||source.lot!=job.LotID{t.Fatal("worker lost authoritative session or FIFO binding")}
 if len(owner.finished)!=1||!owner.finished[0].Trusted||!owner.finished[0].Entitlement.PaidControlsUsed||owner.ids[0]!=job.ID{t.Fatal("durable result was not returned to the same owner intent")}
 source.value=realtime.Entitlement{};source.err=errors.New("private database diagnostic")
 service.flushPremiumUsage(context.Background(),source,owner)
 if owner.finished[1].Trusted{t.Fatal("unknown storage result granted paid use")}
}
func TestPremiumUsageWorkerConflictCanRefreshWithoutGrantingUse(t *testing.T){
 service,_,base,_,clock:=setup(t);owner:=&usageOwner{testOwner:base,jobs:[]realtime.PremiumUsageJob{{ID:"stale_job",LotID:"consumed_lot",EntitlementVersion:1}}}
 source:=&usageSource{fixedEntitlement:fixedEntitlement{value:realtime.Entitlement{Premium:true,Version:2,ExpiresAt:clock.now.Add(time.Hour),UsageLotID:"future_lot_now_current",UsageUntil:clock.now.Add(time.Hour)},err:errors.New("stale ledger revision")}}
 service.flushPremiumUsage(context.Background(),source,owner)
 if len(owner.finished)!=1||!owner.finished[0].Trusted||owner.finished[0].Entitlement.PaidControlsUsed{t.Fatal("fresh conflict projection implied durable paid use")}
}
func TestPremiumUsageWorkerDoesNotBypassReadiness(t *testing.T){
 service,_,base,_,_:=setup(t);owner:=&usageOwner{testOwner:base};source:=&usageSource{}
 service.options.Ready=func(context.Context)error{return errors.New("unready")}
 service.flushPremiumUsage(context.Background(),source,owner)
 if owner.claims!=0||source.calls!=0{t.Fatal("unready state entered financial writer")}
 if err:=service.RunPremiumUsage(context.Background());err==nil{t.Fatal("free source silently enabled paid worker")}
}
