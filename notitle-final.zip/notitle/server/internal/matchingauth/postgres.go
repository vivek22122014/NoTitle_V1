package matchingauth

import (
    "context"
    "errors"
    "time"

    "github.com/jackc/pgx/v5"
    "github.com/jackc/pgx/v5/pgxpool"
    "notitle/internal/identity"
    "notitle/internal/realtime"
)

type PreferenceRepository interface {
    Read(context.Context, identity.Guard) (realtime.Preferences, error)
    Write(context.Context, identity.Guard, realtime.Preferences) (realtime.Preferences, error)
}

type PostgresStore struct { pool *pgxpool.Pool }
func NewPostgresStore(pool *pgxpool.Pool) *PostgresStore { return &PostgresStore{pool:pool} }

// Account locking follows the identity store's lock order. Reads and writes
// recheck session expiry, verifier and revocation under the same account lock,
// preventing a cached principal from changing a deleted or logged-out account.
func (s *PostgresStore) transaction(ctx context.Context, guard identity.Guard, write *realtime.Preferences) (realtime.Preferences, error) {
    if s == nil || s.pool == nil { return realtime.Preferences{}, identity.ErrUnavailable }
    tx, err := s.pool.BeginTx(ctx,pgx.TxOptions{IsoLevel:pgx.ReadCommitted})
    if err != nil { return realtime.Preferences{}, identity.ErrUnavailable }
    defer func(){ cleanup,cancel:=context.WithTimeout(context.Background(),2*time.Second); defer cancel(); _ = tx.Rollback(cleanup) }()
    var generation int64
    var status string
    err = tx.QueryRow(ctx,`SELECT generation,status FROM notitle.accounts WHERE id=$1 FOR UPDATE`,guard.AccountID).Scan(&generation,&status)
    if errors.Is(err,pgx.ErrNoRows) { return realtime.Preferences{},identity.ErrUnauthorized }
    if err != nil { return realtime.Preferences{},identity.ErrUnavailable }
    if status != "active" || generation != guard.AccountGeneration { return realtime.Preferences{},identity.ErrUnauthorized }
    var valid bool
    err = tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.sessions WHERE id=$1 AND account_id=$2
        AND token_hash=$3 AND account_generation=$4 AND revoked_at IS NULL
        AND created_at <= $5 AND absolute_expires_at > $5 AND last_seen_at > $5 - interval '7 days')`,
        guard.SessionID,guard.AccountID,guard.TokenHash[:],generation,guard.Now).Scan(&valid)
    if err != nil { return realtime.Preferences{},identity.ErrUnavailable }
    if !valid { return realtime.Preferences{},identity.ErrUnauthorized }
    // Lazy creation supplies the same version-one defaults for accounts created
    // before or after this migration, without changing registration transactions.
    if _,err = tx.Exec(ctx,`INSERT INTO notitle.matchmaking_preferences(account_id,updated_at)
        VALUES($1,$2) ON CONFLICT(account_id) DO NOTHING`,guard.AccountID,guard.Now); err != nil { return realtime.Preferences{},identity.ErrUnavailable }
    p,err := readPreferences(ctx,tx,guard.AccountID)
    if err != nil { return realtime.Preferences{},err }
    if write != nil {
        if write.Version != p.Version { return realtime.Preferences{},identity.ErrStale }
        p = realtime.ClonePreferences(*write)
        if err := realtime.ValidatePreferences(p); err != nil { return realtime.Preferences{},err }
        p.Version++
        mode:="custom"; if p.Professional.NoPreference { mode="none" }
        _,err=tx.Exec(ctx,`UPDATE notitle.matchmaking_preferences SET version=$2,gender_preference=$3,professional_mode=$4,
            industry_none=$5,profession_none=$6,experience_none=$7,interests_none=$8,topics_none=$9,
            preferred_industries=$10,preferred_roles=$11,preferred_experience=$12,preferred_interests=$13,preferred_topics=$14,updated_at=$15
            WHERE account_id=$1`,guard.AccountID,p.Version,p.Gender,mode,
            p.Professional.Industry.NoPreference,p.Professional.Profession.NoPreference,p.Professional.Experience.NoPreference,p.Professional.Interests.NoPreference,p.Professional.Topics.NoPreference,
            array(p.Professional.Industry.Choices),array(p.Professional.Profession.Choices),array(p.Professional.Experience.Choices),array(p.Professional.Interests.Choices),array(p.Professional.Topics.Choices),guard.Now)
        if err != nil { return realtime.Preferences{},identity.ErrUnavailable }
    }
    if err:=tx.Commit(ctx); err!=nil { return realtime.Preferences{},identity.ErrUnavailable }
    return p,nil
}
func array(values []string) []string { if values==nil { return []string{} }; return values }
func (s *PostgresStore) Read(ctx context.Context,g identity.Guard)(realtime.Preferences,error){ return s.transaction(ctx,g,nil) }
func (s *PostgresStore) Write(ctx context.Context,g identity.Guard,p realtime.Preferences)(realtime.Preferences,error){ return s.transaction(ctx,g,&p) }
func readPreferences(ctx context.Context,tx pgx.Tx,accountID string)(realtime.Preferences,error){
    var p realtime.Preferences
    var mode string
    err:=tx.QueryRow(ctx,`SELECT version,gender_preference,professional_mode,
        industry_none,profession_none,experience_none,interests_none,topics_none,
        preferred_industries,preferred_roles,preferred_experience,preferred_interests,preferred_topics
        FROM notitle.matchmaking_preferences WHERE account_id=$1`,accountID).Scan(&p.Version,&p.Gender,&mode,
        &p.Professional.Industry.NoPreference,&p.Professional.Profession.NoPreference,&p.Professional.Experience.NoPreference,&p.Professional.Interests.NoPreference,&p.Professional.Topics.NoPreference,
        &p.Professional.Industry.Choices,&p.Professional.Profession.Choices,&p.Professional.Experience.Choices,&p.Professional.Interests.Choices,&p.Professional.Topics.Choices)
    if err!=nil { return realtime.Preferences{},identity.ErrUnavailable }
    p.Professional.NoPreference=mode=="none"
    if err:=realtime.ValidatePreferences(p);err!=nil { return realtime.Preferences{},identity.ErrUnavailable }
    return p,nil
}
