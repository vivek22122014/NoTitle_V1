package matchingauth

import (
    "context"
    "crypto/rand"
    "errors"
    "fmt"
    "os"
    "strings"
    "sync"
    "testing"
    "time"

    "notitle/internal/config"
    "notitle/internal/database"
    "notitle/internal/identity"
    "notitle/internal/identitypg"
    "notitle/internal/realtime"
)

func integration(t *testing.T)(context.Context,*PostgresStore,*identitypg.Store,identity.AccountSession){
    t.Helper()
    raw:=strings.TrimSpace(os.Getenv("TEST_DATABASE_URL"));path:=strings.TrimSpace(os.Getenv("TEST_DATABASE_URL_FILE"))
    if raw!=""&&path!=""{t.Fatal("use one integration secret source")}
    if path!=""{data,err:=os.ReadFile(path);if err!=nil{t.Fatal("cannot read integration database secret")};raw=strings.TrimSpace(string(data))}
    if raw==""{if os.Getenv("REQUIRE_DATABASE_INTEGRATION")=="1"{t.Fatal("required database integration missing")};t.Skip("run scripts/db-check.sh with disposable database")}
    ctx,cancel:=context.WithTimeout(context.Background(),40*time.Second);t.Cleanup(cancel)
    pool,err:=database.Open(ctx,config.DatabaseConfig{URL:raw,MaxConns:4,MaxConnLifetime:time.Minute,MaxConnIdleTime:time.Minute,HealthCheckPeriod:time.Minute,ConnectTimeout:5*time.Second})
    if err!=nil{t.Fatal(err)};t.Cleanup(pool.Close)
    if err:=pool.Ready(ctx);err!=nil{t.Fatal("restricted migration-three database required",err)}
    id:=uuid(t);now:=time.Now().UTC().Truncate(time.Microsecond)
    sessions:=identitypg.New(pool.Raw())
    record:=identity.CreateAccountRecord{Account:identity.Account{ID:id,Username:"pref_"+strings.ReplaceAll(id,"-","")[:16],Profile:identity.Profile{Version:1,DisplayName:"Preference Test",Gender:identity.GenderOther,Topic:"general_talk"}},
        PasswordHash:"$argon2id$v=19$m=65536,t=3,p=1$synthetic-store-test$synthetic-store-test",RecoveryHash:verifier(t),
        Consent:identity.Consent{AdultConfirmed:true,Policies:identity.PolicyVersions{Terms:"draft-1",Privacy:"draft-1",Community:"draft-1"}},CreatedAt:now,
        Session:identity.SessionRecord{ID:uuid(t),TokenHash:verifier(t),CreatedAt:now,LastSeenAt:now,AuthenticatedAt:now,AbsoluteExpiresAt:now.Add(identity.SessionAbsoluteTTL)}}
    account,err:=sessions.CreateAccount(ctx,record);if err!=nil{t.Fatal(err)}
    return ctx,NewPostgresStore(pool.Raw()),sessions,account
}
func uuid(t *testing.T)string{t.Helper();var b[16]byte;if _,err:=rand.Read(b[:]);err!=nil{t.Fatal("randomness unavailable")};b[6]=b[6]&15|64;b[8]=b[8]&63|128;return fmt.Sprintf("%x-%x-%x-%x-%x",b[:4],b[4:6],b[6:8],b[8:10],b[10:])}
func verifier(t *testing.T)identity.Verifier{t.Helper();var b identity.Verifier;if _,err:=rand.Read(b[:]);err!=nil{t.Fatal("randomness unavailable")};return b}
func guard(a identity.AccountSession)identity.Guard{return identity.Guard{AccountID:a.Account.ID,AccountGeneration:a.Account.Generation,SessionID:a.Session.ID,TokenHash:a.Session.TokenHash,Now:time.Now().UTC()}}
func TestIntegrationDefaultsCASAndSavedChoices(t *testing.T){
    ctx,store,_,account:=integration(t);g:=guard(account)
    p,err:=store.Read(ctx,g);if err!=nil||p.Version!=1||p.Gender!=realtime.Everyone||!p.Professional.NoPreference{t.Fatal("safe defaults missing",err)}
    p.Professional.Profession=realtime.CategoryPreference{Choices:[]string{"engineering","design"}}
    p,err=store.Write(ctx,g,p);if err!=nil||p.Version!=2{t.Fatal("saved choices failed",err)}
    result,err:=store.Read(ctx,g);if err!=nil||len(result.Professional.Profession.Choices)!=2||!result.Professional.NoPreference{t.Fatal("global none discarded saved choices",err)}
    var wg sync.WaitGroup;results:=make(chan error,2)
    for i:=0;i<2;i++{wg.Add(1);go func(){defer wg.Done();_,err:=store.Write(ctx,g,p);results<-err}()}
    wg.Wait();close(results);ok,stale:=0,0
    for err:=range results{if err==nil{ok++}else if errors.Is(err,identity.ErrStale){stale++}else{t.Fatal(err)}}
    if ok!=1||stale!=1{t.Fatal("concurrent version writes did not serialize")}
}
func TestIntegrationCachedPrincipalCannotReadAfterRevocation(t *testing.T){
    ctx,store,sessions,account:=integration(t);g:=guard(account)
    if _,err:=store.Read(ctx,g);err!=nil{t.Fatal(err)}
    if err:=sessions.RevokeSession(ctx,g);err!=nil{t.Fatal(err)}
    if _,err:=store.Read(ctx,g);!errors.Is(err,identity.ErrUnauthorized){t.Fatal("revoked session read preferences",err)}
    if _,err:=store.Write(ctx,g,realtime.DefaultPreferences());!errors.Is(err,identity.ErrUnauthorized){t.Fatal("revoked session wrote preferences",err)}
}
func TestIntegrationSavedPreferencesUnavailableAfterDeletion(t *testing.T){
    ctx,store,sessions,account:=integration(t);g:=guard(account)
    if _,err:=store.Read(ctx,g);err!=nil{t.Fatal(err)}
    if _,err:=sessions.BeginDeletion(ctx,g,identity.DeletionRecord{ID:uuid(t),ReceiptHash:verifier(t)});err!=nil{t.Fatal(err)}
    if _,err:=store.Read(ctx,g);!errors.Is(err,identity.ErrUnauthorized){t.Fatal("deleted account read preferences",err)}
}
func TestIntegrationDatabaseRejectsUnboundedAndDuplicateSelections(t *testing.T){
    ctx,store,_,account:=integration(t);g:=guard(account)
    if _,err:=store.Read(ctx,g);err!=nil{t.Fatal(err)}
    for _,choices:=range [][]string{{"engineering","engineering"},{"engineering","product","design","data","operations","sales"},{"invented_role"}}{
        tx,err:=store.pool.Begin(ctx);if err!=nil{t.Fatal(err)}
        _,err=tx.Exec(ctx,`UPDATE notitle.matchmaking_preferences SET profession_none=false,preferred_roles=$2 WHERE account_id=$1`,account.Account.ID,choices)
        _=tx.Rollback(context.Background())
        if err==nil{t.Fatal("invalid selections passed database constraints")}
    }
}
