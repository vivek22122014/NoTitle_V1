package matchingauth

import (
	"context"
	"testing"
)

func TestAudioAuthorizationIsTrustedFeatureState(t *testing.T){
	s,id,_,_,_:=setup(t)
	auth,err:=s.Authorize(context.Background(),id.principal)
	if err!=nil||auth.AudioEnabled{t.Fatal("audio enabled without trusted feature configuration")}
	s.options.AudioEnabled=true;s.options.TextEnabled=true
	auth,err=s.Authorize(context.Background(),id.principal)
	if err!=nil||!auth.AudioEnabled{t.Fatal("audio feature authority missing",err)}
	s.options.AudioEnabled=false
	auth,err=s.Authorize(context.Background(),id.principal)
	if err!=nil||auth.AudioEnabled{t.Fatal("audio disablement not reflected in renewed authority")}
	options:=s.options;options.AudioEnabled=true;options.TextEnabled=false
	if _,err:=New(options);err==nil{t.Fatal("audio enabled without safety/text dependency")}
}
