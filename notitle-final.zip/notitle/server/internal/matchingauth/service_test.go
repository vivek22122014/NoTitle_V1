package matchingauth

import (
    "context"
    "errors"
    "testing"
    "time"

    "notitle/internal/identity"
    "notitle/internal/realtime"
)

type testClock struct { now time.Time }
func (c *testClock) Now()time.Time{return c.now}
type testIdentity struct { principal identity.Principal; err error; before func() }
func (i *testIdentity) RefreshPrincipal(context.Context,identity.Principal,bool)(identity.Principal,error){if i.before!=nil{i.before()};return i.principal,i.err}
type testRepository struct { preferences realtime.Preferences; err error; writes int; guard identity.Guard }
func (r *testRepository) Read(_ context.Context,g identity.Guard)(realtime.Preferences,error){r.guard=g;return realtime.ClonePreferences(r.preferences),r.err}
func (r *testRepository) Write(_ context.Context,g identity.Guard,p realtime.Preferences)(realtime.Preferences,error){r.guard=g;r.writes++;if r.err!=nil{return realtime.Preferences{},r.err};if p.Version!=r.preferences.Version{return realtime.Preferences{},identity.ErrStale};p.Version++;r.preferences=realtime.ClonePreferences(p);return p,nil}
type testOwner struct { fence uint64; prefs realtime.Preferences; notified int; invalidated int; unavailable bool; closed bool; notifyErr error; invalidateErr error }
func (o *testOwner) FailClosed(){o.closed=true}
func (o *testOwner) AuthFence(context.Context)(uint64,error){return o.fence,nil}
func (o *testOwner) GetGuestPreferences(context.Context,string,identity.Verifier,time.Time)(realtime.Preferences,error){return realtime.ClonePreferences(o.prefs),nil}
func (o *testOwner) UpdateGuestPreferences(_ context.Context,_ string,_ identity.Verifier,p realtime.Preferences,_ time.Time)(realtime.Preferences,error){if p.Version!=o.prefs.Version{return realtime.Preferences{},identity.ErrStale};p.Version++;o.prefs=realtime.ClonePreferences(p);return p,nil}
func (o *testOwner) PreferencesChanged(context.Context,string,int64,realtime.Preferences,time.Time)error{o.notified++;o.fence++;return o.notifyErr}
func (o *testOwner) InvalidateAccount(context.Context,string,time.Time)error{o.invalidated++;return o.invalidateErr}
func (o *testOwner) HealthOutage(_ context.Context,value bool)error{o.unavailable=value;return nil}
type fixedEntitlement struct { value realtime.Entitlement; err error }
func (e fixedEntitlement) Entitlement(context.Context,identity.Principal)(realtime.Entitlement,error){return e.value,e.err}
type fixedSafety struct { value SafetySnapshot; err error }
func (s fixedSafety) Safety(context.Context,identity.Principal)(SafetySnapshot,error){return s.value,s.err}

func setup(t *testing.T)(*Service,*testIdentity,*testOwner,*testRepository,*testClock){
    t.Helper()
    clock:=&testClock{now:time.Date(2026,10,9,10,0,0,0,time.UTC)}
    profile:=identity.Profile{Version:1,DisplayName:"Test Person",Gender:identity.GenderOther,Topic:"career_growth"}
    p:=identity.Principal{Kind:identity.KindAccount,TokenHash:identity.Verifier{1},AccountSession:identity.AccountSession{
        Account:identity.Account{ID:"account",Generation:2,Status:"active",Profile:profile},
        Session:identity.SessionRecord{ID:"session",AccountID:"account",AccountGeneration:2,CreatedAt:clock.now.Add(-time.Hour),LastSeenAt:clock.now,AbsoluteExpiresAt:clock.now.Add(time.Hour)}}}
    id:=&testIdentity{principal:p};owner:=&testOwner{fence:4,prefs:realtime.DefaultPreferences()};repo:=&testRepository{preferences:realtime.DefaultPreferences()}
    service,err:=New(Options{Clock:clock,Identity:id,Actor:owner,Store:repo,Ready:func(context.Context)error{return nil}})
    if err!=nil{t.Fatal(err)}
    return service,id,owner,repo,clock
}
func TestAuthorizationCapturesFenceBeforeFreshRead(t *testing.T){
    service,id,owner,_,clock:=setup(t)
    id.before=func(){owner.fence++}
    snapshot,err:=service.Authorize(context.Background(),id.principal)
    if err!=nil{t.Fatal(err)}
    if snapshot.Fence!=4||owner.fence!=5{t.Fatal("fence was captured after the external read")}
    if snapshot.ValidUntil!=clock.now.Add(AuthorizationTTL){t.Fatal("authorization lease not bounded")}
    if snapshot.Entitlement.Premium || snapshot.SessionVerifier!=id.principal.TokenHash {t.Fatal("trusted auth shape changed")}
}
func TestAuthorizationRevocationAndReadinessFailClosed(t *testing.T){
    service,id,_,_,_:=setup(t)
    id.err=identity.ErrUnauthorized
    if _,err:=service.Authorize(context.Background(),id.principal);err!=realtime.ErrUnauthorized{t.Fatal(err)}
    id.err=nil;id.principal.Kind=identity.KindGuest
    service.options.Ready=func(context.Context)error{return errors.New("db unavailable")}
    if _,err:=service.Authorize(context.Background(),id.principal);err!=realtime.ErrUnavailable{t.Fatal("guest bypassed safety readiness",err)}
}
func TestAuthorizationRejectsSlowExpiredSnapshot(t *testing.T){
    service,id,_,_,clock:=setup(t)
    id.before=func(){clock.now=clock.now.Add(AuthorizationTTL)}
    if _,err:=service.Authorize(context.Background(),id.principal);err!=realtime.ErrUnauthorized{t.Fatal("expired external result published",err)}
}
func TestSessionDeadlineBoundsAuthorization(t *testing.T){
    service,id,_,_,clock:=setup(t)
    id.principal.AccountSession.Session.AbsoluteExpiresAt=clock.now.Add(time.Second)
    auth,err:=service.Authorize(context.Background(),id.principal)
    if err!=nil||auth.ValidUntil!=clock.now.Add(time.Second){t.Fatal("session deadline ignored",err)}
}
func TestGuestCannotReceivePremiumFromMisconfiguredSource(t *testing.T){
    service,id,_,_,clock:=setup(t)
    id.principal.Kind=identity.KindGuest
    id.principal.Guest=identity.Guest{ID:"guest",Generation:1,Profile:id.principal.AccountSession.Account.Profile,LastSeenAt:clock.now,AbsoluteExpiresAt:clock.now.Add(time.Hour)}
    service.options.Entitlements=fixedEntitlement{value:realtime.Entitlement{Premium:true,Version:3,ExpiresAt:clock.now.Add(time.Hour)}}
    auth,err:=service.Authorize(context.Background(),id.principal)
    if err!=nil||auth.Entitlement.Premium{t.Fatal("guest received paid privilege",err)}
}
func TestExpiredSpecificSavedChoiceRequiresExplicitEveryone(t *testing.T){
    service,id,_,repo,clock:=setup(t)
    repo.preferences.Gender=realtime.PreferFemale
    service.options.Entitlements=fixedEntitlement{value:realtime.Entitlement{Premium:true,Version:3,ExpiresAt:clock.now}}
    view,err:=service.GetPreferences(context.Background(),id.principal)
    if err!=nil||view.PremiumActive||!view.RequiresEveryoneConfirmation||view.Preferences.Gender!=realtime.PreferFemale{t.Fatal("expired preference silently relaxed",err)}
}
func TestFreeCannotSaveActivePaidIntent(t *testing.T){
    service,id,_,repo,_:=setup(t)
    p:=realtime.DefaultPreferences();p.Gender=realtime.PreferMale
    if _,err:=service.UpdatePreferences(context.Background(),id.principal,p);err!=realtime.ErrPremiumRequired||repo.writes!=0{t.Fatal("client acquired paid choice",err)}
    p.Gender=realtime.Everyone;p.Professional.NoPreference=false;p.Professional.Profession=realtime.CategoryPreference{Choices:[]string{"engineering"}}
    if _,err:=service.UpdatePreferences(context.Background(),id.principal,p);err!=realtime.ErrPremiumRequired{t.Fatal("free professional intent accepted",err)}
}
func TestGlobalNonePreservesChoicesCategoryNoneClears(t *testing.T){
    service,id,owner,repo,_:=setup(t)
    p:=realtime.DefaultPreferences();p.Professional.Profession=realtime.CategoryPreference{Choices:[]string{"engineering"}}
    result,err:=service.UpdatePreferences(context.Background(),id.principal,p)
    if err!=nil||len(result.Preferences.Professional.Profession.Choices)!=1||!result.Preferences.Professional.NoPreference||owner.notified!=1{t.Fatal("globalnone lost choices or live update",err)}
    p=result.Preferences;p.Professional.Profession.NoPreference=true
    result,err=service.UpdatePreferences(context.Background(),id.principal,p)
    if err!=nil||len(result.Preferences.Professional.Profession.Choices)!=0||repo.guard.AccountGeneration!=2{t.Fatal("categorynone/session guard failed",err)}
}
func TestPreferenceVersionAndNotificationFailure(t *testing.T){
    service,id,owner,repo,_:=setup(t)
    repo.preferences.Version=2
    if _,err:=service.UpdatePreferences(context.Background(),id.principal,realtime.DefaultPreferences());!errors.Is(err,identity.ErrStale){t.Fatal("stale save overwrote choices",err)}
    owner.notifyErr=errors.New("actor full");owner.invalidateErr=errors.New("actor full")
    p:=realtime.DefaultPreferences();p.Version=2
    if _,err:=service.UpdatePreferences(context.Background(),id.principal,p);err!=realtime.ErrUnavailable||owner.invalidated!=1||!owner.unavailable||!owner.closed{t.Fatal("unapplied committed preference did not fail closed",err)}
}
func TestSafetySourceFailureAndPrivateSlices(t *testing.T){
    service,id,_,_,_:=setup(t)
    blocked:=[]string{"blocked-account"}
    service.options.Safety=fixedSafety{value:SafetySnapshot{Version:2,BlockedIdentities:blocked}}
    auth,err:=service.Authorize(context.Background(),id.principal)
    if err!=nil{t.Fatal(err)}
    blocked[0]="changed"
    if auth.BlockedIdentities[0]!="blocked-account"{t.Fatal("authorization slice aliased")}
    service.options.Safety=fixedSafety{err:errors.New("unavailable")}
    if _,err:=service.Authorize(context.Background(),id.principal);err!=realtime.ErrUnavailable{t.Fatal("safety lookup error bypassed",err)}
}

func TestGuestHandoffBusyPreservesBoundedRetrySignal(t *testing.T){
    service,id,owner,_,clock:=setup(t)
    id.principal.Kind=identity.KindGuest
    id.principal.Guest=identity.Guest{ID:"guest",Generation:1,Profile:id.principal.AccountSession.Account.Profile,LastSeenAt:clock.now,AbsoluteExpiresAt:clock.now.Add(time.Hour)}
    id.err=identity.ErrBusy
    snapshot,err:=service.Authorize(context.Background(),id.principal)
    if !errors.Is(err,identity.ErrBusy)||!snapshot.ValidUntil.IsZero()||owner.closed||owner.unavailable{t.Fatal("temporary handoff busy changed authority or ended identity",err)}
    // Readiness failures remain unavailable and revocation remains terminal;
    // only the explicit handoff/hash-capacity sentinel is eligible for retry.
    id.err=identity.ErrUnauthorized
    if _,err:=service.Authorize(context.Background(),id.principal);err!=realtime.ErrUnauthorized{t.Fatal("revocation incorrectly became retryable",err)}
    id.err=errors.New("private storage diagnostic")
    if _,err:=service.Authorize(context.Background(),id.principal);err!=realtime.ErrUnavailable{t.Fatal("unknown internal error escaped classification",err)}
}
