package httpserver

import (
	"encoding/json"
	"io"
	"log"
	"log/slog"
	"net/http"

	"notitle/internal/config"
	"notitle/internal/health"
	"notitle/internal/httpserver/apierror"
	appmw "notitle/internal/httpserver/middleware"
	"notitle/internal/identityhttp"
 "notitle/internal/performance"
)

type Dependencies struct {
	Logger *slog.Logger
	Health *health.Handler
	Identity *identityhttp.Handler
 Processing *performance.Recorder
 Realtime http.Handler
 PaymentsWebhook http.Handler
 Operations interface{http.Handler;Owns(string)bool}
}

func New(cfg config.HTTPConfig, deps Dependencies) *http.Server {
	routes := map[string]http.HandlerFunc{
		"/health/live": deps.Health.Live,
		"/health/ready": deps.Health.Ready,
		"/api/v1/ping": func(w http.ResponseWriter, _ *http.Request) {
			w.Header().Set("Content-Type", "application/json; charset=utf-8")
			_ = json.NewEncoder(w).Encode(struct{ Status string `json:"status"` }{Status: "ok"})
		},
	}
	// Exact routing avoids ServeMux's plaintext 404/405 and redirect bodies.
	var handler http.Handler = http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if deps.Operations!=nil&&deps.Operations.Owns(r.URL.Path){deps.Operations.ServeHTTP(w,r);return}
        if r.URL.Path=="/api/v1/webhooks/cashfree" {
 r.Pattern="POST /api/v1/webhooks/cashfree"
 if deps.PaymentsWebhook==nil{apierror.Write(w,appmw.RequestIDFromContext(r.Context()),apierror.CheckoutUnavailable);return};deps.PaymentsWebhook.ServeHTTP(w,r);return
 }
 if r.URL.Path=="/ws" {
 r.Pattern="GET /ws"
 if deps.Realtime==nil { apierror.Write(w,appmw.RequestIDFromContext(r.Context()),apierror.Unavailable);return };deps.Realtime.ServeHTTP(w,r);return
 }
 if deps.Identity != nil && deps.Identity.Owns(r.URL.Path) {
			deps.Identity.ServeHTTP(w,r)
			return
		}
		endpoint, ok := routes[r.URL.Path]
		if !ok {
			apierror.Write(w, appmw.RequestIDFromContext(r.Context()), apierror.NotFound)
			return
		}
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			w.Header().Set("Allow", "GET, HEAD")
			apierror.Write(w, appmw.RequestIDFromContext(r.Context()), apierror.MethodNotAllowed)
			return
		}
		r.Pattern = "GET " + r.URL.Path // fixed route label, never a user-supplied URL
		endpoint(w, r)
	})
	ordinary:=appmw.BodyLimit(cfg.MaxBodyBytes,handler)
 webhook:=appmw.BodyLimit(256<<10,handler)
 handler=http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){if r.URL.Path=="/api/v1/webhooks/cashfree"{webhook.ServeHTTP(w,r)}else{ordinary.ServeHTTP(w,r)}})
	handler = appmw.Recover(deps.Logger, handler)
 handler = appmw.Processing(deps.Processing,handler)
	handler = appmw.AccessLog(deps.Logger, handler)
	handler = appmw.RequestID(handler)
	handler = appmw.SecurityHeaders(handler)
	return &http.Server{
		Addr: cfg.Addr, Handler: handler,
		ReadHeaderTimeout: cfg.ReadHeaderTimeout, ReadTimeout: cfg.ReadTimeout,
		WriteTimeout: cfg.WriteTimeout, IdleTimeout: cfg.IdleTimeout, MaxHeaderBytes: cfg.MaxHeaderBytes,
		// net/http parser errors must not log arbitrary request data.
		ErrorLog: log.New(io.Discard, "", 0),
	}
}
