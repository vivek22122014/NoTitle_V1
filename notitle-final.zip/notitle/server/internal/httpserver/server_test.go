package httpserver

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"regexp"
	"strings"
	"testing"
	"time"

	"notitle/internal/config"
	"notitle/internal/health"
)

type readyCheck struct{}
func (readyCheck) Ready(context.Context) error {
	return nil
}

func testServer(output io.Writer) *http.Server {
	return New(config.HTTPConfig{
		Addr: ":8080", ReadHeaderTimeout: time.Second, ReadTimeout: time.Second,
		WriteTimeout: time.Second, IdleTimeout: time.Second,
		MaxHeaderBytes: 16 << 10, MaxBodyBytes: 64 << 10,
	}, Dependencies{
		Logger: slog.New(slog.NewJSONHandler(output, nil)),
		Health: health.New(time.Second, readyCheck{}),
	})
}

func TestStableEndpointContracts(t *testing.T) {
	server := testServer(io.Discard)
	for _, path := range []string{"/api/v1/ping", "/health/live", "/health/ready"} {
		rr := httptest.NewRecorder()
		request := httptest.NewRequest(http.MethodGet, path, nil)
		request.Header.Set("X-Request-ID", "untrusted-client-value")
		server.Handler.ServeHTTP(rr, request)
		if rr.Code != http.StatusOK || rr.Body.String() != "{\"status\":\"ok\"}\n" {
			t.Fatalf("%s: unexpected response %d %s", path, rr.Code, rr.Body)
		}
		if !regexp.MustCompile(`^[a-f0-9]{32}$`).MatchString(rr.Header().Get("X-Request-ID")) {
			t.Fatal("server must generate its own request ID")
		}
		if rr.Header().Get("Cache-Control") != "no-store" || rr.Header().Get("Content-Type") != "application/json; charset=utf-8" {
			t.Fatal("JSON cache/security headers missing")
		}
	}
}

func TestErrorEnvelopeAndMethodContract(t *testing.T) {
	server := testServer(io.Discard)
	tests := []struct {
		method string
		path string
		code string
		status int
	}{
		{"GET", "/missing", "not_found", 404},
		{"POST", "/api/v1/ping", "method_not_allowed", 405},
		{"DELETE", "/health/ready", "method_not_allowed", 405},
	}
	for _, test := range tests {
		rr := httptest.NewRecorder()
		server.Handler.ServeHTTP(rr, httptest.NewRequest(test.method, test.path, nil))
		var body struct {
			Error struct {
				Code string `json:"code"`
				Message string `json:"message"`
				RequestID string `json:"request_id"`
			} `json:"error"`
		}
		if err := json.Unmarshal(rr.Body.Bytes(), &body); err != nil {
			t.Fatal(err)
		}
		if rr.Code != test.status || body.Error.Code != test.code || body.Error.Message == "" || body.Error.RequestID != rr.Header().Get("X-Request-ID") {
			t.Fatalf("unexpected API error: %d %s", rr.Code, rr.Body)
		}
		if test.status == 405 && rr.Header().Get("Allow") != "GET, HEAD" {
			t.Fatal("405 missing Allow header")
		}
	}
}

func TestOversizedBodyRejected(t *testing.T) {
	rr := httptest.NewRecorder()
	testServer(io.Discard).Handler.ServeHTTP(rr, httptest.NewRequest("GET", "/api/v1/ping", strings.NewReader(strings.Repeat("x", 65537))))
	if rr.Code != http.StatusRequestEntityTooLarge || !strings.Contains(rr.Body.String(), "request_too_large") {
		t.Fatal("oversized request not rejected safely")
	}
}

func TestAccessLogsHaveOnlyAllowlistedFields(t *testing.T) {
	var output bytes.Buffer
	server := testServer(&output)
	request := httptest.NewRequest("SECRET_METHOD", "/SECRET_PATH?token=SECRET_QUERY", nil)
	request.Header.Set("Authorization", "Bearer SECRET_AUTH")
	request.Header.Set("Cookie", "session=SECRET_COOKIE")
	request.Header.Set("X-Request-ID", "SECRET_REQUEST_ID")
	request.Header.Set("User-Agent", "SECRET_AGENT")
	server.Handler.ServeHTTP(httptest.NewRecorder(), request)
	if strings.Contains(output.String(), "SECRET") {
		t.Fatal("request data leaked to access logs")
	}
	var entry map[string]any
	if err := json.Unmarshal(output.Bytes(), &entry); err != nil {
		t.Fatal(err)
	}
	allowed := map[string]bool{"time": true, "level": true, "msg": true, "request_id": true, "method": true, "route": true, "status": true, "response_bytes": true, "duration_ms": true}
	for key := range entry {
		if !allowed[key] {
			t.Fatalf("unapproved log field: %s", key)
		}
	}
	if entry["route"] != "unmatched" || entry["method"] != "OTHER" {
		t.Fatal("unbounded route/method labels")
	}
}

func TestHEADViaRealHTTPHasNoBody(t *testing.T) {
	server := httptest.NewServer(testServer(io.Discard).Handler)
	defer server.Close()
	response, err := server.Client().Head(server.URL + "/api/v1/ping")
	if err != nil {
		t.Fatal(err)
	}
	defer response.Body.Close()
	body, err := io.ReadAll(response.Body)
	if err != nil || len(body) != 0 || response.StatusCode != 200 {
		t.Fatal("HEAD response contract failed")
	}
}
