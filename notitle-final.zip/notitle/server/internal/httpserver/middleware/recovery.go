package middleware

import (
	"log/slog"
	"net/http"

	"notitle/internal/httpserver/apierror"
)

func Recover(logger *slog.Logger, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if recovered := recover(); recovered != nil {
				// Panic values, stack locals, raw paths, and request data may
				// contain secrets. Log only this fixed event and generated ID.
				logger.Error("http_panic", "request_id", RequestIDFromContext(r.Context()))
				if recorder, ok := w.(*responseRecorder); ok && recorder.status != 0 {
					// Do not append JSON to a partial response or hide truncation.
					panic(http.ErrAbortHandler)
				}
				apierror.Write(w, RequestIDFromContext(r.Context()), apierror.Internal)
			}
		}()
		next.ServeHTTP(w, r)
	})
}
