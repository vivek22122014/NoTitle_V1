package middleware

import (
	"bufio"
	"bytes"
	"context"
	"errors"
	"io"
	"log/slog"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestRequestID(t *testing.T) {
	handler := RequestID(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if RequestIDFromContext(r.Context()) == "" {
			t.Error("request id missing from context")
		}
		w.WriteHeader(http.StatusNoContent)
	}))

	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, httptest.NewRequest(http.MethodGet, "/", nil))
	if rr.Header().Get("X-Request-ID") == "" {
		t.Fatal("X-Request-ID missing")
	}
}

func TestSecurityHeaders(t *testing.T) {
	handler := SecurityHeaders(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusNoContent)
	}))

	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, httptest.NewRequest(http.MethodGet, "/", nil))

	if got := rr.Header().Get("X-Content-Type-Options"); got != "nosniff" {
		t.Fatalf("X-Content-Type-Options = %q", got)
	}
	if got := rr.Header().Get("Cache-Control"); got != "no-store" {
		t.Fatalf("Cache-Control = %q", got)
	}
}

func TestRecover(t *testing.T) {
	logger := slog.New(slog.NewTextHandler(io.Discard, nil))
	handler := RequestID(Recover(logger, http.HandlerFunc(func(http.ResponseWriter, *http.Request) {
		panic("test")
	})))

	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, httptest.NewRequest(http.MethodGet, "/panic", nil))

	if rr.Code != http.StatusInternalServerError {
		t.Fatalf("status = %d", rr.Code)
	}
	if strings.Contains(rr.Body.String(), "test") {
		t.Fatal("panic value leaked to client")
	}
}

type hijackableRecorder struct {
	*httptest.ResponseRecorder
}

func (h hijackableRecorder) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	return nil, nil, nil
}

func TestAccessRecorderPreservesHijacker(t *testing.T) {
	logger := slog.New(slog.NewTextHandler(io.Discard, nil))
	base := hijackableRecorder{httptest.NewRecorder()}
	handler := AccessLog(logger, http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		if _, ok := w.(http.Hijacker); !ok {
			t.Fatal("http.Hijacker interface was not preserved")
		}
		w.WriteHeader(http.StatusSwitchingProtocols)
	}))

	handler.ServeHTTP(base, httptest.NewRequest(http.MethodGet, "/ws", nil))
}

type failingIDs struct{}
func (failingIDs) New() (string, error) {
	return "", errors.New("secret random source failure")
}

func TestIdentifierFailureIsClosedAndPrivate(t *testing.T) {
	handler := RequestIDWith(failingIDs{}, http.HandlerFunc(func(http.ResponseWriter, *http.Request) {
		t.Fatal("request proceeded without secure ID")
	}))
	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, httptest.NewRequest("GET", "/", nil))
	if rr.Code != 500 || strings.Contains(rr.Body.String(), "secret") {
		t.Fatal("RNG failure was not private and fail closed")
	}
	if RequestIDFromContext(context.Background()) != "" {
		t.Fatal("missing request context should return empty ID")
	}
}

func TestPanicDetailsNeverReachLogsOrResponse(t *testing.T) {
	var output bytes.Buffer
	logger := slog.New(slog.NewJSONHandler(&output, nil))
	handler := RequestID(AccessLog(logger, Recover(logger, http.HandlerFunc(func(http.ResponseWriter, *http.Request) {
		panic("SECRET_PANIC")
	}))))
	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, httptest.NewRequest("GET", "/SECRET_PATH", nil))
	if rr.Code != 500 || strings.Contains(rr.Body.String(), "SECRET") || strings.Contains(output.String(), "SECRET") {
		t.Fatal("panic details leaked")
	}
	if !strings.Contains(output.String(), `"status":500`) {
		t.Fatal("recovered error status not logged")
	}
}

func TestPanicAfterWriteAbortsInsteadOfAppendingJSON(t *testing.T) {
	logger := slog.New(slog.NewTextHandler(io.Discard, nil))
	handler := AccessLog(logger, Recover(logger, http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte("partial"))
		panic("private panic")
	})))
	defer func() {
		if recovered := recover(); recovered != http.ErrAbortHandler {
			t.Errorf("partial response should abort, got %v", recovered)
		}
	}()
	rr := httptest.NewRecorder()
	handler.ServeHTTP(rr, httptest.NewRequest("GET", "/", nil))
}
