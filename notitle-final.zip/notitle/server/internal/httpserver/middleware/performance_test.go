package middleware

import (
    "net/http"
    "net/http/httptest"
    "testing"
    "notitle/internal/performance"
)
func TestOrdinaryProcessingExcludesProviderHashAndSocketLifetimes(t *testing.T){
    metrics:=performance.New()
    for _,route:=range []string{"GET /ws","POST /api/v1/payments/checkout","POST /api/v1/payments/verify","POST /api/v1/auth/login","POST /api/v1/privacy/export","GET /health/ready","GET /secret/user/path"}{
        handler:=Processing(metrics,http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){r.Pattern=route;w.WriteHeader(200)}));handler.ServeHTTP(httptest.NewRecorder(),httptest.NewRequest("GET","/",nil))
    }
    if metrics.Snapshot().API.Samples!=0{t.Fatal("nonordinary work distorted ordinary API latency")}
    handler:=Processing(metrics,http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){r.Pattern="GET /api/v1/me";w.WriteHeader(200)}));handler.ServeHTTP(httptest.NewRecorder(),httptest.NewRequest("GET","/",nil))
    if metrics.Snapshot().API.Samples!=1{t.Fatal("ordinary route not observed")}
}
