package middleware

import (
	"context"
	"net/http"

	"notitle/internal/httpserver/apierror"
	"notitle/internal/platform/identifier"
)

type contextKey struct{}
func RequestID(next http.Handler) http.Handler {
	return RequestIDWith(identifier.Crypto{}, next)
}
func RequestIDWith(ids identifier.Generator, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Ignore client-supplied IDs, including valid-looking ones.
		id, err := ids.New()
		if err != nil {
			apierror.Write(w, "", apierror.Internal)
			return
		}
		w.Header().Set("X-Request-ID", id)
		next.ServeHTTP(w, r.WithContext(context.WithValue(r.Context(), contextKey{}, id)))
	})
}
func RequestIDFromContext(ctx context.Context) string {
	value, _ := ctx.Value(contextKey{}).(string)
	return value
}
