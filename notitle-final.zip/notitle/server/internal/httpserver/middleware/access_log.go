package middleware

import (
	"bufio"
		"io"
	"log/slog"
	"net"
	"net/http"
	"time"
)

type responseRecorder struct {
	http.ResponseWriter
	status int
	bytes  int
}

func (r *responseRecorder) Unwrap() http.ResponseWriter {
	return r.ResponseWriter
}

func (r *responseRecorder) WriteHeader(status int) {
	if r.status != 0 {
		return
	}
	r.status = status
	r.ResponseWriter.WriteHeader(status)
}

func (r *responseRecorder) Write(p []byte) (int, error) {
	if r.status == 0 {
		r.WriteHeader(http.StatusOK)
	}
	n, err := r.ResponseWriter.Write(p)
	r.bytes += n
	return n, err
}

func (r *responseRecorder) ReadFrom(src io.Reader) (int64, error) {
	if r.status == 0 {
		r.WriteHeader(http.StatusOK)
	}
	if readerFrom, ok := r.ResponseWriter.(io.ReaderFrom); ok {
		n, err := readerFrom.ReadFrom(src)
		r.bytes += int(n)
		return n, err
	}
	n, err := io.Copy(struct{ io.Writer }{r}, src)
	return n, err
}

func (r *responseRecorder) Flush() {
	if r.status == 0 {
		r.WriteHeader(http.StatusOK)
	}
	if flusher, ok := r.ResponseWriter.(http.Flusher); ok {
		flusher.Flush()
	}
}

func (r *responseRecorder) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	connection,buffer,err:=http.NewResponseController(r.ResponseWriter).Hijack()
 if err==nil && r.status==0 {r.status=http.StatusSwitchingProtocols}
 return connection,buffer,err
}

func (r *responseRecorder) Push(target string, opts *http.PushOptions) error {
	if pusher, ok := r.ResponseWriter.(http.Pusher); ok {
		return pusher.Push(target, opts)
	}
	return http.ErrNotSupported
}

func AccessLog(logger *slog.Logger, next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		started := time.Now()
		recorder := &responseRecorder{ResponseWriter: w}

		next.ServeHTTP(recorder, r)

		status := recorder.status
		if status == 0 {
			status = http.StatusOK
		}

		logger.Info("http request",
			"request_id", RequestIDFromContext(r.Context()),
			"method", safeMethod(r.Method),
			"route", safeRoute(r.Pattern),
			"status", status,
			"response_bytes", recorder.bytes,
			"duration_ms", time.Since(started).Milliseconds(),
		)
	})
}

// Only finite labels enter access logs: never paths, queries, IPs, user agents,
// authorization, cookies, bodies, panic values, or error strings.
func safeMethod(method string) string {
	switch method {
	case "GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS":
		return method
	}
	return "OTHER"
}
func safeRoute(pattern string) string {
	switch pattern {
 case "GET /api/v1/support/status", "GET /api/v1/support/bootstrap", "POST /api/v1/support/cases", "POST /api/v1/support/case/access", "POST /api/v1/support/case/reply",
 "GET /api/v1/me/support/cases", "POST /api/v1/me/support/cases", "POST /api/v1/me/support/case/access", "POST /api/v1/me/support/case/reply",
 "POST /api/v1/notices/current", "POST /api/v1/notices/ack", "POST /api/v1/privacy/export", "POST /api/v1/privacy/closed-receipt",
 "POST /api/v1/webhooks/cashfree", "GET /api/v1/premium/plans", "GET /api/v1/me/premium", "GET /api/v1/me/orders", "GET /api/v1/me/receipts", "POST /api/v1/payments/orders", "POST /api/v1/payments/checkout", "POST /api/v1/payments/verify":
 return pattern
	case "GET /api/v1/friends", "DELETE /api/v1/friends/{friendRef}":
		return pattern
	case "POST /api/v1/reports/begin", "POST /api/v1/reports", "GET /api/v1/blocks", "POST /api/v1/blocks", "DELETE /api/v1/blocks/{blockRef}":
		return pattern
	case "GET /ws", "POST /api/v1/realtime/ticket", "GET /api/v1/me/matching-preferences", "PATCH /api/v1/me/matching-preferences", "GET /health/live", "GET /health/ready", "GET /api/v1/ping":
		return pattern
	case "GET /api/v1/auth/bootstrap", "POST /api/v1/guest/session", "DELETE /api/v1/guest/session",
		"POST /api/v1/auth/register", "POST /api/v1/auth/login", "POST /api/v1/auth/recover",
		"GET /api/v1/me", "DELETE /api/v1/me", "PATCH /api/v1/me/profile", "PATCH /api/v1/me/professional-profile",
		"POST /api/v1/auth/reauthenticate", "POST /api/v1/auth/change-password", "POST /api/v1/auth/recovery-code",
		"POST /api/v1/auth/logout", "POST /api/v1/auth/logout-all", "POST /api/v1/account/deletion/status":
		return pattern
	}
	return "unmatched"
}
