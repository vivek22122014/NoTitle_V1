package middleware

import (
    "net/http"
    "time"
    "notitle/internal/performance"
)
func Processing(metrics *performance.Recorder,next http.Handler)http.Handler{
    if metrics==nil{return next}
    return http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){start:=time.Now();next.ServeHTTP(w,r);if ordinaryAPI(r.Pattern){metrics.API(time.Since(start))}})
}
// Provider network calls, password/recovery hashing, health probes, exports and
// websocket lifetimes do not belong in ordinary API processing latency.
func ordinaryAPI(pattern string)bool{
    switch pattern{
    case "GET /api/v1/auth/bootstrap","GET /api/v1/me","PATCH /api/v1/me/profile","PATCH /api/v1/me/professional-profile",
    "POST /api/v1/realtime/ticket","GET /api/v1/me/matching-preferences","PATCH /api/v1/me/matching-preferences",
    "POST /api/v1/reports/begin","POST /api/v1/reports","GET /api/v1/blocks","POST /api/v1/blocks","DELETE /api/v1/blocks/{blockRef}",
    "GET /api/v1/friends","DELETE /api/v1/friends/{friendRef}","GET /api/v1/premium/plans","GET /api/v1/me/premium","GET /api/v1/me/orders","GET /api/v1/me/receipts",
    "GET /api/v1/support/status","GET /api/v1/support/bootstrap","POST /api/v1/support/cases","POST /api/v1/support/case/access","POST /api/v1/support/case/reply",
    "GET /api/v1/me/support/cases","POST /api/v1/me/support/cases","POST /api/v1/me/support/case/access","POST /api/v1/me/support/case/reply","POST /api/v1/notices/current","POST /api/v1/notices/ack":return true
    };return false
}
