// Package apierror defines the only public error shape. Callers must use the
// allowlisted values; internal errors and provider payloads stay private.
package apierror

import (
	"encoding/json"
	"net/http"
)

type Error struct {
	status int
	code string
	message string
}
func (e Error) Error() string {
	return e.code
}
func (e Error) Status() int {
	return e.status
}
var (
 SupportConflict = Error{http.StatusConflict,"support_conflict","This request changed. Refresh its status before retrying."}
 CheckoutUnavailable = Error{http.StatusServiceUnavailable,"checkout_unavailable","Checkout is not available. Existing purchases remain recorded."}
 BillingConflict = Error{http.StatusConflict,"billing_conflict","This purchase request changed. Review your orders before retrying."}
 PaymentReview = Error{http.StatusConflict,"payment_review","This payment needs billing review. Do not pay again."}
	FriendConflict = Error{http.StatusConflict, "friend_conflict", "This connection has changed. Refresh and try again."}
	FriendCapacity = Error{http.StatusConflict, "friend_capacity", "Your connection limit has been reached."}
	ReportExpired = Error{http.StatusGone, "report_expired", "The temporary report has expired. Review the grievance options."}
	StaleInteraction = Error{http.StatusConflict, "stale_epoch", "This conversation has ended or changed."}
	SafetyConflict = Error{http.StatusConflict, "safety_conflict", "This submission identifier was already used for different details."}
	PremiumRequired = Error{http.StatusForbidden, "premium_required", "This preference requires active Premium."}
 NotFound = Error{http.StatusNotFound, "not_found", "Resource not found."}
	MethodNotAllowed = Error{http.StatusMethodNotAllowed, "method_not_allowed", "Method not allowed."}
	Internal = Error{http.StatusInternalServerError, "internal_server_error", "An internal error occurred."}
	TooLarge = Error{http.StatusRequestEntityTooLarge, "request_too_large", "Request body is too large."}
	Invalid = Error{http.StatusBadRequest, "invalid_input", "Check the required fields and current policy acceptance."}
	Unauthorized = Error{http.StatusUnauthorized, "authentication_required", "Sign in or start a new guest session."}
	Credentials = Error{http.StatusUnauthorized, "invalid_credentials", "Those credentials could not be verified."}
	Forbidden = Error{http.StatusForbidden, "request_not_allowed", "Refresh this page and try again."}
	Conflict = Error{http.StatusConflict, "identity_unavailable", "The requested identity or change is unavailable."}
	Stale = Error{http.StatusConflict, "stale_identity", "Your profile or session changed. Refresh and try again."}
	Reauthentication = Error{http.StatusForbidden, "reauthentication_required", "Confirm your password before continuing."}
	Unavailable = Error{http.StatusServiceUnavailable, "temporarily_unavailable", "This service is temporarily unavailable. Try again shortly."}
	RateLimited = Error{http.StatusTooManyRequests, "rate_limited", "Too many attempts. Try again shortly."}
	UnsupportedMedia = Error{http.StatusUnsupportedMediaType, "json_required", "Send an application/json request."}
	Handoff = Error{http.StatusConflict, "registration_requires_login", "Registration may have finished. Sign in or use recovery to continue."}
)
type detail struct {
	Code string `json:"code"`
	Message string `json:"message"`
	RequestID string `json:"request_id"`
}
type envelope struct {
	Error detail `json:"error"`
}
func Write(w http.ResponseWriter, requestID string, err Error) {
	if err.status < 400 || err.status > 599 {
		err = Internal
	}
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(err.status)
	_ = json.NewEncoder(w).Encode(envelope{Error: detail{Code: err.code, Message: err.message, RequestID: requestID}})
}
