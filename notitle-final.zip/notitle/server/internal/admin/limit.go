package admin

import (
    "sync"
    "time"
)

type bucket struct { tokens float64; updated time.Time }
type limiter struct { mu sync.Mutex; buckets map[[32]byte]bucket; global bucket }
func newLimiter(now time.Time)*limiter{return &limiter{buckets:map[[32]byte]bucket{},global:bucket{tokens:10,updated:now}}}
func consume(b bucket,now time.Time,max float64,interval time.Duration)(bucket,bool){
    if elapsed:=now.Sub(b.updated);elapsed>0{b.tokens+=elapsed.Seconds()/interval.Seconds();if b.tokens>max{b.tokens=max};b.updated=now}
    if b.tokens<1{return b,false};b.tokens--;return b,true
}
// Global and two independent per-source/per-name buckets run before Argon2.
// Keys are digests; no usernames or addresses enter application logs.
func(l *limiter)allow(source,name string,now time.Time)bool{
    l.mu.Lock();defer l.mu.Unlock()
    var ok bool;l.global,ok=consume(l.global,now,10,10*time.Second);if !ok{return false}
    for key,b:=range l.buckets{if now.Sub(b.updated)>30*time.Minute{delete(l.buckets,key)}}
    for _,key:=range [][32]byte{digest("source",source),digest("login-name",name)}{
        b,found:=l.buckets[key];if !found{if len(l.buckets)>=1024{return false};b=bucket{tokens:5,updated:now}}
        b,ok=consume(b,now,5,time.Minute);l.buckets[key]=b;if !ok{return false}
    };return true
}
