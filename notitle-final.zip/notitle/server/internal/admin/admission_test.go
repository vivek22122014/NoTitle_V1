package admin

import (
    "context"
    "net/http/httptest"
    "net/url"
    "testing"

    "notitle/internal/admission"
)
type fakeAdmission struct{calls int;action,evidence string;seconds int}
func(f *fakeAdmission)State()admission.State{return admission.State{Closed:true}}
func(f *fakeAdmission)Change(_ context.Context,action,evidence string,seconds int)error{f.calls++;f.action=action;f.evidence=evidence;f.seconds=seconds;return nil}
func TestOnlyFreshAuditedOwnerCanChangeAdmission(t *testing.T){
    for _,role:=range []string{Owner,Moderator,GrievanceOfficer,BillingOperator,OperationsReadonly}{
        h,store,_,_:=newTestHandler(t,[]string{role});gate:=&fakeAdmission{};h.admission=gate
        values:=url.Values{"csrf":{testCSRF()},"action":{"drain"},"reason":{"Deployment review complete"},"seconds":{"120"}}
        w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/operations/admission",values))
        if role==Owner{if w.Code!=303||gate.calls!=1||len(store.audits)!=1||store.audits[0].Action!="admission_drain_requested"{t.Fatal("owner action was not audited before dispatch")}}else if w.Code!=403||gate.calls!=0{t.Fatal("non-owner changed deployment admission",role)}
    }
    h,store,_,_:=newTestHandler(t,[]string{Owner});gate:=&fakeAdmission{};h.admission=gate;store.auditFail=true
    values:=url.Values{"csrf":{testCSRF()},"action":{"open"},"reason":{"Reviewed immutable launch candidate"},"evidence_ref":{"release_review"}}
    w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/operations/admission",values));if w.Code!=503||gate.calls!=0{t.Fatal("audit outage allowed opening")}
}
func TestAdmissionRejectsForgedRoleUnknownFieldsAndMissingCSRF(t *testing.T){
    for _,mode:=range []string{"forged","csrf","unbounded"}{
        h,_,_,_:=newTestHandler(t,[]string{Owner});gate:=&fakeAdmission{};h.admission=gate
        v:=url.Values{"csrf":{testCSRF()},"action":{"drain"},"reason":{"Prepare planned maintenance"},"seconds":{"120"}}
        switch mode{case "forged":v.Set("approved","true");case "csrf":v.Set("csrf","invalid");case "unbounded":v.Set("seconds","121")}
        w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/operations/admission",v));if w.Code<400||gate.calls!=0{t.Fatal("invalid admission request reached gate",mode)}
    }
}
