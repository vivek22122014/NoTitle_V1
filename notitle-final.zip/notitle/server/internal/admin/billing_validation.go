package admin

import (
    "crypto/hmac"
    "crypto/sha256"
    "encoding/base64"
    "encoding/json"
    "net/url"
    "strconv"
    "time"
)

// A signed preview ties the deliberate confirmation to the operator session,
// exact purchase/payment, amount, entitlement treatment and ledger revision.
// The database independently verifies current authorization and ledger state.
type refundApproval struct {
    ActorID string
    Generation int64
    SessionHash [32]byte
    OrderRef string
    PaymentID string
    IdempotencyKey string
    Reason string
    Treatment string
    AmountPaise int64
    ReduceSeconds int64
    Revision int64
    ExpiresAt int64
}

func (h *Handler) signRefundApproval(in refundApproval) string {
    raw,err:=json.Marshal(in);if err!=nil{return ""}
    mac:=hmac.New(sha256.New,h.key);_,_=mac.Write([]byte("notitle-admin-refund-preview-v1\x00"));_,_=mac.Write(raw)
    return base64.RawURLEncoding.EncodeToString(mac.Sum(nil))
}

func (h *Handler) verifyRefundApproval(in refundApproval,token string) bool {
    if in.ExpiresAt<=h.now().Unix()||in.ExpiresAt>h.now().Add(10*time.Minute).Unix(){return false}
    expected:=h.signRefundApproval(in)
    return len(token)==43&&hmac.Equal([]byte(expected),[]byte(token))
}

func strictFields(form url.Values,allowed ...string)bool{
    set:=make(map[string]bool,len(allowed));for _,field:=range allowed{set[field]=true}
    for key,values:=range form{if !set[key]||len(values)!=1{return false}}
    return true
}

// No floating-point coercion, exponents, signs, whitespace or decimal rupees.
// Bounded positive integers preserve the exact paise/seconds seen in preview.
func formInteger(value string,minimum,maximum int64)(int64,bool){
    if value==""||len(value)>18||(len(value)>1&&value[0]=='0'){return 0,false}
    for _,r:=range value{if r<'0'||r>'9'{return 0,false}}
    n,err:=strconv.ParseInt(value,10,64);return n,err==nil&&n>=minimum&&n<=maximum
}

func validProviderReference(value string)bool{
    if len(value)<1||len(value)>200{return false}
    for _,r:=range value{if !(r>='a'&&r<='z'||r>='A'&&r<='Z'||r>='0'&&r<='9'||r=='_'||r=='-'||r=='.'||r==':'){return false}}
    return true
}

func validBillingIdempotency(value string)bool{
    return len(value)<=64&&validReference(value)
}

func billingRequestKey(seed,scope string)string{
    sum:=sha256.Sum256([]byte("notitle-billing-form-v1\x00"+seed+"\x00"+scope))
    return base64.RawURLEncoding.EncodeToString(sum[:])
}
