package admin

import (
    "context"
    "errors"

    "github.com/jackc/pgx/v5"
)

type billingViewAuditor interface {
    AuditBillingView(context.Context,Principal,[32]byte,Audit)error
}

func(h *Handler)auditBillingView(ctx context.Context,p Principal,session,action,ref,reason string)error{
    store,ok:=h.store.(billingViewAuditor);if !ok{return ErrUnavailable}
    return store.AuditBillingView(ctx,p,digest("session",session),Audit{AdminID:p.ID,Action:action,SubjectRef:ref,Reason:reason,Result:"success",At:h.now()})
}

// Recheck current role/session/generation after any slow financial read and
// commit the audit before exposing its result. Logout and operator revocation
// use the same operator lock, so an obsolete HTTP principal is insufficient.
func(s *PostgresStore)AuditBillingView(ctx context.Context,p Principal,hash [32]byte,a Audit)error{
    if p.ID==""||p.ID!=a.AdminID||p.Generation<1||!validReason(a.Reason)||a.Result!="success"{return ErrInvalid}
    switch a.Action{case "billing_worklist","billing_order","billing_refund_preview":default:return ErrInvalid}
    tx,err:=s.db.Begin(ctx);if err!=nil{return ErrUnavailable};defer tx.Rollback(context.Background())
    var roles []string;var generation int64;var disabled bool
    err=tx.QueryRow(ctx,`SELECT roles,generation,disabled FROM notitle.admin_users WHERE id=$1 FOR UPDATE`,p.ID).Scan(&roles,&generation,&disabled)
    if errors.Is(err,pgx.ErrNoRows){return ErrCredentials};if err!=nil{return ErrUnavailable};if disabled||generation!=p.Generation||!ValidRoles(roles)||!CanBill(roles){return ErrForbidden}
    var active bool
    err=tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.admin_sessions WHERE token_hash=$1 AND admin_id=$2 AND admin_generation=$3 AND created_at<=$4 AND absolute_expires_at>$4 AND last_seen_at>$4-interval '15 minutes')`,hash[:],p.ID,p.Generation,a.At).Scan(&active)
    if err!=nil{return ErrUnavailable};if !active{return ErrCredentials}
    if err=writeAudit(ctx,tx,a);err!=nil{return err};if tx.Commit(ctx)!=nil{return ErrUnavailable};return nil
}
