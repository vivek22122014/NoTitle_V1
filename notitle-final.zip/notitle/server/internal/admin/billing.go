package admin

import (
    "context"
    "errors"
    "net/http"
    "net/url"
    "strings"
    "time"

    "notitle/internal/billing"
)

// Implemented by the billing store. Mutations authorize the current operator
// and session inside their transaction and commit their audit atomically.
// External provider requests run only in the durable billing worker.
type BillingBackend interface {
    AdminOrders(context.Context,int)([]billing.Order,error)
    AdminOrder(context.Context,string)(billing.AdminOrderDetail,error)
    ListReview(context.Context,int)([]billing.AdminReview,error)
    AdminDisputes(context.Context,int)([]billing.AdminDispute,error)
    PreviewRefund(context.Context,string,string,time.Time)(billing.RefundPreview,error)
    CreateRefund(context.Context,billing.RefundRequest,time.Time)(billing.Refund,error)
    RecordDispute(context.Context,billing.DisputeInput,time.Time)error
    ReviewAction(context.Context,billing.AdminReviewAction,time.Time)error
}

type billingPage struct {
    Orders []billing.Order
    Reviews []billing.AdminReview
    Disputes []billing.AdminDispute
    Detail billing.AdminOrderDetail
    Preview billing.RefundPreview
    Approval refundApproval
    ApprovalToken string
    IdempotencyKey string
    Result billing.Refund
}

func(h *Handler)serveBilling(w http.ResponseWriter,r *http.Request,p Principal,session string,data pageData){
    if !CanBill(p.Roles){_=h.audit(r.Context(),p,"billing_access","","Role does not permit billing access","denied");http.Error(w,"This role does not permit billing access",403);return}
    if h.billing==nil{http.Error(w,"Billing operations are not configured",503);return}
    if r.URL.Path=="/billing"&&r.Method=="GET"{data.Page="billing_access";h.render(w,data);return}
    if r.URL.Path=="/billing/worklist"&&r.Method=="POST"{
        reason:=r.PostForm.Get("reason");if !strictFields(r.PostForm,"csrf","reason")||!validReason(reason){http.Error(w,"Give a review reason of 5–1000 characters",400);return}
        orders,err:=h.billing.AdminOrders(r.Context(),100);if err!=nil{h.billingError(w,err);return}
        reviews,err:=h.billing.ListReview(r.Context(),100);if err!=nil{h.billingError(w,err);return}
        disputes,err:=h.billing.AdminDisputes(r.Context(),100);if err!=nil{h.billingError(w,err);return}
        if err=h.auditBillingView(r.Context(),p,session,"billing_worklist","",reason);err!=nil{http.Error(w,"Audit unavailable",503);return}
        key,err:=secret();if err!=nil{http.Error(w,"Billing operations unavailable",503);return}
        data.Page="billing_worklist";data.Billing=billingPage{Orders:orders,Reviews:reviews,Disputes:disputes,IdempotencyKey:key};h.render(w,data);return
    }
    if strings.HasPrefix(r.URL.Path,"/billing/reviews/"){
        ref:=strings.TrimPrefix(r.URL.Path,"/billing/reviews/")
        if !validReference(ref)||r.Method!="POST"{http.NotFound(w,r);return}
        if !strictFields(r.PostForm,"csrf","reason","version","idempotency_key","action")||!validReason(r.PostForm.Get("reason"))||!validBillingIdempotency(r.PostForm.Get("idempotency_key")){http.Error(w,"Invalid review decision",400);return}
        version,ok:=formInteger(r.PostForm.Get("version"),1,1<<62);if !ok{http.Error(w,"Current review version required",400);return}
        action:=r.PostForm.Get("action");if action!="note"&&action!="resolve"&&action!="reopen"{http.Error(w,"Review action not permitted",403);return}
        input:=billing.AdminReviewAction{ActorID:p.ID,AdminGeneration:p.Generation,AdminSessionHash:digest("session",session),Ref:ref,Action:action,Reason:r.PostForm.Get("reason"),ExpectedVersion:version,IdempotencyKey:r.PostForm.Get("idempotency_key")}
        if err:=h.billing.ReviewAction(r.Context(),input,h.now());err!=nil{h.billingError(w,err);return}
        http.Redirect(w,r,"/billing",303);return
    }
    if !strings.HasPrefix(r.URL.Path,"/billing/orders/"){http.NotFound(w,r);return}
    parts:=strings.Split(strings.TrimPrefix(r.URL.Path,"/billing/orders/"),"/")
    if len(parts)<1||len(parts)>2||!validReference(parts[0]){http.NotFound(w,r);return};ref:=parts[0];data.Ref=ref
    if len(parts)==1&&r.Method=="GET"{data.Page="billing_order_access";h.render(w,data);return}
    if len(parts)!=2||r.Method!="POST"{http.NotFound(w,r);return}
    switch parts[1]{
    case "detail":
        reason:=r.PostForm.Get("reason");if !strictFields(r.PostForm,"csrf","reason")||!validReason(reason){http.Error(w,"Give a review reason of 5–1000 characters",400);return}
        detail,err:=h.billing.AdminOrder(r.Context(),ref);if err!=nil{h.billingError(w,err);return}
        if detail.Order.Ref!=ref{http.Error(w,"Billing operations unavailable",503);return}
        if err=h.auditBillingView(r.Context(),p,session,"billing_order",ref,reason);err!=nil{http.Error(w,"Audit unavailable",503);return}
        key,err:=secret();if err!=nil{http.Error(w,"Billing operations unavailable",503);return}
        data.Page="billing_order";data.Billing=billingPage{Detail:detail,IdempotencyKey:key};h.render(w,data);return
    case "refund-preview","refund":
        in,ok:=parseRefundApproval(r.PostForm,parts[1]=="refund");if !ok{http.Error(w,"Invalid refund selection; use integer paise and explicit seconds",400);return}
        in.ActorID=p.ID;in.Generation=p.Generation;in.SessionHash=digest("session",session);in.OrderRef=ref
        if parts[1]=="refund"{
            if !h.verifyRefundApproval(in,r.PostForm.Get("approval")){http.Error(w,"Refund preview expired or changed; review it again",409);return}
            result,err:=h.billing.CreateRefund(r.Context(),billing.RefundRequest{ActorID:p.ID,AdminGeneration:p.Generation,AdminSessionHash:in.SessionHash,OrderRef:ref,PaymentID:in.PaymentID,IdempotencyKey:in.IdempotencyKey,Reason:in.Reason,Treatment:in.Treatment,AmountPaise:in.AmountPaise,ReduceSeconds:in.ReduceSeconds,ExpectedRevision:in.Revision},h.now())
            if err!=nil{h.billingError(w,err);return}
            if result.OrderRef!=ref||result.PaymentID!=in.PaymentID{http.Error(w,"Refund outcome requires review; do not create another request",503);return}
            data.Page="billing_refund_result";data.Billing.Result=result;h.render(w,data);return
        }
        preview,err:=h.billing.PreviewRefund(r.Context(),ref,in.PaymentID,h.now());if err!=nil{h.billingError(w,err);return}
        if preview.OrderRef!=ref||preview.PaymentID!=in.PaymentID||preview.Revision<0{http.Error(w,"Billing operations unavailable",503);return}
        if in.AmountPaise>preview.RefundablePaise||in.Treatment=="full"&&(in.AmountPaise!=preview.CapturedPaise||preview.RefundablePaise!=preview.CapturedPaise)||in.Treatment=="duration"&&in.ReduceSeconds>preview.AvailableSeconds{http.Error(w,"Selection exceeds the current refundable funds or this purchase's unused duration",409);return}
        in.Revision=preview.Revision;in.ExpiresAt=h.now().Add(10*time.Minute).Unix()
        if err=h.auditBillingView(r.Context(),p,session,"billing_refund_preview",ref,in.Reason);err!=nil{http.Error(w,"Audit unavailable",503);return}
        data.Page="billing_refund_preview";data.Billing=billingPage{Preview:preview,Approval:in,ApprovalToken:h.signRefundApproval(in)};h.render(w,data);return
    case "dispute":
        if !strictFields(r.PostForm,"csrf","reason","version","idempotency_key","payment_id","provider_dispute_id","status","response_due","hold_access")||!validReason(r.PostForm.Get("reason"))||!validBillingIdempotency(r.PostForm.Get("idempotency_key"))||!validProviderReference(r.PostForm.Get("payment_id"))||!validProviderReference(r.PostForm.Get("provider_dispute_id")){http.Error(w,"Invalid dispute decision",400);return}
        version,ok:=formInteger(r.PostForm.Get("version"),0,1<<62);if !ok{http.Error(w,"Current dispute version required",400);return}
        status:=r.PostForm.Get("status");if status!="open"&&status!="won"&&status!="lost"&&status!="review"{http.Error(w,"Dispute action not permitted",403);return}
        due,err:=time.Parse(time.RFC3339,r.PostForm.Get("response_due"));if err!=nil||due.IsZero(){http.Error(w,"Use the provider's exact response deadline with timezone, for example 2026-10-10T12:00:00Z",400);return}
        hold:=r.PostForm.Get("hold_access");if hold!=""&&hold!="true"{http.Error(w,"Invalid dispute access selection",400);return}
        if err=h.billing.RecordDispute(r.Context(),billing.DisputeInput{ActorID:p.ID,AdminGeneration:p.Generation,AdminSessionHash:digest("session",session),OrderRef:ref,PaymentID:r.PostForm.Get("payment_id"),ProviderDisputeID:r.PostForm.Get("provider_dispute_id"),IdempotencyKey:r.PostForm.Get("idempotency_key"),ExpectedRevision:version,Reason:r.PostForm.Get("reason"),Status:status,ResponseDue:due,HoldAccess:hold=="true"},h.now());err!=nil{h.billingError(w,err);return}
        http.Redirect(w,r,"/billing/orders/"+ref,303);return
    default:http.NotFound(w,r)
    }
}

func parseRefundApproval(form url.Values,confirm bool)(refundApproval,bool){
    var in refundApproval
    fields:=[]string{"csrf","reason","payment_id","idempotency_key","amount_paise","treatment","reduce_seconds"}
    if confirm{fields=append(fields,"version","approval","approval_expires")}
    if !strictFields(form,fields...)||!validReason(form.Get("reason"))||!validProviderReference(form.Get("payment_id"))||!validBillingIdempotency(form.Get("idempotency_key")){return in,false}
    amount,ok:=formInteger(form.Get("amount_paise"),1,100000000);if !ok{return in,false}
    seconds,ok:=formInteger(form.Get("reduce_seconds"),0,31536000);if !ok{return in,false}
    treatment:=form.Get("treatment");if treatment!="full"&&treatment!="money_only"&&treatment!="duration"{return in,false}
    if treatment=="duration"&&seconds==0||treatment!="duration"&&seconds!=0{return in,false}
    in.PaymentID=form.Get("payment_id");in.IdempotencyKey=form.Get("idempotency_key");in.Reason=form.Get("reason");in.Treatment=treatment;in.AmountPaise=amount;in.ReduceSeconds=seconds
    if confirm{in.Revision,ok=formInteger(form.Get("version"),0,1<<62);if !ok{return in,false};in.ExpiresAt,ok=formInteger(form.Get("approval_expires"),1,1<<62);if !ok{return in,false}}
    return in,true
}
func(h *Handler)billingError(w http.ResponseWriter,err error){
    switch{case errors.Is(err,billing.ErrUnauthorized):http.Error(w,"Operator authorization changed; sign in again",403)
    case errors.Is(err,billing.ErrNotFound):http.Error(w,"Purchase or review not found",404)
    case errors.Is(err,billing.ErrInvalid):http.Error(w,"Invalid billing request",400)
    case errors.Is(err,billing.ErrConflict):http.Error(w,"Financial state changed; reopen its audited detail before retrying. Preserve the same request key for an uncertain submission.",409)
    case errors.Is(err,billing.ErrReview):http.Error(w,"Restricted financial review required. Reconcile the provider outcome before retrying; do not create a second refund.",409)
    default:http.Error(w,"Billing result unavailable. Inspect the current order and existing requests before retrying with the same key. Do not assume a refund failed.",503)}
}
