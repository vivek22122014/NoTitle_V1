package admin

import (
    "context"
    "crypto/subtle"
    "errors"
    "html/template"
    "net"
    "net/http"
    "net/url"
    "strconv"
    "strings"
    "time"

    "github.com/jackc/pgx/v5/pgxpool"
    "notitle/internal/identity"
    "notitle/internal/admission"
    "notitle/internal/safety"
)

type Backend interface {
    CaseList(context.Context,int)([]safety.CaseSummary,error)
    CaseDetail(context.Context,string)(safety.CaseDetail,error)
    ApplyAction(context.Context,safety.AdminAction)(safety.ActionResult,error)
}
type Options struct {
    Pool *pgxpool.Pool
    Store Store
    Backend Backend
    Billing BillingBackend
    Operations OperationsBackend
    Privacy PrivacyBackend
    Observability DashboardBackend
    Admission AdmissionBackend
    Metrics MetricsBackend
    Hasher identity.PasswordHasher
    Key []byte
    Origin string
    AllowInsecureLocalhost bool
    Now func()time.Time
}
type Handler struct {
    store Store
    backend Backend
    billing BillingBackend
    operations OperationsBackend
    privacy PrivacyBackend
    observability DashboardBackend
    admission AdmissionBackend
    metrics MetricsBackend
    exports *exportVault
    hasher identity.PasswordHasher
    key []byte
    origin,host,cookieName,preCookieName,dummyHash string
    secure bool
    now func()time.Time
    limit *limiter
    slots chan struct{}
}

func New(opts Options)(*Handler,error){
    parsed,err:=url.Parse(opts.Origin)
    if err!=nil||parsed.Host==""||parsed.User!=nil||parsed.Path!=""||parsed.RawQuery!=""||parsed.Fragment!=""||parsed.Opaque!=""{return nil,ErrInvalid}
    secure:=parsed.Scheme=="https"
    if !secure && !(parsed.Scheme=="http"&&opts.AllowInsecureLocalhost&&(parsed.Hostname()=="localhost"||parsed.Hostname()=="127.0.0.1"||parsed.Hostname()=="::1")){return nil,ErrInvalid}
    if opts.Store==nil {if opts.Pool==nil{return nil,ErrInvalid};opts.Store=NewPostgresStore(opts.Pool)}
    if opts.Backend==nil||opts.Hasher==nil||len(opts.Key)!=32{return nil,ErrInvalid}
    if opts.Now==nil{opts.Now=time.Now}
    random,err:=secret();if err!=nil{return nil,err}
    ctx,cancel:=context.WithTimeout(context.Background(),5*time.Second);defer cancel()
    dummy,err:=opts.Hasher.Hash(ctx,random);if err!=nil{return nil,ErrUnavailable}
    h:=&Handler{store:opts.Store,backend:opts.Backend,billing:opts.Billing,operations:opts.Operations,privacy:opts.Privacy,observability:opts.Observability,exports:newExportVault(),hasher:opts.Hasher,key:append([]byte{},opts.Key...),origin:opts.Origin,host:parsed.Host,secure:secure,now:opts.Now,dummyHash:dummy,limit:newLimiter(opts.Now()),slots:make(chan struct{},32),cookieName:"__Host-notitle_admin",preCookieName:"__Host-notitle_admin_pre"}
    if !secure{h.cookieName="notitle_admin_dev";h.preCookieName="notitle_admin_pre_dev"}
    h.admission=opts.Admission
    h.metrics=opts.Metrics
    return h,nil
}

func(h *Handler)ServeHTTP(w http.ResponseWriter,r *http.Request){
    w.Header().Set("Cache-Control","no-store")
    w.Header().Set("X-Content-Type-Options","nosniff")
    w.Header().Set("X-Frame-Options","DENY")
    w.Header().Set("Referrer-Policy","no-referrer")
    w.Header().Set("X-Robots-Tag","noindex, nofollow")
    w.Header().Set("Content-Security-Policy","default-src 'none'; style-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'")
    w.Header().Set("Permissions-Policy","camera=(), microphone=(), geolocation=()")
    if h.secure{w.Header().Set("Strict-Transport-Security","max-age=31536000")}
    if r.Host!=h.host||r.URL.RawQuery!=""||r.URL.ForceQuery||r.URL.EscapedPath()!=r.URL.Path {http.NotFound(w,r);return}
    if r.Method!="GET"&&r.Method!="POST"{w.Header().Set("Allow","GET, POST");http.Error(w,"Method not allowed",405);return}
    select{case h.slots<-struct{}{}:defer func(){<-h.slots}();default:http.Error(w,"Operations busy; retry shortly",503);return}
    ctx,cancel:=context.WithTimeout(r.Context(),5*time.Second);defer cancel();r=r.WithContext(ctx)
    if r.Method=="POST"{
        origins:=r.Header.Values("Origin")
        if len(origins)!=1||origins[0]!=h.origin {http.Error(w,"Request not accepted",403);return}
        if len(r.Header.Values("Content-Type"))!=1||r.Header.Get("Content-Type")!="application/x-www-form-urlencoded"{http.Error(w,"Form required",415);return}
        r.Body=http.MaxBytesReader(w,r.Body,64<<10)
        if err:=r.ParseForm();err!=nil {http.Error(w,"Invalid form",400);return}
        for _,v:=range r.PostForm{if len(v)!=1{http.Error(w,"Invalid form",400);return}}
    }
    if r.URL.Path=="/style.css"&&r.Method=="GET"{w.Header().Set("Content-Type","text/css; charset=utf-8");_,_=w.Write([]byte(styles));return}
    if r.URL.Path=="/login"{h.login(w,r);return}
    cookie,err:=singleCookie(r,h.cookieName)
    if err!=nil||!validToken(cookie.Value){http.Redirect(w,r,"/login",303);return}
    principal,err:=h.store.Authenticate(ctx,digest("session",cookie.Value),h.now())
    if err!=nil{if errors.Is(err,ErrCredentials){h.clearCookie(w,h.cookieName);http.Redirect(w,r,"/login",303)}else{http.Error(w,"Private operations unavailable",503)};return}
    if r.Method=="POST"&&subtle.ConstantTimeCompare([]byte(csrf(cookie.Value)),[]byte(r.PostForm.Get("csrf")))!=1{
        _=h.audit(ctx,principal,"csrf_rejected","","", "denied");http.Error(w,"Request not accepted",403);return
    }
    data:=pageData{Username:principal.Username,CSRF:csrf(cookie.Value),CanReview:CanReview(principal.Roles),CanBill:CanBill(principal.Roles)&&h.billing!=nil,CanGrieve:CanGrieve(principal.Roles)&&h.operations!=nil,CanPrivacy:CanGrieve(principal.Roles)&&h.privacy!=nil,CanOperate:CanOperate(principal.Roles)&&h.observability!=nil,CanAudit:hasRole(principal.Roles,Owner),CanExport:CanExport(principal.Roles)}
    data.CanAdmission=hasRole(principal.Roles,Owner)&&h.admission!=nil
    if r.URL.Path=="/logout"&&r.Method=="POST"{
        if err=h.store.Logout(ctx,digest("session",cookie.Value),principal,h.now());err!=nil{http.Error(w,"Private operations unavailable",503);return}
        h.exports.revoke(digest("session",cookie.Value));h.clearCookie(w,h.cookieName);http.Redirect(w,r,"/login",303);return
    }
    if r.URL.Path=="/"&&r.Method=="GET"{data.Page="home";h.render(w,data);return}
    if r.URL.Path=="/billing"||strings.HasPrefix(r.URL.Path,"/billing/"){h.serveBilling(w,r,principal,cookie.Value,data);return}
    if h.serveOperations(w,r,principal,cookie.Value,data){return}
    if r.URL.Path=="/exports/download"{h.downloadExport(w,r,principal,cookie.Value);return}
    if !strings.HasPrefix(r.URL.Path,"/cases"){http.NotFound(w,r);return}
    if !CanReview(principal.Roles){_ = h.audit(ctx,principal,"case_access","","Role does not permit case access","denied");http.Error(w,"This role does not permit case access",403);return}
    if r.URL.Path=="/cases"&&r.Method=="GET"{
        cases,err:=h.backend.CaseList(ctx,100)
        if err!=nil{_=h.audit(ctx,principal,"case_list","","Triage worklist","failed");http.Error(w,"Cases unavailable",503);return}
        if err=h.auditView(ctx,principal,cookie.Value,"cases","case_list","","Triage worklist");err!=nil{http.Error(w,"Audit unavailable",503);return}
        data.Page="cases";data.Cases=cases;h.render(w,data);return
    }
    pieces:=strings.Split(strings.TrimPrefix(r.URL.Path,"/cases/"),"/")
    if len(pieces)<1||len(pieces)>2||!validReference(pieces[0]){http.NotFound(w,r);return}
    ref:=pieces[0];data.Ref=ref
    if len(pieces)==1&&r.Method=="GET"{data.Page="access";h.render(w,data);return}
    if len(pieces)!=2||r.Method!="POST"{http.NotFound(w,r);return}
    reason:=r.PostForm.Get("reason")
    if !validReason(reason){http.Error(w,"Give a review reason of 5–1000 characters",400);return}
    if pieces[1]=="export"{h.prepareExport(w,r,principal,cookie.Value,ref,reason,data);return}
    if pieces[1]=="evidence"{
        if !strictFields(r.PostForm,"csrf","reason"){http.Error(w,"Invalid form",400);return}
        detail,err:=h.backend.CaseDetail(ctx,ref)
        if err!=nil{_=h.audit(ctx,principal,"case_evidence",ref,reason,"failed");http.Error(w,"Case unavailable",503);return}
        if detail.Ref!=ref{http.Error(w,"Case unavailable",503);return}
        // Do not send one byte of evidence until its audit commit succeeds.
        if err=h.auditView(ctx,principal,cookie.Value,"cases","case_evidence",ref,reason);err!=nil{http.Error(w,"Audit unavailable",503);return}
        data.Page="detail";data.Case=detail;h.render(w,data);return
    }
    if pieces[1]=="action"{
        if !strictFields(r.PostForm,"csrf","reason","action","version","hours"){http.Error(w,"Invalid form",400);return}
        action:=r.PostForm.Get("action")
        if !canAction(principal.Roles,action){_=h.audit(ctx,principal,"case_action",ref,reason,"denied");http.Error(w,"Action not permitted",403);return}
        version,err:=strconv.ParseInt(r.PostForm.Get("version"),10,64);if err!=nil||version<1{http.Error(w,"Invalid case version",400);return}
        input:=safety.AdminAction{AdminID:principal.ID,AdminGeneration:principal.Generation,AdminSessionHash:digest("session",cookie.Value),CaseRef:ref,Action:action,Reason:reason,ExpectedVersion:version}
        if action=="suspend"{hours,e:=strconv.Atoi(r.PostForm.Get("hours"));if e!=nil||hours<1||hours>720{http.Error(w,"Suspension must be 1–720 hours",400);return};until:=h.now().Add(time.Duration(hours)*time.Hour);input.Until=&until}
        // Backend transaction checks case version and writes action+audit together.
        if _,err=h.backend.ApplyAction(ctx,input);err!=nil{_=h.audit(ctx,principal,"case_"+action,ref,reason,"failed");http.Error(w,"Action not completed; reopen the case and verify its latest state before retrying",409);return}
        http.Redirect(w,r,"/cases/"+ref,303);return
    }
    http.NotFound(w,r)
}

func(h *Handler)login(w http.ResponseWriter,r *http.Request){
    if r.Method=="GET"{
        token,err:=secret();if err!=nil{http.Error(w,"Private operations unavailable",503);return}
        h.setCookie(w,h.preCookieName,token,10*time.Minute);h.render(w,pageData{Page:"login",CSRF:csrf(token)});return
    }
    cookie,err:=singleCookie(r,h.preCookieName)
    if err!=nil||!validToken(cookie.Value)||subtle.ConstantTimeCompare([]byte(csrf(cookie.Value)),[]byte(r.PostForm.Get("csrf")))!=1{http.Error(w,"Login form expired; reload",403);return}
    name:=strings.ToLower(strings.TrimSpace(r.PostForm.Get("username")))
    host,_,err:=net.SplitHostPort(r.RemoteAddr);if err!=nil{host=r.RemoteAddr}
    if !h.limit.allow(host,name,h.now()){http.Error(w,"Too many login attempts; retry later",429);return}
    c,findErr:=h.store.FindCredentials(r.Context(),name)
    hash:=h.dummyHash;if findErr==nil{hash=c.PasswordHash}
    ok,verifyErr:=h.hasher.Verify(r.Context(),hash,r.PostForm.Get("password"))
    fail:=func(){_=h.audit(r.Context(),Principal{},"login","","Credentials not accepted","denied");http.Error(w,"Credentials not accepted",401)}
    if findErr!=nil||verifyErr!=nil||!ok||!validUsername(name){fail();return}
    raw,err:=decryptMFA(h.key,c.ID,c.TOTPCiphertext);if err!=nil{http.Error(w,"Private operations unavailable",503);return}
    counter,ok:=verifyTOTP(raw,r.PostForm.Get("code"),h.now(),c.LastCounter)
    clear(raw)
    if !ok{fail();return}
    token,err:=secret();if err!=nil{http.Error(w,"Private operations unavailable",503);return}
    if err=h.store.CreateSession(r.Context(),SessionInput{Credentials:c,Counter:counter,TokenHash:digest("session",token),At:h.now()});err!=nil{fail();return}
    h.clearCookie(w,h.preCookieName);h.setCookie(w,h.cookieName,token,4*time.Hour);http.Redirect(w,r,"/",303)
}

func(h *Handler)audit(ctx context.Context,p Principal,action,ref,reason,result string)error{return h.store.Audit(ctx,Audit{AdminID:p.ID,Action:action,SubjectRef:ref,Reason:reason,Result:result,At:h.now()})}
func(h *Handler)setCookie(w http.ResponseWriter,name,value string,ttl time.Duration){http.SetCookie(w,&http.Cookie{Name:name,Value:value,Path:"/",Secure:h.secure,HttpOnly:true,SameSite:http.SameSiteStrictMode,MaxAge:int(ttl.Seconds()),Expires:h.now().Add(ttl)})}
func(h *Handler)clearCookie(w http.ResponseWriter,name string){http.SetCookie(w,&http.Cookie{Name:name,Value:"",Path:"/",Secure:h.secure,HttpOnly:true,SameSite:http.SameSiteStrictMode,MaxAge:-1,Expires:time.Unix(1,0)})}
func singleCookie(r *http.Request,name string)(*http.Cookie,error){var found *http.Cookie;for _,cookie:=range r.Cookies(){if cookie.Name==name{if found!=nil{return nil,ErrCredentials};found=cookie}};if found==nil{return nil,ErrCredentials};return found,nil}
func validReference(v string)bool{if len(v)<16||len(v)>128{return false};for _,r:=range v{if !(r>='a'&&r<='z'||r>='A'&&r<='Z'||r>='0'&&r<='9'||r=='-'||r=='_'){return false}};return true}
func(h *Handler)render(w http.ResponseWriter,data pageData){w.Header().Set("Content-Type","text/html; charset=utf-8");_ = pages.Execute(w,data)}

type pageData struct { Page,Username,CSRF,Ref string; CanReview,CanBill,CanGrieve,CanPrivacy,CanOperate,CanAudit,CanExport,CanAdmission bool; Admission admission.State; Operations operationsPage; Export exportPage; Cases []safety.CaseSummary; Case safety.CaseDetail; Billing billingPage }
var pages=template.Must(template.New("admin").Funcs(template.FuncMap{"requestKey":billingRequestKey}).Parse(markup+billingMarkup+operationsMarkup+exportMarkup+admissionMarkup+metricsMarkup))
