package admin

import (
    "context"
    "errors"
    "net/http/httptest"
    "net/url"
    "regexp"
    "strconv"
    "strings"
    "testing"
    "time"

    "notitle/internal/billing"
)

func(s *fakeStore)AuditBillingView(ctx context.Context,p Principal,hash [32]byte,a Audit)error{if p.ID!=s.p.ID||p.Generation!=s.p.Generation||!CanBill(s.p.Roles)||hash!=digest("session",strings.Repeat("A",43)){return ErrForbidden};return s.Audit(ctx,a)}

type fakeBilling struct {
    reads,previews,refunds,disputes,reviews int
    detail billing.AdminOrderDetail
    preview billing.RefundPreview
    refund billing.RefundRequest
    dispute billing.DisputeInput
    review billing.AdminReviewAction
    mutationErr error
    afterRead func()
}
func(b *fakeBilling)AdminOrders(context.Context,int)([]billing.Order,error){b.reads++;return []billing.Order{b.detail.Order},nil}
func(b *fakeBilling)AdminOrder(context.Context,string)(billing.AdminOrderDetail,error){b.reads++;if b.afterRead!=nil{b.afterRead()};return b.detail,nil}
func(b *fakeBilling)ListReview(context.Context,int)([]billing.AdminReview,error){b.reads++;return nil,nil}
func(b *fakeBilling)AdminDisputes(context.Context,int)([]billing.AdminDispute,error){b.reads++;return nil,nil}
func(b *fakeBilling)PreviewRefund(context.Context,string,string,time.Time)(billing.RefundPreview,error){b.previews++;return b.preview,nil}
func(b *fakeBilling)CreateRefund(_ context.Context,in billing.RefundRequest,_ time.Time)(billing.Refund,error){b.refunds++;b.refund=in;if b.mutationErr!=nil{return billing.Refund{},b.mutationErr};return billing.Refund{Ref:strings.Repeat("f",32),OrderRef:in.OrderRef,PaymentID:in.PaymentID,AmountPaise:in.AmountPaise,Treatment:in.Treatment,Status:"pending"},nil}
func(b *fakeBilling)RecordDispute(_ context.Context,in billing.DisputeInput,_ time.Time)error{b.disputes++;b.dispute=in;return b.mutationErr}
func(b *fakeBilling)ReviewAction(_ context.Context,in billing.AdminReviewAction,_ time.Time)error{b.reviews++;b.review=in;return b.mutationErr}
func billingHandler(t *testing.T,role string)(*Handler,*fakeStore,*fakeBilling){
    t.Helper();h,s,_,_:=newTestHandler(t,[]string{role});ref:=strings.Repeat("p",32)
    b:=&fakeBilling{detail:billing.AdminOrderDetail{Order:billing.Order{Ref:ref,Plan:billing.Plan{Name:"Restricted purchase"}}},preview:billing.RefundPreview{OrderRef:ref,PaymentID:"123456",CapturedPaise:9900,RefundablePaise:9900,AvailableSeconds:259200,Revision:4}}
    h.billing=b;return h,s,b
}
func refundForm()url.Values{return url.Values{"csrf":{testCSRF()},"reason":{"Correct duplicate capture"},"payment_id":{"123456"},"idempotency_key":{strings.Repeat("k",32)},"amount_paise":{"9900"},"treatment":{"full"},"reduce_seconds":{"0"}}}
func refundConfirmation(t *testing.T,h *Handler)url.Values{
    t.Helper();w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/billing/orders/"+strings.Repeat("p",32)+"/refund-preview",refundForm()));if w.Code!=200{t.Fatal("preview failed",w.Code)}
    values:=refundForm();for _,name:=range []string{"version","approval","approval_expires"}{m:=regexp.MustCompile(`name="`+name+`" value="([^"]*)"`).FindStringSubmatch(w.Body.String());if len(m)!=2{t.Fatal("confirmation field missing")};values.Set(name,m[1])};return values
}

func TestBillingEveryRouteRejectsUnassignedRoles(t *testing.T){
    paths:=[]string{"/billing","/billing/worklist","/billing/orders/"+strings.Repeat("p",32)+"/detail","/billing/orders/"+strings.Repeat("p",32)+"/refund-preview","/billing/orders/"+strings.Repeat("p",32)+"/refund","/billing/orders/"+strings.Repeat("p",32)+"/dispute","/billing/reviews/"+strings.Repeat("r",32)}
    for _,role:=range []string{Moderator,GrievanceOfficer,OperationsReadonly}{for _,path:=range paths{h,_,b:=billingHandler(t,role);w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST",path,refundForm()));if w.Code!=403||b.reads+b.previews+b.refunds+b.disputes+b.reviews!=0{t.Fatal("billing role boundary failed")}}}
}
func TestBillingSensitiveViewsRequireAuditBeforeOutput(t *testing.T){
    for _,path:=range []string{"/billing/worklist","/billing/orders/"+strings.Repeat("p",32)+"/detail"}{h,s,_:=billingHandler(t,BillingOperator);s.auditFail=true;w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST",path,url.Values{"csrf":{testCSRF()},"reason":{"Reconcile purchase records"}}));if w.Code!=503||strings.Contains(w.Body.String(),"Restricted purchase"){t.Fatal("unaudited financial content disclosed")}}
}
func TestBillingReceiptEscapesUntrustedTextAndOmitsCheckout(t *testing.T){
    h,s,b:=billingHandler(t,BillingOperator);b.detail.Order.Plan.Name=`<script>danger</script>`;b.detail.Order.CheckoutSession="must-not-be-rendered"
    w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/billing/orders/"+strings.Repeat("p",32)+"/detail",url.Values{"csrf":{testCSRF()},"reason":{"Reconcile purchase records"}}))
    if w.Code!=200||strings.Contains(w.Body.String(),"<script>")||!strings.Contains(w.Body.String(),"&lt;script&gt;")||strings.Contains(w.Body.String(),"must-not-be-rendered"){t.Fatal("financial view escaped/private projection failed")}
    if len(s.audits)!=1||s.audits[0].Action!="billing_order"||s.audits[0].Result!="success"{t.Fatal("view audit missing")}
}
func TestRefundConfirmationPreservesTrustedActorAndExactPreview(t *testing.T){
    h,s,b:=billingHandler(t,BillingOperator);form:=refundConfirmation(t,h);w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/billing/orders/"+strings.Repeat("p",32)+"/refund",form))
    if w.Code!=200||b.refunds!=1||b.refund.ActorID!=s.p.ID||b.refund.AdminGeneration!=s.p.Generation||b.refund.AdminSessionHash!=digest("session",strings.Repeat("A",43))||b.refund.ExpectedRevision!=4||b.refund.AmountPaise!=9900{t.Fatal("refund lost scoped transaction guard")}
    if !strings.Contains(w.Body.String(),"not bank credit")||!strings.Contains(w.Body.String(),"pending"){t.Fatal("refund result falsely promises bank credit")}
}
func TestRefundForgedConfirmationAndAuthorityNeverReachMutation(t *testing.T){
    for _,mode:=range []string{"amount","seconds","treatment","payment","order","version","operator","csrf","origin","expiry","no_preview"}{
        h,_,b:=billingHandler(t,BillingOperator);form:=refundConfirmation(t,h);path:="/billing/orders/"+strings.Repeat("p",32)+"/refund"
        switch mode{case "amount":form.Set("amount_paise","9800");case "seconds":form.Set("reduce_seconds","1");case "treatment":form.Set("treatment","money_only");case "payment":form.Set("payment_id","999999");case "order":path="/billing/orders/"+strings.Repeat("x",32)+"/refund";case "version":form.Set("version","5");case "operator":form.Set("actor_id","forged");case "csrf":form.Set("csrf","wrong");case "expiry":form.Set("approval_expires",strconv.FormatInt(h.now().Unix(),10));case "no_preview":form.Del("approval")}
        request:=adminRequest("POST",path,form);if mode=="origin"{request.Header.Set("Origin","https://evil.example")};w:=httptest.NewRecorder();h.ServeHTTP(w,request)
        if w.Code<400||b.refunds!=0{t.Fatal("forged refund reached ledger",mode)}
    }
}
func TestRefundPreviewRefusesUnrelatedScopeAndOverdraw(t *testing.T){
    for _,mode:=range []string{"scope","payment","balance","full_after_partial","duration"}{h,_,b:=billingHandler(t,BillingOperator);form:=refundForm();switch mode{case "scope":b.preview.OrderRef=strings.Repeat("x",32);case "payment":b.preview.PaymentID="different";case "balance":form.Set("amount_paise","10000");case "full_after_partial":b.preview.RefundablePaise=9000;form.Set("amount_paise","9000");case "duration":form.Set("treatment","duration");form.Set("reduce_seconds","259201")};w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/billing/orders/"+strings.Repeat("p",32)+"/refund-preview",form));if w.Code<400||strings.Contains(w.Body.String(),"name=\"approval\""){t.Fatal("invalid preview issued")}}
}
func TestRefundDatabaseGuardAndUnknownOutcomesFailClosed(t *testing.T){
    for _,err:=range []error{billing.ErrUnauthorized,billing.ErrConflict,billing.ErrReview,errors.New("private provider failure")} {h,_,b:=billingHandler(t,BillingOperator);form:=refundConfirmation(t,h);b.mutationErr=err;w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/billing/orders/"+strings.Repeat("p",32)+"/refund",form));if w.Code<400||strings.Contains(w.Body.String(),"Refund request recorded")||strings.Contains(w.Body.String(),"private provider failure"){t.Fatal("unknown refund result exposed or marked complete")}}
}
func TestReviewFormScopesVersionAndOperatorAtCommit(t *testing.T){
    h,s,b:=billingHandler(t,Owner);values:=url.Values{"csrf":{testCSRF()},"reason":{"Verified provider reconciliation"},"version":{"3"},"idempotency_key":{strings.Repeat("k",32)},"action":{"resolve"}}
    w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/billing/reviews/"+strings.Repeat("r",32),values))
    if w.Code!=303||b.reviews!=1||b.review.ActorID!=s.p.ID||b.review.AdminGeneration!=s.p.Generation||b.review.AdminSessionHash!=digest("session",strings.Repeat("A",43))||b.review.ExpectedVersion!=3{t.Fatal("review scope guard not forwarded")}
    values.Set("action","grant_premium");w=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/billing/reviews/"+strings.Repeat("r",32),values));if w.Code!=403||b.reviews!=1{t.Fatal("review invented financial action")}
}
func TestDisputeFormScopesVersionAndRejectsForgedAuthority(t *testing.T){
    h,s,b:=billingHandler(t,BillingOperator);values:=url.Values{"csrf":{testCSRF()},"reason":{"Verified provider dispute notice"},"version":{"0"},"idempotency_key":{strings.Repeat("k",32)},"payment_id":{"123456"},"provider_dispute_id":{"dispute_123"},"status":{"open"},"response_due":{"2030-01-01T12:00:00Z"},"hold_access":{"true"}}
    w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/billing/orders/"+strings.Repeat("p",32)+"/dispute",values))
    if w.Code!=303||b.disputes!=1||b.dispute.ActorID!=s.p.ID||b.dispute.AdminGeneration!=s.p.Generation||b.dispute.AdminSessionHash!=digest("session",strings.Repeat("A",43))||b.dispute.ExpectedRevision!=0||!b.dispute.HoldAccess{t.Fatal("dispute guard not forwarded")}
    values.Set("actor_id","another-operator");w=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/billing/orders/"+strings.Repeat("p",32)+"/dispute",values));if w.Code!=400||b.disputes!=1{t.Fatal("forged dispute authority accepted")}
}

func TestBillingViewRevocationDuringReadPreventsDisclosure(t *testing.T){
    h,s,b:=billingHandler(t,BillingOperator);b.afterRead=func(){s.p.Roles=[]string{Moderator}}
    w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/billing/orders/"+strings.Repeat("p",32)+"/detail",url.Values{"csrf":{testCSRF()},"reason":{"Reconcile purchase records"}}))
    if w.Code!=503||strings.Contains(w.Body.String(),"Restricted purchase")||len(s.audits)!=0{t.Fatal("revoked billing role received delayed financial view")}
}
func TestRefundAfterIdentityErasureKeepsFinancialWorkflowAvailable(t *testing.T){
    h,_,b:=billingHandler(t,BillingOperator);b.preview.Revision=0;b.preview.AvailableSeconds=0
    values:=refundConfirmation(t,h);if values.Get("version")!="0"{t.Fatal("detached financial revision was invented")}
    w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/billing/orders/"+strings.Repeat("p",32)+"/refund",values))
    if w.Code!=200||b.refunds!=1||b.refund.ExpectedRevision!=0{t.Fatal("identity erasure blocked financial resolution")}
}
