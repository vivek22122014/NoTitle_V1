package admin

import (
    "context"
    "errors"
    "time"

    "github.com/jackc/pgx/v5"
)

func hasRole(roles []string,want string)bool{for _,role:=range roles{if role==want{return true}};return false}
func CanOperate(roles []string)bool{return hasRole(roles,Owner)||hasRole(roles,OperationsReadonly)}
func CanGrieve(roles []string)bool{return hasRole(roles,Owner)||hasRole(roles,GrievanceOfficer)}
func CanExport(roles []string)bool{return CanGrieve(roles)}

// Scope is server-selected; neither a URL nor a submitted role grants access.
func canView(roles []string,scope string)bool{
    if !ValidRoles(roles){return false}
    switch scope{case "cases":return CanReview(roles);case "export":return CanExport(roles);case "operations":return CanOperate(roles);case "audit","admission":return hasRole(roles,Owner);default:return false}
}
type viewAuditor interface{AuditView(context.Context,Principal,[32]byte,string,Audit)error}
func(h *Handler)auditView(ctx context.Context,p Principal,session,scope,action,ref,reason string)error{
    store,ok:=h.store.(viewAuditor);if !ok{return ErrUnavailable}
    return store.AuditView(ctx,p,digest("session",session),scope,Audit{AdminID:p.ID,Action:action,SubjectRef:ref,Reason:reason,Result:"success",At:h.now()})
}
func authorizeView(ctx context.Context,tx pgx.Tx,p Principal,hash [32]byte,scope string,now time.Time)error{
    var roles []string;var generation int64;var disabled bool
    err:=tx.QueryRow(ctx,`SELECT roles,generation,disabled FROM notitle.admin_users WHERE id=$1 FOR UPDATE`,p.ID).Scan(&roles,&generation,&disabled)
    if errors.Is(err,pgx.ErrNoRows){return ErrCredentials};if err!=nil{return ErrUnavailable}
    if disabled||generation!=p.Generation||!canView(roles,scope){return ErrForbidden}
    var active bool
    err=tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.admin_sessions WHERE token_hash=$1 AND admin_id=$2 AND admin_generation=$3 AND created_at<=$4 AND absolute_expires_at>$4 AND last_seen_at>$4-interval '15 minutes')`,hash[:],p.ID,p.Generation,now).Scan(&active)
    if err!=nil{return ErrUnavailable};if !active{return ErrCredentials};return nil
}
func(s *PostgresStore)AuditView(ctx context.Context,p Principal,hash [32]byte,scope string,a Audit)error{
    if p.ID==""||p.ID!=a.AdminID||p.Generation<1||!validReason(a.Reason)||a.Result!="success"{return ErrInvalid}
    valid:=scope=="cases"&&(a.Action=="case_list"||a.Action=="case_evidence")||scope=="export"&&(a.Action=="evidence_export_prepare"||a.Action=="evidence_export_download")||scope=="operations"&&a.Action=="operations_dashboard"
    valid=valid||scope=="admission"&&(a.Action=="admission_view"||a.Action=="admission_open_requested"||a.Action=="admission_drain_requested")
    valid=valid||scope=="operations"&&a.Action=="processing_metrics_export"
    if !valid{return ErrInvalid}
    tx,err:=s.db.Begin(ctx);if err!=nil{return ErrUnavailable};defer tx.Rollback(context.Background())
    if err=authorizeView(ctx,tx,p,hash,scope,a.At);err!=nil{return err}
    if err=writeAudit(ctx,tx,a);err!=nil{return err};if tx.Commit(ctx)!=nil{return ErrUnavailable};return nil
}

type AuditQuery struct{From,Until time.Time;Action,Result,SubjectRef,Reason string}
type AuditRecord struct{ID,AdminID,Action,SubjectRef,Reason,Result string;At time.Time}
type auditSearcher interface{SearchAudit(context.Context,Principal,[32]byte,AuditQuery,time.Time)([]AuditRecord,error)}
func validAuditQuery(q AuditQuery,now time.Time)bool{
    if !validReason(q.Reason)||q.From.IsZero()||!q.Until.After(q.From)||q.Until.Sub(q.From)>31*24*time.Hour||q.Until.After(now.Add(time.Minute)){return false}
    if q.SubjectRef!=""&&!validReference(q.SubjectRef){return false}
    if q.Result!=""&&q.Result!="success"&&q.Result!="denied"&&q.Result!="failed"{return false}
    if len(q.Action)>80{return false};for _,c:=range q.Action{if !(c>='a'&&c<='z'||c=='_'||c>='0'&&c<='9'){return false}};return true
}
func(s *PostgresStore)SearchAudit(ctx context.Context,p Principal,hash [32]byte,q AuditQuery,now time.Time)([]AuditRecord,error){
    if !validAuditQuery(q,now){return nil,ErrInvalid}
    tx,err:=s.db.Begin(ctx);if err!=nil{return nil,ErrUnavailable};defer tx.Rollback(context.Background())
    if err=authorizeView(ctx,tx,p,hash,"audit",now);err!=nil{return nil,err}
    rows,err:=tx.Query(ctx,`SELECT id::text,COALESCE(admin_id::text,''),action,COALESCE(subject_ref,''),reason,result,created_at FROM notitle.admin_audit WHERE created_at >= $1 AND created_at < $2 AND ($3='' OR action=$3) AND ($4='' OR result=$4) AND ($5='' OR subject_ref=$5) ORDER BY created_at DESC,id DESC LIMIT 200`,q.From,q.Until,q.Action,q.Result,q.SubjectRef)
    if err!=nil{return nil,ErrUnavailable};result:=[]AuditRecord{}
    for rows.Next(){var record AuditRecord;if rows.Scan(&record.ID,&record.AdminID,&record.Action,&record.SubjectRef,&record.Reason,&record.Result,&record.At)!=nil{rows.Close();return nil,ErrUnavailable};result=append(result,record)};err=rows.Err();rows.Close();if err!=nil{return nil,ErrUnavailable}
    if err=writeAudit(ctx,tx,Audit{AdminID:p.ID,Action:"audit_search",SubjectRef:q.SubjectRef,Reason:q.Reason,Result:"success",At:now});err!=nil{return nil,err};if tx.Commit(ctx)!=nil{return nil,ErrUnavailable};return result,nil
}
