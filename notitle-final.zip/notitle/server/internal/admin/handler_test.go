package admin

import (
    "context"
    "errors"
    "net/http"
    "net/http/httptest"
    "net/url"
    "strings"
    "testing"
    "time"

    "notitle/internal/safety"
)

type fakeStore struct { p Principal; audits []Audit; auditFail bool; credential Credentials; createCount int }
func(s *fakeStore)FindCredentials(context.Context,string)(Credentials,error){return s.credential,nil}
func(s *fakeStore)CreateSession(_ context.Context,in SessionInput)error{if in.Counter<=s.credential.LastCounter{return ErrCredentials};s.credential.LastCounter=in.Counter;s.createCount++;return nil}
func(s *fakeStore)Authenticate(context.Context,[32]byte,time.Time)(Principal,error){return s.p,nil}
func(s *fakeStore)Logout(context.Context,[32]byte,Principal,time.Time)error{return nil}
func(s *fakeStore)Audit(_ context.Context,a Audit)error{s.audits=append(s.audits,a);if s.auditFail{return ErrUnavailable};return nil}
type fakeHasher struct{ verifies int }
func(h *fakeHasher)Hash(context.Context,string)(string,error){return "hash",nil}
func(h *fakeHasher)Verify(context.Context,string,string)(bool,error){h.verifies++;return true,nil}
type fakeBackend struct { reads,actions int; detail safety.CaseDetail; afterRead func() }
func(b *fakeBackend)CaseList(context.Context,int)([]safety.CaseSummary,error){return nil,nil}
func(b *fakeBackend)CaseDetail(context.Context,string)(safety.CaseDetail,error){b.reads++;if b.afterRead!=nil{b.afterRead()};return b.detail,nil}
func(b *fakeBackend)ApplyAction(context.Context,safety.AdminAction)(safety.ActionResult,error){b.actions++;return safety.ActionResult{},nil}

func newTestHandler(t *testing.T,roles []string)(*Handler,*fakeStore,*fakeBackend,*fakeHasher){
    t.Helper();store:=&fakeStore{p:Principal{ID:"d1a8df17-88cb-4136-ac04-dfa7bd853f22",Username:"reviewer",Roles:roles,Generation:1}}
    backend:=&fakeBackend{detail:safety.CaseDetail{CaseSummary:safety.CaseSummary{Ref:strings.Repeat("r",32),Version:1},Evidence:[]safety.CaseEvidence{{Kind:"statement",Speaker:"reporter",Text:`<script>alert("evidence")</script>`}}}}
    hasher:=&fakeHasher{};h,err:=New(Options{Store:store,Backend:backend,Hasher:hasher,Key:[]byte(strings.Repeat("k",32)),Origin:"https://ops.example.test",Now:func()time.Time{return time.Unix(1234567890,0)}});if err!=nil{t.Fatal(err)};return h,store,backend,hasher
}
func adminRequest(method,path string,values url.Values)*http.Request{
    var body string;if values!=nil{body=values.Encode()}
    r:=httptest.NewRequest(method,"https://ops.example.test"+path,strings.NewReader(body));r.Header.Set("Origin","https://ops.example.test");r.Header.Set("Content-Type","application/x-www-form-urlencoded");r.AddCookie(&http.Cookie{Name:"__Host-notitle_admin",Value:strings.Repeat("A",43)});return r
}
func testCSRF()string{return csrf(strings.Repeat("A",43))}

func TestPrivateEvidenceEscapesAndAudits(t *testing.T){
    h,store,backend,_:=newTestHandler(t,[]string{Moderator})
    request:=adminRequest("POST","/cases/"+strings.Repeat("r",32)+"/evidence",url.Values{"csrf":{testCSRF()},"reason":{"Review harassment complaint"}})
    recorder:=httptest.NewRecorder();h.ServeHTTP(recorder,request)
    if recorder.Code!=200||backend.reads!=1{t.Fatalf("status %d reads %d",recorder.Code,backend.reads)}
    body:=recorder.Body.String();if strings.Contains(body,"<script>")||!strings.Contains(body,"&lt;script&gt;"){t.Fatal("evidence not escaped")}
    if len(store.audits)!=1||store.audits[0].Action!="case_evidence"||store.audits[0].Result!="success"{t.Fatal("audit missing")}
    if recorder.Header().Get("Cache-Control")!="no-store"||recorder.Header().Get("Referrer-Policy")!="no-referrer"{t.Fatal("privacy headers missing")}
}

func TestEvidenceFailsClosedWhenAuditUnavailable(t *testing.T){
    h,store,_,_:=newTestHandler(t,[]string{Moderator});store.auditFail=true
    recorder:=httptest.NewRecorder();h.ServeHTTP(recorder,adminRequest("POST","/cases/"+strings.Repeat("r",32)+"/evidence",url.Values{"csrf":{testCSRF()},"reason":{"Review complaint"}}))
    if recorder.Code!=503||strings.Contains(recorder.Body.String(),"evidence") {t.Fatal("sensitive content delivered without audit")}
}

func TestBillingAndReadonlyCannotReadCases(t *testing.T){
    for _,role:=range []string{BillingOperator,OperationsReadonly}{h,_,backend,_:=newTestHandler(t,[]string{role});recorder:=httptest.NewRecorder();h.ServeHTTP(recorder,adminRequest("POST","/cases/"+strings.Repeat("r",32)+"/evidence",url.Values{"csrf":{testCSRF()},"reason":{"Review complaint"}}));if recorder.Code!=403||backend.reads!=0{t.Fatal("role leaked evidence",role)}}
}

func TestOriginCSRFAndVersionBeforeMutation(t *testing.T){
    for _,mode:=range []string{"origin","csrf","version"}{h,_,backend,_:=newTestHandler(t,[]string{Owner});values:=url.Values{"csrf":{testCSRF()},"reason":{"Review complaint"},"action":{"resolve"},"version":{"1"}};if mode=="csrf"{values.Set("csrf","incorrect")};if mode=="version"{values.Set("version","0")};request:=adminRequest("POST","/cases/"+strings.Repeat("r",32)+"/action",values);if mode=="origin"{request.Header.Set("Origin","https://evil.example")};recorder:=httptest.NewRecorder();h.ServeHTTP(recorder,request);if recorder.Code<400||backend.actions!=0{t.Fatal("mutation before guard",mode)}}
}

func TestLoginMFAAndRateBudget(t *testing.T){
    h,store,_,hasher:=newTestHandler(t,[]string{Owner});raw:=[]byte("12345678901234567890");encrypted,err:=encryptMFA(h.key,store.p.ID,raw);if err!=nil{t.Fatal(err)}
    store.credential=Credentials{ID:store.p.ID,Username:"reviewer",PasswordHash:"hash",TOTPCiphertext:encrypted,Generation:1,LastCounter:-1}
    run:=func(code string)*httptest.ResponseRecorder{r:=adminRequest("POST","/login",url.Values{"csrf":{testCSRF()},"username":{"reviewer"},"password":{"secretlongpassword"},"code":{code}});r.AddCookie(&http.Cookie{Name:h.preCookieName,Value:strings.Repeat("A",43)});w:=httptest.NewRecorder();h.ServeHTTP(w,r);return w}
    code:=totp(raw,h.now().Unix()/30,6);first:=run(code);if first.Code!=303||store.createCount!=1{t.Fatal("valid MFA login failed")}
    var session *http.Cookie;for _,c:=range first.Result().Cookies(){if c.Name==h.cookieName{session=c}}
    if session==nil||!session.Secure||!session.HttpOnly||session.SameSite!=http.SameSiteStrictMode||session.Domain!=""{t.Fatal("cookie attributes")}
    if run(code).Code!=401||store.createCount!=1{t.Fatal("replayed MFA accepted")}
    for i:=0;i<6;i++{run("000000")};before:=hasher.verifies;if run("000000").Code!=429||hasher.verifies!=before{t.Fatal("rate limit after hash")}
}

func TestOriginConfiguration(t *testing.T){
    h,store,backend,hasher:=newTestHandler(t,[]string{Owner})
    for _,origin:=range []string{"http://ops.example.test","https://ops.example.test/path","https://user@ops.example.test","https://ops.example.test?x=1"}{if _,err:=New(Options{Store:store,Backend:backend,Hasher:hasher,Key:h.key,Origin:origin,AllowInsecureLocalhost:true});!errors.Is(err,ErrInvalid){t.Fatal(origin)}}
}

func TestDuplicateAuthorityAndCredentialInputsRejected(t *testing.T){
    for _,mode:=range []string{"origin","content_type","session_cookie","preauth_cookie","empty_query"}{
        h,_,backend,_:=newTestHandler(t,[]string{Moderator})
        r:=adminRequest("POST","/cases/"+strings.Repeat("r",32)+"/evidence",url.Values{"csrf":{testCSRF()},"reason":{"Review complaint"}})
        if mode=="origin"{r.Header.Add("Origin","https://ops.example.test")}
        if mode=="content_type"{r.Header.Add("Content-Type","application/x-www-form-urlencoded")}
        if mode=="session_cookie"{r.AddCookie(&http.Cookie{Name:h.cookieName,Value:strings.Repeat("A",43)})}
        if mode=="preauth_cookie"{r.URL.Path="/login";r.AddCookie(&http.Cookie{Name:h.preCookieName,Value:strings.Repeat("A",43)});r.AddCookie(&http.Cookie{Name:h.preCookieName,Value:strings.Repeat("A",43)})}
        if mode=="empty_query"{r.URL.ForceQuery=true}
        recorder:=httptest.NewRecorder();h.ServeHTTP(recorder,r)
        if recorder.Code==200||backend.reads!=0{t.Fatal("ambiguous request accepted",mode)}
    }
}

func TestModerationRoleRevocationDuringReadPreventsEvidenceRelease(t *testing.T){
    h,s,b,_:=newTestHandler(t,[]string{Moderator});b.afterRead=func(){s.p.Roles=[]string{BillingOperator}}
    w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/cases/"+strings.Repeat("r",32)+"/evidence",url.Values{"csrf":{testCSRF()},"reason":{"Review complaint"}}))
    if w.Code!=503||strings.Contains(w.Body.String(),"script")||len(s.audits)!=0{t.Fatal("revoked moderation role received evidence")}
}
