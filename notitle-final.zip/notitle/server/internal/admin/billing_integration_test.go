package admin

import (
    "errors"
    "strings"
    "testing"
    "time"

    "notitle/internal/billing"
)

func TestIntegrationBillingViewAuditRechecksSessionAndRole(t *testing.T){
    store,migration,ctx:=adminIntegration(t);now:=time.Now().UTC().Truncate(time.Microsecond);c:=fixtureAdmin(t,ctx,migration,now);hash:=digest("test",c.ID)
    if _,err:=migration.Exec(ctx,`UPDATE notitle.admin_users SET roles=ARRAY['billing_operator'] WHERE id=$1`,c.ID);err!=nil{t.Fatal(err)}
    if err:=store.CreateSession(ctx,SessionInput{Credentials:c,Counter:now.Unix()/30,TokenHash:hash,At:now});err!=nil{t.Fatal(err)}
    p:=Principal{ID:c.ID,Generation:1,Roles:[]string{BillingOperator}};a:=Audit{AdminID:c.ID,Action:"billing_order",SubjectRef:strings.Repeat("p",32),Reason:"Investigate verified payment",Result:"success",At:now}
    if err:=store.AuditBillingView(ctx,p,hash,a);err!=nil{t.Fatal("authorized audited view",err)}
    if err:=store.AuditBillingView(ctx,p,digest("test","wrong-session"),a);!errors.Is(err,ErrCredentials){t.Fatal("wrong-session financial view authorized")}
    if _,err:=migration.Exec(ctx,`UPDATE notitle.admin_users SET roles=ARRAY['moderator'] WHERE id=$1`,c.ID);err!=nil{t.Fatal(err)}
    if err:=store.AuditBillingView(ctx,p,hash,a);!errors.Is(err,ErrForbidden){t.Fatal("role-revoked financial view authorized")}
    var count int;if err:=store.db.QueryRow(ctx,`SELECT count(*) FROM notitle.admin_audit WHERE admin_id=$1 AND action='billing_order'`,c.ID).Scan(&count);err!=nil||count!=1{t.Fatal("invalid billing view audit committed")}
}

func TestIntegrationBillingReviewVersionIdempotencyAndAtomicAudit(t *testing.T){
    store,migration,ctx:=adminIntegration(t);now:=time.Now().UTC().Truncate(time.Microsecond);c:=fixtureAdmin(t,ctx,migration,now);hash:=digest("test",c.ID)
    if _,err:=migration.Exec(ctx,`UPDATE notitle.admin_users SET roles=ARRAY['billing_operator'] WHERE id=$1`,c.ID);err!=nil{t.Fatal(err)}
    if err:=store.CreateSession(ctx,SessionInput{Credentials:c,Counter:now.Unix()/30,TokenHash:hash,At:now});err!=nil{t.Fatal(err)}
    ref:="review_"+strings.ReplaceAll(c.ID,"-","");if _,err:=migration.Exec(ctx,`INSERT INTO notitle.billing_review_cases(ref,kind,environment,created_at) VALUES($1,$1,'sandbox',$2)`,ref,now);err!=nil{t.Fatal(err)}
    ledger:=billing.NewPostgresStore(store.db,billing.Options{Environment:billing.Test,MerchantID:"fixture_merchant"})
    in:=billing.AdminReviewAction{ActorID:c.ID,AdminGeneration:1,AdminSessionHash:hash,Ref:ref,Action:"note",Reason:"Verified provider event under review",IdempotencyKey:"reviewkey_"+strings.ReplaceAll(c.ID,"-",""),ExpectedVersion:1}
    if err:=ledger.ReviewAction(ctx,in,now);err!=nil{t.Fatal("review failed",err)}
    if err:=ledger.ReviewAction(ctx,in,now.Add(time.Second));err!=nil{t.Fatal("identical retry failed",err)}
    changed:=in;changed.Reason="Different economic reasoning";if err:=ledger.ReviewAction(ctx,changed,now);!errors.Is(err,billing.ErrConflict){t.Fatal("same key accepted different decision")}
    stale:=in;stale.IdempotencyKey+="_stale";if err:=ledger.ReviewAction(ctx,stale,now);!errors.Is(err,billing.ErrConflict){t.Fatal("stale review version accepted")}
    var revision,audits,actions int64
    if err:=store.db.QueryRow(ctx,`SELECT revision FROM notitle.billing_review_cases WHERE ref=$1`,ref).Scan(&revision);err!=nil{t.Fatal(err)}
    if err:=store.db.QueryRow(ctx,`SELECT count(*) FROM notitle.admin_audit WHERE admin_id=$1 AND action='billing_review_note'`,c.ID).Scan(&audits);err!=nil{t.Fatal(err)}
    if err:=store.db.QueryRow(ctx,`SELECT count(*) FROM notitle.billing_review_actions WHERE case_ref=$1`,ref).Scan(&actions);err!=nil{t.Fatal(err)}
    if revision!=2||audits!=1||actions!=1{t.Fatal("review/action/audit or retry not atomic")}
    if _,err:=store.db.Exec(ctx,`UPDATE notitle.billing_review_actions SET reason='tampered' WHERE case_ref=$1`,ref);err==nil{t.Fatal("runtime rewrote immutable review action")}
    if _,err:=migration.Exec(ctx,`UPDATE notitle.admin_users SET roles=ARRAY['operations_readonly'] WHERE id=$1`,c.ID);err!=nil{t.Fatal(err)}
    changed=in;changed.ExpectedVersion=2;changed.IdempotencyKey+="_new";if err:=ledger.ReviewAction(ctx,changed,now);!errors.Is(err,billing.ErrUnauthorized){t.Fatal("role change bypassed financial transaction guard")}
}

func TestIntegrationBillingReviewCannotCrossEnvironment(t *testing.T){
    store,migration,ctx:=adminIntegration(t);now:=time.Now().UTC().Truncate(time.Microsecond);c:=fixtureAdmin(t,ctx,migration,now);hash:=digest("test",c.ID)
    if _,err:=migration.Exec(ctx,`UPDATE notitle.admin_users SET roles=ARRAY['billing_operator'] WHERE id=$1`,c.ID);err!=nil{t.Fatal(err)}
    if err:=store.CreateSession(ctx,SessionInput{Credentials:c,Counter:now.Unix()/30,TokenHash:hash,At:now});err!=nil{t.Fatal(err)}
    ref:="review_"+strings.ReplaceAll(c.ID,"-","");if _,err:=migration.Exec(ctx,`INSERT INTO notitle.billing_review_cases(ref,kind,environment,created_at) VALUES($1,$1,'production',$2)`,ref,now);err!=nil{t.Fatal(err)}
    ledger:=billing.NewPostgresStore(store.db,billing.Options{Environment:billing.Test,MerchantID:"fixture_merchant"})
    in:=billing.AdminReviewAction{ActorID:c.ID,AdminGeneration:1,AdminSessionHash:hash,Ref:ref,Action:"resolve",Reason:"Verified provider reconciliation",IdempotencyKey:"reviewkey_"+strings.ReplaceAll(c.ID,"-",""),ExpectedVersion:1}
    if err:=ledger.ReviewAction(ctx,in,now);!errors.Is(err,billing.ErrNotFound){t.Fatal("test operator endpoint mutated production review")}
    cases,err:=ledger.ListReview(ctx,100);if err!=nil{t.Fatal(err)};for _,c:=range cases{if c.Ref==ref{t.Fatal("production review leaked into test worklist")}}
}
