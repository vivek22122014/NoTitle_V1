package admin

import (
    "context"
    "net/http/httptest"
    "net/url"
    "strings"
    "testing"
    "time"

    "notitle/internal/observability"
    "notitle/internal/operations"
    "notitle/internal/privacy"
)

func(s *fakeStore)AuditView(ctx context.Context,p Principal,hash [32]byte,scope string,a Audit)error{if p.ID!=s.p.ID||p.Generation!=s.p.Generation||!canView(s.p.Roles,scope)||hash!=digest("session",strings.Repeat("A",43)){return ErrForbidden};return s.Audit(ctx,a)}
func(s *fakeStore)SearchAudit(ctx context.Context,p Principal,hash [32]byte,q AuditQuery,now time.Time)([]AuditRecord,error){if p.ID!=s.p.ID||p.Generation!=s.p.Generation||!hasRole(s.p.Roles,Owner){return nil,ErrForbidden};if !validAuditQuery(q,now){return nil,ErrInvalid};if err:=s.Audit(ctx,Audit{Action:"audit_search",Reason:q.Reason});err!=nil{return nil,err};return []AuditRecord{{Action:"test_record",Reason:"<script>private</script>"}},nil}
type fakeOperations struct{reads,actions int;guard operations.AdminGuard;input operations.CaseAction;detail operations.CaseDetail}
func(f *fakeOperations)Cases(_ context.Context,g operations.AdminGuard,_ int)([]operations.CaseSummary,error){f.reads++;f.guard=g;return []operations.CaseSummary{f.detail.CaseSummary},nil}
func(f *fakeOperations)Case(_ context.Context,g operations.AdminGuard,_ string)(operations.CaseDetail,error){f.reads++;f.guard=g;return f.detail,nil}
func(f *fakeOperations)Action(_ context.Context,g operations.AdminGuard,in operations.CaseAction)(operations.CaseDetail,error){f.actions++;f.guard=g;f.input=in;return f.detail,nil}
type fakeDashboard struct{reads,acks int;afterRead func();input observability.AcknowledgeInput}
func(f *fakeDashboard)Snapshot(context.Context)(observability.Snapshot,error){f.reads++;if f.afterRead!=nil{f.afterRead()};return observability.Snapshot{Ready:true,Gates:[]string{"private-marker"}},nil}
func(f *fakeDashboard)Acknowledge(_ context.Context,in observability.AcknowledgeInput)error{f.acks++;f.input=in;return nil}
type fakePrivacy struct{reads,writes int;guard privacy.AdminGuard}
func(f *fakePrivacy)Worklist(_ context.Context,g privacy.AdminGuard)(privacy.Worklist,error){f.reads++;f.guard=g;return privacy.Worklist{},nil}
func(f *fakePrivacy)PutHold(_ context.Context,g privacy.AdminGuard,_ privacy.HoldInput)(privacy.Hold,error){f.writes++;f.guard=g;return privacy.Hold{},nil}
func(f *fakePrivacy)ReviewHold(_ context.Context,g privacy.AdminGuard,_ string,_ int64,_ string,_ time.Time)(privacy.Hold,error){f.writes++;f.guard=g;return privacy.Hold{},nil}
func(f *fakePrivacy)ReleaseHold(_ context.Context,g privacy.AdminGuard,_ string,_ int64,_ string)(privacy.Hold,error){f.writes++;f.guard=g;return privacy.Hold{},nil}
func(f *fakePrivacy)SchedulePurge(_ context.Context,g privacy.AdminGuard,_ privacy.PurgeInput)(privacy.PurgeJob,error){f.writes++;f.guard=g;return privacy.PurgeJob{},nil}
func TestPhase9RoleBoundariesCoverEveryPrivateDomain(t *testing.T){
    for _,role:=range []string{Owner,Moderator,GrievanceOfficer,BillingOperator,OperationsReadonly}{
        for _,path:=range []string{"/support/worklist","/privacy/worklist","/operations","/audit"}{
            h,_,_,_:=newTestHandler(t,[]string{role});cases:=&fakeOperations{};holds:=&fakePrivacy{};dashboard:=&fakeDashboard{};h.operations=cases;h.privacy=holds;h.observability=dashboard
            method:="POST";if path=="/operations"||path=="/audit"{method="GET"};w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest(method,path,url.Values{"csrf":{testCSRF()}}))
            allowed:=role==Owner||role==GrievanceOfficer&&(path=="/support/worklist"||path=="/privacy/worklist")||role==OperationsReadonly&&path=="/operations"
            if allowed&&w.Code!=200||!allowed&&(w.Code!=403||cases.reads+holds.reads+dashboard.reads!=0){t.Fatal("role boundary",role,path,w.Code)}
        }
    }
}
func TestReadonlyCannotAcknowledgeAlert(t *testing.T){
    h,_,_,_:=newTestHandler(t,[]string{OperationsReadonly});dashboard:=&fakeDashboard{};h.observability=dashboard;w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/operations/ack",url.Values{"csrf":{testCSRF()},"alert_id":{strings.Repeat("a",32)},"version":{"1"},"reason":{"Responding to service outage"}}));if w.Code!=403||dashboard.acks!=0{t.Fatal("readonly mutation")}
}
func TestDashboardRevocationBeforeRelease(t *testing.T){
    h,s,_,_:=newTestHandler(t,[]string{Owner});dashboard:=&fakeDashboard{afterRead:func(){s.p.Roles=[]string{BillingOperator}}};h.observability=dashboard;w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("GET","/operations",nil));if w.Code!=503||strings.Contains(w.Body.String(),"private-marker"){t.Fatal("revoked actor saw private snapshot")}
}
func TestSupportActionUsesFreshAuthorityAndServerReference(t *testing.T){
    h,s,_,_:=newTestHandler(t,[]string{GrievanceOfficer});ref:=strings.Repeat("c",32);cases:=&fakeOperations{detail:operations.CaseDetail{CaseSummary:operations.CaseSummary{Ref:ref,Version:4}}};h.operations=cases
    values:=url.Values{"csrf":{testCSRF()},"version":{"3"},"action":{"reply"},"reason":{"appeal_review"},"message":{"<script>escaped response</script>"},"submission_id":{strings.Repeat("A",43)}}
    w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/support/cases/"+ref+"/action",values));if w.Code!=200||cases.actions!=1||cases.guard.AdminID!=s.p.ID||cases.guard.Generation!=s.p.Generation||cases.guard.SessionHash!=digest("session",strings.Repeat("A",43))||cases.input.ExpectedVersion!=3||cases.input.CaseRef!=ref{t.Fatal("lost case guard")}
    values.Set("admin_id","forged");w=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/support/cases/"+ref+"/action",values));if w.Code!=400||cases.actions!=1{t.Fatal("forged actor reached action")}
}
func TestPrivacyHoldCannotEscapeRoleOrForgeApprover(t *testing.T){
    h,s,_,_:=newTestHandler(t,[]string{GrievanceOfficer});holds:=&fakePrivacy{};h.privacy=holds
    values:=url.Values{"csrf":{testCSRF()},"scope_kind":{"report"},"scope_ref":{strings.Repeat("r",32)},"reason":{"Legal request review"},"review_at":{"2030-01-01T00:00:00Z"}}
    w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/privacy/holds",values));if w.Code!=303||holds.writes!=1||holds.guard.OperatorID!=s.p.ID||holds.guard.Generation!=s.p.Generation{t.Fatal("hold actor lost")}
    values.Set("approver_id","another-operator");w=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/privacy/holds",values));if w.Code!=400||holds.writes!=1{t.Fatal("client chose approver")}
}
func TestGrievanceOfficerCannotScheduleFinancialPurge(t *testing.T){
    h,_,_,_:=newTestHandler(t,[]string{GrievanceOfficer});holds:=&fakePrivacy{};h.privacy=holds;values:=url.Values{"csrf":{testCSRF()},"kind":{"financial"},"subject_ref":{strings.Repeat("r",32)},"reason":{"Case retention review"},"not_before":{"2030-01-01T00:00:00Z"}};w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/privacy/purge",values));if w.Code!=403||holds.writes!=0{t.Fatal("grievance erased finance")}
}
func TestAuditRangeAndFieldsAreBounded(t *testing.T){
    now:=time.Date(2030,2,1,0,0,0,0,time.UTC);q:=AuditQuery{From:now.Add(-24*time.Hour),Until:now,Reason:"Investigate incident actions"};if !validAuditQuery(q,now){t.Fatal("valid range")};q.From=now.Add(-32*24*time.Hour);if validAuditQuery(q,now){t.Fatal("unbounded scan")};q.From=now.Add(-time.Hour);q.Action="x' OR 1=1";if validAuditQuery(q,now){t.Fatal("invalid action")}
}
func TestAuditSearchIsEscapedAndAudited(t *testing.T){
    h,s,_,_:=newTestHandler(t,[]string{Owner});values:=url.Values{"csrf":{testCSRF()},"from":{h.now().Add(-time.Hour).UTC().Format(time.RFC3339)},"until":{h.now().UTC().Format(time.RFC3339)},"reason":{"Investigate incident actions"}};w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/audit/search",values));if w.Code!=200||strings.Contains(w.Body.String(),"<script>")||!strings.Contains(w.Body.String(),"&lt;script&gt;")||len(s.audits)!=1{t.Fatal("audit disclosure not protected")}
}
