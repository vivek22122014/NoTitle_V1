package admin

import (
    "context"
    "net/http"
    "strconv"

    "notitle/internal/admission"
)
type AdmissionBackend interface {
    State()admission.State
    Change(context.Context,string,string,int)error
}
func(h *Handler)serveAdmission(w http.ResponseWriter,r *http.Request,p Principal,session string,data pageData){
    if !hasRole(p.Roles,Owner){h.denyOperations(w,r,p,"Admission changes require owner authority");return}
    if h.admission==nil{http.Error(w,"Admission control unavailable",503);return}
    if r.Method=="POST"{
        if !strictFields(r.PostForm,"csrf","action","reason","evidence_ref","seconds")||!validReason(r.PostForm.Get("reason")){http.Error(w,"Use a reviewed action and purpose",400);return}
        action:=r.PostForm.Get("action");if action!="open"&&action!="drain"{http.Error(w,"Invalid admission action",400);return}
        seconds:=0;var err error;if action=="drain"{seconds,err=strconv.Atoi(r.PostForm.Get("seconds"));if err!=nil||seconds<0||seconds>120||r.PostForm.Get("evidence_ref")!=""{http.Error(w,"Drain must be between zero and 120 seconds",400);return}}else if r.PostForm.Get("seconds")!=""||!admission.ValidEvidenceRef(r.PostForm.Get("evidence_ref")){http.Error(w,"Current approved evidence reference required",400);return}
        // Fresh DB roles/session and the action purpose are committed before
        // applying the process-local gate. The audit calls this a request,
        // because timeout never establishes the eventual actor outcome.
        if err=h.auditView(r.Context(),p,session,"admission","admission_"+action+"_requested",r.PostForm.Get("evidence_ref"),r.PostForm.Get("reason"));err!=nil{http.Error(w,"Operator authority or audit unavailable",503);return}
        if err=h.admission.Change(r.Context(),action,r.PostForm.Get("evidence_ref"),seconds);err!=nil{_=h.audit(r.Context(),p,"admission_"+action,"",r.PostForm.Get("reason"),"failed");http.Error(w,"Admission change unavailable; inspect current state and release evidence before retrying",503);return}
        http.Redirect(w,r,"/operations/admission",303);return
    }
    if err:=h.auditView(r.Context(),p,session,"admission","admission_view","","Review deployment admission state");err!=nil{http.Error(w,"Operator authority or audit unavailable",503);return}
    data.Page="admission";data.Admission=h.admission.State();h.render(w,data)
}

const admissionMarkup=`{{define "admission"}}{{if eq .Page "admission"}}<h1>Deployment admission</h1><p>New interaction and checkout admission is {{if .Admission.Closed}}closed{{else}}open{{end}}.{{if .Admission.Deadline}} Drain deadline {{.Admission.Deadline.UTC.Format "2006-01-02 15:04:05"}} UTC.{{end}}</p><p>Support, safety controls and committed financial work remain available while their dependencies are healthy. Opening requires current release evidence and runtime readiness; this button does not prove benchmark, legal or staffing approval.</p><section><h2>Drain before deployment</h2><form method="post" action="/operations/admission"><input type="hidden" name="csrf" value="{{.CSRF}}"><input type="hidden" name="action" value="drain"><label>Seconds before ending active interactions<input type="number" name="seconds" min="0" max="120" value="120" required></label><label>Reason<textarea name="reason" required minlength="5" maxlength="1000"></textarea></label><button>Close new admission and announce drain</button></form></section><section><h2>Open after checks</h2><form method="post" action="/operations/admission"><input type="hidden" name="csrf" value="{{.CSRF}}"><input type="hidden" name="action" value="open"><label>Approved evidence reference<input name="evidence_ref" required minlength="1" maxlength="64" pattern="[a-z][a-z0-9_]{0,63}" autocomplete="off"></label><label>Reviewed launch purpose<textarea name="reason" required minlength="5" maxlength="1000"></textarea></label><button>Check evidence and open admission</button></form></section>{{end}}{{end}}`
