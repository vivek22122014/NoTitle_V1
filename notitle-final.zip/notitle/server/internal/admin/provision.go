package admin

import (
    "context"
    "fmt"
    "net/url"
    "os"
    "time"

    "github.com/jackc/pgx/v5/pgxpool"
    "notitle/internal/identity"
)

type ProvisionInput struct { Username string `json:"username"`; Password string `json:"password"`; Roles []string `json:"roles"` }

// Provision is an offline owner operation using migration credentials. It has
// no HTTP route, prints no secret and cannot overwrite an enrollment artifact.
func Provision(ctx context.Context,db *pgxpool.Pool,hasher identity.PasswordHasher,key []byte,input ProvisionInput,enrollmentFile string)error{
    if !validUsername(input.Username)||!ValidRoles(input.Roles)||identity.ValidatePassword(input.Password)!=nil||len(key)!=32{return ErrInvalid}
    var role string
    if err:=db.QueryRow(ctx,`SELECT current_user`).Scan(&role);err!=nil||role!="notitle_migrate"{return ErrForbidden}
    id,err:=uuid();if err!=nil{return err}
    raw,encoded,err:=newMFA();if err!=nil{return err};defer clear(raw)
    encrypted,err:=encryptMFA(key,id,raw);if err!=nil{return err}
    passwordHash,err:=hasher.Hash(ctx,input.Password);if err!=nil{return ErrUnavailable}
    file,err:=os.OpenFile(enrollmentFile,os.O_WRONLY|os.O_CREATE|os.O_EXCL,0600);if err!=nil{return ErrInvalid}
    saved:=false;defer func(){file.Close();if !saved{_ = os.Remove(enrollmentFile)}}()
    otpURI:="otpauth://totp/"+url.PathEscape("NoTitle operations:"+input.Username)+"?secret="+encoded+"&issuer=NoTitle%20operations&algorithm=SHA1&digits=6&period=30"
    if _,err=fmt.Fprintf(file,"Private operator authenticator enrollment\nUsername: %s\nSecret: %s\nURI: %s\nImport offline into the appointed operator's authenticator, verify sign-in, then securely remove this file. Do not put it into application backups or source archives.\n",input.Username,encoded,otpURI);err!=nil{return ErrUnavailable}
    if err=file.Sync();err!=nil{return ErrUnavailable}
    tx,err:=db.Begin(ctx);if err!=nil{return ErrUnavailable};defer tx.Rollback(context.Background())
    now:=time.Now().UTC()
    _,err=tx.Exec(ctx,`INSERT INTO notitle.admin_users(id,username,password_hash,totp_ciphertext,roles,created_at) VALUES($1,$2,$3,$4,$5,$6)`,id,input.Username,passwordHash,encrypted,input.Roles,now)
    if err!=nil{return ErrUnavailable}
    if err=writeAudit(ctx,tx,Audit{Action:"operator_provisioned_offline",SubjectRef:id,Reason:"Offline migration-role provisioning",Result:"success",At:now});err!=nil{return err}
    // A lost commit response is ambiguous: preserve enrollment so an operator
    // can inspect the account and recover, rather than orphaning its MFA key.
    saved=true
    if err=tx.Commit(ctx);err!=nil{return ErrUnavailable};return nil
}
