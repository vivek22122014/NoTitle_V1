package admin

import (
    "bytes"
    "encoding/base64"
    "net/http/httptest"
    "net/url"
    "regexp"
    "strings"
    "sync"
    "testing"
    "time"
)
func exportPreparation(t *testing.T,h *Handler)(string,[]byte){
    t.Helper();w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/cases/"+strings.Repeat("r",32)+"/export",url.Values{"csrf":{testCSRF()},"version":{"1"},"reason":{"Authorized evidence transfer"}}));if w.Code!=200{t.Fatal("prepare failed",w.Code)}
    token:=regexp.MustCompile(`name="permit" value="([^"]+)"`).FindStringSubmatch(w.Body.String());key:=regexp.MustCompile(`readonly value="([^"]+)"`).FindStringSubmatch(w.Body.String());if len(token)!=2||len(key)!=2{t.Fatal("key/permit missing")};raw,err:=base64.StdEncoding.Strict().DecodeString(key[1]);if err!=nil{t.Fatal(err)};return token[1],raw
}
func TestEncryptedExportIsOneUseAndAudited(t *testing.T){
    h,s,_,_:=newTestHandler(t,[]string{Owner});token,key:=exportPreparation(t,h);values:=url.Values{"csrf":{testCSRF()},"permit":{token}}
    w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/exports/download",values));if w.Code!=200||bytes.Contains(w.Body.Bytes(),[]byte("<script>")){t.Fatal("unencrypted export")};raw,err:=DecryptEvidence(key,w.Body.Bytes());if err!=nil||!bytes.Contains(raw,[]byte("notitle-evidence-v1")){t.Fatal("bundle cannot decrypt")};clear(raw)
    if len(s.audits)!=2||s.audits[0].Action!="evidence_export_prepare"||s.audits[1].Action!="evidence_export_download"{t.Fatal("export audit incomplete")}
    w=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/exports/download",values));if w.Code!=410{t.Fatal("export permit replayed")}
}
func TestExportRejectsRevocationExpiryAndWrongSession(t *testing.T){
    for _,mode:=range []string{"role","generation","expiry","audit","session"}{h,s,_,_:=newTestHandler(t,[]string{Owner});token,_:=exportPreparation(t,h);switch mode{case "role":s.p.Roles=[]string{Moderator};case "generation":s.p.Generation++;case "expiry":now:=h.now();h.now=func()time.Time{return now.Add(2*time.Minute)};case "audit":s.auditFail=true};w:=httptest.NewRecorder();request:=adminRequest("POST","/exports/download",url.Values{"csrf":{testCSRF()},"permit":{token}});if mode=="session"{other:=base64.RawURLEncoding.EncodeToString(bytes.Repeat([]byte{7},32));request=adminRequest("POST","/exports/download",url.Values{"csrf":{csrf(other)},"permit":{token}});request.Header.Set("Cookie",h.cookieName+"="+other)};h.ServeHTTP(w,request);if w.Code<400||strings.HasPrefix(w.Body.String(),"NTE1"){t.Fatal("unauthorized export",mode)}}
}
func TestExportPermissionAndVersionMustMatch(t *testing.T){
    for _,mode:=range []string{"moderator","version","forged"}{role:=Owner;if mode=="moderator"{role=Moderator};h,_,_,_:=newTestHandler(t,[]string{role});values:=url.Values{"csrf":{testCSRF()},"version":{"1"},"reason":{"Authorized evidence transfer"}};if mode=="version"{values.Set("version","2")};if mode=="forged"{values.Set("scope","all_conversations")};w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/cases/"+strings.Repeat("r",32)+"/export",values));if w.Code<400||len(h.exports.permits)!=0{t.Fatal("invalid export generated")}}
}
func TestExportConcurrentConsumeAndCipherIntegrity(t *testing.T){
    h,s,_,_:=newTestHandler(t,[]string{Owner});token,key:=exportPreparation(t,h);wins:=make(chan []byte,2);var wg sync.WaitGroup
    for i:=0;i<2;i++{wg.Add(1);go func(){defer wg.Done();p,err:=h.exports.take(token,s.p,digest("session",strings.Repeat("A",43)),h.now());if err==nil{wins<-p.Encrypted}}()};wg.Wait();close(wins);count:=0
    for data:=range wins{count++;data[len(data)-1]^=1;if _,err:=DecryptEvidence(key,data);err==nil{t.Fatal("tampered ciphertext accepted")};clear(data)};if count!=1{t.Fatal("permit shared",count)}
}
func TestExportVaultIsBoundedAndExpiresMemory(t *testing.T){
    v:=newExportVault();now:=time.Now();for i:=0;i<10;i++{token:=strings.Repeat(string(rune('A'+i)),43);if err:=v.put(token,exportPermit{Encrypted:make([]byte,1),Expires:now.Add(time.Minute)},now);err!=nil{t.Fatal(err)}}
    if err:=v.put(strings.Repeat("z",43),exportPermit{Encrypted:[]byte{1},Expires:now.Add(time.Minute)},now);err==nil{t.Fatal("unbounded export permits")};v.mu.Lock();v.sweep(now.Add(time.Minute));v.mu.Unlock();if len(v.permits)!=0||v.bytes!=0{t.Fatal("expired data retained")}
}
