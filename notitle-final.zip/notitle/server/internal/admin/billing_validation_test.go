package admin

import (
    "net/url"
    "strings"
    "testing"
    "time"
)

func TestBillingRoleSeparation(t *testing.T){
    for _,role:=range []string{Owner,BillingOperator}{if !CanBill([]string{role}){t.Fatal("billing role denied")}}
    for _,role:=range []string{Moderator,GrievanceOfficer,OperationsReadonly,"billing",""}{if CanBill([]string{role}){t.Fatal("unassigned role gained billing")}}
    if CanReview([]string{BillingOperator}){t.Fatal("billing operator gained moderation evidence")}
}

func TestBillingExactIntegerInputs(t *testing.T){
    for _,value:=range []string{"","1.00","1e2","-1","+1"," 1","01","0x10","9999999999999999999","1000000000001"}{if _,ok:=formInteger(value,1,1000000000000);ok{t.Fatal("noncanonical monetary value accepted")}}
    for _,value:=range []string{"1","99","149900"}{if _,ok:=formInteger(value,1,1000000000000);!ok{t.Fatal("integer paise rejected")}}
    if n,ok:=formInteger("0",0,31536000);!ok||n!=0{t.Fatal("money-only zero seconds rejected")}
    if strictFields(url.Values{"amount_paise":{"99"},"actor_id":{"forged"}},"amount_paise"){t.Fatal("unknown authority form field accepted")}
    if strictFields(url.Values{"amount_paise":{"99","100"}},"amount_paise"){t.Fatal("ambiguous amount accepted")}
}

func TestRefundApprovalBindsScopeAmountSessionAndRevision(t *testing.T){
    h,_,_,_:=newTestHandler(t,[]string{BillingOperator})
    in:=refundApproval{ActorID:"operator",Generation:3,SessionHash:digest("session","operator-token"),OrderRef:strings.Repeat("o",32),PaymentID:"123456789",IdempotencyKey:strings.Repeat("i",32),Reason:"Correct duplicate capture",Treatment:"money_only",AmountPaise:9900,Revision:7,ExpiresAt:h.now().Add(5*time.Minute).Unix()}
    token:=h.signRefundApproval(in);if !h.verifyRefundApproval(in,token){t.Fatal("original preview rejected")}
    variants:=[]refundApproval{in,in,in,in,in,in,in,in,in,in,in,in}
    variants[0].ActorID="other";variants[1].Generation++;variants[2].SessionHash=digest("session","new-session");variants[3].OrderRef=strings.Repeat("p",32);variants[4].PaymentID="other-payment";variants[5].AmountPaise++;variants[6].Treatment="duration";variants[7].ReduceSeconds=1;variants[8].Revision++;variants[9].IdempotencyKey=strings.Repeat("j",32);variants[10].Reason="Different reason";variants[11].ExpiresAt++
    for _,changed:=range variants{if h.verifyRefundApproval(changed,token){t.Fatal("forged confirmation accepted")}}
    expired:=in;expired.ExpiresAt=h.now().Unix();if h.verifyRefundApproval(expired,h.signRefundApproval(expired)){t.Fatal("expired preview accepted")}
    future:=in;future.ExpiresAt=h.now().Add(11*time.Minute).Unix();if h.verifyRefundApproval(future,h.signRefundApproval(future)){t.Fatal("overlong preview accepted")}
}
