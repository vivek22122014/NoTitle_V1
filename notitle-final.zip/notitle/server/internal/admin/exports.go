package admin

import (
    "context"
    "crypto/rand"
    "encoding/base64"
    "encoding/json"
    "net/http"
    "sync"
    "time"
)

const exportAAD="notitle:evidence-export:v1"
const maxExportBytes=2<<20
// Export permits and encrypted bundles are transient, never stored in a public
// bucket. The key is returned once only to the authenticated prepare response.
type exportPermit struct{ActorID,Ref,Reason string;Generation int64;Session [32]byte;Expires time.Time;Encrypted []byte}
type exportVault struct{mu sync.Mutex;permits map[[32]byte]exportPermit;bytes int}
func newExportVault()*exportVault{return &exportVault{permits:map[[32]byte]exportPermit{}}}
func(v *exportVault)remove(key [32]byte){p:=v.permits[key];clear(p.Encrypted);v.bytes-=len(p.Encrypted);delete(v.permits,key)}
func(v *exportVault)sweep(now time.Time){for key,p:=range v.permits{if !now.Before(p.Expires){v.remove(key)}}}
func(v *exportVault)put(token string,p exportPermit,now time.Time)error{v.mu.Lock();defer v.mu.Unlock();v.sweep(now);if len(v.permits)>=10||v.bytes+len(p.Encrypted)>8<<20{return ErrUnavailable};v.permits[digest("export",token)]=p;v.bytes+=len(p.Encrypted);return nil}
func(v *exportVault)take(token string,p Principal,hash [32]byte,now time.Time)(exportPermit,error){
    v.mu.Lock();defer v.mu.Unlock();v.sweep(now);key:=digest("export",token);entry,ok:=v.permits[key]
    if !ok||entry.ActorID!=p.ID||entry.Generation!=p.Generation||entry.Session!=hash{return exportPermit{},ErrForbidden}
    // Consume before external/database work. A failed read needs a new audited
    // request; simultaneous download attempts can never share a permit.
    delete(v.permits,key);v.bytes-=len(entry.Encrypted);return entry,nil
}
func(v *exportVault)revoke(hash [32]byte){v.mu.Lock();defer v.mu.Unlock();for key,p:=range v.permits{if p.Session==hash{v.remove(key)}}}
func(h *Handler)RunExportCleanup(ctx context.Context){ticker:=time.NewTicker(30*time.Second);defer ticker.Stop();defer func(){h.exports.mu.Lock();defer h.exports.mu.Unlock();for k:=range h.exports.permits{h.exports.remove(k)}}();for{select{case <-ctx.Done():return;case <-ticker.C:h.exports.mu.Lock();h.exports.sweep(h.now());h.exports.mu.Unlock()}}}

type exportPage struct{Key,Token string;Expires time.Time}
func(h *Handler)prepareExport(w http.ResponseWriter,r *http.Request,p Principal,session,ref,reason string,data pageData){
    if !CanExport(p.Roles){_=h.audit(r.Context(),p,"evidence_export_prepare",ref,reason,"denied");http.Error(w,"Evidence export requires an owner or grievance officer",403);return}
    if !strictFields(r.PostForm,"csrf","reason","version"){http.Error(w,"Invalid export request",400);return}
    version,ok:=formInteger(r.PostForm.Get("version"),1,1<<62);if !ok{http.Error(w,"Current case version required",400);return}
    detail,err:=h.backend.CaseDetail(r.Context(),ref);if err!=nil{http.Error(w,"Case unavailable",503);return}
    if detail.Ref!=ref||detail.Version!=version{http.Error(w,"Case changed; reopen evidence before exporting",409);return}
    raw,err:=json.Marshal(struct{Format string `json:"format"`;PreparedAt time.Time `json:"prepared_at"`;Case any `json:"case"`}{"notitle-evidence-v1",h.now().UTC(),detail})
    if err!=nil||len(raw)>maxExportBytes{clear(raw);http.Error(w,"Export exceeds the bounded review bundle",503);return};defer clear(raw)
    key:=make([]byte,32);if _,err=rand.Read(key);err!=nil{http.Error(w,"Export unavailable",503);return};defer clear(key)
    cipher,err:=cipherFor(key);if err!=nil{http.Error(w,"Export unavailable",503);return};nonce:=make([]byte,cipher.NonceSize());if _,err=rand.Read(nonce);err!=nil{http.Error(w,"Export unavailable",503);return}
    encrypted:=cipher.Seal(append([]byte("NTE1"),nonce...),nonce,raw,[]byte(exportAAD))
    token,err:=secret();if err!=nil{clear(encrypted);http.Error(w,"Export unavailable",503);return}
    if err=h.auditView(r.Context(),p,session,"export","evidence_export_prepare",ref,reason);err!=nil{clear(encrypted);http.Error(w,"Audit unavailable",503);return}
    expiry:=h.now().Add(2*time.Minute)
    if err=h.exports.put(token,exportPermit{ActorID:p.ID,Generation:p.Generation,Session:digest("session",session),Ref:ref,Reason:reason,Expires:expiry,Encrypted:encrypted},h.now());err!=nil{clear(encrypted);http.Error(w,"Export capacity reached; retry shortly",503);return}
    data.Page="export_ready";data.Export=exportPage{Key:base64.StdEncoding.EncodeToString(key),Token:token,Expires:expiry};h.render(w,data)
}
func(h *Handler)downloadExport(w http.ResponseWriter,r *http.Request,p Principal,session string){
    if r.Method!="POST"{http.NotFound(w,r);return}
    if !CanExport(p.Roles)||!strictFields(r.PostForm,"csrf","permit")||!validToken(r.PostForm.Get("permit")){_=h.audit(r.Context(),p,"evidence_export_download","","Export authorization or permit rejected","denied");http.Error(w,"Export not permitted",403);return}
    entry,err:=h.exports.take(r.PostForm.Get("permit"),p,digest("session",session),h.now());if err!=nil{_=h.audit(r.Context(),p,"evidence_export_download","","Export expired or unavailable","denied");http.Error(w,"Export expired or already consumed; prepare it again",410);return};defer clear(entry.Encrypted)
    if err=h.auditView(r.Context(),p,session,"export","evidence_export_download",entry.Ref,entry.Reason);err!=nil{http.Error(w,"Audit unavailable",503);return}
    w.Header().Set("Content-Type","application/octet-stream");w.Header().Set("Content-Disposition",`attachment; filename="notitle-evidence.nte"`);_,_=w.Write(entry.Encrypted)
}
// DecryptEvidence is for an authorized operator's offline private workstation.
// Download access expires after two minutes; exported copies require the case's
// retention rules. Expiry cannot revoke an already downloaded decrypted copy.
func DecryptEvidence(key,encrypted []byte)([]byte,error){
    cipher,err:=cipherFor(key);if err!=nil{return nil,err};if len(encrypted)<4+cipher.NonceSize()+cipher.Overhead()||len(encrypted)>maxExportBytes+128||string(encrypted[:4])!="NTE1"{return nil,ErrInvalid}
    nonce:=encrypted[4:4+cipher.NonceSize()];raw,err:=cipher.Open(nil,nonce,encrypted[4+cipher.NonceSize():],[]byte(exportAAD));if err!=nil{return nil,ErrInvalid};return raw,nil
}
const exportMarkup=`{{define "export"}}{{if eq .Page "export_ready"}}<section><h1>Encrypted evidence export</h1><p>This one-use download expires at {{.Export.Expires.UTC.Format "2006-01-02 15:04:05"}} UTC and requires this operator session. Save the key separately in approved restricted storage. The key is displayed only here; it is never included in the download.</p><label>Decryption key (base64)<input readonly value="{{.Export.Key}}" autocomplete="off"></label><form method="post" action="/exports/download"><input type="hidden" name="csrf" value="{{.CSRF}}"><input type="hidden" name="permit" value="{{.Export.Token}}"><button>Download once</button></form><p>Use adminctl decrypt-evidence on the private workstation. Apply the case retention deadline to every exported copy. Download expiry cannot revoke a copy already saved.</p></section>{{end}}{{end}}`
