package admin

import (
    "context"
    "fmt"
    "net/url"
    "os"
    "time"

    "github.com/jackc/pgx/v5"
    "github.com/jackc/pgx/v5/pgxpool"
    "notitle/internal/identity"
)

type LifecycleInput struct {
    Username string `json:"username"`
    AuthorizerUsername string `json:"authorizer_username"`
    AuthorizerPassword string `json:"authorizer_password"`
    AuthorizerCode string `json:"authorizer_code"`
    Action string `json:"action"`
    Roles []string `json:"roles,omitempty"`
    Reason string `json:"reason"`
    ExpectedGeneration int64 `json:"expected_generation"`
}
func validLifecycleInput(in LifecycleInput)bool{
    if !validUsername(in.Username)||!validUsername(in.AuthorizerUsername)||len(in.AuthorizerPassword)<12||len(in.AuthorizerPassword)>128||len(in.AuthorizerCode)!=6||!validReason(in.Reason)||in.ExpectedGeneration<1{return false}
    switch in.Action{case "roles":return ValidRoles(in.Roles);case "disable","enable","reset_mfa":return len(in.Roles)==0;default:return false}
}
// ManageOperator is an explicitly invoked offline owner operation. Runtime
// credentials cannot alter roles/generations. All changes revoke every session
// and invalidate password/TOTP snapshots before returning a committed result.
func ManageOperator(ctx context.Context,db *pgxpool.Pool,key []byte,in LifecycleInput,enrollmentFile string)error{
    if !validLifecycleInput(in)||len(key)!=32||in.Action!="reset_mfa"&&enrollmentFile!=""{return ErrInvalid}
    var role string;if db.QueryRow(ctx,`SELECT current_user`).Scan(&role)!=nil||role!="notitle_migrate"{return ErrForbidden}
    tx,err:=db.Begin(ctx);if err!=nil{return ErrUnavailable};defer tx.Rollback(context.Background())
    // Serializes all offline lifecycle edits, including the last-owner check.
    if _,err=tx.Exec(ctx,`SELECT pg_advisory_xact_lock(785332981)`);err!=nil{return ErrUnavailable}
    authorizerID,err:=authorizeOfflineOwner(ctx,tx,key,in.AuthorizerUsername,in.AuthorizerPassword,in.AuthorizerCode);if err!=nil{return err}
    var id string;var generation int64;var roles []string;var disabled bool
    err=tx.QueryRow(ctx,`SELECT id::text,generation,roles,disabled FROM notitle.admin_users WHERE username=$1 FOR UPDATE`,in.Username).Scan(&id,&generation,&roles,&disabled)
    if err==pgx.ErrNoRows{return ErrCredentials};if err!=nil{return ErrUnavailable};if generation!=in.ExpectedGeneration{return ErrInvalid}
    if !disabled&&hasRole(roles,Owner)&&(in.Action=="disable"||in.Action=="roles"&&!hasRole(in.Roles,Owner)){
        var remaining int;if tx.QueryRow(ctx,`SELECT count(*) FROM notitle.admin_users WHERE id<>$1 AND NOT disabled AND 'owner'=ANY(roles)`,id).Scan(&remaining)!=nil{return ErrUnavailable};if remaining<1{return ErrForbidden}
    }
    var encrypted []byte;var enrollment *os.File;preserve:=false
    if in.Action=="reset_mfa"{
        raw,encoded,e:=newMFA();if e!=nil{return e};defer clear(raw);encrypted,e=encryptMFA(key,id,raw);if e!=nil{return e}
        enrollment,e=os.OpenFile(enrollmentFile,os.O_WRONLY|os.O_CREATE|os.O_EXCL,0600);if e!=nil{return ErrInvalid}
        defer func(){enrollment.Close();if !preserve{_ = os.Remove(enrollmentFile)}}()
        uri:="otpauth://totp/"+url.PathEscape("NoTitle operations:"+in.Username)+"?secret="+encoded+"&issuer=NoTitle%20operations&algorithm=SHA1&digits=6&period=30"
        if _,e=fmt.Fprintf(enrollment,"Private replacement enrollment\nUsername: %s\nSecret: %s\nURI: %s\nVerify identity of the appointed operator, import offline, verify MFA, then securely remove this file. Existing sessions are revoked.\n",in.Username,encoded,uri);e!=nil{return ErrUnavailable};if enrollment.Sync()!=nil{return ErrUnavailable}
    }
    switch in.Action{
    case "roles":_,err=tx.Exec(ctx,`UPDATE notitle.admin_users SET roles=$2,generation=generation+1 WHERE id=$1`,id,in.Roles)
    case "disable":_,err=tx.Exec(ctx,`UPDATE notitle.admin_users SET disabled=true,generation=generation+1 WHERE id=$1`,id)
    case "enable":_,err=tx.Exec(ctx,`UPDATE notitle.admin_users SET disabled=false,generation=generation+1 WHERE id=$1`,id)
    case "reset_mfa":_,err=tx.Exec(ctx,`UPDATE notitle.admin_users SET totp_ciphertext=$2,last_counter=-1,generation=generation+1 WHERE id=$1`,id,encrypted)
    }
    if err!=nil{return ErrUnavailable};if _,err=tx.Exec(ctx,`DELETE FROM notitle.admin_sessions WHERE admin_id=$1`,id);err!=nil{return ErrUnavailable}
    if err=writeAudit(ctx,tx,Audit{AdminID:authorizerID,Action:"operator_"+in.Action+"_offline",SubjectRef:id,Reason:in.Reason,Result:"success",At:time.Now().UTC()});err!=nil{return err}
    // A lost COMMIT acknowledgement is ambiguous; retain replacement enrollment
    // so the owner can recover instead of losing the only valid second factor.
    preserve=true;if tx.Commit(ctx)!=nil{return ErrUnavailable};return nil
}

func authorizeOfflineOwner(ctx context.Context,tx pgx.Tx,key []byte,username,password,code string)(string,error){
    if len(key)!=32||!validUsername(username)||len(password)<12||len(password)>128||len(code)!=6{return "",ErrInvalid}
    var authorizer Credentials
    err:=tx.QueryRow(ctx,`SELECT id::text,password_hash,totp_ciphertext,roles,generation,last_counter FROM notitle.admin_users WHERE username=$1 AND NOT disabled FOR UPDATE`,username).Scan(&authorizer.ID,&authorizer.PasswordHash,&authorizer.TOTPCiphertext,&authorizer.Roles,&authorizer.Generation,&authorizer.LastCounter)
    if err==pgx.ErrNoRows{return "",ErrCredentials};if err!=nil{return "",ErrUnavailable};if !ValidRoles(authorizer.Roles)||!hasRole(authorizer.Roles,Owner){return "",ErrForbidden}
    accepted,err:=identity.NewArgon2Hasher().Verify(ctx,authorizer.PasswordHash,password);if err!=nil||!accepted{return "",ErrCredentials}
    mfa,err:=decryptMFA(key,authorizer.ID,authorizer.TOTPCiphertext);if err!=nil{return "",err};counter,accepted:=verifyTOTP(mfa,code,time.Now().UTC(),authorizer.LastCounter);clear(mfa);if !accepted{return "",ErrCredentials}
    if _,err=tx.Exec(ctx,`UPDATE notitle.admin_users SET last_counter=$2 WHERE id=$1`,authorizer.ID,counter);err!=nil{return "",ErrUnavailable}
    return authorizer.ID,nil
}
