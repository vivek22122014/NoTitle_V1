package admin

import (
    "strings"
    "unicode"
    "unicode/utf8"
)

const (
    Owner = "owner"
    Moderator = "moderator"
    GrievanceOfficer = "grievance_officer"
    BillingOperator = "billing_operator"
    OperationsReadonly = "operations_readonly"
)

func ValidRoles(roles []string) bool {
    if len(roles)<1||len(roles)>5{return false}; seen:=map[string]bool{}
    for _,role:=range roles {switch role {case Owner,Moderator,GrievanceOfficer,BillingOperator,OperationsReadonly:default:return false};if seen[role]{return false};seen[role]=true}
    return true
}

func CanReview(roles []string) bool {
    for _,r:=range roles{if r==Owner||r==Moderator||r==GrievanceOfficer{return true}};return false
}

// Billing and moderation scopes are deliberately independent. A founder with
// owner scope can operate both; a billing operator cannot inspect case evidence.
func CanBill(roles []string) bool {
    for _,r:=range roles{if r==Owner||r==BillingOperator{return true}};return false
}

func canAction(roles []string, action string) bool {
    switch action{case "suspend","unsuspend","resolve","note":return CanReview(roles);default:return false}
}

func validUsername(v string) bool {
    if len(v)<4||len(v)>64{return false};for _,r:=range v{if !(r>='a'&&r<='z'||r>='0'&&r<='9'||r=='_'||r=='-'||r=='.'){return false}};return true
}

func validReason(v string) bool {
    if !utf8.ValidString(v)||len(v)>4000||utf8.RuneCountInString(v)>1000||len(strings.TrimSpace(v))<5{return false}
    for _,r:=range v{if (unicode.IsControl(r)&&r!='\n'&&r!='\t')||r>=0x202a&&r<=0x202e||r>=0x2066&&r<=0x2069{return false}};return true
}
