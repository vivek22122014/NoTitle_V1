package admin

import (
    "context"
    "net/http/httptest"
    "net/url"
    "strings"
    "testing"
    "notitle/internal/performance"
)
type fakeProcessing struct{afterRead func()}
func(f *fakeProcessing)ProcessingSnapshot(context.Context)(performance.Export,error){if f.afterRead!=nil{f.afterRead()};return performance.New().Export(),nil}
func TestProcessingExportRechecksAuthorityBeforeDisclosure(t *testing.T){
    h,store,_,_:=newTestHandler(t,[]string{OperationsReadonly});h.metrics=&fakeProcessing{afterRead:func(){store.p.Roles=[]string{BillingOperator}}}
    v:=url.Values{"csrf":{testCSRF()},"reason":{"Measure controlled capacity exercise"}}
    w:=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/operations/metrics",v));if w.Code!=503||strings.Contains(w.Body.String(),"ordinary_api_server"){t.Fatal("revoked operator received processing aggregates")}
    store.p.Roles=[]string{OperationsReadonly};h.metrics=&fakeProcessing{};w=httptest.NewRecorder();h.ServeHTTP(w,adminRequest("POST","/operations/metrics",v))
    if w.Code!=200||!strings.Contains(w.Body.String(),"available_candidate_to_commit_upper_bound")||w.Header().Get("Cache-Control")!="no-store"{t.Fatal("audited private metrics unavailable")}
}
