package admin

import (
    "context"
    "encoding/json"
    "time"

    "github.com/jackc/pgx/v5/pgxpool"
    "notitle/internal/privacy"
)

type PolicyInstallInput struct {
    AuthorizerUsername string `json:"authorizer_username"`
    AuthorizerPassword string `json:"authorizer_password"`
    AuthorizerCode string `json:"authorizer_code"`
    Reason string `json:"reason"`
}
// InstallRetentionPolicy records a separately reviewed manifest. It does not
// create legal approval, change host files, shorten retention or enable purge.
// Runtime credentials cannot insert or modify this immutable policy catalog.
func InstallRetentionPolicy(ctx context.Context,db *pgxpool.Pool,key []byte,in PolicyInstallInput,path string)error{
    if !validReason(in.Reason){return ErrInvalid}
    policy,err:=privacy.LoadPolicyFile(path,true,time.Now().UTC());if err!=nil{return ErrInvalid}
    raw,err:=json.Marshal(policy);if err!=nil{return ErrInvalid};defer clear(raw)
    var role string;if db.QueryRow(ctx,`SELECT current_user`).Scan(&role)!=nil||role!="notitle_migrate"{return ErrForbidden}
    tx,err:=db.Begin(ctx);if err!=nil{return ErrUnavailable};defer tx.Rollback(context.Background())
    if _,err=tx.Exec(ctx,`SELECT pg_advisory_xact_lock(785332981)`);err!=nil{return ErrUnavailable}
    actor,err:=authorizeOfflineOwner(ctx,tx,key,in.AuthorizerUsername,in.AuthorizerPassword,in.AuthorizerCode);if err!=nil{return err}
    if _,err=tx.Exec(ctx,`INSERT INTO notitle.retention_policies(version,digest,document,approved,installed_at)VALUES($1,$2,$3,true,$4) ON CONFLICT(version) DO NOTHING`,policy.Version,policy.Digest(),raw,time.Now().UTC());err!=nil{return ErrUnavailable}
    var digest string;var approved bool
    if err=tx.QueryRow(ctx,`SELECT digest,approved FROM notitle.retention_policies WHERE version=$1`,policy.Version).Scan(&digest,&approved);err!=nil{return ErrUnavailable};if digest!=policy.Digest()||!approved{return ErrInvalid}
    if err=writeAudit(ctx,tx,Audit{AdminID:actor,Action:"retention_policy_install",SubjectRef:policy.Version,Reason:in.Reason,Result:"success",At:time.Now().UTC()});err!=nil{return err}
    if tx.Commit(ctx)!=nil{return ErrUnavailable};return nil
}
