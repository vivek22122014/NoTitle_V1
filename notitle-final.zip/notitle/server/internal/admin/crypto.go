// Package admin serves the private operations listener only. It has no public
// account credentials, registration endpoint, shared cookies or live-chat view.
package admin

import (
    "crypto/aes"
    "crypto/cipher"
    "crypto/hmac"
    "crypto/rand"
    "crypto/sha1"
    "crypto/sha256"
    "crypto/subtle"
    "encoding/base32"
    "encoding/base64"
    "encoding/binary"
    "encoding/hex"
    "errors"
    "fmt"
    "io"
    "os"
    "strings"
    "time"
)

var ErrUnavailable = errors.New("private operations unavailable")
var ErrCredentials = errors.New("credentials not accepted")
var ErrForbidden = errors.New("operation not permitted")
var ErrInvalid = errors.New("invalid operation")

func secret() (string, error) {
    b := make([]byte, 32)
    if _, err := rand.Read(b); err != nil { return "", ErrUnavailable }
    return base64.RawURLEncoding.EncodeToString(b), nil
}

func uuid() (string, error) {
    var b [16]byte
    if _, err := rand.Read(b[:]); err != nil { return "", ErrUnavailable }
    b[6] = b[6]&0x0f|0x40; b[8] = b[8]&0x3f|0x80
    v := hex.EncodeToString(b[:])
    return v[:8]+"-"+v[8:12]+"-"+v[12:16]+"-"+v[16:20]+"-"+v[20:], nil
}

func digest(purpose, value string) [32]byte { return sha256.Sum256([]byte("notitle:admin:"+purpose+":"+value)) }
func csrf(token string) string { v:=digest("csrf",token); return base64.RawURLEncoding.EncodeToString(v[:]) }
func validToken(token string) bool { if len(token)!=43 { return false }; b,e:=base64.RawURLEncoding.Strict().DecodeString(token); return e==nil&&len(b)==32 }

// ReadKey requires a private, regular file, separate from the evidence key.
func ReadKey(path string) ([]byte,error) {
    b,err:=ReadPrivateFile(path,128)
    if err!=nil { return nil,err }
    defer clear(b)
    key,err:=base64.StdEncoding.Strict().DecodeString(strings.TrimSpace(string(b)))
    if err!=nil || len(key)!=32 { return nil,ErrInvalid }
    return key,nil
}

func ReadPrivateFile(path string, limit int64) ([]byte,error) {
    info,err:=os.Lstat(path)
    if err!=nil || !info.Mode().IsRegular() || info.Mode().Perm()&0077!=0 || info.Size()>limit || info.Size()<1 { return nil,ErrInvalid }
    file,err:=os.Open(path);if err!=nil{return nil,ErrInvalid};defer file.Close()
    opened,err:=file.Stat();if err!=nil||!os.SameFile(info,opened)||!opened.Mode().IsRegular()||opened.Mode().Perm()&0077!=0{return nil,ErrInvalid}
    b,err:=io.ReadAll(io.LimitReader(file,limit+1))
    if err!=nil || int64(len(b))>limit || len(b)<1 { clear(b);return nil,ErrInvalid }
    return b,nil
}

func cipherFor(key []byte) (cipher.AEAD,error) {
    if len(key)!=32 { return nil,ErrInvalid }
    c,err:=aes.NewCipher(key); if err!=nil { return nil,ErrUnavailable }
    return cipher.NewGCM(c)
}

func encryptMFA(key []byte, adminID string, raw []byte) ([]byte,error) {
    c,err:=cipherFor(key); if err!=nil { return nil,err }
    nonce:=make([]byte,c.NonceSize()); if _,err=rand.Read(nonce);err!=nil{return nil,ErrUnavailable}
    return c.Seal(nonce,nonce,raw,[]byte("notitle:admin-mfa:v1:"+adminID)),nil
}

func decryptMFA(key []byte, adminID string, encrypted []byte) ([]byte,error) {
    c,err:=cipherFor(key); if err!=nil{return nil,err}
    if len(encrypted)<c.NonceSize()+c.Overhead(){return nil,ErrUnavailable}
    b,err:=c.Open(nil,encrypted[:c.NonceSize()],encrypted[c.NonceSize():],[]byte("notitle:admin-mfa:v1:"+adminID))
    if err!=nil||len(b)!=20{return nil,ErrUnavailable}; return b,nil
}

// RFC 6238 / RFC 4226: 30 second steps, six decimal digits, HMAC-SHA1.
// Replay prevention is an atomic database compare-and-update of last_counter.
func totp(raw []byte, counter int64, digits int) string {
    var b [8]byte;binary.BigEndian.PutUint64(b[:],uint64(counter))
    h:=hmac.New(sha1.New,raw); _,_=h.Write(b[:]); sum:=h.Sum(nil)
    i:=sum[len(sum)-1]&15
    value:=binary.BigEndian.Uint32(sum[i:i+4])&0x7fffffff
    modulus:=uint32(1000000);if digits==8{modulus=100000000}
    return fmt.Sprintf("%0*d",digits,value%modulus)
}

func verifyTOTP(raw []byte, code string, now time.Time, last int64) (int64,bool) {
    if len(code)!=6{return 0,false};for _,r:=range code{if r<'0'||r>'9'{return 0,false}}
    current:=now.Unix()/30
    for _,counter:=range []int64{current,current-1,current+1} {
        if counter>=0 && counter>last && subtle.ConstantTimeCompare([]byte(totp(raw,counter,6)),[]byte(code))==1{return counter,true}
    }
    return 0,false
}

func newMFA() ([]byte,string,error) {
    raw:=make([]byte,20);if _,err:=rand.Read(raw);err!=nil{return nil,"",ErrUnavailable}
    return raw,base32.StdEncoding.WithPadding(base32.NoPadding).EncodeToString(raw),nil
}
