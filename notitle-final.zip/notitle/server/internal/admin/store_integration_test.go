package admin

import (
    "context"
    "errors"
    "os"
    "strings"
    "sync"
    "testing"
    "time"

    "github.com/jackc/pgx/v5/pgxpool"
)

// These fixtures exist only in db-check.sh's isolated disposable test database.
// The API never receives the migration credential used to provision operators.
func adminIntegration(t *testing.T)(*PostgresStore,*pgxpool.Pool,context.Context){
    t.Helper()
    read:=func(name string)string{path:=os.Getenv(name);if path==""{return ""};b,err:=os.ReadFile(path);if err!=nil{t.Fatal("cannot read isolated integration secret")};return strings.TrimSpace(string(b))}
    runtimeDSN:=read("TEST_DATABASE_URL_FILE");if runtimeDSN==""{runtimeDSN=os.Getenv("TEST_DATABASE_URL")}
    migrationDSN:=read("TEST_ADMIN_MIGRATION_URL_FILE")
    if runtimeDSN==""||migrationDSN==""{if os.Getenv("REQUIRE_DATABASE_INTEGRATION")=="1"{t.Fatal("admin database integration credentials required")};t.Skip("run scripts/db-check.sh for private admin integration")}
    ctx,cancel:=context.WithTimeout(context.Background(),45*time.Second);t.Cleanup(cancel)
    runtimePool,err:=pgxpool.New(ctx,runtimeDSN);if err!=nil{t.Fatal("runtime pool configuration")};t.Cleanup(runtimePool.Close)
    migrationPool,err:=pgxpool.New(ctx,migrationDSN);if err!=nil{t.Fatal("migration pool configuration")};t.Cleanup(migrationPool.Close)
    var role string;if err=migrationPool.QueryRow(ctx,`SELECT current_user`).Scan(&role);err!=nil||role!="notitle_migrate"{t.Fatal("dedicated migration role required")}
    return NewPostgresStore(runtimePool),migrationPool,ctx
}

func fixtureAdmin(t *testing.T,ctx context.Context,db *pgxpool.Pool,now time.Time)Credentials{
    t.Helper();id,err:=uuid();if err!=nil{t.Fatal(err)}
    c:=Credentials{ID:id,Username:"review_"+strings.ReplaceAll(id,"-","")[:16],PasswordHash:"$argon2id$v=19$m=65536,t=3,p=1$synthetic-store-fixture$synthetic-store-fixture",TOTPCiphertext:make([]byte,48),Roles:[]string{Moderator},Generation:1,LastCounter:-1}
    if _,err=db.Exec(ctx,`INSERT INTO notitle.admin_users(id,username,password_hash,totp_ciphertext,roles,created_at) VALUES($1,$2,$3,$4,$5,$6)`,c.ID,c.Username,c.PasswordHash,c.TOTPCiphertext,c.Roles,now);err!=nil{t.Fatal("provision synthetic admin",err)}
    return c
}

func TestIntegrationAdminConcurrentOTPReplayAndExpiry(t *testing.T){
    store,migration,ctx:=adminIntegration(t);now:=time.Now().UTC().Truncate(time.Microsecond);c:=fixtureAdmin(t,ctx,migration,now)
    hashes:=[][32]byte{digest("test",c.ID+"first"),digest("test",c.ID+"second")}
    outcomes:=make(chan int,2);var wg sync.WaitGroup
    for i,hash:=range hashes{wg.Add(1);go func(i int,hash [32]byte){defer wg.Done();err:=store.CreateSession(ctx,SessionInput{Credentials:c,Counter:now.Unix()/30,TokenHash:hash,At:now});if err==nil{outcomes<-i}else if !errors.Is(err,ErrCredentials){outcomes<- -2}}(i,hash)}
    wg.Wait();close(outcomes);winner:=-1;count:=0
    for i:=range outcomes{if i<0{t.Fatal("unexpected transaction failure")};winner=i;count++};if count!=1{t.Fatalf("accepted %d concurrent OTP uses",count)}
    p,err:=store.Authenticate(ctx,hashes[winner],now.Add(time.Minute));if err!=nil||p.ID!=c.ID{t.Fatal("valid session rejected")}
    if _,err=store.Authenticate(ctx,hashes[winner],now.Add(16*time.Minute));!errors.Is(err,ErrCredentials){t.Fatal("idle-expired session accepted")}
    var auditCount int;if err=store.db.QueryRow(ctx,`SELECT count(*) FROM notitle.admin_audit WHERE admin_id=$1 AND action='login' AND result='success'`,c.ID).Scan(&auditCount);err!=nil||auditCount!=1{t.Fatal("login audit is not atomic")}
}

func TestIntegrationAdminRevocationAndRestrictedGrants(t *testing.T){
    store,migration,ctx:=adminIntegration(t);now:=time.Now().UTC().Truncate(time.Microsecond);c:=fixtureAdmin(t,ctx,migration,now);hash:=digest("test",c.ID)
    if err:=store.CreateSession(ctx,SessionInput{Credentials:c,Counter:now.Unix()/30,TokenHash:hash,At:now});err!=nil{t.Fatal(err)}
    if _,err:=migration.Exec(ctx,`UPDATE notitle.admin_users SET disabled=true,generation=generation+1 WHERE id=$1`,c.ID);err!=nil{t.Fatal(err)}
    if _,err:=store.Authenticate(ctx,hash,now.Add(time.Second));!errors.Is(err,ErrCredentials){t.Fatal("disabled operator retained access")}
    if err:=store.CreateSession(ctx,SessionInput{Credentials:c,Counter:now.Unix()/30+1,TokenHash:digest("test",c.ID+"retry"),At:now.Add(30*time.Second)});!errors.Is(err,ErrCredentials){t.Fatal("stale credential snapshot accepted")}
    if _,err:=store.db.Exec(ctx,`UPDATE notitle.admin_users SET roles=ARRAY['owner'] WHERE id=$1`,c.ID);err==nil{t.Fatal("runtime could elevate operator roles")}
    if _,err:=store.db.Exec(ctx,`UPDATE notitle.admin_audit SET reason='tampered' WHERE admin_id=$1`,c.ID);err==nil{t.Fatal("runtime could rewrite audit")}
    if _,err:=store.db.Exec(ctx,`DELETE FROM notitle.admin_audit WHERE admin_id=$1`,c.ID);err==nil{t.Fatal("runtime could erase audit")}
    if _,err:=store.db.Exec(ctx,`DELETE FROM notitle.admin_users WHERE id=$1`,c.ID);err==nil{t.Fatal("runtime could erase operator")}
}
