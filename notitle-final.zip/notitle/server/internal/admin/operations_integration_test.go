package admin

import (
    "errors"
    "strings"
    "testing"
    "time"

    "notitle/internal/identity"
)
func TestIntegrationPhase9EvidenceGuardRejectsRevokedSessionAndAuditSearchRoles(t *testing.T){
    store,migration,ctx:=adminIntegration(t);now:=time.Now().UTC().Truncate(time.Microsecond);c:=fixtureAdmin(t,ctx,migration,now);hash:=digest("test",c.ID)
    if err:=store.CreateSession(ctx,SessionInput{Credentials:c,Counter:now.Unix()/30,TokenHash:hash,At:now});err!=nil{t.Fatal(err)}
    p:=Principal{ID:c.ID,Username:c.Username,Roles:c.Roles,Generation:c.Generation};a:=Audit{AdminID:p.ID,Action:"case_evidence",SubjectRef:strings.Repeat("r",32),Reason:"Review submitted evidence",Result:"success",At:now}
    if err:=store.AuditView(ctx,p,hash,"cases",a);err!=nil{t.Fatal("valid guarded view",err)}
    q:=AuditQuery{From:now.Add(-time.Hour),Until:now.Add(time.Second),Reason:"Review operator actions"};if _,err:=store.SearchAudit(ctx,p,hash,q,now);!errors.Is(err,ErrForbidden){t.Fatal("moderator searched owner audit",err)}
    if _,err:=migration.Exec(ctx,`DELETE FROM notitle.admin_sessions WHERE token_hash=$1`,hash[:]);err!=nil{t.Fatal(err)}
    if err:=store.AuditView(ctx,p,hash,"cases",a);!errors.Is(err,ErrCredentials){t.Fatal("revoked session viewed evidence",err)}
}
func TestIntegrationOfflineRoleChangeRequiresOwnerMFARevokesAndAudits(t *testing.T){
    store,migration,ctx:=adminIntegration(t);now:=time.Now().UTC().Truncate(time.Microsecond);owner:=fixtureAdmin(t,ctx,migration,now);target:=fixtureAdmin(t,ctx,migration,now);key:=[]byte(strings.Repeat("k",32));raw:=[]byte("12345678901234567890");password:="Private-owner-password-123"
    hash,err:=identity.NewArgon2Hasher().Hash(ctx,password);if err!=nil{t.Fatal(err)};encrypted,err:=encryptMFA(key,owner.ID,raw);if err!=nil{t.Fatal(err)}
    if _,err=migration.Exec(ctx,`UPDATE notitle.admin_users SET roles=ARRAY['owner'],password_hash=$2,totp_ciphertext=$3 WHERE id=$1`,owner.ID,hash,encrypted);err!=nil{t.Fatal(err)}
    session:=digest("test",target.ID);if err=store.CreateSession(ctx,SessionInput{Credentials:target,Counter:now.Unix()/30,TokenHash:session,At:now});err!=nil{t.Fatal(err)}
    input:=LifecycleInput{Username:target.Username,AuthorizerUsername:owner.Username,AuthorizerPassword:password,AuthorizerCode:totp(raw,time.Now().Unix()/30,6),Action:"roles",Roles:[]string{OperationsReadonly},Reason:"Reassign documented backup duty",ExpectedGeneration:1}
    if err=ManageOperator(ctx,migration,key,input,"");err!=nil{t.Fatal("authorized offline change",err)}
    if _,err=store.Authenticate(ctx,session,time.Now());!errors.Is(err,ErrCredentials){t.Fatal("old operator session survived")}
    var generation int64;var roles []string;if err=migration.QueryRow(ctx,`SELECT generation,roles FROM notitle.admin_users WHERE id=$1`,target.ID).Scan(&generation,&roles);err!=nil||generation!=2||len(roles)!=1||roles[0]!=OperationsReadonly{t.Fatal("role generation mismatch",err)}
    var count int;if err=migration.QueryRow(ctx,`SELECT count(*) FROM notitle.admin_audit WHERE admin_id=$1 AND subject_ref=$2 AND action='operator_roles_offline'`,owner.ID,target.ID).Scan(&count);err!=nil||count!=1{t.Fatal("offline actor audit missing")}
    input.ExpectedGeneration=2;if err=ManageOperator(ctx,migration,key,input,"");!errors.Is(err,ErrCredentials){t.Fatal("replayed owner OTP accepted",err)}
}
func TestLifecycleInputsRejectSilentPrivilegeChanges(t *testing.T){
    valid:=LifecycleInput{Username:"target",AuthorizerUsername:"founder",AuthorizerPassword:"Strong-owner-password",AuthorizerCode:"123456",Action:"roles",Roles:[]string{Moderator},Reason:"Appointed backup operator",ExpectedGeneration:3};if !validLifecycleInput(valid){t.Fatal("valid input rejected")}
    for _,mode:=range []string{"generation","actor","role","disable_with_roles","action"}{in:=valid;switch mode{case "generation":in.ExpectedGeneration=0;case "actor":in.AuthorizerUsername="";case "role":in.Roles=[]string{"superadmin"};case "disable_with_roles":in.Action="disable";case "action":in.Action="delete"};if validLifecycleInput(in){t.Fatal("invalid lifecycle accepted",mode)}}
}
