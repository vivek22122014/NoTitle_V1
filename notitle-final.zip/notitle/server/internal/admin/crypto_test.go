package admin

import (
    "strings"
    "testing"
    "time"
)

// SHA-1 eight-digit examples from RFC 6238 Appendix B. Production deliberately
// selects six digits, while the underlying truncation shares these vectors.
func TestRFC6238Vectors(t *testing.T){
    secret:=[]byte("12345678901234567890")
    for _,v:=range []struct{unix int64;want string}{{59,"94287082"},{1111111109,"07081804"},{1111111111,"14050471"},{1234567890,"89005924"},{2000000000,"69279037"},{20000000000,"65353130"}}{
        if got:=totp(secret,v.unix/30,8);got!=v.want{t.Fatalf("counter %d got %s",v.unix/30,got)}
    }
}

func TestTOTPWindowAndReplay(t *testing.T){
    raw:=[]byte("12345678901234567890");now:=time.Unix(1234567890,0);counter:=now.Unix()/30
    for _,offset:=range []int64{-1,0,1}{got,ok:=verifyTOTP(raw,totp(raw,counter+offset,6),now,counter-2);if !ok||got!=counter+offset{t.Fatalf("offset %d rejected",offset)}}
    if _,ok:=verifyTOTP(raw,totp(raw,counter,6),now,counter);ok{t.Fatal("replayed counter accepted")}
    if _,ok:=verifyTOTP(raw,totp(raw,counter-2,6),now,-1);ok{t.Fatal("expired code accepted")}
    if _,ok:=verifyTOTP(raw,"１２３４５６",now,-1);ok{t.Fatal("non-ASCII code accepted")}
}

func TestMFAEncryptionBoundToOperator(t *testing.T){
    key:=[]byte(strings.Repeat("k",32));raw:=[]byte("12345678901234567890")
    encrypted,err:=encryptMFA(key,"operator-a",raw);if err!=nil{t.Fatal(err)}
    plain,err:=decryptMFA(key,"operator-a",encrypted);if err!=nil||string(plain)!=string(raw){t.Fatal("roundtrip failed")}
    if _,err=decryptMFA(key,"operator-b",encrypted);err==nil{t.Fatal("cross-operator ciphertext accepted")}
    encrypted[len(encrypted)-1]^=1;if _,err=decryptMFA(key,"operator-a",encrypted);err==nil{t.Fatal("tamper accepted")}
}

func TestRoleSeparation(t *testing.T){
    for _,role:=range []string{Owner,Moderator,GrievanceOfficer}{if !CanReview([]string{role})||!canAction([]string{role},"suspend"){t.Fatal(role)}}
    for _,role:=range []string{BillingOperator,OperationsReadonly,"unknown"}{if CanReview([]string{role})||canAction([]string{role},"resolve"){t.Fatal("case access leaked to",role)}}
    if ValidRoles([]string{Owner,Owner})||ValidRoles(nil)||ValidRoles([]string{"superadmin"}){t.Fatal("invalid role selection")}
}
