package admin

import (
    "context"
    "time"

    "github.com/jackc/pgx/v5"
    "github.com/jackc/pgx/v5/pgxpool"
)

type Credentials struct {
    ID string
    Username string
    PasswordHash string
    TOTPCiphertext []byte
    Roles []string
    Generation int64
    LastCounter int64
}
type Principal struct { ID string; Username string; Roles []string; Generation int64 }
type Audit struct { AdminID string; Action string; SubjectRef string; Reason string; Result string; At time.Time }
type SessionInput struct { Credentials Credentials; Counter int64; TokenHash [32]byte; At time.Time }

type Store interface {
    FindCredentials(context.Context,string)(Credentials,error)
    CreateSession(context.Context,SessionInput) error
    Authenticate(context.Context,[32]byte,time.Time)(Principal,error)
    Logout(context.Context,[32]byte,Principal,time.Time)error
    Audit(context.Context,Audit)error
}

type PostgresStore struct { db *pgxpool.Pool }
func NewPostgresStore(db *pgxpool.Pool)*PostgresStore { return &PostgresStore{db:db} }

func (s *PostgresStore) FindCredentials(ctx context.Context,name string)(Credentials,error){
    var c Credentials
    err:=s.db.QueryRow(ctx,`SELECT id::text,username,password_hash,totp_ciphertext,roles,generation,last_counter FROM notitle.admin_users WHERE username=$1 AND NOT disabled`,name).Scan(&c.ID,&c.Username,&c.PasswordHash,&c.TOTPCiphertext,&c.Roles,&c.Generation,&c.LastCounter)
    if err==pgx.ErrNoRows{return c,ErrCredentials};if err!=nil{return c,ErrUnavailable};return c,nil
}

func writeAudit(ctx context.Context,tx pgx.Tx,a Audit)error{
    id,err:=uuid();if err!=nil{return err}
    var adminID any;if a.AdminID!=""{adminID=a.AdminID}
    _,err=tx.Exec(ctx,`INSERT INTO notitle.admin_audit(id,admin_id,action,subject_ref,reason,result,created_at) VALUES($1,$2,$3,$4,$5,$6,$7)`,id,adminID,a.Action,a.SubjectRef,a.Reason,a.Result,a.At)
    if err!=nil{return ErrUnavailable};return nil
}

func(s *PostgresStore)Audit(ctx context.Context,a Audit)error{
    tx,err:=s.db.Begin(ctx);if err!=nil{return ErrUnavailable};defer tx.Rollback(context.Background())
    if err=writeAudit(ctx,tx,a);err!=nil{return err};if err=tx.Commit(ctx);err!=nil{return ErrUnavailable};return nil
}

func(s *PostgresStore)CreateSession(ctx context.Context,in SessionInput)error{
    tx,err:=s.db.Begin(ctx);if err!=nil{return ErrUnavailable};defer tx.Rollback(context.Background())
    // Row locking plus last_counter comparison prevents concurrent OTP replay.
    command,err:=tx.Exec(ctx,`UPDATE notitle.admin_users SET last_counter=$2 WHERE id=$1 AND NOT disabled AND generation=$3 AND password_hash=$4 AND last_counter < $2`,in.Credentials.ID,in.Counter,in.Credentials.Generation,in.Credentials.PasswordHash)
    if err!=nil{return ErrUnavailable};if command.RowsAffected()!=1{return ErrCredentials}
    _,err=tx.Exec(ctx,`DELETE FROM notitle.admin_sessions WHERE absolute_expires_at <= $1 OR last_seen_at <= $1 - interval '15 minutes'`,in.At)
    if err!=nil{return ErrUnavailable}
    // A small number of sessions is enough for private operators. Eviction is
    // explicit server revocation, never a new bearer returned to another user.
    _,err=tx.Exec(ctx,`DELETE FROM notitle.admin_sessions WHERE token_hash IN (SELECT token_hash FROM notitle.admin_sessions WHERE admin_id=$1 ORDER BY created_at DESC OFFSET 4)`,in.Credentials.ID)
    if err!=nil{return ErrUnavailable}
    _,err=tx.Exec(ctx,`INSERT INTO notitle.admin_sessions(token_hash,admin_id,admin_generation,created_at,last_seen_at,absolute_expires_at) VALUES($1,$2,$3,$4,$4,$5)`,in.TokenHash[:],in.Credentials.ID,in.Credentials.Generation,in.At,in.At.Add(4*time.Hour))
    if err!=nil{return ErrUnavailable}
    if err=writeAudit(ctx,tx,Audit{AdminID:in.Credentials.ID,Action:"login",Result:"success",At:in.At});err!=nil{return err}
    if err=tx.Commit(ctx);err!=nil{return ErrUnavailable};return nil
}

func(s *PostgresStore)Authenticate(ctx context.Context,hash [32]byte,now time.Time)(Principal,error){
    var p Principal
    err:=s.db.QueryRow(ctx,`UPDATE notitle.admin_sessions AS s SET last_seen_at=GREATEST(s.last_seen_at,$2) FROM notitle.admin_users AS a WHERE s.token_hash=$1 AND s.admin_id=a.id AND s.admin_generation=a.generation AND NOT a.disabled AND s.created_at<=$2 AND s.absolute_expires_at>$2 AND s.last_seen_at>$2 - interval '15 minutes' RETURNING a.id::text,a.username,a.roles,a.generation`,hash[:],now).Scan(&p.ID,&p.Username,&p.Roles,&p.Generation)
    if err==pgx.ErrNoRows{return p,ErrCredentials};if err!=nil{return p,ErrUnavailable};if !ValidRoles(p.Roles){return Principal{},ErrForbidden};return p,nil
}

func(s *PostgresStore)Logout(ctx context.Context,hash [32]byte,p Principal,now time.Time)error{
    tx,err:=s.db.Begin(ctx);if err!=nil{return ErrUnavailable};defer tx.Rollback(context.Background())
    // Match the moderation transaction lock order so logout cannot return
    // before an already-authorized concurrent action finishes committing.
    var locked string
    if err=tx.QueryRow(ctx,`SELECT id::text FROM notitle.admin_users WHERE id=$1 FOR UPDATE`,p.ID).Scan(&locked);err!=nil{return ErrUnavailable}
    _,err=tx.Exec(ctx,`DELETE FROM notitle.admin_sessions WHERE token_hash=$1 AND admin_id=$2`,hash[:],p.ID);if err!=nil{return ErrUnavailable}
    if err=writeAudit(ctx,tx,Audit{AdminID:p.ID,Action:"logout",Result:"success",At:now});err!=nil{return err};if err=tx.Commit(ctx);err!=nil{return ErrUnavailable};return nil
}
