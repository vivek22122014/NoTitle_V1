package admin

import (
    "context"
    "errors"
    "net/http"
    "strings"
    "time"

    "notitle/internal/observability"
    "notitle/internal/operations"
    "notitle/internal/privacy"
)
type OperationsBackend interface {
    Cases(context.Context,operations.AdminGuard,int)([]operations.CaseSummary,error)
    Case(context.Context,operations.AdminGuard,string)(operations.CaseDetail,error)
    Action(context.Context,operations.AdminGuard,operations.CaseAction)(operations.CaseDetail,error)
}
type PrivacyBackend interface {
    Worklist(context.Context,privacy.AdminGuard)(privacy.Worklist,error)
    PutHold(context.Context,privacy.AdminGuard,privacy.HoldInput)(privacy.Hold,error)
    ReviewHold(context.Context,privacy.AdminGuard,string,int64,string,time.Time)(privacy.Hold,error)
    ReleaseHold(context.Context,privacy.AdminGuard,string,int64,string)(privacy.Hold,error)
    SchedulePurge(context.Context,privacy.AdminGuard,privacy.PurgeInput)(privacy.PurgeJob,error)
}
type DashboardBackend interface {
    Snapshot(context.Context)(observability.Snapshot,error)
    Acknowledge(context.Context,observability.AcknowledgeInput)error
}
type operationsPage struct {
    Cases []operations.CaseSummary
    Case operations.CaseDetail
    Privacy privacy.Worklist
    Dashboard observability.Snapshot
    Audit []AuditRecord
    RequestKey string
    Owner bool
}
func(h *Handler)serveOperations(w http.ResponseWriter,r *http.Request,p Principal,session string,data pageData)bool{
    path:=r.URL.Path
    if path!="/support"&&!strings.HasPrefix(path,"/support/")&&path!="/privacy"&&!strings.HasPrefix(path,"/privacy/")&&path!="/operations"&&!strings.HasPrefix(path,"/operations/")&&path!="/audit"&&path!="/audit/search"{return false}
    data.Operations.Owner=hasRole(p.Roles,Owner)
    if path=="/operations/admission"{h.serveAdmission(w,r,p,session,data);return true}
    if path=="/operations/metrics"{h.serveMetrics(w,r,p,session,data);return true}
    switch {
    case path=="/audit"||path=="/audit/search":h.serveAudit(w,r,p,session,data)
    case path=="/operations"||strings.HasPrefix(path,"/operations/"):h.serveDashboard(w,r,p,session,data)
    case path=="/privacy"||strings.HasPrefix(path,"/privacy/"):h.servePrivacy(w,r,p,session,data)
    default:h.serveSupport(w,r,p,session,data)
    };return true
}
func(h *Handler)serveSupport(w http.ResponseWriter,r *http.Request,p Principal,session string,data pageData){
    if !CanGrieve(p.Roles){h.denyOperations(w,r,p,"This role does not permit grievance access");return};if h.operations==nil{http.Error(w,"Support operations unavailable",503);return}
    guard:=operations.AdminGuard{AdminID:p.ID,Generation:p.Generation,SessionHash:digest("session",session)}
    if r.URL.Path=="/support"&&r.Method=="GET"{data.Page="support_access";h.render(w,data);return}
    if r.URL.Path=="/support/worklist"&&r.Method=="POST"{
        if !strictFields(r.PostForm,"csrf"){http.Error(w,"Invalid form",400);return}
        cases,err:=h.operations.Cases(r.Context(),guard,100);if err!=nil{h.operationsError(w,r,p,err);return};data.Page="support_worklist";data.Operations.Cases=cases;h.render(w,data);return
    }
    parts:=strings.Split(strings.TrimPrefix(r.URL.Path,"/support/cases/"),"/");if len(parts)<1||len(parts)>2||!strings.HasPrefix(r.URL.Path,"/support/cases/")||!validReference(parts[0]){http.NotFound(w,r);return};ref:=parts[0];data.Ref=ref
    if len(parts)==1&&r.Method=="GET"{data.Page="support_case_access";h.render(w,data);return}
    if len(parts)!=2||r.Method!="POST"{http.NotFound(w,r);return}
    var detail operations.CaseDetail;var err error
    switch parts[1]{
    case "detail":
        if !strictFields(r.PostForm,"csrf","reason")||!validOperationReason(r.PostForm.Get("reason")){http.Error(w,"Invalid review purpose",400);return};guard.Reason=r.PostForm.Get("reason");detail,err=h.operations.Case(r.Context(),guard,ref)
    case "action":
        if !strictFields(r.PostForm,"csrf","version","action","reason","message","category","assignee","submission_id"){http.Error(w,"Invalid form",400);return}
        version,ok:=formInteger(r.PostForm.Get("version"),1,1<<62);if !ok||!validOperationReason(r.PostForm.Get("reason"))||!validToken(r.PostForm.Get("submission_id")){http.Error(w,"Use the current case version, request key and a short reason code",400);return}
        action:=r.PostForm.Get("action");switch action{case "ack","note","reply","resolve","reopen","reclassify","assign":default:http.Error(w,"Case action not permitted",403);return}
        detail,err=h.operations.Action(r.Context(),guard,operations.CaseAction{CaseRef:ref,Action:action,Reason:r.PostForm.Get("reason"),Message:r.PostForm.Get("message"),Category:r.PostForm.Get("category"),Assignee:r.PostForm.Get("assignee"),SubmissionID:r.PostForm.Get("submission_id"),ExpectedVersion:version})
    default:http.NotFound(w,r);return
    }
    if err!=nil{h.operationsError(w,r,p,err);return};if detail.Ref!=ref{http.Error(w,"Case unavailable",503);return}
    key,err:=secret();if err!=nil{http.Error(w,"Operations unavailable",503);return};data.Page="support_case";data.Operations.Case=detail;data.Operations.RequestKey=key;h.render(w,data)
}
func validOperationReason(s string)bool{if len(s)<3||len(s)>64||s[0]<'a'||s[0]>'z'{return false};for _,r:=range s{if !(r>='a'&&r<='z'||r>='0'&&r<='9'||r=='_'){return false}};return true}
func(h *Handler)servePrivacy(w http.ResponseWriter,r *http.Request,p Principal,session string,data pageData){
    if !CanGrieve(p.Roles){h.denyOperations(w,r,p,"This role does not permit privacy operations");return};if h.privacy==nil{http.Error(w,"Privacy operations unavailable",503);return}
    guard:=privacy.AdminGuard{OperatorID:p.ID,Generation:p.Generation,SessionHash:digest("session",session),Now:h.now().UTC()}
    if r.URL.Path=="/privacy"&&r.Method=="GET"{data.Page="privacy_access";h.render(w,data);return}
    if r.Method!="POST"{http.NotFound(w,r);return}
    if r.URL.Path=="/privacy/worklist"{if !strictFields(r.PostForm,"csrf"){http.Error(w,"Invalid form",400);return};result,err:=h.privacy.Worklist(r.Context(),guard);if err!=nil{h.operationsError(w,r,p,err);return};data.Page="privacy_worklist";data.Operations.Privacy=result;h.render(w,data);return}
    reason:=r.PostForm.Get("reason");if !validReason(reason){http.Error(w,"Give an authorized work purpose of 5–1000 characters",400);return}
    switch r.URL.Path{
    case "/privacy/holds":
        if !strictFields(r.PostForm,"csrf","scope_kind","scope_ref","reason","review_at")||!validReference(r.PostForm.Get("scope_ref")){http.Error(w,"Invalid hold scope",400);return}
        reviewAt,err:=time.Parse(time.RFC3339,r.PostForm.Get("review_at"));if err!=nil{http.Error(w,"Use a review date with timezone",400);return}
        _,err=h.privacy.PutHold(r.Context(),guard,privacy.HoldInput{ScopeKind:r.PostForm.Get("scope_kind"),ScopeRef:r.PostForm.Get("scope_ref"),Reason:reason,ReviewAt:reviewAt});if err!=nil{h.operationsError(w,r,p,err);return}
    case "/privacy/holds/review","/privacy/holds/release":
        if !strictFields(r.PostForm,"csrf","hold_id","version","reason","review_at")||!validReference(r.PostForm.Get("hold_id")){http.Error(w,"Invalid hold request",400);return};version,ok:=formInteger(r.PostForm.Get("version"),1,1<<62);if !ok{http.Error(w,"Current hold version required",400);return}
        var err error;if r.URL.Path=="/privacy/holds/review"{at,e:=time.Parse(time.RFC3339,r.PostForm.Get("review_at"));if e!=nil{http.Error(w,"Use a review date with timezone",400);return};_,err=h.privacy.ReviewHold(r.Context(),guard,r.PostForm.Get("hold_id"),version,reason,at)}else{_,err=h.privacy.ReleaseHold(r.Context(),guard,r.PostForm.Get("hold_id"),version,reason)};if err!=nil{h.operationsError(w,r,p,err);return}
    case "/privacy/purge":
        if !strictFields(r.PostForm,"csrf","kind","subject_ref","reason","not_before")||!validReference(r.PostForm.Get("subject_ref")){http.Error(w,"Invalid purge scope",400);return};if r.PostForm.Get("kind")=="financial"&&!hasRole(p.Roles,Owner){h.denyOperations(w,r,p,"Financial retention requires owner authority");return}
        var at time.Time;var err error;if r.PostForm.Get("not_before")!=""{at,err=time.Parse(time.RFC3339,r.PostForm.Get("not_before"));if err!=nil{http.Error(w,"Use a retention date with timezone",400);return}};_,err=h.privacy.SchedulePurge(r.Context(),guard,privacy.PurgeInput{Kind:r.PostForm.Get("kind"),SubjectRef:r.PostForm.Get("subject_ref"),Reason:reason,NotBefore:at});if err!=nil{h.operationsError(w,r,p,err);return}
    default:http.NotFound(w,r);return
    };http.Redirect(w,r,"/privacy",303)
}
func(h *Handler)serveDashboard(w http.ResponseWriter,r *http.Request,p Principal,session string,data pageData){
    if !CanOperate(p.Roles){h.denyOperations(w,r,p,"This role does not permit system operations");return};if h.observability==nil{http.Error(w,"Monitoring unavailable",503);return}
    if r.URL.Path=="/operations/ack"&&r.Method=="POST"{
        if !hasRole(p.Roles,Owner){h.denyOperations(w,r,p,"Read-only operators cannot acknowledge alerts");return}
        if !strictFields(r.PostForm,"csrf","alert_id","version","reason")||!validReference(r.PostForm.Get("alert_id"))||!validReason(r.PostForm.Get("reason")){http.Error(w,"Invalid alert decision",400);return};version,ok:=formInteger(r.PostForm.Get("version"),1,1<<62);if !ok{http.Error(w,"Current alert version required",400);return}
        if err:=h.observability.Acknowledge(r.Context(),observability.AcknowledgeInput{ActorID:p.ID,Generation:p.Generation,SessionHash:digest("session",session),Reason:r.PostForm.Get("reason"),AlertID:r.PostForm.Get("alert_id"),ExpectedVersion:version});err!=nil{h.operationsError(w,r,p,err);return};http.Redirect(w,r,"/operations",303);return
    }
    if r.URL.Path!="/operations"||r.Method!="GET"{http.NotFound(w,r);return}
    snapshot,err:=h.observability.Snapshot(r.Context());if err!=nil{h.operationsError(w,r,p,err);return}
    if err=h.auditView(r.Context(),p,session,"operations","operations_dashboard","","Review aggregate operational health");err!=nil{http.Error(w,"Audit unavailable",503);return};data.Page="operations_dashboard";data.Operations.Dashboard=snapshot;h.render(w,data)
}
func(h *Handler)serveAudit(w http.ResponseWriter,r *http.Request,p Principal,session string,data pageData){
    if !hasRole(p.Roles,Owner){h.denyOperations(w,r,p,"Audit search requires owner authority");return}
    if r.URL.Path=="/audit"&&r.Method=="GET"{data.Page="audit_access";h.render(w,data);return}
    if r.URL.Path!="/audit/search"||r.Method!="POST"{http.NotFound(w,r);return}
    if !strictFields(r.PostForm,"csrf","from","until","action","result","subject_ref","reason"){http.Error(w,"Invalid audit filter",400);return}
    from,e1:=time.Parse(time.RFC3339,r.PostForm.Get("from"));until,e2:=time.Parse(time.RFC3339,r.PostForm.Get("until"));q:=AuditQuery{From:from,Until:until,Action:r.PostForm.Get("action"),Result:r.PostForm.Get("result"),SubjectRef:r.PostForm.Get("subject_ref"),Reason:r.PostForm.Get("reason")};if e1!=nil||e2!=nil||!validAuditQuery(q,h.now()){http.Error(w,"Use explicit timezone dates spanning at most 31 days and an audit purpose",400);return}
    store,ok:=h.store.(auditSearcher);if !ok{http.Error(w,"Audit search unavailable",503);return};records,err:=store.SearchAudit(r.Context(),p,digest("session",session),q,h.now());if err!=nil{h.operationsError(w,r,p,err);return};data.Page="audit_results";data.Operations.Audit=records;h.render(w,data)
}
func(h *Handler)operationsError(w http.ResponseWriter,r *http.Request,p Principal,err error){
    result:="failed";if errors.Is(err,operations.ErrUnauthorized)||errors.Is(err,privacy.ErrUnauthorized)||errors.Is(err,privacy.ErrForbidden)||errors.Is(err,observability.ErrUnauthorized)||errors.Is(err,ErrForbidden)||errors.Is(err,ErrCredentials){result="denied"}
    _=h.audit(r.Context(),p,"operations_request","","Private operation did not complete",result)
    switch {
    case errors.Is(err,operations.ErrUnauthorized),errors.Is(err,privacy.ErrUnauthorized),errors.Is(err,privacy.ErrForbidden),errors.Is(err,observability.ErrUnauthorized),errors.Is(err,ErrCredentials),errors.Is(err,ErrForbidden):http.Error(w,"Operator authority changed; sign in again",403)
    case errors.Is(err,operations.ErrNotFound):http.Error(w,"Case unavailable",404)
    case errors.Is(err,operations.ErrInvalid),errors.Is(err,privacy.ErrInvalid),errors.Is(err,observability.ErrInvalid),errors.Is(err,ErrInvalid):http.Error(w,"Invalid operations request",400)
    case errors.Is(err,operations.ErrConflict),errors.Is(err,privacy.ErrConflict),errors.Is(err,privacy.ErrHeld),errors.Is(err,observability.ErrConflict):http.Error(w,"State changed or retention hold applies; reopen and review before retrying",409)
    case errors.Is(err,privacy.ErrPolicy):http.Error(w,"Approved retention rules are required before this action",503)
    default:http.Error(w,"Operations unavailable; verify the recorded state before retrying",503)
    }
}

var _ OperationsBackend = (*operations.Service)(nil)
var _ PrivacyBackend = (*privacy.Store)(nil)
var _ DashboardBackend = (*observability.Service)(nil)

func(h *Handler)denyOperations(w http.ResponseWriter,r *http.Request,p Principal,reason string){_=h.audit(r.Context(),p,"operations_access","",reason,"denied");http.Error(w,reason,403)}
