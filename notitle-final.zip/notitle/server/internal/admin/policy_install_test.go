package admin

import (
    "encoding/json"
    "errors"
    "os"
    "path/filepath"
    "strings"
    "testing"
    "time"

    "notitle/internal/identity"
    "notitle/internal/privacy"
)
func TestIntegrationPolicyInstallIsOwnerMFAAuditedAndVersionImmutable(t *testing.T){
    _,migration,ctx:=adminIntegration(t);now:=time.Now().UTC().Truncate(time.Second);owner:=fixtureAdmin(t,ctx,migration,now);key:=[]byte(strings.Repeat("k",32));raw:=[]byte("12345678901234567890");password:="Private-policy-owner-password-123"
    hash,err:=identity.NewArgon2Hasher().Hash(ctx,password);if err!=nil{t.Fatal(err)};encrypted,err:=encryptMFA(key,owner.ID,raw);if err!=nil{t.Fatal(err)}
    if _,err=migration.Exec(ctx,`UPDATE notitle.admin_users SET roles=ARRAY['owner'],password_hash=$2,totp_ciphertext=$3 WHERE id=$1`,owner.ID,hash,encrypted);err!=nil{t.Fatal(err)}
    policy:=privacy.Policy{Version:"fixture_"+strings.ReplaceAll(owner.ID,"-",""),StorageRegion:"IN",Approved:true,Approver:"Synthetic test fixture",ApprovalReference:"isolated-test-only",ReviewedAt:now.Add(-time.Hour),ReviewDueAt:now.AddDate(0,1,0),OrdinaryDeletionApproved:true,FinancialScheduleApproved:true,NoContentArchiveApproved:true}
    for purpose,trigger:=range map[string]string{"registration":"cancellation","cases":"closure","financial":"final_activity","security_logs":"collection","backups":"creation","metrics":"collection"}{policy.Rules=append(policy.Rules,privacy.RetentionRule{Purpose:purpose,Trigger:trigger,MinimumDays:180,MaximumDays:200,LegalSource:"https://example.invalid/synthetic-test",EffectiveAt:now.Add(-time.Hour),ReviewedUntil:now.AddDate(0,1,0)})}
    path:=filepath.Join(t.TempDir(),"retention.json");write:=func(){data,e:=json.Marshal(policy);if e!=nil{t.Fatal(e)};if e=os.WriteFile(path,data,0600);e!=nil{t.Fatal(e)}};write()
    input:=PolicyInstallInput{AuthorizerUsername:owner.Username,AuthorizerPassword:password,AuthorizerCode:totp(raw,time.Now().Unix()/30,6),Reason:"Synthetic isolated policy installation"}
    if err=InstallRetentionPolicy(ctx,migration,key,input,path);err!=nil{t.Fatal("install failed",err)}
    var actual string;if err=migration.QueryRow(ctx,`SELECT digest FROM notitle.retention_policies WHERE version=$1`,policy.Version).Scan(&actual);err!=nil||actual!=policy.Digest(){t.Fatal("canonical digest mismatch")}
    original:=actual;policy.Rules[0].MaximumDays++;write();input.AuthorizerCode=totp(raw,time.Now().Unix()/30+1,6)
    if err=InstallRetentionPolicy(ctx,migration,key,input,path);!errors.Is(err,ErrInvalid){t.Fatal("same version changed",err)}
    if err=migration.QueryRow(ctx,`SELECT digest FROM notitle.retention_policies WHERE version=$1`,policy.Version).Scan(&actual);err!=nil||actual!=original{t.Fatal("immutable version overwritten")}
    var count int;if err=migration.QueryRow(ctx,`SELECT count(*) FROM notitle.admin_audit WHERE admin_id=$1 AND action='retention_policy_install' AND subject_ref=$2`,owner.ID,policy.Version).Scan(&count);err!=nil||count!=1{t.Fatal("policy audit missing")}
}
