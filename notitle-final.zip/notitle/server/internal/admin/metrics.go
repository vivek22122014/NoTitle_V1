package admin

import (
    "context"
    "encoding/json"
    "net/http"

    "notitle/internal/performance"
)
type MetricsBackend interface{ProcessingSnapshot(context.Context)(performance.Export,error)}
func(h *Handler)serveMetrics(w http.ResponseWriter,r *http.Request,p Principal,session string,data pageData){
    if !CanOperate(p.Roles){h.denyOperations(w,r,p,"Aggregate export requires operations authority");return}
    if h.metrics==nil{http.Error(w,"Processing observations unavailable",503);return}
    if r.Method=="GET"{data.Page="metrics";h.render(w,data);return}
    if !strictFields(r.PostForm,"csrf","reason")||!validReason(r.PostForm.Get("reason")){http.Error(w,"Give an explicit observation purpose",400);return}
    result,err:=h.metrics.ProcessingSnapshot(r.Context());if err!=nil{http.Error(w,"Processing observations unavailable",503);return}
    if err=h.auditView(r.Context(),p,session,"operations","processing_metrics_export","",r.PostForm.Get("reason"));err!=nil{http.Error(w,"Operator authority or audit unavailable",503);return}
    w.Header().Set("Content-Type","application/json; charset=utf-8");w.Header().Set("Content-Disposition",`attachment; filename="notitle-processing-metrics.json"`)
    _=json.NewEncoder(w).Encode(result)
}
const metricsMarkup=`{{define "metrics"}}{{if eq .Page "metrics"}}<h1>Private processing observations</h1><p>Fixed process-local histograms contain no participant identifiers. Matching uses a conservative upper bound from the later queue request through commit, including pending paid-use authorization. Later profile changes can overcount; a process histogram alone does not prove the full launch benchmark.</p><form method="post" action="/operations/metrics"><input type="hidden" name="csrf" value="{{.CSRF}}"><label>Observation purpose<textarea name="reason" required minlength="5" maxlength="1000"></textarea></label><button>Download audited aggregate snapshot</button></form>{{end}}{{end}}`
