// Package identitypg implements durable identity transactions. It never receives
// bearer secrets, ordinary conversations, or guest records. The application role
// cannot delete accounts, consent history, or deletion jobs.
package identitypg

import (
    "context"
    "crypto/subtle"
    "errors"
    "time"

    "github.com/jackc/pgx/v5"
    "github.com/jackc/pgx/v5/pgconn"
    "github.com/jackc/pgx/v5/pgxpool"
    "notitle/internal/identity"
)

const MaxAccountSessions = 10

type Store struct { pool *pgxpool.Pool }

func New(pool *pgxpool.Pool) *Store { return &Store{pool: pool} }

var _ identity.Store = (*Store)(nil)

const accountColumns = `a.id::text, a.username, a.generation, a.status,
    p.display_name, p.gender, p.bio, p.topic, p.version,
    pp.profession, pp.industry, pp.experience,
    (SELECT COALESCE(array_agg(i.interest ORDER BY i.interest), ARRAY[]::text[])
        FROM notitle.professional_interests i WHERE i.account_id = a.id)`
const accountJoins = ` FROM notitle.accounts a
    JOIN notitle.profiles p ON p.account_id = a.id
    JOIN notitle.professional_profiles pp ON pp.account_id = a.id`

type scanner interface { Scan(...any) error }

func accountTargets(a *identity.Account) []any {
    return []any{&a.ID, &a.Username, &a.Generation, &a.Status,
        &a.Profile.DisplayName, &a.Profile.Gender, &a.Profile.Bio,
        &a.Profile.Topic, &a.Profile.Version, &a.Profile.Professional.Profession,
        &a.Profile.Professional.Industry, &a.Profile.Professional.Experience, &a.Profile.Professional.Interests}
}

func scanAccount(row scanner) (identity.Account, error) {
    var a identity.Account
    err := row.Scan(accountTargets(&a)...)
    return a, err
}

func (s *Store) FindCredentials(ctx context.Context, username string) (identity.Credentials, error) {
    var result identity.Credentials
    var recovery []byte
    targets := append(accountTargets(&result.Account), &result.PasswordHash, &recovery)
    err := s.pool.QueryRow(ctx, `SELECT `+accountColumns+`, a.password_hash, a.recovery_hash`+accountJoins+` WHERE a.username = $1 AND a.status = 'active'`, username).Scan(targets...)
    if errors.Is(err, pgx.ErrNoRows) { return result, identity.ErrCredentials }
    if err != nil || len(recovery) != len(result.RecoveryHash) { return identity.Credentials{}, identity.ErrUnavailable }
    copy(result.RecoveryHash[:], recovery)
    return result, nil
}

// All transactions lock the account before its sessions. The lock is the common
// serialization point for login, recovery, profile changes, and deletion.
func transact[T any](ctx context.Context, s *Store, work func(pgx.Tx) (T, error)) (T, error) {
    var zero T
    tx, err := s.pool.BeginTx(ctx, pgx.TxOptions{IsoLevel: pgx.ReadCommitted})
    if err != nil { return zero, identity.ErrUnavailable }
    defer func() {
        cleanup, cancel := context.WithTimeout(context.Background(), 2*time.Second)
        defer cancel()
        _ = tx.Rollback(cleanup)
    }()
    result, err := work(tx)
    if err != nil { return zero, err }
    // A commit error can be ambiguous. Never return a definite precommit error
    // here: guest handoff uses ErrUnavailable to end the guest safely.
    if err := tx.Commit(ctx); err != nil { return zero, identity.ErrUnavailable }
    return result, nil
}

func lockAccount(ctx context.Context, tx pgx.Tx, accountID string) (identity.Account, error) {
    // Acquire the account lock before reading joined profile rows in a fresh
    // statement snapshot. A single joined SELECT FOR UPDATE OF a can retain a
    // stale profile snapshot while waiting for another writer's account lock.
    var lockedID string
    err := tx.QueryRow(ctx, `SELECT id::text FROM notitle.accounts WHERE id=$1 FOR UPDATE`, accountID).Scan(&lockedID)
    if errors.Is(err, pgx.ErrNoRows) { return identity.Account{}, identity.ErrUnauthorized }
    if err != nil { return identity.Account{}, identity.ErrUnavailable }
    result, err := scanAccount(tx.QueryRow(ctx, `SELECT `+accountColumns+accountJoins+` WHERE a.id = $1`, lockedID))
    if err != nil { return identity.Account{}, identity.ErrUnavailable }
    if result.Status != "active" { return identity.Account{}, identity.ErrUnauthorized }
    return result, nil
}

func readSession(ctx context.Context, tx pgx.Tx, account identity.Account, sessionID string, verifier identity.Verifier) (identity.SessionRecord, error) {
    var result identity.SessionRecord
    var hash []byte
    err := tx.QueryRow(ctx, `SELECT id::text, token_hash, account_id::text, account_generation,
        created_at, last_seen_at, absolute_expires_at, authenticated_at
        FROM notitle.sessions WHERE id = $1 AND account_id = $2 AND token_hash = $3 AND revoked_at IS NULL`,
        sessionID, account.ID, verifier[:]).Scan(&result.ID, &hash, &result.AccountID,
        &result.AccountGeneration, &result.CreatedAt, &result.LastSeenAt,
        &result.AbsoluteExpiresAt, &result.AuthenticatedAt)
    if errors.Is(err, pgx.ErrNoRows) { return result, identity.ErrUnauthorized }
    if err != nil || len(hash) != len(result.TokenHash) { return identity.SessionRecord{}, identity.ErrUnavailable }
    copy(result.TokenHash[:], hash)
    if result.AccountGeneration != account.Generation { return identity.SessionRecord{}, identity.ErrUnauthorized }
    return result, nil
}

func sessionValid(session identity.SessionRecord, now time.Time) bool {
    return !now.Before(session.CreatedAt) && now.Before(session.AbsoluteExpiresAt) && now.Before(session.LastSeenAt.Add(identity.SessionIdleTTL))
}

func guardSession(ctx context.Context, tx pgx.Tx, guard identity.Guard) (identity.AccountSession, error) {
    account, err := lockAccount(ctx, tx, guard.AccountID)
    if err != nil { return identity.AccountSession{}, err }
    if account.Generation != guard.AccountGeneration { return identity.AccountSession{}, identity.ErrStale }
    session, err := readSession(ctx, tx, account, guard.SessionID, guard.TokenHash)
    if err != nil { return identity.AccountSession{}, err }
    if !sessionValid(session, guard.Now) { return identity.AccountSession{}, identity.ErrUnauthorized }
    if guard.RequireRecent && (guard.Now.Before(session.AuthenticatedAt) || !guard.Now.Before(session.AuthenticatedAt.Add(identity.RecentAuthenticationTTL))) {
        return identity.AccountSession{}, identity.ErrReauthentication
    }
    return identity.AccountSession{Account: account, Session: session}, nil
}

func insertSession(ctx context.Context, tx pgx.Tx, account identity.Account, session identity.SessionRecord) (identity.AccountSession, error) {
    session.AccountID = account.ID
    session.AccountGeneration = account.Generation
    if _, err := tx.Exec(ctx, `INSERT INTO notitle.sessions
        (id, token_hash, account_id, account_generation, created_at, last_seen_at, absolute_expires_at, authenticated_at)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`, session.ID, session.TokenHash[:], account.ID,
        account.Generation, session.CreatedAt, session.LastSeenAt, session.AbsoluteExpiresAt, session.AuthenticatedAt); err != nil {
        return identity.AccountSession{}, identity.ErrUnavailable
    }
    return identity.AccountSession{Account: account, Session: session}, nil
}

func revokeSessions(ctx context.Context, tx pgx.Tx, accountID string, now time.Time) error {
    _, err := tx.Exec(ctx, `UPDATE notitle.sessions SET revoked_at = $2 WHERE account_id = $1 AND revoked_at IS NULL`, accountID, now)
    if err != nil { return identity.ErrUnavailable }
    return nil
}

func (s *Store) CreateAccount(ctx context.Context, record identity.CreateAccountRecord) (identity.AccountSession, error) {
    return transact(ctx, s, func(tx pgx.Tx) (identity.AccountSession, error) {
        account := record.Account
        account.Generation = 1
        account.Status = "active"
        account.Profile.Version = 1
        _, err := tx.Exec(ctx, `INSERT INTO notitle.accounts (id,username,password_hash,recovery_hash,generation,status,created_at)
            VALUES ($1,$2,$3,$4,1,'active',$5)`, account.ID, account.Username, record.PasswordHash, record.RecoveryHash[:], record.CreatedAt)
        if err != nil {
            var pgErr *pgconn.PgError
            if errors.As(err, &pgErr) && pgErr.Code == "23505" && pgErr.ConstraintName == "accounts_username_key" { return identity.AccountSession{}, identity.ErrConflict }
            return identity.AccountSession{}, identity.ErrUnavailable
        }
        if err := insertProfile(ctx, tx, account, record.CreatedAt); err != nil { return identity.AccountSession{}, err }
        if record.GuestHandoff {
            // This row is never automatically cleared after restart. The
            // safety finalizer must first persist the coordinator's complete
            // post-upgrade safety snapshot in the same transaction as removal.
            if _,err:=tx.Exec(ctx,`INSERT INTO notitle.pending_safety_handoffs(account_id,created_at) VALUES($1,$2)`,account.ID,record.CreatedAt);err!=nil{return identity.AccountSession{},identity.ErrUnavailable}
        }
        if !record.Consent.AdultConfirmed || !identity.ValidPolicyVersions(record.Consent.Policies) { return identity.AccountSession{}, identity.ErrInvalid }
        _, err = tx.Exec(ctx, `INSERT INTO notitle.consent_events (account_id,policy_type,policy_version,accepted,recorded_at) VALUES
            ($1,'adult','18-plus-v1',true,$5),($1,'terms',$2,true,$5),($1,'privacy',$3,true,$5),($1,'community',$4,true,$5)`,
            account.ID, record.Consent.Policies.Terms, record.Consent.Policies.Privacy, record.Consent.Policies.Community, record.CreatedAt)
        if err != nil { return identity.AccountSession{}, identity.ErrUnavailable }
        return insertSession(ctx, tx, account, record.Session)
    })
}

func insertProfile(ctx context.Context, tx pgx.Tx, account identity.Account, now time.Time) error {
    p := account.Profile
    if err := identity.ValidateProfile(p); err != nil { return err }
    _, err := tx.Exec(ctx, `INSERT INTO notitle.profiles (account_id,display_name,gender,bio,topic,version,updated_at) VALUES ($1,$2,$3,$4,$5,1,$6)`,
        account.ID, p.DisplayName, p.Gender, p.Bio, p.Topic, now)
    if err != nil { return identity.ErrUnavailable }
    _, err = tx.Exec(ctx, `INSERT INTO notitle.professional_profiles (account_id,profession,industry,experience) VALUES ($1,$2,$3,$4)`,
        account.ID, p.Professional.Profession, p.Professional.Industry, p.Professional.Experience)
    if err != nil { return identity.ErrUnavailable }
    return writeInterests(ctx, tx, account.ID, p.Professional.Interests)
}

func writeInterests(ctx context.Context, tx pgx.Tx, accountID string, interests []string) error {
    if _, err := tx.Exec(ctx, `DELETE FROM notitle.professional_interests WHERE account_id=$1`, accountID); err != nil { return identity.ErrUnavailable }
    if len(interests) == 0 { return nil }
    _, err := tx.Exec(ctx, `INSERT INTO notitle.professional_interests (account_id,interest) SELECT $1::uuid, unnest($2::text[])`, accountID, interests)
    if err != nil { return identity.ErrUnavailable }
    return nil
}

func (s *Store) CreateSession(ctx context.Context, accountID string, expectedGeneration int64, session identity.SessionRecord, now time.Time) (identity.AccountSession, error) {
    return transact(ctx, s, func(tx pgx.Tx) (identity.AccountSession, error) {
        account, err := lockAccount(ctx, tx, accountID)
        if err != nil { return identity.AccountSession{}, err }
        if account.Generation != expectedGeneration { return identity.AccountSession{}, identity.ErrStale }
        // Revoke the oldest excess sessions before inserting the new one. This
        // cannot race a concurrent login because the account row stays locked.
        _, err = tx.Exec(ctx, `UPDATE notitle.sessions SET revoked_at = $2 WHERE id IN (
            SELECT id FROM notitle.sessions WHERE account_id = $1 AND revoked_at IS NULL
            ORDER BY created_at DESC, id DESC OFFSET $3)`, accountID, now, MaxAccountSessions-1)
        if err != nil { return identity.AccountSession{}, identity.ErrUnavailable }
        return insertSession(ctx, tx, account, session)
    })
}

func (s *Store) Authenticate(ctx context.Context, verifier identity.Verifier, now time.Time, touch bool) (identity.AccountSession, error) {
    return transact(ctx, s, func(tx pgx.Tx) (identity.AccountSession, error) {
        var accountID, sessionID string
        err := tx.QueryRow(ctx, `SELECT account_id::text,id::text FROM notitle.sessions WHERE token_hash = $1 AND revoked_at IS NULL`, verifier[:]).Scan(&accountID, &sessionID)
        if errors.Is(err, pgx.ErrNoRows) { return identity.AccountSession{}, identity.ErrUnauthorized }
        if err != nil { return identity.AccountSession{}, identity.ErrUnavailable }
        account, err := lockAccount(ctx, tx, accountID)
        if err != nil { return identity.AccountSession{}, err }
        session, err := readSession(ctx, tx, account, sessionID, verifier)
        if err != nil { return identity.AccountSession{}, err }
        if !sessionValid(session, now) { return identity.AccountSession{}, identity.ErrUnauthorized }
        if touch && now.After(session.LastSeenAt) {
            if _, err := tx.Exec(ctx, `UPDATE notitle.sessions SET last_seen_at = $2 WHERE id = $1`, session.ID, now); err != nil { return identity.AccountSession{}, identity.ErrUnavailable }
            session.LastSeenAt = now
        }
        return identity.AccountSession{Account: account, Session: session}, nil
    })
}

func (s *Store) UpdateProfile(ctx context.Context, guard identity.Guard, profile identity.Profile) (identity.Account, error) {
    return transact(ctx, s, func(tx pgx.Tx) (identity.Account, error) {
        current, err := guardSession(ctx, tx, guard)
        if err != nil { return identity.Account{}, err }
        if profile.Version != current.Account.Profile.Version { return identity.Account{}, identity.ErrStale }
        if err := identity.ValidateProfile(profile); err != nil { return identity.Account{}, err }
        profile.Version++
        _, err = tx.Exec(ctx, `UPDATE notitle.profiles SET display_name=$2,gender=$3,bio=$4,topic=$5,version=$6,updated_at=$7 WHERE account_id=$1`,
            current.Account.ID, profile.DisplayName, profile.Gender, profile.Bio, profile.Topic, profile.Version, guard.Now)
        if err != nil { return identity.Account{}, identity.ErrUnavailable }
        _, err = tx.Exec(ctx, `UPDATE notitle.professional_profiles SET profession=$2,industry=$3,experience=$4 WHERE account_id=$1`,
            current.Account.ID, profile.Professional.Profession, profile.Professional.Industry, profile.Professional.Experience)
        if err != nil { return identity.Account{}, identity.ErrUnavailable }
        if err := writeInterests(ctx, tx, current.Account.ID, profile.Professional.Interests); err != nil { return identity.Account{}, err }
        current.Account.Profile = profile
        return current.Account, nil
    })
}

func (s *Store) Reauthenticate(ctx context.Context, guard identity.Guard) error {
    _, err := transact(ctx, s, func(tx pgx.Tx) (struct{}, error) {
        guard.RequireRecent = false
        current, err := guardSession(ctx, tx, guard)
        if err != nil { return struct{}{}, err }
        _, err = tx.Exec(ctx, `UPDATE notitle.sessions SET authenticated_at=$2,last_seen_at=GREATEST(last_seen_at,$2) WHERE id=$1`, current.Session.ID, guard.Now)
        if err != nil { return struct{}{}, identity.ErrUnavailable }
        return struct{}{}, nil
    })
    return err
}

func (s *Store) ChangeCredentials(ctx context.Context, guard identity.Guard, mutation identity.CredentialMutation) (identity.AccountSession, error) {
    return transact(ctx, s, func(tx pgx.Tx) (identity.AccountSession, error) {
        guard.RequireRecent = true
        current, err := guardSession(ctx, tx, guard)
        if err != nil { return identity.AccountSession{}, err }
        if !mutation.ReplacePassword && !mutation.ReplaceRecovery { return identity.AccountSession{}, identity.ErrInvalid }
        _, err = tx.Exec(ctx, `UPDATE notitle.accounts SET
            password_hash=CASE WHEN $2 THEN $3 ELSE password_hash END,
            recovery_hash=CASE WHEN $4 THEN $5 ELSE recovery_hash END,
            generation=generation+1 WHERE id=$1`, current.Account.ID,
            mutation.ReplacePassword, mutation.PasswordHash, mutation.ReplaceRecovery, mutation.RecoveryHash[:])
        if err != nil { return identity.AccountSession{}, identity.ErrUnavailable }
        if err := revokeSessions(ctx, tx, current.Account.ID, guard.Now); err != nil { return identity.AccountSession{}, err }
        current.Account.Generation++
        return insertSession(ctx, tx, current.Account, mutation.NewSession)
    })
}

func (s *Store) Recover(ctx context.Context, mutation identity.RecoveryMutation) (identity.AccountSession, error) {
    return transact(ctx, s, func(tx pgx.Tx) (identity.AccountSession, error) {
        account, err := lockAccount(ctx, tx, mutation.AccountID)
        if errors.Is(err, identity.ErrUnauthorized) { return identity.AccountSession{}, identity.ErrCredentials }
        if err != nil { return identity.AccountSession{}, err }
        if account.Generation != mutation.ExpectedGeneration { return identity.AccountSession{}, identity.ErrCredentials }
        var existing []byte
        if err := tx.QueryRow(ctx, `SELECT recovery_hash FROM notitle.accounts WHERE id=$1`, account.ID).Scan(&existing); err != nil { return identity.AccountSession{}, identity.ErrUnavailable }
        if subtle.ConstantTimeCompare(existing, mutation.ExpectedRecoveryHash[:]) != 1 { return identity.AccountSession{}, identity.ErrCredentials }
        _, err = tx.Exec(ctx, `UPDATE notitle.accounts SET password_hash=$2,recovery_hash=$3,generation=generation+1 WHERE id=$1`, account.ID, mutation.PasswordHash, mutation.RecoveryHash[:])
        if err != nil { return identity.AccountSession{}, identity.ErrUnavailable }
        if err := revokeSessions(ctx, tx, account.ID, mutation.Now); err != nil { return identity.AccountSession{}, err }
        account.Generation++
        return insertSession(ctx, tx, account, mutation.NewSession)
    })
}

func (s *Store) RevokeSession(ctx context.Context, guard identity.Guard) error {
    _, err := transact(ctx, s, func(tx pgx.Tx) (struct{}, error) {
        current, err := guardSession(ctx, tx, guard)
        if err != nil { return struct{}{}, err }
        _, err = tx.Exec(ctx, `UPDATE notitle.sessions SET revoked_at=$2 WHERE id=$1`, current.Session.ID, guard.Now)
        if err != nil { return struct{}{}, identity.ErrUnavailable }
        return struct{}{}, nil
    })
    return err
}

func (s *Store) RevokeAllSessions(ctx context.Context, guard identity.Guard) error {
    _, err := transact(ctx, s, func(tx pgx.Tx) (struct{}, error) {
        current, err := guardSession(ctx, tx, guard)
        if err != nil { return struct{}{}, err }
        if _, err := tx.Exec(ctx, `UPDATE notitle.accounts SET generation=generation+1 WHERE id=$1`, current.Account.ID); err != nil { return struct{}{}, identity.ErrUnavailable }
        return struct{}{}, revokeSessions(ctx, tx, current.Account.ID, guard.Now)
    })
    return err
}

func (s *Store) BeginDeletion(ctx context.Context, guard identity.Guard, record identity.DeletionRecord) (identity.DeletionRecord, error) {
    return transact(ctx, s, func(tx pgx.Tx) (identity.DeletionRecord, error) {
        guard.RequireRecent = true
        current, err := guardSession(ctx, tx, guard)
        if err != nil { return identity.DeletionRecord{}, err }
        record.AccountID = current.Account.ID
        record.AccountGeneration = current.Account.Generation + 1
        // PostgreSQL timestamps have microsecond precision. Return exactly the
        // persisted value so an independent journal retry has identical content.
        record.RequestedAt = guard.Now.UTC().Truncate(time.Microsecond)
        record.State = "awaiting_retention_review"
        record.TombstoneDurable = false
        _, err = tx.Exec(ctx, `UPDATE notitle.accounts SET status='deletion_pending',generation=generation+1,deletion_requested_at=$2 WHERE id=$1`, current.Account.ID, guard.Now)
        if err != nil { return identity.DeletionRecord{}, identity.ErrUnavailable }
        if err := revokeSessions(ctx, tx, current.Account.ID, guard.Now); err != nil { return identity.DeletionRecord{}, err }
        _, err = tx.Exec(ctx, `INSERT INTO notitle.deletion_jobs (id,account_id,account_generation,receipt_hash,requested_at,state,tombstone_durable)
            VALUES ($1,$2,$3,$4,$5,'awaiting_retention_review',false)`, record.ID, record.AccountID, record.AccountGeneration, record.ReceiptHash[:], record.RequestedAt)
        if err != nil { return identity.DeletionRecord{}, identity.ErrUnavailable }
        return record, nil
    })
}

func (s *Store) MarkTombstoneDurable(ctx context.Context, deletionID string, now time.Time) error {
    result, err := s.pool.Exec(ctx, `UPDATE notitle.deletion_jobs SET tombstone_durable=true,tombstone_durable_at=COALESCE(tombstone_durable_at,GREATEST(requested_at,$2)) WHERE id=$1`, deletionID, now)
    if err != nil || result.RowsAffected() != 1 { return identity.ErrUnavailable }
    return nil
}

const deletionColumns = `id::text,account_id::text,account_generation,receipt_hash,requested_at,tombstone_durable,state`

func scanDeletion(row scanner) (identity.DeletionRecord, error) {
    var record identity.DeletionRecord
    var receipt []byte
    err := row.Scan(&record.ID, &record.AccountID, &record.AccountGeneration, &receipt, &record.RequestedAt, &record.TombstoneDurable, &record.State)
    if err != nil { return record, err }
    if receipt != nil && len(receipt) != len(record.ReceiptHash) { return identity.DeletionRecord{}, identity.ErrUnavailable }
    copy(record.ReceiptHash[:], receipt)
    return record, nil
}

func (s *Store) DeletionByReceipt(ctx context.Context, verifier identity.Verifier) (identity.DeletionRecord, error) {
    record, err := scanDeletion(s.pool.QueryRow(ctx, `SELECT `+deletionColumns+` FROM notitle.deletion_jobs WHERE receipt_hash=$1`, verifier[:]))
    if errors.Is(err, pgx.ErrNoRows) { return record, identity.ErrUnauthorized }
    if err != nil { return identity.DeletionRecord{}, identity.ErrUnavailable }
    return record, nil
}

func boundedBatch(limit int) int {
    if limit < 1 { return 1 }
    if limit > 1000 { return 1000 }
    return limit
}

func (s *Store) PendingTombstones(ctx context.Context, limit int) ([]identity.DeletionRecord, error) {
    rows, err := s.pool.Query(ctx, `SELECT `+deletionColumns+` FROM notitle.deletion_jobs WHERE NOT tombstone_durable ORDER BY requested_at,id LIMIT $1`, boundedBatch(limit))
    if err != nil { return nil, identity.ErrUnavailable }
    defer rows.Close()
    records := make([]identity.DeletionRecord, 0)
    for rows.Next() {
        record, err := scanDeletion(rows)
        if err != nil { return nil, identity.ErrUnavailable }
        records = append(records, record)
    }
    if err := rows.Err(); err != nil { return nil, identity.ErrUnavailable }
    return records, nil
}

func (s *Store) PruneExpiredSessions(ctx context.Context, now time.Time, limit int) error {
    _, err := s.pool.Exec(ctx, `DELETE FROM notitle.sessions WHERE id IN (
        SELECT id FROM notitle.sessions WHERE revoked_at IS NOT NULL
            OR absolute_expires_at <= $1 OR last_seen_at <= $2
        ORDER BY absolute_expires_at,id LIMIT $3 FOR UPDATE SKIP LOCKED)`, now, now.Add(-identity.SessionIdleTTL), boundedBatch(limit))
    if err != nil { return identity.ErrUnavailable }
    return nil
}

// ApplyTombstone is idempotent and must complete before serving account APIs on
// a restored database. A journal entry cannot recreate a lost receipt secret.
// Missing accounts are already inaccessible and need no fabricated identity.
func (s *Store) ApplyTombstone(ctx context.Context, tombstone identity.Tombstone) error {
    if tombstone.AccountGeneration < 1 || tombstone.RequestedAt.IsZero() { return identity.ErrInvalid }
    _, err := transact(ctx, s, func(tx pgx.Tx) (struct{}, error) {
        var generation int64
        var status string
        err := tx.QueryRow(ctx, `SELECT generation,status FROM notitle.accounts WHERE id=$1 FOR UPDATE`, tombstone.AccountID).Scan(&generation, &status)
        if errors.Is(err, pgx.ErrNoRows) { return struct{}{}, nil }
        if err != nil { return struct{}{}, identity.ErrUnavailable }
        if status == "active" { generation++ }
        if generation < tombstone.AccountGeneration { generation = tombstone.AccountGeneration }
        _, err = tx.Exec(ctx, `UPDATE notitle.accounts SET status='deletion_pending',generation=$2,
            deletion_requested_at=COALESCE(LEAST(deletion_requested_at,$3),$3) WHERE id=$1`, tombstone.AccountID, generation, tombstone.RequestedAt)
        if err != nil { return struct{}{}, identity.ErrUnavailable }
        if err := revokeSessions(ctx, tx, tombstone.AccountID, tombstone.RequestedAt); err != nil { return struct{}{}, err }
        result, err := tx.Exec(ctx, `INSERT INTO notitle.deletion_jobs
            (id,account_id,account_generation,receipt_hash,requested_at,state,tombstone_durable,tombstone_durable_at)
            VALUES ($1,$2,$3,NULL,$4,'awaiting_retention_review',true,GREATEST($4,CURRENT_TIMESTAMP))
            ON CONFLICT (account_id) DO UPDATE SET
                account_generation=GREATEST(notitle.deletion_jobs.account_generation,EXCLUDED.account_generation),
                tombstone_durable=true,
                tombstone_durable_at=COALESCE(notitle.deletion_jobs.tombstone_durable_at,EXCLUDED.tombstone_durable_at)
            WHERE notitle.deletion_jobs.id=EXCLUDED.id`,
            tombstone.DeletionID, tombstone.AccountID, generation, tombstone.RequestedAt)
        if err != nil || result.RowsAffected() != 1 { return struct{}{}, identity.ErrUnavailable }
        return struct{}{}, nil
    })
    return err
}
