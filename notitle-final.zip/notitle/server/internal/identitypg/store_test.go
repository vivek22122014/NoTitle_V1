package identitypg

import (
    "testing"
    "time"

    "notitle/internal/identity"
)

func TestSessionExpiryUsesStrictIdleAndAbsoluteDeadlines(t *testing.T) {
    start := time.Date(2026, 10, 9, 12, 0, 0, 0, time.UTC)
    session := identity.SessionRecord{CreatedAt: start, LastSeenAt: start, AbsoluteExpiresAt: start.Add(identity.SessionAbsoluteTTL)}
    if sessionValid(session, start.Add(-time.Nanosecond)) { t.Fatal("future-created session accepted") }
    if !sessionValid(session, start.Add(identity.SessionIdleTTL-time.Nanosecond)) { t.Fatal("session expired before idle deadline") }
    if sessionValid(session, start.Add(identity.SessionIdleTTL)) { t.Fatal("session valid at idle deadline") }
    session.LastSeenAt = session.AbsoluteExpiresAt.Add(-time.Hour)
    if !sessionValid(session, session.AbsoluteExpiresAt.Add(-time.Nanosecond)) { t.Fatal("active session expired before absolute deadline") }
    if sessionValid(session, session.AbsoluteExpiresAt) { t.Fatal("active session exceeded absolute deadline") }
}

func TestMaintenanceBatchIsAlwaysBounded(t *testing.T) {
    for _, test := range []struct{ input, want int }{{-100,1},{0,1},{1,1},{25,25},{1000,1000},{1000000,1000}} {
        if got := boundedBatch(test.input); got != test.want { t.Fatalf("bounded batch %d = %d, want %d", test.input, got, test.want) }
    }
}
