package identitypg

import (
    "context"
    "crypto/rand"
    "errors"
    "fmt"
    "os"
    "strings"
    "sync"
    "testing"
    "time"

    "github.com/jackc/pgx/v5/pgconn"
    "notitle/internal/config"
    "notitle/internal/database"
    "notitle/internal/identity"
)

// These tests write synthetic accounts only into scripts/db-check.sh's isolated
// disposable database. The runtime role deliberately cannot erase consent or
// account rows; Compose removes the entire isolated test volume afterwards.
func integrationStore(t *testing.T) (*Store, context.Context) {
    t.Helper()
    raw := strings.TrimSpace(os.Getenv("TEST_DATABASE_URL"))
    path := strings.TrimSpace(os.Getenv("TEST_DATABASE_URL_FILE"))
    if raw != "" && path != "" { t.Fatal("use one integration database secret source") }
    if path != "" {
        data, err := os.ReadFile(path)
        if err != nil { t.Fatal("cannot read integration database secret file") }
        raw = strings.TrimSpace(string(data))
    }
    if raw == "" {
        if os.Getenv("REQUIRE_DATABASE_INTEGRATION") == "1" { t.Fatal("database integration is required but not configured") }
        t.Skip("integration database not configured; run scripts/db-check.sh")
    }
    ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
    t.Cleanup(cancel)
    pool, err := database.Open(ctx, config.DatabaseConfig{URL: raw, MaxConns: 4,
        MaxConnLifetime: time.Minute, MaxConnIdleTime: time.Minute,
        HealthCheckPeriod: time.Minute, ConnectTimeout: 5*time.Second, ReadinessTimeout: time.Second})
    if err != nil { t.Fatal(err) }
    t.Cleanup(pool.Close)
    if err := pool.Ready(ctx); err != nil { t.Fatal("identity test requires migrated, restricted runtime database", err) }
    return New(pool.Raw()), ctx
}

func testUUID(t *testing.T) string {
    t.Helper()
    var b [16]byte
    if _, err := rand.Read(b[:]); err != nil { t.Fatal("test randomness unavailable") }
    b[6] = b[6]&0x0f | 0x40
    b[8] = b[8]&0x3f | 0x80
    return fmt.Sprintf("%x-%x-%x-%x-%x", b[0:4], b[4:6], b[6:8], b[8:10], b[10:16])
}

func testVerifier(t *testing.T) identity.Verifier {
    t.Helper()
    var result identity.Verifier
    if _, err := rand.Read(result[:]); err != nil { t.Fatal("test randomness unavailable") }
    return result
}

func testSession(t *testing.T, now time.Time) identity.SessionRecord {
    t.Helper()
    return identity.SessionRecord{ID: testUUID(t), TokenHash: testVerifier(t),
        CreatedAt: now, LastSeenAt: now, AuthenticatedAt: now,
        AbsoluteExpiresAt: now.Add(identity.SessionAbsoluteTTL)}
}

func testRegistration(t *testing.T, now time.Time) identity.CreateAccountRecord {
    t.Helper()
    id := testUUID(t)
    return identity.CreateAccountRecord{
        Account: identity.Account{ID: id, Username: "test_"+strings.ReplaceAll(id,"-","")[:16],
            Profile: identity.Profile{Version: 1, DisplayName: "Test Worker", Gender: identity.GenderOther,
                Topic: "career_growth", Professional: identity.ProfessionalProfile{Profession: "engineering", Industry: "technology", Experience: "3_5", Interests: []string{"leadership", "learning_skills"}}}},
        // Store tests never authenticate this synthetic hash. Argon2 is tested
        // separately through the identity service/hasher tests.
        PasswordHash: "$argon2id$v=19$m=65536,t=3,p=1$synthetic-store-test$synthetic-store-test",
        RecoveryHash: testVerifier(t), Consent: identity.Consent{AdultConfirmed: true,
            Policies: identity.PolicyVersions{Terms: "draft-1", Privacy: "draft-1", Community: "draft-1"}},
        CreatedAt: now, Session: testSession(t, now),
    }
}

func mustRegister(t *testing.T, store *Store, ctx context.Context, record identity.CreateAccountRecord) identity.AccountSession {
    t.Helper()
    current, err := store.CreateAccount(ctx, record)
    if err != nil { t.Fatal("cannot create synthetic test account", err) }
    return current
}

func testGuard(current identity.AccountSession, now time.Time) identity.Guard {
    return identity.Guard{AccountID: current.Account.ID, AccountGeneration: current.Account.Generation,
        SessionID: current.Session.ID, TokenHash: current.Session.TokenHash, Now: now}
}

func TestIntegrationRegistrationConstraintsAndProfileVersion(t *testing.T) {
    store, ctx := integrationStore(t)
    now := time.Now().UTC().Truncate(time.Microsecond)
    record := testRegistration(t, now)
    current := mustRegister(t, store, ctx, record)
    if current.Account.Profile.Version != 1 || current.Account.Generation != 1 { t.Fatal("initial versions are not one") }
    credentials, err := store.FindCredentials(ctx, record.Account.Username)
    if err != nil || credentials.RecoveryHash != record.RecoveryHash { t.Fatal("credential verifier did not round-trip") }
    if len(credentials.Account.Profile.Professional.Interests) != 2 { t.Fatal("controlled professional interests were not persisted") }
    for _, prefix := range []string{"_", "-"} {
        punctuation := testRegistration(t,now)
        punctuation.Account.Username = prefix + punctuation.Account.Username
        mustRegister(t,store,ctx,punctuation)
    }
    var consents int
    if err := store.pool.QueryRow(ctx, `SELECT count(*) FROM notitle.consent_events WHERE account_id=$1 AND accepted`, current.Account.ID).Scan(&consents); err != nil || consents != 4 { t.Fatal("registration consent not atomically recorded") }
    duplicate := testRegistration(t, now)
    duplicate.Account.Username = record.Account.Username
    if _, err := store.CreateAccount(ctx, duplicate); !errors.Is(err, identity.ErrConflict) { t.Fatal("duplicate username not rejected safely", err) }
    var leaked int
    if err := store.pool.QueryRow(ctx, `SELECT count(*) FROM notitle.accounts WHERE id=$1`, duplicate.Account.ID).Scan(&leaked); err != nil || leaked != 0 { t.Fatal("failed registration left partial identity") }
    profile := current.Account.Profile
    profile.Bio = "Public bio"
    profile.Professional.Interests = []string{"compensation"}
    updated, err := store.UpdateProfile(ctx, testGuard(current, now), profile)
    if err != nil || updated.Profile.Version != 2 || updated.Profile.Bio != "Public bio" { t.Fatal("profile replacement failed", err) }
    saved, err := store.FindCredentials(ctx,record.Account.Username)
    if err != nil || len(saved.Account.Profile.Professional.Interests) != 1 || saved.Account.Profile.Professional.Interests[0] != "compensation" { t.Fatal("professional interests not atomically replaced",err) }
    if _, err := store.UpdateProfile(ctx, testGuard(current, now), profile); !errors.Is(err, identity.ErrStale) { t.Fatal("stale profile overwrote newer data", err) }
    invalid := updated.Profile
    invalid.Gender = ""
    if _, err := store.UpdateProfile(ctx, testGuard(current, now), invalid); !errors.Is(err, identity.ErrInvalid) { t.Fatal("blank gender accepted", err) }
    // Database constraints remain a second barrier beneath domain validation.
    tx, err := store.pool.Begin(ctx)
    if err != nil { t.Fatal("cannot start database constraint check") }
    defer tx.Rollback(context.Background())
    _, err = tx.Exec(ctx, `UPDATE notitle.profiles SET gender='everyone' WHERE account_id=$1`, current.Account.ID)
    var pgErr *pgconn.PgError
    if !errors.As(err, &pgErr) || pgErr.Code != "23514" { t.Fatal("database accepted invalid gender") }
}

func TestIntegrationSessionRevocationExpiryAndAccountLimit(t *testing.T) {
    store, ctx := integrationStore(t)
    now := time.Now().UTC().Truncate(time.Microsecond)
    current := mustRegister(t, store, ctx, testRegistration(t, now))
    original := current
    for i := 1; i <= MaxAccountSessions; i++ {
        at := now.Add(time.Duration(i)*time.Second)
        var err error
        current, err = store.CreateSession(ctx, current.Account.ID, current.Account.Generation, testSession(t,at), at)
        if err != nil { t.Fatal("bounded login failed", err) }
    }
    var count int
    if err := store.pool.QueryRow(ctx, `SELECT count(*) FROM notitle.sessions WHERE account_id=$1 AND revoked_at IS NULL`, current.Account.ID).Scan(&count); err != nil || count != MaxAccountSessions { t.Fatal("account session count not bounded") }
    if _, err := store.Authenticate(ctx, original.Session.TokenHash, now.Add(time.Minute), false); !errors.Is(err, identity.ErrUnauthorized) { t.Fatal("oldest excess session remained active", err) }
    boundary := current.Session.LastSeenAt.Add(identity.SessionIdleTTL)
    if _, err := store.Authenticate(ctx, current.Session.TokenHash, boundary.Add(-time.Microsecond), false); err != nil { t.Fatal("session expired early", err) }
    if _, err := store.Authenticate(ctx, current.Session.TokenHash, boundary, false); !errors.Is(err, identity.ErrUnauthorized) { t.Fatal("idle expiry boundary accepted", err) }
    if err := store.RevokeAllSessions(ctx, testGuard(current, now.Add(time.Minute))); err != nil { t.Fatal("logout-all failed", err) }
    if _, err := store.Authenticate(ctx, current.Session.TokenHash, now.Add(time.Minute), false); !errors.Is(err, identity.ErrUnauthorized) { t.Fatal("logout-all left current session active", err) }
    if _, err := store.CreateSession(ctx, current.Account.ID, current.Account.Generation, testSession(t,now), now); !errors.Is(err, identity.ErrStale) { t.Fatal("stale password verification bypassed generation change", err) }
}

func TestIntegrationRecoveryIsSingleUseAndRollsBackOnFailedSessionInsert(t *testing.T) {
    store, ctx := integrationStore(t)
    now := time.Now().UTC().Truncate(time.Microsecond)
    record := testRegistration(t, now)
    current := mustRegister(t, store, ctx, record)
    mutation := identity.RecoveryMutation{AccountID: current.Account.ID, ExpectedGeneration: current.Account.Generation,
        ExpectedRecoveryHash: record.RecoveryHash, PasswordHash: record.PasswordHash+"-changed", RecoveryHash: testVerifier(t),
        NewSession: testSession(t,now), Now: now}
    // Force a deterministic unique collision after account writes, proving the
    // entire rotation rolls back instead of consuming recovery prematurely.
    mutation.NewSession.ID = current.Session.ID
    if _, err := store.Recover(ctx, mutation); !errors.Is(err, identity.ErrUnavailable) { t.Fatal("recovery insert collision not rejected", err) }
    if _, err := store.Authenticate(ctx, current.Session.TokenHash, now, false); err != nil { t.Fatal("failed transaction revoked original session", err) }
    unchanged, err := store.FindCredentials(ctx, record.Account.Username)
    if err != nil || unchanged.RecoveryHash != record.RecoveryHash || unchanged.Account.Generation != 1 { t.Fatal("failed recovery consumed code") }
    mutation.NewSession = testSession(t,now)
    next, err := store.Recover(ctx, mutation)
    if err != nil || next.Account.Generation != 2 || next.Session.AccountGeneration != 2 { t.Fatal("recovery did not rotate generation atomically", err) }
    if _, err := store.Authenticate(ctx, current.Session.TokenHash, now, false); !errors.Is(err, identity.ErrUnauthorized) { t.Fatal("recovered account retained old session", err) }
    mutation.NewSession = testSession(t,now)
    if _, err := store.Recover(ctx, mutation); !errors.Is(err, identity.ErrCredentials) { t.Fatal("recovery code replay accepted", err) }
    latest, err := store.FindCredentials(ctx, record.Account.Username)
    if err != nil || latest.RecoveryHash != mutation.RecoveryHash { t.Fatal("replacement recovery code not installed") }
}

func TestIntegrationConcurrentRecoveryAllowsExactlyOneCommit(t *testing.T) {
    store, ctx := integrationStore(t)
    now := time.Now().UTC().Truncate(time.Microsecond)
    record := testRegistration(t,now)
    current := mustRegister(t,store,ctx,record)
    attempts := []identity.RecoveryMutation{
        {AccountID:current.Account.ID,ExpectedGeneration:1,ExpectedRecoveryHash:record.RecoveryHash,PasswordHash:record.PasswordHash,RecoveryHash:testVerifier(t),NewSession:testSession(t,now),Now:now},
        {AccountID:current.Account.ID,ExpectedGeneration:1,ExpectedRecoveryHash:record.RecoveryHash,PasswordHash:record.PasswordHash,RecoveryHash:testVerifier(t),NewSession:testSession(t,now),Now:now},
    }
    results := make(chan error,len(attempts))
    var ready sync.WaitGroup
    ready.Add(len(attempts))
    begin := make(chan struct{})
    for _, attempt := range attempts {
        go func(m identity.RecoveryMutation) {
            ready.Done()
            <-begin
            _, err := store.Recover(ctx,m)
            results <- err
        }(attempt)
    }
    ready.Wait()
    close(begin)
    successes, rejected := 0,0
    for range attempts {
        err := <-results
        if err == nil { successes++ } else if errors.Is(err,identity.ErrCredentials) { rejected++ } else { t.Fatal("unexpected recovery race result",err) }
    }
    if successes != 1 || rejected != 1 { t.Fatal("recovery code was not consumed exactly once") }
}

func TestIntegrationDeletionDisablesAccessBeforeJournalAndRequiresRecentAuthentication(t *testing.T) {
    store, ctx := integrationStore(t)
    now := time.Now().UTC().Truncate(time.Microsecond)
    current := mustRegister(t,store,ctx,testRegistration(t,now))
    at := now.Add(identity.RecentAuthenticationTTL).Add(123*time.Nanosecond)
    guard := testGuard(current,at)
    receiptHash := testVerifier(t)
    request := identity.DeletionRecord{ID:testUUID(t),ReceiptHash:receiptHash}
    if _, err := store.BeginDeletion(ctx,guard,request); !errors.Is(err,identity.ErrReauthentication) { t.Fatal("deletion accepted expired recent authentication",err) }
    if err := store.Reauthenticate(ctx,guard); err != nil { t.Fatal("reauthentication failed",err) }
    deletion, err := store.BeginDeletion(ctx,guard,request)
    if err != nil { t.Fatal("deletion transaction failed",err) }
    if deletion.TombstoneDurable || deletion.AccountGeneration != 2 || deletion.State != "awaiting_retention_review" { t.Fatal("deletion incorrectly claims completed durability or erasure") }
    jobs, err := store.PendingTombstones(ctx,1000)
    if err != nil { t.Fatal("pending journal retry query failed",err) }
    found := false
    for _, job := range jobs {
        if job.ID == deletion.ID {
            found = true
            if !job.RequestedAt.Equal(deletion.RequestedAt) { t.Fatal("journal retry timestamp differs from first append") }
        }
    }
    if !found { t.Fatal("pending deletion missing from retry queue") }
    if _, err := store.Authenticate(ctx,current.Session.TokenHash,at,false); !errors.Is(err,identity.ErrUnauthorized) { t.Fatal("deletion left session active",err) }
    if _, err := store.FindCredentials(ctx,current.Account.Username); !errors.Is(err,identity.ErrCredentials) { t.Fatal("deleted account can sign in",err) }
    if _, err := store.UpdateProfile(ctx,guard,current.Account.Profile); !errors.Is(err,identity.ErrUnauthorized) { t.Fatal("stale pre-deletion principal mutated profile",err) }
    pending, err := store.DeletionByReceipt(ctx,receiptHash)
    if err != nil || pending.TombstoneDurable { t.Fatal("pending receipt unavailable or incorrectly durable",err) }
    if _, err := store.DeletionByReceipt(ctx,testVerifier(t)); !errors.Is(err,identity.ErrUnauthorized) { t.Fatal("invalid receipt accepted",err) }
    if err := store.MarkTombstoneDurable(ctx,deletion.ID,at); err != nil { t.Fatal("durable journal acknowledgement failed",err) }
    durable, err := store.DeletionByReceipt(ctx,receiptHash)
    if err != nil || !durable.TombstoneDurable || durable.State != "awaiting_retention_review" { t.Fatal("tombstone changed retention state or lost receipt",err) }
    // Replaying the same external record is idempotent and preserves a receipt
    // that survived database restoration.
    tombstone := identity.Tombstone{DeletionID:deletion.ID,AccountID:deletion.AccountID,AccountGeneration:deletion.AccountGeneration,RequestedAt:deletion.RequestedAt}
    if err := store.ApplyTombstone(ctx,tombstone); err != nil { t.Fatal("existing deletion replay failed",err) }
    again, err := store.DeletionByReceipt(ctx,receiptHash)
    if err != nil || again.AccountGeneration != 2 { t.Fatal("idempotent replay changed generation or lost receipt",err) }
}

func TestIntegrationTombstoneReplayDisablesRestoredAccountWithoutInventingReceipt(t *testing.T) {
    store, ctx := integrationStore(t)
    now := time.Now().UTC().Truncate(time.Microsecond)
    current := mustRegister(t,store,ctx,testRegistration(t,now))
    tombstone := identity.Tombstone{DeletionID:testUUID(t),AccountID:current.Account.ID,AccountGeneration:4,RequestedAt:now.Add(time.Second)}
    for range 2 {
        if err := store.ApplyTombstone(ctx,tombstone); err != nil { t.Fatal("restored account replay failed",err) }
    }
    if _, err := store.Authenticate(ctx,current.Session.TokenHash,now.Add(time.Second),false); !errors.Is(err,identity.ErrUnauthorized) { t.Fatal("restored credentials survived deletion replay",err) }
    var generation int64
    var status string
    var missingReceipt, durable bool
    err := store.pool.QueryRow(ctx, `SELECT a.generation,a.status,j.receipt_hash IS NULL,j.tombstone_durable FROM notitle.accounts a JOIN notitle.deletion_jobs j ON j.account_id=a.id WHERE a.id=$1`,current.Account.ID).Scan(&generation,&status,&missingReceipt,&durable)
    if err != nil || generation != 4 || status != "deletion_pending" || !missingReceipt || !durable { t.Fatal("restored deletion projection unsafe",err) }
    // A tombstone for an account absent from this older backup must not create
    // a placeholder account or public username.
    missing := identity.Tombstone{DeletionID:testUUID(t),AccountID:testUUID(t),AccountGeneration:2,RequestedAt:now}
    if err := store.ApplyTombstone(ctx,missing); err != nil { t.Fatal("absent-account tombstone replay failed",err) }
}

func TestIntegrationCredentialRotationRecentAuthAndRevokedGuard(t *testing.T) {
    store,ctx := integrationStore(t)
    now := time.Now().UTC().Truncate(time.Microsecond)
    record := testRegistration(t,now)
    current := mustRegister(t,store,ctx,record)
    at := now.Add(identity.RecentAuthenticationTTL)
    mutation := identity.CredentialMutation{ReplaceRecovery:true,RecoveryHash:testVerifier(t),NewSession:testSession(t,at)}
    guard := testGuard(current,at)
    if _, err := store.ChangeCredentials(ctx,guard,mutation); !errors.Is(err,identity.ErrReauthentication) { t.Fatal("recovery replacement bypassed recent authentication",err) }
    if err := store.Reauthenticate(ctx,guard); err != nil { t.Fatal(err) }
    rotated,err := store.ChangeCredentials(ctx,guard,mutation)
    if err != nil || rotated.Account.Generation != 2 { t.Fatal("recovery replacement failed",err) }
    if _, err := store.Authenticate(ctx,current.Session.TokenHash,at,false); !errors.Is(err,identity.ErrUnauthorized) { t.Fatal("rotation did not revoke old session",err) }
    credentials,err := store.FindCredentials(ctx,current.Account.Username)
    if err != nil || credentials.PasswordHash != record.PasswordHash || credentials.RecoveryHash != mutation.RecoveryHash { t.Fatal("recovery-only replacement changed password or failed to replace code",err) }
    if err := store.RevokeSession(ctx,testGuard(rotated,at)); err != nil { t.Fatal("logout failed",err) }
    if _, err := store.UpdateProfile(ctx,testGuard(rotated,at),rotated.Account.Profile); !errors.Is(err,identity.ErrUnauthorized) { t.Fatal("revoked session guard still authorized write",err) }
    if err := store.PruneExpiredSessions(ctx,at,1); err != nil { t.Fatal("bounded session maintenance failed",err) }
}


func TestIntegrationConcurrentProfileVersionAllowsExactlyOneCommit(t *testing.T) {
    store,ctx := integrationStore(t)
    now := time.Now().UTC().Truncate(time.Microsecond)
    current := mustRegister(t,store,ctx,testRegistration(t,now))
    guard := testGuard(current,now)
    results := make(chan error,2)
    begin := make(chan struct{})
    var ready sync.WaitGroup
    ready.Add(2)
    for _, bio := range []string{"First edit","Second edit"} {
        go func(bio string) {
            profile := current.Account.Profile
            profile.Bio = bio
            ready.Done()
            <-begin
            _,err := store.UpdateProfile(ctx,guard,profile)
            results <- err
        }(bio)
    }
    ready.Wait()
    close(begin)
    succeeded,stale := 0,0
    for range 2 {
        err := <-results
        if err == nil { succeeded++ } else if errors.Is(err,identity.ErrStale) { stale++ } else { t.Fatal("unexpected concurrent profile result",err) }
    }
    if succeeded != 1 || stale != 1 { t.Fatal("concurrent edit overwrote a newer profile version") }
}
