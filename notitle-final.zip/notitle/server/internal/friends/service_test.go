package friends

import (
 "context"
 "errors"
 "testing"
 "time"
 ft "notitle/internal/friendtypes"
 "notitle/internal/identity"
)

type fakeIdentity struct{touches []bool;err error}
func(f *fakeIdentity)RefreshPrincipal(_ context.Context,p identity.Principal,touch bool)(identity.Principal,error){f.touches=append(f.touches,touch);return p,f.err}
type fakeOwner struct{batch []ft.Mutation;remove ft.Mutation;views []ft.View;fence uint64;published bool;finishErr error;finished,rejected,compensated,closed int;snapshot ft.Snapshot;fallback *ft.Relation}
func(f *fakeOwner)AuthFence(context.Context)(uint64,error){return f.fence,nil}
func(f *fakeOwner)ListFriends(_ context.Context,g ft.Guard,s ft.Snapshot)([]ft.View,error){if g.Fence!=f.fence{return nil,ft.ErrConflict};f.snapshot=s;return f.views,nil}
func(f *fakeOwner)PrepareFriendRemove(_ context.Context,_ ft.Guard,_ string,r *ft.Relation)(ft.Mutation,error){f.fallback=r;return f.remove,nil}
func(f *fakeOwner)FinishFriendMutation(context.Context,string,bool)(bool,error){f.finished++;return f.published,f.finishErr}
func(f *fakeOwner)FinishFriendCompensation(context.Context,string,bool)error{f.compensated++;return nil}
func(f *fakeOwner)RejectFriendMutation(context.Context,string)error{f.rejected++;return nil}
func(f *fakeOwner)ClaimFriendMutations(context.Context,int)([]ft.Mutation,error){return f.batch,nil}
func(f *fakeOwner)FailClosed(){f.closed++}
type fakeRepository struct{snapshot ft.Snapshot;relation ft.Relation;readErr,putErr,removeErr,compensateErr error;puts,removes,compensations int;last ft.Mutation}
func(f *fakeRepository)Friends(context.Context,identity.Principal,time.Time)(ft.Snapshot,error){return f.snapshot,nil}
func(f *fakeRepository)Read(context.Context,identity.Guard,string)(ft.Relation,error){return f.relation,f.readErr}
func(f *fakeRepository)Put(_ context.Context,m ft.Mutation,_ time.Time)error{f.puts++;f.last=m;return f.putErr}
func(f *fakeRepository)Remove(_ context.Context,_ *identity.Guard,m ft.Mutation,_ time.Time)error{f.removes++;f.last=m;return f.removeErr}
func(f *fakeRepository)Compensate(_ context.Context,m ft.Mutation)error{f.compensations++;f.last=m;return f.compensateErr}
func fixture(t *testing.T)(*Service,*fakeIdentity,*fakeOwner,*fakeRepository){
 t.Helper();i:=&fakeIdentity{};o:=&fakeOwner{fence:3,published:true};r:=&fakeRepository{snapshot:ft.Snapshot{Revision:1},readErr:ft.ErrNotFound}
 s,err:=New(Options{Identity:i,Owner:o,Store:r,MaxPerIdentity:100,Ready:func(context.Context)error{return nil}});if err!=nil{t.Fatal(err)};return s,i,o,r
}
func mutation()ft.Mutation{return ft.Mutation{Ref:"random_relation_handle_123",LeaseID:"private_lease",A:ft.Subject{Kind:identity.KindAccount,ID:"a",Generation:1},B:ft.Subject{Kind:identity.KindAccount,ID:"b",Generation:1},ARevision:1,BRevision:1}}
func TestListDoesNotExtendGuestIdleAndUsesOwnerProjection(t *testing.T){
 s,i,o,r:=fixture(t);o.views=[]ft.View{{Ref:"owner_scoped_reference",Presence:ft.Offline}};r.snapshot.Revision=8
 got,err:=s.ListFriends(context.Background(),identity.Principal{Kind:identity.KindGuest});if err!=nil||len(got)!=1||o.snapshot.Revision!=8{t.Fatal("list bypassed owner",err)}
 if len(i.touches)!=1||i.touches[0]{t.Fatal("presence read extended guest lifetime")}
}
func TestTemporaryRemovalNeedsNoDatabaseOrCompletionLease(t *testing.T){
 s,_,o,r:=fixture(t);m:=mutation();m.A.Kind=identity.KindGuest;m.LeaseID="";m.Remove=true;o.remove=m
 if err:=s.RemoveFriend(context.Background(),identity.Principal{Kind:identity.KindGuest},m.Ref);err!=nil{t.Fatal(err)}
 if r.removes!=0||o.finished!=0||o.closed!=0{t.Fatal("temporary removal invoked durable workflow")}
}
func TestDurableRemoveColdFallbackAndDefiniteFailure(t *testing.T){
 s,_,o,r:=fixture(t);m:=mutation();m.Remove=true;o.remove=m;r.readErr=nil;r.relation=ft.Relation{Ref:m.Ref};r.removeErr=ft.ErrUnavailable
 err:=s.RemoveFriend(context.Background(),identity.Principal{Kind:identity.KindAccount},m.Ref)
 if !errors.Is(err,ft.ErrUnavailable)||r.removes!=1||o.fallback==nil||o.finished!=1||o.closed!=0{t.Fatal("durable failure incorrectly acknowledged or lost fallback",err)}
}
func TestAlreadyCommittedRemoveDoesNotAdvanceUnrelatedConsentFence(t *testing.T){
 s,_,o,r:=fixture(t);m:=mutation();m.Remove=true;m.LeaseID="";o.remove=m
 if err:=s.RemoveFriend(context.Background(),identity.Principal{Kind:identity.KindAccount},m.Ref);err!=nil{t.Fatal(err)}
 if r.removes!=0||o.finished!=0{t.Fatal("completed removal rewrote revisions")}
}
func TestStaleRevisionRejectsRatherThanRefreshingConsent(t *testing.T){
 s,_,o,r:=fixture(t);o.batch=[]ft.Mutation{mutation()};r.putErr=ft.ErrConflict;s.cycle(context.Background())
 if o.rejected!=1||o.finished!=0||r.compensations!=0{t.Fatal("stale revision retried or published")}
}
func TestLateCommitCompensatesOnlyItsExactReference(t *testing.T){
 s,_,o,r:=fixture(t);m:=mutation();o.batch=[]ft.Mutation{m};o.published=false;s.cycle(context.Background())
 if r.compensations!=1||r.last.Ref!=m.Ref||o.compensated!=1||o.closed!=0{t.Fatal("stale publication was not compensated")}
}
func TestUncertainCommitLatchesClosedWithoutReleasingLease(t *testing.T){
 s,_,o,r:=fixture(t);o.batch=[]ft.Mutation{mutation()};r.putErr=errCommitUncertain;s.cycle(context.Background())
 if o.closed!=1||o.finished!=0||o.rejected!=0||r.compensations!=0{t.Fatal("uncertain commit released safety fence")}
}
func TestTransientPromotionFailureRemainsPending(t *testing.T){
 s,_,o,r:=fixture(t);o.batch=[]ft.Mutation{mutation()};r.putErr=ft.ErrUnavailable;s.cycle(context.Background())
 if o.finished!=1||o.rejected!=0||r.compensations!=0||o.closed!=0{t.Fatal("transient storage failure discarded consent")}
}
func TestFailedCompensationFailsClosedRatherThanStrandingActiveWorker(t *testing.T){
 s,_,o,r:=fixture(t);o.batch=[]ft.Mutation{mutation()};o.published=false;r.compensateErr=ft.ErrUnavailable;s.cycle(context.Background())
 if o.compensated!=1||o.closed!=1{t.Fatal("failed cleanup silently stranded a pinned lease")}
}
func TestNormalizationPreservesConsentAndAuthorizationOwner(t *testing.T){
 m:=mutation();m.A.ID="z";m.B.ID="a";m.ARevision=4;m.BRevision=8;m.AGuard.AccountID="z";m.BGuard.AccountID="a";m.AConsentAt=time.Unix(10,0);m.BConsentAt=time.Unix(20,0)
 n:=normalize(m);if n.A.ID!="a"||n.AGuard.AccountID!="a"||n.ARevision!=8||n.AConsentAt!=m.BConsentAt||n.BRevision!=4{t.Fatal("normalization mixed identities or consent")}
}
