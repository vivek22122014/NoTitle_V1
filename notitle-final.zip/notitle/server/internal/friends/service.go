package friends

import (
 "context"
 "errors"
 "time"
 ft "notitle/internal/friendtypes"
 "notitle/internal/identity"
)

type Service struct { options Options }
func New(o Options)(*Service,error){
 if o.Now==nil{o.Now=time.Now}
 if o.Identity==nil||o.Owner==nil||o.Store==nil||o.Ready==nil||o.MaxPerIdentity<1||o.MaxPerIdentity>ft.MaxFriendsPerIdentity{return nil,errors.New("friends requires identity, owner, repository, readiness and a bounded limit")}
 return &Service{options:o},nil
}
func publicError(err error)error{
 if err==nil{return nil};if errors.Is(err,identity.ErrUnauthorized)||errors.Is(err,identity.ErrStale){return ft.ErrUnauthorized};var value *ft.Error;if errors.As(err,&value){return value};return ft.ErrUnavailable
}
func(s *Service)guard(ctx context.Context,p identity.Principal)(ft.Guard,error){
 if s.options.Ready(ctx)!=nil{return ft.Guard{},ft.ErrUnavailable}
 fence,err:=s.options.Owner.AuthFence(ctx);if err!=nil{return ft.Guard{},ft.ErrUnavailable}
 // Reading a list or presence must not extend a guest's idle lifetime.
 current,err:=s.options.Identity.RefreshPrincipal(ctx,p,false);if err!=nil{return ft.Guard{},publicError(err)}
 return ft.Guard{Principal:current,Fence:fence},nil
}
func(s *Service)Friends(ctx context.Context,p identity.Principal)(ft.Snapshot,error){
 return s.options.Store.Friends(ctx,p,s.options.Now().UTC())
}
func(s *Service)ListFriends(ctx context.Context,p identity.Principal)([]ft.View,error){
 g,err:=s.guard(ctx,p);if err!=nil{return nil,err}
 snapshot,err:=s.options.Store.Friends(ctx,g.Principal,s.options.Now().UTC());if err!=nil{return nil,publicError(err)}
 return s.options.Owner.ListFriends(ctx,g,snapshot)
}
func(s *Service)RemoveFriend(ctx context.Context,p identity.Principal,ref string)error{
 if !ft.ValidRef(ref){return ft.ErrInvalid}
 g,err:=s.guard(ctx,p);if err!=nil{return err}
 var fallback *ft.Relation
 if g.Principal.Kind==identity.KindAccount{
  relation,readErr:=s.options.Store.Read(ctx,g.Principal.Guard(s.options.Now().UTC(),false),ref)
  if readErr==nil{fallback=&relation}else if !errors.Is(readErr,ft.ErrNotFound){return publicError(readErr)}
 }
 m,err:=s.options.Owner.PrepareFriendRemove(ctx,g,ref,fallback);if err!=nil{return err}
 // No lease means a temporary relation was already forgotten, or this exact
 // durable removal already committed while an older insertion is settling.
 if m.LeaseID==""{return nil}
 var guard *identity.Guard
 if g.Principal.Kind==identity.KindAccount{value:=g.Principal.Guard(s.options.Now().UTC(),false);guard=&value}
 if m.A.Kind==identity.KindAccount&&m.B.Kind==identity.KindAccount{err=s.options.Store.Remove(ctx,guard,m,s.options.Now().UTC())}
 if errors.Is(err,errCommitUncertain){s.failClosed();return ft.ErrUnavailable}
 // Local guest removal needs no SQL; durable deletion is not acknowledged
 // until its pair fence and delete have committed together.
 cleanup,cancel:=context.WithTimeout(context.WithoutCancel(ctx),2*time.Second);defer cancel()
 if _,finishErr:=s.options.Owner.FinishFriendMutation(cleanup,m.LeaseID,err==nil);finishErr!=nil{s.failClosed();return ft.ErrUnavailable}
 return publicError(err)
}
func(s *Service)failClosed(){if closer,ok:=s.options.Owner.(interface{FailClosed()});ok{closer.FailClosed()}}
func permanent(err error)bool{return errors.Is(err,ft.ErrConflict)||errors.Is(err,ft.ErrUnauthorized)||errors.Is(err,ft.ErrCapacity)||errors.Is(err,ft.ErrInvalid)||errors.Is(err,identity.ErrUnauthorized)||errors.Is(err,identity.ErrStale)}

// Run keeps one bounded worker, never a database call inside the coordinator.
// Accepted consent is pending until SQL commits and the owner publishes it.
func(s *Service)Run(ctx context.Context){
 ticker:=time.NewTicker(time.Second);defer ticker.Stop()
 for{select{case<-ctx.Done():return;case<-ticker.C:s.cycle(ctx)}}
}
func(s *Service)cycle(ctx context.Context){
 work,cancel:=context.WithTimeout(ctx,5*time.Second);defer cancel()
 if s.options.Ready(work)!=nil{return}
 batch,err:=s.options.Owner.ClaimFriendMutations(work,8);if err!=nil{return}
 for _,m:=range batch{
  var err error
  if m.Remove{err=s.options.Store.Remove(work,nil,m,s.options.Now().UTC())}else{err=s.options.Store.Put(work,m,s.options.Now().UTC())}
  if errors.Is(err,errCommitUncertain){s.failClosed();return}
  finish,stop:=context.WithTimeout(context.WithoutCancel(work),2*time.Second)
  if !m.Remove&&permanent(err){rejectErr:=s.options.Owner.RejectFriendMutation(finish,m.LeaseID);stop();if rejectErr!=nil{s.failClosed();return};continue}
  published,finishErr:=s.options.Owner.FinishFriendMutation(finish,m.LeaseID,err==nil)
  stop();if finishErr!=nil{s.failClosed();return}
  if err==nil&&!m.Remove&&!published{
   // Only this exact accepted row is removed; never erase a successor pair.
   compensate,done:=context.WithTimeout(context.WithoutCancel(ctx),4*time.Second)
   cleanupErr:=s.options.Store.Compensate(compensate,m)
   if errors.Is(cleanupErr,errCommitUncertain){done();s.failClosed();return}
   final,finishCancel:=context.WithTimeout(context.WithoutCancel(ctx),2*time.Second)
   finalErr:=s.options.Owner.FinishFriendCompensation(final,m.LeaseID,cleanupErr==nil)
   finishCancel();done();if finalErr!=nil||cleanupErr!=nil{s.failClosed();return}
  }
 }
}
