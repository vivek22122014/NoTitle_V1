// Package friends performs durable friendship work outside the live-state owner.
package friends

import (
 "context"
 "time"
 ft "notitle/internal/friendtypes"
 "notitle/internal/identity"
)

type Identity interface { RefreshPrincipal(context.Context,identity.Principal,bool)(identity.Principal,error) }
type Options struct {
 Identity Identity
 Owner ft.Owner
 Store Repository
 Ready func(context.Context)error
 Now func()time.Time
 MaxPerIdentity int
}
type Repository interface {
 Friends(context.Context,identity.Principal,time.Time)(ft.Snapshot,error)
 Read(context.Context,identity.Guard,string)(ft.Relation,error)
 Put(context.Context,ft.Mutation,time.Time)error
 Remove(context.Context,*identity.Guard,ft.Mutation,time.Time)error
 Compensate(context.Context,ft.Mutation)error
}
