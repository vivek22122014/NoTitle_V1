package friends

import (
 "context"
 "crypto/rand"
 "encoding/base64"
 "encoding/hex"
 "errors"
 "os"
 "strings"
 "sync"
 "testing"
 "time"
 "notitle/internal/config"
 "notitle/internal/database"
 ft "notitle/internal/friendtypes"
 "notitle/internal/identity"
 "notitle/internal/identitypg"
 "notitle/internal/safety"
 st "notitle/internal/safetytypes"
)
func testUUID(t *testing.T)string{t.Helper();var b [16]byte;if _,err:=rand.Read(b[:]);err!=nil{t.Fatal(err)};b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;s:=hex.EncodeToString(b[:]);return s[:8]+"-"+s[8:12]+"-"+s[12:16]+"-"+s[16:20]+"-"+s[20:]}
func testRef(t *testing.T)string{t.Helper();var b [32]byte;if _,err:=rand.Read(b[:]);err!=nil{t.Fatal(err)};return base64.RawURLEncoding.EncodeToString(b[:])}
func integrationStore(t *testing.T)(context.Context,*PostgresStore,*identitypg.Store){
 t.Helper();raw:=strings.TrimSpace(os.Getenv("TEST_DATABASE_URL"));path:=strings.TrimSpace(os.Getenv("TEST_DATABASE_URL_FILE"))
 if raw!=""&&path!=""{t.Fatal("use one database secret source")};if path!=""{data,err:=os.ReadFile(path);if err!=nil{t.Fatal("cannot read database secret")};raw=strings.TrimSpace(string(data))}
 if raw==""{if os.Getenv("REQUIRE_DATABASE_INTEGRATION")=="1"{t.Fatal("required database integration missing")};t.Skip("run scripts/db-check.sh with disposable database")}
 ctx,cancel:=context.WithTimeout(context.Background(),45*time.Second);t.Cleanup(cancel)
 db,err:=database.Open(ctx,config.DatabaseConfig{URL:raw,MaxConns:6,MaxConnLifetime:time.Minute,MaxConnIdleTime:time.Minute,HealthCheckPeriod:time.Minute,ConnectTimeout:5*time.Second});if err!=nil{t.Fatal(err)};t.Cleanup(db.Close)
 if err:=db.Ready(ctx);err!=nil{t.Fatal("migration-six runtime database required",err)};return ctx,NewPostgresStore(db.Raw(),100),identitypg.New(db.Raw())
}
func integrationAccount(t *testing.T,ctx context.Context,s *identitypg.Store)identity.Principal{
 t.Helper();id:=testUUID(t);sid:=testUUID(t);var token,recovery identity.Verifier;if _,err:=rand.Read(token[:]);err!=nil{t.Fatal(err)};if _,err:=rand.Read(recovery[:]);err!=nil{t.Fatal(err)}
 now:=time.Now().UTC().Truncate(time.Microsecond)
 created,err:=s.CreateAccount(ctx,identity.CreateAccountRecord{Account:identity.Account{ID:id,Username:"friend_"+strings.ReplaceAll(id,"-","")[:16],Profile:identity.Profile{Version:1,DisplayName:"Friend Test",Gender:identity.GenderOther,Topic:"general_talk"}},PasswordHash:"$argon2id$v=19$m=65536,t=3,p=1$synthetic-store-test$synthetic-store-test",RecoveryHash:recovery,Consent:identity.Consent{AdultConfirmed:true,Policies:identity.PolicyVersions{Terms:"draft-1",Privacy:"draft-1",Community:"draft-1"}},CreatedAt:now,Session:identity.SessionRecord{ID:sid,TokenHash:token,CreatedAt:now,LastSeenAt:now,AuthenticatedAt:now,AbsoluteExpiresAt:now.Add(identity.SessionAbsoluteTTL)}})
 if err!=nil{t.Fatal(err)};return identity.Principal{Kind:identity.KindAccount,AccountSession:created,TokenHash:token}
}
func accepted(t *testing.T,ctx context.Context,s *PostgresStore,a,b identity.Principal)ft.Mutation{
 t.Helper();now:=time.Now().UTC().Truncate(time.Microsecond);av,err:=s.Friends(ctx,a,now);if err!=nil{t.Fatal(err)};bv,err:=s.Friends(ctx,b,now);if err!=nil{t.Fatal(err)}
 return ft.Mutation{Ref:testRef(t),LeaseID:testRef(t),A:ft.Subject{Kind:identity.KindAccount,ID:a.AccountSession.Account.ID,Generation:a.AccountSession.Account.Generation},B:ft.Subject{Kind:identity.KindAccount,ID:b.AccountSession.Account.ID,Generation:b.AccountSession.Account.Generation},AGuard:a.Guard(now,false),BGuard:b.Guard(now,false),ARevision:av.Revision,BRevision:bv.Revision,AConsentAt:now,BConsentAt:now,CreatedAt:now,Version:1}
}
func countPair(t *testing.T,ctx context.Context,s *PostgresStore,m ft.Mutation)int{t.Helper();m=normalize(m);var count int;if err:=s.pool.QueryRow(ctx,`SELECT count(*) FROM notitle.friendships WHERE account_a=$1 AND account_b=$2`,m.A.ID,m.B.ID).Scan(&count);err!=nil{t.Fatal(err)};return count}
func TestIntegrationConcurrentReciprocalAcceptCreatesOneRow(t *testing.T){
 ctx,s,identities:=integrationStore(t);a:=integrationAccount(t,ctx,identities);b:=integrationAccount(t,ctx,identities);m:=accepted(t,ctx,s,a,b);reverse:=m;reverse.A,reverse.B=reverse.B,reverse.A;reverse.AGuard,reverse.BGuard=reverse.BGuard,reverse.AGuard;reverse.ARevision,reverse.BRevision=reverse.BRevision,reverse.ARevision
 var wg sync.WaitGroup;errs:=make(chan error,2);for _,v:=range []ft.Mutation{m,reverse}{wg.Add(1);go func(v ft.Mutation){defer wg.Done();errs<-s.Put(ctx,v,time.Now().UTC())}(v)};wg.Wait();close(errs);for err:=range errs{if err!=nil{t.Fatal(err)}}
 if countPair(t,ctx,s,m)!=1{t.Fatal("reciprocal consent created duplicate friendship")}
 restored:=NewPostgresStore(s.pool,100);got,err:=restored.Friends(ctx,a,time.Now().UTC());if err!=nil||len(got.Relations)!=1||got.Relations[0].Peer.ID!=b.AccountSession.Account.ID{t.Fatal("durable friendship did not survive new repository",err)}
 third:=integrationAccount(t,ctx,identities);if _,err:=s.Read(ctx,third.Guard(time.Now().UTC(),false),m.Ref);!errors.Is(err,ft.ErrNotFound){t.Fatal("foreign opaque reference disclosed relationship",err)}
}
func TestIntegrationRemovalBeforePendingInsertFencesAcrossRestart(t *testing.T){
 ctx,s,identities:=integrationStore(t);a:=integrationAccount(t,ctx,identities);b:=integrationAccount(t,ctx,identities);pending:=accepted(t,ctx,s,a,b);remove:=pending;remove.Remove=true;g:=a.Guard(time.Now().UTC(),false)
 if err:=s.Remove(ctx,&g,remove,time.Now().UTC());err!=nil{t.Fatal(err)}
 restored:=NewPostgresStore(s.pool,100);if err:=restored.Put(ctx,pending,time.Now().UTC());!errors.Is(err,ft.ErrConflict){t.Fatal("late insert resurrected removed consent",err)}
 if countPair(t,ctx,s,pending)!=0{t.Fatal("removed pending friendship persisted")}
 fresh:=accepted(t,ctx,s,a,b);if err:=restored.Put(ctx,fresh,time.Now().UTC());err!=nil{t.Fatal("new affirmative consent could not reconnect",err)}
 if err:=s.Compensate(ctx,pending);err!=nil{t.Fatal(err)};if countPair(t,ctx,s,fresh)!=1{t.Fatal("stale compensation erased successor consent")}
}
func TestIntegrationDurableBlockAtomicallyRemovesAndUnblockNeverRestores(t *testing.T){
 ctx,s,identities:=integrationStore(t);a:=integrationAccount(t,ctx,identities);b:=integrationAccount(t,ctx,identities);m:=accepted(t,ctx,s,a,b);if err:=s.Put(ctx,m,time.Now().UTC());err!=nil{t.Fatal(err)}
 blocks:=safety.NewPostgresStore(s.pool);g:=b.Guard(time.Now().UTC(),false);block:=st.BlockMutation{Ref:testRef(t),Blocker:st.Subject{Kind:identity.KindAccount,ID:m.B.ID,Generation:m.B.Generation},Blocked:st.Subject{Kind:identity.KindAccount,ID:m.A.ID,Generation:m.A.Generation},CreatedAt:time.Now().UTC(),Version:1}
 if err:=blocks.PutBlock(ctx,&g,block);err!=nil{t.Fatal(err)};if countPair(t,ctx,s,m)!=0{t.Fatal("incoming block retained friendship")}
 beforeRetry,err:=s.Friends(ctx,a,time.Now().UTC());if err!=nil{t.Fatal(err)};if err:=blocks.PutBlock(ctx,&g,block);err!=nil{t.Fatal(err)};afterRetry,err:=s.Friends(ctx,a,time.Now().UTC());if err!=nil||beforeRetry.Revision!=afterRetry.Revision{t.Fatal("same durable block retry invalidated unrelated pending consent",err)}
 if err:=s.Put(ctx,m,time.Now().UTC());!errors.Is(err,ft.ErrConflict){t.Fatal("stale consent bypassed block",err)}
 if err:=blocks.DeleteBlock(ctx,g,block.Ref);err!=nil{t.Fatal(err)};if err:=s.Put(ctx,m,time.Now().UTC());!errors.Is(err,ft.ErrConflict){t.Fatal("unblock restored old consent",err)}
 snapshot,err:=s.Friends(ctx,a,time.Now().UTC());if err!=nil||len(snapshot.Relations)!=0{t.Fatal("unblock restored relationship",err)}
}
func TestIntegrationDeletionRemovesInIdentityTransaction(t *testing.T){
 ctx,s,identities:=integrationStore(t);a:=integrationAccount(t,ctx,identities);b:=integrationAccount(t,ctx,identities);m:=accepted(t,ctx,s,a,b);if err:=s.Put(ctx,m,time.Now().UTC());err!=nil{t.Fatal(err)}
 var receipt identity.Verifier;if _,err:=rand.Read(receipt[:]);err!=nil{t.Fatal(err)}
 if _,err:=identities.BeginDeletion(ctx,a.Guard(time.Now().UTC(),true),identity.DeletionRecord{ID:testUUID(t),ReceiptHash:receipt});err!=nil{t.Fatal(err)}
 if countPair(t,ctx,s,m)!=0{t.Fatal("access-disabled deletion retained relationships")};if err:=s.Put(ctx,m,time.Now().UTC());!errors.Is(err,ft.ErrUnauthorized){t.Fatal("deleted participant consent resurrected",err)}
}
func TestIntegrationRevokedSessionAndRestrictedPeerCannotPersist(t *testing.T){
 ctx,s,identities:=integrationStore(t);a:=integrationAccount(t,ctx,identities);b:=integrationAccount(t,ctx,identities);m:=accepted(t,ctx,s,a,b)
 if err:=identities.RevokeSession(ctx,b.Guard(time.Now().UTC(),false));err!=nil{t.Fatal(err)};if err:=s.Put(ctx,m,time.Now().UTC());!errors.Is(err,ft.ErrUnauthorized){t.Fatal("revoked peer consent persisted",err)}
 c:=integrationAccount(t,ctx,identities);next:=accepted(t,ctx,s,a,c);now:=time.Now().UTC();if _,err:=s.pool.Exec(ctx,`INSERT INTO notitle.account_safety_state(account_id,restricted_until,updated_at) VALUES($1,$2,$3)`,c.AccountSession.Account.ID,now.Add(time.Hour),now);err!=nil{t.Fatal(err)}
 if err:=s.Put(ctx,next,time.Now().UTC());!errors.Is(err,ft.ErrConflict){t.Fatal("restricted peer accepted",err)}
}
func TestIntegrationAdmissionLimitDoesNotHideExistingFriends(t *testing.T){
 ctx,s,identities:=integrationStore(t);a:=integrationAccount(t,ctx,identities);b:=integrationAccount(t,ctx,identities);c:=integrationAccount(t,ctx,identities);first:=accepted(t,ctx,s,a,b);second:=accepted(t,ctx,s,a,c)
 if err:=s.Put(ctx,first,time.Now().UTC());err!=nil{t.Fatal(err)};limited:=NewPostgresStore(s.pool,1)
 if err:=limited.Put(ctx,second,time.Now().UTC());!errors.Is(err,ft.ErrCapacity){t.Fatal("per identity admission cap bypassed",err)}
 if err:=s.Put(ctx,second,time.Now().UTC());err!=nil{t.Fatal(err)};snapshot,err:=limited.Friends(ctx,a,time.Now().UTC());if err!=nil||len(snapshot.Relations)!=2{t.Fatal("lower admission cap hid existing friendships",err)}
}
func TestIntegrationAcceptedGuestPromotionSurvivesAccountLogoutButNotRemove(t *testing.T){
 ctx,s,identities:=integrationStore(t);a:=integrationAccount(t,ctx,identities);b:=integrationAccount(t,ctx,identities);m:=accepted(t,ctx,s,a,b);m.Promotion=true
 if err:=identities.RevokeSession(ctx,b.Guard(time.Now().UTC(),false));err!=nil{t.Fatal(err)}
 if err:=s.Put(ctx,m,time.Now().UTC());err!=nil{t.Fatal("accepted guest link could not promote with offline registered peer",err)}
 removal:=m;removal.Remove=true;guard:=a.Guard(time.Now().UTC(),false);if err:=s.Remove(ctx,&guard,removal,time.Now().UTC());err!=nil{t.Fatal(err)}
 if err:=s.Put(ctx,m,time.Now().UTC());!errors.Is(err,ft.ErrConflict){t.Fatal("promotion resurrected removed consent after logout",err)}
}
func TestIntegrationConcurrentRemoveAndInsertCannotResurrect(t *testing.T){
 ctx,s,identities:=integrationStore(t);a:=integrationAccount(t,ctx,identities);b:=integrationAccount(t,ctx,identities);m:=accepted(t,ctx,s,a,b);removal:=m;removal.Remove=true;g:=a.Guard(time.Now().UTC(),false)
 var wg sync.WaitGroup;wg.Add(2);var insertErr,removeErr error
 go func(){defer wg.Done();insertErr=s.Put(ctx,m,time.Now().UTC())}()
 go func(){defer wg.Done();removeErr=s.Remove(ctx,&g,removal,time.Now().UTC())}();wg.Wait()
 if removeErr!=nil{t.Fatal("remove failed",removeErr)};if insertErr!=nil&&!errors.Is(insertErr,ft.ErrConflict){t.Fatal("unexpected insert failure",insertErr)}
 if countPair(t,ctx,s,m)!=0{t.Fatal("concurrent acceptance resurrected removed relationship")}
}
func TestIntegrationBlockTriggerRollsBackWithItsOriginalTransaction(t *testing.T){
 ctx,s,identities:=integrationStore(t);a:=integrationAccount(t,ctx,identities);b:=integrationAccount(t,ctx,identities);m:=accepted(t,ctx,s,a,b);if err:=s.Put(ctx,m,time.Now().UTC());err!=nil{t.Fatal(err)}
 tx,err:=s.pool.Begin(ctx);if err!=nil{t.Fatal(err)};defer tx.Rollback(ctx)
 if _,err:=tx.Exec(ctx,`INSERT INTO notitle.blocks(id,block_ref,blocker_id,blocked_id,created_at) VALUES($1,$2,$3,$4,$5)`,testUUID(t),testRef(t),m.A.ID,m.B.ID,time.Now().UTC());err!=nil{t.Fatal(err)}
 var count int;if tx.QueryRow(ctx,`SELECT count(*) FROM notitle.friendships WHERE relation_ref=$1`,m.Ref).Scan(&count)!=nil||count!=0{t.Fatal("trigger did not remove relationship in same transaction")}
 if err:=tx.Rollback(ctx);err!=nil{t.Fatal(err)};if countPair(t,ctx,s,m)!=1{t.Fatal("rolled-back safety action lost friendship")}
 snapshot,err:=s.Friends(ctx,a,time.Now().UTC());if err!=nil||snapshot.Revision!=m.ARevision{t.Fatal("rolled-back action advanced revision",err)}
}
