package friends

import (
 "context"
 "errors"
 "sort"
 "time"
 "github.com/jackc/pgx/v5"
 "github.com/jackc/pgx/v5/pgxpool"
 ft "notitle/internal/friendtypes"
 "notitle/internal/identity"
)

type PostgresStore struct{pool *pgxpool.Pool;limit int}
var errCommitUncertain=errors.New("friendship commit outcome requires reconciliation")
func NewPostgresStore(pool *pgxpool.Pool,maxPerIdentity int)*PostgresStore{return &PostgresStore{pool:pool,limit:maxPerIdentity}}
var _ Repository=(*PostgresStore)(nil)

func transaction[T any](ctx context.Context,s *PostgresStore,fn func(context.Context,pgx.Tx)(T,error))(T,error){
 var zero T;if s==nil||s.pool==nil||s.limit<1||s.limit>ft.MaxFriendsPerIdentity{return zero,ft.ErrUnavailable}
 ctx,cancel:=context.WithTimeout(ctx,4*time.Second);defer cancel()
 tx,err:=s.pool.BeginTx(ctx,pgx.TxOptions{IsoLevel:pgx.ReadCommitted});if err!=nil{return zero,ft.ErrUnavailable}
 defer func(){cleanup,stop:=context.WithTimeout(context.Background(),time.Second);defer stop();_ = tx.Rollback(cleanup)}()
 out,err:=fn(ctx,tx);if err!=nil{return zero,err};if tx.Commit(ctx)!=nil{return zero,errCommitUncertain};return out,nil
}
// Same deterministic account lock order as identity and safety transactions.
func lockAccounts(ctx context.Context,tx pgx.Tx,ids ...string)error{
 sort.Strings(ids);unique:=make([]string,0,len(ids));previous:="";for _,id:=range ids{if id==""||id==previous{continue};unique=append(unique,id);previous=id}
 rows,err:=tx.Query(ctx,`SELECT id::text FROM notitle.accounts WHERE id=ANY($1::uuid[]) ORDER BY id FOR UPDATE`,unique);if err!=nil{return ft.ErrUnavailable};defer rows.Close()
 count:=0;for rows.Next(){var id string;if rows.Scan(&id)!=nil{return ft.ErrUnavailable};count++};if rows.Err()!=nil{return ft.ErrUnavailable};if count!=len(unique){return ft.ErrUnauthorized};return nil
}
func guardSession(ctx context.Context,tx pgx.Tx,g identity.Guard,now time.Time)error{
 var valid bool;err:=tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.accounts a JOIN notitle.sessions s ON s.account_id=a.id WHERE a.id=$1 AND a.status='active' AND a.generation=$2 AND s.id=$3 AND s.token_hash=$4 AND s.account_generation=a.generation AND s.revoked_at IS NULL AND s.created_at<=$5 AND s.absolute_expires_at>$5 AND s.last_seen_at>$5-interval '7 days')`,g.AccountID,g.AccountGeneration,g.SessionID,g.TokenHash[:],now).Scan(&valid)
 if err!=nil{return ft.ErrUnavailable};if !valid{return ft.ErrUnauthorized};return nil
}
func normalize(m ft.Mutation)ft.Mutation{
 if m.A.ID>m.B.ID{m.A,m.B=m.B,m.A;m.AGuard,m.BGuard=m.BGuard,m.AGuard;m.ARevision,m.BRevision=m.BRevision,m.ARevision;m.AConsentAt,m.BConsentAt=m.BConsentAt,m.AConsentAt};return m
}
func validPair(m ft.Mutation)bool{return ft.ValidRef(m.Ref)&&m.A.Kind==identity.KindAccount&&m.B.Kind==identity.KindAccount&&m.A.ID!=""&&m.B.ID!=""&&m.A.ID!=m.B.ID}
func validInsert(m ft.Mutation,now time.Time)bool{
 return validPair(m)&&!m.Remove&&m.ARevision>0&&m.BRevision>0&&m.A.Generation>0&&m.B.Generation>0&&
 (m.Promotion||(m.AGuard.AccountID==m.A.ID&&m.BGuard.AccountID==m.B.ID&&m.AGuard.AccountGeneration==m.A.Generation&&m.BGuard.AccountGeneration==m.B.Generation))&&
 !m.AConsentAt.IsZero()&&!m.BConsentAt.IsZero()&&!m.CreatedAt.IsZero()&&!m.AConsentAt.After(m.CreatedAt)&&!m.BConsentAt.After(m.CreatedAt)&&!m.CreatedAt.After(now)
}
func(s *PostgresStore)Put(ctx context.Context,m ft.Mutation,now time.Time)error{
 if !validInsert(m,now){return ft.ErrInvalid};m=normalize(m)
 _,err:=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){
  if err:=lockAccounts(ctx,tx,m.A.ID,m.B.ID);err!=nil{return false,err}
  if !m.Promotion{
   if err:=guardSession(ctx,tx,m.AGuard,now);err!=nil{return false,err};if err:=guardSession(ctx,tx,m.BGuard,now);err!=nil{return false,err}
  }else{
   // Mutual consent already exists. Logout or a credential generation change
   // does not delete friendship; an upgrade may finish while the peer is
   // offline. Account deletion, removal revisions and safety still dominate.
   var active bool;if tx.QueryRow(ctx,`SELECT count(*)=2 FROM notitle.accounts WHERE id=ANY($1::uuid[]) AND status='active'`,[]string{m.A.ID,m.B.ID}).Scan(&active)!=nil{return false,ft.ErrUnavailable};if !active{return false,ft.ErrUnauthorized}
  }
  var aRevision,bRevision int64
  if tx.QueryRow(ctx,`SELECT friend_revision FROM notitle.accounts WHERE id=$1`,m.A.ID).Scan(&aRevision)!=nil||tx.QueryRow(ctx,`SELECT friend_revision FROM notitle.accounts WHERE id=$1`,m.B.ID).Scan(&bRevision)!=nil{return false,ft.ErrUnavailable}
  if aRevision!=m.ARevision||bRevision!=m.BRevision{return false,ft.ErrConflict}
  var blocked,restricted,pending bool
  err:=tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.blocks WHERE (blocker_id=$1 AND blocked_id=$2) OR (blocker_id=$2 AND blocked_id=$1)), EXISTS(SELECT 1 FROM notitle.account_safety_state WHERE account_id=ANY($3::uuid[]) AND restricted_until>$4), EXISTS(SELECT 1 FROM notitle.pending_safety_handoffs WHERE account_id=ANY($3::uuid[]))`,m.A.ID,m.B.ID,[]string{m.A.ID,m.B.ID},now).Scan(&blocked,&restricted,&pending)
  if err!=nil{return false,ft.ErrUnavailable};if blocked||restricted{return false,ft.ErrConflict};if pending{return false,ft.ErrBusy}
  var existing string;err=tx.QueryRow(ctx,`SELECT relation_ref FROM notitle.friendships WHERE account_a=$1 AND account_b=$2`,m.A.ID,m.B.ID).Scan(&existing)
  if err==nil{if existing==m.Ref{return true,nil};return false,ft.ErrConflict};if !errors.Is(err,pgx.ErrNoRows){return false,ft.ErrUnavailable}
  for _,id:=range []string{m.A.ID,m.B.ID}{var count int;if tx.QueryRow(ctx,`SELECT count(*) FROM notitle.friendships WHERE account_a=$1 OR account_b=$1`,id).Scan(&count)!=nil{return false,ft.ErrUnavailable};if count>=s.limit{return false,ft.ErrCapacity}}
  _,err=tx.Exec(ctx,`INSERT INTO notitle.friendships(relation_ref,account_a,account_b,consent_a_at,consent_b_at,created_at) VALUES($1,$2,$3,$4,$5,$6)`,m.Ref,m.A.ID,m.B.ID,m.AConsentAt,m.BConsentAt,m.CreatedAt)
  if err!=nil{return false,ft.ErrUnavailable};return true,nil
 });return err
}
func(s *PostgresStore)Remove(ctx context.Context,g *identity.Guard,m ft.Mutation,now time.Time)error{
 if !validPair(m)||!m.Remove{return ft.ErrInvalid};m=normalize(m)
 _,err:=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){
  if err:=lockAccounts(ctx,tx,m.A.ID,m.B.ID);err!=nil{return false,err}
  if g!=nil{if g.AccountID!=m.A.ID&&g.AccountID!=m.B.ID{return false,ft.ErrNotFound};if err:=guardSession(ctx,tx,*g,now);err!=nil{return false,err}}
  // This fence must advance even if the accepted friendship is still waiting
  // for its INSERT. It prevents a late worker resurrecting it after restart.
  _,err:=tx.Exec(ctx,`UPDATE notitle.accounts SET friend_revision=friend_revision+1 WHERE id=ANY($1::uuid[])`,[]string{m.A.ID,m.B.ID});if err!=nil{return false,ft.ErrUnavailable}
  _,err=tx.Exec(ctx,`DELETE FROM notitle.friendships WHERE relation_ref=$1 AND account_a=$2 AND account_b=$3`,m.Ref,m.A.ID,m.B.ID);if err!=nil{return false,ft.ErrUnavailable};return true,nil
 });return err
}
func(s *PostgresStore)Compensate(ctx context.Context,m ft.Mutation)error{
 if !validPair(m){return ft.ErrInvalid};m=normalize(m)
 _,err:=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){
  if err:=lockAccounts(ctx,tx,m.A.ID,m.B.ID);err!=nil{return false,err}
  // Generation changes may make publication stale after SQL succeeded. The
  // exact reference avoids deleting a newer, independently consented pair.
  _,err:=tx.Exec(ctx,`DELETE FROM notitle.friendships WHERE relation_ref=$1 AND account_a=$2 AND account_b=$3`,m.Ref,m.A.ID,m.B.ID);if err!=nil{return false,ft.ErrUnavailable};return true,nil
 });return err
}
func(s *PostgresStore)Friends(ctx context.Context,p identity.Principal,now time.Time)(ft.Snapshot,error){
 if p.Kind==identity.KindGuest{return ft.Snapshot{Relations:[]ft.Relation{}},nil};if p.Kind!=identity.KindAccount{return ft.Snapshot{},ft.ErrUnauthorized}
 return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(ft.Snapshot,error){
  g:=p.Guard(now,false);if err:=lockAccounts(ctx,tx,g.AccountID);err!=nil{return ft.Snapshot{},err};if err:=guardSession(ctx,tx,g,now);err!=nil{return ft.Snapshot{},err}
  out:=ft.Snapshot{Relations:[]ft.Relation{}}
  if tx.QueryRow(ctx,`SELECT friend_revision FROM notitle.accounts WHERE id=$1`,g.AccountID).Scan(&out.Revision)!=nil{return out,ft.ErrUnavailable}
  rows,err:=tx.Query(ctx,`SELECT f.relation_ref,a.id::text,a.generation,a.friend_revision,p.display_name,f.created_at FROM notitle.friendships f JOIN notitle.accounts a ON a.id=CASE WHEN f.account_a=$1 THEN f.account_b ELSE f.account_a END JOIN notitle.profiles p ON p.account_id=a.id WHERE (f.account_a=$1 OR f.account_b=$1) AND a.status='active' AND NOT EXISTS(SELECT 1 FROM notitle.blocks b WHERE (b.blocker_id=$1 AND b.blocked_id=a.id) OR (b.blocker_id=a.id AND b.blocked_id=$1)) ORDER BY f.created_at DESC,f.relation_ref LIMIT $2`,g.AccountID,ft.MaxFriendsPerIdentity+1)
  if err!=nil{return out,ft.ErrUnavailable};defer rows.Close()
  for rows.Next(){r:=ft.Relation{Self:ft.Subject{Kind:identity.KindAccount,ID:g.AccountID,Generation:g.AccountGeneration},Peer:ft.Subject{Kind:identity.KindAccount}};if rows.Scan(&r.Ref,&r.Peer.ID,&r.Peer.Generation,&r.PeerRevision,&r.PeerDisplayName,&r.CreatedAt)!=nil{return out,ft.ErrUnavailable};out.Relations=append(out.Relations,r)}
  if rows.Err()!=nil||len(out.Relations)>ft.MaxFriendsPerIdentity{return ft.Snapshot{},ft.ErrUnavailable};return out,nil
 })
}
func(s *PostgresStore)Read(ctx context.Context,g identity.Guard,ref string)(ft.Relation,error){
 if !ft.ValidRef(ref){return ft.Relation{},ft.ErrInvalid}
 return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(ft.Relation,error){
  if err:=lockAccounts(ctx,tx,g.AccountID);err!=nil{return ft.Relation{},err};if err:=guardSession(ctx,tx,g,g.Now);err!=nil{return ft.Relation{},err}
  r:=ft.Relation{Self:ft.Subject{Kind:identity.KindAccount,ID:g.AccountID,Generation:g.AccountGeneration},Peer:ft.Subject{Kind:identity.KindAccount}}
  err:=tx.QueryRow(ctx,`SELECT f.relation_ref,a.id::text,a.generation,a.friend_revision,p.display_name,f.created_at FROM notitle.friendships f JOIN notitle.accounts a ON a.id=CASE WHEN f.account_a=$1 THEN f.account_b ELSE f.account_a END JOIN notitle.profiles p ON p.account_id=a.id WHERE f.relation_ref=$2 AND (f.account_a=$1 OR f.account_b=$1)`,g.AccountID,ref).Scan(&r.Ref,&r.Peer.ID,&r.Peer.Generation,&r.PeerRevision,&r.PeerDisplayName,&r.CreatedAt)
  if errors.Is(err,pgx.ErrNoRows){return ft.Relation{},ft.ErrNotFound};if err!=nil{return ft.Relation{},ft.ErrUnavailable};return r,nil
 })
}
