# Cashfree contract and validation notes

The adapter pins `x-api-version: 2026-01-01`. No SDK dependency is added: request construction, exact decimal parsing, and the official documented manual webhook HMAC procedure use the Go standard library. The SDK/manual verification documentation was checked on 2026-10-09. This records a contract review, not a successful sandbox or live transaction. The HTTP handler returns exactly `200` with an empty body only after durable inbox commit: Cashfree's documented retry policy requires HTTP 200, so generic successful 2xx responses such as 204 are not used. The delivery contract was rechecked on 2026-10-10 Asia/Kolkata (2026-10-09 UTC).

| Operation | Endpoint |
| --- | --- |
| Create/fetch order | `POST /orders`, `GET /orders/{order_id}` |
| Fetch all payment attempts | `GET /orders/{order_id}/payments` |
| Create/fetch refund | `POST /orders/{order_id}/refunds`, `GET /orders/{order_id}/refunds/{refund_id}` |
| Fetch refunds including dashboard activity | `GET /orders/{order_id}/refunds` |
| Daily payment reconciliation | `POST /recon` |
| Daily settlement reconciliation | `POST /settlement/recon` |

The environment selects one fixed HTTPS origin: `sandbox.cashfree.com/pg` or `api.cashfree.com/pg`. There is no configurable provider URL, environment fallback, redirect following or proxy inheritance. Requests have eight-second deadlines, bounded transport connections, a two-MiB response limit, no automatic retries, and errors that omit provider bodies and URLs. Provider mutations use deterministic UUID-shaped idempotency keys scoped by environment, merchant and immutable operation reference. The service must validate the returned amount, currency, reference and per-purchase customer identifier against its committed intent.

Amounts are integer paise, encoded as decimal JSON rupees. Monetary input never passes through float64. Excess fractional digits, exponents, duplicate JSON keys and oversized bodies are rejected. IDs represented as JSON integers retain all digits. A real checkout phone is passed only to Cashfree; optional email/name are omitted. The application does not persist that phone, provider contact/bank/card data, or raw webhook payloads.

Webhook verification reads the exact raw bytes and the single `x-webhook-timestamp` and `x-webhook-signature` headers. The signature is base64 HMAC-SHA256 of timestamp followed by the untouched body, compared in constant time. The size limit is 256 KiB. The timestamp is decimal Unix milliseconds, with a five-minute future tolerance. There is deliberately no short past-age cutoff: delayed authenticated retries must reach durable deduplication. A fingerprint of environment, merchant and raw body is retained alongside minimal business references; new delivery timestamps do not create new work for the same raw event. A previous secret may be accepted only until an explicit deadline at most 24 hours from startup. After expiry the current key remains the only accepted key. Operational key rotation requires a restart with reviewed overlap and subsequent removal of the previous key.

The worker refetches authoritative order, payment and refund state before every grant. SUCCESS and captured status, exact INR amount, immutable snapshot, provider order ID, customer identifier, merchant credentials and environment must agree. It validates the entire financial snapshot before applying captures. Pending and processed refunds jointly reserve their original capture amount; full reservations withhold an initial grant. Definitive refund failure schedules another verification so a previously withheld capture can recover. Expired provider checkouts clear their session, while a later verified capture remains eligible. Only provider-confirmed absent intents with no attached provider ID may expire locally after 24 hours.

Refunds use STANDARD speed and are reconciled under the original refund reference. A known provider refund ID is polled directly from the original order's refund list; an imported dashboard refund cannot become a second disbursement under its local record ID. Unknown outcomes keep the refund pending. More than one successful payment attempt on the order requires operator review before a new refund, because the API does not select a payment instrument. New API refund submission at or beyond the conservative 180-day boundary is sent to restricted review, including annual-plan cases. A provider's processed status is not independent evidence of credit in the customer's bank account.

Daily reports use bounded pages and durable cursors. The projection includes only financial identifiers, integer amounts and provider statuses; unknown associations and disputes go to review. Known unsuccessful or pending payment observations may lack fee and net amounts: they are retained and verified without creating routine financial exceptions. This exception never applies to successful captures, unknown statuses, non-INR observations or settlement rows. Reconciliation reports do not replace verification of actual bank credits. The operator must investigate exceptions promptly and compare bank records during the weekly review.

Before enabling payments, exercise these exact contracts with the approved merchant sandbox, signed provider deliveries and current hosted checkout, including empty/expired orders, failed attempts, old/delayed events, full and partial dashboard refunds, pagination, invalid currencies, duplicate captures, timeout-after-create, refund timeout, consumer notifications and mobile return behavior. The strict CSP allows only explicitly reviewed origins; Cashfree's hosted checkout documentation does not establish that the supplied CSP has passed real browser checkout. Record any required narrowly scoped adjustments after observing the sandbox flow. Production still requires written business approval, finalized tax/refund disclosures, annual-refund arrangements and deliberately authorized live capture/refund/settlement verification.

Official references:

- [API overview and fixed environment URLs](https://www.cashfree.com/docs/api-reference/payments/latest/overview)
- [Create order and UUID idempotency header](https://www.cashfree.com/docs/api-reference/payments/latest/orders/create-order)
- [Payment attempts, order association and capture fields](https://www.cashfree.com/docs/api-reference/payments/latest/payments/get-payments-for-an-order)
- [Raw webhook signature verification](https://www.cashfree.com/docs/api-reference/payments/latest/webhooks/signature-verification)
- [Webhook delivery and HTTP 200 retry contract](https://www.cashfree.com/docs/payments/online/webhooks/overview)
- [Create refund, ordinary speed and provider window](https://www.cashfree.com/docs/api-reference/payments/latest/refunds/create-refund)
- [Get refund](https://www.cashfree.com/docs/api-reference/payments/latest/refunds/get-refund)
- [List all refunds for an order](https://www.cashfree.com/docs/api-reference/payments/latest/refunds/get-all-refunds-for-an-order)
- [Refund and automatic-refund notifications](https://www.cashfree.com/docs/api-reference/payments/latest/refunds/webhooks)
- [Payment reconciliation](https://www.cashfree.com/docs/api-reference/payments/latest/pg-reconciliation/pg-reconciliation)
- [Settlement reconciliation](https://www.cashfree.com/docs/api-reference/payments/latest/settlement-reconciliation/settlement-reconciliation)
- [Dispute notifications and response deadlines](https://www.cashfree.com/docs/api-reference/payments/latest/disputes/dispute-webhooks)
- [Hosted redirect checkout](https://www.cashfree.com/docs/payments/online/web/redirect)
