// Package cashfree implements the pinned Cashfree Payment Gateway contract.
// Provider responses are private inputs; never log or expose them wholesale.
package cashfree

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"math"
	"strconv"
	"strings"
)

var ErrInvalid = errors.New("invalid provider data")

// Amount is integer paise; JSON uses decimal rupees without any float conversion.
type Amount int64

func (a Amount) MarshalJSON() ([]byte, error) {
	n := int64(a)
	if n == math.MinInt64 { return nil, ErrInvalid }
	sign := ""
	if n < 0 { sign = "-"; n = -n }
	f := strconv.FormatInt(n%100, 10)
	if len(f) == 1 { f = "0"+f }
	return []byte(sign+strconv.FormatInt(n/100,10)+"."+f), nil
}

func (a *Amount) UnmarshalJSON(raw []byte) error {
	s := string(raw)
	if len(s) == 0 || len(s) > 22 || s == "null" { return ErrInvalid }
	negative := strings.HasPrefix(s,"-")
	if negative { s = s[1:] }
	p := strings.Split(s,".")
	if len(p)>2 || len(p[0])==0 || (len(p[0])>1 && p[0][0]=='0') { return ErrInvalid }
	frac := "00"
	if len(p)==2 { if len(p[1])<1 || len(p[1])>2 {return ErrInvalid}; frac=p[1]; if len(frac)==1 {frac+="0"} }
	for _, c := range p[0]+frac { if c<'0'||c>'9' {return ErrInvalid} }
	n, err := strconv.ParseInt(p[0]+frac,10,64)
	if err!=nil {return ErrInvalid}; if negative {n=-n}; *a=Amount(n); return nil
}

// Identifier accepts documented numeric IDs and string IDs losslessly.
type Identifier string
func (i *Identifier) UnmarshalJSON(raw []byte) error {
	if bytes.Equal(raw,[]byte("null")) { *i=""; return nil }
	s:=string(raw)
	if len(raw)>0 && raw[0]=='"' {if json.Unmarshal(raw,&s)!=nil {return ErrInvalid}} else {for _,c:=range s {if c<'0'||c>'9' {return ErrInvalid}}}
	if s!="" && !validRef(s,128) {return ErrInvalid}; *i=Identifier(s); return nil
}
func validRef(s string,max int)bool {if len(s)<1||len(s)>max{return false}; for _,c:=range s {if !(c>='a'&&c<='z'||c>='A'&&c<='Z'||c>='0'&&c<='9'||c=='_'||c=='-'){return false}}; return true}

// Reject duplicate JSON keys rather than allowing different parsers to choose
// different financial identifiers from the same signature-verified document.
func decode(raw []byte, target any) error {
	d:=json.NewDecoder(bytes.NewReader(raw)); d.UseNumber()
	if err:=uniqueValue(d,0);err!=nil{return ErrInvalid}; if _,err:=d.Token();err!=io.EOF{return ErrInvalid}
	if err:=json.Unmarshal(raw,target);err!=nil{return ErrInvalid};return nil
}
func uniqueValue(d *json.Decoder, depth int)error {
	if depth>32{return ErrInvalid};t,err:=d.Token();if err!=nil{return err};v,ok:=t.(json.Delim);if !ok{return nil}
	switch v {case '{': keys:=map[string]bool{};for d.More(){k,e:=d.Token();if e!=nil{return e};s,ok:=k.(string);if !ok||keys[s]{return ErrInvalid};keys[s]=true;if e=uniqueValue(d,depth+1);e!=nil{return e}};end,e:=d.Token();if e!=nil||end!=json.Delim('}'){return ErrInvalid}
	case '[': for d.More(){if e:=uniqueValue(d,depth+1);e!=nil{return e}};end,e:=d.Token();if e!=nil||end!=json.Delim(']'){return ErrInvalid}
	default:return ErrInvalid};return nil
}
