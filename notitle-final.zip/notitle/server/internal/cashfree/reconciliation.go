package cashfree

import (
	"context"
	"net/http"
	"time"
)

// ReconRow deliberately excludes customer, bank and provider free-text fields.
type ReconRow struct {
	Event struct{ID Identifier `json:"event_id"`;Type string `json:"event_type"`;Status string `json:"event_status"`;Currency string `json:"event_currency"`;Amount *Amount `json:"event_amount"`;Fee *Amount `json:"event_service_charge"`;Tax *Amount `json:"event_service_tax"`;Net *Amount `json:"event_settlement_amount"`;SaleType string `json:"sale_type"`} `json:"event_details"`
	Order struct{ID string `json:"order_id"`;Currency string `json:"order_currency"`;Amount *Amount `json:"order_amount"`} `json:"order_details"`
	Payment struct{ID Identifier `json:"cf_payment_id"`;Status string `json:"status"`;Currency string `json:"payment_currency"`;Amount *Amount `json:"payment_amount"`;Fee *Amount `json:"payment_service_charge"`;Tax *Amount `json:"payment_service_tax"`} `json:"payment_details"`
	Settlement struct{ID Identifier `json:"cf_settlement_id"`;Currency string `json:"settlement_currency"`;Status string `json:"status"`} `json:"settlement_details"`
}
type ReconPage struct{Cursor string `json:"cursor"`;Data []ReconRow `json:"data"`}
func(c *Client)Reconciliation(ctx context.Context,settlement bool,from,to time.Time,cursor string)(ReconPage,error){
	var out ReconPage;if from.IsZero()||!to.After(from)||to.Sub(from)>8*24*time.Hour||len(cursor)>4096{return out,ErrInvalid}
	filters:=map[string]string{"start_date":from.UTC().Format(time.RFC3339),"end_date":to.UTC().Format(time.RFC3339)};path:="/recon"
	if settlement{path="/settlement/recon";filters=map[string]string{"start_date_initiated_on":from.UTC().Format(time.RFC3339),"end_date_initiated_on":to.UTC().Format(time.RFC3339)}}
	var next *string;if cursor!=""{next=&cursor};body:=struct{Pagination struct{Limit int `json:"limit"`;Cursor *string `json:"cursor"`} `json:"pagination"`;Filters map[string]string `json:"filters"`}{Filters:filters};body.Pagination.Limit=100;body.Pagination.Cursor=next
	if e:=c.do(ctx,http.MethodPost,path,"",body,&out);e!=nil{return out,e};if out.Data==nil||len(out.Data)>100||len(out.Cursor)>4096{return ReconPage{},ErrInvalid};for _,r:=range out.Data{if r.Event.ID==""||r.Event.Type==""||len(r.Event.Type)>80||len(r.Event.Status)>80||(r.Order.ID!=""&&!validRef(r.Order.ID,128)){return ReconPage{},ErrInvalid}}
	return out,nil
}
