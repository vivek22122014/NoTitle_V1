package cashfree

import (
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/tls"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"
)

const APIVersion = "2026-01-01"
const MaxResponseBytes = 2 << 20
var (
	ErrUnavailable=errors.New("provider unavailable; outcome requires reconciliation")
	ErrNotFound=errors.New("provider reference not found")
	ErrRejected=errors.New("provider rejected request")
)
type Options struct { Environment, ClientID, ClientSecret, MerchantID, PublicOrigin string }
type Client struct { environment,clientID,secret,merchant,origin,base string; http *http.Client }
func New(o Options)(*Client,error){
	base:="";switch o.Environment {case "sandbox":base="https://sandbox.cashfree.com/pg";case "production":base="https://api.cashfree.com/pg";default:return nil,ErrInvalid}
	if !validRef(o.ClientID,256)||len(o.ClientSecret)<16||len(o.ClientSecret)>512||strings.ContainsAny(o.ClientSecret,"\r\n")||!validRef(o.MerchantID,128){return nil,ErrInvalid}
	u,e:=url.Parse(o.PublicOrigin);if e!=nil||u.User!=nil||u.RawQuery!=""||u.Fragment!=""||u.Path!=""||u.Host=="" {return nil,ErrInvalid}
	if u.Scheme!="https" && !(o.Environment=="sandbox"&&u.Scheme=="http"&&(u.Hostname()=="localhost"||u.Hostname()=="127.0.0.1"||u.Hostname()=="::1")){return nil,ErrInvalid}
	t:= &http.Transport{Proxy:nil,DialContext:(&net.Dialer{Timeout:3*time.Second,KeepAlive:30*time.Second}).DialContext,TLSClientConfig:&tls.Config{MinVersion:tls.VersionTLS12},TLSHandshakeTimeout:3*time.Second,ResponseHeaderTimeout:5*time.Second,MaxIdleConns:4,MaxConnsPerHost:4,IdleConnTimeout:60*time.Second}
	return &Client{environment:o.Environment,clientID:o.ClientID,secret:o.ClientSecret,merchant:o.MerchantID,origin:o.PublicOrigin,base:base,http:&http.Client{Transport:t,Timeout:8*time.Second,CheckRedirect:func(*http.Request,[]*http.Request)error{return http.ErrUseLastResponse}}},nil
}
func(c *Client) Environment()string{return c.environment}
func(c *Client) MerchantID()string{return c.merchant}
func(c *Client) do(ctx context.Context,method,path,key string,input,out any)error{
	var body []byte;var err error;if input!=nil {body,err=json.Marshal(input);if err!=nil{return ErrInvalid}}
	r,err:=http.NewRequestWithContext(ctx,method,c.base+path,bytes.NewReader(body));if err!=nil{return ErrInvalid}
	r.Header.Set("x-client-id",c.clientID);r.Header.Set("x-client-secret",c.secret);r.Header.Set("x-api-version",APIVersion);r.Header.Set("Accept","application/json");if input!=nil{r.Header.Set("Content-Type","application/json")};if key!=""{r.Header.Set("x-idempotency-key",IdempotencyKey(c.environment+":"+c.merchant+":"+key))}
	resp,err:=c.http.Do(r);if err!=nil{return ErrUnavailable};defer resp.Body.Close()
	raw,err:=io.ReadAll(io.LimitReader(resp.Body,MaxResponseBytes+1));if err!=nil||len(raw)>MaxResponseBytes{return ErrUnavailable}
	if resp.StatusCode==404{return ErrNotFound};if resp.StatusCode==409||resp.StatusCode==408||resp.StatusCode==429||resp.StatusCode>=500{return ErrUnavailable};if resp.StatusCode<200||resp.StatusCode>=300{return ErrRejected}
	if err=decode(raw,out);err!=nil{return ErrInvalid};return nil
}
// UUID-shaped deterministic key from a stable operation reference. Retry never
// generates a new merchant order/refund ID or a new provider idempotency key.
func IdempotencyKey(reference string)string{h:=sha256.Sum256([]byte(reference));h[6]=(h[6]&15)|0x50;h[8]=(h[8]&63)|0x80;s:=hex.EncodeToString(h[:16]);return s[:8]+"-"+s[8:12]+"-"+s[12:16]+"-"+s[16:20]+"-"+s[20:]}
type Order struct { ID string `json:"order_id"`; ProviderID Identifier `json:"cf_order_id"`; Amount Amount `json:"order_amount"`; Currency string `json:"order_currency"`; Status string `json:"order_status"`; Session string `json:"payment_session_id"`; Customer struct{ID string `json:"customer_id"`} `json:"customer_details"` }
type CreateOrder struct {Ref,CustomerID,Phone string; AmountPaise int64; Currency string}
func(c *Client)CreateOrder(ctx context.Context,v CreateOrder)(Order,error){
	var out Order;if !validRef(v.Ref,45)||len(v.Ref)<3||!validRef(v.CustomerID,50)||!ValidPhone(v.Phone)||v.AmountPaise<100||v.Currency!="INR"{return out,ErrInvalid}
	body:=struct{ID string `json:"order_id"`;Amount Amount `json:"order_amount"`;Currency string `json:"order_currency"`;Customer map[string]string `json:"customer_details"`;Meta map[string]string `json:"order_meta"`}{v.Ref,Amount(v.AmountPaise),v.Currency,map[string]string{"customer_id":v.CustomerID,"customer_phone":v.Phone},map[string]string{"return_url":c.origin+"/payment/status?purchase_ref="+url.QueryEscape(v.Ref),"notify_url":c.origin+"/api/v1/webhooks/cashfree"}}
	err:=c.do(ctx,http.MethodPost,"/orders","order:"+v.Ref,body,&out);if err==nil{err=validateOrder(out,v.Ref)};return out,err
}
func ValidPhone(v string)bool{if strings.HasPrefix(v,"+91"){v=v[3:]};if len(v)!=10||v[0]<'6'||v[0]>'9'{return false};for _,c:=range v{if c<'0'||c>'9'{return false}};return true}
func validateOrder(v Order,ref string)error{if v.ID!=ref||v.ProviderID==""||v.Currency!="INR"||v.Amount<100||len(v.Session)>2048{return ErrInvalid};switch v.Status{case "ACTIVE","PAID","EXPIRED","TERMINATED","TERMINATION_REQUESTED":return nil};return ErrInvalid}
func(c *Client)GetOrder(ctx context.Context,ref string)(Order,error){var out Order;if !validRef(ref,45){return out,ErrInvalid};err:=c.do(ctx,http.MethodGet,"/orders/"+ref,"",nil,&out);if err==nil{err=validateOrder(out,ref)};return out,err}
type Payment struct {ID Identifier `json:"cf_payment_id"`;OrderID string `json:"order_id"`;Amount Amount `json:"payment_amount"`;OrderAmount Amount `json:"order_amount"`;Currency string `json:"payment_currency"`;OrderCurrency string `json:"order_currency"`;Status string `json:"payment_status"`;Captured bool `json:"is_captured"`;CompletedAt string `json:"payment_completion_time"`;StartedAt string `json:"payment_time"`}
func(c *Client)Payments(ctx context.Context,ref string)([]Payment,error){var out []Payment;if !validRef(ref,45){return nil,ErrInvalid};if e:=c.do(ctx,http.MethodGet,"/orders/"+ref+"/payments","",nil,&out);e!=nil{return nil,e};if out==nil||len(out)>256{return nil,ErrInvalid};for _,p:=range out{if p.OrderID!=ref||p.ID==""{return nil,ErrInvalid}};return out,nil}
type Refund struct {ID string `json:"refund_id"`;ProviderID Identifier `json:"cf_refund_id"`;OrderID string `json:"order_id"`;PaymentID Identifier `json:"cf_payment_id"`;Amount Amount `json:"refund_amount"`;Currency string `json:"refund_currency"`;Status string `json:"refund_status"`;Type string `json:"refund_type"`;ProcessedAt string `json:"processed_at"`}
func validateRefund(r Refund,ref string)error{auto:=r.Type=="PAYMENT_AUTO_REFUND"||r.Type=="UNRECONCILED_AUTO_REFUND";if r.OrderID!=ref||(!validRef(r.ID,128)&&!(auto&&r.ID==""))||r.ProviderID==""||r.PaymentID==""||r.Currency!="INR"||r.Amount<=0{return ErrInvalid};return nil}
func(c *Client)Refunds(ctx context.Context,ref string)([]Refund,error){var out []Refund;if !validRef(ref,45){return nil,ErrInvalid};if e:=c.do(ctx,http.MethodGet,"/orders/"+ref+"/refunds","",nil,&out);e!=nil{return nil,e};if out==nil||len(out)>256{return nil,ErrInvalid};for _,r:=range out{if e:=validateRefund(r,ref);e!=nil{return nil,e}};return out,nil}
func(c *Client)GetRefund(ctx context.Context,ref,id string)(Refund,error){var out Refund;if !validRef(ref,45)||!validRef(id,128){return out,ErrInvalid};e:=c.do(ctx,http.MethodGet,"/orders/"+ref+"/refunds/"+id,"",nil,&out);if e==nil{e=validateRefund(out,ref);if out.ID!=id{e=ErrInvalid}};return out,e}
func(c *Client)CreateRefund(ctx context.Context,ref,id string,paise int64)(Refund,error){var out Refund;if !validRef(ref,45)||!validRef(id,40)||len(id)<3||paise<=0{return out,ErrInvalid};body:=struct{ID string `json:"refund_id"`;Amount Amount `json:"refund_amount"`;Note string `json:"refund_note"`;Speed string `json:"refund_speed"`}{id,Amount(paise),"Approved refund","STANDARD"};var raw json.RawMessage;e:=c.do(ctx,http.MethodPost,"/orders/"+ref+"/refunds","refund:"+id,body,&raw);if e!=nil{return out,e};if len(raw)>0&&raw[0]=='['{var rows []Refund;if e=decode(raw,&rows);e!=nil||len(rows)!=1{return out,ErrInvalid};out=rows[0]}else if e=decode(raw,&out);e!=nil{return out,e};if e=validateRefund(out,ref);e!=nil{return out,e};if out.ID!=id||int64(out.Amount)!=paise{return out,ErrInvalid};return out,nil}
