package cashfree

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"net/http"
	"strconv"
	"strings"
	"time"
)

const MaxWebhookBytes = 256 << 10
var ErrSignature=errors.New("invalid webhook signature")
type WebhookOptions struct { Environment,MerchantID,Secret,PreviousSecret string; PreviousUntil time.Time; Now func()time.Time }
type WebhookVerifier struct { environment,merchant string; current,previous []byte; previousUntil time.Time; now func()time.Time }
type Event struct { Fingerprint,Type,OrderID,PaymentID,RefundID,DisputeID,DisputeStatus string; ResponseDue time.Time }
func NewWebhookVerifier(o WebhookOptions)(*WebhookVerifier,error){
	if o.Now==nil{o.Now=time.Now};if (o.Environment!="sandbox"&&o.Environment!="production")||!validRef(o.MerchantID,128)||len(o.Secret)<16||len(o.Secret)>512{return nil,ErrInvalid}
	if o.PreviousSecret!=""&&(len(o.PreviousSecret)<16||len(o.PreviousSecret)>512||!o.PreviousUntil.After(o.Now())||o.PreviousUntil.After(o.Now().Add(24*time.Hour))){return nil,ErrInvalid}
	return &WebhookVerifier{environment:o.Environment,merchant:o.MerchantID,current:[]byte(o.Secret),previous:[]byte(o.PreviousSecret),previousUntil:o.PreviousUntil,now:o.Now},nil
}
func(v *WebhookVerifier)Environment()string{return v.environment}
func(v *WebhookVerifier)MerchantID()string{return v.merchant}
func(v *WebhookVerifier)Verify(headers http.Header,raw []byte)(Event,error){
	var out Event
	if len(raw)==0||len(raw)>MaxWebhookBytes||len(headers.Values("x-webhook-timestamp"))!=1||len(headers.Values("x-webhook-signature"))!=1{return out,ErrSignature}
	ts:=headers.Get("x-webhook-timestamp");sig:=headers.Get("x-webhook-signature")
	if len(ts)<10||len(ts)>16||len(sig)!=44{return out,ErrSignature};for _,c:=range ts{if c<'0'||c>'9'{return out,ErrSignature}}
	ms,e:=strconv.ParseInt(ts,10,64);if e!=nil||ms<=0||time.UnixMilli(ms).After(v.now().Add(5*time.Minute)){return out,ErrSignature}
	got,e:=base64.StdEncoding.Strict().DecodeString(sig);if e!=nil||len(got)!=sha256.Size{return out,ErrSignature}
	valid:=verifyMAC(v.current,ts,raw,got)
	if len(v.previous)>0&&v.now().Before(v.previousUntil){valid=verifyMAC(v.previous,ts,raw,got)||valid};if !valid{return out,ErrSignature}
	// No short past-age cutoff: provider retries can carry the original signed
	// timestamp. Durable delivery and financial constraints make replay inert.
	var body struct{Type string `json:"type"`;Data struct{
		Order struct{ID string `json:"order_id"`} `json:"order"`
		Payment struct{ID Identifier `json:"cf_payment_id"`} `json:"payment"`
		Refund struct{ID string `json:"refund_id"`;OrderID string `json:"order_id"`;PaymentID Identifier `json:"cf_payment_id"`} `json:"refund"`
		AutoRefund struct{OrderID string `json:"order_id"`;PaymentID Identifier `json:"cf_payment_id"`} `json:"auto_refund"`
		OrderDetails struct{ID string `json:"order_id"`;PaymentID Identifier `json:"cf_payment_id"`} `json:"order_details"`
		Dispute struct{ID Identifier `json:"dispute_id"`;Status string `json:"dispute_status"`;RespondBy string `json:"respond_by"`} `json:"dispute"`
	} `json:"data"`}
	if decode(raw,&body)!=nil||len(body.Type)==0||len(body.Type)>80{return out,ErrInvalid}
	for _,c:=range body.Type{if !(c>='A'&&c<='Z'||c=='_'){return out,ErrInvalid}}
	h:=sha256.New();_,_=h.Write([]byte(v.environment+"\x00"+v.merchant+"\x00"));_,_=h.Write(raw);out.Fingerprint=hex.EncodeToString(h.Sum(nil));out.Type=body.Type;out.OrderID=body.Data.Order.ID;out.PaymentID=string(body.Data.Payment.ID)
	if body.Data.Refund.ID!=""{out.RefundID=body.Data.Refund.ID;if out.OrderID==""{out.OrderID=body.Data.Refund.OrderID};if out.PaymentID==""{out.PaymentID=string(body.Data.Refund.PaymentID)}}
	if body.Data.AutoRefund.OrderID!=""{if out.OrderID!=""&&out.OrderID!=body.Data.AutoRefund.OrderID{return Event{},ErrInvalid};out.OrderID=body.Data.AutoRefund.OrderID;out.PaymentID=string(body.Data.AutoRefund.PaymentID)}
	if body.Data.OrderDetails.ID!=""{if out.OrderID!=""&&out.OrderID!=body.Data.OrderDetails.ID{return Event{},ErrInvalid};out.OrderID=body.Data.OrderDetails.ID;out.PaymentID=string(body.Data.OrderDetails.PaymentID)}
	if body.Data.Dispute.ID!=""{out.DisputeID=string(body.Data.Dispute.ID);out.DisputeStatus=body.Data.Dispute.Status;if len(out.DisputeStatus)>80{return Event{},ErrInvalid};if body.Data.Dispute.RespondBy!=""{out.ResponseDue,e=time.Parse(time.RFC3339Nano,body.Data.Dispute.RespondBy);if e!=nil{return Event{},ErrInvalid}}}
	for _,s:=range []string{out.OrderID,out.PaymentID,out.RefundID,out.DisputeID}{if s!=""&&!validRef(s,128){return Event{},ErrInvalid}}
	if strings.HasPrefix(out.Type,"PAYMENT_")&&(out.OrderID==""||out.PaymentID==""){return Event{},ErrInvalid}
	// Unknown signed event types are durably retained as a minimal review trigger.
	return out,nil
}
func verifyMAC(secret []byte,ts string,raw,got []byte)bool{m:=hmac.New(sha256.New,secret);_,_=m.Write([]byte(ts));_,_=m.Write(raw);return hmac.Equal(m.Sum(nil),got)}
