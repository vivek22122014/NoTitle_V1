package audiotypes

import (
 "net/netip"
 "regexp"
 "strconv"
 "strings"
)

var (
 signalToken = regexp.MustCompile(`^[A-Za-z0-9_+/.=-]{1,256}$`)
 iceToken = regexp.MustCompile(`^[A-Za-z0-9+/]{4,256}$`)
 fingerprint = regexp.MustCompile(`^sha-256 ([A-Fa-f0-9]{2}:){31}[A-Fa-f0-9]{2}$`)
 blockedRelayRanges = []netip.Prefix{
  netip.MustParsePrefix("0.0.0.0/8"), netip.MustParsePrefix("100.64.0.0/10"),
  netip.MustParsePrefix("192.0.0.0/24"), netip.MustParsePrefix("198.18.0.0/15"),
  netip.MustParsePrefix("240.0.0.0/4"), netip.MustParsePrefix("64:ff9b::/96"),
  netip.MustParsePrefix("64:ff9b:1::/48"), netip.MustParsePrefix("100::/64"),
  netip.MustParsePrefix("2001::/32"), netip.MustParsePrefix("2001:2::/48"),
  netip.MustParsePrefix("2002::/16"), netip.MustParsePrefix("fec0::/10"),
 }
)

// ValidateCandidate accepts only RTP-component UDP relay candidates on the
// explicitly configured relay addresses and bounded allocation ports. TURN
// TCP/TLS is the browser-to-TURN transport; relayed media still uses UDP.
// Related addresses must be privacy placeholders, never client host/srflx IPs.
func ValidateCandidate(candidate string, approved []netip.Addr) error {
 if len(candidate) == 0 || len(candidate) > MaxCandidateBytes || !printable(candidate) || strings.TrimSpace(candidate) != candidate { return ErrInvalidSignal }
 f := strings.Fields(candidate)
 if len(f) < 8 || !strings.HasPrefix(f[0],"candidate:") || !smallToken(strings.TrimPrefix(f[0],"candidate:"),32) || f[1] != "1" || strings.ToLower(f[2]) != "udp" || !number(f[3],1,4294967295) || !approvedAddress(f[4],approved) || !number(f[5],RelayMinPort,RelayMaxPort) || f[6] != "typ" || f[7] != "relay" || (len(f)-8)%2 != 0 { return ErrInvalidSignal }
 seen := map[string]bool{}
 for i:=8; i<len(f); i+=2 {
  key,value := f[i],f[i+1]
  if seen[key] { return ErrInvalidSignal }; seen[key] = true
  switch key {
  case "raddr": if value != "0.0.0.0" && value != "::" { return ErrInvalidSignal }
  case "rport": if value != "0" && value != "9" { return ErrInvalidSignal }
  case "generation": if value != "0" { return ErrInvalidSignal }
  case "network-id": if !number(value,0,65535) { return ErrInvalidSignal }
  case "network-cost": if !number(value,0,999) { return ErrInvalidSignal }
  case "ufrag": if !iceToken.MatchString(value) { return ErrInvalidSignal }
  default: return ErrInvalidSignal
  }
 }
 if seen["raddr"] != seen["rport"] { return ErrInvalidSignal }
 return nil
}

// ValidateSDP deliberately implements a narrow, complete WebRTC audio grammar.
// Unsupported SDP extensions fail closed instead of forwarding unparsed lines
// that may carry an address, additional media or a data channel. The browser
// selects Opus before creating its offer; this validator never rewrites SDP.
func ValidateSDP(sdp,kind string,approved []netip.Addr) error {
 if len(sdp) == 0 || len(sdp)>MaxSDPBytes || (kind!="offer" && kind!="answer") || !strings.HasSuffix(sdp,"\r\n") { return ErrInvalidSignal }
 lines:=strings.Split(strings.TrimSuffix(sdp,"\r\n"),"\r\n")
 if len(lines)<12 || len(lines)>256 || lines[0]!="v=0" { return ErrInvalidSignal }
 seen:=map[string]bool{}; media:=false; payload:=""; candidates:=0; ssrcCount:=0
 extIDs:=map[string]bool{}
 for _,line:=range lines {
  if len(line)<2 || len(line)>2048 || line[1]!='=' || !printable(line) { return ErrInvalidSignal }
  value:=line[2:]
  switch line[0] {
  case 'v': if media || value!="0" || !once(seen,"v") { return ErrInvalidSignal }
  case 'o':
   f:=strings.Fields(value)
   if media || !once(seen,"o") || len(f)!=6 || f[0]!="-" || !decimal(f[1],32) || !decimal(f[2],32) || f[3]!="IN" || !placeholderAddress(f[4],f[5],true) { return ErrInvalidSignal }
  case 's': if media || value!="-" || !once(seen,"s") { return ErrInvalidSignal }
  case 't': if media || value!="0 0" || !once(seen,"t") { return ErrInvalidSignal }
  case 'm':
   f:=strings.Fields(value)
   if media || !seen["v"] || !seen["o"] || !seen["s"] || !seen["t"] || len(f)!=4 || f[0]!="audio" || (f[1]!="9" && !number(f[1],RelayMinPort,RelayMaxPort)) || f[2]!="UDP/TLS/RTP/SAVPF" || !number(f[3],96,127) { return ErrInvalidSignal }
   media=true;payload=f[3]
  case 'c':
   if !media || !once(seen,"c") || !connection(value,approved) { return ErrInvalidSignal }
  case 'b':
   if !media { return ErrInvalidSignal }; pair:=strings.Split(value,":")
   if len(pair)!=2 || !once(seen,"b:"+pair[0]) || !((pair[0]=="AS" && number(pair[1],1,128)) || (pair[0]=="TIAS" && number(pair[1],1,128000))) { return ErrInvalidSignal }
  case 'a':
   key,val,hasValue:=strings.Cut(value,":")
   switch key {
   case "group": if media || val!="BUNDLE 0" || !once(seen,key) { return ErrInvalidSignal }
   case "msid-semantic":
    f:=strings.Fields(val);if media || !once(seen,key) || len(f)<1 || len(f)>3 || f[0]!="WMS" { return ErrInvalidSignal }
    for _,item:=range f[1:] { if item!="*" && !smallToken(item,64) { return ErrInvalidSignal } }
   case "extmap-allow-mixed": if hasValue || !once(seen,key) { return ErrInvalidSignal }
   case "ice-ufrag": if !media || !once(seen,key) || !iceToken.MatchString(val) { return ErrInvalidSignal }
   case "ice-pwd": if !media || !once(seen,key) || len(val)<22 || !iceToken.MatchString(val) { return ErrInvalidSignal }
   case "ice-options": if !once(seen,key) || (val!="trickle" && val!="trickle renomination") { return ErrInvalidSignal }
   case "fingerprint": if !once(seen,key) || !fingerprint.MatchString(val) { return ErrInvalidSignal }
   case "setup": if !once(seen,key) || (kind=="offer" && val!="actpass") || (kind=="answer" && val!="active" && val!="passive") { return ErrInvalidSignal }
   case "mid": if !media || val!="0" || !once(seen,key) { return ErrInvalidSignal }
   case "sendrecv", "rtcp-mux", "rtcp-mux-only", "rtcp-rsize", "end-of-candidates": if !media || hasValue || !once(seen,key) { return ErrInvalidSignal }
   case "rtcp":
    f:=strings.Fields(val)
    if !media || !once(seen,key) || len(f)!=4 || (f[0]!="9" && !number(f[0],RelayMinPort,RelayMaxPort)) || !connection(strings.Join(f[1:]," "),approved) { return ErrInvalidSignal }
   case "rtpmap": if !media || !once(seen,key) || !strings.EqualFold(val,payload+" opus/48000/2") { return ErrInvalidSignal }
   case "fmtp": if !media || !once(seen,key) || !opusParameters(val,payload) { return ErrInvalidSignal }
   case "rtcp-fb": if !media || (val!=payload+" transport-cc" && val!=payload+" nack") || !once(seen,key+":"+val) { return ErrInvalidSignal }
   case "ptime", "maxptime": if !media || !once(seen,key) || !number(val,10,60) { return ErrInvalidSignal }
   case "extmap":
    f:=strings.Fields(val)
    if !media || len(f)!=2 { return ErrInvalidSignal };id,direction,hasDirection:=strings.Cut(f[0],"/")
    if !number(id,1,14) || extIDs[id] || (hasDirection && direction!="sendrecv" && direction!="sendonly" && direction!="recvonly" && direction!="inactive") || !audioExtension(f[1]) { return ErrInvalidSignal };extIDs[id]=true
   case "msid":
    if !media || !once(seen,key) || !tokens(val,1,2) { return ErrInvalidSignal }
   case "ssrc":
    if !media || ssrcCount>=8 { return ErrInvalidSignal };ssrcCount++
    id,attribute,ok:=strings.Cut(val," ");if !ok || !number(id,1,4294967295) { return ErrInvalidSignal }
    name,content,ok:=strings.Cut(attribute,":");if !ok || !once(seen,"ssrc:"+id+":"+name) || (name!="cname" && name!="msid" && name!="mslabel" && name!="label") || (name!="msid" && !tokens(content,1,1)) || (name=="msid" && !tokens(content,1,2)) { return ErrInvalidSignal }
   case "candidate": if !media || candidates>=MaxCandidates || ValidateCandidate(value,approved)!=nil { return ErrInvalidSignal };candidates++
   default: return ErrInvalidSignal
   }
  default:return ErrInvalidSignal
  }
 }
 for _,key:=range []string{"v","o","s","t","c","group","mid","ice-ufrag","ice-pwd","fingerprint","setup","sendrecv","rtcp-mux","rtpmap"} { if !seen[key] { return ErrInvalidSignal } }
 return nil
}

func printable(value string) bool { for _,c:=range value { if c<32 || c>126 { return false } };return true }
func once(seen map[string]bool,key string) bool { if seen[key] { return false };seen[key]=true;return true }
func decimal(value string,max int) bool { if len(value)==0 || len(value)>max { return false };for _,c:=range value { if c<'0'||c>'9' { return false } };return true }
func number(value string,min,max uint64) bool { if !decimal(value,10) { return false };n,err:=strconv.ParseUint(value,10,64);return err==nil&&n>=min&&n<=max }
func smallToken(value string,max int) bool { return len(value)<=max && signalToken.MatchString(value) }
func tokens(value string,min,max int) bool { f:=strings.Fields(value);if len(f)<min||len(f)>max{return false};for _,v:=range f { if !smallToken(v,64) { return false } };return true }
func approvedAddress(value string,approved []netip.Addr) bool {
 ip,err:=netip.ParseAddr(value)
 if err!=nil || ip.Zone()!="" || ip.Is4In6() || !ip.IsGlobalUnicast() || ip.IsPrivate() { return false }
 for _,prefix:=range blockedRelayRanges { if prefix.Contains(ip) { return false } }
 for _,allowed:=range approved { if allowed==ip { return true } };return false
}
func placeholderAddress(family,value string,origin bool) bool {
 if family=="IP4" { return value=="0.0.0.0" || (origin && value=="127.0.0.1") }
 return family=="IP6" && (value=="::" || (origin && value=="::1"))
}
func connection(value string,approved []netip.Addr) bool {
 f:=strings.Fields(value);if len(f)!=3 || f[0]!="IN" { return false }
 if placeholderAddress(f[1],f[2],false) { return true }
 ip,err:=netip.ParseAddr(f[2]);return err==nil && ((f[1]=="IP4"&&ip.Is4())||(f[1]=="IP6"&&ip.Is6()&&!ip.Is4In6())) && approvedAddress(f[2],approved)
}
func audioExtension(value string) bool {
 switch value {
 case "urn:ietf:params:rtp-hdrext:ssrc-audio-level", "urn:ietf:params:rtp-hdrext:toffset", "urn:ietf:params:rtp-hdrext:sdes:mid", "urn:ietf:params:rtp-hdrext:sdes:rtp-stream-id", "urn:ietf:params:rtp-hdrext:sdes:repaired-rtp-stream-id", "http://www.webrtc.org/experiments/rtp-hdrext/abs-send-time", "http://www.ietf.org/id/draft-holmer-rmcat-transport-wide-cc-extensions-01", "http://www.webrtc.org/experiments/rtp-hdrext/abs-capture-time": return true
 };return false
}
func opusParameters(value,payload string) bool {
 prefix,params,ok:=strings.Cut(value," ");if !ok||prefix!=payload{return false};seen:=map[string]bool{}
 parts:=strings.Split(params,";");if len(parts)>10{return false}
 for _,part:=range parts {
  key,value,ok:=strings.Cut(strings.TrimSpace(part),"=");if !ok||!once(seen,key){return false}
  switch key {
  case "minptime", "maxptime": if !number(value,10,60) { return false }
  case "useinbandfec", "usedtx", "stereo", "sprop-stereo", "cbr": if value!="0"&&value!="1"{return false}
  case "maxaveragebitrate": if !number(value,6000,128000){return false}
  case "maxplaybackrate", "sprop-maxcapturerate": if !number(value,8000,48000){return false}
  default:return false
  }
 };return true
}
