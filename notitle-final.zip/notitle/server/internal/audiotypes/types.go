// Package audiotypes defines bounded audio-control contracts. Media and SDP
// never enter durable storage, logs or a relay-control API.
package audiotypes

import (
 "context"
 "errors"
 "regexp"
 "time"
)

const (
 MaxCalls = 25
 RingTimeout = 30 * time.Second
 DeclineCooldown = 15 * time.Second
 ConnectTimeout = 30 * time.Second
 LeaseDuration = 30 * time.Second
 LeaseRenewInterval = 10 * time.Second
 CredentialLifetime = 10 * time.Minute
 CredentialRefreshInterval = 5 * time.Minute
 MaxSDPBytes = 60 * 1024
 MaxCandidateBytes = 1024
 MaxCandidates = 16
 RelayMinPort = 49152
 RelayMaxPort = 50175
)

type State string
const (
 Idle State = "IDLE"
 Requested State = "REQUESTED"
 Ringing State = "RINGING"
 Accepted State = "ACCEPTED"
 Connecting State = "CONNECTING"
 Connected State = "CONNECTED"
 Ended State = "ENDED"
)

type View struct {
 CallRef string `json:"call_ref"`
 State State `json:"state"`
 Direction string `json:"direction"`
 OfferOwner string `json:"offer_owner"`
 ExpiresAt time.Time `json:"expires_at"`
}
type RefPayload struct { CallRef string `json:"call_ref"` }
type SDPPayload struct { CallRef string `json:"call_ref"`; Negotiation uint64 `json:"negotiation"`; SDP string `json:"sdp"` }
type ConnectedPayload struct { CallRef string `json:"call_ref"`; Negotiation uint64 `json:"negotiation"` }
type ICEPayload struct {
 CallRef string `json:"call_ref"`
 Negotiation uint64 `json:"negotiation"`
 Candidate string `json:"candidate"`
 SDPMid string `json:"sdp_mid"`
 SDPMLineIndex int `json:"sdp_mline_index"`
}
type EndedPayload struct { CallRef string `json:"call_ref"`; Reason string `json:"reason"` }

// Credentials are delivered only to their accepted participant. They must
// never appear in another participant's state, logs, URLs or browser storage.
type Credentials struct {
 URLs []string `json:"urls"`
 Username string `json:"username"`
 Credential string `json:"credential"`
 ExpiresAt time.Time `json:"expires_at"`
 RefreshAt time.Time `json:"refresh_at"`
 RelayAddresses []string `json:"relay_addresses"`
 RelayMinPort int `json:"relay_min_port"`
 RelayMaxPort int `json:"relay_max_port"`
}
type CredentialsPayload struct { CallRef string `json:"call_ref"`; Negotiation uint64 `json:"negotiation"`; Credentials Credentials `json:"credentials"` }

// Jobs are immutable owner reservations. A and B credential indexes refer to
// frozen owner slots; the worker cannot choose a peer or conversation.
type Job struct {
 LeaseID string
 CallRef string
 Version uint64
 Action string
 ServerInstance string
 LeaseUntil time.Time
 CredentialExpiresAt time.Time
}
func (Job) MarshalJSON() ([]byte,error) { return nil,errors.New("private audio job cannot be serialized") }
type JobResult struct {
 Success bool
 Credentials [2]Credentials
 Revoked bool
 RelayBootID string
}
func (JobResult) MarshalJSON() ([]byte,error) { return nil,errors.New("private audio result cannot be serialized") }
type Owner interface {
 AudioServerInstance(context.Context) (string,error)
 ClaimAudioJobs(context.Context,int) ([]Job,error)
 FinishAudioJob(context.Context,string,JobResult) (bool,error)
 SetAudioRelayReady(context.Context,bool,string) error
}

var opaqueRef = regexp.MustCompile(`^[A-Za-z0-9_-]{16,128}$`)
func ValidRef(value string) bool { return opaqueRef.MatchString(value) }
var ErrInvalidSignal = errors.New("invalid audio signal")
