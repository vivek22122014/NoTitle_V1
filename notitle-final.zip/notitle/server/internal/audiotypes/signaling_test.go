package audiotypes

import (
 "encoding/json"
 "net/netip"
 "strings"
 "testing"
)

var testRelays=[]netip.Addr{netip.MustParseAddr("203.0.113.5"),netip.MustParseAddr("2001:db8::5")}
const testCandidate="candidate:1 1 udp 16777215 203.0.113.5 49152 typ relay raddr 0.0.0.0 rport 0 generation 0 ufrag abcd network-cost 999"
func testSDP()string{return strings.Join([]string{
 "v=0","o=- 12345 2 IN IP4 127.0.0.1","s=-","t=0 0","a=group:BUNDLE 0","a=extmap-allow-mixed","a=msid-semantic: WMS synthetic-stream",
 "m=audio 9 UDP/TLS/RTP/SAVPF 111","c=IN IP4 0.0.0.0","a=rtcp:9 IN IP4 0.0.0.0","a=ice-ufrag:abcd","a=ice-pwd:abcdefghijklmnopqrstuv","a=ice-options:trickle",
 "a=fingerprint:sha-256 "+strings.TrimSuffix(strings.Repeat("AA:",32),":"),"a=setup:actpass","a=mid:0","a=extmap:1 urn:ietf:params:rtp-hdrext:ssrc-audio-level","a=sendrecv","a=rtcp-mux","a=rtcp-rsize",
 "a=rtpmap:111 opus/48000/2","a=fmtp:111 minptime=10;useinbandfec=1","a=rtcp-fb:111 transport-cc","a=msid:synthetic-stream synthetic-track","a=ssrc:123 cname:synthetic-cname","a="+testCandidate,"a=end-of-candidates","",
},"\r\n")}

func TestValidateAudioOnlyRelaySDP(t *testing.T){
 for _,sdp:=range []string{testSDP(),strings.ReplaceAll(testSDP(),"a="+testCandidate+"\r\n",""),strings.Replace(testSDP(),"a=extmap:1 ","a=extmap:1/sendonly ",1)+"a=rtcp-fb:111 nack\r\na=ssrc:123 mslabel:stream\r\na=ssrc:123 label:track\r\n"} {if err:=ValidateSDP(sdp,"offer",testRelays);err!=nil{t.Fatal(err)}}
 if err:=ValidateSDP(strings.ReplaceAll(testSDP(),"a=setup:actpass","a=setup:active"),"answer",testRelays);err!=nil{t.Fatal(err)}
 if err:=ValidateSDP(testSDP(),"offer",nil);err==nil{t.Fatal("embedded relay accepted without configured addresses")}
}
func TestEntireSDPRejectsAddressAndMediaLeaks(t *testing.T){
 cases:=map[string]string{
  "origin public IP":strings.Replace(testSDP(),"127.0.0.1","198.51.100.9",1),
  "connection host IP":strings.Replace(testSDP(),"c=IN IP4 0.0.0.0","c=IN IP4 10.0.0.9",1),
  "rtcp address":strings.Replace(testSDP(),"a=rtcp:9 IN IP4 0.0.0.0","a=rtcp:9 IN IP4 198.51.100.9",1),
  "embedded host candidate":strings.Replace(testSDP(),"typ relay","typ host",1),
  "embedded srflx":strings.Replace(testSDP(),"typ relay","typ srflx",1),
  "related address":strings.Replace(testSDP(),"raddr 0.0.0.0","raddr 198.51.100.9",1),
  "video":testSDP()+"m=video 9 UDP/TLS/RTP/SAVPF 96\r\n",
  "data channel":testSDP()+"m=application 9 UDP/DTLS/SCTP webrtc-datachannel\r\n",
  "second audio":testSDP()+"m=audio 9 UDP/TLS/RTP/SAVPF 111\r\n",
  "alternate codec":strings.Replace(testSDP(),"opus/48000/2","PCMU/8000",1),
  "extra codec":strings.Replace(testSDP(),"SAVPF 111","SAVPF 111 0",1),
  "arbitrary information":testSDP()+"i=private network metadata\r\n",
  "remote candidates":testSDP()+"a=remote-candidates:1 198.51.100.9 50000\r\n",
  "unknown extension":testSDP()+"a=x-private:198.51.100.9\r\n",
  "session URI":testSDP()+"u=https://malicious.example\r\n",
  "duplicate fingerprint":testSDP()+"a=fingerprint:sha-256 "+strings.TrimSuffix(strings.Repeat("AB:",32),":")+"\r\n",
  "wrong setup":strings.Replace(testSDP(),"setup:actpass","setup:active",1),
  "missing mux":strings.Replace(testSDP(),"a=rtcp-mux\r\n","",1),
  "different mid":strings.Replace(testSDP(),"a=mid:0","a=mid:1",1),
  "LF injection":testSDP()+"a=msid:valid\nx=y\r\n",
  "missing CRLF":strings.ReplaceAll(testSDP(),"\r\n","\n"),
  "excess candidates":testSDP()+strings.Repeat("a="+testCandidate+"\r\n",MaxCandidates),
 }
 for name,sdp:=range cases{t.Run(name,func(t *testing.T){if ValidateSDP(sdp,"offer",testRelays)==nil{t.Fatal("unsafe SDP accepted")}})}
}
func TestCandidateAllowsOnlyApprovedRelayAndPrivacyPlaceholders(t *testing.T){
 for _,candidate:=range []string{testCandidate,"candidate:2 1 UDP 16777215 2001:db8::5 50175 typ relay raddr :: rport 9"}{if ValidateCandidate(candidate,testRelays)!=nil{t.Fatal("valid relay rejected")}}
 for _,candidate:=range []string{
  strings.Replace(testCandidate,"203.0.113.5","198.51.100.6",1),strings.Replace(testCandidate,"49152","49151",1),strings.Replace(testCandidate,"49152","50176",1),
  strings.Replace(testCandidate,"typ relay","typ host",1),strings.Replace(testCandidate,"typ relay","typ srflx",1),strings.Replace(testCandidate,"1 1 udp","1 2 udp",1),
  strings.Replace(testCandidate,"udp","tcp",1),strings.Replace(testCandidate,"0.0.0.0","192.168.1.1",1),strings.Replace(testCandidate,"rport 0","rport 50000",1),
  testCandidate+" network-cost 1",testCandidate+" tcptype passive",testCandidate+" x-private 1",testCandidate+"\r\n",strings.Replace(testCandidate," rport 0","",1),
 }{if ValidateCandidate(candidate,testRelays)==nil{t.Fatalf("unsafe candidate accepted: %q",candidate)}}
 for _,ip:=range []string{"127.0.0.1","169.254.169.254","10.1.1.1","::1","fe80::1","ff02::1","::ffff:203.0.113.5","100.100.100.200","198.18.0.1","64:ff9b::a00:1","2002:a00:1::"}{candidate:=strings.Replace(testCandidate,"203.0.113.5",ip,1);if ValidateCandidate(candidate,[]netip.Addr{netip.MustParseAddr(ip)})==nil{t.Fatal("unsafe address accepted even when configured")}}
}
func TestPrivateAudioJobsCannotSerialize(t *testing.T){for _,value:=range []any{Job{CallRef:"private-call-ref"},JobResult{Credentials:[2]Credentials{{Credential:"secret"},{}}}}{if _,err:=json.Marshal(value);err==nil{t.Fatal("private record serialized")}}}
func FuzzSDPValidation(f *testing.F){f.Add(testSDP());f.Add("v=0\r\n");f.Fuzz(func(t *testing.T,value string){_ = ValidateSDP(value,"offer",testRelays)})}
func FuzzCandidateValidation(f *testing.F){f.Add(testCandidate);f.Fuzz(func(t *testing.T,value string){_ = ValidateCandidate(value,testRelays)})}
