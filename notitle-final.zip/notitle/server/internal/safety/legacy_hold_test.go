package safety

import (
    "context"
    "errors"
    "testing"
    "time"
    st "notitle/internal/safetytypes"
)
func TestLegacyHoldActionsCannotReachServiceRepository(t *testing.T){
    service,_,_,_,_:=fixture(t)
    for _,action:=range []string{"hold","release_hold"}{
        // The fixture embeds a nil Repository.Action implementation: calling it
        // would panic, so this checks rejection before any unjournaled write.
        _,err:=service.ApplyAction(context.Background(),AdminAction{AdminID:"operator",AdminGeneration:1,ExpectedVersion:1,CaseRef:"server-case-reference-123456",Action:action,Reason:"Authorized preservation review"})
        if !errors.Is(err,st.ErrInvalid){t.Fatal("legacy hold reached repository",action,err)}
    }
}
func TestLegacyHoldActionsCannotReachPostgresTransaction(t *testing.T){
    store:=&PostgresStore{}
    for _,action:=range []string{"hold","release_hold"}{if _,err:=store.Action(context.Background(),AdminAction{Action:action},time.Now());!errors.Is(err,st.ErrInvalid){t.Fatal("legacy hold reached database",action,err)}}
}
