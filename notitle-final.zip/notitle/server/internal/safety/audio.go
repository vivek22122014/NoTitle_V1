package safety

import (
	"time"
	at "notitle/internal/audiotypes"
	st "notitle/internal/safetytypes"
)

func validReportCall(call *st.CallMetadata,started,now time.Time)bool{
	if call==nil{return true}
	if !at.ValidRef(call.CallRef)||call.RequestedAt.IsZero()||call.RequestedAt.Before(started)||call.RequestedAt.After(now)||call.AcceptedAt==nil{return false}
	if call.AcceptedAt.Before(call.RequestedAt)||call.AcceptedAt.After(now){return false}
	return call.EndedAt==nil||(!call.EndedAt.Before(*call.AcceptedAt)&&!call.EndedAt.After(now))
}
