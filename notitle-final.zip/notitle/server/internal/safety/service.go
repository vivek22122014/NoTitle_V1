package safety

import (
 "context"
 "crypto/rand"
 "crypto/sha256"
 "encoding/base64"
 "encoding/hex"
 "encoding/json"
 "errors"
 "regexp"
 "sort"
 "strings"
 "sync"
 "time"

 "notitle/internal/identity"
 "notitle/internal/matchingauth"
 st "notitle/internal/safetytypes"
)

type Service struct { options Options; safetyWrites sync.Mutex }
var retentionPolicyPattern=regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$`)
func New(o Options)(*Service,error){
 if o.Now==nil{o.Now=time.Now}
 if o.Identity==nil||o.Owner==nil||o.Store==nil||o.Cipher==nil||o.Ready==nil||o.Retention<24*time.Hour||o.Retention>3650*24*time.Hour||!retentionPolicyPattern.MatchString(o.RetentionPolicyVersion){return nil,errors.New("safety requires identity, owner, repository, encryption and retention policy")}
 return &Service{options:o},nil
}
func(s *Service) guard(ctx context.Context,p identity.Principal)(st.Guard,error){
 fence,err:=s.options.Owner.AuthFence(ctx);if err!=nil{return st.Guard{},st.ErrUnavailable}
 current,err:=s.options.Identity.RefreshPrincipal(ctx,p,true);if err!=nil{if errors.Is(err,identity.ErrUnauthorized)||errors.Is(err,identity.ErrStale){return st.Guard{},st.ErrUnauthorized};return st.Guard{},st.ErrUnavailable}
 return st.Guard{Principal:current,Fence:fence},nil
}
func(s *Service) BeginReport(ctx context.Context,p identity.Principal,in st.BeginReportRequest)(st.DraftView,error){
 g,err:=s.guard(ctx,p);if err!=nil{return st.DraftView{},err};return s.options.Owner.BeginReport(ctx,g,in)
}
func(s *Service) SubmitReport(ctx context.Context,p identity.Principal,in st.SubmitReportRequest)(st.ReportReceipt,error){
 if err:=st.ValidateSubmitReport(in);err!=nil{return st.ReportReceipt{},err}
 g,err:=s.guard(ctx,p);if err!=nil{return st.ReportReceipt{},err}
 prepared,err:=s.options.Owner.PrepareReport(ctx,g,in);if err!=nil{return st.ReportReceipt{},err}
 if prepared.CompletedReceipt!=nil{return *prepared.CompletedReceipt,nil}
 record,err:=s.prepareRecord(prepared);if err!=nil{
  cleanup,cancel:=context.WithTimeout(context.WithoutCancel(ctx),2*time.Second)
  finishErr:=s.options.Owner.FinishReport(cleanup,g,st.ReportCompletion{Handle:in.Handle,SubmissionID:in.SubmissionID,Persisted:false});cancel()
  if finishErr!=nil{s.failClosed()};return st.ReportReceipt{},st.ErrUnavailable
 }
 receipt,err:=s.options.Store.Submit(ctx,g.Principal,record)
 if errors.Is(err,errCommitUncertain){s.failClosed();return st.ReportReceipt{},st.ErrUnavailable}
 cleanup,cancel:=context.WithTimeout(context.WithoutCancel(ctx),2*time.Second);defer cancel()
 completion:=st.ReportCompletion{Handle:in.Handle,SubmissionID:in.SubmissionID,CaseRef:receipt.CaseRef,Persisted:err==nil}
 if err==nil{completion.Receipt=&receipt}
 if prepared.Block!=nil{completion.BlockVersion=prepared.Block.Version;completion.DurableBlockPersisted=err==nil&&prepared.Block.Blocker.Kind==identity.KindAccount&&prepared.Block.Blocked.Kind==identity.KindAccount}
 finishErr:=s.options.Owner.FinishReport(cleanup,g,completion)
 if finishErr!=nil{s.failClosed()}
 // A receipt is emitted only after the repository committed. An uncertain
 // commit is retried with the same submission ID; it cannot create two cases.
 if err!=nil{return st.ReportReceipt{},publicStoreError(err)}
 if finishErr!=nil{return st.ReportReceipt{},st.ErrUnavailable};return receipt,nil
}
func publicStoreError(err error)error{if errors.Is(err,identity.ErrUnauthorized)||errors.Is(err,identity.ErrStale){return st.ErrUnauthorized};var typed *st.Error;if errors.As(err,&typed){return typed};return st.ErrUnavailable}
func(s *Service) failClosed(){if closer,ok:=s.options.Owner.(interface{FailClosed()});ok{closer.FailClosed()}}
func uuid() (string,error){b:=make([]byte,16);if _,err:=rand.Read(b);err!=nil{return "",err};b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;v:=hex.EncodeToString(b);return v[:8]+"-"+v[8:12]+"-"+v[12:16]+"-"+v[16:20]+"-"+v[20:],nil}
func opaque()(string,error){b:=make([]byte,32);if _,err:=rand.Read(b);err!=nil{return "",err};return base64.RawURLEncoding.EncodeToString(b),nil}
type evidenceMetadata struct{Version int `json:"v"`;CaseID string `json:"case"`;EvidenceID string `json:"evidence"`;Sequence uint64 `json:"sequence"`;Speaker string `json:"speaker"`;Kind string `json:"kind"`;Reason string `json:"reason"`;CollectedAt time.Time `json:"collected_at"`;RetentionUntil time.Time `json:"retention_until"`;RetentionPolicyVersion string `json:"retention_policy_version"`}
type evidencePlaintext struct{Text string `json:"text"`;SentAt *time.Time `json:"sent_at,omitempty"`}
// Case-private references are encrypted separately per case; no guest table or
// reusable guest correlation tag exists. The private administrator path alone
// can recover the current-process guest reference for an operator restriction.
type interactionMetadata struct{InteractionID string `json:"interaction_id"`;Epoch uint64 `json:"epoch"`;StartedAt time.Time `json:"started_at"`;EndedAt *time.Time `json:"ended_at,omitempty"`;SubjectKind identity.Kind `json:"subject_kind"`;SubjectID string `json:"subject_id"`;SubjectGeneration int64 `json:"subject_generation"`;Call *st.CallMetadata `json:"call,omitempty"`}
func(s *Service) prepareRecord(p st.PreparedReport)(ReportRecord,error){
 observedNow:=s.options.Now().UTC();now:=observedNow.Truncate(time.Microsecond);r:=ReportRecord{Category:p.Category,Severity:severity(p.Category,p.Statement),SubmittedAt:now,RetentionUntil:now.Add(s.options.Retention),RetentionPolicyVersion:s.options.RetentionPolicyVersion,Blocked:p.Block!=nil,Block:p.Block}
 if !validReportCall(p.Call,p.StartedAt,observedNow){return r,st.ErrInvalid}
 var err error;r.ID,err=uuid();if err!=nil{return r,err};r.CaseRef,err=opaque();if err!=nil{return r,err}
 r.DueAt=now.Add(24*time.Hour);if r.Severity=="urgent"{r.DueAt=now.Add(time.Hour)}
 r.SubmissionHash=sha256.Sum256([]byte(p.Handle+"\x00"+p.SubmissionID))
 // The digest commits selected server sequences, the statement and block intent.
 // It detects a reused submission ID carrying different report details.
 sequences:=make([]uint64,0,len(p.Evidence));for _,e:=range p.Evidence{sequences=append(sequences,e.ServerSequence)};sort.Slice(sequences,func(i,j int)bool{return sequences[i]<sequences[j]})
 canonical,_:=json.Marshal(struct{Category,Statement string;Sequences []uint64;Blocked bool}{p.Category,p.Statement,sequences,p.Block!=nil})
 // The unpersisted 256-bit draft secret also salts the request digest. A DB
 // reader cannot dictionary-test short user statements against a bare hash.
 r.RequestHash=sha256.Sum256(append([]byte("report-request-v1\x00"+p.Handle+"\x00"),canonical...))
 refs:=map[string]string{}
 for _,x:=range []struct{role string;subject st.Subject}{{"reporter",p.Reporter},{"subject",p.Subject}}{
  ref,e:=opaque();if e!=nil{return r,e};entry:=SubjectRecord{Ref:ref,Role:x.role}
  if x.subject.Kind==identity.KindAccount{entry.AccountID=x.subject.ID}else if x.subject.Kind==identity.KindGuest{entry.GuestTag=make([]byte,32);if _,e=rand.Read(entry.GuestTag);e!=nil{return r,e}}else{return r,st.ErrInvalid}
  refs[string(x.subject.Kind)+":"+x.subject.ID]=ref;r.Subjects=append(r.Subjects,entry)
 }
 add:=func(seq uint64,speaker,kind string,plain []byte)error{
  id,e:=uuid();if e!=nil{return e};meta:=evidenceMetadata{1,r.ID,id,seq,speaker,kind,"user_submitted_report",now,r.RetentionUntil,r.RetentionPolicyVersion};aad,e:=json.Marshal(meta);if e!=nil{return e};encrypted,e:=s.options.Cipher.Encrypt(plain,aad);if e!=nil{return e}
  r.Evidence=append(r.Evidence,EvidenceRecord{ID:id,CaseID:r.ID,SpeakerRef:speaker,Kind:kind,Sequence:seq,CollectedAt:now,RetentionUntil:r.RetentionUntil,RetentionPolicyVersion:r.RetentionPolicyVersion,Encrypted:encrypted,AAD:aad});return nil
 }
 for _,e:=range p.Evidence{speaker,ok:=refs[string(e.Sender.Kind)+":"+e.Sender.ID];if !ok||e.ServerSequence==0{return r,st.ErrInvalid};plain,_:=json.Marshal(evidencePlaintext{Text:e.Text,SentAt:&e.SentAt});if err=add(e.ServerSequence,speaker,"server_text",plain);err!=nil{return r,err}}
 reporter:=r.Subjects[0].Ref
 plain,_:=json.Marshal(evidencePlaintext{Text:p.Statement});if err=add(0,reporter,"user_statement",plain);err!=nil{return r,err}
 meta,_:=json.Marshal(interactionMetadata{InteractionID:p.InteractionID,Epoch:p.Epoch,StartedAt:p.StartedAt,EndedAt:p.EndedAt,SubjectKind:p.Subject.Kind,SubjectID:p.Subject.ID,SubjectGeneration:p.Subject.Generation,Call:p.Call});if err=add(0,reporter,"interaction_metadata",meta);err!=nil{return r,err};return r,nil
}
func severity(category,statement string)string{
 // Routing aids manual review only. There is no automatic restriction or
 // confidence claim, and the reporter-selected category is not the sole input.
 if category=="threats"||category=="suspected_underage_access"||category=="sexual_misconduct"{return "urgent"}
 lower:=strings.ToLower(statement);for _,word:=range []string{"kill","suicide","immediate danger","blackmail","underage","child abuse","home address","death threat","hurt myself"}{if strings.Contains(lower,word){return "urgent"}};return "normal"
}
func(s *Service) Safety(ctx context.Context,p identity.Principal)(matchingauth.SafetySnapshot,error){return s.options.Store.Safety(ctx,p,s.options.Now().UTC())}
func(s *Service) Block(ctx context.Context,p identity.Principal,in st.BlockRequest)(st.BlockView,error){
 if err:=st.ValidateBlock(in);err!=nil{return st.BlockView{},err}
 // A relationship handle is scoped to its authenticated owner. Hydrate a
 // cold durable relationship through the authoritative friend service before
 // taking a fresh safety fence; never accept a client-supplied subject ID.
 if in.FriendRef!="" {
  if s.options.Friends==nil{return st.BlockView{},st.ErrUnavailable}
  if _,err:=s.options.Friends.ListFriends(ctx,p);err!=nil{return st.BlockView{},st.ErrUnavailable}
 }
 g,err:=s.guard(ctx,p);if err!=nil{return st.BlockView{},err};m,err:=s.options.Owner.BlockPeer(ctx,g,in);if err!=nil{return st.BlockView{},err}
 durable:=m.Blocker.Kind==identity.KindAccount&&m.Blocked.Kind==identity.KindAccount
 if durable{guard:=g.Principal.Guard(s.options.Now().UTC(),false);err=s.options.Store.PutBlock(ctx,&guard,m)}
 if errors.Is(err,errCommitUncertain){s.failClosed();return st.BlockView{},st.ErrUnavailable}
 cleanup,cancel:=context.WithTimeout(context.WithoutCancel(ctx),2*time.Second);defer cancel()
 if m.LeaseID!=""{if e:=s.options.Owner.FinishBlockPromotion(cleanup,m.LeaseID,err==nil&&durable);e!=nil{s.failClosed();err=st.ErrUnavailable}}
 if err!=nil{return st.BlockView{},publicStoreError(err)};return st.BlockView{Ref:m.Ref,CreatedAt:m.CreatedAt,Durable:durable},nil
}
func(s *Service) ListBlocks(ctx context.Context,p identity.Principal)([]st.BlockView,error){
 g,err:=s.guard(ctx,p);if err!=nil{return nil,err};local,err:=s.options.Owner.ListLocalBlocks(ctx,g);if err!=nil{return nil,err}
 if g.Principal.Kind!=identity.KindAccount{return local,nil};durable,err:=s.options.Store.ListBlocks(ctx,g.Principal.Guard(s.options.Now().UTC(),false));if err!=nil{return nil,publicStoreError(err)}
 byRef:=map[string]int{};for i,b:=range durable{byRef[b.Ref]=i};for _,b:=range local{if i,ok:=byRef[b.Ref];ok{if durable[i].DisplayName==""{durable[i].DisplayName=b.DisplayName}}else{durable=append(durable,b)}};return durable,nil
}
func(s *Service) Unblock(ctx context.Context,p identity.Principal,ref string)error{
 if len(ref)<22||len(ref)>64{return st.ErrInvalid};g,err:=s.guard(ctx,p);if err!=nil{return err}
 m,err:=s.options.Owner.PrepareUnblock(ctx,g,ref)
 if errors.Is(err,st.ErrExpired)&&g.Principal.Kind==identity.KindAccount{
  durable,readErr:=s.options.Store.ReadBlock(ctx,g.Principal.Guard(s.options.Now().UTC(),false),ref)
  if readErr!=nil{return publicStoreError(readErr)}
  m,err=s.options.Owner.PrepareDurableUnblock(ctx,g,durable)
 }
 if err!=nil{return err}
 if g.Principal.Kind==identity.KindAccount{err=s.options.Store.DeleteBlock(ctx,g.Principal.Guard(s.options.Now().UTC(),false),ref)}
 if errors.Is(err,errCommitUncertain){s.failClosed();return st.ErrUnavailable}
 cleanup,cancel:=context.WithTimeout(context.WithoutCancel(ctx),2*time.Second);defer cancel()
 finishErr:=s.options.Owner.FinishUnblock(cleanup,g,m.LeaseID,err==nil);if finishErr!=nil{s.failClosed();return st.ErrUnavailable};return publicOrNil(err)
}
func publicOrNil(err error)error{if err==nil{return nil};return publicStoreError(err)}

// Run promotes guest-upgrade blocks outside the coordinator, with bounded
// batches and owner leases pinned until a definite persistence outcome. Failed
// persistence retains local blocks; ambiguous commits latch access closed.
func(s *Service) Run(ctx context.Context){
 ticker:=time.NewTicker(time.Second);defer ticker.Stop()
 for{select{case<-ctx.Done():return;case<-ticker.C:
  work,cancel:=context.WithTimeout(ctx,5*time.Second);if s.options.Ready(work)!=nil{cancel();continue}
  batch,err:=s.options.Owner.ClaimBlockPromotions(work,8)
  if err==nil{for _,m:=range batch{err=s.options.Store.PutBlock(work,nil,m);if errors.Is(err,errCommitUncertain){s.failClosed();continue};finish,stop:=context.WithTimeout(context.WithoutCancel(work),time.Second);if s.options.Owner.FinishBlockPromotion(finish,m.LeaseID,err==nil)!=nil{s.failClosed()};stop()}}
  s.safetyWrites.Lock()
  finalizations,finalizeErr:=s.options.Owner.ClaimHandoffFinalizations(work,1)
  if finalizeErr==nil{for _,m:=range finalizations{err=s.options.Store.FlushHandoff(work,m,s.options.Now().UTC());if errors.Is(err,errCommitUncertain){s.failClosed();continue};finish,stop:=context.WithTimeout(context.WithoutCancel(work),time.Second);if s.options.Owner.FinishHandoffFinalization(finish,m.LeaseID,err==nil)!=nil{s.failClosed()};stop()}}
  restrictions,claimErr:=s.options.Owner.ClaimRestrictionPromotions(work,8)
  if claimErr==nil{for _,m:=range restrictions{err=s.options.Store.PromoteRestriction(work,m,s.options.Now().UTC());if errors.Is(err,errCommitUncertain){s.failClosed();continue};finish,stop:=context.WithTimeout(context.WithoutCancel(work),time.Second);if s.options.Owner.FinishRestrictionPromotion(finish,m.LeaseID,err==nil)!=nil{s.failClosed()};stop()}}
  s.safetyWrites.Unlock()
  cancel()
 }}
}
