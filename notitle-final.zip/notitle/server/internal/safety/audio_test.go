package safety

import (
	"bytes"
	"context"
	"encoding/json"
	"testing"
	"time"
	st "notitle/internal/safetytypes"
)

func TestReportedCallTimingIsEncryptedAndAuditedCaseScoped(t *testing.T){
	s,owner,repo,p,input:=fixture(t)
	accepted:=s.options.Now().Add(-20*time.Second);ended:=s.options.Now().Add(-time.Second)
	owner.prepared.Call=&st.CallMetadata{CallRef:"opaque_call_reference_123",RequestedAt:accepted.Add(-time.Second),AcceptedAt:&accepted,EndedAt:&ended}
	if _,err:=s.SubmitReport(context.Background(),p,input);err!=nil{t.Fatal(err)}
	record:=repo.records[0]
	if len(record.Evidence)!=3{t.Fatal("call timing created an ordinary call-history record")}
	found:=false
	for _,e:=range record.Evidence{
		if bytes.Contains(e.AAD,[]byte(owner.prepared.Call.CallRef))||bytes.Contains(e.Encrypted.Ciphertext,[]byte(owner.prepared.Call.CallRef)){t.Fatal("call reference retained outside encrypted report metadata")}
		if e.Kind!="interaction_metadata"{continue}
		plain,err:=s.decryptEvidence(e);if err!=nil{t.Fatal(err)}
		var meta interactionMetadata;if json.Unmarshal(plain,&meta)!=nil||meta.Call==nil||meta.Call.CallRef!=owner.prepared.Call.CallRef{t.Fatal("server call timing omitted from submitted case")};found=true
	}
	if !found{t.Fatal("encrypted case metadata missing")}
	repo.stored=StoredCase{Summary:CaseSummary{Ref:record.CaseRef},Evidence:record.Evidence,Subjects:record.Subjects}
	detail,err:=s.CaseDetail(context.Background(),record.CaseRef);if err!=nil||detail.Call==nil||detail.Call.CallRef!=owner.prepared.Call.CallRef{t.Fatal("private case review lost call metadata",err)}
	wire,_:=json.Marshal(detail)
	for _,secret:=range []string{owner.prepared.Subject.ID,owner.prepared.Reporter.ID,owner.prepared.InteractionID}{if bytes.Contains(wire,[]byte(`"`+secret+`"`)){t.Fatal("case metadata exposed internal identity or interaction")}}
}

func TestReportedCallTimingRejectsImpossibleOrUnacceptedMetadata(t *testing.T){
	s,owner,_,_,_:=fixture(t);now:=s.options.Now();accepted:=now.Add(-time.Second)
	valid:=st.CallMetadata{CallRef:"opaque_call_reference_123",RequestedAt:now.Add(-2*time.Second),AcceptedAt:&accepted}
	for _,mutate:=range []func(*st.CallMetadata){
		func(c *st.CallMetadata){c.CallRef="invalid"},
		func(c *st.CallMetadata){c.AcceptedAt=nil},
		func(c *st.CallMetadata){c.RequestedAt=owner.prepared.StartedAt.Add(-time.Second)},
		func(c *st.CallMetadata){future:=now.Add(time.Second);c.EndedAt=&future},
		func(c *st.CallMetadata){past:=c.RequestedAt.Add(-time.Second);c.EndedAt=&past},
	}{call:=valid;mutate(&call);owner.prepared.Call=&call;if _,err:=s.prepareRecord(owner.prepared);err==nil{t.Fatal("impossible call timing accepted")}}
}
