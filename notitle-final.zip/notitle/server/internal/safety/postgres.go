package safety

import (
 "bytes"
 "context"
 "errors"
 "sort"
 "time"
 "github.com/jackc/pgx/v5"
 "github.com/jackc/pgx/v5/pgxpool"
 "notitle/internal/identity"
 "notitle/internal/matchingauth"
 "notitle/internal/realtime"
 st "notitle/internal/safetytypes"
)

type PostgresStore struct{pool *pgxpool.Pool}
var errCommitUncertain=errors.New("safety commit outcome requires reconciliation")
func NewPostgresStore(pool *pgxpool.Pool)*PostgresStore{return &PostgresStore{pool}}
var _ Repository=(*PostgresStore)(nil)
func transaction[T any](ctx context.Context,s *PostgresStore,fn func(context.Context,pgx.Tx)(T,error))(T,error){
 var zero T;if s==nil||s.pool==nil{return zero,st.ErrUnavailable}
 ctx,cancel:=context.WithTimeout(ctx,4*time.Second);defer cancel()
 tx,err:=s.pool.BeginTx(ctx,pgx.TxOptions{IsoLevel:pgx.ReadCommitted});if err!=nil{return zero,st.ErrUnavailable}
 defer func(){c,stop:=context.WithTimeout(context.Background(),time.Second);defer stop();_ = tx.Rollback(c)}()
 v,err:=fn(ctx,tx);if err!=nil{return zero,err};if tx.Commit(ctx)!=nil{return zero,errCommitUncertain};return v,nil
}
// Every operation uses one deterministic account lock order. The identity
// store locks the same account row before mutating credentials or deletion.
func lockAccounts(ctx context.Context,tx pgx.Tx,ids ...string)error{
 sort.Strings(ids);unique:=make([]string,0,len(ids));last:="";for _,id:=range ids{if id==""||id==last{continue};unique=append(unique,id);last=id};if len(unique)==0{return nil}
 rows,err:=tx.Query(ctx,`SELECT id::text FROM notitle.accounts WHERE id=ANY($1::uuid[]) ORDER BY id FOR UPDATE`,unique);if err!=nil{return st.ErrUnavailable};defer rows.Close();count:=0
 for rows.Next(){var id string;if rows.Scan(&id)!=nil{return st.ErrUnavailable};count++};if rows.Err()!=nil{return st.ErrUnavailable};if count!=len(unique){return st.ErrUnauthorized};return nil
}
func guardSession(ctx context.Context,tx pgx.Tx,g identity.Guard)error{
 var valid bool;err:=tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.accounts a JOIN notitle.sessions s ON s.account_id=a.id WHERE a.id=$1 AND a.status='active' AND a.generation=$2 AND s.id=$3 AND s.token_hash=$4 AND s.account_generation=a.generation AND s.revoked_at IS NULL AND s.created_at<=$5 AND s.absolute_expires_at>$5 AND s.last_seen_at>$5-interval '7 days')`,g.AccountID,g.AccountGeneration,g.SessionID,g.TokenHash[:],g.Now).Scan(&valid)
 if err!=nil{return st.ErrUnavailable};if !valid{return st.ErrUnauthorized};return nil
}
func bumpSafety(ctx context.Context,tx pgx.Tx,id string,now time.Time)error{
 _,err:=tx.Exec(ctx,`INSERT INTO notitle.account_safety_state(account_id,updated_at) VALUES($1,$2) ON CONFLICT(account_id) DO UPDATE SET version=notitle.account_safety_state.version+1,updated_at=EXCLUDED.updated_at`,id,now);if err!=nil{return st.ErrUnavailable};return nil
}
func putBlock(ctx context.Context,tx pgx.Tx,m st.BlockMutation)error{
 if m.Blocker.Kind!=identity.KindAccount||m.Blocked.Kind!=identity.KindAccount||m.Blocker.ID==m.Blocked.ID{return st.ErrInvalid}
 var eligible bool;err:=tx.QueryRow(ctx,`SELECT count(*)=2 FROM notitle.accounts WHERE id=ANY($1::uuid[]) AND status='active'`,[]string{m.Blocker.ID,m.Blocked.ID}).Scan(&eligible)
 if err!=nil{return st.ErrUnavailable};if !eligible{return st.ErrUnauthorized}
 var count int;var exists bool
 err=tx.QueryRow(ctx,`SELECT count(*),COALESCE(bool_or(blocked_id=$2),false) FROM notitle.blocks WHERE blocker_id=$1`,m.Blocker.ID,m.Blocked.ID).Scan(&count,&exists)
 if err!=nil{return st.ErrUnavailable};if count>=st.MaxBlocksPerIdentity&&!exists{return st.ErrCapacity}
 id,err:=uuid();if err!=nil{return st.ErrUnavailable}
 // A newly authorized local relation can replace its own opaque handle after
 // guest promotion. No public endpoint ever addresses the target account ID.
 _,err=tx.Exec(ctx,`INSERT INTO notitle.blocks(id,block_ref,blocker_id,blocked_id,created_at) VALUES($1,$2,$3,$4,$5) ON CONFLICT(blocker_id,blocked_id) DO UPDATE SET block_ref=EXCLUDED.block_ref`,id,m.Ref,m.Blocker.ID,m.Blocked.ID,m.CreatedAt)
 if err!=nil{return st.ErrUnavailable};if bumpSafety(ctx,tx,m.Blocker.ID,m.CreatedAt)!=nil||bumpSafety(ctx,tx,m.Blocked.ID,m.CreatedAt)!=nil{return st.ErrUnavailable};return nil
}
func(s *PostgresStore) PutBlock(ctx context.Context,g *identity.Guard,m st.BlockMutation)error{
 _,err:=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){
  if err:=lockAccounts(ctx,tx,m.Blocker.ID,m.Blocked.ID);err!=nil{return false,err}
  if g!=nil{if g.AccountID!=m.Blocker.ID{return false,st.ErrUnauthorized};if err:=guardSession(ctx,tx,*g);err!=nil{return false,err}}
  return true,putBlock(ctx,tx,m)
 });return err
}
func(s *PostgresStore) Submit(ctx context.Context,p identity.Principal,r ReportRecord)(st.ReportReceipt,error){
 return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(st.ReportReceipt,error){
  var ids []string;for _,subject:=range r.Subjects{if subject.AccountID!=""{ids=append(ids,subject.AccountID)}}
  if err:=lockAccounts(ctx,tx,ids...);err!=nil{return st.ReportReceipt{},err}
  if p.Kind==identity.KindAccount{if err:=guardSession(ctx,tx,p.Guard(r.SubmittedAt,false));err!=nil{return st.ReportReceipt{},err}}else if p.Kind!=identity.KindGuest{return st.ReportReceipt{},st.ErrUnauthorized}
  // Concurrent submissions serialize on the cryptographic idempotency key.
  // The unique constraint is the final duplicate barrier.
  inserted,err:=tx.Exec(ctx,`INSERT INTO notitle.reports(id,case_ref,submission_hash,request_hash,category,severity,submitted_at,due_at,retention_until,retention_policy_version,blocked) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) ON CONFLICT(submission_hash) DO NOTHING`,r.ID,r.CaseRef,r.SubmissionHash[:],r.RequestHash[:],r.Category,r.Severity,r.SubmittedAt,r.DueAt,r.RetentionUntil,r.RetentionPolicyVersion,r.Blocked)
  if err!=nil{return st.ReportReceipt{},st.ErrUnavailable}
  var existingID string;var hash []byte;var receipt st.ReportReceipt
  err=tx.QueryRow(ctx,`SELECT id::text,case_ref,request_hash,submitted_at,blocked FROM notitle.reports WHERE submission_hash=$1 FOR UPDATE`,r.SubmissionHash[:]).Scan(&existingID,&receipt.CaseRef,&hash,&receipt.SubmittedAt,&receipt.Blocked)
  if err!=nil{return st.ReportReceipt{},st.ErrUnavailable};if !bytes.Equal(hash,r.RequestHash[:]){return st.ReportReceipt{},st.ErrConflict};if inserted.RowsAffected()==0{return receipt,nil}
  for _,subject:=range r.Subjects{var account any;if subject.AccountID!=""{account=subject.AccountID};_,err=tx.Exec(ctx,`INSERT INTO notitle.case_subject_refs(case_id,subject_ref,role,account_id,guest_case_tag) VALUES($1,$2,$3,$4,$5)`,r.ID,subject.Ref,subject.Role,account,subject.GuestTag);if err!=nil{return st.ReportReceipt{},st.ErrUnavailable}}
  for _,e:=range r.Evidence{_,err=tx.Exec(ctx,`INSERT INTO notitle.report_evidence(id,case_id,server_sequence,speaker_ref,kind,collection_reason,collected_at,retention_until,key_id,nonce,ciphertext,aad) VALUES($1,$2,$3,$4,$5,'user_submitted_report',$6,$7,$8,$9,$10,$11)`,e.ID,r.ID,int64(e.Sequence),e.SpeakerRef,e.Kind,e.CollectedAt,e.RetentionUntil,e.Encrypted.KeyID,e.Encrypted.Nonce,e.Encrypted.Ciphertext,e.AAD);if err!=nil{return st.ReportReceipt{},st.ErrUnavailable}}
  if r.Block!=nil&&r.Block.Blocker.Kind==identity.KindAccount&&r.Block.Blocked.Kind==identity.KindAccount{if err:=putBlock(ctx,tx,*r.Block);err!=nil{return st.ReportReceipt{},err}}
  return receipt,nil
 })
}
func(s *PostgresStore) ListBlocks(ctx context.Context,g identity.Guard)([]st.BlockView,error){
 return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)([]st.BlockView,error){
  if err:=lockAccounts(ctx,tx,g.AccountID);err!=nil{return nil,err};if err:=guardSession(ctx,tx,g);err!=nil{return nil,err}
  rows,err:=tx.Query(ctx,`SELECT b.block_ref,p.display_name,b.created_at FROM notitle.blocks b JOIN notitle.profiles p ON p.account_id=b.blocked_id WHERE b.blocker_id=$1 ORDER BY b.created_at DESC,b.id LIMIT $2`,g.AccountID,st.MaxBlocksPerIdentity);if err!=nil{return nil,st.ErrUnavailable};defer rows.Close()
  out:=[]st.BlockView{};for rows.Next(){b:=st.BlockView{Durable:true};if rows.Scan(&b.Ref,&b.DisplayName,&b.CreatedAt)!=nil{return nil,st.ErrUnavailable};out=append(out,b)};if rows.Err()!=nil{return nil,st.ErrUnavailable};return out,nil
 })
}
func(s *PostgresStore) DeleteBlock(ctx context.Context,g identity.Guard,ref string)error{
 _,err:=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){
  // Read the other account before locking, then recheck/delete under the
  // deterministic pair lock; missing or someone else's handles reveal nothing.
  var target string;err:=tx.QueryRow(ctx,`SELECT blocked_id::text FROM notitle.blocks WHERE blocker_id=$1 AND block_ref=$2`,g.AccountID,ref).Scan(&target)
  if err!=nil&&!errors.Is(err,pgx.ErrNoRows){return false,st.ErrUnavailable}
  if err:=lockAccounts(ctx,tx,g.AccountID,target);err!=nil{return false,err};if err:=guardSession(ctx,tx,g);err!=nil{return false,err}
  tag,err:=tx.Exec(ctx,`DELETE FROM notitle.blocks WHERE blocker_id=$1 AND block_ref=$2`,g.AccountID,ref);if err!=nil{return false,st.ErrUnavailable}
  if tag.RowsAffected()>0{if bumpSafety(ctx,tx,g.AccountID,g.Now)!=nil||bumpSafety(ctx,tx,target,g.Now)!=nil{return false,st.ErrUnavailable}};return true,nil
 });return err
}
func(s *PostgresStore) Safety(ctx context.Context,p identity.Principal,now time.Time)(matchingauth.SafetySnapshot,error){
 if p.Kind==identity.KindGuest{return matchingauth.SafetySnapshot{Version:1},nil}
 if p.Kind!=identity.KindAccount{return matchingauth.SafetySnapshot{},st.ErrUnauthorized}
 return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(matchingauth.SafetySnapshot,error){
  g:=p.Guard(now,false);if err:=lockAccounts(ctx,tx,g.AccountID);err!=nil{return matchingauth.SafetySnapshot{},err};if err:=guardSession(ctx,tx,g);err!=nil{return matchingauth.SafetySnapshot{},err}
  out:=matchingauth.SafetySnapshot{Version:1};var until *time.Time
  err:=tx.QueryRow(ctx,`SELECT version,restricted_until FROM notitle.account_safety_state WHERE account_id=$1`,g.AccountID).Scan(&out.Version,&until)
  if err!=nil&&!errors.Is(err,pgx.ErrNoRows){return out,st.ErrUnavailable};out.Restricted=until!=nil&&now.Before(*until)
  var pending bool;err=tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.pending_safety_handoffs WHERE account_id=$1)`,g.AccountID).Scan(&pending);if err!=nil{return out,st.ErrUnavailable};if pending{return out,identity.ErrBusy}
  rows,err:=tx.Query(ctx,`SELECT blocked_id::text FROM notitle.blocks WHERE blocker_id=$1 UNION SELECT blocker_id::text FROM notitle.blocks WHERE blocked_id=$1 LIMIT $2`,g.AccountID,realtime.MaxBlockedIdentities+1);if err!=nil{return out,st.ErrUnavailable};defer rows.Close()
  for rows.Next(){var id string;if rows.Scan(&id)!=nil{return out,st.ErrUnavailable};out.BlockedIdentities=append(out.BlockedIdentities,id)};if rows.Err()!=nil||len(out.BlockedIdentities)>realtime.MaxBlockedIdentities{return out,st.ErrUnavailable};return out,nil
 })
}

func(s *PostgresStore) ReadBlock(ctx context.Context,g identity.Guard,ref string)(st.BlockMutation,error){
 return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(st.BlockMutation,error){
  var m st.BlockMutation
  if err:=lockAccounts(ctx,tx,g.AccountID);err!=nil{return m,err};if err:=guardSession(ctx,tx,g);err!=nil{return m,err}
  m.Blocker=st.Subject{Kind:identity.KindAccount,ID:g.AccountID,Generation:g.AccountGeneration};m.Blocked.Kind=identity.KindAccount
  err:=tx.QueryRow(ctx,`SELECT b.block_ref,b.blocked_id::text,a.generation,b.created_at FROM notitle.blocks b JOIN notitle.accounts a ON a.id=b.blocked_id WHERE b.blocker_id=$1 AND b.block_ref=$2`,g.AccountID,ref).Scan(&m.Ref,&m.Blocked.ID,&m.Blocked.Generation,&m.CreatedAt)
  if errors.Is(err,pgx.ErrNoRows){return m,st.ErrExpired};if err!=nil{return m,st.ErrUnavailable};m.Version=1;return m,nil
 })
}
func(s *PostgresStore) PromoteRestriction(ctx context.Context,m st.RestrictionMutation,now time.Time)error{
 if m.Subject.Kind!=identity.KindAccount||m.Subject.ID==""||m.LeaseID==""{return st.ErrInvalid}
 if m.DecidedAt.IsZero(){return st.ErrInvalid}
 _,err:=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){
  if err:=lockAccounts(ctx,tx,m.Subject.ID);err!=nil{return false,err}
  var until any;reason:="";if now.Before(m.Until){until=m.Until;reason="Interaction access is restricted following a safety review. Use the grievance route to appeal."}
  _,err:=tx.Exec(ctx,`INSERT INTO notitle.account_safety_state(account_id,restricted_until,restriction_updated_at,restriction_reason,updated_at) VALUES($1,$2,$3,$4,$5) ON CONFLICT(account_id) DO UPDATE SET version=notitle.account_safety_state.version+1,restricted_until=EXCLUDED.restricted_until,restriction_updated_at=EXCLUDED.restriction_updated_at,restriction_reason=EXCLUDED.restriction_reason,updated_at=EXCLUDED.updated_at WHERE notitle.account_safety_state.restriction_updated_at IS NULL OR notitle.account_safety_state.restriction_updated_at<EXCLUDED.restriction_updated_at`,m.Subject.ID,until,m.DecidedAt,reason,now)
  if err!=nil{return false,st.ErrUnavailable};return true,nil
 });return err
}

func(s *PostgresStore) FlushHandoff(ctx context.Context,m st.HandoffFinalization,now time.Time)error{
 if m.Subject.Kind!=identity.KindAccount||m.Subject.ID==""||m.LeaseID==""||len(m.Blocks)>st.MaxLocalBlocks{return st.ErrInvalid}
 _,err:=transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(bool,error){
  ids:=[]string{m.Subject.ID};for _,block:=range m.Blocks{if block.Blocker.Kind!=identity.KindAccount||block.Blocked.Kind!=identity.KindAccount{return false,st.ErrInvalid};ids=append(ids,block.Blocker.ID,block.Blocked.ID)}
  if err:=lockAccounts(ctx,tx,ids...);err!=nil{return false,err}
  var pending bool;err:=tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.pending_safety_handoffs WHERE account_id=$1)`,m.Subject.ID).Scan(&pending);if err!=nil{return false,st.ErrUnavailable}
  // A repeat after a successful commit is harmless. The owner finalizer is the
  // only source of this server-private snapshot; arbitrary accounts cannot
  // request that a durable registration fence be cleared.
  if !pending{return true,nil}
  if err:=flushHandoffBlocks(ctx,tx,m.Blocks,now);err!=nil{return false,err}
  if !m.RestrictionDecidedAt.IsZero(){
   var until any;reason:="";if now.Before(m.RestrictionUntil){until=m.RestrictionUntil;reason="Interaction access is restricted following a safety review. Use the grievance route to appeal."}
   _,err=tx.Exec(ctx,`INSERT INTO notitle.account_safety_state(account_id,restricted_until,restriction_updated_at,restriction_reason,updated_at) VALUES($1,$2,$3,$4,$5) ON CONFLICT(account_id) DO UPDATE SET version=notitle.account_safety_state.version+1,restricted_until=EXCLUDED.restricted_until,restriction_updated_at=EXCLUDED.restriction_updated_at,restriction_reason=EXCLUDED.restriction_reason,updated_at=EXCLUDED.updated_at WHERE notitle.account_safety_state.restriction_updated_at IS NULL OR notitle.account_safety_state.restriction_updated_at<EXCLUDED.restriction_updated_at`,m.Subject.ID,until,m.RestrictionDecidedAt,reason,now);if err!=nil{return false,st.ErrUnavailable}
  }
  if err:=bumpSafety(ctx,tx,m.Subject.ID,now);err!=nil{return false,err}
  _,err=tx.Exec(ctx,`DELETE FROM notitle.pending_safety_handoffs WHERE account_id=$1`,m.Subject.ID);if err!=nil{return false,st.ErrUnavailable};return true,nil
 });return err
}

// Existing guest edges were already authorized and admitted by the owner. A
// large inbound degree cannot strand an unrelated registering participant.
// Bulk writes stay within the owner's global bound and transaction deadline;
// the ordinary public block-create quota is not reapplied to accepted edges.
func flushHandoffBlocks(ctx context.Context,tx pgx.Tx,blocks []st.BlockMutation,now time.Time)error{
 if len(blocks)==0{return nil}
 ids:=[]string{};refs:=[]string{};blockers:=[]string{};blocked:=[]string{};created:=[]time.Time{};accounts:=map[string]bool{};pairs:=map[string]bool{}
 for _,block:=range blocks{
  pair:=block.Blocker.ID+":"+block.Blocked.ID;if pairs[pair]{continue};pairs[pair]=true
  id,err:=uuid();if err!=nil{return st.ErrUnavailable};ids=append(ids,id);refs=append(refs,block.Ref);blockers=append(blockers,block.Blocker.ID);blocked=append(blocked,block.Blocked.ID);created=append(created,block.CreatedAt);accounts[block.Blocker.ID]=true;accounts[block.Blocked.ID]=true
 }
 _,err:=tx.Exec(ctx,`INSERT INTO notitle.blocks(id,block_ref,blocker_id,blocked_id,created_at) SELECT * FROM unnest($1::uuid[],$2::text[],$3::uuid[],$4::uuid[],$5::timestamptz[]) ON CONFLICT(blocker_id,blocked_id) DO UPDATE SET block_ref=EXCLUDED.block_ref`,ids,refs,blockers,blocked,created)
 if err!=nil{return st.ErrUnavailable};touched:=make([]string,0,len(accounts));for id:=range accounts{touched=append(touched,id)};sort.Strings(touched)
 _,err=tx.Exec(ctx,`INSERT INTO notitle.account_safety_state(account_id,updated_at) SELECT unnest($1::uuid[]),$2::timestamptz ON CONFLICT(account_id) DO UPDATE SET version=notitle.account_safety_state.version+1,updated_at=EXCLUDED.updated_at`,touched,now);if err!=nil{return st.ErrUnavailable};return nil
}
