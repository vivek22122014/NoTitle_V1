package safety

import (
 "context"
 "crypto/rand"
 "errors"
 "os"
 "strings"
 "sync"
 "testing"
 "time"
 "notitle/internal/config"
 "notitle/internal/database"
 "notitle/internal/identity"
 "notitle/internal/identitypg"
 st "notitle/internal/safetytypes"
)
func integrationStore(t *testing.T)(context.Context,*PostgresStore,*identitypg.Store){
 t.Helper();raw:=strings.TrimSpace(os.Getenv("TEST_DATABASE_URL"));path:=strings.TrimSpace(os.Getenv("TEST_DATABASE_URL_FILE"))
 if raw!=""&&path!=""{t.Fatal("use one integration database secret source")};if path!=""{data,err:=os.ReadFile(path);if err!=nil{t.Fatal("cannot read database secret")};raw=strings.TrimSpace(string(data))}
 if raw==""{if os.Getenv("REQUIRE_DATABASE_INTEGRATION")=="1"{t.Fatal("required database integration missing")};t.Skip("run scripts/db-check.sh with disposable database")}
 ctx,cancel:=context.WithTimeout(context.Background(),40*time.Second);t.Cleanup(cancel)
 pool,err:=database.Open(ctx,config.DatabaseConfig{URL:raw,MaxConns:6,MaxConnLifetime:time.Minute,MaxConnIdleTime:time.Minute,HealthCheckPeriod:time.Minute,ConnectTimeout:5*time.Second});if err!=nil{t.Fatal(err)};t.Cleanup(pool.Close)
 if err:=pool.Ready(ctx);err!=nil{t.Fatal("migration-five database with restricted runtime required",err)};return ctx,NewPostgresStore(pool.Raw()),identitypg.New(pool.Raw())
}
func integrationAccount(t *testing.T,ctx context.Context,store *identitypg.Store)identity.Principal{
 return integrationAccountWithHandoff(t,ctx,store,false)
}
func integrationAccountWithHandoff(t *testing.T,ctx context.Context,store *identitypg.Store,handoff bool)identity.Principal{
 t.Helper();id,err:=uuid();if err!=nil{t.Fatal(err)};sid,err:=uuid();if err!=nil{t.Fatal(err)};var token,recovery identity.Verifier;if _,err=rand.Read(token[:]);err!=nil{t.Fatal(err)};if _,err=rand.Read(recovery[:]);err!=nil{t.Fatal(err)}
 now:=time.Now().UTC().Truncate(time.Microsecond);record:=identity.CreateAccountRecord{Account:identity.Account{ID:id,Username:"safe_"+strings.ReplaceAll(id,"-","")[:16],Profile:identity.Profile{Version:1,DisplayName:"Safety Test",Gender:identity.GenderOther,Topic:"general_talk"}},PasswordHash:"$argon2id$v=19$m=65536,t=3,p=1$synthetic-store-test$synthetic-store-test",RecoveryHash:recovery,Consent:identity.Consent{AdultConfirmed:true,Policies:identity.PolicyVersions{Terms:"draft-1",Privacy:"draft-1",Community:"draft-1"}},CreatedAt:now,Session:identity.SessionRecord{ID:sid,TokenHash:token,CreatedAt:now,LastSeenAt:now,AuthenticatedAt:now,AbsoluteExpiresAt:now.Add(identity.SessionAbsoluteTTL)}}
 record.GuestHandoff=handoff
 account,err:=store.CreateAccount(ctx,record);if err!=nil{t.Fatal(err)};return identity.Principal{Kind:identity.KindAccount,AccountSession:account,TokenHash:token}
}
func integrationPrepared(t *testing.T,a,b identity.Principal)(*Service,st.PreparedReport){
 t.Helper();s,o,_,_,_:=fixture(t);now:=time.Now().UTC().Truncate(time.Microsecond);s.options.Now=func()time.Time{return now}
 p:=o.prepared;p.Handle,_=opaque();p.SubmissionID,_=opaque();p.Reporter=st.Subject{Kind:identity.KindAccount,ID:a.AccountSession.Account.ID,Generation:a.AccountSession.Account.Generation};p.Subject=st.Subject{Kind:identity.KindAccount,ID:b.AccountSession.Account.ID,Generation:b.AccountSession.Account.Generation};p.Evidence[0].Sender=p.Subject;p.Evidence[0].SentAt=now.Add(-time.Second);p.StartedAt=now.Add(-time.Minute)
 ref,_:=opaque();p.Block=&st.BlockMutation{Ref:ref,Blocker:p.Reporter,Blocked:p.Subject,CreatedAt:now,Version:1};return s,p
}
func TestIntegrationReportBlockAtomicAndConcurrentRetry(t *testing.T){
 ctx,store,identities:=integrationStore(t);a:=integrationAccount(t,ctx,identities);b:=integrationAccount(t,ctx,identities);s,p:=integrationPrepared(t,a,b)
 first,err:=s.prepareRecord(p);if err!=nil{t.Fatal(err)};second,err:=s.prepareRecord(p);if err!=nil{t.Fatal(err)}
 var wg sync.WaitGroup;receipts:=make(chan st.ReportReceipt,2);errs:=make(chan error,2)
 for _,record:=range []ReportRecord{first,second}{wg.Add(1);go func(r ReportRecord){defer wg.Done();v,e:=store.Submit(ctx,a,r);receipts<-v;errs<-e}(record)};wg.Wait();close(receipts);close(errs)
 for e:=range errs{if e!=nil{t.Fatal("concurrent idempotent submit failed",e)}};ref:="";for r:=range receipts{if ref!=""&&ref!=r.CaseRef{t.Fatal("retry created duplicate cases")};ref=r.CaseRef}
 var reports,evidence,blocks int
 if err:=store.pool.QueryRow(ctx,`SELECT count(*) FROM notitle.reports WHERE submission_hash=$1`,first.SubmissionHash[:]).Scan(&reports);err!=nil{t.Fatal(err)}
 if err:=store.pool.QueryRow(ctx,`SELECT count(*) FROM notitle.report_evidence e JOIN notitle.reports r ON r.id=e.case_id WHERE r.submission_hash=$1`,first.SubmissionHash[:]).Scan(&evidence);err!=nil{t.Fatal(err)}
 if err:=store.pool.QueryRow(ctx,`SELECT count(*) FROM notitle.blocks WHERE blocker_id=$1 AND blocked_id=$2`,p.Reporter.ID,p.Subject.ID).Scan(&blocks);err!=nil{t.Fatal(err)}
 if reports!=1||evidence!=3||blocks!=1{t.Fatal("atomic case/evidence/block or duplicate barrier failed",reports,evidence,blocks)}
 s.options.Store=store;if _,err:=s.CaseDetail(ctx,ref);err!=nil{t.Fatal("database timestamp/AAD roundtrip failed",err)}
 changed:=second;changed.RequestHash[0]^=1;if _,err:=store.Submit(ctx,a,changed);!errors.Is(err,st.ErrConflict){t.Fatal("submission ID reused for different request")}
}
func TestIntegrationInvalidBlockRollsBackEntireReport(t *testing.T){
 ctx,store,identities:=integrationStore(t);a:=integrationAccount(t,ctx,identities);b:=integrationAccount(t,ctx,identities);s,p:=integrationPrepared(t,a,b);p.Block.Ref="invalid"
 record,err:=s.prepareRecord(p);if err!=nil{t.Fatal(err)};if _,err:=store.Submit(ctx,a,record);err==nil{t.Fatal("invalid block accepted")}
 var count int;if store.pool.QueryRow(ctx,`SELECT count(*) FROM notitle.reports WHERE submission_hash=$1`,record.SubmissionHash[:]).Scan(&count)!=nil||count!=0{t.Fatal("report committed after block failure")}
}
func TestIntegrationEitherBlockDirectionAndRevokedPrincipal(t *testing.T){
 ctx,store,identities:=integrationStore(t);a:=integrationAccount(t,ctx,identities);b:=integrationAccount(t,ctx,identities);_,p:=integrationPrepared(t,a,b);g:=a.Guard(time.Now().UTC(),false)
 if err:=store.PutBlock(ctx,&g,*p.Block);err!=nil{t.Fatal(err)}
 snapshot,err:=store.Safety(ctx,b,time.Now().UTC());if err!=nil||len(snapshot.BlockedIdentities)!=1||snapshot.BlockedIdentities[0]!=p.Reporter.ID{t.Fatal("incoming block missing",err)}
 if err:=identities.RevokeSession(ctx,g);err!=nil{t.Fatal(err)}
 if err:=store.DeleteBlock(ctx,g,p.Block.Ref);!errors.Is(err,st.ErrUnauthorized){t.Fatal("revoked account removed block",err)}
}

func TestIntegrationGuestUpgradeFenceSurvivesUntilAtomicSafetyFlush(t *testing.T){
 ctx,store,identities:=integrationStore(t);a:=integrationAccountWithHandoff(t,ctx,identities,true);b:=integrationAccount(t,ctx,identities);_,p:=integrationPrepared(t,a,b)
 // A fresh repository sees the durable fence; no owner memory is needed to
 // reject interaction access after a process restart.
 restored:=NewPostgresStore(store.pool);if _,err:=restored.Safety(ctx,a,time.Now().UTC());!errors.Is(err,identity.ErrBusy){t.Fatal("pending upgrade became unrestricted",err)}
 now:=time.Now().UTC().Truncate(time.Microsecond);m:=st.HandoffFinalization{LeaseID:"server-owned-finalization",Subject:p.Reporter,Blocks:[]st.BlockMutation{*p.Block},RestrictionUntil:now.Add(time.Hour),RestrictionDecidedAt:now,Version:1}
 if err:=store.FlushHandoff(ctx,m,now);err!=nil{t.Fatal(err)}
 snapshot,err:=restored.Safety(ctx,a,time.Now().UTC());if err!=nil||!snapshot.Restricted||len(snapshot.BlockedIdentities)!=1{t.Fatal("flush lost restriction or block",err)}
 var pending int;if err:=store.pool.QueryRow(ctx,`SELECT count(*) FROM notitle.pending_safety_handoffs WHERE account_id=$1`,p.Reporter.ID).Scan(&pending);err!=nil||pending!=0{t.Fatal("completed fence retained",err)}
}
func TestIntegrationFailedFlushKeepsRegistrationFence(t *testing.T){
 ctx,store,identities:=integrationStore(t);a:=integrationAccountWithHandoff(t,ctx,identities,true);b:=integrationAccount(t,ctx,identities);_,p:=integrationPrepared(t,a,b);p.Block.Ref="invalid"
 m:=st.HandoffFinalization{LeaseID:"server-owned-finalization",Subject:p.Reporter,Blocks:[]st.BlockMutation{*p.Block},Version:1}
 if err:=store.FlushHandoff(ctx,m,time.Now().UTC());err==nil{t.Fatal("invalid safety snapshot accepted")}
 if _,err:=store.Safety(ctx,a,time.Now().UTC());!errors.Is(err,identity.ErrBusy){t.Fatal("failed flush cleared fence",err)}
}
func TestIntegrationOldRestrictionPromotionCannotUndoNewerLift(t *testing.T){
 ctx,store,identities:=integrationStore(t);a:=integrationAccount(t,ctx,identities);now:=time.Now().UTC().Truncate(time.Microsecond)
 _,err:=store.pool.Exec(ctx,`INSERT INTO notitle.account_safety_state(account_id,restricted_until,restriction_updated_at,updated_at) VALUES($1,NULL,$2,$2)`,a.AccountSession.Account.ID,now);if err!=nil{t.Fatal(err)}
 m:=st.RestrictionMutation{LeaseID:"older-guest-decision",Subject:st.Subject{Kind:identity.KindAccount,ID:a.AccountSession.Account.ID,Generation:1},Until:now.Add(time.Hour),DecidedAt:now.Add(-time.Minute)}
 if err:=store.PromoteRestriction(ctx,m,now.Add(time.Second));err!=nil{t.Fatal(err)}
 snapshot,err:=store.Safety(ctx,a,time.Now().UTC());if err!=nil||snapshot.Restricted{t.Fatal("late promotion resurrected lifted restriction",err)}
}
