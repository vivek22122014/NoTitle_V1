package safety

import (
 "context"
 "time"
 "notitle/internal/identity"
 "notitle/internal/friendtypes"
 "notitle/internal/matchingauth"
 st "notitle/internal/safetytypes"
)

type Identity interface { RefreshPrincipal(context.Context,identity.Principal,bool)(identity.Principal,error) }
type FriendHydrator interface { ListFriends(context.Context,identity.Principal)([]friendtypes.View,error) }
type Options struct {
 Friends FriendHydrator
 Identity Identity
 Owner st.Owner
 Store Repository
 Cipher *Keyring
 Now func()time.Time
 Retention time.Duration
 RetentionPolicyVersion string
 Ready func(context.Context)error
}
type SubjectRecord struct { Ref string; Role string; AccountID string; GuestTag []byte }
type EvidenceRecord struct { ID,CaseID,SpeakerRef,Kind,RetentionPolicyVersion string; Sequence uint64; CollectedAt,RetentionUntil time.Time; Encrypted Encrypted; AAD []byte }
type ReportRecord struct {
 ID,CaseRef,Category,Severity,RetentionPolicyVersion string
 SubmissionHash,RequestHash [32]byte
 SubmittedAt,DueAt,RetentionUntil time.Time
 Blocked bool
 Subjects []SubjectRecord
 Evidence []EvidenceRecord
 Block *st.BlockMutation
}
type Repository interface {
 Submit(context.Context,identity.Principal,ReportRecord)(st.ReportReceipt,error)
 PutBlock(context.Context,*identity.Guard,st.BlockMutation)error
 ListBlocks(context.Context,identity.Guard)([]st.BlockView,error)
 ReadBlock(context.Context,identity.Guard,string)(st.BlockMutation,error)
 DeleteBlock(context.Context,identity.Guard,string)error
 Safety(context.Context,identity.Principal,time.Time)(matchingauth.SafetySnapshot,error)
 Cases(context.Context,int)([]CaseSummary,error)
 Case(context.Context,string)(StoredCase,error)
 Action(context.Context,AdminAction,time.Time)(ActionResult,error)
 PromoteRestriction(context.Context,st.RestrictionMutation,time.Time)error
 FlushHandoff(context.Context,st.HandoffFinalization,time.Time)error
}
type CaseSummary struct {
 Ref string `json:"ref"`
 Category string `json:"category"`
 Severity string `json:"severity"`
 State string `json:"state"`
 Version int64 `json:"version"`
 SubmittedAt time.Time `json:"submitted_at"`
 DueAt time.Time `json:"due_at"`
 RetentionUntil time.Time `json:"retention_until"`
 RetentionPolicyVersion string `json:"retention_policy_version"`
}
type CaseEvidence struct {
 Sequence uint64 `json:"server_sequence"`
 Speaker string `json:"speaker"`
 Kind string `json:"kind"`
 Text string `json:"text"`
 SentAt *time.Time `json:"sent_at,omitempty"`
}
type ActionView struct {
 Action string `json:"action"`
 Reason string `json:"reason"`
 At time.Time `json:"at"`
 Until *time.Time `json:"until,omitempty"`
}
type CaseDetail struct {
 CaseSummary
 Call *st.CallMetadata `json:"call,omitempty"`
 Evidence []CaseEvidence `json:"evidence"`
 Actions []ActionView `json:"actions"`
 SubjectKind identity.Kind `json:"subject_kind"`
 LegalHold bool `json:"legal_hold"`
}
type StoredCase struct { Summary CaseSummary; Evidence []EvidenceRecord; Subjects []SubjectRecord; Actions []ActionView; LegalHold bool }
type AdminAction struct {
 AdminID string `json:"-"`
 AdminGeneration int64 `json:"-"`
 AdminSessionHash [32]byte `json:"-"`
 ResolvedSubject st.Subject `json:"-"`
 CaseRef string `json:"case_ref"`
 Action string `json:"action"`
 Reason string `json:"reason"`
 ExpectedVersion int64 `json:"expected_version"`
 Until *time.Time `json:"until,omitempty"`
}
type ActionResult struct {
 CaseRef string `json:"case_ref"`
 Version int64 `json:"version"`
 State string `json:"state"`
 Subject st.Subject `json:"-"`
}
