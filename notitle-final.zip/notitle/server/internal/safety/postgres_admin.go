package safety

import (
 "context"
 "errors"
 "time"
 "github.com/jackc/pgx/v5"
 "notitle/internal/identity"
 st "notitle/internal/safetytypes"
)

type scanner interface{Scan(...any)error}
func scanCase(row scanner)(CaseSummary,error){var v CaseSummary;err:=row.Scan(&v.Ref,&v.Category,&v.Severity,&v.State,&v.Version,&v.SubmittedAt,&v.DueAt,&v.RetentionUntil,&v.RetentionPolicyVersion);return v,err}
const caseColumns=`case_ref,category,severity,state,version,submitted_at,due_at,retention_until,retention_policy_version`
func(s *PostgresStore) Cases(ctx context.Context,limit int)([]CaseSummary,error){
 if limit<1||limit>100{return nil,st.ErrInvalid};ctx,cancel:=context.WithTimeout(ctx,3*time.Second);defer cancel()
 rows,err:=s.pool.Query(ctx,`SELECT `+caseColumns+` FROM notitle.reports ORDER BY (state='open') DESC,(severity='urgent') DESC,due_at,id LIMIT $1`,limit);if err!=nil{return nil,st.ErrUnavailable};defer rows.Close()
 out:=[]CaseSummary{};for rows.Next(){v,err:=scanCase(rows);if err!=nil{return nil,st.ErrUnavailable};out=append(out,v)};if rows.Err()!=nil{return nil,st.ErrUnavailable};return out,nil
}
func(s *PostgresStore) Case(ctx context.Context,ref string)(StoredCase,error){
 return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(StoredCase,error){
  var result StoredCase;var id string;err:=tx.QueryRow(ctx,`SELECT id::text FROM notitle.reports WHERE case_ref=$1`,ref).Scan(&id);if errors.Is(err,pgx.ErrNoRows){return result,st.ErrExpired};if err!=nil{return result,st.ErrUnavailable}
  result.Summary,err=scanCase(tx.QueryRow(ctx,`SELECT `+caseColumns+` FROM notitle.reports WHERE id=$1`,id));if err!=nil{return result,st.ErrUnavailable}
  rows,err:=tx.Query(ctx,`SELECT subject_ref,role,COALESCE(account_id::text,''),guest_case_tag FROM notitle.case_subject_refs WHERE case_id=$1 ORDER BY role`,id);if err!=nil{return result,st.ErrUnavailable}
  for rows.Next(){var subject SubjectRecord;if rows.Scan(&subject.Ref,&subject.Role,&subject.AccountID,&subject.GuestTag)!=nil{rows.Close();return result,st.ErrUnavailable};result.Subjects=append(result.Subjects,subject)};err=rows.Err();rows.Close();if err!=nil{return result,st.ErrUnavailable}
  rows,err=tx.Query(ctx,`SELECT id::text,server_sequence,speaker_ref,kind,collected_at,retention_until,key_id,nonce,ciphertext,aad FROM notitle.report_evidence WHERE case_id=$1 ORDER BY kind,server_sequence,id LIMIT 33`,id);if err!=nil{return result,st.ErrUnavailable}
  for rows.Next(){e:=EvidenceRecord{CaseID:id,RetentionPolicyVersion:result.Summary.RetentionPolicyVersion};var sequence int64;if rows.Scan(&e.ID,&sequence,&e.SpeakerRef,&e.Kind,&e.CollectedAt,&e.RetentionUntil,&e.Encrypted.KeyID,&e.Encrypted.Nonce,&e.Encrypted.Ciphertext,&e.AAD)!=nil{rows.Close();return result,st.ErrUnavailable};e.Sequence=uint64(sequence);result.Evidence=append(result.Evidence,e)};err=rows.Err();rows.Close();if err!=nil||len(result.Evidence)>32{return result,st.ErrUnavailable}
  rows,err=tx.Query(ctx,`SELECT action,reason,created_at,until_at FROM notitle.moderation_actions WHERE case_id=$1 ORDER BY created_at DESC,id DESC LIMIT 100`,id);if err!=nil{return result,st.ErrUnavailable};result.Actions=[]ActionView{}
  for rows.Next(){var a ActionView;if rows.Scan(&a.Action,&a.Reason,&a.At,&a.Until)!=nil{rows.Close();return result,st.ErrUnavailable};result.Actions=append(result.Actions,a)};err=rows.Err();rows.Close();if err!=nil{return result,st.ErrUnavailable}
  err=tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.legal_holds WHERE case_id=$1 AND released_by_action IS NULL) OR EXISTS(SELECT 1 FROM notitle.privacy_holds h WHERE h.released_at IS NULL AND ((h.scope_kind='report' AND h.scope_ref=$1::uuid::text) OR (h.scope_kind='account' AND EXISTS(SELECT 1 FROM notitle.case_subject_refs c WHERE c.case_id=$1 AND c.account_id::text=h.scope_ref))))`,id).Scan(&result.LegalHold);if err!=nil{return result,st.ErrUnavailable};return result,nil
 })
}
func adminGuard(ctx context.Context,tx pgx.Tx,a AdminAction,now time.Time)error{
 var roles []string;var generation int64;var disabled bool
 err:=tx.QueryRow(ctx,`SELECT roles,generation,disabled FROM notitle.admin_users WHERE id=$1 FOR UPDATE`,a.AdminID).Scan(&roles,&generation,&disabled)
 if errors.Is(err,pgx.ErrNoRows){return st.ErrUnauthorized};if err!=nil{return st.ErrUnavailable};if disabled||generation!=a.AdminGeneration{return st.ErrUnauthorized}
 allowed:=false;for _,role:=range roles{if role=="owner"||role=="moderator"||role=="grievance_officer"{allowed=true}}
 if !allowed{return st.ErrUnauthorized};var valid bool
 err=tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.admin_sessions WHERE token_hash=$1 AND admin_id=$2 AND admin_generation=$3 AND created_at<=$4 AND absolute_expires_at>$4 AND last_seen_at>$4-interval '15 minutes')`,a.AdminSessionHash[:],a.AdminID,generation,now).Scan(&valid)
 if err!=nil{return st.ErrUnavailable};if !valid{return st.ErrUnauthorized};return nil
}
func(s *PostgresStore) Action(ctx context.Context,a AdminAction,now time.Time)(ActionResult,error){
 if a.Action=="hold"||a.Action=="release_hold"{return ActionResult{},st.ErrInvalid}
 return transaction(ctx,s,func(ctx context.Context,tx pgx.Tx)(ActionResult,error){
  var out ActionResult;if err:=adminGuard(ctx,tx,a,now);err!=nil{return out,err}
  var id,target string;err:=tx.QueryRow(ctx,`SELECT r.id::text,COALESCE(c.account_id::text,'') FROM notitle.reports r JOIN notitle.case_subject_refs c ON c.case_id=r.id AND c.role='subject' WHERE r.case_ref=$1`,a.CaseRef).Scan(&id,&target)
  if errors.Is(err,pgx.ErrNoRows){return out,st.ErrExpired};if err!=nil{return out,st.ErrUnavailable}
  if target==""&&a.ResolvedSubject.Kind==identity.KindAccount{target=a.ResolvedSubject.ID}
  if target!=""{if err:=lockAccounts(ctx,tx,target);err!=nil{return out,err};var generation int64;err=tx.QueryRow(ctx,`SELECT generation FROM notitle.accounts WHERE id=$1`,target).Scan(&generation);if err!=nil{return out,st.ErrUnavailable};out.Subject=st.Subject{Kind:identity.KindAccount,ID:target,Generation:generation}}
  var version int64;var state string;err=tx.QueryRow(ctx,`SELECT version,state FROM notitle.reports WHERE id=$1 FOR UPDATE`,id).Scan(&version,&state);if err!=nil{return out,st.ErrUnavailable};if version!=a.ExpectedVersion{return out,st.ErrConflict}
  switch a.Action{case "resolve":state="resolved";case "reopen":state="open";case "suspend","unsuspend","note":default:return out,st.ErrInvalid}
  actionID,err:=uuid();if err!=nil{return out,st.ErrUnavailable};version++
  _,err=tx.Exec(ctx,`INSERT INTO notitle.moderation_actions(id,case_id,admin_id,action,reason,created_at,until_at,case_version) VALUES($1,$2,$3,$4,$5,$6,$7,$8)`,actionID,id,a.AdminID,a.Action,a.Reason,now,a.Until,version);if err!=nil{return out,st.ErrUnavailable}
  if target!=""&&(a.Action=="suspend"||a.Action=="unsuspend"){
   var until any;reason:="";if a.Action=="suspend"{if a.Until==nil||!a.Until.After(now){return out,st.ErrInvalid};until=*a.Until;reason="Interaction access is restricted following a safety review. Use the grievance route to appeal."}
   _,err=tx.Exec(ctx,`INSERT INTO notitle.account_safety_state(account_id,restricted_until,restriction_updated_at,restriction_reason,updated_at) VALUES($1,$2,$4,$3,$4) ON CONFLICT(account_id) DO UPDATE SET version=notitle.account_safety_state.version+1,restricted_until=EXCLUDED.restricted_until,restriction_updated_at=GREATEST(notitle.account_safety_state.restriction_updated_at,EXCLUDED.restriction_updated_at),restriction_reason=EXCLUDED.restriction_reason,updated_at=EXCLUDED.updated_at`,target,until,reason,now);if err!=nil{return out,st.ErrUnavailable}
  }
  _,err=tx.Exec(ctx,`UPDATE notitle.reports SET version=$2,state=$3 WHERE id=$1`,id,version,state);if err!=nil{return out,st.ErrUnavailable}
  auditID,err:=uuid();if err!=nil{return out,st.ErrUnavailable};_,err=tx.Exec(ctx,`INSERT INTO notitle.admin_audit(id,admin_id,action,subject_ref,reason,result,created_at) VALUES($1,$2,$3,$4,$5,'success',$6)`,auditID,a.AdminID,"case."+a.Action,a.CaseRef,a.Reason,now);if err!=nil{return out,st.ErrUnavailable}
  out.CaseRef=a.CaseRef;out.Version=version;out.State=state;return out,nil
 })
}
