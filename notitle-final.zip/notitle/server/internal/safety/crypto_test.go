package safety

import (
 "bytes"
 "encoding/base64"
 "os"
 "path/filepath"
 "testing"
)
func TestEvidenceEncryptionBindsMetadataAndRotatedReadKeys(t *testing.T){
 old:=testCipher(t);e,err:=old.Encrypt([]byte("selected server evidence"),[]byte("case-one:sequence-seven:speaker"));if err!=nil{t.Fatal(err)}
 if _,err:=old.Decrypt(e,[]byte("case-two:sequence-seven:speaker"));err==nil{t.Fatal("cross-case ciphertext accepted")}
 keys:=map[string]string{"test-1":base64.StdEncoding.EncodeToString(bytes.Repeat([]byte{7},32)),"test-2":base64.StdEncoding.EncodeToString(bytes.Repeat([]byte{8},32))}
 rotated,err:=NewKeyring("test-2",keys);if err!=nil{t.Fatal(err)};plain,err:=rotated.Decrypt(e,[]byte("case-one:sequence-seven:speaker"));if err!=nil||string(plain)!="selected server evidence"{t.Fatal("rotation lost historical evidence",err)}
 next,err:=rotated.Encrypt([]byte("new case"),[]byte("new metadata"));if err!=nil||next.KeyID!="test-2"{t.Fatal("active key not used")}
 e.Ciphertext[0]^=1;if _,err:=rotated.Decrypt(e,[]byte("case-one:sequence-seven:speaker"));err==nil{t.Fatal("modified ciphertext accepted")}
}
func TestEvidenceKeyringRequiresPrivateSecretAndAES256(t *testing.T){
 if _,err:=NewKeyring("bad",map[string]string{"bad":base64.StdEncoding.EncodeToString(make([]byte,16))});err==nil{t.Fatal("short key accepted")}
 path:=filepath.Join(t.TempDir(),"keyring");content:=`{"active_key_id":"one","keys":{"one":"`+base64.StdEncoding.EncodeToString(make([]byte,32))+`"}}`
 if err:=os.WriteFile(path,[]byte(content),0600);err!=nil{t.Fatal(err)};if _,err:=LoadKeyring(path);err!=nil{t.Fatal(err)}
 if err:=os.Chmod(path,0644);err!=nil{t.Fatal(err)};if _,err:=LoadKeyring(path);err==nil{t.Fatal("world-readable keyring accepted")}
}
