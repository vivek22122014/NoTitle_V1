package safety

import (
 "bytes"
 "context"
 "encoding/json"
 "errors"
 "strings"
 "time"
 "unicode/utf8"
 "notitle/internal/identity"
 st "notitle/internal/safetytypes"
)

// These methods are wired only into the authenticated private operations
// listener. The public API deliberately has no evidence or case lookup route.
func(s *Service) CaseList(ctx context.Context,limit int)([]CaseSummary,error){if limit<1||limit>100{limit=50};return s.options.Store.Cases(ctx,limit)}
func(s *Service) decryptEvidence(e EvidenceRecord)([]byte,error){
 expected,err:=json.Marshal(evidenceMetadata{1,e.CaseID,e.ID,e.Sequence,e.SpeakerRef,e.Kind,"user_submitted_report",e.CollectedAt,e.RetentionUntil,e.RetentionPolicyVersion})
 if err!=nil||!bytes.Equal(expected,e.AAD){return nil,st.ErrUnavailable};plain,err:=s.options.Cipher.Decrypt(e.Encrypted,expected);if err!=nil{return nil,st.ErrUnavailable};return plain,nil
}
func(s *Service) CaseDetail(ctx context.Context,ref string)(CaseDetail,error){
 if len(ref)<22||len(ref)>64{return CaseDetail{},st.ErrInvalid};stored,err:=s.options.Store.Case(ctx,ref);if err!=nil{return CaseDetail{},publicStoreError(err)}
 result:=CaseDetail{CaseSummary:stored.Summary,Evidence:[]CaseEvidence{},Actions:stored.Actions,LegalHold:stored.LegalHold,SubjectKind:identity.KindGuest}
 for _,subject:=range stored.Subjects{if subject.Role=="subject"&&subject.AccountID!=""{result.SubjectKind=identity.KindAccount}}
 for _,e:=range stored.Evidence{
  plain,err:=s.decryptEvidence(e);if err!=nil{return CaseDetail{},err}
  if e.Kind=="interaction_metadata"{
   var meta interactionMetadata
   if json.Unmarshal(plain,&meta)!=nil||!validReportCall(meta.Call,meta.StartedAt,s.options.Now().UTC()){return CaseDetail{},st.ErrUnavailable}
   // Never expose the encrypted subject/identity mapping in a case DTO.
   result.Call=meta.Call;continue
  }
  var content evidencePlaintext;if json.Unmarshal(plain,&content)!=nil{return CaseDetail{},st.ErrUnavailable};result.Evidence=append(result.Evidence,CaseEvidence{Sequence:e.Sequence,Speaker:e.SpeakerRef,Kind:e.Kind,Text:content.Text,SentAt:content.SentAt})
 }
 return result,nil
}
func(s *Service) ApplyAction(ctx context.Context,a AdminAction)(ActionResult,error){
 // Holds use the independently durable privacy journal and authorized review workflow.
 if a.Action=="hold"||a.Action=="release_hold"{return ActionResult{},st.ErrInvalid}
 // Minimum moderation has few operators. One bounded DB transaction at a time
 // keeps committed restrictions and their owner publications in the same order
 // across different cases, including guest-upgrade promotion writes.
 s.safetyWrites.Lock();defer s.safetyWrites.Unlock()
 now:=s.options.Now().UTC().Truncate(time.Microsecond)
 if a.AdminID==""||a.AdminGeneration<1||a.ExpectedVersion<1||len(a.CaseRef)<22||len(a.CaseRef)>64||strings.TrimSpace(a.Reason)==""||st.ValidateStatement(a.Reason)!=nil||utf8.RuneCountInString(a.Reason)>1000||len(a.Reason)>4096{return ActionResult{},st.ErrInvalid}
 switch a.Action{case "suspend":if a.Until==nil{until:=now.Add(24*time.Hour);a.Until=&until};if !a.Until.After(now)||a.Until.After(now.Add(366*24*time.Hour)){return ActionResult{},st.ErrInvalid}
 case "unsuspend","resolve","note","reopen":if a.Until!=nil{return ActionResult{},st.ErrInvalid}
 default:return ActionResult{},st.ErrInvalid}
 // Read/decrypt only the private case reference needed for a guest action.
 // The transaction independently authorizes the admin and expected version.
 var guestSubject st.Subject
 if a.Action=="suspend"||a.Action=="unsuspend"{
  stored,err:=s.options.Store.Case(ctx,a.CaseRef);if err!=nil{return ActionResult{},publicStoreError(err)}
  for _,e:=range stored.Evidence{if e.Kind!="interaction_metadata"{continue};plain,err:=s.decryptEvidence(e);if err!=nil{return ActionResult{},err};var meta interactionMetadata;if json.Unmarshal(plain,&meta)!=nil{return ActionResult{},st.ErrUnavailable};if meta.SubjectKind==identity.KindGuest{guestSubject=st.Subject{Kind:meta.SubjectKind,ID:meta.SubjectID,Generation:meta.SubjectGeneration}}}
 }
 if guestSubject.ID!=""{resolved,err:=s.options.Owner.ResolveSafetySubject(ctx,guestSubject);if err!=nil{return ActionResult{},publicStoreError(err)};a.ResolvedSubject=resolved}
 result,err:=s.options.Store.Action(ctx,a,now);if err!=nil{if errors.Is(err,errCommitUncertain){s.failClosed()};return ActionResult{},publicStoreError(err)}
 if a.Action=="suspend"||a.Action=="unsuspend"{
  target:=result.Subject;if target.ID==""{target=guestSubject}
  if target.ID!=""{deadline:=time.Time{};if a.Action=="suspend"{deadline=*a.Until};publish,cancel:=context.WithTimeout(context.WithoutCancel(ctx),2*time.Second);err=s.options.Owner.ApplyTimedRestriction(publish,target,deadline);cancel();if err!=nil{s.failClosed();return ActionResult{},st.ErrUnavailable}}
 }
 return result,nil
}
