package safety

import (
 "context"
 "time"
 "github.com/jackc/pgx/v5/pgxpool"
 "notitle/internal/identity"
 "notitle/internal/matchingauth"
)

// AuthorizationSource is always wired into realtime, even if the text/report
// feature flag is disabled. Feature flags must never bypass existing durable
// blocks, restrictions or pending registration fences. It needs no read key.
type AuthorizationSource struct{store *PostgresStore}
func NewAuthorizationSource(pool *pgxpool.Pool)*AuthorizationSource{return &AuthorizationSource{NewPostgresStore(pool)}}
func(s *AuthorizationSource)Safety(ctx context.Context,p identity.Principal)(matchingauth.SafetySnapshot,error){return s.store.Safety(ctx,p,time.Now().UTC())}
