package safety

import (
 "bytes"
 "context"
 "encoding/base64"
 "errors"
 "testing"
 "time"
 "notitle/internal/identity"
 st "notitle/internal/safetytypes"
)

type testIdentity struct{err error}
func(i testIdentity)RefreshPrincipal(_ context.Context,p identity.Principal,_ bool)(identity.Principal,error){return p,i.err}
type testOwner struct{st.Owner;prepared st.PreparedReport;completion st.ReportCompletion;failed bool;prepareCalls int}
func(o *testOwner)AuthFence(context.Context)(uint64,error){return 4,nil}
func(o *testOwner)PrepareReport(_ context.Context,_ st.Guard,_ st.SubmitReportRequest)(st.PreparedReport,error){o.prepareCalls++;return o.prepared,nil}
func(o *testOwner)FinishReport(_ context.Context,_ st.Guard,c st.ReportCompletion)error{o.completion=c;return nil}
func(o *testOwner)FailClosed(){o.failed=true}
type testRepository struct{Repository;records []ReportRecord;err error;receipt st.ReportReceipt;stored StoredCase}
func(r *testRepository)Submit(_ context.Context,_ identity.Principal,v ReportRecord)(st.ReportReceipt,error){r.records=append(r.records,v);if r.err!=nil{return st.ReportReceipt{},r.err};if r.receipt.CaseRef==""{r.receipt=st.ReportReceipt{CaseRef:v.CaseRef,SubmittedAt:v.SubmittedAt,Blocked:v.Blocked}};return r.receipt,nil}
func(r *testRepository)Case(context.Context,string)(StoredCase,error){return r.stored,nil}
func testCipher(t *testing.T)*Keyring{t.Helper();key:=base64.StdEncoding.EncodeToString(bytes.Repeat([]byte{7},32));c,err:=NewKeyring("test-1",map[string]string{"test-1":key});if err!=nil{t.Fatal(err)};return c}
func fixture(t *testing.T)(*Service,*testOwner,*testRepository,identity.Principal,st.SubmitReportRequest){
 t.Helper();now:=time.Date(2026,10,9,12,0,0,123456000,time.UTC)
 reporter:=st.Subject{Kind:identity.KindGuest,ID:"reporter-guest",Generation:1};subject:=st.Subject{Kind:identity.KindGuest,ID:"subject-guest",Generation:1}
 owner:=&testOwner{prepared:st.PreparedReport{Handle:"abcdefghijklmnopqrstuvwxyz0123456789_ABCDEFG",SubmissionID:"submission-id-000001",Reporter:reporter,Subject:subject,InteractionID:"interaction",Epoch:7,StartedAt:now.Add(-time.Minute),Category:"harassment",Statement:"The selected message is my allegation context.",Evidence:[]st.Evidence{{ServerSequence:12,Sender:subject,Text:"<script>synthetic-evidence</script>",SentAt:now.Add(-time.Second)}}}}
 repo:=&testRepository{};service,err:=New(Options{Identity:testIdentity{},Owner:owner,Store:repo,Cipher:testCipher(t),Now:func()time.Time{return now},Retention:30*24*time.Hour,RetentionPolicyVersion:"test-policy-v1",Ready:func(context.Context)error{return nil}});if err!=nil{t.Fatal(err)}
 p:=identity.Principal{Kind:identity.KindGuest,Guest:identity.Guest{ID:reporter.ID,Generation:1}}
 request:=st.SubmitReportRequest{Handle:owner.prepared.Handle,SubmissionID:owner.prepared.SubmissionID,Category:owner.prepared.Category,Statement:owner.prepared.Statement,SelectedSequences:[]uint64{12}}
 return service,owner,repo,p,request
}
func TestSubmittedEvidenceEncryptedAndSeparatelyAttributed(t *testing.T){
 s,owner,repo,p,in:=fixture(t);receipt,err:=s.SubmitReport(context.Background(),p,in);if err!=nil||receipt.CaseRef==""||!owner.completion.Persisted{t.Fatal("missing durable acknowledgement",err)}
 r:=repo.records[0];if len(r.Evidence)!=3{t.Fatal("only selected text, separate statement and metadata should persist")};if len(r.Subjects)!=2||bytes.Equal(r.Subjects[0].GuestTag,r.Subjects[1].GuestTag){t.Fatal("guest references are not case scoped")}
 found:=false;for _,e:=range r.Evidence{if bytes.Contains(e.Encrypted.Ciphertext,[]byte("synthetic-evidence"))||bytes.Contains(e.AAD,[]byte("subject-guest")){t.Fatal("plain content or guest identity leaked outside ciphertext")};plain,err:=s.decryptEvidence(e);if err!=nil{t.Fatal(err)};if e.Kind=="server_text"{found=true;if e.Sequence!=12||e.SpeakerRef!=r.Subjects[1].Ref||!bytes.Contains(plain,[]byte("synthetic-evidence")){t.Fatal("attribution lost")}}};if !found{t.Fatal("selected evidence absent")}
 repo.stored=StoredCase{Summary:CaseSummary{Ref:r.CaseRef},Evidence:r.Evidence,Subjects:r.Subjects}
 detail,err:=s.CaseDetail(context.Background(),r.CaseRef);if err!=nil||len(detail.Evidence)!=2{t.Fatal("private mapping exposed or statement omitted",err)}
}
func TestStorageFailureNeverAcknowledgedAndRetryKeepsIdempotencyKey(t *testing.T){
 s,owner,repo,p,in:=fixture(t);repo.err=st.ErrUnavailable
 if receipt,err:=s.SubmitReport(context.Background(),p,in);err==nil||receipt.CaseRef!=""||owner.completion.Persisted{t.Fatal("failed storage acknowledged")}
 repo.err=nil;receipt,err:=s.SubmitReport(context.Background(),p,in);if err!=nil||receipt.CaseRef==""{t.Fatal(err)}
 if repo.records[0].SubmissionHash!=repo.records[1].SubmissionHash||repo.records[0].RequestHash!=repo.records[1].RequestHash{t.Fatal("retry keys changed")}
 if repo.records[0].ID==repo.records[1].ID{t.Fatal("fixture must exercise repository idempotency across fresh attempts")}
}
func TestUncertainCommitLatchesOwnerWithoutReleasingLease(t *testing.T){
 s,owner,repo,p,in:=fixture(t);repo.err=errCommitUncertain
 if _,err:=s.SubmitReport(context.Background(),p,in);err==nil||!owner.failed{t.Fatal("uncertain commit did not fail closed")};if owner.completion.Handle!=""{t.Fatal("uncertain lease released")}
}
func TestServerMetadataTamperingCannotChangeEvidenceAttribution(t *testing.T){
 s,_,repo,p,in:=fixture(t);if _,err:=s.SubmitReport(context.Background(),p,in);err!=nil{t.Fatal(err)}
 e:=repo.records[0].Evidence[0];e.Sequence++
 if _,err:=s.decryptEvidence(e);err==nil{t.Fatal("row attribution altered without authenticated metadata")}
}
func TestRevokedIdentityAndInvalidTranscriptSelectionsStopBeforeActor(t *testing.T){
 s,owner,_,p,in:=fixture(t);s.options.Identity=testIdentity{identity.ErrUnauthorized}
 if _,err:=s.SubmitReport(context.Background(),p,in);!errors.Is(err,st.ErrUnauthorized)||owner.prepareCalls!=0{t.Fatal("revoked principal submitted")}
 s.options.Identity=testIdentity{};in.SelectedSequences=[]uint64{12,12}
 if _,err:=s.SubmitReport(context.Background(),p,in);!errors.Is(err,st.ErrInvalid)||owner.prepareCalls!=0{t.Fatal("duplicate sequence accepted")}
}
func TestFreeTextIndicatorsEscalateWithoutAutomaticRestriction(t *testing.T){
 if severity("other","They threatened to kill me")!="urgent"{t.Fatal("category alone controlled urgency")}
 if severity("spam","ordinary unrelated text")!="normal"{t.Fatal("ordinary case escalated")}
}
func TestCompletedReceiptRetryDoesNotPersistOrReapplyBlock(t *testing.T){
 s,owner,repo,p,in:=fixture(t);receipt:=st.ReportReceipt{CaseRef:"already-committed-case-reference-000001",SubmittedAt:s.options.Now(),Blocked:true};owner.prepared.CompletedReceipt=&receipt;owner.prepared.Evidence=nil;owner.prepared.Block=nil
 got,err:=s.SubmitReport(context.Background(),p,in);if err!=nil||got!=receipt||len(repo.records)!=0{t.Fatal("committed retry wrote again or lost original receipt",err)}
}
