// Package safety persists only deliberately submitted safety material. Ordinary
// conversation text never reaches this package's repository.
package safety

import (
    "crypto/aes"
    "crypto/cipher"
    "crypto/rand"
    "encoding/base64"
    "encoding/json"
    "errors"
    "io"
    "os"
    "regexp"
)

var errCipher = errors.New("evidence encryption unavailable")
var keyIDPattern = regexp.MustCompile(`^[A-Za-z0-9_-]{1,48}$`)

// Keyring holds an active write key and older read keys. It is loaded only from
// a mounted secret file. Retired keys must remain recoverable while their
// evidence or encrypted backups remain under approved retention.
type Keyring struct { active string; keys map[string]cipher.AEAD }
type Encrypted struct { KeyID string; Nonce []byte; Ciphertext []byte }
type keyFile struct { Active string `json:"active_key_id"`; Keys map[string]string `json:"keys"` }

func LoadKeyring(path string) (*Keyring,error) {
    f,err:=os.Open(path); if err!=nil{return nil,errCipher}; defer f.Close()
    info,err:=f.Stat(); if err!=nil || !info.Mode().IsRegular() || info.Size()>16384 {return nil,errCipher}
    // Group access permits a dedicated container secret group; world-readable
    // key material is never accepted. Deployment assigns the narrowest group.
    if info.Mode().Perm()&0007!=0{return nil,errCipher}
    d:=json.NewDecoder(io.LimitReader(f,16385));d.DisallowUnknownFields()
    var input keyFile; if d.Decode(&input)!=nil{return nil,errCipher}
    var extra any; if d.Decode(&extra)!=io.EOF{return nil,errCipher}
    return NewKeyring(input.Active,input.Keys)
}
func NewKeyring(active string, encoded map[string]string)(*Keyring,error){
    if !keyIDPattern.MatchString(active)||len(encoded)<1||len(encoded)>16{return nil,errCipher}
    result:=&Keyring{active:active,keys:make(map[string]cipher.AEAD,len(encoded))}
    for id,raw:=range encoded {
        if !keyIDPattern.MatchString(id){return nil,errCipher}
        key,err:=base64.StdEncoding.Strict().DecodeString(raw);if err!=nil||len(key)!=32{return nil,errCipher}
        block,err:=aes.NewCipher(key);for i:=range key{key[i]=0};if err!=nil{return nil,errCipher}
        aead,err:=cipher.NewGCM(block);if err!=nil{return nil,errCipher};result.keys[id]=aead
    }
    if result.keys[active]==nil{return nil,errCipher};return result,nil
}
func (k *Keyring) Encrypt(plaintext,metadata []byte)(Encrypted,error){
    if k==nil||len(plaintext)>131072||len(metadata)>4096{return Encrypted{},errCipher}
    aead:=k.keys[k.active];if aead==nil{return Encrypted{},errCipher}
    nonce:=make([]byte,aead.NonceSize());if _,err:=rand.Read(nonce);err!=nil{return Encrypted{},errCipher}
    return Encrypted{KeyID:k.active,Nonce:nonce,Ciphertext:aead.Seal(nil,nonce,plaintext,metadata)},nil
}
func(k *Keyring) Decrypt(e Encrypted,metadata []byte)([]byte,error){
    if k==nil||len(e.Ciphertext)>131088||len(metadata)>4096{return nil,errCipher}
    aead:=k.keys[e.KeyID];if aead==nil||len(e.Nonce)!=aead.NonceSize(){return nil,errCipher}
    plain,err:=aead.Open(nil,e.Nonce,e.Ciphertext,metadata);if err!=nil{return nil,errCipher};return plain,nil
}
