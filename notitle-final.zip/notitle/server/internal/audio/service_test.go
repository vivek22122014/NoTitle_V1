package audio

import (
 "context"
 "errors"
 "strings"
 "testing"
 "time"
 at "notitle/internal/audiotypes"
 "notitle/internal/relay"
)
type ownerFake struct { jobs []at.Job;results []at.JobResult;ready []bool;publish bool }
func(o *ownerFake)AudioServerInstance(context.Context)(string,error){return strings.Repeat("i",32),nil}
func(o *ownerFake)ClaimAudioJobs(context.Context,int)([]at.Job,error){value:=o.jobs;o.jobs=nil;return value,nil}
func(o *ownerFake)FinishAudioJob(_ context.Context,_ string,r at.JobResult)(bool,error){o.results=append(o.results,r);return o.publish||r.Revoked,nil}
func(o *ownerFake)SetAudioRelayReady(_ context.Context,b bool,_ string)error{o.ready=append(o.ready,b);return nil}
type controllerFake struct { boot string;fail bool;requests []relay.Request;syncs []string }
func(c *controllerFake)Status(context.Context)(relay.Response,error){if c.fail{return relay.Response{},errors.New("failure")};return relay.Response{BootID:c.boot,Ready:true},nil}
func(c *controllerFake)Sync(_ context.Context,boot,instance string)(relay.Response,error){c.syncs=append(c.syncs,instance);return relay.Response{BootID:boot,Ready:true,Success:true},nil}
func(c *controllerFake)Apply(_ context.Context,r relay.Request)(relay.Response,error){c.requests=append(c.requests,r);return relay.Response{BootID:c.boot,Success:true,Revoked:r.Action=="revoke"},nil}
func TestLateCreateCompletionIsCompensated(t *testing.T){o:=&ownerFake{jobs:[]at.Job{{LeaseID:"job",CallRef:strings.Repeat("c",32),Action:"create",Version:1,LeaseUntil:time.Now().Add(30*time.Second)}}};c:=&controllerFake{boot:strings.Repeat("b",32)};s,err:=New(Options{Owner:o,Controller:c,Ready:func(context.Context)error{return nil}});if err!=nil{t.Fatal(err)};s.cycle(context.Background());if len(c.requests)!=2||c.requests[1].Action!="revoke"||len(o.results)!=2||!o.results[1].Revoked{t.Fatal("late credentials were not revoked")}}
func TestControlOutageClosesAudioWithoutChangingTextReadiness(t *testing.T){o:=&ownerFake{};c:=&controllerFake{fail:true};s,_:=New(Options{Owner:o,Controller:c,Ready:func(context.Context)error{return nil}});s.cycle(context.Background());if len(o.ready)!=1||o.ready[0]{t.Fatal("audio not disabled")}}
func TestNewSupervisorBootDisablesOldCallsBeforeSync(t *testing.T){o:=&ownerFake{};c:=&controllerFake{boot:strings.Repeat("b",32)};s,_:=New(Options{Owner:o,Controller:c,Ready:func(context.Context)error{return nil}});s.boot=strings.Repeat("a",32);s.cycle(context.Background());if len(o.ready)<2||o.ready[0]||!o.ready[len(o.ready)-1]||len(c.syncs)!=1{t.Fatal("boot transition did not close old calls")}}
func TestShutdownUsesTerminalNewInstanceBarrier(t *testing.T){o:=&ownerFake{};c:=&controllerFake{boot:strings.Repeat("b",32)};s,_:=New(Options{Owner:o,Controller:c,Ready:func(context.Context)error{return nil}});s.boot=c.boot;s.instance=strings.Repeat("i",32);if err:=s.Shutdown(context.Background());err!=nil{t.Fatal(err)};if len(c.syncs)!=1||c.syncs[0]==s.instance||len(o.ready)!=1||o.ready[0]{t.Fatal("shutdown did not fence old writes")}}
