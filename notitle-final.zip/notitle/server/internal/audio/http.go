// Package audio performs relay-control I/O outside the realtime owner.
package audio

import (
 "bytes"
 "context"
 "crypto/tls"
 "crypto/x509"
 "encoding/hex"
 "encoding/json"
 "errors"
 "io"
 "net"
 "net/http"
 "net/url"
 "os"
 "strings"
 "time"
 "notitle/internal/relay"
)

type Controller interface {
 Status(context.Context)(relay.Response,error)
 Sync(context.Context,string,string)(relay.Response,error)
 Apply(context.Context,relay.Request)(relay.Response,error)
}
type HTTPOptions struct { URL,Token,CAFile,ClientCertFile,ClientKeyFile string;AllowLoopbackHTTP bool }
type httpController struct{ origin,token string;client *http.Client }
var ErrUnavailable=errors.New("audio relay unavailable")

func LoadControlTokenFile(path string)(string,error){
 info,err:=os.Lstat(path);if err!=nil||!info.Mode().IsRegular()||info.Mode().Perm()&0077!=0||info.Size()>4096{return "",ErrUnavailable}
 raw,err:=os.ReadFile(path);if err!=nil{return "",ErrUnavailable};value:=strings.TrimSpace(string(raw));decoded,err:=hex.DecodeString(value)
 if err!=nil||len(decoded)!=32{return "",ErrUnavailable};return value,nil
}
func NewHTTPController(o HTTPOptions)(Controller,error){
 parsed,err:=url.Parse(o.URL);if err!=nil||parsed.User!=nil||parsed.RawQuery!=""||parsed.Fragment!=""||parsed.Host==""||(parsed.Path!=""&&parsed.Path!="/")||len(o.Token)!=64{return nil,ErrUnavailable}
 if _,err=hex.DecodeString(o.Token);err!=nil{return nil,ErrUnavailable}
 transport:=&http.Transport{Proxy:nil,MaxConnsPerHost:4,MaxIdleConnsPerHost:4,IdleConnTimeout:30*time.Second,TLSHandshakeTimeout:time.Second,ResponseHeaderTimeout:2*time.Second,DialContext:(&net.Dialer{Timeout:time.Second}).DialContext}
 if parsed.Scheme=="http"{
  ip:=net.ParseIP(parsed.Hostname());if !o.AllowLoopbackHTTP||ip==nil||(parsed.Hostname()!="127.0.0.1"&&parsed.Hostname()!="::1"){return nil,ErrUnavailable}
 }else if parsed.Scheme=="https"{
  if o.CAFile==""||o.ClientCertFile==""||o.ClientKeyFile==""{return nil,ErrUnavailable}
  raw,err:=os.ReadFile(o.CAFile);if err!=nil{return nil,ErrUnavailable};roots:=x509.NewCertPool();if !roots.AppendCertsFromPEM(raw){return nil,ErrUnavailable}
  keyInfo,err:=os.Lstat(o.ClientKeyFile);if err!=nil||!keyInfo.Mode().IsRegular()||keyInfo.Mode().Perm()&0077!=0{return nil,ErrUnavailable}
  certificate,err:=tls.LoadX509KeyPair(o.ClientCertFile,o.ClientKeyFile);if err!=nil{return nil,ErrUnavailable}
  transport.TLSClientConfig=&tls.Config{MinVersion:tls.VersionTLS13,RootCAs:roots,Certificates:[]tls.Certificate{certificate}}
 }else{return nil,ErrUnavailable}
 return &httpController{origin:strings.TrimSuffix(o.URL,"/"),token:o.Token,client:&http.Client{Transport:transport,Timeout:2500*time.Millisecond,CheckRedirect:func(*http.Request,[]*http.Request)error{return ErrUnavailable}}},nil
}
func(c *httpController)request(ctx context.Context,method,path string,value any)(relay.Response,error){
 var body io.Reader
 if value!=nil{raw,err:=json.Marshal(value);if err!=nil{return relay.Response{},ErrUnavailable};body=bytes.NewReader(raw)}
 request,err:=http.NewRequestWithContext(ctx,method,c.origin+path,body);if err!=nil{return relay.Response{},ErrUnavailable};request.Header.Set("Authorization","Bearer "+c.token);request.Header.Set("Content-Type","application/json")
 response,err:=c.client.Do(request);if err!=nil{return relay.Response{},ErrUnavailable};defer response.Body.Close();if response.StatusCode!=200{return relay.Response{},ErrUnavailable}
 decoder:=json.NewDecoder(io.LimitReader(response.Body,16385));decoder.DisallowUnknownFields();var result relay.Response
 if decoder.Decode(&result)!=nil||decoder.Decode(new(any))!=io.EOF{return relay.Response{},ErrUnavailable};return result,nil
}
func(c *httpController)Status(ctx context.Context)(relay.Response,error){return c.request(ctx,http.MethodGet,"/v1/status",nil)}
func(c *httpController)Sync(ctx context.Context,boot,instance string)(relay.Response,error){return c.request(ctx,http.MethodPost,"/v1/sync",relay.Request{BootID:boot,ServerInstance:instance})}
func(c *httpController)Apply(ctx context.Context,r relay.Request)(relay.Response,error){return c.request(ctx,http.MethodPost,"/v1/lease",r)}
