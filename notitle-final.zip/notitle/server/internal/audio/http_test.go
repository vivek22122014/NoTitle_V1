package audio

import (
 "os"
 "path/filepath"
 "strings"
 "testing"
)
func TestCleartextControlOnlyExplicitLiteralLoopback(t *testing.T){token:=strings.Repeat("ab",32);for _,u:=range []string{"http://localhost:9443","http://10.0.0.5:9443","http://127.0.0.2:9443","http://127.0.0.1:9443/path","http://127.0.0.1:9443/?token=x","https://example.com"}{if _,err:=NewHTTPController(HTTPOptions{URL:u,Token:token,AllowLoopbackHTTP:true});err==nil{t.Fatal("unsafe transport accepted")}};if _,err:=NewHTTPController(HTTPOptions{URL:"http://127.0.0.1:9443",Token:token});err==nil{t.Fatal("implicit HTTP accepted")};if _,err:=NewHTTPController(HTTPOptions{URL:"http://127.0.0.1:9443",Token:token,AllowLoopbackHTTP:true});err!=nil{t.Fatal("explicit loopback rejected")}}
func TestTokenFileRejectsPublicPermissionsSymlinksAndWeakValues(t *testing.T){path:=filepath.Join(t.TempDir(),"control-token");if err:=os.WriteFile(path,[]byte(strings.Repeat("ab",32)),0600);err!=nil{t.Fatal(err)};if _,err:=LoadControlTokenFile(path);err!=nil{t.Fatal(err)};if err:=os.Chmod(path,0644);err!=nil{t.Fatal(err)};if _,err:=LoadControlTokenFile(path);err==nil{t.Fatal("world-readable token accepted")};os.Chmod(path,0600);link:=path+"-link";if err:=os.Symlink(path,link);err==nil{if _,err:=LoadControlTokenFile(link);err==nil{t.Fatal("symlink accepted")}};os.WriteFile(path,[]byte("short"),0600);if _,err:=LoadControlTokenFile(path);err==nil{t.Fatal("weak token accepted")}}
