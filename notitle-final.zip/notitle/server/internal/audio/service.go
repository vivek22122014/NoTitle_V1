package audio

import (
 "context"
 "crypto/rand"
 "encoding/base64"
 "sync"
 "time"
 at "notitle/internal/audiotypes"
 "notitle/internal/relay"
)

type Options struct { Owner at.Owner;Controller Controller;Ready func(context.Context)error;Now func()time.Time }
type Service struct { options Options;mu sync.Mutex;boot,instance string;stopping bool }
func New(o Options)(*Service,error){if o.Owner==nil||o.Controller==nil||o.Ready==nil{return nil,ErrUnavailable};if o.Now==nil{o.Now=time.Now};return &Service{options:o},nil}
func(s *Service) unavailable(ctx context.Context){finish,cancel:=context.WithTimeout(context.WithoutCancel(ctx),time.Second);defer cancel();_ =s.options.Owner.SetAudioRelayReady(finish,false,s.boot)}
func(s *Service)Run(ctx context.Context){
 ticker:=time.NewTicker(time.Second);defer ticker.Stop()
 for{select{case<-ctx.Done():return;case<-ticker.C:s.mu.Lock();if !s.stopping{s.cycle(ctx)};s.mu.Unlock()}}
}
func(s *Service)cycle(ctx context.Context){
 work,cancel:=context.WithTimeout(ctx,4*time.Second);defer cancel()
 if s.instance==""{value,err:=s.options.Owner.AudioServerInstance(work);if err!=nil{return};s.instance=value}
 status,err:=s.options.Controller.Status(work)
 if err!=nil||!at.ValidRef(status.BootID){s.unavailable(work);return}
 if status.BootID!=s.boot{
  s.unavailable(work);s.boot=status.BootID
  synced,err:=s.options.Controller.Sync(work,s.boot,s.instance);if err!=nil||!synced.Success||synced.BootID!=s.boot{return}
 }
 ready:=s.options.Ready(work)==nil&&status.Ready
 if !status.Ready{synced,err:=s.options.Controller.Sync(work,s.boot,s.instance);ready=err==nil&&synced.Ready&&s.options.Ready(work)==nil}
 if err:=s.options.Owner.SetAudioRelayReady(work,ready,s.boot);err!=nil{return}
 s.drain(work,16)
}
func(s *Service)drain(ctx context.Context,limit int)int{
 jobs,err:=s.options.Owner.ClaimAudioJobs(ctx,limit);if err!=nil{return 0}
 for _,job:=range jobs{
  if ctx.Err()!=nil{break}
  request:=relay.Request{BootID:s.boot,ServerInstance:s.instance,CallRef:job.CallRef,Version:job.Version,Action:job.Action,LeaseUntil:job.LeaseUntil}
  result,err:=s.options.Controller.Apply(ctx,request)
  completed:=at.JobResult{Success:err==nil&&result.Success,Credentials:result.Credentials,Revoked:err==nil&&result.Revoked,RelayBootID:result.BootID}
  if err!=nil||result.BootID!=s.boot{completed.Success=false;s.unavailable(ctx)}
  finish,stop:=context.WithTimeout(context.WithoutCancel(ctx),time.Second)
  published,finishErr:=s.options.Owner.FinishAudioJob(finish,job.LeaseID,completed);stop()
  if (finishErr!=nil||!published)&&job.Action!="revoke"{
   // Even ambiguous create failures may have issued usable credentials. Send
   // a terminal tombstone, then confirm cleanup of this exact owner job.
   cleanup,done:=context.WithTimeout(ctx,2500*time.Millisecond)
   request.Action="revoke";revoked,revokeErr:=s.options.Controller.Apply(cleanup,request)
   if revokeErr==nil&&revoked.Revoked&&revoked.BootID==s.boot{_,_=s.options.Owner.FinishAudioJob(cleanup,job.LeaseID,at.JobResult{Success:true,Revoked:true,RelayBootID:s.boot})}else{s.unavailable(cleanup)};done()
  }
 }
 return len(jobs)
}
// Shutdown stops admission and explicitly drains cancellation while the owner
// is still running. A crash still falls back to the private lease watchdog.
func(s *Service)Shutdown(ctx context.Context)error{
 s.mu.Lock();defer s.mu.Unlock();s.stopping=true;s.unavailable(ctx)
 var nonce[24]byte;if _,err:=rand.Read(nonce[:]);err!=nil{return ErrUnavailable};shutdownInstance:=base64.RawURLEncoding.EncodeToString(nonce[:])
 ticker:=time.NewTicker(100*time.Millisecond);defer ticker.Stop()
 // Change the authenticated app incarnation as a terminal barrier against
 // every delayed create, then require an empty allocation scan. Claimed-job
 // count alone cannot prove cleanup when the owner has retry timers pending.
 for{result,err:=s.options.Controller.Sync(ctx,s.boot,shutdownInstance);if err==nil&&result.Success&&result.BootID==s.boot{return nil};select{case<-ctx.Done():return ErrUnavailable;case<-ticker.C:}}
}
