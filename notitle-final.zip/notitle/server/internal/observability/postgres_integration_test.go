package observability

import (
 "context"
 "crypto/rand"
 "crypto/sha256"
 "encoding/hex"
 "errors"
 "os"
 "strings"
 "testing"
 "time"
 "github.com/jackc/pgx/v5/pgxpool"
)
func alertIntegration(t *testing.T)(*pgxpool.Pool,*pgxpool.Pool,context.Context){
 t.Helper();read:=func(name string)string{path:=os.Getenv(name);if path==""{return ""};raw,err:=os.ReadFile(path);if err!=nil{t.Fatal("integration credential unavailable")};return strings.TrimSpace(string(raw))}
 dsn:=read("TEST_DATABASE_URL_FILE");if dsn==""{dsn=os.Getenv("TEST_DATABASE_URL")};migration:=read("TEST_ADMIN_MIGRATION_URL_FILE")
 if dsn==""||migration==""{if os.Getenv("REQUIRE_DATABASE_INTEGRATION")=="1"{t.Fatal("isolated integration credentials required")};t.Skip("run scripts/db-check.sh")}
 ctx,cancel:=context.WithTimeout(context.Background(),30*time.Second);t.Cleanup(cancel)
 pool,err:=pgxpool.New(ctx,dsn);if err!=nil{t.Fatal("runtime configuration")};t.Cleanup(pool.Close)
 owner,err:=pgxpool.New(ctx,migration);if err!=nil{t.Fatal("migration configuration")};t.Cleanup(owner.Close)
 var role string;if owner.QueryRow(ctx,`SELECT current_user`).Scan(&role)!=nil||role!="notitle_migrate"{t.Fatal("migration role required")};return pool,owner,ctx
}
type acceptReceiver struct { calls []string }
func(r *acceptReceiver)Configured(string)bool{return true}
func(r *acceptReceiver)Send(_ context.Context,channel string,_ Envelope)error{r.calls=append(r.calls,channel);return nil}
func TestIntegrationTransportAcceptanceDoesNotAcknowledgeOrCancelBackup(t *testing.T){
 pool,_,ctx:=alertIntegration(t);now:=time.Now().UTC().Truncate(time.Microsecond);receiver:=&acceptReceiver{};s:=New(Options{Pool:pool,Receiver:receiver,Now:func()time.Time{return now}})
 if s.syncAlerts(ctx,[]Condition{{"backup_wal","urgent",true}},now)!=nil{t.Fatal("create incident")};s.deliverOne(ctx,now)
 var state,primary,backup string;if pool.QueryRow(ctx,`SELECT a.state,p.state,b.state FROM notitle.operational_alerts a JOIN notitle.operational_alert_deliveries p ON p.event_ref=a.event_ref AND p.channel='primary' JOIN notitle.operational_alert_deliveries b ON b.event_ref=a.event_ref AND b.channel='backup' WHERE a.code='backup_wal' AND a.state<>'resolved'`).Scan(&state,&primary,&backup)!=nil{t.Fatal("read delivery")};if state!="open"||primary!="delivered"||backup!="pending"{t.Fatal("transport acceptance cancelled human escalation")}
 now=now.Add(2*time.Minute);s.deliverOne(ctx,now);if len(receiver.calls)!=2||receiver.calls[1]!="backup"{t.Fatal("backup was not delivered")}
 if s.syncAlerts(ctx,[]Condition{{"backup_wal","urgent",false}},now)!=nil{t.Fatal("resolve incident")}
}
func TestIntegrationAcknowledgementRechecksRoleAndAuditsAtomically(t *testing.T){
 pool,migrate,ctx:=alertIntegration(t);now:=time.Now().UTC().Truncate(time.Microsecond);s:=New(Options{Pool:pool,Now:func()time.Time{return now}})
 if err:=s.syncAlerts(ctx,[]Condition{{"host_cpu","warning",true}},now);err!=nil{t.Fatal(err)};var ref string;if pool.QueryRow(ctx,`SELECT event_ref FROM notitle.operational_alerts WHERE code='host_cpu' AND state='open'`).Scan(&ref)!=nil{t.Fatal("read incident")}
 var raw[16]byte;if _,err:=rand.Read(raw[:]);err!=nil{t.Fatal(err)};id:=hex.EncodeToString(raw[:]);hash:=sha256.Sum256(raw[:])
 if _,err:=migrate.Exec(ctx,`INSERT INTO notitle.admin_users(id,username,password_hash,totp_ciphertext,roles,created_at) VALUES($1,$2,$3,$4,ARRAY['operations_readonly'],$5)`,id,"ops_"+id,"$argon2id$v=19$m=65536,t=3,p=1$synthetic-fixture$synthetic-fixture",make([]byte,48),now);err!=nil{t.Fatal(err)}
 if _,err:=pool.Exec(ctx,`INSERT INTO notitle.admin_sessions(token_hash,admin_id,admin_generation,created_at,last_seen_at,absolute_expires_at) VALUES($1,$2,1,$3,$3,$3+interval '4 hours')`,hash[:],id,now);err!=nil{t.Fatal(err)}
 input:=AcknowledgeInput{ActorID:id,Generation:1,SessionHash:hash,Reason:"Investigating measured CPU pressure",AlertID:ref,ExpectedVersion:1}
 if !errors.Is(s.Acknowledge(ctx,input),ErrUnauthorized){t.Fatal("readonly role acknowledged incident")}
 if _,err:=migrate.Exec(ctx,`UPDATE notitle.admin_users SET roles=ARRAY['owner'] WHERE id=$1`,id);err!=nil{t.Fatal(err)}
 wrong:=input;wrong.SessionHash=sha256.Sum256([]byte("other-session"));if !errors.Is(s.Acknowledge(ctx,wrong),ErrUnauthorized){t.Fatal("stale session accepted")}
 if err:=s.Acknowledge(ctx,input);err!=nil{t.Fatal(err)};if !errors.Is(s.Acknowledge(ctx,input),ErrConflict){t.Fatal("stale alert revision accepted")}
 var audits,pending int;var state string;if pool.QueryRow(ctx,`SELECT state FROM notitle.operational_alerts WHERE event_ref=$1`,ref).Scan(&state)!=nil{t.Fatal("state query")};if pool.QueryRow(ctx,`SELECT count(*) FROM notitle.admin_audit WHERE subject_ref=$1 AND action='operations_alert_ack'`,ref).Scan(&audits)!=nil{t.Fatal("audit query")};if pool.QueryRow(ctx,`SELECT count(*) FROM notitle.operational_alert_deliveries WHERE event_ref=$1 AND state IN ('pending','leased')`,ref).Scan(&pending)!=nil{t.Fatal("outbox query")};if state!="acknowledged"||audits!=1||pending!=0{t.Fatal("acknowledgement/audit/cancellation not atomic")}
 if err:=s.syncAlerts(ctx,[]Condition{{"host_cpu","warning",false}},now);err!=nil{t.Fatal(err)}
}
func TestIntegrationAbandonedFinalLeaseBecomesDead(t *testing.T){
 pool,_,ctx:=alertIntegration(t);now:=time.Now().UTC().Truncate(time.Microsecond);s:=New(Options{Pool:pool,Now:func()time.Time{return now}})
 if err:=s.syncAlerts(ctx,[]Condition{{"host_disk","warning",true}},now);err!=nil{t.Fatal(err)};first,err:=s.claim(ctx,now);if err!=nil||first.ID==0{t.Fatal("claim failed")}
 second,err:=s.claim(ctx,now);if err!=nil||second.ID!=0{t.Fatal("live lease double claimed")}
 if _,err=pool.Exec(ctx,`UPDATE notitle.operational_alert_deliveries SET attempts=8,lease_until=$2 WHERE id=$1`,first.ID,now.Add(-time.Second));err!=nil{t.Fatal(err)}
 if _,err=s.claim(ctx,now);err!=nil{t.Fatal(err)};var state string;if pool.QueryRow(ctx,`SELECT state FROM notitle.operational_alert_deliveries WHERE id=$1`,first.ID).Scan(&state)!=nil||state!="dead"{t.Fatal("abandoned last attempt remained leased")}
 if err=s.syncAlerts(ctx,[]Condition{{"host_disk","warning",false}},now);err!=nil{t.Fatal(err)}
}
