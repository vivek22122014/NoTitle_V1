package observability

import (
 "context"
 "crypto/sha256"
 "errors"
 "time"
 "github.com/jackc/pgx/v5"
)
type delivery struct { ID int64; Token,Channel string; Attempts int; Envelope Envelope }
func(s *Service)claim(ctx context.Context,now time.Time)(delivery,error){
 var d delivery;if s.options.Pool==nil{return d,ErrUnavailable};token,err:=randomRef();if err!=nil{return d,err}
 // Exhaust expired final attempts before claiming. A killed process cannot
 // exceed the retry budget by repeatedly abandoning its final lease.
 if _,err=s.options.Pool.Exec(ctx,`UPDATE notitle.operational_alert_deliveries SET state='dead',last_result='attempts_exhausted',lease_token=NULL,lease_until=NULL WHERE attempts>=8 AND ((state='leased' AND lease_until<=$1) OR state='pending')`,now);err!=nil{return d,ErrUnavailable}
 err=s.options.Pool.QueryRow(ctx,`WITH due AS (SELECT d.id FROM notitle.operational_alert_deliveries d JOIN notitle.operational_alerts a ON a.event_ref=d.event_ref WHERE a.state='open' AND d.attempts<8 AND ((d.state='pending' AND d.available_at<=$1) OR (d.state='leased' AND d.lease_until<=$1)) ORDER BY (a.severity='urgent') DESC,d.available_at,d.id FOR UPDATE OF d SKIP LOCKED LIMIT 1), claimed AS (UPDATE notitle.operational_alert_deliveries d SET state='leased',attempts=attempts+1,lease_token=$2,lease_until=$1+interval '30 seconds' FROM due WHERE d.id=due.id RETURNING d.*) SELECT d.id,d.lease_token,d.channel,d.attempts,a.event_ref,a.code,a.severity,a.opened_at FROM claimed d JOIN notitle.operational_alerts a ON a.event_ref=d.event_ref`,now,token).Scan(&d.ID,&d.Token,&d.Channel,&d.Attempts,&d.Envelope.EventRef,&d.Envelope.Code,&d.Envelope.Severity,&d.Envelope.OpenedAt)
 if errors.Is(err,pgx.ErrNoRows){return delivery{},nil};if err!=nil{return delivery{},ErrUnavailable};return d,nil
}
func(s *Service)deliverOne(ctx context.Context,now time.Time){
 d,err:=s.claim(ctx,now);if err!=nil||d.ID==0{return}
 // ACK may arrive after claim. Recheck before I/O. Delivery already in flight
 // can still reach the device; the opaque ID lets receivers deduplicate it.
 var valid bool;err=s.options.Pool.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.operational_alert_deliveries d JOIN notitle.operational_alerts a ON a.event_ref=d.event_ref WHERE d.id=$1 AND d.lease_token=$2 AND d.state='leased' AND d.lease_until>$3 AND a.state='open')`,d.ID,d.Token,s.options.Now().UTC()).Scan(&valid);if err!=nil||!valid{return}
 success:=s.options.Receiver!=nil&&s.options.Receiver.Configured(d.Channel)&&s.options.Receiver.Send(ctx,d.Channel,d.Envelope)==nil
 state,result:="pending","receiver_unavailable";finished:=s.options.Now().UTC();if success{state="delivered";result="delivered"}else if d.Attempts>=8{state="dead";result="attempts_exhausted"}
 // Only a human action sets acknowledged. HTTP acceptance means transport
 // delivery only, and cannot cancel the backup escalation.
 _,_=s.options.Pool.Exec(ctx,`UPDATE notitle.operational_alert_deliveries SET state=$3,last_result=$4,available_at=$5,delivered_at=CASE WHEN $3='delivered' THEN $6 ELSE NULL END,lease_token=NULL,lease_until=NULL WHERE id=$1 AND lease_token=$2 AND state='leased' AND lease_until>$6`,d.ID,d.Token,state,result,finished.Add(RetryDelay(d.Envelope.EventRef,d.Attempts)),finished)
}
func RetryDelay(ref string,attempt int)time.Duration{if attempt<1{attempt=1};if attempt>8{attempt=8};delay:=5*time.Second*time.Duration(1<<uint(attempt-1));if delay>5*time.Minute{delay=5*time.Minute};sum:=sha256.Sum256([]byte(ref));return delay+time.Duration(sum[attempt-1]%11)*time.Second}
