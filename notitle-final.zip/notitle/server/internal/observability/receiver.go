package observability

import (
 "bytes"
 "context"
 "encoding/json"
 "io"
 "net"
 "net/http"
 "net/netip"
 "net/url"
 "regexp"
 "strings"
 "time"
)
type ReceiverConfig struct { PrimaryURL,BackupURL string; PrimaryToken,BackupToken []byte }
type endpoint struct { url,token string }
type HTTPReceiver struct { endpoints map[string]endpoint; client *http.Client }
var eventReference=regexp.MustCompile(`^[A-Za-z0-9_-]{16,128}$`)
func NewReceiver(c ReceiverConfig)(*HTTPReceiver,error){
 r:=&HTTPReceiver{endpoints:map[string]endpoint{}}
 for channel,v:=range map[string]endpoint{"primary":{c.PrimaryURL,string(c.PrimaryToken)},"backup":{c.BackupURL,string(c.BackupToken)}}{
  if v.url==""&&v.token==""{continue}
  u,err:=url.Parse(v.url);if err!=nil||u.Scheme!="https"||u.Host==""||u.Hostname()==""||u.User!=nil||u.RawQuery!=""||u.Fragment!=""||u.Opaque!=""||u.ForceQuery||len(v.url)>2048||u.Port()!=""&&u.Port()!="443"||len(v.token)<32||len(v.token)>1024||strings.ContainsAny(v.token,"\r\n\x00"){return nil,ErrInvalid}
  if ip,err:=netip.ParseAddr(u.Hostname());err==nil&&!publicIP(ip){return nil,ErrInvalid}
  r.endpoints[channel]=v
 }
 if c.PrimaryURL!=""&&c.PrimaryURL==c.BackupURL{return nil,ErrInvalid}
 transport:=&http.Transport{Proxy:nil,DialContext:publicDial,TLSHandshakeTimeout:3*time.Second,MaxIdleConns:2,MaxConnsPerHost:2,IdleConnTimeout:30*time.Second,ResponseHeaderTimeout:4*time.Second,DisableCompression:true}
 r.client=&http.Client{Transport:transport,Timeout:5*time.Second,CheckRedirect:func(*http.Request,[]*http.Request)error{return http.ErrUseLastResponse}}
 return r,nil
}
func publicIP(ip netip.Addr)bool{
 ip=ip.Unmap();if !ip.IsGlobalUnicast()||ip.IsPrivate()||ip.IsLoopback()||ip.IsLinkLocalUnicast(){return false}
 for _,cidr:=range []string{"100.64.0.0/10","192.0.0.0/24","192.0.2.0/24","198.18.0.0/15","198.51.100.0/24","203.0.113.0/24","240.0.0.0/4","2001:db8::/32","64:ff9b:1::/48","64:ff9b::/96","2002::/16","2001::/32"}{if netip.MustParsePrefix(cidr).Contains(ip){return false}}
 return true
}
func publicDial(ctx context.Context,network,address string)(net.Conn,error){
 host,port,err:=net.SplitHostPort(address);if err!=nil||port!="443"{return nil,ErrInvalid}
 ips,err:=net.DefaultResolver.LookupNetIP(ctx,"ip",host);if err!=nil||len(ips)==0||len(ips)>16{return nil,ErrUnavailable}
 // Validate every answer before opening a socket; an approved hostname cannot
 // rebind to loopback, cloud metadata, a database or another private service.
 for _,ip:=range ips{if !publicIP(ip){return nil,ErrUnavailable}}
 dialer:=net.Dialer{Timeout:3*time.Second};for _,ip:=range ips{conn,e:=dialer.DialContext(ctx,network,net.JoinHostPort(ip.String(),port));if e==nil{return conn,nil}}
 return nil,ErrUnavailable
}
func(r *HTTPReceiver)Configured(channel string)bool{if r==nil{return false};_,ok:=r.endpoints[channel];return ok}
func(r *HTTPReceiver)Send(ctx context.Context,channel string,e Envelope)error{
 if r==nil||r.client==nil||!r.Configured(channel)||!eventReference.MatchString(e.EventRef)||!allowedCode(e.Code)||(e.Severity!="warning"&&e.Severity!="urgent")||e.OpenedAt.IsZero(){return ErrInvalid}
 raw,err:=json.Marshal(e);if err!=nil{return ErrInvalid};target:=r.endpoints[channel]
 req,err:=http.NewRequestWithContext(ctx,http.MethodPost,target.url,bytes.NewReader(raw));if err!=nil{return ErrInvalid}
 req.Header.Set("Content-Type","application/json");req.Header.Set("Authorization","Bearer "+target.token);req.Header.Set("Idempotency-Key",e.EventRef+":"+channel)
 response,err:=r.client.Do(req);if err!=nil{return ErrUnavailable};defer response.Body.Close();_,_=io.Copy(io.Discard,io.LimitReader(response.Body,1024))
 if response.StatusCode<200||response.StatusCode>=300{return ErrUnavailable};return nil
}
