package observability

import (
 "context"
 "crypto/rand"
 "encoding/base64"
 "encoding/hex"
 "errors"
 "strings"
 "time"
 "unicode"
 "unicode/utf8"
 "github.com/jackc/pgx/v5"
 "github.com/jackc/pgx/v5/pgxpool"
)
func randomRef()(string,error){var value[24]byte;if _,err:=rand.Read(value[:]);err!=nil{return "",ErrUnavailable};return base64.RawURLEncoding.EncodeToString(value[:]),nil}
func(s *Service)readDatabase(ctx context.Context,out *DatabaseMetrics,now time.Time)error{
 err:=s.options.Pool.QueryRow(ctx,`SELECT
 (SELECT count(*) FROM notitle.payment_attempts p WHERE p.environment=$1 AND p.status='SUCCESS' AND p.observed_at<=$2-interval '5 minutes' AND NOT EXISTS(SELECT 1 FROM notitle.premium_lots l WHERE l.order_ref=p.order_ref)),
 (SELECT count(*) FROM notitle.billing_jobs WHERE environment=$1 AND ((state='ready' AND run_at<$2-interval '5 minutes') OR (state='leased' AND lease_until<$2))),
 (SELECT count(*) FROM notitle.billing_jobs WHERE environment=$1 AND state='dead')`,s.options.Environment,now).Scan(&out.UngrantedCaptures,&out.OverdueJobs,&out.DeadJobs)
 if err!=nil{return ErrUnavailable};return nil
}
// No personal rows leave PostgreSQL. Environment-specific financial counts are
// separate; safety/privacy operational work covers the deployed application.
func NewPostgresCounts(pool *pgxpool.Pool)func(context.Context,time.Time)(AggregateCounts,error){return func(ctx context.Context,now time.Time)(AggregateCounts,error){
 var v AggregateCounts;if pool==nil{return v,ErrUnavailable}
 err:=pool.QueryRow(ctx,`SELECT
 (SELECT count(*) FROM notitle.grievances WHERE severity='urgent' AND pending_attention AND closed_at IS NULL),
 (SELECT count(*) FROM notitle.grievances WHERE closed_at IS NULL AND (resolution_due<$1 OR (acknowledged_at IS NULL AND acknowledge_due<$1))),
 (SELECT count(*) FROM notitle.operations_outbox WHERE (state='pending' AND available_at<$1-interval '5 minutes') OR (state='leased' AND lease_until<$1)),
 (SELECT count(*) FROM notitle.operations_outbox WHERE state='dead')+(SELECT count(*) FROM notitle.privacy_jobs WHERE state='dead')+(SELECT count(*) FROM notitle.operational_alert_deliveries d JOIN notitle.operational_alerts a ON a.event_ref=d.event_ref WHERE d.state='dead' AND a.state='open'),
 (SELECT count(*) FROM notitle.deletion_jobs WHERE requested_at<$1-interval '5 minutes' AND (NOT tombstone_durable OR (scrubbed_at IS NULL AND EXISTS(SELECT 1 FROM notitle.retention_policies WHERE approved AND (document->>'review_due_at')::timestamptz>$1 AND (document->>'ordinary_deletion_approved')::boolean)))),
 (SELECT count(*) FROM notitle.privacy_jobs WHERE state IN ('ready','leased') AND not_before<$1-interval '15 minutes')+(SELECT count(*) FROM notitle.privacy_holds WHERE released_at IS NULL AND review_at<$1),
 (SELECT count(*) FROM notitle.operational_alert_deliveries d JOIN notitle.operational_alerts a ON a.event_ref=d.event_ref WHERE a.state='open' AND d.state IN ('pending','leased','dead') AND d.last_result IN ('receiver_unavailable','attempts_exhausted'))+(SELECT count(*) FROM notitle.operations_outbox o JOIN notitle.grievances g ON g.ref=o.case_ref WHERE g.pending_attention AND g.closed_at IS NULL AND ((o.state='pending' AND o.attempts>0) OR o.state='dead'))
 `,now).Scan(&v.UrgentCases,&v.OverdueCases,&v.OverdueJobs,&v.DeadJobs,&v.DeletionFailures,&v.PrivacyOverdue,&v.DeliveryFailures)
 if err!=nil{return AggregateCounts{},ErrUnavailable};return v,nil
}}
func(s *Service)syncAlerts(ctx context.Context,conditions []Condition,now time.Time)error{
 tx,err:=s.options.Pool.Begin(ctx);if err!=nil{return ErrUnavailable};defer rollback(tx)
 for _,c:=range conditions{
  if !allowedCode(c.Code){return ErrInvalid}
  if !c.Active{
   if _,err=tx.Exec(ctx,`WITH cleared AS (UPDATE notitle.operational_alerts SET state='resolved',resolved_at=$2,touched_at=$2,generation=generation+1 WHERE code=$1 AND state<>'resolved' RETURNING event_ref) UPDATE notitle.operational_alert_deliveries d SET state='cancelled',lease_token=NULL,lease_until=NULL FROM cleared c WHERE d.event_ref=c.event_ref AND d.state IN ('pending','leased')`,c.Code,now);err!=nil{return ErrUnavailable};continue
  }
  ref,err:=randomRef();if err!=nil{return err}
  var event string;var opened time.Time
  err=tx.QueryRow(ctx,`INSERT INTO notitle.operational_alerts(event_ref,code,severity,state,opened_at,touched_at) VALUES($1,$2,$3,'open',$4,$4) ON CONFLICT(code) WHERE state<>'resolved' DO UPDATE SET touched_at=EXCLUDED.touched_at RETURNING event_ref,opened_at`,ref,c.Code,c.Severity,now).Scan(&event,&opened);if err!=nil{return ErrUnavailable}
  delay:=5*time.Minute;if c.Severity=="urgent"{delay=2*time.Minute}
  _,err=tx.Exec(ctx,`INSERT INTO notitle.operational_alert_deliveries(event_ref,channel,state,available_at) SELECT $1,v.channel,'pending',v.at FROM (VALUES('primary'::text,$2::timestamptz),('backup'::text,$3::timestamptz))v(channel,at) WHERE EXISTS(SELECT 1 FROM notitle.operational_alerts WHERE event_ref=$1 AND state='open') ON CONFLICT(event_ref,channel) DO NOTHING`,event,opened,opened.Add(delay));if err!=nil{return ErrUnavailable}
 }
 if tx.Commit(ctx)!=nil{return ErrUnavailable};return nil
}
func(s *Service)listAlerts(ctx context.Context)([]Alert,error){
 rows,err:=s.options.Pool.Query(ctx,`SELECT a.event_ref,a.code,a.severity,a.state,a.opened_at,a.touched_at,a.acknowledged_at,a.generation,COALESCE(p.state,''),COALESCE(b.state,'') FROM notitle.operational_alerts a LEFT JOIN notitle.operational_alert_deliveries p ON p.event_ref=a.event_ref AND p.channel='primary' LEFT JOIN notitle.operational_alert_deliveries b ON b.event_ref=a.event_ref AND b.channel='backup' WHERE a.state<>'resolved' ORDER BY (a.severity='urgent') DESC,a.opened_at LIMIT 100`);if err!=nil{return nil,ErrUnavailable};defer rows.Close();result:=[]Alert{}
 for rows.Next(){var a Alert;if rows.Scan(&a.ID,&a.Code,&a.Severity,&a.State,&a.OpenedAt,&a.TouchedAt,&a.AcknowledgedAt,&a.Version,&a.Primary,&a.Backup)!=nil{return nil,ErrUnavailable};result=append(result,a)};if rows.Err()!=nil{return nil,ErrUnavailable};return result,nil
}
func(s *Service)saveMetric(ctx context.Context,v Snapshot,retentionDays int)error{
 if retentionDays<1||retentionDays>36525{return ErrInvalid}
 _,err:=s.options.Pool.Exec(ctx,`INSERT INTO notitle.operational_metric_hours(bucket,samples,connected_max,waiting_max,calls_max,heap_max,probe_max_ms,cpu_sum,memory_max,disk_max,updated_at) VALUES($1,1,$2,$3,$4,$5,$6,$7,$8,$9,$10) ON CONFLICT(bucket) DO UPDATE SET samples=notitle.operational_metric_hours.samples+1,connected_max=GREATEST(notitle.operational_metric_hours.connected_max,EXCLUDED.connected_max),waiting_max=GREATEST(notitle.operational_metric_hours.waiting_max,EXCLUDED.waiting_max),calls_max=GREATEST(notitle.operational_metric_hours.calls_max,EXCLUDED.calls_max),heap_max=GREATEST(notitle.operational_metric_hours.heap_max,EXCLUDED.heap_max),probe_max_ms=GREATEST(notitle.operational_metric_hours.probe_max_ms,EXCLUDED.probe_max_ms),cpu_sum=notitle.operational_metric_hours.cpu_sum+EXCLUDED.cpu_sum,memory_max=GREATEST(notitle.operational_metric_hours.memory_max,EXCLUDED.memory_max),disk_max=GREATEST(notitle.operational_metric_hours.disk_max,EXCLUDED.disk_max),updated_at=EXCLUDED.updated_at`,v.SampledAt.Truncate(time.Hour),v.Realtime.Connected,v.Realtime.Waiting,v.Realtime.Calls,v.Process.HeapBytes,v.Realtime.ProbeMS,v.External.HostCPUPercent,v.External.HostMemoryPercent,v.External.DiskUsedPercent,v.SampledAt)
 if err!=nil{return ErrUnavailable}
 _,err=s.options.Pool.Exec(ctx,`SELECT notitle.operations_expire_metadata($1,$2)`,s.options.RetentionVersion,s.options.Now().UTC());if err!=nil{return ErrUnavailable};return nil
}
func(s *Service)Acknowledge(ctx context.Context,in AcknowledgeInput)error{
 if s.options.Pool==nil{return ErrUnavailable};if in.ActorID==""||in.Generation<1||in.ExpectedVersion<1||!eventReference.MatchString(in.AlertID)||!validReason(in.Reason){return ErrInvalid}
 now:=s.options.Now().UTC();tx,err:=s.options.Pool.Begin(ctx);if err!=nil{return ErrUnavailable};defer rollback(tx)
 var roles []string;var generation int64;var disabled bool
 err=tx.QueryRow(ctx,`SELECT roles,generation,disabled FROM notitle.admin_users WHERE id=$1 FOR UPDATE`,in.ActorID).Scan(&roles,&generation,&disabled);if errors.Is(err,pgx.ErrNoRows){return ErrUnauthorized};if err!=nil{return ErrUnavailable};owner:=false;for _,role:=range roles{if role=="owner"{owner=true}}
 if disabled||generation!=in.Generation||!owner{return ErrUnauthorized}
 var active bool;err=tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.admin_sessions WHERE token_hash=$1 AND admin_id=$2 AND admin_generation=$3 AND created_at<=$4 AND absolute_expires_at>$4 AND last_seen_at>$4-interval '15 minutes')`,in.SessionHash[:],in.ActorID,in.Generation,now).Scan(&active);if err!=nil{return ErrUnavailable};if !active{return ErrUnauthorized}
 tag,err:=tx.Exec(ctx,`UPDATE notitle.operational_alerts SET state='acknowledged',acknowledged_at=$4,acknowledged_by=$3,generation=generation+1 WHERE event_ref=$1 AND generation=$2 AND state='open'`,in.AlertID,in.ExpectedVersion,in.ActorID,now);if err!=nil{return ErrUnavailable};if tag.RowsAffected()!=1{return ErrConflict}
 if _,err=tx.Exec(ctx,`UPDATE notitle.operational_alert_deliveries SET state='cancelled',lease_token=NULL,lease_until=NULL WHERE event_ref=$1 AND state IN ('pending','leased')`,in.AlertID);err!=nil{return ErrUnavailable}
 var id[16]byte;if _,err=rand.Read(id[:]);err!=nil{return ErrUnavailable};id[6]=(id[6]&15)|64;id[8]=(id[8]&63)|128
 if _,err=tx.Exec(ctx,`INSERT INTO notitle.admin_audit(id,admin_id,action,subject_ref,reason,result,created_at) VALUES($1,$2,'operations_alert_ack',$3,$4,'success',$5)`,hex.EncodeToString(id[:]),in.ActorID,in.AlertID,in.Reason,now);err!=nil{return ErrUnavailable}
 if tx.Commit(ctx)!=nil{return ErrUnavailable};return nil
}
func validReason(reason string)bool{if !utf8.ValidString(reason)||len(reason)>4000||utf8.RuneCountInString(reason)>1000||len(strings.TrimSpace(reason))<5{return false};for _,r:=range reason{if unicode.IsControl(r)&&r!='\n'&&r!='\t'||r>=0x202a&&r<=0x202e||r>=0x2066&&r<=0x2069{return false}};return true}

func rollback(tx pgx.Tx){ctx,cancel:=context.WithTimeout(context.Background(),2*time.Second);defer cancel();_=tx.Rollback(ctx)}
