package observability

import (
 "context"
 "runtime"
 "sync"
 "time"
)
type Service struct { options Options; mu sync.RWMutex; latest Snapshot; highCPU time.Time; histogram [7]uint64; failures uint64 }
func New(options Options)*Service{if options.Now==nil{options.Now=time.Now};return &Service{options:options}}
func(s *Service)Ready(ctx context.Context)error{s.mu.RLock();latest:=s.latest;s.mu.RUnlock();if !latest.Ready||!fresh(latest.SampledAt,s.options.Now(),45*time.Second){return ErrUnavailable};return ctx.Err()}
func(s *Service)Snapshot(ctx context.Context)(Snapshot,error){
 s.mu.RLock();v:=s.latest;v.Gates=append([]string(nil),v.Gates...);v.Conditions=append([]Condition(nil),v.Conditions...);s.mu.RUnlock()
 if v.SampledAt.IsZero(){return Snapshot{},ErrUnavailable};if !fresh(v.SampledAt,s.options.Now(),45*time.Second){v.Ready=false;v.Gates=append(v.Gates,"monitor_sample_stale")}
 if s.options.Pool==nil{return v,ErrUnavailable};alerts,err:=s.listAlerts(ctx);if err!=nil{return Snapshot{},err};v.Alerts=alerts;return v,nil
}
// Run uses independent bounded work even when operational readiness is false:
// missing delivery, staffing or backup evidence must never suppress support.
func(s *Service)Run(ctx context.Context){
 ticker:=time.NewTicker(time.Second);defer ticker.Stop();next:=time.Time{}
 for{now:=s.options.Now().UTC();if !now.Before(next){work,cancel:=context.WithTimeout(ctx,8*time.Second);s.sample(work,now);cancel();next=now.Add(15*time.Second)}
  work,cancel:=context.WithTimeout(ctx,8*time.Second);s.deliverOne(work,now);cancel()
  select{case <-ctx.Done():return;case <-ticker.C:}
 }
}
func(s *Service)sample(ctx context.Context,now time.Time){
 s.mu.RLock();previous:=s.latest;s.mu.RUnlock()
 v:=Snapshot{SampledAt:now,Gates:[]string{},Conditions:[]Condition{},Counts:previous.Counts}
 databaseUnknown:=false;countsUnknown:=false
 var memory runtime.MemStats;runtime.ReadMemStats(&memory);v.Process=ProcessMetrics{HeapBytes:memory.HeapAlloc,HeapInUseBytes:memory.HeapInuse,GCCount:uint64(memory.NumGC),Goroutines:runtime.NumGoroutine()}
 if s.options.Coordinator==nil{v.Gates=append(v.Gates,"coordinator_unavailable")}else{
  start:=time.Now();probe,cancel:=context.WithTimeout(ctx,500*time.Millisecond);owner,err:=s.options.Coordinator.Snapshot(probe);cancel();elapsed:=time.Since(start).Milliseconds()
  if err!=nil{s.failures++;v.Gates=append(v.Gates,"coordinator_unavailable")}else{v.Realtime=RealtimeMetrics{Matching:owner.MatchMetrics,Connected:owner.Connected,Waiting:owner.Waiting,Calls:owner.AudioCalls,Cleanup:owner.AudioCleanup,Retained:owner.Retained,ConnectedLimit:owner.Limits.Connected,WaitingLimit:owner.Limits.Waiting,CallLimit:owner.Limits.AudioCalls,ProbeMS:elapsed};index:=6;for i,bound:=range []int64{5,10,25,50,100,250}{if elapsed<=bound{index=i;break}};s.histogram[index]++}
 };v.Realtime.ProbeFailures=s.failures;v.Realtime.ProbeHistogram=s.histogram
 if s.options.Pool==nil{databaseUnknown=true;v.Gates=append(v.Gates,"database_unavailable")}else{
  stats:=s.options.Pool.Stat();v.Database=DatabaseMetrics{Acquired:stats.AcquiredConns(),Total:stats.TotalConns(),Maximum:stats.MaxConns(),AcquireCount:stats.AcquireCount(),EmptyAcquireCount:stats.EmptyAcquireCount(),AcquireDurationMS:stats.AcquireDuration().Milliseconds()}
  if s.readDatabase(ctx,&v.Database,now)!=nil{v.Gates=append(v.Gates,"database_metrics_unavailable");databaseUnknown=true}
 }
 if s.options.Counts!=nil{counts,err:=s.options.Counts(ctx,now);if err!=nil{v.Gates=append(v.Gates,"operations_counts_unavailable");countsUnknown=true}else{v.Counts=counts}}else{countsUnknown=true;v.Gates=append(v.Gates,"operations_counts_unavailable")}
 observation,err:=ReadObservation(s.options.ObservationFile,now);if err!=nil{v.Gates=append(v.Gates,"host_observation_unavailable")}else{v.External=observation}
 if s.options.RelayEnabled&&!v.External.RelayEnabled{v.Gates=append(v.Gates,"relay_observation_missing")}
 v.External.RelayEnabled=s.options.RelayEnabled
 if v.External.ClockOffsetMS>2000||v.External.ClockOffsetMS< -2000{v.Gates=append(v.Gates,"host_clock_drift")}
 if s.options.LifecycleReady==nil||s.options.LifecycleReady(ctx)!=nil{v.Gates=append(v.Gates,"lifecycle_replay_unavailable")}
 if v.Counts.DeliveryFailures>0{v.Gates=append(v.Gates,"operator_delivery_unhealthy")}
 if s.options.ClockReady==nil||s.options.ClockReady(ctx)!=nil{v.Gates=append(v.Gates,"clock_unhealthy")}
 if s.options.Receiver==nil||!s.options.Receiver.Configured("primary"){v.Gates=append(v.Gates,"primary_receiver_missing")}
 if s.options.Receiver==nil||!s.options.Receiver.Configured("backup"){v.Gates=append(v.Gates,"backup_receiver_missing")}
 if !s.options.CoverageApproved{v.Gates=append(v.Gates,"operator_coverage_unapproved")}
 if !fresh(v.External.PrimaryDrillAt,now,90*24*time.Hour){v.Gates=append(v.Gates,"primary_delivery_drill_missing")}
 if !fresh(v.External.BackupDrillAt,now,90*24*time.Hour){v.Gates=append(v.Gates,"backup_delivery_drill_missing")}
 if !fresh(v.External.ExternalProbeAt,now,2*time.Minute)||!v.External.ExternalProbeHealthy{v.Gates=append(v.Gates,"external_availability_unproven")}
 if !fresh(v.External.RecoverableWALAt,now,15*time.Minute){v.Gates=append(v.Gates,"recoverable_wal_lag")}
 if !fresh(v.External.DeletionJournalRecoverableAt,now,15*time.Minute){v.Gates=append(v.Gates,"deletion_journal_recovery_lag")}
 if !fresh(v.External.HoldJournalRecoverableAt,now,15*time.Minute){v.Gates=append(v.Gates,"hold_journal_recovery_lag")}
 if v.External.HostCPUPercent>=70{if s.highCPU.IsZero(){s.highCPU=now}}else{s.highCPU=time.Time{}}
 if s.options.Pool!=nil{days,approved:=s.retentionDays("metrics",now);if !approved{v.Gates=append(v.Gates,"aggregate_retention_unapproved")}else if s.saveMetric(ctx,v,days)!=nil{v.Gates=append(v.Gates,"aggregate_history_unavailable")}}
 v.Conditions=evaluate(v,!s.highCPU.IsZero()&&now.Sub(s.highCPU)>=15*time.Minute,now)
 // A failed source cannot resolve previously observed active incidents.
 for i,c:=range v.Conditions { uncertain:=databaseUnknown&&(c.Code=="ungranted_captures"||c.Code=="overdue_jobs"||c.Code=="dead_jobs")||countsUnknown&&(c.Code=="urgent_cases"||c.Code=="overdue_cases"||c.Code=="overdue_jobs"||c.Code=="dead_jobs"||c.Code=="deletion_failure"||c.Code=="privacy_overdue");if uncertain{for _,old:=range previous.Conditions{if old.Code==c.Code&&old.Active{v.Conditions[i].Active=true}}} }
 durableConditions:=make([]Condition,0,len(v.Conditions));for _,c:=range v.Conditions{unknown:=databaseUnknown&&(c.Code=="ungranted_captures"||c.Code=="overdue_jobs"||c.Code=="dead_jobs")||countsUnknown&&(c.Code=="urgent_cases"||c.Code=="overdue_cases"||c.Code=="overdue_jobs"||c.Code=="dead_jobs"||c.Code=="deletion_failure"||c.Code=="privacy_overdue");if !unknown{durableConditions=append(durableConditions,c)}}
 if s.options.Pool!=nil{if s.syncAlerts(ctx,durableConditions,now)!=nil{v.Gates=append(v.Gates,"alert_outbox_unavailable");for i:=range v.Conditions{if v.Conditions[i].Code=="operations_gate"{v.Conditions[i].Active=true}}}}
 v.Ready=len(v.Gates)==0;s.mu.Lock();s.latest=v;s.mu.Unlock()
}
func evaluate(v Snapshot,sustainedCPU bool,now time.Time)[]Condition{
 stale:=len(v.Gates)>0;poolPressure:=v.Database.Maximum>0&&v.Database.Acquired*10>=v.Database.Maximum*9
 return []Condition{
  {"operations_gate","urgent",stale},
  {"capacity_connections","warning",v.Realtime.Connected>=140},{"capacity_calls","warning",v.Realtime.Calls>=18},
  {"owner_latency","warning",v.Realtime.ProbeMS>100},{"database_pool","warning",poolPressure},
  {"host_cpu","warning",sustainedCPU},{"host_memory","warning",v.External.HostMemoryPercent>=75},
  {"host_disk","warning",v.External.DiskUsedPercent>=70||v.External.DiskGrowthDays>0&&v.External.DiskGrowthDays<30},
  {"clock_drift","urgent",v.External.ClockOffsetMS>2000||v.External.ClockOffsetMS< -2000},
  {"backup_wal","urgent",!fresh(v.External.RecoverableWALAt,now,15*time.Minute)},
  {"backup_holds","urgent",!fresh(v.External.HoldJournalRecoverableAt,now,15*time.Minute)},
  {"backup_deletions","urgent",!fresh(v.External.DeletionJournalRecoverableAt,now,15*time.Minute)},
  {"urgent_cases","urgent",v.Counts.UrgentCases>0},{"overdue_cases","urgent",v.Counts.OverdueCases>0},
  {"ungranted_captures","urgent",v.Database.UngrantedCaptures>0},
  {"overdue_jobs","warning",v.Counts.OverdueJobs+v.Database.OverdueJobs>0},
  {"dead_jobs","urgent",v.Counts.DeadJobs+v.Database.DeadJobs>0},{"deletion_failure","urgent",v.Counts.DeletionFailures>0},
  {"privacy_overdue","urgent",v.Counts.PrivacyOverdue>0},
  {"relay_unhealthy","urgent",v.External.RelayEnabled&&(!v.External.RelayReady||!fresh(v.External.RelayObservedAt,now,10*time.Second))},
  {"relay_loss","warning",v.External.RelayEnabled&&v.External.RelayPacketLossPercent>2},
  {"transfer_forecast","warning",v.External.TransferAllowanceBytes>0&&float64(v.External.TransferProjectedBytes)>=float64(v.External.TransferAllowanceBytes)*0.8},
 }
}
func allowedCode(code string)bool{if code=="case_attention"{return true};for _,v:=range evaluate(Snapshot{},false,time.Now()){if v.Code==code{return true}};return false}

func(s *Service)retentionDays(purpose string,now time.Time)(int,bool){if s.options.Retention==nil{return 0,false};days,approved:=s.options.Retention(purpose,now);return days,approved&&days>=1&&days<=36525}
