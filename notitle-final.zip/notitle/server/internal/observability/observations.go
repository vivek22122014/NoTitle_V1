package observability

import (
 "bytes"
 "encoding/json"
 "io"
 "math"
 "os"
 "path/filepath"
 "time"
)
// The host collector is a trusted control input. Strict mode/size/type checks
// reject world-readable, symlinked, partial or unexpected records. Collector
// writes a same-directory temporary 0600 file and atomically renames it.
func ReadObservation(path string,now time.Time)(ExternalObservation,error){
 var out ExternalObservation
 if !filepath.IsAbs(path)||filepath.Clean(path)!=path{return out,ErrInvalid}
 before,err:=os.Lstat(path);if err!=nil||!before.Mode().IsRegular()||before.Mode().Perm()&0077!=0||before.Size()>16384{return out,ErrUnavailable}
 file,err:=os.Open(path);if err!=nil{return out,ErrUnavailable};defer file.Close()
 after,err:=file.Stat();if err!=nil||!os.SameFile(before,after)||!after.Mode().IsRegular()||after.Mode().Perm()&0077!=0{return out,ErrUnavailable}
 raw,err:=io.ReadAll(io.LimitReader(file,16385));if err!=nil||len(raw)>16384{return out,ErrUnavailable}
 if !uniqueObservationKeys(raw){return ExternalObservation{},ErrInvalid}
 dec:=json.NewDecoder(bytes.NewReader(raw));dec.DisallowUnknownFields();if dec.Decode(&out)!=nil{return ExternalObservation{},ErrInvalid};var trailing any;if dec.Decode(&trailing)!=io.EOF{return ExternalObservation{},ErrInvalid}
 if !validObservation(out,now){return ExternalObservation{},ErrInvalid};return out,nil
}
func validObservation(v ExternalObservation,now time.Time)bool{
 for _,x:=range []float64{v.HostCPUPercent,v.HostMemoryPercent,v.DiskUsedPercent,v.CPUStealPercent,v.RelayPacketLossPercent}{if math.IsNaN(x)||math.IsInf(x,0)||x<0||x>100{return false}}
 if math.IsNaN(v.DiskGrowthDays)||math.IsInf(v.DiskGrowthDays,0)||v.DiskGrowthDays<0||v.DiskGrowthDays>36500||v.RelayAllocations<0||v.RelayAllocations>100000{return false}
 if !fresh(v.ObservedAt,now,2*time.Minute){return false}
 for _,at:=range []time.Time{v.RecoverableWALAt,v.DeletionJournalRecoverableAt,v.HoldJournalRecoverableAt,v.ExternalProbeAt,v.RelayObservedAt,v.PrimaryDrillAt,v.BackupDrillAt}{if at.After(now.Add(5*time.Second)){return false}}
 return true
}
func fresh(at,now time.Time,maxAge time.Duration)bool{return !at.IsZero()&&!at.After(now.Add(5*time.Second))&&!at.Before(now.Add(-maxAge))}

func uniqueObservationKeys(raw []byte)bool{
 dec:=json.NewDecoder(bytes.NewReader(raw));token,err:=dec.Token();if err!=nil||token!=json.Delim('{'){return false};seen:=map[string]bool{}
 for dec.More(){key,err:=dec.Token();if err!=nil{return false};name,ok:=key.(string);if !ok||seen[name]{return false};seen[name]=true;var value json.RawMessage;if dec.Decode(&value)!=nil{return false}}
 if _,err=dec.Token();err!=nil{return false}
 for _,key:=range []string{"observed_at","host_cpu_percent","host_memory_percent","disk_used_percent","disk_growth_days","cpu_steal_percent","clock_offset_ms","relay_enabled","transfer_projected_bytes","transfer_allowance_bytes"}{if !seen[key]{return false}}
 return true
}
