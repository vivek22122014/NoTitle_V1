package observability

import (
 "context"
 "encoding/json"
 "net/http"
 "net/http/httptest"
 "net/netip"
 "os"
 "path/filepath"
 "strings"
 "testing"
 "time"
)
func TestMissingEvidenceCannotShowReady(t *testing.T){now:=time.Unix(1800000000,0);s:=New(Options{Now:func()time.Time{return now}});if s.Ready(context.Background())==nil{t.Fatal("unsampled source must be unavailable")};v:=Snapshot{SampledAt:now,Ready:true};s.latest=v;if s.Ready(context.Background())!=nil{t.Fatal("fresh allowed snapshot")};s.options.Now=func()time.Time{return now.Add(time.Minute)};if s.Ready(context.Background())==nil{t.Fatal("stale monitor must become unavailable")}}
func TestObservationRejectsStaleUnknownUnsafeAndFuture(t *testing.T){
 now:=time.Unix(1800000000,0);path:=filepath.Join(t.TempDir(),"health.json");v:=ExternalObservation{ObservedAt:now,DiskGrowthDays:100};raw,_:=json.Marshal(v);if os.WriteFile(path,raw,0600)!=nil{t.Fatal("write")};if _,e:=ReadObservation(path,now);e!=nil{t.Fatal(e)}
 if os.Chmod(path,0644)!=nil{t.Fatal("chmod")};if _,e:=ReadObservation(path,now);e==nil{t.Fatal("public file accepted")};_=os.Chmod(path,0600)
 if _,e:=ReadObservation(path,now.Add(3*time.Minute));e==nil{t.Fatal("stale sample accepted")}
 raw=append(raw[:len(raw)-1],[]byte(`,"account_id":"secret"}`)...);_=os.WriteFile(path,raw,0600);if _,e:=ReadObservation(path,now);e==nil{t.Fatal("unknown identifier accepted")}
 v.ObservedAt=now.Add(time.Minute);raw,_=json.Marshal(v);_=os.WriteFile(path,raw,0600);if _,e:=ReadObservation(path,now);e==nil{t.Fatal("future observation accepted")}
 target:=filepath.Join(t.TempDir(),"target");_=os.WriteFile(target,raw,0600);_=os.Remove(path);if os.Symlink(target,path)==nil{if _,e:=ReadObservation(path,now);e==nil{t.Fatal("symlink accepted")}}
}
func TestBoundedReceiverRejectsPrivateDestinations(t *testing.T){for _,ip:=range []string{"127.0.0.1","::1","169.254.169.254","10.0.0.1","::ffff:10.1.1.1","100.64.0.1","198.18.0.2","2001:db8::1"}{if publicIP(netip.MustParseAddr(ip)){t.Fatalf("private destination %s accepted",ip)}};if !publicIP(netip.MustParseAddr("8.8.8.8")){t.Fatal("public destination rejected")}
 for _,address:=range []string{"http://example.com/","https://user:password@example.com/","https://example.com/?token=a","https://example.com/#fragment","https://127.0.0.1/","https://example.com:9443/"}{if _,e:=NewReceiver(ReceiverConfig{PrimaryURL:address,PrimaryToken:[]byte(strings.Repeat("s",32))});e==nil{t.Fatalf("unsafe URL accepted %s",address)}}
}
func TestReceiverSendsOnlyOpaqueEnvelopeAndIgnoresResponseBody(t *testing.T){
 var got Envelope;calls:=0;server:=httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){calls++;if r.Header.Get("Authorization")!="Bearer protected-token"{t.Error("missing token")};if r.Header.Get("Idempotency-Key")!="0123456789abcdef0123456789abcdef:backup"{t.Error("stable receiver key missing")};dec:=json.NewDecoder(r.Body);dec.DisallowUnknownFields();if dec.Decode(&got)!=nil{t.Error("invalid envelope")};w.WriteHeader(http.StatusAccepted);_,_=w.Write([]byte(`{"acknowledged":true,"secret":"must-be-ignored"}`))}));defer server.Close()
 // Test-only injected httptest transport never weakens public constructor.
 receiver:=&HTTPReceiver{endpoints:map[string]endpoint{"backup":{server.URL,"protected-token"}},client:server.Client()};input:=Envelope{EventRef:"0123456789abcdef0123456789abcdef",Code:"case_attention",Severity:"urgent",OpenedAt:time.Unix(1800000000,0)}
 if err:=receiver.Send(context.Background(),"backup",input);err!=nil{t.Fatal(err)};if got.EventRef!=input.EventRef||got.Code!=input.Code||got.Severity!=input.Severity||!got.OpenedAt.Equal(input.OpenedAt)||calls!=1{t.Fatal("wrong envelope")}
 input.Code="/private/user/alice";if receiver.Send(context.Background(),"backup",input)==nil||calls!=1{t.Fatal("unbounded label reached receiver")}
}
func TestThresholdsUseRecoverablePointAndMonthlyForecast(t *testing.T){now:=time.Unix(1800000000,0);v:=Snapshot{Realtime:RealtimeMetrics{Connected:140,Calls:18},External:ExternalObservation{RecoverableWALAt:now.Add(-16*time.Minute),DeletionJournalRecoverableAt:now,TransferAllowanceBytes:100,TransferProjectedBytes:80}};conditions:=evaluate(v,false,now);active:=map[string]bool{};for _,c:=range conditions{active[c.Code]=c.Active};if !active["backup_wal"]||active["backup_deletions"]||!active["capacity_connections"]||!active["capacity_calls"]||!active["transfer_forecast"]{t.Fatal("threshold lost")}}
func TestRetriesRemainFiniteAndJittered(t *testing.T){for attempt:=-2;attempt<100;attempt++{d:=RetryDelay("opaque-event-ref-123",attempt);if d<5*time.Second||d>310*time.Second{t.Fatalf("unbounded retry %v",d)}}}
func TestRetentionRequiresReviewedFinitePolicy(t *testing.T){now:=time.Now();s:=New(Options{});if _,ok:=s.retentionDays("metrics",now);ok{t.Fatal("missing retention approval allowed persistence")};for _,days:=range []int{-1,0,36526}{s.options.Retention=func(string,time.Time)(int,bool){return days,true};if _,ok:=s.retentionDays("metrics",now);ok{t.Fatal("unbounded expiry accepted")}};s.options.Retention=func(string,time.Time)(int,bool){return 395,true};if days,ok:=s.retentionDays("metrics",now);!ok||days!=395{t.Fatal("reviewed retention rejected")}}
func TestObservationDuplicateKeysAreRejected(t *testing.T){now:=time.Now().UTC();raw,_:=json.Marshal(ExternalObservation{ObservedAt:now});raw=append(raw[:len(raw)-1],[]byte(`,"host_cpu_percent":0}`)...);if uniqueObservationKeys(raw){t.Fatal("ambiguous duplicate observation accepted")}}
