// Package observability provides bounded private aggregates. It never accepts
// user labels, demographic dimensions, paths, message content or session IDs.
package observability

import (
 "context"
 "errors"
 "time"
 "github.com/jackc/pgx/v5/pgxpool"
 "notitle/internal/coordinator"
)
var (
 ErrUnavailable=errors.New("operations monitoring unavailable")
 ErrInvalid=errors.New("invalid operations request")
 ErrUnauthorized=errors.New("operations authorization required")
 ErrConflict=errors.New("operations alert changed")
)
type Coordinator interface { Snapshot(context.Context)(coordinator.Snapshot,error) }
type AggregateCounts struct { UrgentCases,OverdueCases,OverdueJobs,DeadJobs,DeletionFailures,PrivacyOverdue,DeliveryFailures int64 }
type ProcessMetrics struct { HeapBytes,HeapInUseBytes,GCCount uint64; Goroutines int }
type DatabaseMetrics struct { Acquired,Total,Maximum int32; AcquireCount,EmptyAcquireCount int64; AcquireDurationMS int64; UngrantedCaptures,OverdueJobs,DeadJobs int64 }
type RealtimeMetrics struct { Matching coordinator.MatchMetrics; Connected,Waiting,Calls,Cleanup,Retained int; ConnectedLimit,WaitingLimit,CallLimit int; ProbeMS int64; ProbeFailures uint64; ProbeHistogram [7]uint64 }
// Fixed boundaries [5,10,25,50,100,250,+Inf] ms. This is owner probe roundtrip,
// not request latency, queue wait, end-to-end message latency or a capacity proof.
type ExternalObservation struct {
 ObservedAt time.Time `json:"observed_at"`
 HostCPUPercent float64 `json:"host_cpu_percent"`
 HostMemoryPercent float64 `json:"host_memory_percent"`
 DiskUsedPercent float64 `json:"disk_used_percent"`
 DiskGrowthDays float64 `json:"disk_growth_days"`
 CPUStealPercent float64 `json:"cpu_steal_percent"`
 ClockOffsetMS int64 `json:"clock_offset_ms"`
 RecoverableWALAt time.Time `json:"recoverable_wal_at"`
 HoldJournalRecoverableAt time.Time `json:"hold_journal_recoverable_at"`
 DeletionJournalRecoverableAt time.Time `json:"deletion_journal_recoverable_at"`
 ExternalProbeAt time.Time `json:"external_probe_at"`
 ExternalProbeHealthy bool `json:"external_probe_healthy"`
 RelayEnabled bool `json:"relay_enabled"`
 RelayObservedAt time.Time `json:"relay_observed_at"`
 RelayReady bool `json:"relay_ready"`
 RelayAllocations int64 `json:"relay_allocations"`
 RelayControlFailures uint64 `json:"relay_control_failures"`
 RelayPacketLossPercent float64 `json:"relay_packet_loss_percent"`
 TransferProjectedBytes uint64 `json:"transfer_projected_bytes"`
 TransferAllowanceBytes uint64 `json:"transfer_allowance_bytes"`
 PrimaryDrillAt time.Time `json:"primary_drill_at"`
 BackupDrillAt time.Time `json:"backup_drill_at"`
}
type Condition struct { Code,Severity string; Active bool }
type Alert struct { ID,Code,Severity,State string; OpenedAt,TouchedAt time.Time; AcknowledgedAt *time.Time; Version int64; Primary,Backup string }
type Snapshot struct {
 SampledAt time.Time; Ready bool; Gates []string
 Process ProcessMetrics; Database DatabaseMetrics; Realtime RealtimeMetrics
 External ExternalObservation; Counts AggregateCounts; Conditions []Condition; Alerts []Alert
}
type AcknowledgeInput struct { ActorID string; Generation int64; SessionHash [32]byte; Reason,AlertID string; ExpectedVersion int64 }
type Options struct {
 Pool *pgxpool.Pool; Coordinator Coordinator
 ClockReady func(context.Context)error
 LifecycleReady func(context.Context)error
 Counts func(context.Context,time.Time)(AggregateCounts,error)
 ObservationFile string
 Receiver Receiver
 CoverageApproved bool
 RelayEnabled bool
 Environment string
 Retention func(string,time.Time)(int,bool)
 RetentionVersion string
 Now func()time.Time
}
type Envelope struct { EventRef string `json:"event_ref"`; Code string `json:"code"`; Severity string `json:"severity"`; OpenedAt time.Time `json:"opened_at"` }
type Receiver interface { Send(context.Context,string,Envelope)error; Configured(string)bool }
