// Package realtimeruntime publishes dependency safety to the one live-state
// owner. Database I/O stays outside the coordinator and WebSocket reader loops.
package realtimeruntime

import (
	"context"
	"errors"
	"log/slog"
	"sync/atomic"
	"time"
)

type Checker interface { Ready(context.Context) error }
type Owner interface { HealthOutage(context.Context, bool) error }
type Runtime struct {
	checks []Checker
	owner Owner
	logger *slog.Logger
	ready atomic.Bool
}

func New(owner Owner, logger *slog.Logger, checks ...Checker) *Runtime {
	return &Runtime{owner: owner, logger: logger, checks: checks}
}
func (r *Runtime) Ready(ctx context.Context) error {
	if ctx.Err() != nil || !r.ready.Load() { return errors.New("realtime dependencies unavailable") }
	return nil
}
func (r *Runtime) probe(ctx context.Context) {
	probe, cancel := context.WithTimeout(ctx, time.Second)
	healthy := len(r.checks) > 0
	for _, check := range r.checks {
		if check.Ready(probe) != nil { healthy = false; break }
	}
	cancel()
	if ctx.Err() != nil { r.ready.Store(false); return }
	// Publishing safety is a bounded actor command; failure keeps admission
	// closed. The owner's independent authorization leases also expire.
	command, cancel := context.WithTimeout(ctx, time.Second)
	if err := r.owner.HealthOutage(command, !healthy); err != nil { healthy = false }
	cancel()
	wasHealthy := r.ready.Swap(healthy)
	if wasHealthy != healthy {
		if healthy { r.logger.Info("realtime_dependencies_ready") } else { r.logger.Warn("realtime_dependencies_unavailable") }
	}
}
func (r *Runtime) Run(ctx context.Context) {
	defer r.ready.Store(false)
	r.probe(ctx)
	ticker := time.NewTicker(2*time.Second)
	defer ticker.Stop()
	for {
		select { case <-ctx.Done(): return; case <-ticker.C: r.probe(ctx) }
	}
}
