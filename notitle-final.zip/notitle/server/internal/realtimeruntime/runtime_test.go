package realtimeruntime

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"testing"
)

type checker struct { err error }
func (c *checker) Ready(context.Context) error { return c.err }
type owner struct { outage bool; err error; calls int }
func (o *owner) HealthOutage(_ context.Context, outage bool) error { o.outage=outage; o.calls++; return o.err }

func TestSafetyProbeFailsClosedAndPublishesRecovery(t *testing.T) {
	db, replay, actor := &checker{}, &checker{}, &owner{}
	r := New(actor,slog.New(slog.NewTextHandler(io.Discard,nil)),db,replay)
	ctx := context.Background()
	if r.Ready(ctx) == nil { t.Fatal("realtime opened before dependency checks") }
	r.probe(ctx)
	if r.Ready(ctx) != nil || actor.outage { t.Fatal("healthy dependencies did not enable admission") }
	db.err = errors.New("database unavailable")
	r.probe(ctx)
	if r.Ready(ctx) == nil || !actor.outage { t.Fatal("dependency outage did not close admission") }
	db.err = nil; replay.err = errors.New("restore incomplete")
	r.probe(ctx)
	if r.Ready(ctx) == nil || !actor.outage { t.Fatal("replay barrier bypassed") }
	replay.err = nil; actor.err = errors.New("mailbox unavailable")
	r.probe(ctx)
	if r.Ready(ctx) == nil { t.Fatal("failed safety publication opened admission") }
	actor.err = nil
	r.probe(ctx)
	if r.Ready(ctx) != nil || actor.outage { t.Fatal("recovered dependencies stayed unavailable") }
}
