// Package holdlog durably records complete legal-hold snapshots independently
// of database rollback. This establishes local fsync durability only; encrypted
// off-host replication and recovery drills remain deployment requirements.
package holdlog

import (
    "errors"
    "strings"
    "time"
    "unicode"
    "unicode/utf8"
)

var (
    ErrUnavailable = errors.New("hold journal unavailable")
    ErrInvalid = errors.New("invalid hold journal record")
    ErrConflict = errors.New("conflicting hold journal record")
    ErrClosed = errors.New("hold journal closed")
)

// Each event is a complete versioned snapshot. Replay order is immaterial: the
// database accepts only increasing revisions, including release snapshots.
type Record struct {
    EventID string `json:"event_id"`
    ID string `json:"id"`
    Revision int64 `json:"revision"`
    ScopeKind string `json:"scope_kind"`
    ScopeRef string `json:"scope_ref"`
    Reason string `json:"reason"`
    ApproverID string `json:"approver_id"`
    ReviewAt time.Time `json:"review_at"`
    RecordedAt time.Time `json:"recorded_at"`
    ReleasedAt *time.Time `json:"released_at,omitempty"`
    ReleaseReason string `json:"release_reason,omitempty"`
}

func Valid(r Record) bool {
    if !validUUID(r.EventID) || !validUUID(r.ID) || !validUUID(r.ApproverID) || r.Revision < 1 || !ValidReason(r.Reason) || r.RecordedAt.IsZero() || r.ReviewAt.IsZero() { return false }
    switch r.ScopeKind { case "account", "report", "financial": if !validUUID(r.ScopeRef){return false}; case "operations_case": if len(r.ScopeRef)!=32{return false};for _,c:=range r.ScopeRef{if !(c>='0'&&c<='9'||c>='a'&&c<='f'){return false}}; default: return false }
    if !utc(r.RecordedAt) || !utc(r.ReviewAt) || r.ReviewAt.Before(r.RecordedAt) || r.ReviewAt.After(r.RecordedAt.AddDate(1,0,0)) { return false }
    if r.ReleasedAt != nil { return utc(*r.ReleasedAt) && !r.ReleasedAt.Before(r.RecordedAt) && ValidReason(r.ReleaseReason) }
    return r.ReleaseReason == ""
}

func utc(t time.Time) bool { _, offset := t.Zone(); return offset == 0 && t.Year() >= 1 && t.Year() <= 9999 }
func ValidReason(s string) bool {
    if !utf8.ValidString(s) || len(strings.TrimSpace(s)) < 5 || utf8.RuneCountInString(s) > 1000 { return false }
    for _, r := range s { if unicode.IsControl(r) || r >= 0x202a && r <= 0x202e || r >= 0x2066 && r <= 0x2069 { return false } }
    return true
}

func validUUID(value string) bool {
	if len(value) != 36 {
		return false
	}
	for i := range value {
		c := value[i]
		if i == 8 || i == 13 || i == 18 || i == 23 {
			if c != '-' {
				return false
			}
		} else if !(c >= '0' && c <= '9' || c >= 'a' && c <= 'f') {
			return false
		}
	}
	return true
}

