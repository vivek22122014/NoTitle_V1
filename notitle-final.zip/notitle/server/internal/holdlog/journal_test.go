//go:build linux

package holdlog

import (
    "context"
    "errors"
    "os"
    "path/filepath"
    "testing"
    "time"
)

func fixture()Record{at:=time.Date(2026,10,9,0,0,0,0,time.UTC);return Record{EventID:"11111111-1111-4111-8111-111111111111",ID:"22222222-2222-4222-8222-222222222222",Revision:1,ScopeKind:"account",ScopeRef:"33333333-3333-4333-8333-333333333333",Reason:"Preservation for a reviewed legal case",ApproverID:"44444444-4444-4444-8444-444444444444",RecordedAt:at,ReviewAt:at.Add(24*time.Hour)}}
func TestHoldJournalDurabilityAndIdempotency(t *testing.T){j,e:=Open(filepath.Join(t.TempDir(),"journal"));if e!=nil{t.Fatal(e)};defer j.Close();h:=fixture();ctx:=context.Background();if e=j.Append(ctx,h);e!=nil{t.Fatal(e)};if e=j.Append(ctx,h);e!=nil{t.Fatal(e)};seen:=0;if e=j.Replay(ctx,func(_ context.Context,r Record)error{seen++;if r.ID!=h.ID||r.Reason!=h.Reason{t.Fatal("hold changed")};return nil});e!=nil{t.Fatal(e)};if seen!=1{t.Fatal("duplicate event")};h.Reason="Attempted rewrite of an approved hold";if !errors.Is(j.Append(ctx,h),ErrConflict){t.Fatal("immutable event changed")}}
func TestHoldJournalReleaseIsIndependentSnapshot(t *testing.T){j,e:=Open(filepath.Join(t.TempDir(),"journal"));if e!=nil{t.Fatal(e)};defer j.Close();h:=fixture();h.EventID="55555555-5555-4555-8555-555555555555";h.Revision=2;at:=h.RecordedAt;h.ReleasedAt=&at;h.ReleaseReason="Legal duty fulfilled after review";if e=j.Append(context.Background(),h);e!=nil{t.Fatal(e)};if e=j.Replay(context.Background(),func(_ context.Context,r Record)error{if r.ReleasedAt==nil||r.Revision!=2{t.Fatal("release not replayable")};return nil});e!=nil{t.Fatal(e)}}
func TestHoldJournalMissingFsyncNeverAcknowledges(t *testing.T){j,e:=Open(filepath.Join(t.TempDir(),"journal"));if e!=nil{t.Fatal(e)};defer j.Close();j.syncRecord=func(*os.File)error{return errors.New("disk full")};if !errors.Is(j.Append(context.Background(),fixture()),ErrUnavailable){t.Fatal("acknowledged an unsynced hold")};seen:=0;j.syncRecord=func(f *os.File)error{return f.Sync()};if e=j.Replay(context.Background(),func(context.Context,Record)error{seen++;return nil});e!=nil||seen!=0{t.Fatal("unpublished event became durable")}}
func TestHoldJournalCorruptionAndSymlinkFailClosed(t *testing.T){dir:=filepath.Join(t.TempDir(),"journal");j,e:=Open(dir);if e!=nil{t.Fatal(e)};defer j.Close();h:=fixture();if e=j.Append(context.Background(),h);e!=nil{t.Fatal(e)};path:=filepath.Join(dir,h.EventID+".json");if e=os.WriteFile(path,[]byte("{}\n"),0600);e!=nil{t.Fatal(e)};if !errors.Is(j.Replay(context.Background(),func(context.Context,Record)error{return nil}),ErrUnavailable){t.Fatal("corrupt journal reopened")};parent:=t.TempDir();link:=filepath.Join(parent,"link");if e=os.Symlink(dir,link);e!=nil{t.Fatal(e)};if _,e=Open(link);!errors.Is(e,ErrUnavailable){t.Fatal("symlink journal accepted")}}
func TestHoldJournalExcludesSecondProcessAndInsecureFiles(t *testing.T){dir:=filepath.Join(t.TempDir(),"journal");j,e:=Open(dir);if e!=nil{t.Fatal(e)};defer j.Close();if other,e:=Open(dir);e==nil{other.Close();t.Fatal("two owners")};h:=fixture();if e=j.Append(context.Background(),h);e!=nil{t.Fatal(e)};if e=os.Chmod(filepath.Join(dir,h.EventID+".json"),0644);e!=nil{t.Fatal(e)};if !errors.Is(j.Replay(context.Background(),func(context.Context,Record)error{return nil}),ErrUnavailable){t.Fatal("insecure file replayed")}}
func TestHoldValidationRequiresScopeApprovalDeadlineAndReleaseReason(t *testing.T){good:=fixture();if !Valid(good){t.Fatal("valid fixture rejected")};cases:=[]Record{good,good,good,good};cases[0].ScopeKind="chat";cases[1].ApproverID="";cases[2].ReviewAt=good.RecordedAt.AddDate(2,0,0);cases[3].ReleasedAt=&good.RecordedAt;for _,bad:=range cases{if Valid(bad){t.Fatal("invalid hold accepted")}}}
