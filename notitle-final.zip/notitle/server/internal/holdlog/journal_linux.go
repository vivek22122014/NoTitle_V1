//go:build linux

package holdlog

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"syscall"

)

const (
	maxRecordBytes = 8192
	replayBatchSize = 64
	directoryFlags = syscall.O_RDONLY | syscall.O_DIRECTORY | syscall.O_NOFOLLOW | syscall.O_CLOEXEC
)

type diskRecord struct {
	Version int `json:"version"`
	Tombstone Record `json:"hold"`
}

// Journal has a process-wide filesystem lock as well as a goroutine mutex.
// Only one API process may own the configured directory. All operations remain
// relative to an open directory descriptor, including after directory renames.
type Journal struct {
	mu sync.Mutex
	dir *os.File
	// Keep the two durability barriers injectable for deterministic I/O
	// failure tests. They are private and fixed to fsync by Open.
	syncDirectory func() error
	syncRecord func(*os.File) error
}

// Open securely walks an absolute or relative path without following symlinks.
// Parents must exist. It creates only the final directory component, if absent.
// The final directory must belong to the effective user and have mode 0700.
// Deployments must mount it independently of the PostgreSQL/ordinary backup
// volume; a path alone cannot establish the backup policy or physical isolation.
func Open(path string) (*Journal, error) {
	if path == "" || strings.IndexByte(path, 0) >= 0 {
		return nil, ErrUnavailable
	}
	abs, err := filepath.Abs(path)
	if err != nil || abs == "/" {
		return nil, ErrUnavailable
	}
	fd, err := syscall.Open("/", directoryFlags, 0)
	if err != nil {
		return nil, ErrUnavailable
	}
	parts := strings.Split(strings.TrimPrefix(abs, "/"), "/")
	for i, part := range parts {
		next, openErr := syscall.Openat(fd, part, directoryFlags, 0)
		if openErr != nil && errors.Is(openErr, syscall.ENOENT) && i == len(parts)-1 {
			if mkdirErr := syscall.Mkdirat(fd, part, 0700); mkdirErr != nil && !errors.Is(mkdirErr, syscall.EEXIST) {
				_ = syscall.Close(fd)
				return nil, ErrUnavailable
			}
			// Make creation of the journal directory durable in its parent.
			if syncErr := syscall.Fsync(fd); syncErr != nil {
				_ = syscall.Close(fd)
				return nil, ErrUnavailable
			}
			next, openErr = syscall.Openat(fd, part, directoryFlags, 0)
		}
		_ = syscall.Close(fd)
		if openErr != nil {
			return nil, ErrUnavailable
		}
		fd = next
	}
	var st syscall.Stat_t
	if err := syscall.Fstat(fd, &st); err != nil || st.Mode&07777 != 0700 || st.Uid != uint32(os.Geteuid()) {
		_ = syscall.Close(fd)
		return nil, ErrUnavailable
	}
	if err := syscall.Flock(fd, syscall.LOCK_EX|syscall.LOCK_NB); err != nil {
		_ = syscall.Close(fd)
		return nil, ErrUnavailable
	}
	dir := os.NewFile(uintptr(fd), "hold-journal")
	if dir == nil {
		_ = syscall.Close(fd)
		return nil, ErrUnavailable
	}
	if err := dir.Sync(); err != nil {
		_ = dir.Close()
		return nil, ErrUnavailable
	}
	return &Journal{dir: dir, syncDirectory: dir.Sync, syncRecord: func(f *os.File) error { return f.Sync() }}, nil
}

// Append returns nil only after the record and its directory entry are synced.
// Repeating an event ID is allowed only for precisely the same hold snapshot.
func (j *Journal) Append(ctx context.Context, tombstone Record) error {
	if !validTombstone(tombstone) {
		return ErrInvalid
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	j.mu.Lock()
	defer j.mu.Unlock()
	if j.dir == nil {
		return ErrClosed
	}
	name := tombstone.EventID + ".json"
	existing, err := j.readRecord(name)
	if err == nil {
		if !sameTombstone(existing, tombstone) {
			return ErrConflict
		}
		// A previous call may have crashed after rename but before directory
		// sync. Idempotency must complete that sync before acknowledging.
		if err := j.syncDirectory(); err != nil {
			return ErrUnavailable
		}
		return nil
	}
	if !errors.Is(err, os.ErrNotExist) {
		return ErrUnavailable
	}
	data, err := marshalRecord(tombstone)
	if err != nil {
		return ErrInvalid
	}
	var random [16]byte
	if _, err := rand.Read(random[:]); err != nil {
		return ErrUnavailable
	}
	stage := ".pending-" + hex.EncodeToString(random[:]) + ".tmp"
	fd, err := syscall.Openat(int(j.dir.Fd()), stage, syscall.O_WRONLY|syscall.O_CREAT|syscall.O_EXCL|syscall.O_NOFOLLOW|syscall.O_CLOEXEC, 0600)
	if err != nil {
		return ErrUnavailable
	}
	f := os.NewFile(uintptr(fd), "hold-record")
	published := false
	defer func() {
		_ = f.Close()
		if !published {
			_ = syscall.Unlinkat(int(j.dir.Fd()), stage)
			_ = j.syncDirectory()
		}
	}()
	if n, err := f.Write(data); err != nil || n != len(data) {
		return ErrUnavailable
	}
	if err := j.syncRecord(f); err != nil {
		return ErrUnavailable
	}
	if err := f.Close(); err != nil {
		return ErrUnavailable
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	// The exclusive directory lock prevents another journal process from
	// publishing this ID after the absence check. Mode 0700 excludes other
	// users. Host/root compromise is outside this filesystem trust boundary.
	if err := syscall.Renameat(int(j.dir.Fd()), stage, int(j.dir.Fd()), name); err != nil {
		return ErrUnavailable
	}
	published = true
	// After publication, complete durability even if the request cancels.
	if err := j.syncDirectory(); err != nil {
		return ErrUnavailable
	}
	return nil
}

// Replay invokes apply with each validated hold snapshot while holding the journal
// lock. Callbacks must be idempotent and must not call Journal methods. Entries
// are streamed in bounded batches, sorted within each batch; callers must not
// depend on directory order or timestamp order. Startup must keep identity
// authentication unavailable until Replay succeeds completely.
//
// Atomic publication leaves only complete live records. Orphan staging files
// from a crash are removed; malformed live records, unexpected files, symlinks,
// hard links and insecure permissions fail closed.
func (j *Journal) Replay(ctx context.Context, apply func(context.Context, Record) error) error {
	if apply == nil {
		return ErrInvalid
	}
	j.mu.Lock()
	defer j.mu.Unlock()
	if j.dir == nil {
		return ErrClosed
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	// Cleanup has a separate directory scan. Removing entries while applying
	// live records could invalidate a filesystem's readdir continuation and
	// skip a hold event. The application pass below never changes the directory.
	if err := j.cleanupStages(ctx); err != nil {
		return err
	}
	// Restored files or a prior append that lost its directory-sync response
	// must pass durability barriers before replay may mark the DB job durable.
	if err := j.syncDirectory(); err != nil {
		return ErrUnavailable
	}
	fd, err := syscall.Openat(int(j.dir.Fd()), ".", directoryFlags, 0)
	if err != nil {
		return ErrUnavailable
	}
	scan := os.NewFile(uintptr(fd), "hold-journal-scan")
	defer scan.Close()
	for {
		entries, readErr := scan.ReadDir(replayBatchSize)
		if readErr != nil && !errors.Is(readErr, io.EOF) {
			return ErrUnavailable
		}
		sort.Slice(entries, func(a, b int) bool { return entries[a].Name() < entries[b].Name() })
		for _, entry := range entries {
			if err := ctx.Err(); err != nil {
				return err
			}
			name := entry.Name()
			if isStageName(name) {
				// A filesystem continuation may have skipped another orphan
				// during the cleanup scan. It is never a committed hold event.
				f, err := j.openRecord(name)
				if err != nil {
					return ErrUnavailable
				}
				_ = f.Close()
				continue
			}
			if !strings.HasSuffix(name, ".json") || !validUUID(strings.TrimSuffix(name, ".json")) {
				return ErrUnavailable
			}
			tombstone, err := j.readRecord(name)
			if err != nil {
				return ErrUnavailable
			}
			if err := apply(ctx, tombstone); err != nil {
				// Callback errors may contain database/identifier details.
				return ErrUnavailable
			}
		}
		if errors.Is(readErr, io.EOF) {
			return nil
		}
	}
}

func (j *Journal) cleanupStages(ctx context.Context) error {
	fd, err := syscall.Openat(int(j.dir.Fd()), ".", directoryFlags, 0)
	if err != nil {
		return ErrUnavailable
	}
	scan := os.NewFile(uintptr(fd), "hold-stage-scan")
	defer scan.Close()
	changed := false
	for {
		entries, readErr := scan.ReadDir(replayBatchSize)
		if readErr != nil && !errors.Is(readErr, io.EOF) {
			return ErrUnavailable
		}
		for _, entry := range entries {
			if err := ctx.Err(); err != nil {
				return err
			}
			if !isStageName(entry.Name()) {
				continue
			}
			f, err := j.openRecord(entry.Name())
			if err != nil {
				return ErrUnavailable
			}
			_ = f.Close()
			if err := syscall.Unlinkat(int(j.dir.Fd()), entry.Name()); err != nil {
				return ErrUnavailable
			}
			changed = true
		}
		if errors.Is(readErr, io.EOF) {
			if changed {
				if err := j.syncDirectory(); err != nil {
					return ErrUnavailable
				}
			}
			return nil
		}
	}
}

func (j *Journal) Close() error {
	j.mu.Lock()
	defer j.mu.Unlock()
	if j.dir == nil {
		return nil
	}
	err := j.dir.Close()
	j.dir = nil
	if err != nil {
		return ErrUnavailable
	}
	return nil
}

func (j *Journal) openRecord(name string) (*os.File, error) {
	fd, err := syscall.Openat(int(j.dir.Fd()), name, syscall.O_RDONLY|syscall.O_NOFOLLOW|syscall.O_NONBLOCK|syscall.O_CLOEXEC, 0)
	if err != nil {
		if errors.Is(err, syscall.ENOENT) {
			return nil, os.ErrNotExist
		}
		return nil, ErrUnavailable
	}
	var st syscall.Stat_t
	if err := syscall.Fstat(fd, &st); err != nil || st.Mode&syscall.S_IFMT != syscall.S_IFREG || st.Mode&07777 != 0600 || st.Uid != uint32(os.Geteuid()) || st.Nlink != 1 {
		_ = syscall.Close(fd)
		return nil, ErrUnavailable
	}
	return os.NewFile(uintptr(fd), "hold-record"), nil
}

func (j *Journal) readRecord(name string) (Record, error) {
	var empty Record
	f, err := j.openRecord(name)
	if err != nil {
		return empty, err
	}
	defer f.Close()
	data, err := io.ReadAll(io.LimitReader(f, maxRecordBytes+1))
	if err != nil || len(data) > maxRecordBytes {
		return empty, ErrUnavailable
	}
	var record diskRecord
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&record); err != nil || record.Version != 1 || !validTombstone(record.Tombstone) || name != record.Tombstone.EventID+".json" {
		return empty, ErrUnavailable
	}
	canonical, err := marshalRecord(record.Tombstone)
	// Canonical encoding rejects duplicate fields, trailing documents and any
	// unrecognized representation instead of trusting ambiguous JSON.
	if err != nil || !bytes.Equal(data, canonical) {
		return empty, ErrUnavailable
	}
	if err := j.syncRecord(f); err != nil {
		return empty, ErrUnavailable
	}
	return record.Tombstone, nil
}

func marshalRecord(tombstone Record) ([]byte, error) {
	data, err := json.Marshal(diskRecord{Version: 1, Tombstone: tombstone})
	if err != nil || len(data)+1 > maxRecordBytes {
		return nil, ErrInvalid
	}
	return append(data, '\n'), nil
}

func validTombstone(t Record) bool { return Valid(t) }

func isStageName(name string) bool {
	if len(name) != len(".pending-")+32+len(".tmp") || !strings.HasPrefix(name, ".pending-") || !strings.HasSuffix(name, ".tmp") {
		return false
	}
	for _, c := range name[len(".pending-") : len(".pending-")+32] {
		if !(c >= '0' && c <= '9' || c >= 'a' && c <= 'f') {
			return false
		}
	}
	return true
}

func sameTombstone(a, b Record) bool {
    left, err := marshalRecord(a); if err != nil { return false }
    right, err := marshalRecord(b); return err == nil && bytes.Equal(left, right)
}
