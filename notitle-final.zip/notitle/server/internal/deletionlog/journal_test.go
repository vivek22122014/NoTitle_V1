//go:build linux

package deletionlog

import (
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"notitle/internal/identity"
)

func fixture() identity.Tombstone {
	return identity.Tombstone{
		DeletionID: "12345678-1234-4234-8234-123456789abc",
		AccountID: "22345678-1234-4234-8234-123456789abc",
		AccountGeneration: 2,
		RequestedAt: time.Date(2026, 10, 9, 12, 0, 0, 0, time.UTC),
	}
}

func openTestJournal(t *testing.T) (*Journal, string) {
	t.Helper()
	path := filepath.Join(t.TempDir(), "journal")
	j, err := Open(path)
	if err != nil {
		t.Fatalf("open journal: %v", err)
	}
	t.Cleanup(func() { _ = j.Close() })
	return j, path
}

func TestAppendReplayAndDurableIdempotency(t *testing.T) {
	j, path := openTestJournal(t)
	ctx := context.Background()
	record := fixture()
	if err := j.Append(ctx, record); err != nil {
		t.Fatal(err)
	}
	if err := j.Append(ctx, record); err != nil {
		t.Fatalf("idempotent append: %v", err)
	}
	entries, err := os.ReadDir(path)
	if err != nil || len(entries) != 1 {
		t.Fatalf("expected one durable file, count %d, error %v", len(entries), err)
	}
	info, err := os.Stat(filepath.Join(path, record.DeletionID+".json"))
	if err != nil || info.Mode().Perm() != 0600 {
		t.Fatal("record permissions are not private")
	}
	if err := j.Close(); err != nil {
		t.Fatal(err)
	}
	reopened, err := Open(path)
	if err != nil {
		t.Fatal(err)
	}
	defer reopened.Close()
	var got []identity.Tombstone
	err = reopened.Replay(ctx, func(_ context.Context, item identity.Tombstone) error { got = append(got, item); return nil })
	if err != nil || len(got) != 1 || !sameTombstone(got[0], record) {
		t.Fatalf("replay after reopen did not preserve record: %v", err)
	}
}

func TestExclusiveDirectoryLockAndClose(t *testing.T) {
	j, path := openTestJournal(t)
	if duplicate, err := Open(path); err == nil {
		_ = duplicate.Close()
		t.Fatal("second process journal handle was allowed")
	}
	if err := j.Close(); err != nil {
		t.Fatal(err)
	}
	if err := j.Close(); err != nil {
		t.Fatal("close must be idempotent")
	}
	if err := j.Append(context.Background(), fixture()); !errors.Is(err, ErrClosed) {
		t.Fatalf("closed append: %v", err)
	}
	if err := j.Replay(context.Background(), func(context.Context, identity.Tombstone) error { return nil }); !errors.Is(err, ErrClosed) {
		t.Fatalf("closed replay: %v", err)
	}
}

func TestConflictingDeletionCannotReplaceExistingAccount(t *testing.T) {
	j, _ := openTestJournal(t)
	first := fixture()
	if err := j.Append(context.Background(), first); err != nil {
		t.Fatal(err)
	}
	for _, change := range []func(*identity.Tombstone){
		func(r *identity.Tombstone) { r.AccountID = "32345678-1234-4234-8234-123456789abc" },
		func(r *identity.Tombstone) { r.AccountGeneration++ },
		func(r *identity.Tombstone) { r.RequestedAt = r.RequestedAt.Add(time.Second) },
	} {
		conflict := first
		change(&conflict)
		if err := j.Append(context.Background(), conflict); !errors.Is(err, ErrConflict) {
			t.Fatalf("conflict must not overwrite original: %v", err)
		}
	}
	if err := j.Replay(context.Background(), func(_ context.Context, got identity.Tombstone) error {
		if !sameTombstone(first, got) { t.Fatal("existing tombstone changed") }
		return nil
	}); err != nil {
		t.Fatal(err)
	}
}

func TestInvalidRecordsAndPathTraversalAreRejected(t *testing.T) {
	j, _ := openTestJournal(t)
	for name, change := range map[string]func(*identity.Tombstone){
		"traversal": func(r *identity.Tombstone) { r.DeletionID = "../outside" },
		"uppercase": func(r *identity.Tombstone) { r.DeletionID = strings.ToUpper(r.DeletionID) },
		"missing account": func(r *identity.Tombstone) { r.AccountID = "" },
		"zero generation": func(r *identity.Tombstone) { r.AccountGeneration = 0 },
		"negative generation": func(r *identity.Tombstone) { r.AccountGeneration = -1 },
		"missing time": func(r *identity.Tombstone) { r.RequestedAt = time.Time{} },
		"non UTC": func(r *identity.Tombstone) { r.RequestedAt = r.RequestedAt.In(time.FixedZone("offset", 3600)) },
	} {
		t.Run(name, func(t *testing.T) {
			record := fixture()
			change(&record)
			if err := j.Append(context.Background(), record); !errors.Is(err, ErrInvalid) {
				t.Fatalf("invalid record: %v", err)
			}
		})
	}
}

func TestJournalPathRejectsSymlinkComponentsAndUnsafeModes(t *testing.T) {
	parent := t.TempDir()
	actual := filepath.Join(parent, "actual")
	if err := os.Mkdir(actual, 0700); err != nil { t.Fatal(err) }
	link := filepath.Join(parent, "link")
	if err := os.Symlink(actual, link); err != nil { t.Fatal(err) }
	for _, path := range []string{link, filepath.Join(link, "nested"), filepath.Join(parent, "absent", "nested")} {
		if j, err := Open(path); err == nil { _ = j.Close(); t.Fatal("unsafe path accepted") }
	}
	if err := os.Chmod(actual, 0750); err != nil { t.Fatal(err) }
	if j, err := Open(actual); err == nil { _ = j.Close(); t.Fatal("group readable journal accepted") }
}

func TestReplayRejectsMalformedLiveEntries(t *testing.T) {
	for _, test := range []struct { name string; contents []byte }{
		{"invalid JSON", []byte("{")},
		{"oversized", []byte(strings.Repeat(" ", maxRecordBytes+1))},
		{"extra field", []byte(`{"version":1,"extra":true,"tombstone":{}}`)},
		{"unsupported format", []byte(`{"version":2,"tombstone":{}}`)},
		{"trailing JSON", []byte(`{} {}`)},
	} {
		t.Run(test.name, func(t *testing.T) {
			j, path := openTestJournal(t)
			if err := os.WriteFile(filepath.Join(path, fixture().DeletionID+".json"), test.contents, 0600); err != nil { t.Fatal(err) }
			called := false
			err := j.Replay(context.Background(), func(context.Context, identity.Tombstone) error { called = true; return nil })
			if !errors.Is(err, ErrUnavailable) || called { t.Fatal("invalid record was applied") }
		})
	}
	t.Run("filename mismatch", func(t *testing.T) {
		j, path := openTestJournal(t)
		data, _ := marshalRecord(fixture())
		if err := os.WriteFile(filepath.Join(path, "32345678-1234-4234-8234-123456789abc.json"), data, 0600); err != nil { t.Fatal(err) }
		if err := j.Replay(context.Background(), func(context.Context, identity.Tombstone) error { t.Fatal("mismatched ID applied"); return nil }); !errors.Is(err, ErrUnavailable) { t.Fatal("mismatched filename accepted") }
	})
}

func TestLiveAndStagingSymlinksHardlinksAndDirectoriesFailClosed(t *testing.T) {
	for _, kind := range []string{"live symlink", "staging symlink", "hardlink", "directory", "insecure file", "unexpected file"} {
		t.Run(kind, func(t *testing.T) {
			j, path := openTestJournal(t)
			data, _ := marshalRecord(fixture())
			outside := filepath.Join(t.TempDir(), "outside")
			if err := os.WriteFile(outside, data, 0600); err != nil { t.Fatal(err) }
			target := filepath.Join(path, fixture().DeletionID+".json")
			var err error
			switch kind {
			case "live symlink": err = os.Symlink(outside, target)
			case "staging symlink": err = os.Symlink(outside, filepath.Join(path, ".pending-0123456789abcdef0123456789abcdef.tmp"))
			case "hardlink": err = os.Link(outside, target)
			case "directory": err = os.Mkdir(target, 0700)
			case "insecure file": err = os.WriteFile(target, data, 0644)
			case "unexpected file": err = os.WriteFile(filepath.Join(path, "unknown"), data, 0600)
			}
			if err != nil { t.Fatal(err) }
			if err := j.Replay(context.Background(), func(context.Context, identity.Tombstone) error { t.Fatal("unsafe entry applied"); return nil }); !errors.Is(err, ErrUnavailable) { t.Fatal("unsafe entry accepted") }
			if kind == "live symlink" {
				if err := j.Append(context.Background(), fixture()); !errors.Is(err, ErrUnavailable) { t.Fatal("append followed symlink") }
			}
		})
	}
}

func TestReplayRemovesOnlyRecognizedOrphanStages(t *testing.T) {
	j, path := openTestJournal(t)
	stage := filepath.Join(path, ".pending-0123456789abcdef0123456789abcdef.tmp")
	if err := os.WriteFile(stage, []byte("interrupted write"), 0600); err != nil { t.Fatal(err) }
	if err := j.Replay(context.Background(), func(context.Context, identity.Tombstone) error { t.Fatal("staging file applied"); return nil }); err != nil { t.Fatal(err) }
	if _, err := os.Stat(stage); !errors.Is(err, os.ErrNotExist) { t.Fatal("orphan stage not removed") }
}

func TestFsyncFailuresNeverAcknowledgeDurabilityAndRetryRepairs(t *testing.T) {
	t.Run("file fsync", func(t *testing.T) {
		j, path := openTestJournal(t)
		j.syncRecord = func(*os.File) error { return errors.New("injected disk failure") }
		if err := j.Append(context.Background(), fixture()); !errors.Is(err, ErrUnavailable) { t.Fatal("file fsync failure acknowledged") }
		if _, err := os.Stat(filepath.Join(path, fixture().DeletionID+".json")); !errors.Is(err, os.ErrNotExist) { t.Fatal("unsynced record published") }
	})
	t.Run("directory fsync after rename", func(t *testing.T) {
		j, path := openTestJournal(t)
		j.syncDirectory = func() error { return errors.New("injected directory failure") }
		if err := j.Append(context.Background(), fixture()); !errors.Is(err, ErrUnavailable) { t.Fatal("directory fsync failure acknowledged") }
		if _, err := os.Stat(filepath.Join(path, fixture().DeletionID+".json")); err != nil { t.Fatal("test did not reach publication") }
		j.syncDirectory = j.dir.Sync
		if err := j.Append(context.Background(), fixture()); err != nil { t.Fatalf("retry did not finish durability: %v", err) }
	})
	t.Run("replay reestablishes restored file durability", func(t *testing.T) {
		j, _ := openTestJournal(t)
		if err := j.Append(context.Background(), fixture()); err != nil { t.Fatal(err) }
		j.syncRecord = func(*os.File) error { return errors.New("restored file sync failure") }
		if err := j.Replay(context.Background(), func(context.Context, identity.Tombstone) error { t.Fatal("unsynced restore marked durable"); return nil }); !errors.Is(err, ErrUnavailable) { t.Fatal("restore file fsync failure accepted") }
	})
}

func TestCancellationAndCallbackFailuresAreSafe(t *testing.T) {
	j, path := openTestJournal(t)
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err := j.Append(ctx, fixture()); !errors.Is(err, context.Canceled) { t.Fatal("cancelled append accepted") }
	entries, err := os.ReadDir(path)
	if err != nil || len(entries) != 0 { t.Fatal("cancelled append wrote data") }
	if err := j.Append(context.Background(), fixture()); err != nil { t.Fatal(err) }
	if err := j.Replay(ctx, func(context.Context, identity.Tombstone) error { t.Fatal("cancelled replay applied data"); return nil }); !errors.Is(err, context.Canceled) { t.Fatal("cancelled replay succeeded") }
	err = j.Replay(context.Background(), func(context.Context, identity.Tombstone) error { return errors.New("database password /private/path account-secret") })
	if err != ErrUnavailable || strings.Contains(err.Error(), "account-secret") { t.Fatal("callback details leaked") }
}

func TestConcurrentAppendsAndReplayAcrossBatches(t *testing.T) {
	j, _ := openTestJournal(t)
	const count = replayBatchSize + 7
	var wg sync.WaitGroup
	errorsSeen := make(chan error, count)
	for i := 0; i < count; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			r := fixture()
			r.DeletionID = fmt.Sprintf("%08x-1234-4234-8234-123456789abc", i)
			errorsSeen <- j.Append(context.Background(), r)
		}(i)
	}
	wg.Wait()
	close(errorsSeen)
	for err := range errorsSeen { if err != nil { t.Fatal(err) } }
	seen := make(map[string]bool)
	err := j.Replay(context.Background(), func(_ context.Context, r identity.Tombstone) error {
		if seen[r.DeletionID] { t.Fatal("duplicate replay") }
		seen[r.DeletionID] = true
		return nil
	})
	if err != nil || len(seen) != count { t.Fatalf("batched replay count %d, error %v", len(seen), err) }
}
