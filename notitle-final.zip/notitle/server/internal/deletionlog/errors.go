// Package deletionlog keeps account-deletion tombstones on an independently
// mounted volume. Its acknowledgements establish local filesystem durability,
// not off-host replication or protection against loss of the host.
package deletionlog

import "errors"

// Deliberately stable errors never include paths, identifiers, or record data.
var (
	ErrUnavailable = errors.New("deletion journal unavailable")
	ErrInvalid = errors.New("invalid deletion tombstone")
	ErrConflict = errors.New("conflicting deletion tombstone")
	ErrClosed = errors.New("deletion journal closed")
)
