//go:build !linux

package deletionlog

import (
	"context"

	"notitle/internal/identity"
)

// The release target is Linux. Other hosts must use the documented Linux
// container workflow; weakening path/durability controls is not a fallback.
type Journal struct{}

func Open(string) (*Journal, error) { return nil, ErrUnavailable }
func (*Journal) Append(context.Context, identity.Tombstone) error { return ErrUnavailable }
func (*Journal) Replay(context.Context, func(context.Context, identity.Tombstone) error) error { return ErrUnavailable }
func (*Journal) Close() error { return nil }
