package config

import (
	"errors"
	"os"
	"path/filepath"
	"regexp"
	"strings"
)

type IdentityConfig struct {
	Enabled bool
	TombstoneDirectory string
	TermsVersion string
	PrivacyVersion string
	CommunityVersion string
}

var policyVersion = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$`)

func loadIdentity(env Environment) (IdentityConfig, error) {
	cfg := IdentityConfig{Enabled: !env.Deployed()}
	if raw := strings.TrimSpace(os.Getenv("IDENTITY_ENABLED")); raw != "" {
		switch raw { case "true": cfg.Enabled = true; case "false": cfg.Enabled = false; default: return cfg, errors.New("IDENTITY_ENABLED must be true or false") }
	}
	if !cfg.Enabled { return cfg, nil }
	cfg.TombstoneDirectory = getenv("DELETION_TOMBSTONE_DIR", "/var/lib/notitle/tombstones")
	if !filepath.IsAbs(cfg.TombstoneDirectory) || filepath.Clean(cfg.TombstoneDirectory) != cfg.TombstoneDirectory || cfg.TombstoneDirectory == "/" {
		return cfg, errors.New("DELETION_TOMBSTONE_DIR must be a clean absolute directory path")
	}
	fallback := "draft-phase3-v1"
	if env.Deployed() { fallback = "" }
	cfg.TermsVersion = getenv("TERMS_VERSION", fallback)
	cfg.PrivacyVersion = getenv("PRIVACY_VERSION", fallback)
	cfg.CommunityVersion = getenv("COMMUNITY_VERSION", fallback)
	for _, version := range []string{cfg.TermsVersion, cfg.PrivacyVersion, cfg.CommunityVersion} {
		if !policyVersion.MatchString(version) || (env.Deployed() && strings.HasPrefix(strings.ToLower(version), "draft")) {
			return cfg, errors.New("identity requires explicit non-draft policy versions in deployed environments")
		}
	}
	return cfg, nil
}
