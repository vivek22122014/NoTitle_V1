package config

import "testing"

func localOperations(t *testing.T) {
 testEnvironment(t)
 for k,v:=range map[string]string{"OPERATIONS_ENABLED":"true","OPERATIONS_KEYRING_FILE":"/private/cases/keyring","RETENTION_POLICY_FILE":"/private/policy.json","HOLD_JOURNAL_DIR":"/var/lib/notitle/holds"}{t.Setenv(k,v)}
}
func TestOperationsDefaultsAndDependencies(t *testing.T){
 testEnvironment(t);c,e:=loadOperations(EnvironmentProduction,false,false,false);if e!=nil||c.Enabled{t.Fatal("operations must require deliberate enablement")}
 localOperations(t);for _,enabled:=range [][3]bool{{false,true,true},{true,false,true},{true,true,false}}{if _,e=loadOperations(EnvironmentTest,enabled[0],enabled[1],enabled[2]);e==nil{t.Fatal("required service bypass")}}
 if _,e=loadOperations(EnvironmentTest,true,true,true);e!=nil{t.Fatal(e)}
 if _,e=loadOperations(EnvironmentProduction,true,true,true);e==nil{t.Fatal("unreviewed deployed coverage accepted")}
}
func TestDeployedOperationsRequireIndependentMonitoredDestinations(t *testing.T){
 localOperations(t)
 for k,v:=range map[string]string{"OPERATIONS_COVERAGE_APPROVED":"true","OPERATIONS_COVERAGE_REFERENCE":"approved-roster-reference","OPERATIONS_OBSERVATION_FILE":"/private/observations/current.json","OPERATIONS_ALERT_PRIMARY_URL":"https://alerts.example.com/primary","OPERATIONS_ALERT_BACKUP_URL":"https://alerts.example.com/backup","OPERATIONS_ALERT_PRIMARY_TOKEN_FILE":"/private/primary","OPERATIONS_ALERT_BACKUP_TOKEN_FILE":"/private/backup"}{t.Setenv(k,v)}
 if _,e:=loadOperations(EnvironmentProduction,true,true,true);e!=nil{t.Fatal(e)}
 t.Setenv("OPERATIONS_ALERT_BACKUP_URL","https://alerts.example.com/primary");if _,e:=loadOperations(EnvironmentProduction,true,true,true);e==nil{t.Fatal("same destination accepted as redundant coverage")}
}
func TestOperationsRejectUntrustedEndpointsAndSecrets(t *testing.T){
 for _,endpoint:=range []string{"http://alerts.example.com/x","https://localhost/x","https://127.0.0.1/x","https://metadata.internal/x","https://alerts.example.com/x?secret=yes","https://user:pass@alerts.example.com","https://alerts.example.com:8443/x","https://alerts.example.com/%2fprivate"}{t.Run(endpoint,func(t *testing.T){localOperations(t);t.Setenv("OPERATIONS_ALERT_PRIMARY_URL",endpoint);t.Setenv("OPERATIONS_ALERT_PRIMARY_TOKEN_FILE","/private/token");if _,e:=loadOperations(EnvironmentTest,true,true,true);e==nil{t.Fatal("untrusted endpoint accepted")}})}
 localOperations(t);t.Setenv("OPERATIONS_ALERT_PRIMARY_TOKEN","inline-secret");if _,e:=loadOperations(EnvironmentTest,true,true,true);e==nil{t.Fatal("inline credential accepted")}
}
func TestOperationsIndependentKeyAndJournalPaths(t *testing.T){
 localOperations(t);t.Setenv("EVIDENCE_KEYRING_FILE","/private/cases/keyring");if _,e:=loadOperations(EnvironmentTest,true,true,true);e==nil{t.Fatal("reused keyring accepted")}
 t.Setenv("EVIDENCE_KEYRING_FILE","/private/evidence");t.Setenv("DELETION_TOMBSTONE_DIR","/var/lib/notitle/holds");if _,e:=loadOperations(EnvironmentTest,true,true,true);e==nil{t.Fatal("shared journal directory accepted")}
}

func TestOperationsRejectEffectiveDefaultAndExplicitPathAliases(t *testing.T) {
	tests := []struct {
		name, otherSetting, operationSetting, defaultPath string
	}{
		{"evidence", "EVIDENCE_KEYRING_FILE", "OPERATIONS_KEYRING_FILE", "/run/secrets/evidence_keyring"},
		{"mfa", "ADMIN_MFA_KEY_FILE", "OPERATIONS_KEYRING_FILE", "/run/secrets/admin_mfa_key"},
		{"deletion", "DELETION_TOMBSTONE_DIR", "HOLD_JOURNAL_DIR", "/var/lib/notitle/tombstones"},
	}
	for _, test := range tests {
		for _, explicit := range []bool{false, true} {
			name := test.name + "/default"
			if explicit {
				name = test.name + "/explicit"
			}
			t.Run(name, func(t *testing.T) {
				localOperations(t)
				path := test.defaultPath
				if explicit {
					path = "/private/shared-" + test.name
					t.Setenv(test.otherSetting, "  " + path + "  ")
				}
				t.Setenv(test.operationSetting, path)
				if _, err := loadOperations(EnvironmentTest, true, true, true); err == nil {
					t.Fatal("operations accepted another feature's effective protected path")
				}
			})
		}
	}
}
