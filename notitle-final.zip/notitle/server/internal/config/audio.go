package config

import (
	"errors"
	"net/netip"
	"net/url"
	"strings"
)

// Audio configuration contains paths, never relay credentials. The supervisor
// owns the TURN shared secret; the application only receives per-call grants.
type AudioConfig struct {
	Enabled bool
	SafetyVerified bool
	AllowLoopbackHTTP bool
	ControlURL string
	ControlTokenFile string
	CAFile string
	ClientCertFile string
	ClientKeyFile string
	RelayAddresses []netip.Addr
}

func loadAudio(env Environment, safetyEnabled bool) (AudioConfig,error) {
	var cfg AudioConfig
	var err error
	cfg.Enabled,err=featureFlag("AUDIO_ENABLED",false)
	if err!=nil{return cfg,err}
	cfg.SafetyVerified,err=featureFlag("AUDIO_SAFETY_VERIFIED",false)
	if err!=nil{return cfg,err}
	cfg.AllowLoopbackHTTP,err=featureFlag("AUDIO_ALLOW_LOOPBACK_HTTP",false)
	if err!=nil{return cfg,err}
	if !cfg.Enabled{return cfg,nil}
	if !safetyEnabled{return cfg,errors.New("AUDIO_ENABLED requires SAFETY_ENABLED")}
	if env==EnvironmentProduction && !cfg.SafetyVerified{return cfg,errors.New("production audio requires AUDIO_SAFETY_VERIFIED after relay and device acceptance")}
	if env.Deployed() && cfg.AllowLoopbackHTTP{return cfg,errors.New("deployed audio control requires HTTPS and mutual TLS")}
	cfg.ControlURL=getenv("AUDIO_CONTROL_URL","")
	u,parseErr:=url.Parse(cfg.ControlURL)
	if parseErr!=nil||u==nil||u.Hostname()==""||u.User!=nil||u.Path!=""||u.RawPath!=""||u.RawQuery!=""||u.ForceQuery||u.Fragment!=""||u.Opaque!=""||strings.ContainsAny(cfg.ControlURL,"#\r\n\x00"){
		return cfg,errors.New("AUDIO_CONTROL_URL must be an explicit control origin without credentials or path")
	}
	if u.Port()!=""{if err:=ValidateHTTPAddr(u.Host);err!=nil{return cfg,errors.New("AUDIO_CONTROL_URL has an invalid port")}}
	if strings.HasSuffix(u.Host,":"){return cfg,errors.New("AUDIO_CONTROL_URL has an invalid port")}
	if u.Scheme!="https"{
		ip,ipErr:=netip.ParseAddr(u.Hostname())
		if u.Scheme!="http"||!cfg.AllowLoopbackHTTP||env.Deployed()||ipErr!=nil||(ip.String()!="127.0.0.1"&&ip.String()!="::1"){return cfg,errors.New("audio control requires mutual TLS except explicit local loopback tests")}
	}
	cfg.ControlTokenFile=getenv("AUDIO_CONTROL_TOKEN_FILE","")
	if !cleanSecretPath(cfg.ControlTokenFile){return cfg,errors.New("AUDIO_CONTROL_TOKEN_FILE must be a clean absolute protected file path")}
	cfg.CAFile=getenv("AUDIO_CONTROL_CA_FILE","")
	cfg.ClientCertFile=getenv("AUDIO_CONTROL_CLIENT_CERT_FILE","")
	cfg.ClientKeyFile=getenv("AUDIO_CONTROL_CLIENT_KEY_FILE","")
	if u.Scheme=="https"{
		if !cleanSecretPath(cfg.CAFile)||!cleanSecretPath(cfg.ClientCertFile)||!cleanSecretPath(cfg.ClientKeyFile){return cfg,errors.New("audio mutual TLS requires CA, client certificate and protected client key files")}
		if cfg.ControlTokenFile==cfg.ClientKeyFile||cfg.CAFile==cfg.ClientKeyFile||cfg.ClientCertFile==cfg.ClientKeyFile{return cfg,errors.New("audio control secrets and certificates must use separate files")}
	}
	addresses:=strings.Split(getenv("AUDIO_RELAY_ADDRESSES",""),",")
	if len(addresses)<1||len(addresses)>8{return cfg,errors.New("AUDIO_RELAY_ADDRESSES requires one to eight public literal addresses")}
	seen:=make(map[netip.Addr]bool)
	for _,raw:=range addresses{
		ip,err:=netip.ParseAddr(strings.TrimSpace(raw))
		if err!=nil||ip.Zone()!=""||ip.Is4In6()||!ip.IsGlobalUnicast()||ip.IsPrivate()||specialRelayAddress(ip)||seen[ip]{return cfg,errors.New("AUDIO_RELAY_ADDRESSES must contain distinct public literal IP addresses")}
		seen[ip]=true;cfg.RelayAddresses=append(cfg.RelayAddresses,ip)
	}
	return cfg,nil
}

// Global-unicast alone also includes shared, benchmark and translation ranges.
// Reject these as relay endpoints; they must not become an SSRF/privacy bypass.
func specialRelayAddress(ip netip.Addr)bool{
	for _,value:=range []string{"0.0.0.0/8","100.64.0.0/10","192.0.0.0/24","198.18.0.0/15","240.0.0.0/4","64:ff9b::/96","64:ff9b:1::/48","100::/64","2001::/32","2001:2::/48","2002::/16","fec0::/10"}{
		if netip.MustParsePrefix(value).Contains(ip){return true}
	}
	return false
}
