package config

import (
	"errors"
	"strconv"
)

type FriendsConfig struct { Enabled bool; MaxPerIdentity int }

func loadFriends(env Environment, safetyEnabled bool)(FriendsConfig,error) {
	enabled,err:=featureFlag("FRIENDS_ENABLED",!env.Deployed() && safetyEnabled)
	if err!=nil {return FriendsConfig{},err}
	if enabled && !safetyEnabled {return FriendsConfig{},errors.New("FRIENDS_ENABLED requires SAFETY_ENABLED")}
	maximum,err:=strconv.Atoi(getenv("FRIENDS_PER_IDENTITY","100"))
	if err!=nil || maximum<1 || maximum>100 {return FriendsConfig{},errors.New("FRIENDS_PER_IDENTITY must be an integer from 1 to 100")}
	return FriendsConfig{Enabled:enabled,MaxPerIdentity:maximum},nil
}
