package config

import (
	"errors"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

type SafetyConfig struct {
	Enabled bool
	EvidenceKeyringFile string
	Retention time.Duration
	RetentionPolicyVersion string
}
type AdminConfig struct {
	Enabled bool
	Addr string
	Origin string
	KeyFile string
}
func featureFlag(name string, fallback bool)(bool,error) {
	switch strings.TrimSpace(os.Getenv(name)) {
	case "": return fallback,nil
	case "true": return true,nil
	case "false": return false,nil
	default: return false,errors.New(name+" must be true or false")
	}
}
func cleanSecretPath(path string) bool { return filepath.IsAbs(path) && filepath.Clean(path)==path && path!="/" }
func loadSafety(env Environment, realtimeEnabled bool)(SafetyConfig,AdminConfig,error) {
	var safety SafetyConfig; var admin AdminConfig; var err error
	safety.Enabled,err=featureFlag("SAFETY_ENABLED",!env.Deployed() && realtimeEnabled)
	if err!=nil { return safety,admin,err }
	admin.Enabled,err=featureFlag("ADMIN_ENABLED",!env.Deployed() && safety.Enabled)
	if err!=nil { return safety,admin,err }
	if safety.Enabled && !realtimeEnabled { return safety,admin,errors.New("SAFETY_ENABLED requires REALTIME_ENABLED") }
	if admin.Enabled && !safety.Enabled { return safety,admin,errors.New("ADMIN_ENABLED requires SAFETY_ENABLED") }
	if !safety.Enabled { return safety,admin,nil }
	safety.EvidenceKeyringFile=getenv("EVIDENCE_KEYRING_FILE","/run/secrets/evidence_keyring")
	if !cleanSecretPath(safety.EvidenceKeyringFile) { return safety,admin,errors.New("EVIDENCE_KEYRING_FILE must be a clean absolute file path") }
	days:=getenv("CASE_RETENTION_DAYS","30")
	safety.RetentionPolicyVersion=getenv("CASE_RETENTION_POLICY_VERSION","draft-phase5-local")
	if env.Deployed() {
		if !admin.Enabled { return safety,admin,errors.New("deployed safety requires ADMIN_ENABLED") }
		if strings.TrimSpace(os.Getenv("CASE_RETENTION_DAYS"))=="" || !policyVersion.MatchString(safety.RetentionPolicyVersion) || strings.HasPrefix(strings.ToLower(safety.RetentionPolicyVersion),"draft") { return safety,admin,errors.New("deployed safety requires explicit reviewed case retention settings") }
		if os.Getenv("MODERATION_COVERAGE_CONFIRMED")!="true" { return safety,admin,errors.New("deployed safety requires confirmed report and grievance coverage") }
	}
	n,err:=strconv.Atoi(days)
	if err!=nil || n<1 || n>3650 { return safety,admin,errors.New("CASE_RETENTION_DAYS must be an integer from 1 to 3650") }
	safety.Retention=time.Duration(n)*24*time.Hour
	if !admin.Enabled { return safety,admin,nil }
	admin.Addr=getenv("ADMIN_ADDR","127.0.0.1:9090")
	if err:=ValidateHTTPAddr(admin.Addr);err!=nil { return safety,admin,errors.New("ADMIN_ADDR must be a valid private listener address") }
	defaultOrigin:="http://localhost:9090"; if env.Deployed() { defaultOrigin="" }
	admin.Origin=getenv("ADMIN_ORIGIN",defaultOrigin)
	if err:=validateOrigin(admin.Origin,env);err!=nil { return safety,admin,errors.New("ADMIN_ORIGIN must be an explicit valid private origin") }
	admin.KeyFile=getenv("ADMIN_MFA_KEY_FILE","/run/secrets/admin_mfa_key")
	if !cleanSecretPath(admin.KeyFile) || admin.KeyFile==safety.EvidenceKeyringFile { return safety,admin,errors.New("ADMIN_MFA_KEY_FILE must be a separate clean absolute secret path") }
	return safety,admin,nil
}
