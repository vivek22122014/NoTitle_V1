package config

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func testEnvironment(t *testing.T) {
	t.Helper()
	for _, key := range []string{
		"APP_ENV", "PUBLIC_ORIGIN", "LOG_LEVEL", "DATABASE_URL", "DATABASE_URL_FILE",
		"MAINTENANCE_MODE", "LAUNCH_APPROVAL_FILE", "DEPLOYED_API_IMAGE",
  "DEPLOYMENT_MANIFEST_SHA256", "LAUNCH_STAGE",
		"DB_MAX_CONNS", "DB_MIN_CONNS", "HTTP_ADDR", "HTTP_MAX_HEADER_BYTES", "HTTP_MAX_BODY_BYTES",
		"HTTP_READ_HEADER_TIMEOUT", "HTTP_READ_TIMEOUT", "HTTP_WRITE_TIMEOUT", "HTTP_IDLE_TIMEOUT",
		"HTTP_SHUTDOWN_TIMEOUT", "DB_MAX_CONN_LIFETIME", "DB_MAX_CONN_IDLE_TIME",
		"DB_HEALTHCHECK_PERIOD", "DB_CONNECT_TIMEOUT", "DB_READINESS_TIMEOUT",
		"IDENTITY_ENABLED", "DELETION_TOMBSTONE_DIR", "TERMS_VERSION", "PRIVACY_VERSION", "COMMUNITY_VERSION",
		"REALTIME_ENABLED",
        "OPERATIONS_ENABLED", "OPERATIONS_COVERAGE_APPROVED", "OPERATIONS_KEYRING_FILE", "RETENTION_POLICY_FILE", "HOLD_JOURNAL_DIR", "OPERATIONS_OBSERVATION_FILE", "OPERATIONS_ALERT_PRIMARY_URL", "OPERATIONS_ALERT_BACKUP_URL", "OPERATIONS_ALERT_PRIMARY_TOKEN_FILE", "OPERATIONS_ALERT_BACKUP_TOKEN_FILE", "OPERATIONS_COVERAGE_REFERENCE", "OPERATIONS_ALERT_PRIMARY_TOKEN", "OPERATIONS_ALERT_BACKUP_TOKEN",
		"PAYMENTS_ENABLED", "CHECKOUT_ENABLED", "PAYMENT_ENVIRONMENT", "PAYMENT_MERCHANT_ID", "PAYMENT_MERCHANT_APPROVED", "PAYMENT_POLICY_APPROVED", "PAYMENT_ANNUAL_APPROVED", "CASHFREE_CLIENT_ID_FILE", "CASHFREE_CLIENT_SECRET_FILE", "CASHFREE_PREVIOUS_SECRET_FILE", "CASHFREE_PREVIOUS_SECRET_UNTIL", "CASHFREE_CLIENT_ID", "CASHFREE_CLIENT_SECRET", "CASHFREE_PREVIOUS_SECRET",
		"FRIENDS_ENABLED", "FRIENDS_PER_IDENTITY",
		"AUDIO_ENABLED", "AUDIO_SAFETY_VERIFIED", "AUDIO_ALLOW_LOOPBACK_HTTP", "AUDIO_CONTROL_URL", "AUDIO_CONTROL_TOKEN_FILE", "AUDIO_CONTROL_CA_FILE", "AUDIO_CONTROL_CLIENT_CERT_FILE", "AUDIO_CONTROL_CLIENT_KEY_FILE", "AUDIO_RELAY_ADDRESSES",
		"SAFETY_ENABLED", "ADMIN_ENABLED", "EVIDENCE_KEYRING_FILE", "CASE_RETENTION_DAYS", "CASE_RETENTION_POLICY_VERSION", "MODERATION_COVERAGE_CONFIRMED", "ADMIN_ADDR", "ADMIN_ORIGIN", "ADMIN_MFA_KEY_FILE",
	} {
		t.Setenv(key, "")
	}
	t.Setenv("APP_ENV", "test")
	t.Setenv("DATABASE_URL", "postgres://notitle_app:local-password@localhost:5432/notitle?sslmode=disable")
}

func TestLoadDefaults(t *testing.T) {
	testEnvironment(t)
	cfg, err := Load()
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Database.MaxConns != 8 || cfg.Database.MinConns != 0 {
		t.Fatal("unexpected default pool bounds")
	}
	if cfg.HTTP.Addr != ":8080" || cfg.HTTP.MaxHeaderBytes != 16384 || cfg.HTTP.MaxBodyBytes != 65536 {
		t.Fatal("unexpected default HTTP limits")
	}
	if cfg.Database.ReadinessTimeout != time.Second || cfg.HTTP.ShutdownTimeout != 15*time.Second {
		t.Fatal("unexpected timeout defaults")
	}
}

func TestLoadRejectsInvalidConfiguration(t *testing.T) {
	tests := []struct{ key, value string }{
		{"APP_ENV", "prod"},
		{"DATABASE_URL", ""},
		{"DATABASE_URL", "postgres://user:SECRET%xx@localhost/notitle"},
		{"DATABASE_URL", "postgres://user:SECRET@localhost/notitle?bad=%xx"},
		{"DATABASE_URL", "postgres://localhost/notitle"},
		{"DB_MAX_CONNS", "21"},
		{"DB_MAX_CONNS", "0"},
		{"DB_MIN_CONNS", "-1"},
		{"DB_MIN_CONNS", "9"},
		{"HTTP_ADDR", ":0"},
		{"HTTP_ADDR", "http://localhost:8080"},
		{"HTTP_ADDR", ":65536"},
		{"PUBLIC_ORIGIN", "https://user:SECRET@example.com"},
		{"PUBLIC_ORIGIN", "https://example.com/path"},
		{"PUBLIC_ORIGIN", "https://example.com?"},
		{"PUBLIC_ORIGIN", "https://example.com:65536"},
		{"HTTP_MAX_BODY_BYTES", "1048577"},
		{"HTTP_MAX_HEADER_BYTES", "1023"},
		{"HTTP_READ_TIMEOUT", "0s"},
		{"HTTP_WRITE_TIMEOUT", "1s"},
		{"HTTP_READ_HEADER_TIMEOUT", "20s"},
		{"DB_READINESS_TIMEOUT", "6s"},
		{"DB_CONNECT_TIMEOUT", "24h"},
		{"LOG_LEVEL", "trace"},
	}
	for _, test := range tests {
		t.Run(test.key+"="+test.value, func(t *testing.T) {
			testEnvironment(t)
			t.Setenv(test.key, test.value)
			_, err := Load()
			if err == nil {
				t.Fatal("invalid configuration accepted")
			}
			if strings.Contains(err.Error(), "SECRET") {
				t.Fatal("configuration error leaked credentials")
			}
		})
	}
}

func TestDeployedEnvironmentRequiresHTTPSAndFileSecret(t *testing.T) {
	for _, env := range []string{"staging", "production"} {
		t.Run(env, func(t *testing.T) {
			testEnvironment(t)
			t.Setenv("APP_ENV", env)
			t.Setenv("MAINTENANCE_MODE", "true")
			t.Setenv("PUBLIC_ORIGIN", "https://example.com")
			if _, err := Load(); err == nil {
				t.Fatal("inline production secret accepted")
			}
			path := filepath.Join(t.TempDir(), "database-url")
			if err := os.WriteFile(path, []byte(os.Getenv("DATABASE_URL")), 0600); err != nil {
				t.Fatal(err)
			}
			t.Setenv("DATABASE_URL", "")
			t.Setenv("DATABASE_URL_FILE", path)
			if _, err := Load(); err != nil {
				t.Fatal(err)
			}
			t.Setenv("PUBLIC_ORIGIN", "http://example.com")
			if _, err := Load(); err == nil {
				t.Fatal("insecure production origin accepted")
			}
		})
	}
}

func TestDatabaseConfigurationRedactsFormatting(t *testing.T) {
	cfg := DatabaseConfig{URL: "postgres://user:SECRET@localhost/db"}
	encoded, err := json.Marshal(cfg)
	if err != nil {
		t.Fatal(err)
	}
	for _, value := range []string{fmt.Sprint(cfg), fmt.Sprintf("%#v", cfg), string(encoded), cfg.LogValue().String()} {
		if strings.Contains(value, "SECRET") {
			t.Fatal("configuration formatting leaked credentials")
		}
	}
}
