package config

import (
	"strings"
	"testing"
)

func audioEnvironment(t *testing.T){
	t.Helper();testEnvironment(t)
	t.Setenv("AUDIO_ENABLED","true")
	t.Setenv("AUDIO_CONTROL_URL","https://relay-control.example.test:9443")
	t.Setenv("AUDIO_CONTROL_TOKEN_FILE","/run/secrets/audio_control_token")
	t.Setenv("AUDIO_CONTROL_CA_FILE","/run/secrets/audio_control_ca")
	t.Setenv("AUDIO_CONTROL_CLIENT_CERT_FILE","/run/secrets/audio_client_cert")
	t.Setenv("AUDIO_CONTROL_CLIENT_KEY_FILE","/run/secrets/audio_client_key")
	t.Setenv("AUDIO_RELAY_ADDRESSES","93.184.216.34,2606:4700:4700::1111")
}

func TestAudioDisabledByDefaultAndProductionRequiresAcceptance(t *testing.T){
	testEnvironment(t)
	for _,env:=range []Environment{EnvironmentDevelopment,EnvironmentTest,EnvironmentStaging,EnvironmentProduction}{
		cfg,err:=loadAudio(env,true);if err!=nil||cfg.Enabled{t.Fatal("audio enabled before relay configuration")}
	}
	audioEnvironment(t)
	if _,err:=loadAudio(EnvironmentStaging,true);err!=nil{t.Fatal("isolated staging acceptance cannot run",err)}
	if _,err:=loadAudio(EnvironmentProduction,true);err==nil{t.Fatal("production audio bypassed acceptance assertion")}
	t.Setenv("AUDIO_SAFETY_VERIFIED","true")
	if cfg,err:=loadAudio(EnvironmentProduction,true);err!=nil||len(cfg.RelayAddresses)!=2{t.Fatal("reviewed production configuration rejected",err)}
	if _,err:=loadAudio(EnvironmentProduction,false);err==nil{t.Fatal("audio bypassed safety dependency")}
}

func TestAudioRejectsUnsafeControlOriginsAndMissingMutualTLS(t *testing.T){
	for _,raw:=range []string{"http://relay-control.example.test:9443","https://name:SECRET@relay.test","https://relay.test/path","https://relay.test?","https://relay.test#","https://relay.test:0","https://relay.test:65536","https://relay.test:"}{
		t.Run(raw,func(t *testing.T){audioEnvironment(t);t.Setenv("AUDIO_CONTROL_URL",raw);_,err:=loadAudio(EnvironmentTest,true);if err==nil{t.Fatal("unsafe control origin accepted")};if strings.Contains(err.Error(),"SECRET"){t.Fatal("control secret leaked")}})
	}
	for _,key:=range []string{"AUDIO_CONTROL_TOKEN_FILE","AUDIO_CONTROL_CA_FILE","AUDIO_CONTROL_CLIENT_CERT_FILE","AUDIO_CONTROL_CLIENT_KEY_FILE"}{
		t.Run(key,func(t *testing.T){audioEnvironment(t);t.Setenv(key,"");if _,err:=loadAudio(EnvironmentTest,true);err==nil{t.Fatal("missing protected control file accepted")}})
	}
}

func TestAudioLoopbackHTTPIsExplicitAndNeverDeployed(t *testing.T){
	audioEnvironment(t);t.Setenv("AUDIO_CONTROL_URL","http://127.0.0.1:9443")
	if _,err:=loadAudio(EnvironmentDevelopment,true);err==nil{t.Fatal("plaintext control silently permitted")}
	t.Setenv("AUDIO_ALLOW_LOOPBACK_HTTP","true")
	if _,err:=loadAudio(EnvironmentDevelopment,true);err!=nil{t.Fatal(err)}
	if _,err:=loadAudio(EnvironmentStaging,true);err==nil{t.Fatal("staging accepted plaintext control")}
	t.Setenv("AUDIO_CONTROL_URL","http://localhost:9443")
	if _,err:=loadAudio(EnvironmentDevelopment,true);err==nil{t.Fatal("DNS name accepted as literal loopback")}
	for _,value:=range []string{"http://10.0.0.1:9443","http://127.0.0.1.evil.test:9443"}{t.Setenv("AUDIO_CONTROL_URL",value);if _,err:=loadAudio(EnvironmentDevelopment,true);err==nil{t.Fatal("remote plaintext accepted")}}
}

func TestAudioRelayAllowlistRejectsPrivateMappedAndUnboundedAddresses(t *testing.T){
	for _,value:=range []string{"","127.0.0.1","10.0.0.1","169.254.169.254","100.100.100.200","224.0.0.1","::1","fc00::1","fec0::1","2001:2::1","fe80::1%eth0","::ffff:93.184.216.34","64:ff9b::a00:1","relay.test","93.184.216.34/32","93.184.216.34,93.184.216.34","1.1.1.1,2.2.2.2,3.3.3.3,4.4.4.4,5.5.5.5,6.6.6.6,7.7.7.7,8.8.8.8,9.9.9.9"}{
		t.Run(value,func(t *testing.T){audioEnvironment(t);t.Setenv("AUDIO_RELAY_ADDRESSES",value);if _,err:=loadAudio(EnvironmentTest,true);err==nil{t.Fatal("unsafe relay allowlist accepted")}})
	}
}
