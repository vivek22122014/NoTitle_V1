package config

import "testing"

func TestIdentityEnvironmentDefaultsAndGates(t *testing.T) {
	for _, key := range []string{"IDENTITY_ENABLED", "DELETION_TOMBSTONE_DIR", "TERMS_VERSION", "PRIVACY_VERSION", "COMMUNITY_VERSION"} { t.Setenv(key, "") }
	local, err := loadIdentity(EnvironmentDevelopment)
	if err != nil || !local.Enabled || local.TermsVersion != "draft-phase3-v1" { t.Fatal("local identity defaults invalid") }
	production, err := loadIdentity(EnvironmentProduction)
	if err != nil || production.Enabled { t.Fatal("deployed identity must require deliberate enablement") }
	t.Setenv("IDENTITY_ENABLED", "true")
	if _, err := loadIdentity(EnvironmentProduction); err == nil { t.Fatal("missing policy versions accepted") }
	for _, key := range []string{"TERMS_VERSION", "PRIVACY_VERSION", "COMMUNITY_VERSION"} { t.Setenv(key, "2026-10-09-v1") }
	if _, err := loadIdentity(EnvironmentProduction); err != nil { t.Fatal(err) }
	t.Setenv("DELETION_TOMBSTONE_DIR", "../database")
	if _, err := loadIdentity(EnvironmentProduction); err == nil { t.Fatal("relative journal path accepted") }
	t.Setenv("IDENTITY_ENABLED", "yes")
	if _, err := loadIdentity(EnvironmentTest); err == nil { t.Fatal("invalid enablement value accepted") }
}
