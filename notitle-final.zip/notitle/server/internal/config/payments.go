package config

import (
 "errors"
 "os"
 "strings"
 "time"
)

// Payment credentials are file paths only; no inline credential is accepted.
// Checkout admission is independent of processing already committed money.
type PaymentsConfig struct {
 Enabled,CheckoutEnabled,MerchantApproved,PolicyApproved,AnnualApproved bool
 Environment,MerchantID,ClientIDFile,ClientSecretFile,PreviousSecretFile string
 PreviousSecretUntil time.Time
}
func loadPayments(env Environment,identityEnabled,safetyEnabled,adminEnabled bool)(PaymentsConfig,error){
 var c PaymentsConfig;var err error
 for _,flag:=range []struct{name string;value *bool}{{"PAYMENTS_ENABLED",&c.Enabled},{"CHECKOUT_ENABLED",&c.CheckoutEnabled},{"PAYMENT_MERCHANT_APPROVED",&c.MerchantApproved},{"PAYMENT_POLICY_APPROVED",&c.PolicyApproved},{"PAYMENT_ANNUAL_APPROVED",&c.AnnualApproved}}{*flag.value,err=featureFlag(flag.name,false);if err!=nil{return c,err}}
 mode:="sandbox";if env==EnvironmentProduction{mode="production"};c.Environment=getenv("PAYMENT_ENVIRONMENT",mode)
 if c.Environment!="sandbox"&&c.Environment!="production"{return c,errors.New("PAYMENT_ENVIRONMENT must be sandbox or production")}
 if (env==EnvironmentProduction)!=(c.Environment=="production"){return c,errors.New("payment environment must match the application environment; use isolated sandbox data outside production")}
 c.MerchantID=getenv("PAYMENT_MERCHANT_ID","unconfigured")
 if len(c.MerchantID)>128||strings.ContainsAny(c.MerchantID," \t\r\n/\\"){return c,errors.New("PAYMENT_MERCHANT_ID is invalid")}
 if c.CheckoutEnabled&&!c.Enabled{return c,errors.New("CHECKOUT_ENABLED requires PAYMENTS_ENABLED")}
 if !c.Enabled{return c,nil}
 if !identityEnabled||!safetyEnabled||!adminEnabled{return c,errors.New("payments require identity, safety and private billing administration")}
 if c.MerchantID=="unconfigured"{return c,errors.New("PAYMENT_MERCHANT_ID is required")}
 if c.Environment=="production"&&(!c.MerchantApproved||!c.PolicyApproved){return c,errors.New("live payment integration requires merchant underwriting and reviewed tax/refund policy")}
 for _,key:=range []string{"CASHFREE_CLIENT_ID","CASHFREE_CLIENT_SECRET","CASHFREE_PREVIOUS_SECRET"}{if strings.TrimSpace(os.Getenv(key))!=""{return c,errors.New("Cashfree credentials must use protected files, never inline environment values")}}
 c.ClientIDFile=getenv("CASHFREE_CLIENT_ID_FILE","");c.ClientSecretFile=getenv("CASHFREE_CLIENT_SECRET_FILE","");c.PreviousSecretFile=getenv("CASHFREE_PREVIOUS_SECRET_FILE","")
 if !cleanSecretPath(c.ClientIDFile)||!cleanSecretPath(c.ClientSecretFile)||c.ClientIDFile==c.ClientSecretFile{return c,errors.New("Cashfree credentials require distinct clean absolute file paths")}
 if c.PreviousSecretFile!=""{
  if !cleanSecretPath(c.PreviousSecretFile)||c.PreviousSecretFile==c.ClientSecretFile||c.PreviousSecretFile==c.ClientIDFile{return c,errors.New("previous Cashfree secret requires a separate protected file")}
  until,e:=time.Parse(time.RFC3339,getenv("CASHFREE_PREVIOUS_SECRET_UNTIL",""));if e!=nil||!until.After(time.Now())||until.After(time.Now().Add(24*time.Hour)){return c,errors.New("previous Cashfree secret overlap must end within the next 24 hours")};c.PreviousSecretUntil=until.UTC()
 }else if strings.TrimSpace(os.Getenv("CASHFREE_PREVIOUS_SECRET_UNTIL"))!=""{return c,errors.New("previous-secret deadline requires its protected key file")}
 return c,nil
}
