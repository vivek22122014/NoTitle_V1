package config

import "testing"

func TestProductionAlwaysBootsWithAdmissionClosed(t *testing.T){
    testEnvironment(t)
    local,err:=loadAdmission(EnvironmentDevelopment);if err!=nil||local.Maintenance{t.Fatal("local workflow changed")}
    if _,err=loadAdmission(EnvironmentProduction);err==nil{t.Fatal("production automatically opened after a restart")}
    t.Setenv("MAINTENANCE_MODE","true")
    deployed,err:=loadAdmission(EnvironmentProduction);if err!=nil||!deployed.Maintenance{t.Fatal(err)}
    // The initial closed deployment can boot without a fabricated permit. It
    // cannot be opened until a real current approval file is installed.
    t.Setenv("LAUNCH_APPROVAL_FILE","../approval.json")
    if _,err=loadAdmission(EnvironmentProduction);err==nil{t.Fatal("relative launch approval accepted")}
}
