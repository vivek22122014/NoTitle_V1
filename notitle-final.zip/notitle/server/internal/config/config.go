package config

import (
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"
)

type Environment string
const (
	EnvironmentDevelopment Environment = "development"
	EnvironmentTest Environment = "test"
	EnvironmentStaging Environment = "staging"
	EnvironmentProduction Environment = "production"
)

type Config struct {
	Environment Environment
	ServiceName string
	PublicOrigin string
	LogLevel string
	HTTP HTTPConfig
	Database DatabaseConfig
	Identity IdentityConfig
	Realtime RealtimeConfig
	Safety SafetyConfig
	Admin AdminConfig
	Friends FriendsConfig
	Audio AudioConfig
	Payments PaymentsConfig
 Operations OperationsConfig
 Admission AdmissionConfig
}

type HTTPConfig struct {
	Addr string
	ReadHeaderTimeout time.Duration
	ReadTimeout time.Duration
	WriteTimeout time.Duration
	IdleTimeout time.Duration
	ShutdownTimeout time.Duration
	MaxHeaderBytes int
	MaxBodyBytes int64
}

type DatabaseConfig struct {
	URL string `json:"-"`
	MaxConns int32
	MinConns int32
	MaxConnLifetime time.Duration
	MaxConnIdleTime time.Duration
	HealthCheckPeriod time.Duration
	ConnectTimeout time.Duration
	ReadinessTimeout time.Duration
}

// Never let generic structured logging or formatted errors expose a DSN.
func (DatabaseConfig) String() string {
	return "database configuration [redacted]"
}
func (DatabaseConfig) GoString() string {
	return "database configuration [redacted]"
}
func (DatabaseConfig) LogValue() slog.Value {
	return slog.StringValue("[redacted]")
}

func Load() (Config, error) {
	env := Environment(strings.ToLower(getenv("APP_ENV", string(EnvironmentDevelopment))))
	if !env.Valid() {
		return Config{}, errors.New("APP_ENV must be development, test, staging, or production")
	}
	origin := getenv("PUBLIC_ORIGIN", "http://localhost:5173")
	if err := validateOrigin(origin, env); err != nil {
		return Config{}, err
	}
	if env.Deployed() && (strings.TrimSpace(os.Getenv("DATABASE_URL")) != "" || strings.TrimSpace(os.Getenv("DATABASE_URL_FILE")) == "") {
		return Config{}, errors.New("DATABASE_URL_FILE is required and inline DATABASE_URL is forbidden in staging and production")
	}
	databaseURL, err := secretValue("DATABASE_URL")
	if err != nil {
		return Config{}, err
	}
	if err := validateDatabaseURL(databaseURL); err != nil {
		return Config{}, err
	}

	maxConns, err := int32Env("DB_MAX_CONNS", 8)
	if err != nil {
		return Config{}, err
	}
	minConns, err := int32Env("DB_MIN_CONNS", 0)
	if err != nil {
		return Config{}, err
	}
	if maxConns < 1 || maxConns > 20 {
		return Config{}, errors.New("DB_MAX_CONNS must be between 1 and 20")
	}
	if minConns < 0 || minConns > maxConns {
		return Config{}, errors.New("DB_MIN_CONNS must be between 0 and DB_MAX_CONNS")
	}
	headerBytes, err := int32Env("HTTP_MAX_HEADER_BYTES", 16 << 10)
	if err != nil {
		return Config{}, err
	}
	bodyBytes, err := int32Env("HTTP_MAX_BODY_BYTES", 64 << 10)
	if err != nil {
		return Config{}, err
	}
	if headerBytes < 1024 || headerBytes > 1 << 20 {
		return Config{}, errors.New("HTTP_MAX_HEADER_BYTES must be between 1024 and 1048576")
	}
	if bodyBytes < 1024 || bodyBytes > 1 << 20 {
		return Config{}, errors.New("HTTP_MAX_BODY_BYTES must be between 1024 and 1048576")
	}
	addr := getenv("HTTP_ADDR", ":8080")
	if err := ValidateHTTPAddr(addr); err != nil {
		return Config{}, err
	}
	cfg := Config{
		Environment: env, ServiceName: "notitle-api", PublicOrigin: origin,
		LogLevel: strings.ToLower(getenv("LOG_LEVEL", defaultLogLevel(env))),
		HTTP: HTTPConfig{Addr: addr, MaxHeaderBytes: int(headerBytes), MaxBodyBytes: int64(bodyBytes)},
		Database: DatabaseConfig{URL: databaseURL, MaxConns: maxConns, MinConns: minConns},
	}
	if !validLogLevel(cfg.LogLevel) {
		return Config{}, errors.New("LOG_LEVEL must be debug, info, warn, or error")
	}
 cfg.Admission,err=loadAdmission(env);if err!=nil{return Config{},err}
	durations := []struct {
		key string
		target *time.Duration
		fallback time.Duration
		maximum time.Duration
	}{
		{"HTTP_READ_HEADER_TIMEOUT", &cfg.HTTP.ReadHeaderTimeout, 5*time.Second, time.Minute},
		{"HTTP_READ_TIMEOUT", &cfg.HTTP.ReadTimeout, 15*time.Second, 2*time.Minute},
		{"HTTP_WRITE_TIMEOUT", &cfg.HTTP.WriteTimeout, 15*time.Second, 2*time.Minute},
		{"HTTP_IDLE_TIMEOUT", &cfg.HTTP.IdleTimeout, time.Minute, 5*time.Minute},
		{"HTTP_SHUTDOWN_TIMEOUT", &cfg.HTTP.ShutdownTimeout, 15*time.Second, time.Minute},
		{"DB_MAX_CONN_LIFETIME", &cfg.Database.MaxConnLifetime, 30*time.Minute, 24*time.Hour},
		{"DB_MAX_CONN_IDLE_TIME", &cfg.Database.MaxConnIdleTime, 5*time.Minute, time.Hour},
		{"DB_HEALTHCHECK_PERIOD", &cfg.Database.HealthCheckPeriod, time.Minute, 5*time.Minute},
		{"DB_CONNECT_TIMEOUT", &cfg.Database.ConnectTimeout, 10*time.Second, time.Minute},
		{"DB_READINESS_TIMEOUT", &cfg.Database.ReadinessTimeout, time.Second, 5*time.Second},
	}
	for _, item := range durations {
		value, err := durationEnv(item.key, item.fallback, item.maximum)
		if err != nil {
			return Config{}, err
		}
		*item.target = value
	}
	if cfg.HTTP.ReadHeaderTimeout > cfg.HTTP.ReadTimeout {
		return Config{}, errors.New("HTTP_READ_HEADER_TIMEOUT must not exceed HTTP_READ_TIMEOUT")
	}
	if cfg.Database.ReadinessTimeout >= cfg.HTTP.WriteTimeout {
		return Config{}, errors.New("DB_READINESS_TIMEOUT must be shorter than HTTP_WRITE_TIMEOUT")
	}
	cfg.Identity, err = loadIdentity(env)
	if err != nil { return Config{}, err }
	cfg.Realtime, err = loadRealtime(env, cfg.Identity.Enabled)
	if err != nil { return Config{}, err }
	cfg.Safety, cfg.Admin, err = loadSafety(env, cfg.Realtime.Enabled)
	if err != nil { return Config{}, err }
	cfg.Friends, err = loadFriends(env, cfg.Safety.Enabled)
	if err != nil { return Config{}, err }
	cfg.Payments, err = loadPayments(env, cfg.Identity.Enabled, cfg.Safety.Enabled, cfg.Admin.Enabled)
	if err != nil { return Config{}, err }
	cfg.Audio, err = loadAudio(env, cfg.Safety.Enabled)
	if err != nil { return Config{}, err }
 cfg.Operations,err=loadOperations(env,cfg.Identity.Enabled,cfg.Safety.Enabled,cfg.Admin.Enabled)
 if err!=nil{return Config{},err}
	if cfg.Admin.Enabled && (cfg.Admin.Origin == cfg.PublicOrigin || cfg.Admin.Addr == cfg.HTTP.Addr) { return Config{}, errors.New("admin origin and listener must be separate from the public application") }
	if cfg.Admin.Enabled && env.Deployed() {
		privateOrigin, _ := url.Parse(cfg.Admin.Origin)
		publicOrigin, _ := url.Parse(cfg.PublicOrigin)
		if strings.EqualFold(strings.TrimSuffix(privateOrigin.Hostname(), "."), strings.TrimSuffix(publicOrigin.Hostname(), ".")) { return Config{}, errors.New("deployed admin requires a separate hostname for cookie isolation") }
	}
	return cfg, nil
}

func (e Environment) Valid() bool {
	switch e {
	case EnvironmentDevelopment, EnvironmentTest, EnvironmentStaging, EnvironmentProduction:
		return true
	}
	return false
}
func (e Environment) Deployed() bool {
	return e == EnvironmentStaging || e == EnvironmentProduction
}

func ValidateHTTPAddr(addr string) error {
	host, port, err := net.SplitHostPort(addr)
	if err != nil || strings.ContainsAny(host, " /\\\t\r\n") {
		return errors.New("HTTP_ADDR must be a host:port address")
	}
	value, err := strconv.Atoi(port)
	if err != nil || value < 1 || value > 65535 {
		return errors.New("HTTP_ADDR port must be between 1 and 65535")
	}
	return nil
}

func validateOrigin(raw string, env Environment) error {
	u, err := url.Parse(raw)
	if err != nil || u.Scheme == "" || u.Hostname() == "" || u.User != nil || u.Path != "" || u.RawPath != "" || u.RawQuery != "" || u.ForceQuery || strings.Contains(raw, "#") || strings.HasSuffix(u.Host, ":") || u.Fragment != "" || u.Opaque != "" {
		return errors.New("PUBLIC_ORIGIN must be an http(s) origin without credentials, path, query, or fragment")
	}
	if u.Scheme != "http" && u.Scheme != "https" {
		return errors.New("PUBLIC_ORIGIN must use http or https")
	}
	if env.Deployed() && u.Scheme != "https" {
		return errors.New("PUBLIC_ORIGIN must use https in staging and production")
	}
	if port := u.Port(); port != "" {
		n, err := strconv.Atoi(port)
		if err != nil || n < 1 || n > 65535 {
			return errors.New("PUBLIC_ORIGIN has an invalid port")
		}
	}
	return nil
}

func validateDatabaseURL(raw string) error {
	// url.Parse and pgx errors can embed passwords. Never return their text.
	u, err := url.Parse(raw)
	if err != nil || u == nil || strings.ContainsAny(raw, "\r\n\x00") {
		return errors.New("DATABASE_URL is invalid")
	}
	if u.Scheme != "postgres" && u.Scheme != "postgresql" {
		return errors.New("DATABASE_URL must use postgres or postgresql scheme")
	}
	if u.Hostname() == "" || u.User == nil || u.User.Username() == "" || strings.TrimPrefix(u.Path, "/") == "" || u.Fragment != "" {
		return errors.New("DATABASE_URL must include a user, host, and database name, with no fragment")
	}
	if _, err := url.ParseQuery(u.RawQuery); err != nil {
		return errors.New("DATABASE_URL has invalid connection options")
	}
	return nil
}

func defaultLogLevel(env Environment) string {
	if env == EnvironmentDevelopment {
		return "debug"
	}
	return "info"
}
func validLogLevel(level string) bool {
	switch level {
	case "debug", "info", "warn", "error":
		return true
	}
	return false
}
func getenv(key, fallback string) string {
	if value := strings.TrimSpace(os.Getenv(key)); value != "" {
		return value
	}
	return fallback
}
func durationEnv(key string, fallback, maximum time.Duration) (time.Duration, error) {
	raw := strings.TrimSpace(os.Getenv(key))
	if raw == "" {
		return fallback, nil
	}
	value, err := time.ParseDuration(raw)
	if err != nil || value <= 0 || value > maximum {
		return 0, fmt.Errorf("%s must be a positive duration no greater than %s", key, maximum)
	}
	return value, nil
}
func int32Env(key string, fallback int32) (int32, error) {
	raw := strings.TrimSpace(os.Getenv(key))
	if raw == "" {
		return fallback, nil
	}
	value, err := strconv.ParseInt(raw, 10, 32)
	if err != nil {
		return 0, fmt.Errorf("%s must be an integer", key)
	}
	return int32(value), nil
}

func secretValue(key string) (string, error) {
	inline := strings.TrimSpace(os.Getenv(key))
	path := strings.TrimSpace(os.Getenv(key + "_FILE"))
	if inline != "" && path != "" {
		return "", fmt.Errorf("set only one of %s or %s_FILE", key, key)
	}
	if path == "" {
		return inline, nil
	}
	info, err := os.Stat(path)
	if err != nil || !info.Mode().IsRegular() {
		return "", fmt.Errorf("%s_FILE must be a readable regular file", key)
	}
	file, err := os.Open(path)
	if err != nil {
		return "", fmt.Errorf("%s_FILE cannot be read", key)
	}
	defer file.Close()
	info, err = file.Stat()
	if err != nil || !info.Mode().IsRegular() {
		return "", fmt.Errorf("%s_FILE must be a regular file", key)
	}
	const maximum = 64 << 10
	data, err := io.ReadAll(io.LimitReader(file, maximum + 1))
	if err != nil || len(data) > maximum {
		return "", fmt.Errorf("%s_FILE cannot be read or exceeds 64 KiB", key)
	}
	value := strings.TrimSpace(string(data))
	if value == "" {
		return "", fmt.Errorf("%s_FILE is empty", key)
	}
	return value, nil
}
