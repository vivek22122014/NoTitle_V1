package config

import (
 "errors"
 "net"
 "net/url"
 "os"
 "strings"
)
type OperationsConfig struct {
 Enabled,CoverageApproved bool
 KeyringFile,PolicyFile,HoldJournalDirectory,ObservationFile string
 PrimaryURL,BackupURL,PrimaryTokenFile,BackupTokenFile,CoverageReference string
}
func loadOperations(env Environment,identityEnabled,safetyEnabled,adminEnabled bool)(OperationsConfig,error){
 var c OperationsConfig;var err error;c.Enabled,err=featureFlag("OPERATIONS_ENABLED",false);if err!=nil{return c,err};c.CoverageApproved,err=featureFlag("OPERATIONS_COVERAGE_APPROVED",false);if err!=nil{return c,err};if !c.Enabled{return c,nil}
 if !identityEnabled||!safetyEnabled||!adminEnabled{return c,errors.New("operations require identity, safety and private administration")}
 c.KeyringFile=getenv("OPERATIONS_KEYRING_FILE","");c.PolicyFile=getenv("RETENTION_POLICY_FILE","");c.HoldJournalDirectory=getenv("HOLD_JOURNAL_DIR","");c.ObservationFile=getenv("OPERATIONS_OBSERVATION_FILE","")
 for _,field:=range []struct{name,value string}{{"OPERATIONS_KEYRING_FILE",c.KeyringFile},{"RETENTION_POLICY_FILE",c.PolicyFile},{"HOLD_JOURNAL_DIR",c.HoldJournalDirectory}}{if !cleanSecretPath(field.value){return c,errors.New(field.name+" must be a clean absolute protected path")}}
 // Match the effective defaults used by loadSafety/loadIdentity. An omitted
 // environment variable does not make that feature's protected path absent.
 if c.KeyringFile==getenv("EVIDENCE_KEYRING_FILE","/run/secrets/evidence_keyring")||c.KeyringFile==getenv("ADMIN_MFA_KEY_FILE","/run/secrets/admin_mfa_key"){return c,errors.New("operations case encryption requires its own keyring")}
 if c.HoldJournalDirectory==getenv("DELETION_TOMBSTONE_DIR","/var/lib/notitle/tombstones"){return c,errors.New("hold journal requires its own independent directory")}
 if c.ObservationFile!=""&&!cleanSecretPath(c.ObservationFile){return c,errors.New("OPERATIONS_OBSERVATION_FILE must be a clean absolute protected path")}
 c.PrimaryURL=getenv("OPERATIONS_ALERT_PRIMARY_URL","");c.BackupURL=getenv("OPERATIONS_ALERT_BACKUP_URL","");c.PrimaryTokenFile=getenv("OPERATIONS_ALERT_PRIMARY_TOKEN_FILE","");c.BackupTokenFile=getenv("OPERATIONS_ALERT_BACKUP_TOKEN_FILE","")
 for _,destination:=range []struct{endpoint,path string}{{c.PrimaryURL,c.PrimaryTokenFile},{c.BackupURL,c.BackupTokenFile}}{if (destination.endpoint=="")!=(destination.path==""){return c,errors.New("each operator alert endpoint requires a protected token file")};if destination.endpoint!=""&&(!operatorEndpoint(destination.endpoint)||!cleanSecretPath(destination.path)){return c,errors.New("operator alert destinations require an exact HTTPS URL and protected absolute token file")}}
 if c.PrimaryURL!=""&&c.PrimaryURL==c.BackupURL{return c,errors.New("primary and backup alerts require distinct approved destinations")}
 if c.PrimaryTokenFile!=""&&c.PrimaryTokenFile==c.BackupTokenFile{return c,errors.New("primary and backup alerts require separate credential files")}
 for _,key:=range []string{"OPERATIONS_ALERT_PRIMARY_TOKEN","OPERATIONS_ALERT_BACKUP_TOKEN"}{if strings.TrimSpace(os.Getenv(key))!=""{return c,errors.New("operator alert credentials must use protected files")}}
 c.CoverageReference=getenv("OPERATIONS_COVERAGE_REFERENCE","")
 if env.Deployed(){if !c.CoverageApproved||len(c.CoverageReference)<5||len(c.CoverageReference)>200||strings.ContainsAny(c.CoverageReference,"\r\n\x00")||c.ObservationFile==""||c.PrimaryURL==""||c.BackupURL==""{return c,errors.New("deployed operations require reviewed primary and backup coverage, its evidence reference, two alert destinations and monitored observations")}}
 return c,nil
}
func operatorEndpoint(raw string)bool{u,err:=url.Parse(raw);if err!=nil||u.Scheme!="https"||u.Hostname()==""||u.User!=nil||u.RawQuery!=""||u.ForceQuery||u.Fragment!=""||u.Opaque!=""||u.RawPath!=""||len(raw)>1024{return false};if u.Port()!=""&&u.Port()!="443"{return false};host:=strings.ToLower(u.Hostname());if host=="localhost"||!strings.Contains(host,".")||strings.HasSuffix(host,".local")||strings.HasSuffix(host,".internal")||strings.HasSuffix(host,".localhost")||net.ParseIP(host)!=nil{return false};return !strings.ContainsAny(raw,"\r\n\x00")}
