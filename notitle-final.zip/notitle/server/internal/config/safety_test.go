package config

import (
	"testing"
	"os"
	"path/filepath"
)

func TestSafetyAndAdminFeatureGates(t *testing.T) {
	testEnvironment(t)
	s,a,err:=loadSafety(EnvironmentDevelopment,true)
	if err!=nil || !s.Enabled || !a.Enabled || a.Addr!="127.0.0.1:9090" { t.Fatal("local safety defaults invalid") }
	s,a,err=loadSafety(EnvironmentProduction,true)
	if err!=nil || s.Enabled || a.Enabled { t.Fatal("deployed safety must default off") }
	t.Setenv("SAFETY_ENABLED","true")
	if _,_,err:=loadSafety(EnvironmentDevelopment,false);err==nil { t.Fatal("safety enabled without realtime") }
	if _,_,err:=loadSafety(EnvironmentProduction,true);err==nil { t.Fatal("deployed safety bypassed operations requirements") }
	t.Setenv("ADMIN_ENABLED","true");t.Setenv("ADMIN_ORIGIN","https://operations.example")
	t.Setenv("CASE_RETENTION_DAYS","45");t.Setenv("CASE_RETENTION_POLICY_VERSION","reviewed-test-version")
	t.Setenv("MODERATION_COVERAGE_CONFIRMED","true")
	if _,_,err:=loadSafety(EnvironmentProduction,true);err!=nil { t.Fatal(err) }
	t.Setenv("CASE_RETENTION_DAYS","0")
	if _,_,err:=loadSafety(EnvironmentProduction,true);err==nil { t.Fatal("invalid retention accepted") }
}
func TestAdminCannotSharePublicOriginOrKey(t *testing.T) {
	testEnvironment(t)
	t.Setenv("ADMIN_ORIGIN","http://localhost:5173")
	if _,err:=Load();err==nil { t.Fatal("private admin reused public origin") }
	t.Setenv("ADMIN_ORIGIN","http://localhost:9090");t.Setenv("ADMIN_MFA_KEY_FILE","/run/secrets/evidence_keyring")
	if _,err:=Load();err==nil { t.Fatal("MFA reused evidence key file") }
}
func TestDeployedAdminCookiesUseSeparateHostname(t *testing.T) {
	testEnvironment(t)
 t.Setenv("MAINTENANCE_MODE","true")
	path:=filepath.Join(t.TempDir(),"database-url")
	if err:=os.WriteFile(path,[]byte(os.Getenv("DATABASE_URL")),0600);err!=nil {t.Fatal(err)}
	for k,v:=range map[string]string{"DATABASE_URL":"","DATABASE_URL_FILE":path,"APP_ENV":"production","PUBLIC_ORIGIN":"https://app.example","IDENTITY_ENABLED":"true","REALTIME_ENABLED":"true","SAFETY_ENABLED":"true","ADMIN_ENABLED":"true","ADMIN_ORIGIN":"https://app.example:9443","TERMS_VERSION":"approved-test","PRIVACY_VERSION":"approved-test","COMMUNITY_VERSION":"approved-test","CASE_RETENTION_DAYS":"30","CASE_RETENTION_POLICY_VERSION":"approved-test","MODERATION_COVERAGE_CONFIRMED":"true"} {t.Setenv(k,v)}
	if _,err:=Load();err==nil {t.Fatal("admin cookies could leak to public hostname on another port")}
	t.Setenv("ADMIN_ORIGIN","https://operations.example")
	if _,err:=Load();err!=nil {t.Fatal(err)}
}
