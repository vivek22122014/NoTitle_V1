package config

import "errors"

type AdmissionConfig struct { Maintenance bool; ApprovalFile,APIImage,ManifestSHA256,Stage string }
func loadAdmission(env Environment)(AdmissionConfig,error){
    var c AdmissionConfig;var err error
    c.Maintenance,err=featureFlag("MAINTENANCE_MODE",false);if err!=nil{return c,err}
    c.ApprovalFile=getenv("LAUNCH_APPROVAL_FILE","");c.APIImage=getenv("DEPLOYED_API_IMAGE","")
    c.ManifestSHA256=getenv("DEPLOYMENT_MANIFEST_SHA256","");c.Stage=getenv("LAUNCH_STAGE","validation")
    if c.Stage!="validation"&&c.Stage!="cohort"&&c.Stage!="public"{return c,errors.New("LAUNCH_STAGE must be validation, cohort or public")}
    if c.ApprovalFile!=""&&!cleanSecretPath(c.ApprovalFile){return c,errors.New("LAUNCH_APPROVAL_FILE must be a clean protected absolute path")}
    // Production startup is always paused. A prior process's open state cannot
    // survive replacement of its binary or restored database automatically.
    if env==EnvironmentProduction&&!c.Maintenance{return c,errors.New("production requires MAINTENANCE_MODE=true until the private owner launch check")}
    return c,nil
}
