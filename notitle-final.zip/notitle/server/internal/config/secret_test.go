package config

import (
	"os"
	"path/filepath"
	"testing"
	"strings"
)

func TestSecretValueFromFile(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "secret")
	if err := os.WriteFile(path, []byte("value-from-file\n"), 0o600); err != nil {
		t.Fatal(err)
	}

	t.Setenv("TEST_SECRET", "")
	t.Setenv("TEST_SECRET_FILE", path)

	got, err := secretValue("TEST_SECRET")
	if err != nil {
		t.Fatalf("secretValue() error = %v", err)
	}
	if got != "value-from-file" {
		t.Fatalf("secretValue() = %q", got)
	}
}

func TestSecretValueRejectsInlineAndFile(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "secret")
	if err := os.WriteFile(path, []byte("file"), 0o600); err != nil {
		t.Fatal(err)
	}

	t.Setenv("TEST_SECRET", "inline")
	t.Setenv("TEST_SECRET_FILE", path)

	if _, err := secretValue("TEST_SECRET"); err == nil {
		t.Fatal("expected conflicting secret source error")
	}
}

func TestSecretFileErrorsDoNotExposePath(t *testing.T) {
	t.Setenv("TEST_SECRET", "")
	t.Setenv("TEST_SECRET_FILE", filepath.Join(t.TempDir(), "sensitive-path"))
	_, err := secretValue("TEST_SECRET")
	if err == nil || strings.Contains(err.Error(), "sensitive-path") {
		t.Fatal("file error exposed path or accepted missing file")
	}
}

func TestSecretFileRejectsOversizeAndEmpty(t *testing.T) {
	t.Setenv("TEST_SECRET", "")
	for _, data := range [][]byte{[]byte(" \n"), make([]byte, (64 << 10) + 1)} {
		path := filepath.Join(t.TempDir(), "secret")
		if err := os.WriteFile(path, data, 0600); err != nil {
			t.Fatal(err)
		}
		t.Setenv("TEST_SECRET_FILE", path)
		if _, err := secretValue("TEST_SECRET"); err == nil {
			t.Fatal("invalid secret file accepted")
		}
	}
}
