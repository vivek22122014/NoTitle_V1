package config

import (
	"errors"
	"os"
	"strings"
)

// Realtime does not enable later text, audio, friendship or payment features.
// Admission caps are fixed by the tested launch contract, not public env knobs.
type RealtimeConfig struct { Enabled bool }

func loadRealtime(env Environment, identityEnabled bool) (RealtimeConfig, error) {
	cfg := RealtimeConfig{Enabled: !env.Deployed() && identityEnabled}
	if value := strings.TrimSpace(os.Getenv("REALTIME_ENABLED")); value != "" {
		switch value {
		case "true": cfg.Enabled = true
		case "false": cfg.Enabled = false
		default: return cfg, errors.New("REALTIME_ENABLED must be true or false")
		}
	}
	if cfg.Enabled && !identityEnabled { return cfg, errors.New("REALTIME_ENABLED requires IDENTITY_ENABLED") }
	return cfg, nil
}
