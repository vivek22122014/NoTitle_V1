package config

import "testing"

func TestRealtimeReleaseAndIdentityGates(t *testing.T) {
	t.Setenv("REALTIME_ENABLED", "")
	for _, env := range []Environment{EnvironmentDevelopment, EnvironmentTest, EnvironmentStaging, EnvironmentProduction} {
		cfg, err := loadRealtime(env, true)
		if err != nil || cfg.Enabled == env.Deployed() { t.Fatal("unexpected realtime environment default") }
		cfg, err = loadRealtime(env, false)
		if err != nil || cfg.Enabled { t.Fatal("realtime implicitly enabled without identity") }
	}
	t.Setenv("REALTIME_ENABLED", "true")
	if _, err := loadRealtime(EnvironmentProduction, false); err == nil { t.Fatal("realtime accepted without identity") }
	if cfg, err := loadRealtime(EnvironmentProduction, true); err != nil || !cfg.Enabled { t.Fatal("explicit deployed enablement rejected") }
	t.Setenv("REALTIME_ENABLED", "1")
	if _, err := loadRealtime(EnvironmentTest, true); err == nil { t.Fatal("ambiguous flag accepted") }
}
