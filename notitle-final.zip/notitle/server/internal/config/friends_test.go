package config

import "testing"

func TestFriendsRequireSafetyAndBoundedCapacity(t *testing.T) {
	testEnvironment(t)
	local,err:=loadFriends(EnvironmentDevelopment,true)
	if err!=nil || !local.Enabled || local.MaxPerIdentity!=100 {t.Fatal("invalid local friendship defaults")}
	deployed,err:=loadFriends(EnvironmentProduction,true)
	if err!=nil || deployed.Enabled {t.Fatal("deployed friendships enabled by default")}
	t.Setenv("FRIENDS_ENABLED","true")
	if _,err:=loadFriends(EnvironmentDevelopment,false);err==nil {t.Fatal("friendship without safety accepted")}
	for _,value:=range []string{"0","101","-1","ten"} {
		t.Setenv("FRIENDS_PER_IDENTITY",value)
		if _,err:=loadFriends(EnvironmentDevelopment,true);err==nil {t.Fatal("unbounded relationship configuration accepted")}
	}
	t.Setenv("FRIENDS_PER_IDENTITY","25")
	if cfg,err:=loadFriends(EnvironmentDevelopment,true);err!=nil || cfg.MaxPerIdentity!=25 {t.Fatal("bounded operator limit rejected")}
	t.Setenv("FRIENDS_ENABLED","yes")
	if _,err:=loadFriends(EnvironmentDevelopment,true);err==nil {t.Fatal("ambiguous feature flag accepted")}
}
