package realtimehttp

import (
 "crypto/rand"
 "crypto/sha256"
 "encoding/base64"
 "errors"
 "sync"
 "time"

 "notitle/internal/identity"
)

const TicketTTL = 60 * time.Second
const ticketCapacity = 400

var errTicket = errors.New("invalid realtime ticket")

type TicketDTO struct {
 Ticket string `json:"ticket"`
 ExpiresAt time.Time `json:"expires_at"`
 ProtocolVersion int `json:"protocol_version"`
}
type ticketRecord struct {
 session identity.Verifier
 takeover bool
 expires time.Time
}
type ticketStore struct {
 mu sync.Mutex
 records map[[32]byte]ticketRecord
}
func newTickets() *ticketStore { return &ticketStore{records:make(map[[32]byte]ticketRecord)} }
func (s *ticketStore) issue(p identity.Principal, takeover bool, now time.Time) (TicketDTO,error) {
 var raw [32]byte
 if _,err:=rand.Read(raw[:]);err!=nil { return TicketDTO{},identity.ErrUnavailable }
 token:=base64.RawURLEncoding.EncodeToString(raw[:]); key:=sha256.Sum256([]byte(token))
 s.mu.Lock(); defer s.mu.Unlock()
 count:=0
 for k,v:=range s.records { if !now.Before(v.expires) { delete(s.records,k) } else if v.session==p.TokenHash { count++ } }
 // Two unconsumed tickets permit a failed opening and an explicit second tab,
 // without allowing one authenticated session to exhaust the global store.
 if count>=2 || len(s.records)>=ticketCapacity { return TicketDTO{},identity.ErrCapacity }
 expiry:=now.Add(TicketTTL)
 s.records[key]=ticketRecord{session:p.TokenHash,takeover:takeover,expires:expiry}
 return TicketDTO{Ticket:token,ExpiresAt:expiry,ProtocolVersion:1},nil
}
func (s *ticketStore) consume(token string, now time.Time) (ticketRecord,error) {
 if len(token)!=43 { return ticketRecord{},errTicket }
 raw,err:=base64.RawURLEncoding.Strict().DecodeString(token); if err!=nil || len(raw)!=32 { return ticketRecord{},errTicket }
 key:=sha256.Sum256([]byte(token))
 s.mu.Lock(); defer s.mu.Unlock()
 record,ok:=s.records[key]
 // Burn before the cookie lookup. The handler compares this session verifier
 // with fresh authentication; failed use never permits a second attempt.
 delete(s.records,key)
 if !ok || !now.Before(record.expires) { return ticketRecord{},errTicket }
 return record,nil
}
func (s *ticketStore) clear() { s.mu.Lock(); clear(s.records); s.mu.Unlock() }
