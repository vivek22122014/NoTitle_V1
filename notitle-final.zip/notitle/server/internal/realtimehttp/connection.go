package realtimehttp

import (
 "context"
 "errors"
 "time"

 "github.com/coder/websocket"
 "notitle/internal/identity"
 "notitle/internal/realtime"
)

func (h *Handler) run(parent context.Context,c *websocket.Conn,p identity.Principal,connection realtime.Connection,initialLease time.Time) {
 ctx,cancel:=context.WithCancel(parent)
 responses:=make(chan realtime.ServerEvent,realtime.OutboundCapacity)
 writerDone:=make(chan struct{});monitorDone:=make(chan struct{})
 defer func(){cancel();_=c.CloseNow();<-writerDone;<-monitorDone}()
 // Exactly one application-data writer. Library-managed control frames remain
 // safe concurrently with the reader, as required for ping/close handshakes.
 go func(){
  defer close(writerDone);defer cancel();defer c.CloseNow()
  heartbeat:=time.NewTicker(realtime.HeartbeatInterval);defer heartbeat.Stop()
  for {
   // Never emit an old queued peer event after takeover or invalidation.
   select{case <-connection.Closed:finishActorClosure(ctx,c,connection);return;default:}
   select {
   case <-ctx.Done():return
   case <-connection.Closed:finishActorClosure(ctx,c,connection);return
   case event,ok:=<-connection.Events:
    if !ok{finishActorClosure(ctx,c,connection);return}
    select{case <-connection.Closed:finishActorClosure(ctx,c,connection,event);return;default:}
    if err:=writeEvent(ctx,c,event);err!=nil{return}
   case event:=<-responses:
    if err:=writeEvent(ctx,c,event);err!=nil{return}
    if payload,ok:=event.Payload.(realtime.ErrorPayload);ok && (payload.Code=="AUTHENTICATION_REQUIRED" || payload.Code=="BLOCKED"){closeSocket(c,websocket.StatusPolicyViolation,payload.Code);return}
   case <-heartbeat.C:
    pingCtx,pingCancel:=context.WithTimeout(ctx,realtime.DeadConnectionTimeout-realtime.HeartbeatInterval)
    err:=c.Ping(pingCtx);pingCancel();if err!=nil{return}
   }
  }
 }()
 go func(){
  defer close(monitorDone)
  leaseUntil:=initialLease
  timer:=time.NewTimer(10*time.Second);defer timer.Stop()
  for {
   select{
   case <-ctx.Done():return
   case <-connection.Closed:time.AfterFunc(500*time.Millisecond,func(){_=c.CloseNow()});return
   case <-timer.C:
    if !h.now().Before(leaseUntil){closeSocket(c,websocket.StatusPolicyViolation,"AUTHENTICATION_REQUIRED");cancel();return}
    // Each live socket contributes at most one bounded waiter. Foreground
    // requests fail fast, whereas renewals wait briefly to avoid synchronized
    // expiry of otherwise healthy users after a reconnect burst.
    refreshCtx,refreshCancel:=context.WithTimeout(ctx,2*time.Second)
    select{case h.authSlots<-struct{}{}:case <-refreshCtx.Done():refreshCancel();timer.Reset(time.Second);continue}
    snapshot,err:=h.authorizer.Authorize(refreshCtx,p)
    <-h.authSlots;refreshCancel()
    if err!=nil {
     if errors.Is(err,identity.ErrBusy){timer.Reset(time.Second);continue}
     closeSocket(c,websocket.StatusPolicyViolation,realtime.PublicError(publicAuthError(err)).Code);cancel();return
    }
    if err=h.actor.Refresh(ctx,snapshot);err!=nil{
     if errors.Is(err,realtime.ErrUnavailable){timer.Reset(time.Second);continue}
     closeSocket(c,websocket.StatusPolicyViolation,"SESSION_CLOSED");cancel();return
    }
    leaseUntil=snapshot.ValidUntil
    timer.Reset(10*time.Second)
   }
  }
 }()
 tokens:=20.0;updated:=h.now()
 for {
  kind,data,err:=c.Read(ctx);if err!=nil{return}
  if kind!=websocket.MessageText {closeSocket(c,websocket.StatusUnsupportedData,"INVALID_EVENT");return}
  now:=h.now();elapsed:=now.Sub(updated).Seconds();if elapsed<0{elapsed=0};tokens+=elapsed*5;if tokens>20{tokens=20};updated=now
  if tokens<1 {closeSocket(c,websocket.StatusPolicyViolation,"RATE_LIMITED");return};tokens--
  event,err:=realtime.DecodeEnvelope(data)
  if err!=nil {select{case responses<-errorEvent(event.ID,connection.Ref.Generation,err):default:return};continue}
  // The actor checks ownership and generation again at mutation, after this
  // external session/storage read. Unsupported events never reach storage.
  if event.Type=="session.authenticate" {select{case responses<-errorEvent(event.ID,connection.Ref.Generation,realtime.ErrProtocol):default:return};continue}
  // Text and accepted-call signaling use the short authorization lease,
  // renewed every 10s. Ending/declining a call must not wait on database reads.
  // The owner rechecks binding, generation, epoch, lease, both peers and safety
  // at mutation. Priority revocation/outage handling still terminates the epoch.
  // This avoids database work for every message and rendered-delivery receipt.
  if event.Type=="chat.send" || event.Type=="chat.delivery_ack" || event.Type=="call.end" || event.Type=="call.decline" || event.Type=="call.connected" || event.Type=="webrtc.offer" || event.Type=="webrtc.answer" || event.Type=="webrtc.ice" {
   if err=h.actor.Command(ctx,connection.Ref,event);err!=nil {select{case responses<-errorEvent(event.ID,connection.Ref.Generation,err):default:return}}
   continue
  }
  snapshot,err:=h.authorize(ctx,p)
  if err!=nil {
   public:=realtime.PublicError(publicAuthError(err))
   select{case responses<-errorEvent(event.ID,connection.Ref.Generation,public):default:return}
   if public.Code=="AUTHENTICATION_REQUIRED" || public.Code=="BLOCKED"{<-ctx.Done();return}
   continue
  }
  if err=h.actor.Refresh(ctx,snapshot);err==nil {err=h.actor.Command(ctx,connection.Ref,event)}
  if err!=nil {select{case responses<-errorEvent(event.ID,connection.Ref.Generation,err):default:return}}
 }
}

// The actor prunes its old outbox before signaling Closed. Only terminal event
// types may cross this path; no stale peer payload can drain after replacement.
func finishActorClosure(ctx context.Context,c *websocket.Conn,connection realtime.Connection,pending ...realtime.ServerEvent){
 writeTerminal:=func(event realtime.ServerEvent){
  if event.Type=="session.replaced" || event.Type=="session.closed"{
   terminalCtx,cancel:=context.WithTimeout(ctx,250*time.Millisecond);_=writeEvent(terminalCtx,c,event);cancel()
  }
 }
 for _,event:=range pending{writeTerminal(event)}
 for {
  select{
  case event,ok:=<-connection.Events:
   if !ok{closeSocket(c,websocket.StatusPolicyViolation,"SESSION_CLOSED");return}
   writeTerminal(event)
  default:closeSocket(c,websocket.StatusPolicyViolation,"SESSION_CLOSED");return
  }
 }
}
