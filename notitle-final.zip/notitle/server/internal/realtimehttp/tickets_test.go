package realtimehttp

import (
 "strings"
 "testing"
 "time"

 "notitle/internal/identity"
)

func TestTicketsExpireOnceAndStoreOnlyVerifiers(t *testing.T) {
 now:=time.Date(2026,10,9,12,0,0,0,time.UTC)
 store:=newTickets();p:=identity.Principal{TokenHash:identity.Verifier{1}}
 ticket,err:=store.issue(p,true,now);if err!=nil{t.Fatal(err)}
 if len(ticket.Ticket)!=43 || ticket.ExpiresAt.Sub(now)!=60*time.Second || ticket.ProtocolVersion!=1{t.Fatal("wrong ticket contract")}
 record,err:=store.consume(ticket.Ticket,now.Add(59*time.Second));if err!=nil || !record.takeover || record.session!=p.TokenHash{t.Fatal("valid ticket rejected")}
 if _,err=store.consume(ticket.Ticket,now);err==nil{t.Fatal("ticket replay accepted")}
 expired,_:=store.issue(p,false,now)
 if _,err=store.consume(expired.Ticket,now.Add(TicketTTL));err==nil{t.Fatal("boundary-expired ticket accepted")}
 if _,err=store.consume(strings.Repeat("A",10000),now);err==nil{t.Fatal("oversized ticket accepted")}
}
func TestTicketBudgetsAndExpiryCleanup(t *testing.T) {
 now:=time.Now();s:=newTickets();p:=identity.Principal{TokenHash:identity.Verifier{1}}
 for range 2{if _,err:=s.issue(p,false,now);err!=nil{t.Fatal(err)}}
 if _,err:=s.issue(p,false,now);err==nil{t.Fatal("per-session budget exceeded")}
 if _,err:=s.issue(p,false,now.Add(TicketTTL));err!=nil{t.Fatal("expired ticket did not free budget")}
 s.clear();if len(s.records)!=0{t.Fatal("shutdown retained tickets")}
}
