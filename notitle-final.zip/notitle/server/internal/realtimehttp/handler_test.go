package realtimehttp

import (
 "bytes"
 "context"
 "encoding/json"
 "log/slog"
 "net/http"
 "net/http/httptest"
 "strings"
 "sync"
 "testing"
 "time"

 "github.com/coder/websocket"
 "notitle/internal/coordinator"
 "notitle/internal/httpserver/middleware"
 "notitle/internal/identity"
 "notitle/internal/platform/clock"
 "notitle/internal/realtime"
)

type testIdentity struct{principals map[string]identity.Principal}
func (a testIdentity)Authenticate(_ context.Context,cookie string,_ bool)(identity.Principal,error){p,ok:=a.principals[cookie];if !ok{return p,identity.ErrUnauthorized};return p,nil}
type testAuthorizer struct{actor realtime.Actor}
func (a testAuthorizer)Authorize(ctx context.Context,p identity.Principal)(realtime.AuthSnapshot,error){
 fence,err:=a.actor.AuthFence(ctx);if err!=nil{return realtime.AuthSnapshot{},err}
 now:=time.Now()
 return realtime.AuthSnapshot{Fence:fence,Kind:p.Kind,IdentityID:p.AccountSession.Account.ID,SessionID:p.AccountSession.Session.ID,IdentityGeneration:1,SessionVerifier:p.TokenHash,Profile:p.AccountSession.Account.Profile,Preferences:realtime.DefaultPreferences(),Entitlement:realtime.Entitlement{Version:1},SafetyVersion:1,AuthorizedAt:now,ValidUntil:now.Add(30*time.Second)},nil
}
type lockedBuffer struct{mu sync.Mutex;buffer bytes.Buffer}
func(b *lockedBuffer)Write(p []byte)(int,error){b.mu.Lock();defer b.mu.Unlock();return b.buffer.Write(p)}
func(b *lockedBuffer)String()string{b.mu.Lock();defer b.mu.Unlock();return b.buffer.String()}
type wsFixture struct{handler *Handler;server *httptest.Server;principals map[string]identity.Principal;logs *lockedBuffer}
func fixture(t *testing.T)*wsFixture{
 t.Helper();ctx,cancel:=context.WithCancel(context.Background());owner:=coordinator.New(clock.System{})
 go func(){_=owner.Run(ctx)}()
 readyCtx,readyCancel:=context.WithTimeout(ctx,time.Second);defer readyCancel()
 for owner.Ready(readyCtx)!=nil{if readyCtx.Err()!=nil{t.Fatal("coordinator failed to start")};time.Sleep(time.Millisecond)}
 principals:=map[string]identity.Principal{}
 for i,key:=range []string{"COOKIE_ONE","COOKIE_TWO"}{principals[key]=identity.Principal{Kind:identity.KindAccount,TokenHash:identity.Verifier{byte(i+1)},AccountSession:identity.AccountSession{Account:identity.Account{ID:"private-account-"+key,Generation:1,Status:"active",Profile:identity.Profile{Version:1,DisplayName:"Participant",Gender:identity.GenderOther,Topic:"general_talk"}},Session:identity.SessionRecord{ID:"private-session-"+key}}}}
 h,err:=New(Options{PublicOrigin:"https://notitle.example",Identity:testIdentity{principals},Authorizer:testAuthorizer{owner},Actor:owner});if err!=nil{t.Fatal(err)}
 logs:=&lockedBuffer{};server:=httptest.NewServer(middleware.SecurityHeaders(middleware.RequestID(middleware.AccessLog(slog.New(slog.NewJSONHandler(logs,nil)),h))))
 t.Cleanup(func(){stop,stopCancel:=context.WithTimeout(context.Background(),time.Second);defer stopCancel();_=h.Close(stop);server.Close();cancel();<-owner.Done()})
 return &wsFixture{h,server,principals,logs}
}
func (f *wsFixture)dial(t *testing.T,cookie,origin,suffix string)(*websocket.Conn,*http.Response,error){
 t.Helper();ctx,cancel:=context.WithTimeout(context.Background(),2*time.Second);defer cancel()
 return websocket.Dial(ctx,"ws"+strings.TrimPrefix(f.server.URL,"http")+"/ws"+suffix,&websocket.DialOptions{HTTPHeader:http.Header{"Origin":[]string{origin},"Cookie":[]string{"__Host-session="+cookie}},CompressionMode:websocket.CompressionDisabled})
}
func readEvent(t *testing.T,c *websocket.Conn)realtime.ServerEvent{
 t.Helper();ctx,cancel:=context.WithTimeout(context.Background(),3*time.Second);defer cancel()
 _,data,err:=c.Read(ctx);if err!=nil{t.Fatal(err)}
 var event realtime.ServerEvent;if json.Unmarshal(data,&event)!=nil{t.Fatal("invalid server JSON")};return event
}
func send(t *testing.T,c *websocket.Conn,event realtime.ClientEnvelope){
 t.Helper();data,err:=json.Marshal(event);if err!=nil{t.Fatal(err)}
 ctx,cancel:=context.WithTimeout(context.Background(),time.Second);defer cancel();if err=c.Write(ctx,websocket.MessageText,data);err!=nil{t.Fatal(err)}
}
func authFrame(ticket string,takeover bool)realtime.ClientEnvelope{
 payload,_:=json.Marshal(realtime.AuthenticatePayload{Ticket:ticket,Takeover:takeover})
 return realtime.ClientEnvelope{V:1,ID:"auth-1",Type:"session.authenticate",Generation:0,Payload:payload}
}
func (f *wsFixture)connect(t *testing.T,cookie string)(*websocket.Conn,realtime.ServerEvent){
 t.Helper();ticket,err:=f.handler.IssueTicket(context.Background(),f.principals[cookie],false);if err!=nil{t.Fatal(err)}
 c,_,err:=f.dial(t,cookie,"https://notitle.example","");if err!=nil{t.Fatal(err)};t.Cleanup(func(){_=c.CloseNow()})
 send(t,c,authFrame(ticket.Ticket,false));event:=readEvent(t,c);if event.Type!="session.ready"{t.Fatalf("expected session.ready, got %s",event.Type)};return c,event
}
func TestWebSocketOriginQueryAndCookieGuards(t *testing.T){
 f:=fixture(t)
 for _,tc:=range []struct{origin,query,cookie string;status int}{{"https://evil.example","","COOKIE_ONE",403},{"","","COOKIE_ONE",403},{"https://notitle.example","?ticket=PRIVATE","COOKIE_ONE",400},{"https://notitle.example","","",401}}{
  c,response,err:=f.dial(t,tc.cookie,tc.origin,tc.query);if c!=nil{_=c.CloseNow()};if err==nil || response==nil || response.StatusCode!=tc.status{t.Fatalf("guard expected %d",tc.status)}
 }
}
func TestRealWebSocketsPairAndRejectTicketReplay(t *testing.T){
 f:=fixture(t);a,readyA:=f.connect(t,"COOKIE_ONE");b,readyB:=f.connect(t,"COOKIE_TWO")
 send(t,a,realtime.ClientEnvelope{V:1,ID:"join-a",Type:"queue.join",Generation:readyA.Generation,Payload:json.RawMessage(`{}`)})
 send(t,b,realtime.ClientEnvelope{V:1,ID:"join-b",Type:"queue.join",Generation:readyB.Generation,Payload:json.RawMessage(`{}`)})
 for _,c:=range []*websocket.Conn{a,b}{
  found:=false
  for range 5{event:=readEvent(t,c);if event.Type=="match.found"{encoded,_:=json.Marshal(event.Payload);if strings.Contains(string(encoded),"private-account")||strings.Contains(string(encoded),"private-session"){t.Fatal("private peer fields leaked")};found=true;break}}
  if !found{t.Fatal("participants did not match")}
 }
 ticket,err:=f.handler.IssueTicket(context.Background(),f.principals["COOKIE_ONE"],false);if err!=nil{t.Fatal(err)}
 for _,cookie:=range []string{"COOKIE_TWO","COOKIE_ONE"}{
  c,_,err:=f.dial(t,cookie,"https://notitle.example","");if err!=nil{t.Fatal(err)}
  send(t,c,authFrame(ticket.Ticket,false));event:=readEvent(t,c);data,_:=json.Marshal(event.Payload);if event.Type!="error"||!strings.Contains(string(data),"AUTHENTICATION_REQUIRED"){t.Fatal("mismatch or replay accepted")};_=c.CloseNow()
 }
}
func TestTakeoverChoiceBoundToTicketAndShutdownDrainsSockets(t *testing.T){
 f:=fixture(t);c,_:=f.connect(t,"COOKIE_ONE")
 ticket,err:=f.handler.IssueTicket(context.Background(),f.principals["COOKIE_TWO"],false);if err!=nil{t.Fatal(err)}
 other,_,err:=f.dial(t,"COOKIE_TWO","https://notitle.example","");if err!=nil{t.Fatal(err)}
 send(t,other,authFrame(ticket.Ticket,true));event:=readEvent(t,other);if event.Type!="error"{t.Fatal("ticket takeover choice changed")};_=other.CloseNow()
 idle,_,err:=f.dial(t,"COOKIE_TWO","https://notitle.example","");if err!=nil{t.Fatal(err)};defer idle.CloseNow()
 ctx,cancel:=context.WithTimeout(context.Background(),time.Second);defer cancel();if err=f.handler.Close(ctx);err!=nil{t.Fatal("hijacked shutdown did not drain")}
 _,_,err=c.Read(ctx);if err==nil{t.Fatal("socket survived shutdown")}
 if _,err=f.handler.IssueTicket(ctx,f.principals["COOKIE_ONE"],false);err==nil{t.Fatal("issued ticket after shutdown")}
}
func TestBinaryAndOversizeFramesCloseWithoutLoggingSecrets(t *testing.T){
 f:=fixture(t);c,_:=f.connect(t,"COOKIE_ONE")
 ctx,cancel:=context.WithTimeout(context.Background(),time.Second);defer cancel()
 if err:=c.Write(ctx,websocket.MessageBinary,[]byte("PRIVATE_PAYLOAD"));err!=nil{t.Fatal(err)}
 _,_,err:=c.Read(ctx);if err==nil{t.Fatal("binary frame accepted")};_=c.CloseNow()
 oversized,_:=f.connect(t,"COOKIE_TWO")
 _=oversized.Write(ctx,websocket.MessageText,[]byte(strings.Repeat("s",realtime.MaxFrameBytes+1)))
 _,_,err=oversized.Read(ctx);if err==nil{t.Fatal("oversized frame accepted")};_=oversized.CloseNow()
 // Ensure handlers have completed before inspecting the synchronous access log.
 stop,stopCancel:=context.WithTimeout(context.Background(),time.Second);defer stopCancel();_=f.handler.Close(stop)
 if strings.Contains(f.logs.String(),"PRIVATE_PAYLOAD")||strings.Contains(f.logs.String(),"COOKIE_ONE"){t.Fatal("credential or payload leaked to access log")}
}

func TestExplicitTakeoverDeliversTerminalEvent(t *testing.T){
 f:=fixture(t);original,_:=f.connect(t,"COOKIE_ONE")
 refusedTicket,err:=f.handler.IssueTicket(context.Background(),f.principals["COOKIE_ONE"],false);if err!=nil{t.Fatal(err)}
 refused,_,err:=f.dial(t,"COOKIE_ONE","https://notitle.example","");if err!=nil{t.Fatal(err)}
 send(t,refused,authFrame(refusedTicket.Ticket,false));event:=readEvent(t,refused)
 payload,_:=json.Marshal(event.Payload);if !strings.Contains(string(payload),"TAKEOVER_REQUIRED"){t.Fatal("silent takeover allowed")};_=refused.CloseNow()
 approved,err:=f.handler.IssueTicket(context.Background(),f.principals["COOKIE_ONE"],true);if err!=nil{t.Fatal(err)}
 replacement,_,err:=f.dial(t,"COOKIE_ONE","https://notitle.example","");if err!=nil{t.Fatal(err)};defer replacement.CloseNow()
 send(t,replacement,authFrame(approved.Ticket,true));if readEvent(t,replacement).Type!="session.ready"{t.Fatal("explicit takeover did not attach")}
 if readEvent(t,original).Type!="session.replaced"{t.Fatal("terminal replacement notice missing")}
}

func TestFirstFrameDeadlineClosesUnauthenticatedSocket(t *testing.T){
 f:=fixture(t);c,_,err:=f.dial(t,"COOKIE_ONE","https://notitle.example","");if err!=nil{t.Fatal(err)};defer c.CloseNow()
 ctx,cancel:=context.WithTimeout(context.Background(),realtime.FirstFrameTimeout+2*time.Second);defer cancel()
 _,_,err=c.Read(ctx);if err==nil || ctx.Err()!=nil{t.Fatal("first-frame deadline was not enforced by server")}
}
