// Package realtimehttp owns bounded tickets and WebSocket IO. The coordinator
// alone owns live participants; no database operation runs in its actor loop.
package realtimehttp

import (
 "bytes"
 "context"
 "encoding/json"
 "errors"
 "net/http"
 "net/url"
 "strings"
 "sync"
 "sync/atomic"
 "strconv"
 "time"

 "github.com/coder/websocket"
 "notitle/internal/httpserver/apierror"
 "notitle/internal/httpserver/middleware"
 "notitle/internal/identity"
 "notitle/internal/realtime"
)

type Authenticator interface { Authenticate(context.Context,string,bool)(identity.Principal,error) }
type Options struct {
 PublicOrigin string
 AllowInsecureLocalhost bool
 Identity Authenticator
 Authorizer realtime.Authorizer
 Actor realtime.Actor
 Ready func(context.Context) error
 Now func() time.Time
}
type Handler struct {
 origin string
 cookieName string
 identity Authenticator
 authorizer realtime.Authorizer
 actor realtime.Actor
 ready func(context.Context)error
 now func()time.Time
 tickets *ticketStore
 authSlots chan struct{}
 ctx context.Context
 cancel context.CancelFunc
 mu sync.Mutex
 sockets map[*websocket.Conn]struct{}
 opening int
 closing bool
 rateTokens float64
 rateUpdated time.Time
 workers sync.WaitGroup
}
func New(opts Options)(*Handler,error) {
 u,err:=url.Parse(opts.PublicOrigin)
 if err!=nil || u.Hostname()=="" || u.Path!="" || u.User!=nil || u.RawQuery!="" || u.ForceQuery || u.Fragment!="" || strings.Contains(opts.PublicOrigin,"#") || u.Opaque!="" { return nil,errors.New("realtime requires a valid exact origin") }
 local:=u.Hostname()=="localhost" || u.Hostname()=="127.0.0.1" || u.Hostname()=="::1"
 if u.Scheme!="https" && !(u.Scheme=="http" && local && opts.AllowInsecureLocalhost) { return nil,errors.New("realtime requires HTTPS except explicit loopback development") }
 if opts.Identity==nil || opts.Authorizer==nil || opts.Actor==nil { return nil,errors.New("realtime dependencies are required") }
 if opts.Now==nil {opts.Now=time.Now}
 ctx,cancel:=context.WithCancel(context.Background())
 h:=&Handler{origin:opts.PublicOrigin,cookieName:"__Host-session",identity:opts.Identity,authorizer:opts.Authorizer,actor:opts.Actor,ready:opts.Ready,now:opts.Now,tickets:newTickets(),authSlots:make(chan struct{},8),ctx:ctx,cancel:cancel,sockets:make(map[*websocket.Conn]struct{}),rateTokens:200,rateUpdated:opts.Now()}
 if u.Scheme=="http" {h.cookieName="notitle_dev_session"}
 return h,nil
}

// IssueTicket is called only through identityhttp's same-origin, authenticated
// CSRF mutation handler. The ticket is bound to the verified session and choice.
func (h *Handler) IssueTicket(ctx context.Context,p identity.Principal,takeover bool)(realtime.TicketResponse,error) {
 h.mu.Lock(); closed:=h.closing; h.mu.Unlock()
 if closed {return realtime.TicketResponse{},identity.ErrUnavailable}
 if _,err:=h.authorize(ctx,p);err!=nil{return realtime.TicketResponse{},err}
 h.mu.Lock();defer h.mu.Unlock()
 if h.closing{return realtime.TicketResponse{},identity.ErrUnavailable}
 dto,err:=h.tickets.issue(p,takeover,h.now())
 return realtime.TicketResponse{Ticket:dto.Ticket,ExpiresAt:dto.ExpiresAt,ProtocolVersion:dto.ProtocolVersion},err
}
func (h *Handler) authorize(ctx context.Context,p identity.Principal)(realtime.AuthSnapshot,error) {
 select {case h.authSlots<-struct{}{}:default:return realtime.AuthSnapshot{},identity.ErrBusy}
 defer func(){<-h.authSlots}()
 ctx,cancel:=context.WithTimeout(ctx,2*time.Second);defer cancel()
 return h.authorizer.Authorize(ctx,p)
}
func (h *Handler) cookie(r *http.Request)string {
 value:="";count:=0
 for _,c:=range r.Cookies(){if c.Name==h.cookieName {value=c.Value;count++}}
 if count!=1 || len(value)>256 {return ""};return value
}
func (h *Handler) fail(w http.ResponseWriter,r *http.Request,err apierror.Error) {apierror.Write(w,middleware.RequestIDFromContext(r.Context()),err)}
func (h *Handler) admit()bool {
 h.mu.Lock();defer h.mu.Unlock()
 now:=h.now();elapsed:=now.Sub(h.rateUpdated).Seconds();if elapsed<0{elapsed=0}
 h.rateTokens+=elapsed*10;if h.rateTokens>200{h.rateTokens=200};h.rateUpdated=now
 // Active authenticated users do not consume the pre-authentication budget.
 // The actor separately enforces exactly 200 participants.
 if h.closing || h.opening>=64 || len(h.sockets)+h.opening>=264 || h.rateTokens<1{return false}
 h.rateTokens--;h.opening++;h.workers.Add(1);return true
}
func (h *Handler) ServeHTTP(w http.ResponseWriter,r *http.Request) {
 w.Header().Set("Cache-Control","no-store")
 if r.URL.Path!="/ws" {h.fail(w,r,apierror.NotFound);return}
 r.Pattern="GET /ws"
 if r.Method!=http.MethodGet {w.Header().Set("Allow","GET");h.fail(w,r,apierror.MethodNotAllowed);return}
 if r.URL.RawQuery!="" || r.URL.ForceQuery {h.fail(w,r,apierror.Invalid);return}
 if len(r.Header.Values("Origin"))!=1 || r.Header.Get("Origin")!=h.origin || r.Header.Get("Sec-Fetch-Site")=="cross-site" {h.fail(w,r,apierror.Forbidden);return}
 cookie:=h.cookie(r);if cookie=="" {h.fail(w,r,apierror.Unauthorized);return}
 // A hijacked request remains alive for the socket lifetime; keep the bearer
 // only until its first-frame check, then retain trusted hashes and references.
 r.Header.Del("Cookie");r.Header.Del("Authorization")
 if !h.admit(){w.Header().Set("Retry-After","5");h.fail(w,r,apierror.RateLimited);return}
 defer h.workers.Done()
 opening:=true
 defer func(){if opening{h.mu.Lock();h.opening--;h.mu.Unlock()}}()
 if h.ready!=nil {
  ctx,cancel:=context.WithTimeout(r.Context(),time.Second);err:=h.ready(ctx);cancel()
  if err!=nil{h.fail(w,r,apierror.Unavailable);return}
 }
 // HTTP deadlines must not become a fixed lifetime for hijacked sockets.
 controller:=http.NewResponseController(w)
 _=controller.SetReadDeadline(time.Time{});_=controller.SetWriteDeadline(time.Time{})
 c,err:=websocket.Accept(w,r,&websocket.AcceptOptions{OriginPatterns:[]string{h.origin},CompressionMode:websocket.CompressionDisabled})
 if err!=nil{return}
 defer c.CloseNow()
 c.SetReadLimit(realtime.MaxFrameBytes)
 h.mu.Lock();if h.closing {h.mu.Unlock();return};h.sockets[c]=struct{}{};h.mu.Unlock()
 defer func(){h.mu.Lock();delete(h.sockets,c);h.mu.Unlock()}()
 ctx,cancel:=context.WithCancel(h.ctx);defer cancel()
 firstCtx,firstCancel:=context.WithTimeout(ctx,realtime.FirstFrameTimeout)
 kind,data,err:=c.Read(firstCtx);firstCancel()
 if err!=nil{return}
 if kind!=websocket.MessageText {closeSocket(c,websocket.StatusUnsupportedData,"INVALID_EVENT");return}
 envelope,err:=realtime.DecodeEnvelope(data)
 if err!=nil{h.initialError(ctx,c,"",err);return}
 auth,err:=realtime.DecodeAuthenticate(envelope)
 if err!=nil{h.initialError(ctx,c,envelope.ID,err);return}
 // A valid ticket is consumed before any database work. A ticket cannot be
 // replayed even if its cookie has expired or the subsequent attach fails.
 ticket,err:=h.tickets.consume(auth.Ticket,h.now())
 if err!=nil || ticket.takeover!=auth.Takeover {h.initialError(ctx,c,envelope.ID,realtime.ErrUnauthorized);return}
 authCtx,authCancel:=context.WithTimeout(ctx,2*time.Second)
 select {case h.authSlots<-struct{}{}:default:authCancel();h.initialError(ctx,c,envelope.ID,realtime.ErrRateLimited);return}
 principal,err:=h.identity.Authenticate(authCtx,cookie,false)
 <-h.authSlots;authCancel();cookie=""
 if err!=nil {h.initialError(ctx,c,envelope.ID,publicAuthError(err));return}
 if principal.TokenHash!=ticket.session {h.initialError(ctx,c,envelope.ID,realtime.ErrUnauthorized);return}
 principal.CSRFToken=""
 snapshot,err:=h.authorize(ctx,principal)
 if err!=nil{h.initialError(ctx,c,envelope.ID,publicAuthError(err));return}
 connection,err:=h.actor.Attach(ctx,realtime.AttachRequest{Auth:snapshot,Takeover:ticket.takeover,Resume:auth.Resume})
 if err!=nil{h.initialError(ctx,c,envelope.ID,err);return}
 // Only authenticated participants can send the larger explicitly typed SDP
 // frames. DecodeEnvelope still applies the ordinary 8 KiB limit otherwise.
 c.SetReadLimit(realtime.MaxSDPFrameBytes)
 h.mu.Lock();h.opening--;h.mu.Unlock();opening=false
 defer func(){detachCtx,detachCancel:=context.WithTimeout(context.Background(),time.Second);defer detachCancel();_=h.actor.Detach(detachCtx,connection.Ref,"connection_lost")}()
 h.run(ctx,c,principal,connection,snapshot.ValidUntil)
}
func (h *Handler) initialError(ctx context.Context,c *websocket.Conn,reply string,err error) {
 event:=errorEvent(reply,0,err);_=writeEvent(ctx,c,event)
 closeSocket(c,websocket.StatusPolicyViolation,realtime.PublicError(err).Code)
}
var transportEventSequence atomic.Uint64
func errorEvent(reply string,generation uint64,err error)realtime.ServerEvent {
 // A failed decoder may return a partial envelope. Never echo unchecked IDs.
 if len(reply)>64 { reply="" }
 for _,r:=range reply { if !((r>='a'&&r<='z')||(r>='A'&&r<='Z')||(r>='0'&&r<='9')||r=='_'||r=='-') {reply="";break} }
 public:=realtime.PublicError(err)
 return realtime.ServerEvent{V:1,ID:"transport-"+strconv.FormatUint(transportEventSequence.Add(1),10),Type:"error",Generation:generation,ReplyTo:reply,Payload:realtime.ErrorPayload{Code:public.Code,Message:public.Message,Retryable:public.Retryable}}
}
func publicAuthError(err error)error {
 var known *realtime.Error;if errors.As(err,&known){return realtime.PublicError(err)}
 if errors.Is(err,identity.ErrUnauthorized)||errors.Is(err,identity.ErrStale){return realtime.ErrUnauthorized}
 if errors.Is(err,identity.ErrBusy)||errors.Is(err,identity.ErrCapacity){return realtime.ErrRateLimited}
 return realtime.ErrUnavailable
}
func writeEvent(ctx context.Context,c *websocket.Conn,event realtime.ServerEvent)error {
 var buffer bytes.Buffer
 encoder:=json.NewEncoder(&buffer);encoder.SetEscapeHTML(false)
 if err:=encoder.Encode(event);err!=nil{return err};payload:=buffer.Bytes()
 if len(payload)>realtime.FrameLimit(event.Type){return realtime.ErrProtocol}
 writeCtx,cancel:=context.WithTimeout(ctx,3*time.Second);defer cancel()
 return c.Write(writeCtx,websocket.MessageText,payload)
}
func closeSocket(c *websocket.Conn,status websocket.StatusCode,reason string) {
 timer:=time.AfterFunc(500*time.Millisecond,func(){_=c.CloseNow()});defer timer.Stop()
 _=c.Close(status,reason)
}

// Close accounts for hijacked connections, which http.Server.Shutdown cannot
// drain. No new handshakes are admitted after this method starts.
func (h *Handler) Close(ctx context.Context)error {
 h.mu.Lock();h.closing=true;h.cancel()
 sockets:=make([]*websocket.Conn,0,len(h.sockets));for c:=range h.sockets{sockets=append(sockets,c)};h.mu.Unlock()
 h.tickets.clear()
 for _,c:=range sockets{_=c.CloseNow()}
 done:=make(chan struct{});go func(){h.workers.Wait();close(done)}()
 select{case <-done:return nil;case <-ctx.Done():return ctx.Err()}
}
