// Package relay owns private, bounded TURN leases, never media or signaling.
package relay

import (
 "context"
 "crypto/hmac"
 "crypto/rand"
 "crypto/sha1" // TURN REST credentials require HMAC-SHA1; not a password hash.
 "encoding/base64"
 "errors"
 "fmt"
 "sort"
 "sync"
 "time"
 at "notitle/internal/audiotypes"
)

const MaxRecords = 2048
var ErrUnavailable = errors.New("relay unavailable")
type Allocation struct { ID, Username string }
type Admin interface { Sessions(context.Context)([]Allocation,error); Cancel(context.Context,[]string)error }
type Options struct {
 Admin Admin
 Secret []byte
 URLs, RelayAddresses []string
 Now func()time.Time
 Stop func()
}
type Request struct {
 BootID string `json:"boot_id"`
 ServerInstance string `json:"server_instance"`
 CallRef string `json:"call_ref"`
 Version uint64 `json:"version"`
 Action string `json:"action"`
 LeaseUntil time.Time `json:"lease_until"`
}
type Response struct {
 BootID string `json:"boot_id"`
 Ready bool `json:"ready"`
 Success bool `json:"success"`
 Revoked bool `json:"revoked"`
 Credentials [2]at.Credentials `json:"credentials"`
}
type Metrics struct {
 ActiveCalls int `json:"active_calls"`
 RevocationRecords int `json:"revocation_records"`
 Allocations int `json:"allocations"`
 CancellationRequests uint64 `json:"cancellation_requests"`
 ControlFailures uint64 `json:"control_failures"`
 LastScanAt time.Time `json:"last_scan_at"`
 Ready bool `json:"ready"`
}
type lease struct {
 instance string
 version uint64
 until time.Time
 revoked bool
 credentials [2]at.Credentials
 usernames map[string]time.Time
 endpoints map[string]int
 retainUntil time.Time
}
type Controller struct {
 mu sync.Mutex
 options Options
 boot, instance string
 healthy bool
 synced bool
 failed bool
 calls map[string]*lease
 metrics Metrics
 cancelPending map[string]time.Time
 retiredInstances map[string]bool
}
func New(o Options)(*Controller,error){
 if o.Admin==nil||len(o.Secret)<32||len(o.URLs)<1||len(o.RelayAddresses)<1||o.Stop==nil{return nil,ErrUnavailable}
 if o.Now==nil{o.Now=time.Now};boot,err:=randomRef();if err!=nil{return nil,err}
 return &Controller{options:o,boot:boot,calls:make(map[string]*lease),cancelPending:make(map[string]time.Time),retiredInstances:make(map[string]bool)},nil
}
func randomRef()(string,error){var raw[24]byte;if _,err:=rand.Read(raw[:]);err!=nil{return "",err};return base64.RawURLEncoding.EncodeToString(raw[:]),nil}
func(c *Controller) Status()Response{c.mu.Lock();defer c.mu.Unlock();return Response{BootID:c.boot,Ready:c.healthy&&c.synced&&c.instance!=""}}
func(c *Controller) Metrics()Metrics{c.mu.Lock();defer c.mu.Unlock();value:=c.metrics;for _,l:=range c.calls{if l.revoked{value.RevocationRecords++}else{value.ActiveCalls++}};value.Ready=c.healthy&&c.synced&&c.instance!="";return value}
func(c *Controller) failLocked(){c.metrics.ControlFailures++;c.failed=true;c.healthy=false;c.synced=false;c.instance="";for _,l:=range c.calls{l.revoked=true};c.options.Stop()}
// Sync is explicit, authenticated and destructive: a new app instance ends all
// previous leases. No old call is reconstructed across either process restart.
func(c *Controller) Sync(ctx context.Context,boot,instance string)(Response,error){
 c.mu.Lock();defer c.mu.Unlock()
 if boot!=c.boot||!at.ValidRef(instance)||!c.healthy||c.retiredInstances[instance]{return Response{},ErrUnavailable}
 if c.instance==instance&&c.synced{return Response{BootID:c.boot,Ready:true,Success:true},nil}
 if c.instance!=instance{
  if c.instance!=""{if len(c.retiredInstances)>=256{c.failLocked();return Response{},ErrUnavailable};c.retiredInstances[c.instance]=true}
  for _,l:=range c.calls{l.revoked=true};c.instance=instance;c.synced=false
 }
 if err:=c.scanLocked(ctx);err!=nil{return Response{},err}
 sessions,err:=c.options.Admin.Sessions(ctx);if err!=nil{c.failLocked();return Response{},ErrUnavailable};if len(sessions)!=0{return Response{BootID:c.boot},nil}
 c.synced=true;return Response{BootID:c.boot,Ready:true,Success:true},nil
}
func(c *Controller) Apply(ctx context.Context,r Request)(Response,error){
 c.mu.Lock();defer c.mu.Unlock();now:=c.options.Now()
 response:=Response{BootID:c.boot}
 if !c.healthy||!c.synced||r.BootID!=c.boot||r.ServerInstance!=c.instance||c.instance==""||!at.ValidRef(r.CallRef)||r.Version==0{return response,ErrUnavailable}
 l:=c.calls[r.CallRef]
 if r.Action=="revoke"{
  if l==nil{
   if len(c.calls)>=MaxRecords{c.failLocked();return response,ErrUnavailable}
   l=&lease{instance:r.ServerInstance,version:r.Version,revoked:true,retainUntil:now.Add(at.CredentialLifetime+time.Minute),usernames:make(map[string]time.Time),endpoints:make(map[string]int)};c.calls[r.CallRef]=l
  };l.revoked=true
  if err:=c.scanLocked(ctx);err!=nil{return response,err}
  sessions,err:=c.options.Admin.Sessions(ctx);if err!=nil{c.failLocked();return response,ErrUnavailable}
  for _,a:=range sessions{
   // Expired usernames are already absent from l.usernames, but their old
   // allocations may still be awaiting asynchronous cancellation.
   if _,pending:=c.cancelPending[a.ID];pending{return response,nil}
   if _,ok:=l.usernames[a.Username];ok{return response,nil}
  }
  response.Success=true;response.Revoked=true;return response,nil
 }
 if r.Action!="create"&&r.Action!="renew"&&r.Action!="refresh"{return response,ErrUnavailable}
 if !r.LeaseUntil.After(now)||r.LeaseUntil.After(now.Add(at.LeaseDuration+2*time.Second)){return response,ErrUnavailable}
 // Two seconds of measured cross-host clock tolerance must not steal the
 // six-second enforcement reserve. Receipt-time cap also limits late packets.
 remaining:=r.LeaseUntil.Sub(now)-8*time.Second;if remaining<=0{return response,ErrUnavailable};if remaining>24*time.Second{remaining=24*time.Second}
 if l==nil{
  if r.Action!="create"||len(c.calls)>=MaxRecords{return response,ErrUnavailable}
  active:=0;for _,value:=range c.calls{if !value.revoked{active++}};if active>=at.MaxCalls{return response,ErrUnavailable}
  l=&lease{instance:r.ServerInstance,version:r.Version,usernames:make(map[string]time.Time),endpoints:make(map[string]int)}
  if err:=c.issue(l,now);err!=nil{return response,ErrUnavailable};c.calls[r.CallRef]=l
 }else if l.revoked||l.instance!=r.ServerInstance||r.Version<l.version||!l.until.After(now){return response,ErrUnavailable}
 // Reserve six seconds for scans, asynchronous cancellation and the watchdog. The public
 // contract is at most30s, not a30s timer plus an unbounded cancellation delay.
 l.until=now.Add(remaining);l.version=r.Version
 if r.Action=="refresh"&&!now.Before(l.credentials[0].RefreshAt){if err:=c.issue(l,now);err!=nil{return response,ErrUnavailable}}
 response.Success=true;response.Ready=true;response.Credentials=l.credentials;return response,nil
}
func(c *Controller) issue(l *lease,now time.Time)error{
 var pair[2]at.Credentials
 for i:=range pair{
  ref,err:=randomRef();if err!=nil{return err};expires:=now.UTC().Add(at.CredentialLifetime)
  username:=fmt.Sprintf("%d:%s",expires.Unix(),ref)
  mac:=hmac.New(sha1.New,c.options.Secret);_,_=mac.Write([]byte(username))
  pair[i]=at.Credentials{URLs:append([]string(nil),c.options.URLs...),Username:username,Credential:base64.StdEncoding.EncodeToString(mac.Sum(nil)),ExpiresAt:expires,RefreshAt:now.Add(at.CredentialRefreshInterval),RelayAddresses:append([]string(nil),c.options.RelayAddresses...),RelayMinPort:at.RelayMinPort,RelayMaxPort:at.RelayMaxPort}
 }
 for i,credential:=range pair{l.usernames[credential.Username]=credential.ExpiresAt;l.endpoints[credential.Username]=i;l.retainUntil=credential.ExpiresAt.Add(time.Minute)}
 l.credentials=pair;return nil
}
// Tick is mandatory once per second. Unknown usernames are denied too, so an
// expired credential cannot keep an existing allocation alive indefinitely.
func(c *Controller) Tick(ctx context.Context)error{c.mu.Lock();defer c.mu.Unlock();return c.scanLocked(ctx)}
func(c *Controller) scanLocked(ctx context.Context)error{
 if c.failed{return ErrUnavailable}
 sessions,err:=c.options.Admin.Sessions(ctx);if err!=nil{c.failLocked();return ErrUnavailable}
 now:=c.options.Now();c.metrics.Allocations=len(sessions);c.metrics.LastScanAt=now.UTC()
 allowed:=make(map[string]string);current:=make(map[string]bool)
 for ref,l:=range c.calls{
  if !l.until.After(now){l.revoked=true}
  for username,expires:=range l.usernames{if !expires.After(now){delete(l.usernames,username);delete(l.endpoints,username)}else if !l.revoked{allowed[username]=fmt.Sprintf("%s:%d",ref,l.endpoints[username])}}
  for _,credential:=range l.credentials{current[credential.Username]=true}
 }
 // Prefer the current credential generation during a bounded ICE restart.
 sort.Slice(sessions,func(i,j int)bool{a,b:=current[sessions[i].Username],current[sessions[j].Username];if a!=b{return a};return sessions[i].ID<sessions[j].ID})
 present:=make(map[string]bool,len(sessions));for _,a:=range sessions{present[a.ID]=true;if since,ok:=c.cancelPending[a.ID];ok&&!now.Before(since.Add(2*time.Second)){c.failLocked();return ErrUnavailable}}
 for id:=range c.cancelPending{if !present[id]{delete(c.cancelPending,id)}}
 counts:=make(map[string]int)
 ids:=make([]string,0,len(sessions));for _,a:=range sessions{key:=allowed[a.Username];counts[key]++;if key==""||counts[key]>4{ids=append(ids,a.ID)}}
 if len(ids)>0{for _,id:=range ids{if _,ok:=c.cancelPending[id];!ok{c.cancelPending[id]=now}};c.metrics.CancellationRequests+=uint64(len(ids));if err=c.options.Admin.Cancel(ctx,ids);err!=nil{c.failLocked();return ErrUnavailable}}
 for ref,l:=range c.calls{if l.revoked&&!l.retainUntil.After(now){delete(c.calls,ref)}}
 c.healthy=true;return nil
}
