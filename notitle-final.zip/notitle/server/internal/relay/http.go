package relay

import (
 "context"
 "crypto/subtle"
 "encoding/json"
 "io"
 "net/http"
 "strings"
 "time"
)

func Handler(c *Controller,token string)http.Handler{
 slots:=make(chan struct{},4)
 return http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){
  w.Header().Set("Cache-Control","no-store");w.Header().Set("Content-Type","application/json")
  supplied:=strings.TrimPrefix(r.Header.Get("Authorization"),"Bearer ")
  if !strings.HasPrefix(r.Header.Get("Authorization"),"Bearer ")||len(token)<32||subtle.ConstantTimeCompare([]byte(token),[]byte(supplied))!=1{http.Error(w,"unavailable",http.StatusUnauthorized);return}
  if r.URL.RawQuery!=""{http.Error(w,"invalid",http.StatusBadRequest);return}
  select{case slots<-struct{}{}:defer func(){<-slots}();default:http.Error(w,"busy",http.StatusServiceUnavailable);return}
  ctx,cancel:=context.WithTimeout(r.Context(),2*time.Second);defer cancel()
  if r.URL.Path=="/v1/metrics"&&r.Method==http.MethodGet{_ =json.NewEncoder(w).Encode(c.Metrics());return}
  var response Response;var err error
  if r.URL.Path=="/v1/status"&&r.Method==http.MethodGet{response=c.Status()}else{
   if r.Method!=http.MethodPost{http.Error(w,"not found",http.StatusNotFound);return}
   var value Request;decoder:=json.NewDecoder(http.MaxBytesReader(w,r.Body,4096));decoder.DisallowUnknownFields()
   if decoder.Decode(&value)!=nil||decoder.Decode(new(any))!=io.EOF{http.Error(w,"invalid",http.StatusBadRequest);return}
   switch r.URL.Path{case "/v1/sync":if value.CallRef!=""||value.Action!=""||value.Version!=0||!value.LeaseUntil.IsZero(){http.Error(w,"invalid",http.StatusBadRequest);return};response,err=c.Sync(ctx,value.BootID,value.ServerInstance)
   case "/v1/lease":response,err=c.Apply(ctx,value)
   default:http.Error(w,"not found",http.StatusNotFound);return}
  }
  if err!=nil{http.Error(w,"unavailable",http.StatusServiceUnavailable);return}
  _=json.NewEncoder(w).Encode(response)
 })
}
