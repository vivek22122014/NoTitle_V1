package relay

import (
 "net/http"
 "net/http/httptest"
 "strings"
 "testing"
)
func TestPrivateControlRequiresBearerAndRejectsUnknownFields(t *testing.T){h:=setup(t);token:=strings.Repeat("ab",32);handler:=Handler(h.c,token);for _,authorization:=range []string{"",token,"Bearer wrong"}{r:=httptest.NewRequest(http.MethodGet,"/v1/metrics",nil);r.Header.Set("Authorization",authorization);w:=httptest.NewRecorder();handler.ServeHTTP(w,r);if w.Code!=401{t.Fatal("private metrics exposed")}};r:=httptest.NewRequest(http.MethodPost,"/v1/lease",strings.NewReader(`{"unknown":true}`));r.Header.Set("Authorization","Bearer "+token);w:=httptest.NewRecorder();handler.ServeHTTP(w,r);if w.Code!=400{t.Fatal("unknown fields accepted")}}
func TestPrivateMetricsContainNoIdentifiersOrCredentials(t *testing.T){h:=setup(t);result:=h.apply(t);token:=strings.Repeat("ab",32);r:=httptest.NewRequest(http.MethodGet,"/v1/metrics",nil);r.Header.Set("Authorization","Bearer "+token);w:=httptest.NewRecorder();Handler(h.c,token).ServeHTTP(w,r);body:=w.Body.String();if w.Code!=200||!strings.Contains(body,`"active_calls":1`){t.Fatal("metrics unavailable")};for _,secret:=range []string{h.request.CallRef,h.request.ServerInstance,result.Credentials[0].Username,result.Credentials[0].Credential}{if strings.Contains(body,secret){t.Fatal("private identifier in aggregates")}}}
