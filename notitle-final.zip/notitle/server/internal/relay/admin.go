package relay

import (
 "bufio"
 "context"
 "fmt"
 "net"
 "regexp"
 "strconv"
 "strings"
 "time"
)

const MaxAdminBytes=1024*1024
const MaxAllocations=256
var sessionLine=regexp.MustCompile(`^\s*[0-9]+\) id=([0-9]{1,20}), user <([^<>\r\n]{0,256})>:$`)
var totalLine=regexp.MustCompile(`^\s*Total sessions: ([0-9]+)\s*$`)
var decimalID=regexp.MustCompile(`^[0-9]{1,20}$`)

// ParseSessions accepts the upstream4.18 CLI ps format. A missing summary,
// truncation or a changed header is an enforcement failure, never an empty list.
func ParseSessions(value string)([]Allocation,error){
 if len(value)>MaxAdminBytes||strings.Contains(value,"...")||strings.Contains(value,"Warning:"){return nil,ErrUnavailable}
 var out []Allocation;total:=-1;seen:=make(map[string]bool)
 for _,line:=range strings.Split(strings.ReplaceAll(value,"\r",""),"\n"){
  if m:=sessionLine.FindStringSubmatch(line);m!=nil{
   if _,err:=strconv.ParseUint(m[1],10,64);err!=nil||seen[m[1]]{return nil,ErrUnavailable};seen[m[1]]=true;out=append(out,Allocation{ID:m[1],Username:m[2]})
  }else if m:=totalLine.FindStringSubmatch(line);m!=nil{
   if total!=-1{return nil,ErrUnavailable};var err error;total,err=strconv.Atoi(m[1]);if err!=nil{return nil,ErrUnavailable}
  }else if strings.Contains(line,"id=")||strings.Contains(line,"Total sessions"){return nil,ErrUnavailable}
 }
 if total<0||total!=len(out)||total>MaxAllocations{return nil,ErrUnavailable};return out,nil
}

// CLI only connects to coturn's container-local IPv4 loopback. It never accepts
// a configurable public admin address or exposes the raw command surface.
type CLI struct { Password string }
type cliConnection struct { net.Conn; reader *bufio.Reader; bytes int }
func(c CLI) connect(ctx context.Context)(*cliConnection,error){
 if len(c.Password)<32||strings.ContainsAny(c.Password,"\r\n"){return nil,ErrUnavailable}
 conn,err:=(&net.Dialer{Timeout:time.Second}).DialContext(ctx,"tcp","127.0.0.1:5766");if err!=nil{return nil,ErrUnavailable}
 deadline:=time.Now().Add(1500*time.Millisecond);if end,ok:=ctx.Deadline();ok&&end.Before(deadline){deadline=end};_ =conn.SetDeadline(deadline)
 client:=&cliConnection{Conn:conn,reader:bufio.NewReader(conn)}
 if _,err=client.until("Enter password: ");err!=nil{conn.Close();return nil,ErrUnavailable}
 if _,err=fmt.Fprintf(conn,"%s\r\n",c.Password);err!=nil{conn.Close();return nil,ErrUnavailable}
 if _,err=client.until("> ");err!=nil{conn.Close();return nil,ErrUnavailable};return client,nil
}
func(c *cliConnection)until(suffix string)(string,error){
 var value strings.Builder
 for{b,err:=c.reader.ReadByte();if err!=nil{return "",ErrUnavailable};c.bytes++;if c.bytes>MaxAdminBytes{return "",ErrUnavailable}
  if b==255{ // Reject optional telnet features; coturn operates in line mode.
   op,err:=c.reader.ReadByte();if err!=nil{return "",ErrUnavailable};c.bytes++
   if op==255{return "",ErrUnavailable}
   if op>=251&&op<=254{option,err:=c.reader.ReadByte();if err!=nil{return "",ErrUnavailable};c.bytes++;reply:=byte(254);if op==253||op==254{reply=252};if _,err=c.Write([]byte{255,reply,option});err!=nil{return "",ErrUnavailable};continue}
   return "",ErrUnavailable
  }
  value.WriteByte(b)
  if strings.HasSuffix(value.String(),suffix){return value.String(),nil}
 }
}
func(c CLI)Sessions(ctx context.Context)([]Allocation,error){
 conn,err:=c.connect(ctx);if err!=nil{return nil,err};defer conn.Close()
 if _,err=conn.Write([]byte("ps\r\n"));err!=nil{return nil,ErrUnavailable};value,err:=conn.until("> ");if err!=nil{return nil,err};return ParseSessions(value)
}
func(c CLI)Cancel(ctx context.Context,ids []string)error{
 if len(ids)>MaxAllocations{return ErrUnavailable};if len(ids)==0{return nil}
 conn,err:=c.connect(ctx);if err!=nil{return err};defer conn.Close()
 for _,id:=range ids{if !decimalID.MatchString(id){return ErrUnavailable};if _,err=fmt.Fprintf(conn,"cs %s\r\n",id);err!=nil{return ErrUnavailable};value,err:=conn.until("> ");if err!=nil||strings.Contains(value,"Error"){return ErrUnavailable}}
 return nil
}
