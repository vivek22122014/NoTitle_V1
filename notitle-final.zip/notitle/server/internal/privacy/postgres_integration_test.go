//go:build linux

package privacy

import (
    "context"
    "crypto/rand"
    "encoding/base64"
    "encoding/json"
    "errors"
    "os"
    "path/filepath"
    "strings"
    "testing"
    "time"

    "github.com/jackc/pgx/v5/pgxpool"
    "notitle/internal/holdlog"
    "notitle/internal/identity"
    "notitle/internal/identitypg"
)

type privacyFixture struct { ctx context.Context; store *Store; migration *pgxpool.Pool; identity *identitypg.Store; account identity.AccountSession; guard identity.Guard; admin AdminGuard; now time.Time; receipt string }
func integration(t *testing.T)privacyFixture{
    t.Helper();read:=func(name string)string{if path:=os.Getenv(name+"_FILE");path!=""{raw,e:=os.ReadFile(path);if e!=nil{t.Fatal("cannot read isolated database secret")};return strings.TrimSpace(string(raw))};return os.Getenv(name)}
    runtime,migration:=read("TEST_DATABASE_URL"),read("TEST_ADMIN_MIGRATION_URL");if runtime==""||migration==""{if os.Getenv("REQUIRE_DATABASE_INTEGRATION")=="1"{t.Fatal("required PostgreSQL privacy fixture credentials missing")};t.Skip("run scripts/db-check.sh with disposable PostgreSQL")}
    ctx,cancel:=context.WithTimeout(context.Background(),45*time.Second);t.Cleanup(cancel);pool,e:=pgxpool.New(ctx,runtime);if e!=nil{t.Fatal("runtime pool")};t.Cleanup(pool.Close);migrate,e:=pgxpool.New(ctx,migration);if e!=nil{t.Fatal("migration pool")};t.Cleanup(migrate.Close)
    now:=time.Now().UTC().Truncate(time.Microsecond);p:=reviewedFixture(now);version,e:=uuid();if e!=nil{t.Fatal(e)};p.Version="test-"+version;raw,_:=json.Marshal(p)
    if _,e=migrate.Exec(ctx,`INSERT INTO notitle.retention_policies(version,digest,document,approved,installed_at)VALUES($1,$2,$3,true,$4)`,p.Version,p.Digest(),raw,now);e!=nil{t.Fatal(e)}
    j,e:=holdlog.Open(filepath.Join(t.TempDir(),"holds"));if e!=nil{t.Fatal(e)};t.Cleanup(func(){_ = j.Close()})
    f:=privacyFixture{ctx:ctx,migration:migrate,identity:identitypg.New(pool),now:now}
    f.store=NewStore(pool,Options{Policy:p,Journal:j,Now:func()time.Time{return now},RecoveryPoint:func(context.Context)(time.Time,error){return now,nil},DeletionRecoveryPoint:func(context.Context)(time.Time,error){return now,nil}});if e=f.store.Replay(ctx);e!=nil{t.Fatal(e)}
    id,_:=uuid();sid,_:=uuid();var token,recovery identity.Verifier;_,_=rand.Read(token[:]);_,_=rand.Read(recovery[:]);f.account,e=f.identity.CreateAccount(ctx,identity.CreateAccountRecord{Account:identity.Account{ID:id,Username:"priv_"+strings.ReplaceAll(id,"-","")[:16],Profile:identity.Profile{Version:1,DisplayName:"Privacy fixture",Gender:identity.GenderOther,Topic:"general_talk",Bio:"Own bounded profile"}},PasswordHash:"$argon2id$v=19$m=65536,t=3,p=1$synthetic-fixture$synthetic-fixture",RecoveryHash:recovery,Consent:identity.Consent{AdultConfirmed:true,Policies:identity.PolicyVersions{Terms:"draft-1",Privacy:"draft-1",Community:"draft-1"}},CreatedAt:now,Session:identity.SessionRecord{ID:sid,TokenHash:token,CreatedAt:now,LastSeenAt:now,AuthenticatedAt:now,AbsoluteExpiresAt:now.Add(identity.SessionAbsoluteTTL)}});if e!=nil{t.Fatal(e)}
    t.Cleanup(func(){cleanup,stop:=context.WithTimeout(context.Background(),5*time.Second);defer stop();_,_=migrate.Exec(cleanup,`DELETE FROM notitle.privacy_holds WHERE scope_ref=$1`,id);_,_=migrate.Exec(cleanup,`DELETE FROM notitle.privacy_hold_events WHERE snapshot->>'scope_ref'=$1`,id)})
    f.guard=identity.Guard{AccountID:id,AccountGeneration:1,SessionID:sid,TokenHash:token,Now:now,RequireRecent:true};f.admin.OperatorID,_=uuid();f.admin.Generation=1;f.admin.Now=now;_,_=rand.Read(f.admin.SessionHash[:])
    if _,e=migrate.Exec(ctx,`INSERT INTO notitle.admin_users(id,username,password_hash,totp_ciphertext,roles,created_at)VALUES($1,$2,$3,$4,ARRAY['owner'],$5)`,f.admin.OperatorID,"priv_"+strings.ReplaceAll(f.admin.OperatorID,"-","")[:16],"$argon2id$v=19$m=65536,t=3,p=1$synthetic-fixture$synthetic-fixture",make([]byte,48),now);e!=nil{t.Fatal(e)}
    if _,e=pool.Exec(ctx,`INSERT INTO notitle.admin_sessions(token_hash,admin_id,admin_generation,created_at,last_seen_at,absolute_expires_at)VALUES($1,$2,1,$3,$3,$3+interval '4 hours')`,f.admin.SessionHash[:],f.admin.OperatorID,now);e!=nil{t.Fatal(e)}
    var receipt [32]byte;_,_=rand.Read(receipt[:]);f.receipt=base64.RawURLEncoding.EncodeToString(receipt[:]);return f
}
func(f privacyFixture)delete(t *testing.T){t.Helper();id,_:=uuid();hash,e:=receiptHash(f.receipt);if e!=nil{t.Fatal(e)};record,e:=f.identity.BeginDeletion(f.ctx,f.guard,identity.DeletionRecord{ID:id,ReceiptHash:identity.Verifier(hash)});if e!=nil{t.Fatal(e)};if e=f.identity.MarkTombstoneDurable(f.ctx,record.ID,f.now);e!=nil{t.Fatal(e)}}
func(f privacyFixture)scrub()error{f.store.mu.Lock();defer f.store.mu.Unlock();return f.store.scrubAccountLocked(f.ctx,f.account.Account.ID,time.Now().UTC())}
func(f privacyFixture)count(t *testing.T,query string,args ...any)int{t.Helper();var n int;if e:=f.store.pool.QueryRow(f.ctx,query,args...).Scan(&n);e!=nil{t.Fatal(e)};return n}

func TestIntegrationPrivacyRuntimeCannotInstallPolicyOrForgeClock(t *testing.T){f:=integration(t);if _,e:=f.store.pool.Exec(f.ctx,`INSERT INTO notitle.retention_policies(version,digest,document,approved,installed_at)VALUES('forged',$1,'{}',true,$2)`,strings.Repeat("0",64),f.now);e==nil{t.Fatal("runtime approved its own erasure policy")};var done bool;if e:=f.store.pool.QueryRow(f.ctx,`SELECT notitle.privacy_scrub_account($1,$2,$3)`,f.account.Account.ID,f.store.options.Policy.Version,f.now.Add(365*24*time.Hour)).Scan(&done);e==nil{t.Fatal("future caller clock bypassed retention")};p:=f.store.options.Policy;p.Rules[0].MaximumDays++;other:=NewStore(f.store.pool,Options{Policy:p,Journal:f.store.options.Journal,Now:func()time.Time{return f.now}});if !errors.Is(other.Replay(f.ctx),ErrPolicy){t.Fatal("changed manifest reused approved version")}}

func TestIntegrationPrivacyHoldsEnforceRolesRevisionAndReplay(t *testing.T){f:=integration(t);in:=HoldInput{ScopeKind:"account",ScopeRef:f.account.Account.ID,Reason:"Synthetic reviewed preservation requirement",ReviewAt:f.now.Add(time.Hour)};h,e:=f.store.PutHold(f.ctx,f.admin,in);if e!=nil{t.Fatal(e)}
    if _,e=f.store.ReleaseHold(f.ctx,f.admin,h.ID,h.Revision+1,"Synthetic approved release");!errors.Is(e,ErrConflict){t.Fatal("stale release accepted")};released,e:=f.store.ReleaseHold(f.ctx,f.admin,h.ID,h.Revision,"Synthetic approved release");if e!=nil||released.ReleasedAt==nil{t.Fatal("release failed",e)}
    // Simulate an older restored projection; journal replay must restore the
    // release without needing directory order or resurrecting the old hold.
    if _,e=f.migration.Exec(f.ctx,`DELETE FROM notitle.privacy_holds WHERE id=$1`,h.ID);e!=nil{t.Fatal(e)};if e=f.store.Replay(f.ctx);e!=nil{t.Fatal(e)};var rev int64;var release *time.Time;if f.store.pool.QueryRow(f.ctx,`SELECT revision,released_at FROM notitle.privacy_holds WHERE id=$1`,h.ID).Scan(&rev,&release)!=nil||rev!=2||release==nil{t.Fatal("restore lost release")}
    if _,e=f.migration.Exec(f.ctx,`UPDATE notitle.admin_users SET roles=ARRAY['moderator'] WHERE id=$1`,f.admin.OperatorID);e!=nil{t.Fatal(e)};if _,e=f.store.PutHold(f.ctx,f.admin,in);!errors.Is(e,ErrForbidden){t.Fatal("moderator authorized privacy hold")}
}

func TestIntegrationPrivacyOrdinaryScrubHonorsHoldAndOffHostBarrier(t *testing.T){f:=integration(t);f.delete(t);h,e:=f.store.PutHold(f.ctx,f.admin,HoldInput{ScopeKind:"account",ScopeRef:f.account.Account.ID,Reason:"Retain ordinary data for reviewed investigation",ReviewAt:f.now.Add(time.Hour)});if e!=nil{t.Fatal(e)};if e=f.scrub();e!=nil{t.Fatal(e)};if f.count(t,`SELECT count(*) FROM notitle.profiles WHERE account_id=$1`,f.account.Account.ID)!=1{t.Fatal("held profile erased")}
    if _,e=f.store.ReleaseHold(f.ctx,f.admin,h.ID,h.Revision,"Duty satisfied; release authorized");e!=nil{t.Fatal(e)};f.store.options.DeletionRecoveryPoint=func(context.Context)(time.Time,error){return f.now.Add(-time.Second),nil};if e=f.scrub();e!=nil{t.Fatal(e)};if f.count(t,`SELECT count(*) FROM notitle.profiles WHERE account_id=$1`,f.account.Account.ID)!=1{t.Fatal("unrecoverable deletion was completed")};f.store.options.DeletionRecoveryPoint=func(context.Context)(time.Time,error){return f.now,nil};if e=f.scrub();e!=nil{t.Fatal(e)}
    if f.count(t,`SELECT count(*) FROM notitle.profiles WHERE account_id=$1`,f.account.Account.ID)!=0||f.count(t,`SELECT count(*) FROM notitle.sessions WHERE account_id=$1`,f.account.Account.ID)!=0{t.Fatal("ordinary data not scrubbed")};if f.count(t,`SELECT count(*) FROM notitle.restricted_registration WHERE account_id=$1`,f.account.Account.ID)!=1{t.Fatal("required registration erased")};var state,status string;if f.store.pool.QueryRow(f.ctx,`SELECT d.state,a.status FROM notitle.deletion_jobs d JOIN notitle.accounts a ON a.id=d.account_id WHERE a.id=$1`,f.account.Account.ID).Scan(&state,&status)!=nil||state!="ordinary_erased_restricted_retained"||status!="deletion_pending"{t.Fatal("scrub revived account or overstated erasure")}
    // Reapplying a restored tombstone must never reconstruct a removed profile.
    var deletionID string;if f.store.pool.QueryRow(f.ctx,`SELECT id::text FROM notitle.deletion_jobs WHERE account_id=$1`,f.account.Account.ID).Scan(&deletionID)!=nil{t.Fatal("deletion missing")};if e=f.identity.ApplyTombstone(f.ctx,identity.Tombstone{DeletionID:deletionID,AccountID:f.account.Account.ID,AccountGeneration:2,RequestedAt:f.now});e!=nil{t.Fatal(e)};if f.count(t,`SELECT count(*) FROM notitle.profiles WHERE account_id=$1`,f.account.Account.ID)!=0{t.Fatal("restore resurrected profile")}
}

func TestIntegrationPrivacyExportIsOwnOnlyAndFresh(t *testing.T){f:=integration(t);got,e:=f.store.Export(f.ctx,f.guard);if e!=nil||got.Username!=f.account.Account.Username||len(got.Consents)!=4{t.Fatal("own export failed",e)};raw,_:=json.Marshal(got);for _,forbidden:=range []string{"password_hash","recovery_hash","token_hash","account_id","case_id","reporter","friends","blocked"}{if strings.Contains(string(raw),forbidden){t.Fatal("restricted data entered self export")}};if _,e=f.store.pool.Exec(f.ctx,`UPDATE notitle.sessions SET revoked_at=$2 WHERE id=$1`,f.guard.SessionID,f.now);e!=nil{t.Fatal(e)};if _,e=f.store.Export(f.ctx,f.guard);e==nil{t.Fatal("revoked session exported")}}

func TestIntegrationPrivacyClosedReceiptKeepsOnlyOriginalFinancialSubject(t *testing.T){f:=integration(t);ref,_:=uuid();ref=strings.ReplaceAll(ref,"-","");_,e:=f.migration.Exec(f.ctx,`INSERT INTO notitle.purchase_orders(ref,account_id,financial_subject,idempotency_key,environment,merchant_id,plan_id,plan_version,plan_name,amount_paise,currency,duration_seconds,tax_treatment,tax_paise,state,created_at,paid_at)VALUES($1,$2,$2::text,$1,'sandbox','synthetic','three-day',1,'Three days',9900,'INR',259200,'not_applicable',0,'paid',$3,$3)`,ref,f.account.Account.ID,f.now);if e!=nil{t.Fatal(e)};if _,e=f.migration.Exec(f.ctx,`INSERT INTO notitle.payment_attempts(environment,payment_id,order_ref,amount_paise,currency,status,paid_at,observed_at)VALUES('sandbox',$1,$1,9900,'INR','SUCCESS',$2,$2)`,ref,f.now);e!=nil{t.Fatal(e)};f.delete(t);if e=f.scrub();e!=nil{t.Fatal(e)};receipt,e:=f.store.ClosedReceipt(f.ctx,f.receipt,ref);if e!=nil||receipt.Receipt.CapturedPaise!=9900||receipt.Environment!="sandbox"{t.Fatal("closed account lost required receipt",e)};if _,e=f.store.ClosedReceipt(f.ctx,base64.RawURLEncoding.EncodeToString(make([]byte,32)),ref);!errors.Is(e,ErrUnauthorized){t.Fatal("purchase reference alone proved ownership")}
    job,e:=f.store.SchedulePurge(f.ctx,f.admin,PurgeInput{Kind:"financial",SubjectRef:f.account.Account.ID,Reason:"Reviewed future expiry of original financial books"});if e!=nil{t.Fatal(e)};if !job.NotBefore.After(f.now){t.Fatal("fresh financial records immediately erasable")};if e=f.scrub();e!=nil{t.Fatal(e)};if f.count(t,`SELECT count(*) FROM notitle.purchase_orders WHERE ref=$1`,ref)!=1{t.Fatal("financial minimum erased")}
}

func TestIntegrationPrivacyMissingJournalFailsRestoreBarrier(t *testing.T){f:=integration(t);if _,e:=f.store.PutHold(f.ctx,f.admin,HoldInput{ScopeKind:"account",ScopeRef:f.account.Account.ID,Reason:"Synthetic recoverable preservation requirement",ReviewAt:f.now.Add(time.Hour)});e!=nil{t.Fatal(e)};missing,e:=holdlog.Open(filepath.Join(t.TempDir(),"empty"));if e!=nil{t.Fatal(e)};defer missing.Close();options:=f.store.options;options.Journal=missing;restored:=NewStore(f.store.pool,options);if !errors.Is(restored.Replay(f.ctx),ErrUnavailable)||restored.Ready(f.ctx)==nil{t.Fatal("empty journal reopened a database with known hold history")}}

func TestIntegrationPrivacySecurityAuditExpiryPreservesHeldSubject(t *testing.T){f:=integration(t);held,_:=uuid();expired,_:=uuid();old:=f.now.AddDate(0,0,-181);if _,e:=f.migration.Exec(f.ctx,`INSERT INTO notitle.admin_audit(id,admin_id,action,subject_ref,reason,result,created_at)VALUES($1,$3,'synthetic_audit',$4,'Synthetic held record','success',$5),($2,$3,'synthetic_audit','','Synthetic expired record','success',$5)`,held,expired,f.admin.OperatorID,f.account.Account.ID,old);e!=nil{t.Fatal(e)};if _,e:=f.store.PutHold(f.ctx,f.admin,HoldInput{ScopeKind:"account",ScopeRef:f.account.Account.ID,Reason:"Synthetic authorized audit preservation",ReviewAt:f.now.Add(time.Hour)});e!=nil{t.Fatal(e)};var n int64;if e:=f.store.pool.QueryRow(f.ctx,`SELECT notitle.privacy_expire_security_audit($1,$2)`,f.store.options.Policy.Version,time.Now().UTC()).Scan(&n);e!=nil{t.Fatal(e)};if f.count(t,`SELECT count(*) FROM notitle.admin_audit WHERE id=$1`,held)!=1||f.count(t,`SELECT count(*) FROM notitle.admin_audit WHERE id=$1`,expired)!=0{t.Fatal("security audit expiry crossed hold or failed retention")}}
