package privacy

import (
    "context"
    "crypto/sha256"
    "encoding/base64"
    "time"

    "github.com/jackc/pgx/v5"
    "notitle/internal/billing"
    "notitle/internal/identity"
)

type ExportProfile struct {
    DisplayName string `json:"display_name"`; Gender string `json:"gender"`; Bio string `json:"bio"`; Topic string `json:"topic"`
    Profession string `json:"profession"`; Industry string `json:"industry"`; Experience string `json:"experience"`; Interests []string `json:"interests"`
}
type ExportConsent struct { PolicyType string `json:"policy_type"`; PolicyVersion string `json:"policy_version"`; Accepted bool `json:"accepted"`; RecordedAt time.Time `json:"recorded_at"` }
type ExportPurchase struct { PurchaseRef string `json:"purchase_ref"`; Plan string `json:"plan"`; AmountPaise int64 `json:"amount_paise"`; Currency string `json:"currency"`; Environment string `json:"environment"`; CreatedAt time.Time `json:"created_at"`; PaidAt *time.Time `json:"paid_at,omitempty"`; Status string `json:"status"` }
type Export struct { SchemaVersion int `json:"schema_version"`; ExportedAt time.Time `json:"exported_at"`; Username string `json:"username"`; Profile ExportProfile `json:"profile"`; Consents []ExportConsent `json:"consents"`; Purchases []ExportPurchase `json:"purchases"` }

// Export is a purpose-built owner DTO, never database serialization. Friends,
// blocked peers, reports about the user, evidence and other users' data are not
// included. A larger reviewed export is handled through a privacy case.
func(s *Store)Export(ctx context.Context,g identity.Guard)(Export,error){
    if e:=s.Ready(ctx);e!=nil{return Export{},e};now:=s.options.Now().UTC();tx,e:=s.pool.BeginTx(ctx,pgx.TxOptions{IsoLevel:pgx.RepeatableRead});if e!=nil{return Export{},ErrUnavailable};defer rollback(tx)
    var generation int64;var status string;var out Export
    if tx.QueryRow(ctx,`SELECT username,generation,status FROM notitle.accounts WHERE id=$1 FOR UPDATE`,g.AccountID).Scan(&out.Username,&generation,&status)!=nil{return Export{},ErrUnauthorized};if generation!=g.AccountGeneration||status!="active"{return Export{},ErrUnauthorized}
    var valid bool
    if tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.sessions WHERE id=$1 AND account_id=$2 AND account_generation=$3 AND token_hash=$4 AND revoked_at IS NULL AND created_at<=$5 AND absolute_expires_at>$5 AND last_seen_at>$5-interval '7 days' AND authenticated_at<=$5 AND authenticated_at>$5-interval '5 minutes')`,g.SessionID,g.AccountID,g.AccountGeneration,g.TokenHash[:],now).Scan(&valid)!=nil{return Export{},ErrUnavailable};if !valid{return Export{},identity.ErrReauthentication}
    p:=&out.Profile
    if tx.QueryRow(ctx,`SELECT p.display_name,p.gender,p.bio,p.topic,pp.profession,pp.industry,pp.experience,COALESCE((SELECT array_agg(interest ORDER BY interest) FROM notitle.professional_interests WHERE account_id=$1),ARRAY[]::text[]) FROM notitle.profiles p JOIN notitle.professional_profiles pp USING(account_id) WHERE p.account_id=$1`,g.AccountID).Scan(&p.DisplayName,&p.Gender,&p.Bio,&p.Topic,&p.Profession,&p.Industry,&p.Experience,&p.Interests)!=nil{return Export{},ErrUnavailable}
    out.Consents=[]ExportConsent{};rows,e:=tx.Query(ctx,`SELECT policy_type,policy_version,accepted,recorded_at FROM notitle.consent_events WHERE account_id=$1 ORDER BY recorded_at,policy_type LIMIT 1001`,g.AccountID);if e!=nil{return Export{},ErrUnavailable};for rows.Next(){var c ExportConsent;if rows.Scan(&c.PolicyType,&c.PolicyVersion,&c.Accepted,&c.RecordedAt)!=nil{rows.Close();return Export{},ErrUnavailable};out.Consents=append(out.Consents,c)};rows.Close();if rows.Err()!=nil||len(out.Consents)>1000{return Export{},ErrUnavailable}
    out.Purchases=[]ExportPurchase{};rows,e=tx.Query(ctx,`SELECT ref,plan_name,amount_paise,currency,environment,created_at,paid_at,state FROM notitle.purchase_orders WHERE account_id=$1 ORDER BY created_at,ref LIMIT 1001`,g.AccountID);if e!=nil{return Export{},ErrUnavailable};for rows.Next(){var p ExportPurchase;if rows.Scan(&p.PurchaseRef,&p.Plan,&p.AmountPaise,&p.Currency,&p.Environment,&p.CreatedAt,&p.PaidAt,&p.Status)!=nil{rows.Close();return Export{},ErrUnavailable};out.Purchases=append(out.Purchases,p)};rows.Close();if rows.Err()!=nil||len(out.Purchases)>1000{return Export{},ErrUnavailable}
    out.SchemaVersion=1;out.ExportedAt=now
    if e=audit(ctx,tx,AdminGuard{Now:now},"privacy_self_export","","Authenticated account exported its own allowlisted data");e!=nil{return Export{},e};if tx.Commit(ctx)!=nil{return Export{},ErrUnavailable};return out,nil
}

type ClosedReceipt struct { Receipt billing.Receipt `json:"receipt"`; Environment billing.Environment `json:"environment"` }
func receiptHash(secret string)([32]byte,error){if len(secret)!=43{return [32]byte{},ErrUnauthorized};v,e:=base64.RawURLEncoding.Strict().DecodeString(secret);if e!=nil||len(v)!=32{return [32]byte{},ErrUnauthorized};return sha256.Sum256([]byte("notitle:deletion:"+secret)),nil}

// A saved independent deletion receipt proves the same original account. A
// complaint case bearer, public purchase reference or screenshot proves nothing.
// Losing this secret routes to the restricted privacy case verification process.
func(s *Store)ClosedReceipt(ctx context.Context,deletionReceiptSecret,purchaseRef string)(ClosedReceipt,error){
    var out ClosedReceipt;if e:=s.Ready(ctx);e!=nil{return out,e};hash,e:=receiptHash(deletionReceiptSecret);if e!=nil{return out,e};if len(purchaseRef)<16||len(purchaseRef)>128{return out,ErrUnauthorized}
    tx,e:=s.pool.Begin(ctx);if e!=nil{return out,ErrUnavailable};defer rollback(tx);var accountID string
    if tx.QueryRow(ctx,`SELECT a.id::text FROM notitle.deletion_jobs d JOIN notitle.accounts a ON a.id=d.account_id WHERE d.receipt_hash=$1 AND a.status='deletion_pending' AND d.tombstone_durable FOR UPDATE OF a`,hash[:]).Scan(&accountID)!=nil{return out,ErrUnauthorized}
    r:=&out.Receipt;p:=&r.Plan
    if tx.QueryRow(ctx,`SELECT ref,environment,plan_id,plan_version,plan_name,amount_paise,currency,duration_seconds,tax_treatment,tax_paise,paid_at,state FROM notitle.purchase_orders WHERE ref=$1 AND account_id=$2 AND paid_at IS NOT NULL`,purchaseRef,accountID).Scan(&r.PurchaseRef,&out.Environment,&p.ID,&p.Version,&p.Name,&p.AmountPaise,&p.Currency,&p.DurationSeconds,&p.TaxTreatment,&p.TaxPaise,&r.PaidAt,&r.Status)!=nil{return out,ErrUnauthorized}
    if tx.QueryRow(ctx,`SELECT COALESCE(sum(amount_paise),0) FROM notitle.payment_attempts WHERE order_ref=$1 AND status='SUCCESS'`,purchaseRef).Scan(&r.CapturedPaise)!=nil{return out,ErrUnavailable};if tx.QueryRow(ctx,`SELECT COALESCE(sum(amount_paise),0) FROM notitle.refunds WHERE order_ref=$1 AND state='processed'`,purchaseRef).Scan(&r.RefundedPaise)!=nil{return out,ErrUnavailable}
    if e=audit(ctx,tx,AdminGuard{Now:s.options.Now().UTC()},"privacy_closed_receipt",purchaseRef,"Independent deletion receipt verified for retained purchase");e!=nil{return out,e};if tx.Commit(ctx)!=nil{return out,ErrUnavailable};return out,nil
}
