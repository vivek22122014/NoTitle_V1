package privacy

import (
    "bytes"
    "context"
    "crypto/rand"
    "encoding/hex"
    "encoding/json"
    "fmt"
    "sync"
    "sync/atomic"
    "time"

    "github.com/jackc/pgx/v5"
    "github.com/jackc/pgx/v5/pgxpool"
    "notitle/internal/holdlog"
)

type Options struct { Policy Policy; Journal Journal; Now func()time.Time; Ready func(context.Context)error; RecoveryPoint func(context.Context)(time.Time,error); DeletionRecoveryPoint func(context.Context)(time.Time,error) }
type Store struct { pool *pgxpool.Pool; options Options; mu sync.Mutex; ready atomic.Bool }
func NewStore(pool *pgxpool.Pool,options Options)*Store{if options.Now==nil{options.Now=time.Now};return &Store{pool:pool,options:options}}
func(s *Store)Ready(ctx context.Context)error{
    if ctx.Err()!=nil||!s.ready.Load(){return ErrUnavailable}
    // Readiness also protects private hold/release/export entry points. The
    // background worker's check alone cannot fence a concurrent operator
    // action when the host clock or deletion replay becomes unavailable.
    // This dependency is the base lifecycle check, never Store.Ready itself.
    if s.options.Ready!=nil&&s.options.Ready(ctx)!=nil{return ErrUnavailable}
    if s.options.Policy.Approved&&s.options.Policy.Validate(true,s.options.Now())!=nil{return ErrPolicy}
    return nil
}

func uuid()(string,error){var b [16]byte;if _,e:=rand.Read(b[:]);e!=nil{return "",ErrUnavailable};b[6]=b[6]&15|64;b[8]=b[8]&63|128;v:=hex.EncodeToString(b[:]);return fmt.Sprintf("%s-%s-%s-%s-%s",v[:8],v[8:12],v[12:16],v[16:20],v[20:]),nil}
func validUUID(s string)bool{if len(s)!=36{return false};for i,c:=range s{if i==8||i==13||i==18||i==23{if c!='-'{return false}}else if !(c>='0'&&c<='9'||c>='a'&&c<='f'){return false}};return true}
func rollback(tx pgx.Tx){ctx,cancel:=context.WithTimeout(context.Background(),2*time.Second);defer cancel();_ = tx.Rollback(ctx)}
func lockRetention(ctx context.Context,tx pgx.Tx)error{if _,e:=tx.Exec(ctx,`SELECT pg_advisory_xact_lock(7183924509)`);e!=nil{return ErrUnavailable};return nil}

func guardAdmin(ctx context.Context,tx pgx.Tx,g AdminGuard,ownerOnly bool)error{
    var roles []string;var generation int64;var disabled bool
    if tx.QueryRow(ctx,`SELECT roles,generation,disabled FROM notitle.admin_users WHERE id=$1 FOR UPDATE`,g.OperatorID).Scan(&roles,&generation,&disabled)!=nil{return ErrUnauthorized}
    if generation!=g.Generation||disabled{return ErrUnauthorized};allowed:=false;for _,r:=range roles{if r=="owner"||!ownerOnly&&r=="grievance_officer"{allowed=true}};if !allowed{return ErrForbidden}
    var ok bool
    if tx.QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM notitle.admin_sessions WHERE token_hash=$1 AND admin_id=$2 AND admin_generation=$3 AND created_at<=$4 AND absolute_expires_at>$4 AND last_seen_at>$4-interval '15 minutes')`,g.SessionHash[:],g.OperatorID,g.Generation,g.Now).Scan(&ok)!=nil{return ErrUnavailable};if !ok{return ErrUnauthorized};return nil
}
func audit(ctx context.Context,tx pgx.Tx,g AdminGuard,action,subject,reason string)error{id,e:=uuid();if e!=nil{return e};var actor any;if g.OperatorID!=""{actor=g.OperatorID};_,e=tx.Exec(ctx,`INSERT INTO notitle.admin_audit(id,admin_id,action,subject_ref,reason,result,created_at)VALUES($1,$2,$3,$4,$5,'success',$6)`,id,actor,action,subject,reason,g.Now);if e!=nil{return ErrUnavailable};return nil}

// Replay must finish before account APIs or purge workers become ready. Hold
// events do not reference restored admin rows with a foreign key: the immutable
// authorized approver ID remains evidence even if that operator postdates PITR.
func(s *Store)Replay(ctx context.Context)error{
    s.mu.Lock();defer s.mu.Unlock();s.ready.Store(false)
    if s.pool==nil||s.options.Journal==nil||s.options.Policy.Validate(false,s.options.Now())!=nil{return ErrUnavailable}
    var replayed int64
    if e:=s.options.Journal.Replay(ctx,func(ctx context.Context,h holdlog.Record)error{
        tx,e:=s.pool.Begin(ctx);if e!=nil{return ErrUnavailable};defer rollback(tx);if e=lockRetention(ctx,tx);e!=nil{return e};if e=applyHold(ctx,tx,h);e!=nil{return e};if tx.Commit(ctx)!=nil{return ErrUnavailable};replayed++;return nil
    });e!=nil{return ErrUnavailable}
    var recorded int64;if s.pool.QueryRow(ctx,`SELECT count(*) FROM notitle.privacy_hold_events`).Scan(&recorded)!=nil||recorded!=replayed{return ErrUnavailable}
    // The runtime cannot install or approve retention rules. An operator using
    // the dedicated migration role installs reviewed manifest bytes and digest.
    if s.options.Policy.Approved {
        var digest string;var approved bool;var document []byte;var installed Policy
        if s.pool.QueryRow(ctx,`SELECT digest,approved,document FROM notitle.retention_policies WHERE version=$1`,s.options.Policy.Version).Scan(&digest,&approved,&document)!=nil||!approved||digest!=s.options.Policy.Digest(){return ErrPolicy}
        if json.Unmarshal(document,&installed)!=nil||installed.Validate(true,s.options.Now())!=nil||installed.Digest()!=digest{return ErrPolicy}
    }
    s.ready.Store(true);return nil
}

const holdColumns=`event_id::text,id::text,revision,scope_kind,scope_ref,reason,approver_id::text,review_at,recorded_at,released_at,release_reason`
type scanner interface{Scan(...any)error}
func scanHold(row scanner)(Hold,error){var h Hold;e:=row.Scan(&h.EventID,&h.ID,&h.Revision,&h.ScopeKind,&h.ScopeRef,&h.Reason,&h.ApproverID,&h.ReviewAt,&h.RecordedAt,&h.ReleasedAt,&h.ReleaseReason);if e!=nil{return Hold{},ErrUnavailable};return h,nil}
func applyHold(ctx context.Context,tx pgx.Tx,h Hold)error{
    if !holdlog.Valid(h){return ErrInvalid}
    raw,e:=json.Marshal(h);if e!=nil{return ErrInvalid}
    _,e=tx.Exec(ctx,`INSERT INTO notitle.privacy_hold_events(event_id,hold_id,revision,snapshot,recorded_at)VALUES($1,$2,$3,$4,$5) ON CONFLICT(event_id) DO NOTHING`,h.EventID,h.ID,h.Revision,raw,h.RecordedAt);if e!=nil{return ErrUnavailable}
    var stored []byte;if tx.QueryRow(ctx,`SELECT snapshot FROM notitle.privacy_hold_events WHERE event_id=$1`,h.EventID).Scan(&stored)!=nil{return ErrUnavailable};var previous Hold;if json.Unmarshal(stored,&previous)!=nil{return ErrConflict};canonical,e:=json.Marshal(previous);if e!=nil||!bytes.Equal(canonical,raw){return ErrConflict}
    _,e=tx.Exec(ctx,`INSERT INTO notitle.privacy_holds(event_id,id,revision,scope_kind,scope_ref,reason,approver_id,review_at,recorded_at,released_at,release_reason)VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) ON CONFLICT(id) DO UPDATE SET event_id=EXCLUDED.event_id,revision=EXCLUDED.revision,reason=EXCLUDED.reason,approver_id=EXCLUDED.approver_id,review_at=EXCLUDED.review_at,recorded_at=EXCLUDED.recorded_at,released_at=EXCLUDED.released_at,release_reason=EXCLUDED.release_reason WHERE notitle.privacy_holds.revision<EXCLUDED.revision AND notitle.privacy_holds.scope_kind=EXCLUDED.scope_kind AND notitle.privacy_holds.scope_ref=EXCLUDED.scope_ref`,h.EventID,h.ID,h.Revision,h.ScopeKind,h.ScopeRef,h.Reason,h.ApproverID,h.ReviewAt,h.RecordedAt,h.ReleasedAt,h.ReleaseReason);if e!=nil{return ErrUnavailable};var currentScope,currentRef,currentEvent string;var currentRevision int64;if tx.QueryRow(ctx,`SELECT scope_kind,scope_ref,event_id::text,revision FROM notitle.privacy_holds WHERE id=$1`,h.ID).Scan(&currentScope,&currentRef,&currentEvent,&currentRevision)!=nil{return ErrUnavailable};if currentScope!=h.ScopeKind||currentRef!=h.ScopeRef||currentRevision<h.Revision||currentRevision==h.Revision&&currentEvent!=h.EventID{return ErrConflict};return nil
}

func(s *Store)PutHold(ctx context.Context,g AdminGuard,in HoldInput)(Hold,error){
    if !holdlog.ValidReason(in.Reason)||len(in.ScopeRef)>128||len(in.ScopeRef)<16{return Hold{},ErrInvalid}
    id,e:=uuid();if e!=nil{return Hold{},e};event,e:=uuid();if e!=nil{return Hold{},e}
    h:=Hold{EventID:event,ID:id,Revision:1,ScopeKind:in.ScopeKind,ScopeRef:in.ScopeRef,Reason:in.Reason,ApproverID:g.OperatorID,ReviewAt:in.ReviewAt.UTC(),RecordedAt:g.Now.UTC()}
    return s.mutateHold(ctx,g,h,"privacy_hold_create",0)
}
func(s *Store)ReviewHold(ctx context.Context,g AdminGuard,id string,revision int64,reason string,reviewAt time.Time)(Hold,error){return s.changeHold(ctx,g,id,revision,reason,reviewAt,false)}
func(s *Store)ReleaseHold(ctx context.Context,g AdminGuard,id string,revision int64,reason string)(Hold,error){return s.changeHold(ctx,g,id,revision,reason,g.Now.AddDate(0,1,0),true)}
func(s *Store)changeHold(ctx context.Context,g AdminGuard,id string,revision int64,reason string,reviewAt time.Time,release bool)(Hold,error){
    if !validUUID(id)||revision<1||!holdlog.ValidReason(reason){return Hold{},ErrInvalid};if e:=s.Ready(ctx);e!=nil{return Hold{},e}
    // This preliminary read contains no user evidence; authorization and current
    // revision are checked again under the mutation lock before any change.
    h,e:=scanHold(s.pool.QueryRow(ctx,`SELECT `+holdColumns+` FROM notitle.privacy_holds WHERE id=$1`,id));if e!=nil{return Hold{},e}
    if h.Revision!=revision||h.ReleasedAt!=nil{return Hold{},ErrConflict};if release {if s.options.RecoveryPoint==nil{return Hold{},ErrUnavailable};point,e:=s.options.RecoveryPoint(ctx);if e!=nil||point.Before(h.RecordedAt){return Hold{},ErrUnavailable}};h.EventID,e=uuid();if e!=nil{return Hold{},e};h.Revision++;h.ApproverID=g.OperatorID;h.RecordedAt=g.Now.UTC();h.ReviewAt=reviewAt.UTC();action:="privacy_hold_review";h.Reason=reason
    if release{at:=g.Now.UTC();h.ReleasedAt=&at;h.ReleaseReason=reason;action="privacy_hold_release"};if !holdlog.Valid(h){return Hold{},ErrInvalid};return s.mutateHold(ctx,g,h,action,revision)
}
func(s *Store)mutateHold(ctx context.Context,g AdminGuard,h Hold,action string,expected int64)(Hold,error){
    s.mu.Lock();defer s.mu.Unlock();if e:=s.Ready(ctx);e!=nil{return Hold{},e}
    tx,e:=s.pool.Begin(ctx);if e!=nil{return Hold{},ErrUnavailable};defer rollback(tx)
    if e=guardAdmin(ctx,tx,g,h.ScopeKind=="financial");e!=nil{return Hold{},e};if e=lockRetention(ctx,tx);e!=nil{return Hold{},e}
    if expected==0 {ref,e:=resolveSubject(ctx,tx,h.ScopeKind,h.ScopeRef);if e!=nil{return Hold{},e};h.ScopeRef=ref};if !holdlog.Valid(h){return Hold{},ErrInvalid}
    if expected>0{var revision int64;var released *time.Time;if tx.QueryRow(ctx,`SELECT revision,released_at FROM notitle.privacy_holds WHERE id=$1 FOR UPDATE`,h.ID).Scan(&revision,&released)!=nil||revision!=expected||released!=nil{return Hold{},ErrConflict}}
    if e=audit(ctx,tx,g,action,h.ID,h.Reason);e!=nil{return Hold{},e}
    // Journal first, while the same global lock excludes every destructive job.
    // Any ambiguous write/commit latches readiness until a complete replay.
    if e=s.options.Journal.Append(ctx,h);e!=nil{s.ready.Store(false);return Hold{},ErrUnavailable}
    if e=applyHold(ctx,tx,h);e!=nil{s.ready.Store(false);return Hold{},e};if tx.Commit(ctx)!=nil{s.ready.Store(false);return Hold{},ErrUnavailable};return h,nil
}
