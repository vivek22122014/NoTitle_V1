package privacy

import (
    "bytes"
    "crypto/sha256"
    "encoding/hex"
    "encoding/json"
    "io"
    "net/url"
    "os"
    "strings"
    "time"
)

type RetentionRule struct {
    Purpose string `json:"purpose"`
    Trigger string `json:"trigger"`
    MinimumDays int `json:"minimum_days"`
    MaximumDays int `json:"maximum_days"`
    LegalSource string `json:"legal_source"`
    EffectiveAt time.Time `json:"effective_at"`
    ReviewedUntil time.Time `json:"reviewed_until"`
}
type Policy struct {
    Version string `json:"version"`
    StorageRegion string `json:"storage_region"`
    Approved bool `json:"approved"`
    Approver string `json:"approver"`
    ApprovalReference string `json:"approval_reference"`
    ReviewedAt time.Time `json:"reviewed_at"`
    ReviewDueAt time.Time `json:"review_due_at"`
    OrdinaryDeletionApproved bool `json:"ordinary_deletion_approved"`
    FinancialScheduleApproved bool `json:"financial_schedule_approved"`
    NoContentArchiveApproved bool `json:"no_content_archive_approved"`
    Rules []RetentionRule `json:"rules"`
}

// Validate requires actual versioned sources and exact effective dates. Setting
// Approved cannot substitute for the deployment's signed counsel/accountant
// review; the referenced approval must bind this manifest's digest.
func (p Policy) Validate(production bool, now time.Time) error {
    if len(p.Version)<1 || len(p.Version)>64 || strings.ContainsAny(p.Version," /\\\n\r\t") || len(p.Rules)>16 { return ErrPolicy }
    if !p.Approved { if production { return ErrPolicy }; return nil }
    if p.StorageRegion!="IN" || len(strings.TrimSpace(p.Approver))<3 || len(strings.TrimSpace(p.ApprovalReference))<8 || p.ReviewedAt.IsZero() || p.ReviewedAt.After(now) || !p.ReviewDueAt.After(now) || p.ReviewDueAt.After(p.ReviewedAt.AddDate(1,0,0)) || !p.OrdinaryDeletionApproved || !p.FinancialScheduleApproved || !p.NoContentArchiveApproved { return ErrPolicy }
    expected:=map[string]string{"registration":"cancellation","cases":"closure","financial":"final_activity","security_logs":"collection","backups":"creation","metrics":"collection"}
    for _,r:=range p.Rules {
        trigger,ok:=expected[r.Purpose]; if !ok || r.Trigger!=trigger || r.MinimumDays<0 || r.MaximumDays<1 || r.MaximumDays<r.MinimumDays || r.MaximumDays>36525 || r.EffectiveAt.IsZero() || r.EffectiveAt.After(now) || !r.ReviewedUntil.After(now) || r.ReviewedUntil.After(p.ReviewDueAt) { return ErrPolicy }
        u,err:=url.Parse(r.LegalSource); if err!=nil || u.Scheme!="https" || u.Host=="" || u.User!=nil || u.Fragment!="" || len(r.LegalSource)>2048 { return ErrPolicy }
        if (r.Purpose=="registration"||r.Purpose=="security_logs")&&r.MinimumDays<180{return ErrPolicy}
        delete(expected,r.Purpose)
    }
    if len(expected)!=0 { return ErrPolicy }; return nil
}
func (p Policy) Rule(purpose string)(RetentionRule,bool){for _,r:=range p.Rules{if r.Purpose==purpose{return r,true}};return RetentionRule{},false}
func (p Policy) Digest() string { raw,_:=json.Marshal(p); sum:=sha256.Sum256(raw); return hex.EncodeToString(sum[:]) }

func LoadPolicyFile(path string, production bool, now time.Time)(Policy,error){
    var p Policy
    if path=="" { p.Version="draft-v1"; return p,p.Validate(production,now) }
    st,err:=os.Lstat(path);if err!=nil||!st.Mode().IsRegular()||st.Mode()&os.ModeSymlink!=0||st.Mode().Perm()&0022!=0||st.Size()>65536{return p,ErrPolicy}
    f,err:=os.Open(path);if err!=nil{return p,ErrPolicy};defer f.Close();actual,err:=f.Stat();if err!=nil||!os.SameFile(st,actual){return p,ErrPolicy}
    raw,err:=io.ReadAll(io.LimitReader(f,65537));if err!=nil||len(raw)>65536{return p,ErrPolicy}
    d:=json.NewDecoder(bytes.NewReader(raw));d.DisallowUnknownFields();if d.Decode(&p)!=nil{return Policy{},ErrPolicy};var extra any;if d.Decode(&extra)!=io.EOF{return Policy{},ErrPolicy}
    if err:=p.Validate(production,now);err!=nil{return Policy{},err};return p,nil
}
