package privacy

import (
    "context"
    "errors"
    "time"
    "notitle/internal/holdlog"
)

var (
    ErrForbidden=errors.New("privacy permission denied")
    ErrInvalid=errors.New("invalid privacy request")
    ErrConflict=errors.New("privacy state changed")
    ErrUnavailable=errors.New("privacy service unavailable")
    ErrUnauthorized=errors.New("privacy authentication required")
    ErrPolicy=errors.New("reviewed retention policy required")
    ErrHeld=errors.New("retention subject held")
)
type AdminGuard struct { OperatorID string; Generation int64; SessionHash [32]byte; Now time.Time }
type Hold = holdlog.Record
type HoldInput struct { ScopeKind,ScopeRef,Reason string; ReviewAt time.Time }
type PurgeInput struct { Kind,SubjectRef,Reason string; NotBefore time.Time }
type PurgeJob struct { ID string; Kind string; SubjectRef string; State string; PolicyVersion string; NotBefore time.Time; Attempts int; LastError string; CreatedAt time.Time }
type Worklist struct { Holds []Hold; Jobs []PurgeJob; PolicyVersion string; PurgeEnabled bool }
type Journal interface { Append(context.Context,holdlog.Record)error; Replay(context.Context,func(context.Context,holdlog.Record)error)error }
