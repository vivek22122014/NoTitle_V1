package privacy

import (
    "context"
    "time"
    "notitle/internal/holdlog"
    "github.com/jackc/pgx/v5"
)

const jobColumns=`id::text,kind,subject_ref,state,policy_version,not_before,attempts,last_error,created_at`
func scanJob(row scanner)(PurgeJob,error){var j PurgeJob;e:=row.Scan(&j.ID,&j.Kind,&j.SubjectRef,&j.State,&j.PolicyVersion,&j.NotBefore,&j.Attempts,&j.LastError,&j.CreatedAt);if e!=nil{return PurgeJob{},ErrUnavailable};return j,nil}
func(s *Store)Worklist(ctx context.Context,g AdminGuard)(Worklist,error){
    out:=Worklist{Holds:[]Hold{},Jobs:[]PurgeJob{},PolicyVersion:s.options.Policy.Version,PurgeEnabled:s.options.Policy.Approved}
    if e:=s.Ready(ctx);e!=nil{return out,e};tx,e:=s.pool.Begin(ctx);if e!=nil{return out,ErrUnavailable};defer rollback(tx);if e=guardAdmin(ctx,tx,g,false);e!=nil{return out,e};if e=audit(ctx,tx,g,"privacy_worklist","","Reviewed restricted retention and legal hold worklist");e!=nil{return out,e}
    rows,e:=tx.Query(ctx,`SELECT `+holdColumns+` FROM notitle.privacy_holds ORDER BY (released_at IS NULL) DESC,review_at,id LIMIT 100`);if e!=nil{return out,ErrUnavailable};for rows.Next(){h,e:=scanHold(rows);if e!=nil{rows.Close();return out,e};out.Holds=append(out.Holds,h)};rows.Close();if rows.Err()!=nil{return out,ErrUnavailable}
    rows,e=tx.Query(ctx,`SELECT `+jobColumns+` FROM notitle.privacy_jobs ORDER BY (state<>'done') DESC,not_before,id LIMIT 100`);if e!=nil{return out,ErrUnavailable};for rows.Next(){j,e:=scanJob(rows);if e!=nil{rows.Close();return out,e};out.Jobs=append(out.Jobs,j)};rows.Close();if rows.Err()!=nil{return out,ErrUnavailable};if tx.Commit(ctx)!=nil{return out,ErrUnavailable};return out,nil
}

func resolveSubject(ctx context.Context,tx pgx.Tx,kind,ref string)(string,error){
    if kind=="report"{var id string;e:=tx.QueryRow(ctx,`SELECT id::text FROM notitle.reports WHERE case_ref=$1 OR id::text=$1`,ref).Scan(&id);if e!=nil{return "",ErrInvalid};return id,nil}
    if kind=="operations_case"{var found string;e:=tx.QueryRow(ctx,`SELECT ref FROM notitle.grievances WHERE ref=$1`,ref).Scan(&found);if e!=nil{return "",ErrInvalid};return found,nil}
    if (kind!="account"&&kind!="registration"&&kind!="financial")||!validUUID(ref){return "",ErrInvalid};var found string;if tx.QueryRow(ctx,`SELECT id::text FROM notitle.accounts WHERE id=$1`,ref).Scan(&found)!=nil{return "",ErrInvalid};return found,nil
}
func retentionAnchor(ctx context.Context,tx pgx.Tx,kind,ref string)(time.Time,error){
    var t *time.Time;var e error
    switch kind {
    case "registration":e=tx.QueryRow(ctx,`SELECT requested_at FROM notitle.deletion_jobs WHERE account_id=$1 AND tombstone_durable AND scrubbed_at IS NOT NULL`,ref).Scan(&t)
    case "report":e=tx.QueryRow(ctx,`SELECT max(a.created_at) FROM notitle.moderation_actions a JOIN notitle.reports r ON r.id=a.case_id WHERE a.case_id=$1 AND a.action='resolve' AND r.state='resolved'`,ref).Scan(&t)
    case "operations_case":e=tx.QueryRow(ctx,`SELECT closed_at FROM notitle.grievances WHERE ref=$1 AND state='resolved'`,ref).Scan(&t)
    case "financial":e=tx.QueryRow(ctx,`SELECT max(at_) FROM (
        SELECT GREATEST(o.created_at,o.paid_at)at_ FROM notitle.purchase_orders o JOIN notitle.accounts a ON a.id=o.account_id WHERE a.id=$1 AND a.status='deletion_pending'
        UNION ALL SELECT GREATEST(r.created_at,r.processed_at) FROM notitle.refunds r JOIN notitle.purchase_orders o ON o.ref=r.order_ref WHERE o.account_id=$1
        UNION ALL SELECT d.updated_at FROM notitle.disputes d JOIN notitle.purchase_orders o ON o.ref=d.order_ref WHERE o.account_id=$1
        UNION ALL SELECT r.recorded_at FROM notitle.settlement_reconciliation r JOIN notitle.purchase_orders o ON o.ref=r.order_ref WHERE o.account_id=$1
        UNION ALL SELECT a.created_at FROM notitle.premium_adjustments a WHERE a.account_id=$1
        UNION ALL SELECT b.resolved_at FROM notitle.billing_review_cases b JOIN notitle.purchase_orders o ON o.ref=b.order_ref WHERE o.account_id=$1
        UNION ALL SELECT a.created_at FROM notitle.billing_review_actions a JOIN notitle.billing_review_cases b ON b.ref=a.case_ref JOIN notitle.purchase_orders o ON o.ref=b.order_ref WHERE o.account_id=$1
        UNION ALL SELECT a.created_at FROM notitle.billing_dispute_actions a JOIN notitle.purchase_orders o ON o.ref=a.order_ref WHERE o.account_id=$1
    )a`,ref).Scan(&t)
    default:return time.Time{},ErrInvalid
    }
    if e!=nil||t==nil{return time.Time{},ErrConflict};return *t,nil
}
type rowQuerier interface{QueryRow(context.Context,string,...any)pgx.Row}
func dueAfterRecordMinimum(ctx context.Context,q rowQuerier,kind,ref string,due time.Time)(time.Time,error){
    var floor *time.Time;var sql string
    switch kind {
    case "registration":sql=`SELECT retention_until FROM notitle.restricted_registration WHERE account_id=$1`
    case "report":sql=`SELECT max(retention_until) FROM (SELECT retention_until FROM notitle.reports WHERE id=$1 UNION ALL SELECT retention_until FROM notitle.report_evidence WHERE case_id=$1)t`
    case "operations_case":sql=`SELECT max(retention_until) FROM (SELECT retention_until FROM notitle.grievances WHERE ref=$1 UNION ALL SELECT retention_until FROM notitle.grievance_messages WHERE case_ref=$1)t`
    default:return due,nil
    }
    if e:=q.QueryRow(ctx,sql,ref).Scan(&floor);e!=nil{return time.Time{},ErrUnavailable};if floor!=nil&&floor.After(due){due=*floor};return due,nil
}
func(s *Store)SchedulePurge(ctx context.Context,g AdminGuard,in PurgeInput)(PurgeJob,error){
    if e:=s.Ready(ctx);e!=nil{return PurgeJob{},e};if !s.options.Policy.Approved||s.options.Policy.Validate(true,s.options.Now())!=nil{return PurgeJob{},ErrPolicy};if !holdlog.ValidReason(in.Reason){return PurgeJob{},ErrInvalid}
    tx,e:=s.pool.Begin(ctx);if e!=nil{return PurgeJob{},ErrUnavailable};defer rollback(tx);if e=guardAdmin(ctx,tx,g,in.Kind=="financial");e!=nil{return PurgeJob{},e};if e=lockRetention(ctx,tx);e!=nil{return PurgeJob{},e}
    ref,e:=resolveSubject(ctx,tx,in.Kind,in.SubjectRef);if e!=nil{return PurgeJob{},e};anchor,e:=retentionAnchor(ctx,tx,in.Kind,ref);if e!=nil{return PurgeJob{},e};purpose:=in.Kind;if purpose=="report"||purpose=="operations_case"{purpose="cases"};rule,ok:=s.options.Policy.Rule(purpose);if !ok{return PurgeJob{},ErrPolicy}
    // The reviewed maximum is the automatic expiry boundary. Operators cannot
    // silently shorten a statutory minimum or extend a record indefinitely.
    due,e:=dueAfterRecordMinimum(ctx,tx,in.Kind,ref,anchor.AddDate(0,0,rule.MaximumDays).UTC());if e!=nil{return PurgeJob{},e};if !in.NotBefore.IsZero()&&!in.NotBefore.Equal(due){return PurgeJob{},ErrInvalid}
    id,e:=uuid();if e!=nil{return PurgeJob{},e};if e=audit(ctx,tx,g,"privacy_purge_schedule",ref,in.Reason);e!=nil{return PurgeJob{},e}
    j,e:=scanJob(tx.QueryRow(ctx,`INSERT INTO notitle.privacy_jobs(id,kind,subject_ref,policy_version,not_before,reason,approved_by,created_at)VALUES($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT(kind,subject_ref,policy_version) DO UPDATE SET not_before=GREATEST(notitle.privacy_jobs.not_before,EXCLUDED.not_before),state=CASE WHEN notitle.privacy_jobs.state IN ('dead','held') THEN 'ready' ELSE notitle.privacy_jobs.state END,attempts=CASE WHEN notitle.privacy_jobs.state IN ('dead','held') THEN 0 ELSE notitle.privacy_jobs.attempts END,last_error=CASE WHEN notitle.privacy_jobs.state IN ('dead','held') THEN '' ELSE notitle.privacy_jobs.last_error END RETURNING `+jobColumns,id,in.Kind,ref,s.options.Policy.Version,due,in.Reason,g.OperatorID,g.Now));if e!=nil{return PurgeJob{},e};if tx.Commit(ctx)!=nil{return PurgeJob{},ErrUnavailable};return j,nil
}

// Run executes at most one ordinary scrub and one leased retention job per
// second. It never starts before both journal replay and the caller's deletion
// lifecycle readiness. Database/provider work stays outside the live owner.
func(s *Store)Run(ctx context.Context)error{
    ticker:=time.NewTicker(time.Second);defer ticker.Stop()
    for{select{case<-ctx.Done():return nil;case<-ticker.C:
        if s.Ready(ctx)!=nil||!s.options.Policy.Approved{continue};if s.options.Ready!=nil&&s.options.Ready(ctx)!=nil{continue}
        work,cancel:=context.WithTimeout(ctx,10*time.Second);_ = s.step(work);cancel()
    }}
}
func(s *Store)step(ctx context.Context)error{
    s.mu.Lock();defer s.mu.Unlock();if e:=s.Ready(ctx);e!=nil{return e};now:=s.options.Now().UTC()
    // Local fsync alone cannot authorize erasure of the only remaining copy.
    // The operator's verified off-host checkpoint must include every committed
    // deletion and hold event, including a release, before destructive work.
    if s.options.RecoveryPoint==nil{return ErrUnavailable};recoverable,e:=s.options.RecoveryPoint(ctx);if e!=nil||recoverable.IsZero()||recoverable.After(now.Add(5*time.Second)){return ErrUnavailable}
    var latest *time.Time;if s.pool.QueryRow(ctx,`SELECT max(recorded_at) FROM notitle.privacy_hold_events`).Scan(&latest)!=nil{return ErrUnavailable};if latest!=nil&&recoverable.Before(*latest){return ErrUnavailable}
    if s.options.DeletionRecoveryPoint==nil{return ErrUnavailable};deletionPoint,e:=s.options.DeletionRecoveryPoint(ctx);if e!=nil||deletionPoint.IsZero()||deletionPoint.After(now.Add(5*time.Second)){return ErrUnavailable}
    var account string;e=s.pool.QueryRow(ctx,`SELECT account_id::text FROM notitle.deletion_jobs d WHERE tombstone_durable AND scrubbed_at IS NULL AND requested_at<=$1 AND NOT EXISTS(SELECT 1 FROM notitle.privacy_holds h WHERE h.scope_kind='account' AND h.scope_ref=d.account_id::text AND h.released_at IS NULL) ORDER BY requested_at,id LIMIT 1`,deletionPoint).Scan(&account)
    if e==nil {if e=s.scrubAccountLocked(ctx,account,now);e!=nil{return e}}else if e!=pgx.ErrNoRows{return ErrUnavailable}
    var expiredAudit int64;if s.pool.QueryRow(ctx,`SELECT notitle.privacy_expire_security_audit($1,$2)`,s.options.Policy.Version,now).Scan(&expiredAudit)!=nil{return ErrUnavailable}
    if e=s.scheduleAutomatic(ctx,now);e!=nil{return e}
    lease,e:=uuid();if e!=nil{return e}
    var job string;e=s.pool.QueryRow(ctx,`UPDATE notitle.privacy_jobs SET state='leased',lease_owner=$1,lease_until=$2,attempts=attempts+1 WHERE id=(SELECT id FROM notitle.privacy_jobs WHERE policy_version=$3 AND attempts<8 AND ((state IN ('ready','held') AND not_before<=$4) OR (state='leased' AND lease_until<=$4)) ORDER BY not_before,id LIMIT 1 FOR UPDATE SKIP LOCKED) RETURNING id::text`,lease,now.Add(30*time.Second),s.options.Policy.Version,now).Scan(&job)
    if e==pgx.ErrNoRows{return nil};if e!=nil{return ErrUnavailable};var result string
    if s.pool.QueryRow(ctx,`SELECT notitle.privacy_execute_job($1,$2,$3)`,job,lease,now).Scan(&result)!=nil{result="database"}
    if result=="done"{return nil};state:="ready";retry:=now.Add(time.Minute);if result=="held"{state="held";retry=now.Add(time.Hour)};if result=="policy"||result=="review"{state="dead"};if result=="not_due"{retry=now.Add(24*time.Hour)}
    _,e=s.pool.Exec(ctx,`UPDATE notitle.privacy_jobs SET state=CASE WHEN attempts>=8 THEN 'dead' ELSE $3 END,last_error=$4,lease_owner=NULL,lease_until=NULL,not_before=$5 WHERE id=$1 AND state='leased' AND lease_owner=$2`,job,lease,state,result,retry);if e!=nil{return ErrUnavailable};return nil
}
// The caller holds mu, keeping an ambiguous hold-journal commit from racing
// destruction. This helper is also used by targeted real-PostgreSQL tests so a
// shared disposable test database cannot erase another package's fixtures.
func(s *Store)scrubAccountLocked(ctx context.Context,account string,now time.Time)error{
    if s.Ready(ctx)!=nil||!s.options.Policy.Approved||s.options.RecoveryPoint==nil||s.options.DeletionRecoveryPoint==nil{return ErrUnavailable}
    point,e:=s.options.RecoveryPoint(ctx);if e!=nil||point.IsZero()||point.After(now.Add(5*time.Second)){return ErrUnavailable};var latest *time.Time
    if s.pool.QueryRow(ctx,`SELECT max(recorded_at) FROM notitle.privacy_hold_events`).Scan(&latest)!=nil{return ErrUnavailable};if latest!=nil&&point.Before(*latest){return ErrUnavailable}
    deletion,e:=s.options.DeletionRecoveryPoint(ctx);if e!=nil||deletion.IsZero()||deletion.After(now.Add(5*time.Second)){return ErrUnavailable};var requested time.Time
    e=s.pool.QueryRow(ctx,`SELECT requested_at FROM notitle.deletion_jobs WHERE account_id=$1 AND tombstone_durable`,account).Scan(&requested);if e!=nil{return ErrUnavailable};if deletion.Before(requested){return nil}
    var done bool;if s.pool.QueryRow(ctx,`SELECT notitle.privacy_scrub_account($1,$2,$3)`,account,s.options.Policy.Version,now).Scan(&done)!=nil{return ErrUnavailable};return nil
}
func(s *Store)scheduleAutomatic(ctx context.Context,now time.Time)error{
    // Policy approval explicitly authorizes these scoped jobs. Financial books
    // require a separate owner action and are never auto-enqueued.
    for _,kind:=range []string{"registration","report","operations_case"}{
        purpose:=kind;if kind!="registration"{purpose="cases"};rule,ok:=s.options.Policy.Rule(purpose);if !ok{return ErrPolicy}
        var ref string;var anchor time.Time;var query string
        switch kind {
        case "registration":query=`SELECT r.account_id::text,d.requested_at FROM notitle.restricted_registration r JOIN notitle.deletion_jobs d ON d.account_id=r.account_id WHERE NOT EXISTS(SELECT 1 FROM notitle.privacy_jobs j WHERE j.kind='registration' AND j.subject_ref=r.account_id::text AND j.policy_version=$1) ORDER BY r.retention_until LIMIT 1`
        case "report":query=`SELECT r.id::text,(SELECT max(created_at) FROM notitle.moderation_actions WHERE case_id=r.id AND action='resolve') FROM notitle.reports r WHERE r.state='resolved' AND r.evidence_purged_at IS NULL AND EXISTS(SELECT 1 FROM notitle.moderation_actions WHERE case_id=r.id AND action='resolve') AND NOT EXISTS(SELECT 1 FROM notitle.privacy_jobs j WHERE j.kind='report' AND j.subject_ref=r.id::text AND j.policy_version=$1) ORDER BY r.retention_until LIMIT 1`
        case "operations_case":query=`SELECT g.ref,g.closed_at FROM notitle.grievances g WHERE g.state='resolved' AND EXISTS(SELECT 1 FROM notitle.grievance_messages m WHERE m.case_ref=g.ref AND m.purged_at IS NULL) AND NOT EXISTS(SELECT 1 FROM notitle.privacy_jobs j WHERE j.kind='operations_case' AND j.subject_ref=g.ref AND j.policy_version=$1) ORDER BY g.closed_at LIMIT 1`
        }
        e:=s.pool.QueryRow(ctx,query,s.options.Policy.Version).Scan(&ref,&anchor);if e==pgx.ErrNoRows{continue};if e!=nil{return ErrUnavailable};due,e:=dueAfterRecordMinimum(ctx,s.pool,kind,ref,anchor.AddDate(0,0,rule.MaximumDays));if e!=nil{return e};id,e:=uuid();if e!=nil{return e};_,e=s.pool.Exec(ctx,`INSERT INTO notitle.privacy_jobs(id,kind,subject_ref,policy_version,not_before,reason,created_at)VALUES($1,$2,$3,$4,$5,'Approved purpose-specific lifecycle expiry',$6) ON CONFLICT(kind,subject_ref,policy_version) DO NOTHING`,id,kind,ref,s.options.Policy.Version,due,now);if e!=nil{return ErrUnavailable}
    };return nil
}
