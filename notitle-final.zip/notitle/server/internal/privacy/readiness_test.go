package privacy

import (
    "context"
    "errors"
    "testing"
    "time"
)

func TestPrivacyReadinessFencesAllEntryPointsAfterDependencyFailure(t *testing.T) {
    healthy := true
    store := NewStore(nil, Options{Policy: Policy{Version:"draft-test"}, Ready:func(context.Context)error{
        if !healthy{return errors.New("clock or deletion replay unavailable")};return nil
    }})
    store.ready.Store(true)
    if err:=store.Ready(context.Background());err!=nil{t.Fatal(err)}
    healthy=false
    if err:=store.Ready(context.Background());!errors.Is(err,ErrUnavailable){t.Fatal("dependency failure did not close privacy operations")}
    // Nil DB is deliberate: none of these operations may reach a transaction
    // after the clock/replay barrier has closed.
    if _,err:=store.Worklist(context.Background(),AdminGuard{});!errors.Is(err,ErrUnavailable){t.Fatal("private worklist bypassed dependency barrier")}
    if _,err:=store.ReleaseHold(context.Background(),AdminGuard{},"00000000-0000-4000-8000-000000000001",1,"Approved release");!errors.Is(err,ErrUnavailable){t.Fatal("hold release bypassed dependency barrier")}
    if err:=store.step(context.Background());!errors.Is(err,ErrUnavailable){t.Fatal("destructive worker bypassed dependency barrier")}
}

func TestPrivacyReadinessRequiresReplayAndCurrentPolicy(t *testing.T) {
    now:=time.Date(2026,10,9,0,0,0,0,time.UTC)
    store:=NewStore(nil,Options{Policy:reviewedFixture(now),Now:func()time.Time{return now}})
    if !errors.Is(store.Ready(context.Background()),ErrUnavailable){t.Fatal("unreplayed store opened")}
    store.ready.Store(true)
    ctx,cancel:=context.WithCancel(context.Background());cancel()
    if !errors.Is(store.Ready(ctx),ErrUnavailable){t.Fatal("canceled operation opened")}
    now=now.Add(31*24*time.Hour)
    if !errors.Is(store.Ready(context.Background()),ErrPolicy){t.Fatal("expired review remained ready")}
}
