package admission

import (
    "context"
    "encoding/json"
    "os"
    "path/filepath"
    "strings"
    "testing"
    "time"
)
func TestLaunchPermitBindsExactArtifactAndFiniteReviewWindow(t *testing.T){
    now:=time.Date(2026,10,9,0,0,0,0,time.UTC);release:=Release{SourceSHA256:strings.Repeat("a",64),APIImage:"registry.example/notitle/api@sha256:"+strings.Repeat("b",64),Origin:"https://example.test",Schema:9,Stage:"cohort",DeploymentManifestSHA256:strings.Repeat("f",64),Limits:Limits{200,100,25}}
    good:=Approval{SchemaVersion:1,SourceSHA256:release.SourceSHA256,APIImage:release.APIImage,Origin:release.Origin,Schema:9,ApprovedAt:now.Add(-time.Hour),ExpiresAt:now.Add(time.Hour),EvidenceSHA256:strings.Repeat("c",64),EvidenceRef:"release_review",Approved:true,Purpose:"launch",DeploymentManifestSHA256:release.DeploymentManifestSHA256,Limits:release.Limits}
    path:=filepath.Join(t.TempDir(),"permit.json")
    check:=func(v Approval)error{raw,_:=json.Marshal(v);if err:=os.WriteFile(path,raw,0600);err!=nil{t.Fatal(err)};return CheckApproval(context.Background(),path,release,"release_review",now)}
    if err:=check(good);err!=nil{t.Fatal(err)}
    for _,mutate:=range []func(*Approval){func(v *Approval){v.SourceSHA256=strings.Repeat("d",64)},func(v *Approval){v.APIImage="registry.example/notitle/api:latest"},func(v *Approval){v.Origin="https://other.test"},func(v *Approval){v.Schema=8},func(v *Approval){v.ExpiresAt=now},func(v *Approval){v.ExpiresAt=now.Add(25*time.Hour)},func(v *Approval){v.ApprovedAt=now.Add(time.Minute)},func(v *Approval){v.Approved=false}}{v:=good;mutate(&v);if check(v)==nil{t.Fatal("mismatched or expired approval accepted")}}
    if err:=check(good);err!=nil{t.Fatal(err)};if err:=os.Chmod(path,0644);err!=nil{t.Fatal(err)};if CheckApproval(context.Background(),path,release,"release_review",now)==nil{t.Fatal("world-readable approval accepted")}
}
func TestLaunchPermitRejectsDuplicateApprovalFields(t *testing.T){
    now:=time.Date(2026,10,9,0,0,0,0,time.UTC)
    release:=Release{SourceSHA256:strings.Repeat("a",64),APIImage:"registry.example/api@sha256:"+strings.Repeat("b",64),DeploymentManifestSHA256:strings.Repeat("d",64),Origin:"https://example.test",Schema:9,Stage:"cohort",Limits:Limits{200,100,25}}
    good:=Approval{SchemaVersion:1,SourceSHA256:release.SourceSHA256,APIImage:release.APIImage,DeploymentManifestSHA256:release.DeploymentManifestSHA256,Origin:release.Origin,Schema:9,Purpose:"launch",Limits:release.Limits,Approved:true,ApprovedAt:now,ExpiresAt:now.Add(time.Hour),EvidenceSHA256:strings.Repeat("c",64),EvidenceRef:"release_review"}
    raw,_:=json.Marshal(good);path:=filepath.Join(t.TempDir(),"permit.json")
    for _,changed:=range []string{strings.Replace(string(raw),`"approved":true`,`"approved":false,"approved":true`,1),strings.Replace(string(raw),`"approved":true`,`"approved":false,"Approved":true`,1),strings.Replace(string(raw),`"connected":200`,`"connected":1,"connected":200`,1)}{
        if err:=os.WriteFile(path,[]byte(changed),0600);err!=nil{t.Fatal(err)}
        if CheckApproval(context.Background(),path,release,good.EvidenceRef,now)==nil{t.Fatal("duplicate or alternate-case approval accepted")}
    }
}

func TestNestedLimitsRejectDuplicateAndCaseAliases(t *testing.T){
 for _,raw:=range []string{`{"connected":1,"connected":200,"waiting":100,"calls":25}`,`{"Connected":200,"waiting":100,"calls":25}`,`{"connected":200,"waiting":100,"calls":25,"extra":1}`,`{"connected":200,"waiting":100}`} {if strictLimits([]byte(raw)){t.Fatal("ambiguous or incomplete limits accepted")}}
 if !strictLimits([]byte(`{"connected":200,"waiting":100,"calls":25}`)){t.Fatal("canonical limits rejected")}
}

func TestValidationPermitCannotOpenPublicStageOrExceedTwoHours(t *testing.T){
 now:=time.Date(2026,10,9,0,0,0,0,time.UTC);release:=Release{SourceSHA256:strings.Repeat("a",64),APIImage:"registry.example/api@sha256:"+strings.Repeat("b",64),DeploymentManifestSHA256:strings.Repeat("d",64),Origin:"https://example.test",Schema:9,Stage:"validation",Limits:Limits{200,100,25}}
 permit:=Approval{SchemaVersion:1,SourceSHA256:release.SourceSHA256,APIImage:release.APIImage,DeploymentManifestSHA256:release.DeploymentManifestSHA256,Origin:release.Origin,Schema:9,Purpose:"validation",Limits:release.Limits,Approved:true,ApprovedAt:now,ExpiresAt:now.Add(2*time.Hour),EvidenceSHA256:strings.Repeat("c",64),EvidenceRef:"controlled_validation"}
 path:=filepath.Join(t.TempDir(),"permit.json");raw,_:=json.Marshal(permit);if err:=os.WriteFile(path,raw,0600);err!=nil{t.Fatal(err)}
 if CheckApproval(context.Background(),path,release,permit.EvidenceRef,now)!=nil{t.Fatal("valid controlled validation rejected")}
 release.Stage="public";if CheckApproval(context.Background(),path,release,permit.EvidenceRef,now)==nil{t.Fatal("validation permission opened public launch")}
 release.Stage="validation";permit.ExpiresAt=now.Add(2*time.Hour+time.Second);raw,_=json.Marshal(permit);if err:=os.WriteFile(path,raw,0600);err!=nil{t.Fatal(err)}
 if CheckApproval(context.Background(),path,release,permit.EvidenceRef,now)==nil{t.Fatal("validation window exceeded two hours")}
}
