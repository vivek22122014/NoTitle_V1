package admission

import (
    "bytes"
    "context"
    "encoding/json"
    "io"
    "os"
    "path/filepath"
    "regexp"
    "time"
)

var hashPattern=regexp.MustCompile(`^[a-f0-9]{64}$`)
var imagePattern=regexp.MustCompile(`^[a-z0-9][a-z0-9./:_-]{2,250}@sha256:[a-f0-9]{64}$`)
var evidencePattern=regexp.MustCompile(`^[a-z][a-z0-9_]{0,63}$`)
func ValidEvidenceRef(value string)bool{return evidencePattern.MatchString(value)}
type Approval struct {
    SchemaVersion int `json:"schema_version"`
    SourceSHA256 string `json:"source_sha256"`
    APIImage string `json:"api_image"`
    Origin string `json:"origin"`
    Schema int `json:"schema"`
    ApprovedAt time.Time `json:"approved_at"`
    ExpiresAt time.Time `json:"expires_at"`
    EvidenceSHA256 string `json:"evidence_sha256"`
    EvidenceRef string `json:"evidence_ref"`
    Approved bool `json:"approved"`
    Purpose string `json:"purpose"`
    DeploymentManifestSHA256 string `json:"deployment_manifest_sha256"`
    Limits Limits `json:"limits"`
}
type Limits struct {Connected int `json:"connected"`;Waiting int `json:"waiting"`;Calls int `json:"calls"`}
type Release struct {SourceSHA256,APIImage,Origin,DeploymentManifestSHA256,Stage string;Schema int;Limits Limits}
// CheckApproval binds a separately reviewed, protected consistency permit to
// this artifact. It is not a signature, a benchmark, or proof of staff/legal
// approval; those remain the underlying evidence plus the owner/MFA decision.
func CheckApproval(ctx context.Context,path string,release Release,evidence string,now time.Time)error{
    _,err:=LoadApproval(ctx,path,release,evidence,now);return err
}
func LoadApproval(ctx context.Context,path string,release Release,evidence string,now time.Time)(Approval,error){
    var unavailable Approval
    if ctx.Err()!=nil||!ValidEvidenceRef(evidence)||!hashPattern.MatchString(release.SourceSHA256)||!hashPattern.MatchString(release.DeploymentManifestSHA256)||!imagePattern.MatchString(release.APIImage)||!protectedParents(path){return unavailable,ErrUnavailable}
    info,err:=os.Lstat(path);if err!=nil||!info.Mode().IsRegular()||info.Mode()&os.ModeSymlink!=0||info.Mode().Perm()&0077!=0||info.Size()<1||info.Size()>16384{return unavailable,ErrUnavailable}
    file,err:=os.Open(path);if err!=nil{return unavailable,ErrUnavailable};defer file.Close()
    actual,err:=file.Stat();if err!=nil||!os.SameFile(info,actual)||!actual.Mode().IsRegular()||actual.Mode().Perm()&0077!=0||actual.Size()!=info.Size(){return unavailable,ErrUnavailable}
    raw,err:=io.ReadAll(io.LimitReader(file,16385));if err!=nil||len(raw)>16384{return unavailable,ErrUnavailable}
    final,err:=file.Stat();leaf,leafErr:=os.Lstat(path);if err!=nil||leafErr!=nil||!os.SameFile(actual,final)||!os.SameFile(final,leaf)||leaf.Mode()&os.ModeSymlink!=0||final.Mode().Perm()&0077!=0||final.Size()!=actual.Size()||!final.ModTime().Equal(actual.ModTime())||!protectedParents(path){return unavailable,ErrUnavailable}
    // Repeated fields can otherwise override a human-reviewed decision.
    keys:=map[string]bool{};tokens:=json.NewDecoder(bytes.NewReader(raw));token,err:=tokens.Token();if err!=nil||token!=json.Delim('{'){return unavailable,ErrUnavailable}
    for tokens.More(){token,err=tokens.Token();key,ok:=token.(string);if err!=nil||!ok||keys[key]{return unavailable,ErrUnavailable};keys[key]=true;var value json.RawMessage;if tokens.Decode(&value)!=nil{return unavailable,ErrUnavailable}
        switch key{case "schema_version","source_sha256","api_image","origin","schema","approved_at","expires_at","evidence_sha256","evidence_ref","approved","purpose","deployment_manifest_sha256":
            trimmed:=bytes.TrimSpace(value);if len(trimmed)==0||trimmed[0]=='{'||trimmed[0]=='['||bytes.Equal(trimmed,[]byte("null")){return unavailable,ErrUnavailable}
        case "limits":if !strictLimits(value){return unavailable,ErrUnavailable}
        default:return unavailable,ErrUnavailable}
    }
    if token,err=tokens.Token();err!=nil||token!=json.Delim('}'){return unavailable,ErrUnavailable}
    var approval Approval;decoder:=json.NewDecoder(bytes.NewReader(raw));decoder.DisallowUnknownFields()
    if decoder.Decode(&approval)!=nil{return unavailable,ErrUnavailable};var trailing any;if decoder.Decode(&trailing)!=io.EOF{return unavailable,ErrUnavailable}
    if !approval.Approved||approval.SchemaVersion!=1||approval.Schema!=release.Schema||approval.SourceSHA256!=release.SourceSHA256||approval.APIImage!=release.APIImage||approval.Origin!=release.Origin||approval.EvidenceRef!=evidence||!hashPattern.MatchString(approval.EvidenceSHA256)||approval.DeploymentManifestSHA256!=release.DeploymentManifestSHA256||approval.Limits!=release.Limits||release.Limits.Connected!=200||release.Limits.Waiting!=100||release.Limits.Calls!=25{return unavailable,ErrUnavailable}
    maximum:=24*time.Hour
    if release.Stage=="validation"{if approval.Purpose!="validation"{return unavailable,ErrUnavailable};maximum=2*time.Hour}else if release.Stage!="cohort"&&release.Stage!="public"||approval.Purpose!="launch"{return unavailable,ErrUnavailable}
    if approval.ApprovedAt.IsZero()||approval.ApprovedAt.After(now)||!now.Before(approval.ExpiresAt)||!approval.ExpiresAt.After(approval.ApprovedAt)||approval.ExpiresAt.Sub(approval.ApprovedAt)>maximum{return unavailable,ErrUnavailable}
    return approval,ctx.Err()
}

func protectedParents(path string)bool{
    if !filepath.IsAbs(path)||filepath.Clean(path)!=path{return false}
    for parent:=filepath.Dir(path);;parent=filepath.Dir(parent){
        info,err:=os.Lstat(parent);if err!=nil||!info.IsDir()||info.Mode()&os.ModeSymlink!=0{return false}
        // Sticky temporary roots are permitted ancestors for isolated
        // test directories; the containing private directory must still be
        // non-writable to group/others. Deployment uses a protected /run path.
        if info.Mode().Perm()&0022!=0&&(info.Mode()&os.ModeSticky==0||parent==filepath.Dir(path)){return false}
        if parent==filepath.Dir(parent){break}
    };return true
}
func strictLimits(raw []byte)bool{
    decoder:=json.NewDecoder(bytes.NewReader(raw));token,err:=decoder.Token();if err!=nil||token!=json.Delim('{'){return false};seen:=map[string]bool{}
    for decoder.More(){token,err=decoder.Token();key,ok:=token.(string);if err!=nil||!ok||seen[key]||(key!="connected"&&key!="waiting"&&key!="calls"){return false};seen[key]=true;var value int;if decoder.Decode(&value)!=nil{return false}}
    token,err=decoder.Token();return err==nil&&token==json.Delim('}')&&len(seen)==3
}
