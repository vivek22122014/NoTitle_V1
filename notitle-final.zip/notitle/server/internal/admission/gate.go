// Package admission coordinates deliberate operator admission changes. It does
// not own live interactions or authorize a payment; those remain in their
// existing transaction/coordinator boundaries.
package admission

import (
    "context"
    "errors"
    "sync"
    "sync/atomic"
    "time"
)

var (
    ErrInvalid=errors.New("invalid admission action")
    ErrUnavailable=errors.New("admission prerequisites unavailable")
)
type Owner interface {
    ChangeAdmission(context.Context,bool,time.Time)error
    FailClosed()
}
type Options struct {
    Owner Owner
    Closed bool
    Ready func(context.Context)error
    Approval func(context.Context,string)error
    ValidationExpiry func()time.Time
    Now func()time.Time
}
type State struct { Closed bool `json:"closed"`; Deadline *time.Time `json:"deadline,omitempty"` }
type Gate struct { options Options;mu sync.Mutex;closed atomic.Bool;deadline time.Time;validationUntil time.Time }
func New(options Options)*Gate {
    if options.Now==nil{options.Now=time.Now}
    g:=&Gate{options:options};g.closed.Store(options.Closed)
    return g
}
func(g *Gate)Closed()bool{return g.closed.Load()}
func(g *Gate)State()State{g.mu.Lock();defer g.mu.Unlock();out:=State{Closed:g.closed.Load()};if !g.deadline.IsZero(){v:=g.deadline;out.Deadline=&v};return out}
func(g *Gate)Ready(ctx context.Context)error{if ctx.Err()!=nil||g.closed.Load(){return ErrUnavailable};return nil}
// Change is called only after a private owner/MFA session has passed a fresh
// transactional role check and durable audit. Open requires the current
// runtime prerequisites and the operator-reviewed evidence for this artifact.
func(g *Gate)Change(ctx context.Context,action,evidence string,seconds int)error {
    g.mu.Lock();defer g.mu.Unlock()
    if ctx.Err()!=nil||g.options.Owner==nil{return ErrUnavailable}
    now:=g.options.Now().UTC()
    switch action {
    case "open":
        if seconds!=0||!ValidEvidenceRef(evidence){return ErrInvalid}
        if g.options.Ready==nil||g.options.Approval==nil||g.options.Ready(ctx)!=nil||g.options.Approval(ctx,evidence)!=nil{return ErrUnavailable}
        expiry:=time.Time{};if g.options.ValidationExpiry!=nil{expiry=g.options.ValidationExpiry();if !expiry.IsZero()&&!now.Before(expiry){return ErrUnavailable}}
        if !g.closed.Load(){g.validationUntil=expiry;return nil}
        if !g.deadline.IsZero()&&now.Before(g.deadline){return ErrUnavailable}
        if err:=g.options.Owner.ChangeAdmission(ctx,false,time.Time{});err!=nil{g.options.Owner.FailClosed();return ErrUnavailable}
        g.closed.Store(false);g.deadline=time.Time{};g.validationUntil=expiry
        return nil
    case "drain":
        if seconds<0||seconds>120||evidence!=""{return ErrInvalid}
        deadline:=now.Add(time.Duration(seconds)*time.Second)
        if !g.deadline.IsZero()&&deadline.After(g.deadline){deadline=g.deadline}
        // Checkout closes before the actor command is submitted. If it cannot
        // be delivered, latch owner authorization closed as the safe fallback.
        g.closed.Store(true);g.deadline=deadline
        if err:=g.options.Owner.ChangeAdmission(ctx,true,deadline);err!=nil{g.options.Owner.FailClosed();return ErrUnavailable}
        return nil
    default:return ErrInvalid
    }
}

// Validation windows are bounded permissions for controlled prelaunch checks.
// Their expiration closes admission and ends interactions without waiting for
// another operator request. Ordinary launch permits are checked only on open.
func(g *Gate)Run(ctx context.Context){ticker:=time.NewTicker(time.Second);defer ticker.Stop();for{select{case<-ctx.Done():return;case<-ticker.C:work,cancel:=context.WithTimeout(ctx,2*time.Second);g.expireValidation(work);cancel()}}}
func(g *Gate)expireValidation(ctx context.Context){
    g.mu.Lock();defer g.mu.Unlock();now:=g.options.Now().UTC()
    if g.closed.Load()||g.validationUntil.IsZero()||now.Before(g.validationUntil){return}
    g.closed.Store(true);g.deadline=now
    if g.options.Owner==nil{return};if g.options.Owner.ChangeAdmission(ctx,true,now)!=nil{g.options.Owner.FailClosed()}
}
