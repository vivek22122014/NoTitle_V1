package admission

import (
    "context"
    "errors"
    "testing"
    "time"
)
type fakeOwner struct{calls int;closed,failed bool;deadline time.Time;err error;before func()}
func(f *fakeOwner)ChangeAdmission(_ context.Context,closed bool,deadline time.Time)error{if f.before!=nil{f.before()};f.calls++;f.closed=closed;f.deadline=deadline;return f.err}
func(f *fakeOwner)FailClosed(){f.failed=true}
func TestAdmissionOpenRequiresFreshEvidenceAndRuntime(t *testing.T){
    owner:=&fakeOwner{};ready,approved:=false,false
    gate:=New(Options{Owner:owner,Closed:true,Ready:func(context.Context)error{if !ready{return ErrUnavailable};return nil},Approval:func(context.Context,string)error{if !approved{return ErrUnavailable};return nil}})
    for i:=0;i<2;i++{if !errors.Is(gate.Change(context.Background(),"open","reviewed_release",0),ErrUnavailable)||!gate.Closed()||owner.calls!=0{t.Fatal("opened without both prerequisites")};ready=true}
    approved=true;if err:=gate.Change(context.Background(),"open","reviewed_release",0);err!=nil||gate.Closed()||owner.closed{t.Fatal("reviewed launch failed",err)}
}
func TestDrainClosesCheckoutBeforeActorAndCannotExtendDeadline(t *testing.T){
    now:=time.Date(2026,10,9,0,0,0,0,time.UTC);owner:=&fakeOwner{};gate:=New(Options{Owner:owner,Now:func()time.Time{return now}})
    owner.before=func(){if !gate.Closed(){t.Fatal("checkout stayed open while drain queued")}}
    if err:=gate.Change(context.Background(),"drain","",120);err!=nil{t.Fatal(err)};deadline:=owner.deadline
    now=now.Add(time.Minute);if err:=gate.Change(context.Background(),"drain","",120);err!=nil||!owner.deadline.Equal(deadline){t.Fatal("retry extended announced drain")}
    owner.err=ErrUnavailable;if err:=gate.Change(context.Background(),"drain","",0);err==nil||!owner.failed||!gate.Closed(){t.Fatal("failed actor delivery left admission open")}
}
func TestDrainRejectsUnboundedWindow(t *testing.T){owner:=&fakeOwner{};gate:=New(Options{Owner:owner});for _,seconds:=range []int{-1,121}{if !errors.Is(gate.Change(context.Background(),"drain","",seconds),ErrInvalid)||owner.calls!=0{t.Fatal("unbounded drain")}}}

func TestValidationExpiryAutomaticallyDrainsButLaunchDoesNot(t *testing.T){
 for _,validation:=range []bool{true,false}{
  now:=time.Date(2026,10,9,0,0,0,0,time.UTC);expires:=now.Add(time.Hour);owner:=&fakeOwner{}
  gate:=New(Options{Owner:owner,Closed:true,Now:func()time.Time{return now},Ready:func(context.Context)error{return nil},Approval:func(context.Context,string)error{return nil},ValidationExpiry:func()time.Time{if validation{return expires};return time.Time{}}})
  if err:=gate.Change(context.Background(),"open","reviewed_release",0);err!=nil{t.Fatal(err)}
  now=expires;gate.expireValidation(context.Background())
  if gate.Closed()!=validation||owner.closed!=validation{t.Fatal("validation and ordinary launch expiry were not distinguished")}
 }
}
