package friendtypes

import (
 "encoding/json"
 "strings"
 "testing"
)

func TestPrivateFriendRecordsNeverSerialize(t *testing.T) {
 for _,value := range []any{Subject{},Guard{},Relation{},Snapshot{},Mutation{}} {
  if _,err:=json.Marshal(value);err==nil { t.Fatalf("private %T serialized",value) }
 }
}
func TestRelationshipReferenceIsBounded(t *testing.T) {
 for _,value:=range []string{strings.Repeat("a",16),strings.Repeat("a",128),"01234567-89ab-cdef-0123-456789abcdef"} {
  if !ValidRef(value) { t.Fatal("valid opaque reference rejected") }
 }
 for _,value:=range []string{"",strings.Repeat("a",15),strings.Repeat("a",129),"../../another_user", "relationship?token=x","ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰ"} {
  if ValidRef(value) { t.Fatal("invalid opaque reference accepted") }
 }
}
