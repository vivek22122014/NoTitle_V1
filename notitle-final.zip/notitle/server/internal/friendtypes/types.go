// Package friendtypes contains shared friendship contracts. Private subjects,
// authorization snapshots and persistence work must never cross the peer wire.
package friendtypes

import (
 "context"
 "errors"
 "regexp"
 "time"

 "notitle/internal/identity"
)

const (
 MaxFriendsPerIdentity = 100
 MaxLocalRelationships = 20000
 MaxPendingRequests = 200
 MaxInvitations = 100
 InvitationTTL = 30 * time.Second
 MutationLease = 30 * time.Second
)

type Error struct { Code string; Message string; Retryable bool }
func (e *Error) Error() string { return e.Code }
var (
 ErrNotFound = &Error{"NOT_FOUND", "This connection is not available.", false}
 ErrInvalid = &Error{"INVALID_REQUEST", "Check the connection request and try again.", false}
 ErrUnauthorized = &Error{"AUTHENTICATION_REQUIRED", "Your session has ended. Sign in or start again.", false}
 ErrUnavailable = &Error{"NOT_AVAILABLE", "This connection is not available right now.", true}
 ErrStale = &Error{"STALE_EPOCH", "This conversation has ended or changed.", false}
 ErrCapacity = &Error{"CAPACITY_REACHED", "Your connection limit has been reached.", false}
 ErrConflict = &Error{"CONFLICT", "This connection has changed. Refresh and try again.", false}
 ErrBusy = &Error{"BUSY", "This connection is not available right now.", true}
)
func PublicError(err error) *Error { var value *Error; if errors.As(err,&value) { return value }; return ErrUnavailable }

type Subject struct { Kind identity.Kind; ID string; Generation int64 }
func (Subject) MarshalJSON() ([]byte,error) { return nil,errors.New("private friend subject cannot be serialized") }
type Guard struct { Principal identity.Principal; Fence uint64 }
func (Guard) MarshalJSON() ([]byte,error) { return nil,errors.New("private friend guard cannot be serialized") }

// Relation is a durable, caller-oriented hydration record. Ref lookup MUST be
// scoped to the authenticated endpoint; possession alone is never authority.
type Relation struct {
 Ref string
 Self Subject
 Peer Subject
 PeerDisplayName string
 PeerRevision int64
 CreatedAt time.Time
}
func (Relation) MarshalJSON() ([]byte,error) { return nil,errors.New("private friend relation cannot be serialized") }
type Snapshot struct { Revision int64; Relations []Relation }
func (Snapshot) MarshalJSON() ([]byte,error) { return nil,errors.New("private friend snapshot cannot be serialized") }

type Presence string
const (
 Offline Presence = "offline"
 Online Presence = "online"
 Busy Presence = "busy"
)
type View struct {
 Ref string `json:"ref"`
 DisplayName string `json:"display_name"`
 CreatedAt time.Time `json:"created_at"`
 Durable bool `json:"durable"`
 Pending bool `json:"pending"`
 Presence Presence `json:"presence"`
}
type RequestView struct {
 Ref string `json:"request_ref"`
 Direction string `json:"direction"`
}
type InvitationView struct {
 Ref string `json:"invitation_ref"`
 FriendRef string `json:"friend_ref"`
 Kind string `json:"kind"`
 ExpiresAt time.Time `json:"expires_at"`
 DisplayName string `json:"display_name"`
 Direction string `json:"direction"`
}

// Mutation is frozen by the owner after affirmative consent, or when removal
// immediately hides a relation. Session guards and account friend revisions
// are rechecked under ordered row locks. A stale revision is terminal; retries
// must never refresh it and thereby resurrect consent withdrawn by Remove.
type Mutation struct {
 Ref string
 LeaseID string
 A Subject
 B Subject
 AGuard identity.Guard
 BGuard identity.Guard
 ARevision int64
 BRevision int64
 AConsentAt time.Time
 BConsentAt time.Time
 CreatedAt time.Time
 Version uint64
 Remove bool
 // Promotion carries an already accepted guest relation after both endpoints
 // became accounts. It preserves consent across logout; the repository checks
 // active account status, immutable friendship revisions and safety; password
 // rotation or logout does not revoke existing accepted consent.
 Promotion bool
}
func (Mutation) MarshalJSON() ([]byte,error) { return nil,errors.New("private friend mutation cannot be serialized") }

// All methods run bounded in-memory work in the single owner. Database work
// stays outside. ListFriends merges current local state with fenced hydration.
// Removal hides presence, cancels invitations and ends a friend interaction
// before external persistence. Tombstones prevent old snapshots resurrecting it.
// Finish returning false after a successful insert requires exact Ref/pair
// compensation. Its lease remains pinned until compensation acknowledges;
// Reject is for permanent generation/revision/session rejection, not outages.
type Owner interface {
 AuthFence(context.Context) (uint64,error)
 ListFriends(context.Context,Guard,Snapshot) ([]View,error)
 PrepareFriendRemove(context.Context,Guard,string,*Relation) (Mutation,error)
 FinishFriendMutation(context.Context,string,bool) (bool,error)
 FinishFriendCompensation(context.Context,string,bool) error
 RejectFriendMutation(context.Context,string) error
 ClaimFriendMutations(context.Context,int) ([]Mutation,error)
}

var opaqueRef = regexp.MustCompile(`^[A-Za-z0-9_-]{16,128}$`)
func ValidRef(value string) bool { return opaqueRef.MatchString(value) }
