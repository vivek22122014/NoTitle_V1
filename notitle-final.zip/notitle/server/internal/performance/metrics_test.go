package performance

import (
    "sync"
    "testing"
    "time"
)
func TestProcessingHistogramCountsDisjointBoundariesAndOverflow(t *testing.T){
    r:=New();for _,duration:=range []time.Duration{time.Millisecond,100*time.Millisecond,time.Second,time.Second+1}{r.API(duration)}
    v:=r.Snapshot().API;if v.Samples!=4||v.Buckets[0]!=1||v.Buckets[5]!=1||v.Buckets[8]!=1||v.Buckets[9]!=1{t.Fatal("boundary or overflow observations changed",v)}
    snapshot:=r.Snapshot();snapshot.API.Buckets[0]=900;if r.Snapshot().API.Buckets[0]!=1{t.Fatal("snapshot mutated aggregate state")}
}
func TestProcessingCounterIsRaceSafeAndContainsNoDynamicLabels(t *testing.T){r:=New();var workers sync.WaitGroup;for i:=0;i<10;i++{workers.Add(1);go func(){defer workers.Done();for n:=0;n<100;n++{r.Message(time.Millisecond)}}()};workers.Wait();v:=r.Export();if v.Server.Message.Samples!=1000||v.Server.Message.Scope!="message_owner_processing"||v.SampledAt.Before(v.WindowStartedAt)||v.Process.Goroutines<1{t.Fatal("incomplete private aggregate export")}}
