// Package performance records fixed bounded process-local timing histograms.
// It accepts no paths, account IDs, peer IDs or user-controlled metric labels.
package performance

import (
    "runtime"
    "sync"
    "time"
)
type Histogram struct {Samples uint64 `json:"samples"`;Buckets [10]uint64 `json:"buckets"`;Scope string `json:"scope"`}
type Snapshot struct {API Histogram `json:"api"`;Message Histogram `json:"message"`;Match Histogram `json:"match"`}
type Export struct {SampledAt time.Time `json:"sampled_at"`;WindowStartedAt time.Time `json:"window_started_at"`;Server Snapshot `json:"server"`;Process Process `json:"process"`}
type Process struct {GoHeapBytes uint64 `json:"go_heap_bytes"`;Goroutines int `json:"goroutines"`}
type Recorder struct {mu sync.Mutex;value Snapshot;startedAt time.Time}
func New()*Recorder{return &Recorder{startedAt:time.Now().UTC(),value:Snapshot{API:Histogram{Scope:"ordinary_api_server"},Message:Histogram{Scope:"message_owner_processing"},Match:Histogram{Scope:"available_candidate_to_commit_upper_bound"}}}}
// Buckets are disjoint upper bounds 1,5,10,25,50,100,250,300,1000,+Inf ms.
// A percentile in the last bucket is unknown, never reported as 1000ms.
func observe(h *Histogram,d time.Duration){i:=9;for n,b:=range []time.Duration{time.Millisecond,5*time.Millisecond,10*time.Millisecond,25*time.Millisecond,50*time.Millisecond,100*time.Millisecond,250*time.Millisecond,300*time.Millisecond,time.Second}{if d<=b{i=n;break}};h.Samples++;h.Buckets[i]++}
func(r *Recorder)API(d time.Duration){if r==nil{return};r.mu.Lock();defer r.mu.Unlock();observe(&r.value.API,d)}
func(r *Recorder)Message(d time.Duration){if r==nil{return};r.mu.Lock();defer r.mu.Unlock();observe(&r.value.Message,d)}
func(r *Recorder)Match(d time.Duration){if r==nil{return};r.mu.Lock();defer r.mu.Unlock();observe(&r.value.Match,d)}
func(r *Recorder)Snapshot()Snapshot{r.mu.Lock();defer r.mu.Unlock();return r.value}
func(r *Recorder)Export()Export{var memory runtime.MemStats;runtime.ReadMemStats(&memory);return Export{SampledAt:time.Now().UTC(),WindowStartedAt:r.startedAt,Server:r.Snapshot(),Process:Process{GoHeapBytes:memory.HeapAlloc,Goroutines:runtime.NumGoroutine()}}}
