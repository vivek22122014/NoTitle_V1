package identityruntime

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"testing"

	"notitle/internal/identity"
)

type fixture struct { databaseErr, replayErr, applyErr error; applied int }
func (f *fixture) Ready(context.Context) error { return f.databaseErr }
func (f *fixture) Replay(ctx context.Context, apply func(context.Context,identity.Tombstone) error) error {
	if f.replayErr != nil { return f.replayErr }; return apply(ctx, identity.Tombstone{})
}
func (f *fixture) ApplyTombstone(context.Context, identity.Tombstone) error { f.applied++; return f.applyErr }
func (f *fixture) RetryTombstones(context.Context,int) error { return nil }
func (f *fixture) PruneSessions(context.Context,int) error { return nil }

func TestIdentityRemainsClosedUntilDeletionReplayCommits(t *testing.T) {
	for _, failure := range []string{"database", "journal", "apply", "none"} {
		t.Run(failure, func(t *testing.T) {
			f := &fixture{}
			err := errors.New("injected")
			switch failure { case "database": f.databaseErr=err; case "journal": f.replayErr=err; case "apply": f.applyErr=err }
			r := New(f,f,f,f,slog.New(slog.NewTextHandler(io.Discard,nil)))
			if r.Ready(context.Background()) == nil { t.Fatal("opened before replay") }
			result := r.initialize(context.Background())
			if failure == "none" {
				if result != nil || r.Ready(context.Background()) != nil || f.applied != 1 { t.Fatal("successful replay did not open gate") }
			} else if result == nil || r.Ready(context.Background()) == nil { t.Fatal("failed replay opened gate") }
		})
	}
}
