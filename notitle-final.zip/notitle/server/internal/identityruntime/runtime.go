// Package identityruntime keeps identity routes closed until independent
// deletion tombstones have been applied to the current database after startup.
package identityruntime

import (
	"context"
	"errors"
	"log/slog"
	"sync/atomic"
	"time"

	"notitle/internal/identity"
)

type Database interface { Ready(context.Context) error }
type Journal interface { Replay(context.Context, func(context.Context, identity.Tombstone) error) error }
type Store interface { ApplyTombstone(context.Context, identity.Tombstone) error }
type Maintenance interface {
	RetryTombstones(context.Context, int) error
	PruneSessions(context.Context, int) error
}
type Runtime struct {
	database Database
	journal Journal
	store Store
	service Maintenance
	logger *slog.Logger
	ready atomic.Bool
}
func New(db Database, journal Journal, store Store, service Maintenance, logger *slog.Logger) *Runtime {
	return &Runtime{database:db, journal:journal, store:store, service:service, logger:logger}
}
func (r *Runtime) Ready(ctx context.Context) error {
	if ctx.Err() != nil || !r.ready.Load() { return errors.New("identity initialization incomplete") }
	return nil
}
func (r *Runtime) initialize(ctx context.Context) error {
	probe, cancel := context.WithTimeout(ctx, 5*time.Second)
	err := r.database.Ready(probe)
	cancel()
	if err != nil { return err }
	if err := r.journal.Replay(ctx, r.store.ApplyTombstone); err != nil { return err }
	if ctx.Err() != nil { return ctx.Err() }
	r.ready.Store(true)
	return nil
}
func (r *Runtime) Run(ctx context.Context) {
	defer r.ready.Store(false)
	for {
		if r.initialize(ctx) == nil { break }
		if ctx.Err() != nil { return }
		r.logger.Warn("identity_initialization_pending")
		timer := time.NewTimer(5*time.Second)
		select { case <-ctx.Done(): timer.Stop(); return; case <-timer.C: }
	}
	r.logger.Info("identity_deletion_replay_complete")
	ticker := time.NewTicker(time.Minute)
	defer ticker.Stop()
	for {
		work, cancel := context.WithTimeout(ctx, 30*time.Second)
		if err := r.service.RetryTombstones(work, 100); err != nil && ctx.Err() == nil { r.logger.Warn("identity_tombstone_retry_pending") }
		if err := r.service.PruneSessions(work, 500); err != nil && ctx.Err() == nil { r.logger.Warn("identity_session_maintenance_pending") }
		cancel()
		select { case <-ctx.Done(): return; case <-ticker.C: }
	}
}
