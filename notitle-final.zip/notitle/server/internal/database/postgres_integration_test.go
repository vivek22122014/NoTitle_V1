package database

import (
	"context"
	"errors"
	"os"
	"sort"
	"strings"
	"testing"
	"time"

	"github.com/jackc/pgx/v5/pgconn"
	"notitle/internal/config"
)

// Run against the isolated Compose database after migration, using the runtime
// role. These tests never create/drop schema or mutate business data.
func integrationConfig(t *testing.T) config.DatabaseConfig {
	t.Helper()
	raw := strings.TrimSpace(os.Getenv("TEST_DATABASE_URL"))
	path := strings.TrimSpace(os.Getenv("TEST_DATABASE_URL_FILE"))
	if raw != "" && path != "" {
		t.Fatal("use only one integration database secret source")
	}
	if path != "" {
		data, err := os.ReadFile(path)
		if err != nil {
			t.Fatal("integration database secret file cannot be read")
		}
		raw = strings.TrimSpace(string(data))
	}
	if raw == "" {
		if os.Getenv("REQUIRE_DATABASE_INTEGRATION") == "1" {
			t.Fatal("database integration is required but no test database was configured")
		}
		t.Skip("integration database not configured; run scripts/db-check.sh")
	}
	return config.DatabaseConfig{
		URL: raw, MaxConns: 2, MinConns: 0,
		MaxConnLifetime: time.Minute, MaxConnIdleTime: time.Minute,
		HealthCheckPeriod: time.Minute, ConnectTimeout: 5*time.Second,
		ReadinessTimeout: time.Second,
	}
}

func TestRuntimeDatabaseReadyAndRestricted(t *testing.T) {
	cfg := integrationConfig(t)
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	pool, err := Open(ctx, cfg)
	if err != nil {
		t.Fatal(err)
	}
	defer pool.Close()
	if err := pool.Ready(ctx); err != nil {
		t.Fatal(err)
	}
	if got := pool.Raw().Config().MaxConns; got != 2 {
		t.Fatalf("pool maximum = %d", got)
	}
	var timezone, statementTimeout string
	if err := pool.Raw().QueryRow(ctx, "SELECT current_setting('TimeZone'), current_setting('statement_timeout')").Scan(&timezone, &statementTimeout); err != nil {
		t.Fatal("cannot inspect database session settings")
	}
	if timezone != "UTC" || statementTimeout != "5s" {
		t.Fatal("database session safety settings not applied")
	}
	// Transactions always roll back, including if an incorrect role permits DDL.
	tx, err := pool.Raw().Begin(ctx)
	if err != nil {
		t.Fatal("cannot start privilege-check transaction")
	}
	defer tx.Rollback(context.Background())
	_, err = tx.Exec(ctx, "CREATE TABLE notitle.phase1_forbidden_ddl_check (id integer)")
	var pgErr *pgconn.PgError
	if !errors.As(err, &pgErr) || pgErr.Code != "42501" {
		t.Fatal("runtime role was not denied schema DDL")
	}
}

func TestDatabaseCanceledReadiness(t *testing.T) {
	cfg := integrationConfig(t)
	pool, err := Open(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	defer pool.Close()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err := pool.Ready(ctx); !errors.Is(err, ErrUnavailable) {
		t.Fatalf("canceled readiness = %v", err)
	}
}

func TestParseErrorDoesNotExposeCredentials(t *testing.T) {
	cfg := config.DatabaseConfig{
		URL: "postgres://user:SECRET%xx@localhost/db", MaxConns: 8,
		MaxConnLifetime: time.Minute, MaxConnIdleTime: time.Minute,
		HealthCheckPeriod: time.Minute, ConnectTimeout: time.Second,
	}
	_, err := Open(context.Background(), cfg)
	if !errors.Is(err, ErrConfiguration) || strings.Contains(err.Error(), "SECRET") {
		t.Fatal("driver parse error was not safely classified")
	}
}

func TestApplicationTablePrivilegesAreExplicitAndLeastPrivilege(t *testing.T) {
    cfg := integrationConfig(t)
    ctx,cancel := context.WithTimeout(context.Background(),10*time.Second)
    defer cancel()
    pool,err := Open(ctx,cfg)
    if err != nil { t.Fatal(err) }
    defer pool.Close()
    if err := pool.Ready(ctx); err != nil { t.Fatal(err) }
    tables := []struct{ name string; update, remove bool }{
        {"accounts",true,false}, {"profiles",true,false}, {"professional_profiles",true,false},
        {"professional_interests",false,true}, {"sessions",true,true},
        {"consent_events",false,false}, {"deletion_jobs",true,false}, {"matchmaking_preferences",true,false},
        {"account_safety_state",true,false}, {"pending_safety_handoffs",false,true}, {"blocks",true,true}, {"reports",true,false},
        {"case_subject_refs",false,false}, {"report_evidence",false,false},
        {"moderation_actions",false,false},
        {"admin_sessions",true,true}, {"admin_audit",false,false}, {"friendships",false,true},
        {"purchase_orders",true,false}, {"payment_attempts",true,false}, {"premium_accounts",true,false},
        {"premium_lots",true,false}, {"premium_adjustments",false,false}, {"refunds",true,false},
        {"disputes",true,false}, {"billing_review_cases",true,false}, {"billing_review_actions",false,false},
        {"billing_dispute_actions",false,false}, {"payment_webhook_inbox",false,false},
        {"billing_jobs",true,false}, {"billing_reconciliation_watermarks",true,false}, {"settlement_reconciliation",false,false},
        {"grievances",true,false}, {"grievance_messages",true,false}, {"grievance_actions",false,false},
        {"operations_outbox",true,false}, {"rule_notice_deliveries",true,false},
        {"operational_alerts",true,false}, {"operational_alert_deliveries",true,false}, {"operational_metric_hours",true,false},
        {"privacy_hold_events",false,false}, {"privacy_holds",true,false}, {"privacy_jobs",true,false},
    }
    for _, table := range tables {
        var owner string
        var read,insert,update,remove,truncate,trigger bool
        err := pool.Raw().QueryRow(ctx, `SELECT tableowner,
            has_table_privilege(current_user,'notitle.'||tablename,'SELECT'),
            has_table_privilege(current_user,'notitle.'||tablename,'INSERT'),
            has_table_privilege(current_user,'notitle.'||tablename,'UPDATE'),
            has_table_privilege(current_user,'notitle.'||tablename,'DELETE'),
            has_table_privilege(current_user,'notitle.'||tablename,'TRUNCATE'),
            has_table_privilege(current_user,'notitle.'||tablename,'TRIGGER')
            FROM pg_tables WHERE schemaname='notitle' AND tablename=$1`,table.name).Scan(&owner,&read,&insert,&update,&remove,&truncate,&trigger)
        if err != nil { t.Fatalf("cannot inspect application table %s privileges",table.name) }
        if owner != "notitle_migrate" || !read || !insert || update != table.update || remove != table.remove || truncate || trigger {
            t.Fatalf("unexpected application table %s privileges",table.name)
        }
    }
}

func TestAdminCredentialsOnlyPermitRuntimeMFAReplayCounterUpdates(t *testing.T) {
    cfg:=integrationConfig(t)
    ctx,cancel:=context.WithTimeout(context.Background(),10*time.Second);defer cancel()
    pool,err:=Open(ctx,cfg);if err!=nil{t.Fatal(err)};defer pool.Close()
    if err=pool.Ready(ctx);err!=nil{t.Fatal(err)}
    var owner string;var read,insert,update,remove,truncate,trigger,references bool
    err=pool.Raw().QueryRow(ctx,`SELECT tableowner,
        has_table_privilege(current_user,'notitle.admin_users','SELECT'),
        has_table_privilege(current_user,'notitle.admin_users','INSERT'),
        has_table_privilege(current_user,'notitle.admin_users','UPDATE'),
        has_table_privilege(current_user,'notitle.admin_users','DELETE'),
        has_table_privilege(current_user,'notitle.admin_users','TRUNCATE'),
        has_table_privilege(current_user,'notitle.admin_users','TRIGGER'),
        has_table_privilege(current_user,'notitle.admin_users','REFERENCES')
        FROM pg_tables WHERE schemaname='notitle' AND tablename='admin_users'`).Scan(&owner,&read,&insert,&update,&remove,&truncate,&trigger,&references)
    if err!=nil||owner!="notitle_migrate"||!read||insert||update||remove||truncate||trigger||references{t.Fatal("operator identity table has excess runtime grants")}
    rows,err:=pool.Raw().Query(ctx,`SELECT column_name,has_column_privilege(current_user,'notitle.admin_users',column_name,'UPDATE') FROM information_schema.columns WHERE table_schema='notitle' AND table_name='admin_users' ORDER BY ordinal_position`)
    if err!=nil{t.Fatal("cannot inspect operator column grants")};defer rows.Close()
    count:=0;counter:=false
    for rows.Next(){var column string;var allowed bool;if err=rows.Scan(&column,&allowed);err!=nil{t.Fatal(err)};count++;if allowed!=(column=="last_counter"){t.Fatal("unexpected operator column update privilege",column)};if column=="last_counter"{counter=true}}
    if err=rows.Err();err!=nil||count!=9||!counter{t.Fatal("operator schema columns incomplete")}
}

func TestPhase9DurableInventoryExcludesOrdinaryChatsGuestsAndPendingInvitations(t *testing.T) {
    cfg:=integrationConfig(t)
    ctx,cancel:=context.WithTimeout(context.Background(),10*time.Second);defer cancel()
    pool,err:=Open(ctx,cfg);if err!=nil{t.Fatal(err)};defer pool.Close()
    expected:=[]string{"schema_version","accounts","profiles","professional_profiles","professional_interests","sessions","consent_events","deletion_jobs","matchmaking_preferences","account_safety_state","pending_safety_handoffs","blocks","reports","case_subject_refs","report_evidence","moderation_actions","legal_holds","admin_users","admin_sessions","admin_audit","friendships"}
    expected=append(expected,"premium_plans","purchase_orders","payment_attempts","premium_accounts","premium_lots","premium_adjustments","refunds","disputes","billing_review_cases","billing_review_actions","billing_dispute_actions","payment_webhook_inbox","billing_jobs","billing_reconciliation_watermarks","settlement_reconciliation")
    expected=append(expected,"legal_deadline_rules","grievances","grievance_messages","grievance_actions","operations_outbox","rule_notices","rule_notice_deliveries","operational_alerts","operational_alert_deliveries","operational_metric_hours","retention_policies","privacy_hold_events","privacy_holds","restricted_registration","privacy_jobs","privacy_purge_audit")
    sort.Strings(expected)
    rows,err:=pool.Raw().Query(ctx,`SELECT tablename FROM pg_tables WHERE schemaname='notitle' ORDER BY tablename`);if err!=nil{t.Fatal("cannot inspect durable schema")};defer rows.Close()
    actual:=[]string{};for rows.Next(){var name string;if err=rows.Scan(&name);err!=nil{t.Fatal(err)};actual=append(actual,name)}
    if rows.Err()!=nil||strings.Join(actual,",")!=strings.Join(expected,","){t.Fatal("unexpected durable table; review ordinary-chat and guest retention boundary")}
    // This schema gate supplements safety integration's plaintext sentinel
    // inspections; it does not by itself prove that logs retain no content.
}

func TestBillingCatalogReadOnlyAndImmutableSnapshotBarriers(t *testing.T) {
    cfg:=integrationConfig(t);ctx,cancel:=context.WithTimeout(context.Background(),10*time.Second);defer cancel()
    pool,err:=Open(ctx,cfg);if err!=nil{t.Fatal(err)};defer pool.Close()
    if err=pool.Ready(ctx);err!=nil{t.Fatal(err)}
    var marker int;var owner string;var read,insert,update,remove,truncate,trigger,references bool
    err=pool.Raw().QueryRow(ctx,`SELECT version FROM notitle.schema_version`).Scan(&marker)
    if err!=nil||marker!=9{t.Fatal("operations/privacy readiness requires schema version 9")}
    err=pool.Raw().QueryRow(ctx,`SELECT tableowner,
        has_table_privilege(current_user,'notitle.premium_plans','SELECT'),
        has_table_privilege(current_user,'notitle.premium_plans','INSERT'),
        has_table_privilege(current_user,'notitle.premium_plans','UPDATE'),
        has_table_privilege(current_user,'notitle.premium_plans','DELETE'),
        has_table_privilege(current_user,'notitle.premium_plans','TRUNCATE'),
        has_table_privilege(current_user,'notitle.premium_plans','TRIGGER'),
        has_table_privilege(current_user,'notitle.premium_plans','REFERENCES')
        FROM pg_tables WHERE schemaname='notitle' AND tablename='premium_plans'`).Scan(&owner,&read,&insert,&update,&remove,&truncate,&trigger,&references)
    if err!=nil||owner!="notitle_migrate"||!read||insert||update||remove||truncate||trigger||references{t.Fatal("runtime can publish plans or alter approved catalog economics")}
    var columnWrite bool
    err=pool.Raw().QueryRow(ctx,`SELECT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema='notitle' AND table_name='premium_plans' AND (has_column_privilege(current_user,'notitle.premium_plans',column_name,'UPDATE') OR has_column_privilege(current_user,'notitle.premium_plans',column_name,'INSERT')))` ).Scan(&columnWrite)
    if err!=nil||columnWrite{t.Fatal("catalog column grant bypasses read-only policy")}
    var barriers int;var helperCallable bool
    err=pool.Raw().QueryRow(ctx,`SELECT count(*) FROM pg_trigger WHERE NOT tgisinternal AND tgenabled='O' AND ((tgname='premium_plan_immutable' AND tgrelid='notitle.premium_plans'::regclass) OR (tgname='purchase_order_immutable' AND tgrelid='notitle.purchase_orders'::regclass))`).Scan(&barriers)
    if err!=nil||barriers!=2{t.Fatal("immutable catalog and original order snapshots are not both guarded")}
    err=pool.Raw().QueryRow(ctx,`SELECT has_function_privilege(current_user,'notitle.billing_immutable_snapshot()','EXECUTE')`).Scan(&helperCallable)
    if err!=nil||helperCallable{t.Fatal("billing snapshot helper exposed as runtime RPC")}
}

func TestBillingFinancialIDsCannotBeResetAndHistoryCannotBeRewritten(t *testing.T) {
    cfg:=integrationConfig(t);ctx,cancel:=context.WithTimeout(context.Background(),10*time.Second);defer cancel()
    pool,err:=Open(ctx,cfg);if err!=nil{t.Fatal(err)};defer pool.Close()
    for _,sequence:=range []string{"premium_adjustments_id_seq","premium_lots_grant_sequence_seq","billing_jobs_id_seq","billing_review_actions_id_seq","billing_dispute_actions_id_seq"}{
        var usage,read,write bool
        err=pool.Raw().QueryRow(ctx,`SELECT has_sequence_privilege(current_user,'notitle.'||$1,'USAGE'),has_sequence_privilege(current_user,'notitle.'||$1,'SELECT'),has_sequence_privilege(current_user,'notitle.'||$1,'UPDATE')`,sequence).Scan(&usage,&read,&write)
        if err!=nil||!usage||!read||write{t.Fatal("financial sequence grants permit resetting IDs or block allocation",sequence)}
    }
    for _,probe:=range []string{
        `UPDATE notitle.premium_adjustments SET seconds=seconds WHERE false`,
        `DELETE FROM notitle.premium_adjustments WHERE false`,
        `UPDATE notitle.payment_webhook_inbox SET kind=kind WHERE false`,
        `DELETE FROM notitle.payment_webhook_inbox WHERE false`,
        `UPDATE notitle.settlement_reconciliation SET state=state WHERE false`,
        `DELETE FROM notitle.settlement_reconciliation WHERE false`,
        `UPDATE notitle.billing_review_actions SET reason=reason WHERE false`,
        `DELETE FROM notitle.billing_review_actions WHERE false`,
        `UPDATE notitle.billing_dispute_actions SET reason=reason WHERE false`,
        `DELETE FROM notitle.billing_dispute_actions WHERE false`,
    }{
        tx,e:=pool.Raw().Begin(ctx);if e!=nil{t.Fatal("cannot start immutable history probe")}
        _,e=tx.Exec(ctx,probe);_ =tx.Rollback(context.Background())
        var pgErr *pgconn.PgError
        if !errors.As(e,&pgErr)||pgErr.Code!="42501"{t.Fatal("runtime financial history mutation was not refused")}
    }
}

func TestBillingProviderAndBalanceUniquenessIncludesEnvironment(t *testing.T) {
    cfg:=integrationConfig(t);ctx,cancel:=context.WithTimeout(context.Background(),10*time.Second);defer cancel()
    pool,err:=Open(ctx,cfg);if err!=nil{t.Fatal(err)};defer pool.Close()
    for _,table:=range []struct{name string;keys []string}{
        {"premium_accounts",[]string{"account_id,environment"}},
        {"payment_attempts",[]string{"environment,payment_id"}},
        {"payment_webhook_inbox",[]string{"environment,event_key"}},
        {"disputes",[]string{"environment,provider_dispute_id"}},
        {"premium_lots",[]string{"environment,payment_id"}},
        {"purchase_orders",[]string{"environment,financial_subject,idempotency_key","environment,provider_order_id"}},
        {"refunds",[]string{"environment,provider_refund_id"}},
        {"billing_review_cases",[]string{"environment,kind,order_ref,payment_id"}},
        {"billing_reconciliation_watermarks",[]string{"environment,kind"}},
    }{
        rows,e:=pool.Raw().Query(ctx,`SELECT array_agg(a.attname::text ORDER BY key.ordinality)
            FROM pg_constraint c CROSS JOIN LATERAL unnest(c.conkey) WITH ORDINALITY AS key(attnum,ordinality)
            JOIN pg_attribute a ON a.attrelid=c.conrelid AND a.attnum=key.attnum
            WHERE c.conrelid=to_regclass($1) AND c.contype IN ('p','u') GROUP BY c.oid`,"notitle."+table.name)
        if e!=nil{t.Fatal("cannot inspect financial uniqueness",table.name)}
        found:=map[string]bool{}
        for rows.Next(){var names []string;if e=rows.Scan(&names);e!=nil{rows.Close();t.Fatal(e)};found[strings.Join(names,",")]=true}
        e=rows.Err();rows.Close();if e!=nil{t.Fatal(e)}
        for _,key:=range table.keys{if !found[key]{t.Fatal("financial uniqueness can mix sandbox and production or lose idempotency",table.name,key)}}
    }
}

func TestOperationsPoliciesAndPrivacyFunctionsEnforceRestrictedRoles(t *testing.T) {
    cfg:=integrationConfig(t);ctx,cancel:=context.WithTimeout(context.Background(),10*time.Second);defer cancel()
    pool,err:=Open(ctx,cfg);if err!=nil{t.Fatal(err)};defer pool.Close()
    for _,table:=range []string{"legal_deadline_rules","rule_notices","retention_policies","restricted_registration","privacy_purge_audit","legal_holds"}{
        var owner string;var read,write,columnWrite bool
        err=pool.Raw().QueryRow(ctx,`SELECT tableowner,
            has_table_privilege(current_user,'notitle.'||tablename,'SELECT'),
            has_table_privilege(current_user,'notitle.'||tablename,'INSERT,UPDATE,DELETE,TRUNCATE,TRIGGER,REFERENCES'),
            EXISTS(SELECT 1 FROM information_schema.columns c WHERE c.table_schema='notitle' AND c.table_name=$1
                AND (has_column_privilege(current_user,'notitle.'||c.table_name,c.column_name,'UPDATE') OR has_column_privilege(current_user,'notitle.'||c.table_name,c.column_name,'INSERT')))
            FROM pg_tables WHERE schemaname='notitle' AND tablename=$1`,table).Scan(&owner,&read,&write,&columnWrite)
        if err!=nil||owner!="notitle_migrate"||!read||write||columnWrite{t.Fatal("reviewed policy or restricted projection has excess runtime privileges",table)}
    }
    for _,function:=range []string{"notitle.privacy_scrub_account(uuid,text,timestamp with time zone)","notitle.privacy_execute_job(uuid,uuid,timestamp with time zone)","notitle.privacy_expire_security_audit(text,timestamp with time zone)","notitle.operations_expire_metadata(text,timestamp with time zone)"}{
        var definer,owner,path,runtime,public bool
        err=pool.Raw().QueryRow(ctx,`SELECT p.prosecdef,p.proowner=(SELECT oid FROM pg_roles WHERE rolname='notitle_migrate'),
            'search_path=pg_catalog'=ANY(p.proconfig),has_function_privilege(current_user,p.oid,'EXECUTE'),
            EXISTS(SELECT 1 FROM aclexplode(COALESCE(p.proacl,acldefault('f',p.proowner)))a WHERE a.grantee=0 AND a.privilege_type='EXECUTE')
            FROM pg_proc p WHERE p.oid=to_regprocedure($1)`,function).Scan(&definer,&owner,&path,&runtime,&public)
        if err!=nil||!definer||!owner||!path||!runtime||public{t.Fatal("privacy entrypoint owner, search path or execute grants are unsafe",function)}
    }
    var helper bool
    err=pool.Raw().QueryRow(ctx,`SELECT has_function_privilege(current_user,'notitle.protect_grievance_receipt()','EXECUTE')`).Scan(&helper)
    if err!=nil||helper{t.Fatal("grievance receipt trigger helper is an unnecessary runtime RPC")}
    for _,probe:=range []string{
        `INSERT INTO notitle.retention_policies(version,digest,document,approved,installed_at) SELECT 'forbidden',repeat('0',64),'{}'::jsonb,true,now() WHERE false`,
        `UPDATE notitle.legal_deadline_rules SET resolve_seconds=604800 WHERE false`,
        `DELETE FROM notitle.privacy_hold_events WHERE false`,
        `UPDATE notitle.grievance_actions SET reason=reason WHERE false`,
        `DELETE FROM notitle.restricted_registration WHERE false`,
        `DELETE FROM notitle.privacy_purge_audit WHERE false`,
        `UPDATE notitle.legal_holds SET created_at=created_at WHERE false`,
    }{
        tx,e:=pool.Raw().Begin(ctx);if e!=nil{t.Fatal("cannot begin operations role probe")}
        _,e=tx.Exec(ctx,probe);_ =tx.Rollback(context.Background());var pgErr *pgconn.PgError
        if !errors.As(e,&pgErr)||pgErr.Code!="42501"{t.Fatal("runtime bypasses reviewed privacy or immutable action boundary")}
    }
}
