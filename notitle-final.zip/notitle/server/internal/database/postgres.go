package database

import (
	"context"
	"errors"

	"github.com/jackc/pgx/v5/pgxpool"
	"notitle/internal/config"
)

var (
	ErrConfiguration = errors.New("database configuration is invalid")
	ErrUnavailable = errors.New("database is unavailable")
	ErrSchema = errors.New("database schema is not ready")
	ErrRole = errors.New("database runtime role is not restricted")
)

type Pool struct {
	pool *pgxpool.Pool
}

func Open(ctx context.Context, cfg config.DatabaseConfig) (*Pool, error) {
	if cfg.MaxConns < 1 || cfg.MaxConns > 20 || cfg.MinConns < 0 || cfg.MinConns > cfg.MaxConns || cfg.ConnectTimeout <= 0 || cfg.MaxConnLifetime <= 0 || cfg.MaxConnIdleTime <= 0 || cfg.HealthCheckPeriod <= 0 {
		return nil, ErrConfiguration
	}
	poolConfig, err := pgxpool.ParseConfig(cfg.URL)
	if err != nil {
		return nil, ErrConfiguration
	}
	poolConfig.MaxConns = cfg.MaxConns
	poolConfig.MinConns = cfg.MinConns
	poolConfig.MaxConnLifetime = cfg.MaxConnLifetime
	poolConfig.MaxConnIdleTime = cfg.MaxConnIdleTime
	poolConfig.HealthCheckPeriod = cfg.HealthCheckPeriod
	poolConfig.ConnConfig.ConnectTimeout = cfg.ConnectTimeout
	if poolConfig.ConnConfig.RuntimeParams == nil {
		poolConfig.ConnConfig.RuntimeParams = map[string]string{}
	}
	params := poolConfig.ConnConfig.RuntimeParams
	params["application_name"] = "notitle-api"
	params["timezone"] = "UTC"
	params["search_path"] = "pg_catalog,notitle"
	params["statement_timeout"] = "5000"
	params["lock_timeout"] = "3000"
	params["idle_in_transaction_session_timeout"] = "10000"
	// Keep startup independent of database availability. Connections are lazy;
	// readiness below verifies connectivity, schema, and least-privilege role.
	pool, err := pgxpool.NewWithConfig(ctx, poolConfig)
	if err != nil {
		return nil, ErrConfiguration
	}
	return &Pool{pool: pool}, nil
}

func (p *Pool) Ping(ctx context.Context) error {
	if err := p.pool.Ping(ctx); err != nil {
		return ErrUnavailable
	}
	return nil
}

func (p *Pool) Ready(ctx context.Context) error {
	if err := p.Ping(ctx); err != nil {
		return err
	}
	var valid bool
	err := p.pool.QueryRow(ctx, `SELECT count(*) = 1 AND COALESCE(min(version) = 9, false) FROM notitle.schema_version`).Scan(&valid)
	if err != nil || !valid {
		return ErrSchema
	}
	err = p.pool.QueryRow(ctx, `
		SELECT current_user = 'notitle_app'
			AND NOT rolsuper AND NOT rolcreatedb AND NOT rolcreaterole
			AND NOT rolreplication AND NOT rolbypassrls
			AND NOT has_database_privilege(current_user, current_database(), 'CREATE')
			AND NOT has_database_privilege(current_user, current_database(), 'TEMP')
			AND NOT has_schema_privilege(current_user, 'notitle', 'CREATE')
			AND NOT has_schema_privilege(current_user, 'public', 'CREATE')
			AND NOT EXISTS (SELECT 1 FROM pg_auth_members WHERE member = pg_roles.oid)
		FROM pg_roles WHERE rolname = current_user`).Scan(&valid)
	if err != nil || !valid {
		return ErrRole
	}
	return nil
}

func (p *Pool) Close() {
	p.pool.Close()
}
func (p *Pool) Raw() *pgxpool.Pool {
	return p.pool
}
