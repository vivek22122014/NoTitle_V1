module notitle

go 1.27.2

require (
	github.com/coder/websocket v1.8.15
	github.com/jackc/pgx/v5 v5.11.0
	golang.org/x/crypto v0.57.0
)
