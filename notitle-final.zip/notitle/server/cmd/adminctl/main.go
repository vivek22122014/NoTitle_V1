// adminctl is run interactively by an authorized operator on the private host.
// All secret inputs are private files; passwords/keys/DSNs are never flags.
package main

import (
    "bytes"
    "context"
    "encoding/json"
    "flag"
    "fmt"
    "io"
    "os"
    "path/filepath"
    "encoding/base64"
    "strings"
    "time"

    "github.com/jackc/pgx/v5/pgxpool"
    "notitle/internal/admin"
    "notitle/internal/identity"
)

func main(){if run()!=nil{fmt.Fprintln(os.Stderr,"Operator action failed; inspect private inputs, current generation and permissions. Do not assume a timed-out change failed.");os.Exit(1)}}
func run()error{
    action:=flag.String("action","provision","provision, manage, install-retention-policy or decrypt-evidence")
    policyFile:=flag.String("policy-file","","absolute reviewed retention manifest JSON")
    encryptedFile:=flag.String("encrypted-file","","private downloaded encrypted evidence file")
    outputFile:=flag.String("output-file","","new private decrypted JSON file")
    exportKeyFile:=flag.String("export-key-file","","private file containing one-time base64 export key")
    inputFile:=flag.String("input-file","","absolute path to private operator JSON")
    databaseFile:=flag.String("database-url-file","","absolute path to migration DSN secret")
    keyFile:=flag.String("mfa-key-file","","absolute path to separate base64 32-byte MFA key")
    enrollment:=flag.String("enrollment-file","","new absolute private authenticator enrollment file")
    flag.Parse()
    if flag.NArg()!=0{return admin.ErrInvalid}
    if *action=="decrypt-evidence"{return decryptEvidence(*encryptedFile,*exportKeyFile,*outputFile)}
    if *action!="provision"&&*action!="manage"&&*action!="install-retention-policy"{return admin.ErrInvalid}
    for _,path:=range []string{*inputFile,*databaseFile}{if !filepath.IsAbs(path)||filepath.Clean(path)!=path{return admin.ErrInvalid}}
    for _,path:=range []string{*keyFile,*enrollment}{if path!=""&&(!filepath.IsAbs(path)||filepath.Clean(path)!=path){return admin.ErrInvalid}}
    data,err:=admin.ReadPrivateFile(*inputFile,8192);if err!=nil{return err};defer clear(data)
    var in admin.ProvisionInput;var change admin.LifecycleInput;var policyAdmin admin.PolicyInstallInput
    dec:=json.NewDecoder(bytes.NewReader(data));dec.DisallowUnknownFields()
    var target any=&in;if *action=="manage"{target=&change};if *action=="install-retention-policy"{target=&policyAdmin;if !filepath.IsAbs(*policyFile)||filepath.Clean(*policyFile)!=*policyFile||*enrollment!=""{return admin.ErrInvalid}}
    if err=dec.Decode(target);err!=nil{return admin.ErrInvalid};if err=dec.Decode(new(any));err!=io.EOF{return admin.ErrInvalid}
    var key []byte
    if *keyFile==""||(*action=="provision"||change.Action=="reset_mfa")&&*enrollment==""{return admin.ErrInvalid};key,err=admin.ReadKey(*keyFile);if err!=nil{return err};defer clear(key)
    dsn,err:=admin.ReadPrivateFile(*databaseFile,8192);if err!=nil{return err};defer clear(dsn)
    ctx,cancel:=context.WithTimeout(context.Background(),30*time.Second);defer cancel()
    cfg,err:=pgxpool.ParseConfig(strings.TrimSpace(string(dsn)));if err!=nil{return admin.ErrInvalid}
    cfg.MaxConns=1;if cfg.ConnConfig.RuntimeParams==nil{cfg.ConnConfig.RuntimeParams=map[string]string{}};cfg.ConnConfig.RuntimeParams["statement_timeout"]="5000";cfg.ConnConfig.RuntimeParams["lock_timeout"]="3000"
    db,err:=pgxpool.NewWithConfig(ctx,cfg);if err!=nil{return admin.ErrUnavailable};defer db.Close()
    if *action=="install-retention-policy"{if err=admin.InstallRetentionPolicy(ctx,db,key,policyAdmin,*policyFile);err!=nil{return err};fmt.Println("Approved retention manifest installed with its exact immutable digest. Configure the matching protected host file and verify readiness; this command does not activate purging.");return nil}
    if *action=="manage"{if err=admin.ManageOperator(ctx,db,key,change,*enrollment);err!=nil{return err};fmt.Println("Operator change committed; prior sessions are revoked. Inspect the audited current generation before another change.");return nil}
    if err=admin.Provision(ctx,db,identity.NewArgon2Hasher(),key,in,*enrollment);err!=nil{return err}
    fmt.Println("Operator created. Import the private enrollment file into the appointed operator's authenticator, verify sign-in, then remove the input and enrollment files.")
    return nil
}

func decryptEvidence(encryptedFile,keyFile,outputFile string)error{
    for _,path:=range []string{encryptedFile,keyFile,outputFile}{if !filepath.IsAbs(path)||filepath.Clean(path)!=path{return admin.ErrInvalid}}
    encrypted,err:=admin.ReadPrivateFile(encryptedFile,(2<<20)+128);if err!=nil{return err};defer clear(encrypted)
    encoded,err:=admin.ReadPrivateFile(keyFile,128);if err!=nil{return err};defer clear(encoded)
    key,err:=base64.StdEncoding.Strict().DecodeString(strings.TrimSpace(string(encoded)));if err!=nil{return admin.ErrInvalid};defer clear(key)
    raw,err:=admin.DecryptEvidence(key,encrypted);if err!=nil{return err};defer clear(raw)
    out,err:=os.OpenFile(outputFile,os.O_WRONLY|os.O_CREATE|os.O_EXCL,0600);if err!=nil{return admin.ErrInvalid};saved:=false;defer func(){out.Close();if !saved{_ = os.Remove(outputFile)}}()
    if _,err=out.Write(raw);err!=nil{return admin.ErrUnavailable};if err=out.Sync();err!=nil{return admin.ErrUnavailable};saved=true
    fmt.Println("Evidence decrypted into the new private file. Apply the case retention deadline to exported copies and keys.");return nil
}
