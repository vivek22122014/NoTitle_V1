//go:build linux

package main

import (
 "context"
 "os"
 "os/exec"
 "strconv"
 "testing"
 "time"
)

func TestWatchdogHelper(t *testing.T){
 switch os.Getenv("NOTITLE_WATCHDOG_TEST_MODE"){
 case "target":time.Sleep(30*time.Second);os.Exit(0)
 case "watch":os.Args=[]string{"test","watchdog",os.Getenv("NOTITLE_TEST_PARENT_PID"),os.Getenv("NOTITLE_TEST_RELAY_PID")};watchdog();os.Exit(0)
 }
}
func TestIndependentWatchdogKillsBothChildrenWithoutHeartbeats(t *testing.T){
 ctx,cancel:=context.WithTimeout(context.Background(),6*time.Second);defer cancel()
 startTarget:=func()*exec.Cmd{cmd:=exec.CommandContext(ctx,os.Args[0],"-test.run=^TestWatchdogHelper$");cmd.Env=append(os.Environ(),"NOTITLE_WATCHDOG_TEST_MODE=target");if err:=cmd.Start();err!=nil{t.Fatal(err)};t.Cleanup(func(){_ =cmd.Process.Kill()});return cmd}
 supervisor,turn:=startTarget(),startTarget();read,write,err:=os.Pipe();if err!=nil{t.Fatal(err)};defer write.Close()
 watch:=exec.CommandContext(ctx,os.Args[0],"-test.run=^TestWatchdogHelper$");watch.Env=append(os.Environ(),"NOTITLE_WATCHDOG_TEST_MODE=watch","NOTITLE_TEST_PARENT_PID="+strconv.Itoa(supervisor.Process.Pid),"NOTITLE_TEST_RELAY_PID="+strconv.Itoa(turn.Process.Pid));watch.ExtraFiles=[]*os.File{read}
 if err=watch.Start();err!=nil{read.Close();t.Fatal(err)};read.Close();defer watch.Process.Kill();started:=time.Now();if _,err=write.Write([]byte{1});err!=nil{t.Fatal(err)}
 if err=watch.Wait();err==nil{t.Fatal("watchdog unexpectedly exited successfully")};if err=supervisor.Wait();err==nil{t.Fatal("stalled supervisor was not killed")};if err=turn.Wait();err==nil{t.Fatal("coturn child was not killed")};if time.Since(started)>4500*time.Millisecond||ctx.Err()!=nil{t.Fatal("watchdog exceeded shutdown budget")}
}
