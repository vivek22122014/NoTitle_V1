//go:build linux

// relay-supervisor is PID1 of the dedicated TURN container. It owns coturn,
// rotates authentication material on each boot and exposes private mTLS only.
package main

import (
 "context"
 "crypto/rand"
 "crypto/tls"
 "crypto/x509"
 "encoding/hex"
 "errors"
 "fmt"
 "io"
 "net"
 "net/http"
 "os"
 "os/exec"
 "os/signal"
 "path/filepath"
 "regexp"
 "strconv"
 "strings"
 "syscall"
 "time"
 "notitle/internal/audio"
 "notitle/internal/relay"
)

func main(){
 if len(os.Args)==4&&os.Args[1]=="watchdog"{watchdog();return}
 if err:=run();err!=nil{fmt.Fprintln(os.Stderr,"relay supervisor stopped; audio is unavailable");os.Exit(1)}
}
func watchdog(){
 parent,e1:=strconv.Atoi(os.Args[2]);child,e2:=strconv.Atoi(os.Args[3]);if e1!=nil||e2!=nil||parent<=0||child<=0{os.Exit(1)}
 file:=os.NewFile(3,"heartbeat");if file==nil{os.Exit(1)};defer file.Close()
 heartbeat:=make(chan bool,1)
 go func(){var b[1]byte;for{_,err:=io.ReadFull(file,b[:]);if err!=nil||b[0]!=1{heartbeat<-false;return};heartbeat<-true}}()
 timer:=time.NewTimer(3*time.Second);defer timer.Stop()
 kill:=func(){_ =syscall.Kill(child,syscall.SIGKILL);_ =syscall.Kill(parent,syscall.SIGKILL);os.Exit(1)}
 for{select{case ok:=<-heartbeat:if !ok{kill()};if !timer.Stop(){select{case<-timer.C:default:}};timer.Reset(3*time.Second);case<-timer.C:kill()}}
}
func env(name,fallback string)string{if value:=os.Getenv(name);value!=""{return value};return fallback}
func randomSecret()(string,error){var value[32]byte;if _,err:=rand.Read(value[:]);err!=nil{return "",err};return hex.EncodeToString(value[:]),nil}
func privateFile(path string)error{info,err:=os.Lstat(path);if err!=nil||!info.Mode().IsRegular()||info.Mode().Perm()&0077!=0{return errors.New("private file required")};return nil}
var domain=regexp.MustCompile(`^[a-zA-Z0-9][a-zA-Z0-9.-]{0,251}[a-zA-Z0-9]$`)
func run()error{
 if os.Getpid()!=1{return errors.New("supervisor must be container PID1")}
 token,err:=audio.LoadControlTokenFile(env("RELAY_CONTROL_TOKEN_FILE","/run/secrets/relay-control-token"));if err!=nil{return err}
 host:=os.Getenv("TURN_HOSTNAME");public:=net.ParseIP(os.Getenv("TURN_PUBLIC_IP"));local:=net.ParseIP(os.Getenv("TURN_RELAY_IP"))
 if !domain.MatchString(host)||public==nil||public.To4()==nil||!public.IsGlobalUnicast()||public.IsPrivate()||local==nil||local.To4()==nil{return errors.New("relay address configuration required")}
 control:=env("RELAY_CONTROL_ADDR","0.0.0.0:9443");controlHost,_,err:=net.SplitHostPort(control);if err!=nil||net.ParseIP(controlHost)==nil{return errors.New("control address must be literal")}
 allowHTTP:=os.Getenv("RELAY_ALLOW_LOOPBACK_HTTP")=="true"
 if allowHTTP&&controlHost!="127.0.0.1"&&controlHost!="::1"{return errors.New("cleartext control must be loopback")}
 if err=privateFile("/run/secrets/turn-key.pem");err!=nil{return err}
 if !allowHTTP{if err=privateFile(env("RELAY_CONTROL_KEY_FILE","/run/secrets/control-key.pem"));err!=nil{return err}}
 binary,err:=exec.LookPath("turnserver");if err!=nil{return err}
 versionCtx,cancel:=context.WithTimeout(context.Background(),2*time.Second);version,versionErr:=exec.CommandContext(versionCtx,binary,"--version").CombinedOutput();cancel()
 if versionErr!=nil||!regexp.MustCompile(`\b4\.18\.0\b`).Match(version){return errors.New("unsupported coturn version")}
 secret,err:=randomSecret();if err!=nil{return err};password,err:=randomSecret();if err!=nil{return err}
 template,err:=os.ReadFile("/etc/notitle/turnserver.conf");if err!=nil{return err}
 text:=strings.NewReplacer("{{HOSTNAME}}",host,"{{PUBLIC_IP}}",public.String(),"{{RELAY_IP}}",local.String(),"{{AUTH_SECRET}}",secret,"{{CLI_PASSWORD}}",password).Replace(string(template))
 if strings.Contains(text,"{{"){return errors.New("unresolved relay config")}
 config:=filepath.Join("/run/notitle","turnserver.conf");if err=os.WriteFile(config,[]byte(text),0600);err!=nil{return err};defer os.Remove(config)
 child:=exec.Command(binary,"-c",config);child.Stdout=io.Discard;child.Stderr=io.Discard;child.SysProcAttr=&syscall.SysProcAttr{Pdeathsig:syscall.SIGKILL}
 if err=child.Start();err!=nil{return err};defer child.Process.Kill()
 childDone:=make(chan error,1);go func(){childDone<-child.Wait()}()
 read,write,err:=os.Pipe();if err!=nil{return err};defer write.Close()
 executable,err:=os.Executable();if err!=nil{return err};watch:=exec.Command(executable,"watchdog",strconv.Itoa(os.Getpid()),strconv.Itoa(child.Process.Pid));watch.ExtraFiles=[]*os.File{read};watch.SysProcAttr=&syscall.SysProcAttr{Pdeathsig:syscall.SIGKILL};watch.Stdout=io.Discard;watch.Stderr=io.Discard
 if err=watch.Start();err!=nil{read.Close();return err};read.Close();defer watch.Process.Kill();watchDone:=make(chan error,1);go func(){watchDone<-watch.Wait()}()
 // The secret's ASCII form must match the exact bytes coturn reads from config.
 controller,err:=relay.New(relay.Options{Admin:relay.CLI{Password:password},Secret:[]byte(secret),URLs:[]string{"turn:"+host+":3478?transport=udp","turn:"+host+":3478?transport=tcp","turns:"+host+":443?transport=tcp"},RelayAddresses:[]string{public.String()},Stop:func(){_ =child.Process.Kill()}});if err!=nil{return err}
 server:=&http.Server{Addr:control,Handler:relay.Handler(controller,token),ReadHeaderTimeout:time.Second,ReadTimeout:3*time.Second,WriteTimeout:3*time.Second,IdleTimeout:15*time.Second,MaxHeaderBytes:4096,ErrorLog:discardLog()}
 if !allowHTTP{
  ca,err:=os.ReadFile(env("RELAY_CONTROL_CA_FILE","/run/secrets/control-ca.pem"));if err!=nil{return err};pool:=x509.NewCertPool();if !pool.AppendCertsFromPEM(ca){return errors.New("invalid control CA")}
  server.TLSConfig=&tls.Config{MinVersion:tls.VersionTLS13,ClientAuth:tls.RequireAndVerifyClientCert,ClientCAs:pool}
 }
 // Wait for a real CLI probe before starting the control listener. Startup has
 // a bounded2s window; subsequent administrative failures kill the relay.
 cli:=relay.CLI{Password:password};startup:=time.Now().Add(2*time.Second)
 for{probe,stop:=context.WithTimeout(context.Background(),250*time.Millisecond);_,err=cli.Sessions(probe);stop();if err==nil{break};if time.Now().After(startup){return errors.New("relay CLI unavailable")};_,_=write.Write([]byte{1});time.Sleep(50*time.Millisecond)}
 if err=controller.Tick(context.Background());err!=nil{return err};_,_=write.Write([]byte{1})
 serverDone:=make(chan error,1);go func(){if allowHTTP{serverDone<-server.ListenAndServe()}else{serverDone<-server.ListenAndServeTLS(env("RELAY_CONTROL_CERT_FILE","/run/secrets/control-cert.pem"),env("RELAY_CONTROL_KEY_FILE","/run/secrets/control-key.pem"))}}();defer server.Close()
 ctx,stop:=signal.NotifyContext(context.Background(),syscall.SIGINT,syscall.SIGTERM);defer stop();ticker:=time.NewTicker(time.Second);defer ticker.Stop()
 for{select{
 case<-ctx.Done():return nil
 case<-childDone:return errors.New("relay exited")
 case<-watchDone:return errors.New("watchdog exited")
 case<-serverDone:return errors.New("control listener exited")
 case<-ticker.C:
  scan,done:=context.WithTimeout(ctx,1500*time.Millisecond);err=controller.Tick(scan);done();if err!=nil{return err};if _,err=write.Write([]byte{1});err!=nil{return err}
 }}
}
