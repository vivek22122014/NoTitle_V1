package main

import("io";"log")
func discardLog()*log.Logger{return log.New(io.Discard,"",0)}
