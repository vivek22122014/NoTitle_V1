//go:build !linux

package main

import("fmt";"os")
func main(){fmt.Fprintln(os.Stderr,"relay supervisor requires Linux container PID1");os.Exit(1)}
