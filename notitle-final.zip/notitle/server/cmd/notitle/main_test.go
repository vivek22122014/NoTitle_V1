package main

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestHealthcheckOnlyAcceptsReadyJSON(t *testing.T) {
	tests := []struct {
		status int
		body string
		wantError bool
	}{
		{200, `{"status":"ok"}`, false},
		{503, `{"status":"not_ready"}`, true},
		{200, `{"status":"not_ready"}`, true},
		{200, `not json`, true},
		{302, `{"status":"ok"}`, true},
	}
	for _, test := range tests {
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if r.URL.Path != "/health/ready" {
				t.Error("probe requested wrong endpoint")
			}
			w.WriteHeader(test.status)
			_, _ = w.Write([]byte(test.body))
		}))
		err := healthcheck(context.Background(), strings.TrimPrefix(server.URL, "http://"))
		server.Close()
		if (err != nil) != test.wantError {
			t.Fatalf("status %d body %s: got %v", test.status, test.body, err)
		}
	}
}
