package main

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log"
	"log/slog"
	"net"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"notitle/internal/admin"
 "notitle/internal/admission"
	"notitle/internal/audio"
 "notitle/internal/billing"
 "notitle/internal/cashfree"
 "notitle/internal/payments"
	"notitle/internal/config"
	"notitle/internal/coordinator"
	"notitle/internal/database"
	"notitle/internal/deletionlog"
	"notitle/internal/friends"
	"notitle/internal/health"
	"notitle/internal/httpserver"
	appmw "notitle/internal/httpserver/middleware"
	"notitle/internal/identity"
	"notitle/internal/identityhttp"
	"notitle/internal/identitypg"
	"notitle/internal/identityruntime"
	"notitle/internal/matchingauth"
	"notitle/internal/platform/clock"
	"notitle/internal/realtimehttp"
	"notitle/internal/realtimeruntime"
	"notitle/internal/safety"
 "notitle/internal/holdlog"
 "notitle/internal/operations"
 "notitle/internal/operationshttp"
 "notitle/internal/observability"
 "notitle/internal/privacy"
)

var (
	version = "dev"
	commit = "unknown"
	buildTime = "unknown"
 sourceSHA256 = "unknown"
)

func main() {
	// The probe does not load database secrets or start a second server.
	if len(os.Args) == 2 && os.Args[1] == "healthcheck" {
		addr := strings.TrimSpace(os.Getenv("HTTP_ADDR"))
		if addr == "" {
			addr = ":8080"
		}
		if err := healthcheck(context.Background(), addr); err != nil {
			os.Exit(1)
		}
		return
	}
	if len(os.Args) != 1 {
		os.Exit(2)
	}
	// JSON from the first log, including configuration failures.
	slog.SetDefault(newLogger("info", "notitle-api", "startup"))
	if err := run(); err != nil {
		// Only our fixed errors or validated field names reach this boundary.
		slog.Error("service_stopped", "reason", err.Error())
		os.Exit(1)
	}
}

func run() error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	logger := newLogger(cfg.LogLevel, cfg.ServiceName, string(cfg.Environment))
	slog.SetDefault(logger)
	signalCtx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()
	serviceCtx, cancelService := context.WithCancel(context.Background())
	defer cancelService()
	db, err := database.Open(serviceCtx, cfg.Database)
	if err != nil {
		return err
	}
	defer db.Close()
	owner := coordinator.New(clock.System{})
 if cfg.Admission.Maintenance {owner.StartInMaintenance()}
 var admissionChecks []health.Checker
 validationExpiry:=time.Time{}
 admissionGate:=admission.New(admission.Options{Owner:owner,Closed:cfg.Admission.Maintenance,
  Ready:func(ctx context.Context)error{if len(admissionChecks)==0{return admission.ErrUnavailable};for _,check:=range admissionChecks{if err:=check.Ready(ctx);err!=nil{return err}};return nil},
  Approval:func(ctx context.Context,evidence string)error{
   if cfg.Environment!=config.EnvironmentProduction&&cfg.Admission.ApprovalFile==""{if !admission.ValidEvidenceRef(evidence){return admission.ErrInvalid};return nil}
   limits:=coordinator.LaunchLimits()
   permit,err:=admission.LoadApproval(ctx,cfg.Admission.ApprovalFile,admission.Release{SourceSHA256:sourceSHA256,APIImage:cfg.Admission.APIImage,Origin:cfg.PublicOrigin,Schema:9,Stage:cfg.Admission.Stage,DeploymentManifestSHA256:cfg.Admission.ManifestSHA256,Limits:admission.Limits{Connected:limits.Connected,Waiting:limits.Waiting,Calls:limits.AudioCalls}},evidence,time.Now().UTC())
   if err!=nil{return err};validationExpiry=time.Time{};if permit.Purpose=="validation"{validationExpiry=permit.ExpiresAt};return nil
  },
  ValidationExpiry:func()time.Time{return validationExpiry},
 })
 clockGuard:=payments.NewClockGuard()
 trustedClock:=func(ctx context.Context)error{
  if err:=clockGuard.Ready(ctx);err!=nil{return err}
  if cfg.Operations.Enabled&&cfg.Operations.ObservationFile!=""{observation,err:=observability.ReadObservation(cfg.Operations.ObservationFile,time.Now().UTC());if err!=nil||observation.ClockOffsetMS>2000||observation.ClockOffsetMS< -2000{return errors.New("host clock observation unavailable")}}
  return nil
 }
 // Financial obligations continue even while realtime admission is disabled.
 owner.EnablePremium()
	if cfg.Safety.Enabled { owner.EnableSafety() }
	if cfg.Friends.Enabled { owner.EnableFriends(cfg.Friends.MaxPerIdentity) }
	if cfg.Audio.Enabled { owner.EnableAudio(cfg.Audio.RelayAddresses) }
	var identityHandler *identityhttp.Handler
	var identityLifecycle *identityruntime.Runtime
	var realtimeHandler *realtimehttp.Handler
	var realtimeLifecycle *realtimeruntime.Runtime
	var safetyService *safety.Service
	var friendsService *friends.Service
	var audioService *audio.Service
 var paymentService *payments.Service
 var paymentWorker *billing.Worker
 var paymentWebhook http.Handler
 var preferenceStore *matchingauth.Service
	var adminServer *http.Server
 var adminHandler *admin.Handler
 var operationsHandler *operationshttp.Handler
 var caseService *operations.Service
 var caseStore *operations.PostgresStore
 var caseAlertWorker *operations.AlertWorker
 var privacyStore *privacy.Store
 var monitor *observability.Service
	if cfg.Identity.Enabled {
  if cfg.Environment.Deployed(){if err:=existingJournalDirectory(cfg.Identity.TombstoneDirectory);err!=nil{return err}}
		journal, err := deletionlog.Open(cfg.Identity.TombstoneDirectory)
		if err != nil { return errors.New("deletion journal initialization failed") }
		defer journal.Close()
		store := identitypg.New(db.Raw())
		// Public and private authentication share the same two-job memory bound.
		hasher := identity.NewArgon2Hasher()
		service, err := identity.New(identity.Options{
			Clock: clock.System{}, Store: store, Guests: owner, Journal: journal,
			Hasher: hasher,
			Policies: identity.PolicyVersions{Terms:cfg.Identity.TermsVersion, Privacy:cfg.Identity.PrivacyVersion, Community:cfg.Identity.CommunityVersion},
		})
		if err != nil { return errors.New("identity initialization failed") }
		identityLifecycle = identityruntime.New(db, journal, store, service, logger)
		identityBaseReady := func(ctx context.Context) error {
			if err := identityLifecycle.Ready(ctx); err != nil { return err }
   if err:=trustedClock(ctx);err!=nil{return err}
			return db.Ready(ctx)
		}
  identityReady:=func(ctx context.Context)error{if err:=identityBaseReady(ctx);err!=nil{return err};if privacyStore!=nil{return privacyStore.Ready(ctx)};return nil}
  // Anonymous support remains available during identity recovery and receiver
  // outages. New submissions enforce their reviewed policy in the transaction.
  supportReady:=func(ctx context.Context)error{if err:=clockGuard.Ready(ctx);err!=nil{return err};return db.Ready(ctx)}
  if cfg.Operations.Enabled {
   caseKeys,keyErr:=safety.LoadKeyring(cfg.Operations.KeyringFile);if keyErr!=nil{return errors.New("support encryption initialization failed")}
   policy,policyErr:=privacy.LoadPolicyFile(cfg.Operations.PolicyFile,cfg.Environment.Deployed(),time.Now().UTC());if policyErr!=nil{return errors.New("retention policy initialization failed")}
   if cfg.Environment.Deployed(){if err:=existingJournalDirectory(cfg.Operations.HoldJournalDirectory);err!=nil{return err}}
   holdJournal,journalErr:=holdlog.Open(cfg.Operations.HoldJournalDirectory);if journalErr!=nil{return errors.New("hold journal initialization failed")};defer holdJournal.Close()
   privacyStore=privacy.NewStore(db.Raw(),privacy.Options{Policy:policy,Journal:holdJournal,Ready:identityBaseReady,RecoveryPoint:recoveryPoint(cfg.Operations.ObservationFile,false),DeletionRecoveryPoint:recoveryPoint(cfg.Operations.ObservationFile,true)})
   caseRule,_:=policy.Rule("cases")
   caseStore=operations.NewPostgresStore(db.Raw(),operations.StoreOptions{Cipher:caseKeys,AllowDraftPolicies:!cfg.Environment.Deployed(),RetentionDays:caseRule.MaximumDays,RetentionPolicyVersion:policy.Version})
   caseService=operations.New(operations.Options{Store:caseStore,Ready:supportReady})
   var receiver observability.Receiver
   if cfg.Operations.PrimaryURL!=""||cfg.Operations.BackupURL!="" {
    primary,backup:="","";var tokenErr error
    if cfg.Operations.PrimaryTokenFile!=""{primary,tokenErr=payments.ReadSecretFile(cfg.Operations.PrimaryTokenFile);if tokenErr!=nil{return errors.New("primary operator credential initialization failed")}}
    if cfg.Operations.BackupTokenFile!=""{backup,tokenErr=payments.ReadSecretFile(cfg.Operations.BackupTokenFile);if tokenErr!=nil{return errors.New("backup operator credential initialization failed")}}
    primaryBytes,backupBytes:=[]byte(primary),[]byte(backup)
    receiver,err=observability.NewReceiver(observability.ReceiverConfig{PrimaryURL:cfg.Operations.PrimaryURL,BackupURL:cfg.Operations.BackupURL,PrimaryToken:primaryBytes,BackupToken:backupBytes});clear(primaryBytes);clear(backupBytes)
    if err!=nil{return errors.New("operator receiver initialization failed")}
   }
   caseAlertWorker=&operations.AlertWorker{Store:caseStore,Receiver:receiver}
   monitor=observability.New(observability.Options{Pool:db.Raw(),Coordinator:owner,ClockReady:trustedClock,Counts:observability.NewPostgresCounts(db.Raw()),ObservationFile:cfg.Operations.ObservationFile,Receiver:receiver,RetentionVersion:policy.Version,Retention:func(purpose string,now time.Time)(int,bool){rule,ok:=policy.Rule(purpose);return rule.MaximumDays,ok&&policy.Approved&&policy.Validate(true,now)==nil},CoverageApproved:cfg.Operations.CoverageApproved,RelayEnabled:cfg.Audio.Enabled,Environment:cfg.Payments.Environment,LifecycleReady:identityReady})
  }
  supportOptions:=operationshttp.Options{Identity:service,Ready:supportReady,IdentityReady:identityReady,PublicOrigin:cfg.PublicOrigin,AllowInsecureLocalhost:!cfg.Environment.Deployed()};if caseService!=nil{supportOptions.Cases=caseService;supportOptions.IntakeReady=func(ctx context.Context)error{return caseStore.Ready(ctx,time.Now().UTC())}};if privacyStore!=nil{supportOptions.Privacy=privacyStore}
  operationsHandler,err=operationshttp.New(supportOptions)
  if err!=nil{return errors.New("support transport initialization failed")}

        ledgerStore:=billing.NewPostgresStore(db.Raw(),billing.Options{Environment:billing.Environment(cfg.Payments.Environment),MerchantID:cfg.Payments.MerchantID,Mutations:payments.Fence{Owner:owner}})
        paymentOptions:=payments.Options{Store:ledgerStore,Ready:identityReady,AdmissionClosed:admissionGate.Closed,CheckoutEnabled:cfg.Payments.CheckoutEnabled,AnnualApproved:cfg.Payments.AnnualApproved,Environment:billing.Environment(cfg.Payments.Environment),MerchantID:cfg.Payments.MerchantID}
        if cfg.Payments.Enabled {
            clientID,keyErr:=payments.ReadSecretFile(cfg.Payments.ClientIDFile);if keyErr!=nil{return errors.New("payment credential initialization failed")}
            secret,keyErr:=payments.ReadSecretFile(cfg.Payments.ClientSecretFile);if keyErr!=nil{return errors.New("payment credential initialization failed")}
            previous:="";if cfg.Payments.PreviousSecretFile!=""{previous,keyErr=payments.ReadSecretFile(cfg.Payments.PreviousSecretFile);if keyErr!=nil{return errors.New("payment previous-key initialization failed")}}
            client,providerErr:=cashfree.New(cashfree.Options{Environment:cfg.Payments.Environment,ClientID:clientID,ClientSecret:secret,MerchantID:cfg.Payments.MerchantID,PublicOrigin:cfg.PublicOrigin});if providerErr!=nil{return errors.New("payment provider initialization failed")}
            verifier,verifyErr:=cashfree.NewWebhookVerifier(cashfree.WebhookOptions{Environment:cfg.Payments.Environment,MerchantID:cfg.Payments.MerchantID,Secret:secret,PreviousSecret:previous,PreviousUntil:cfg.Payments.PreviousSecretUntil});if verifyErr!=nil{return errors.New("payment webhook initialization failed")}
            paymentWorker,err=billing.NewWorker(billing.WorkerOptions{Store:ledgerStore,Provider:client,Ready:identityReady});if err!=nil{return errors.New("payment worker initialization failed")}
            paymentOptions.Provider=client;paymentOptions.Verifier=paymentWorker
            paymentWebhook=payments.Webhook(ledgerStore,verifier,func(ctx context.Context)error{if err:=trustedClock(ctx);err!=nil{return err};return db.Ready(ctx)})
        }
        paymentService,err=payments.New(paymentOptions);if err!=nil{return errors.New("payment service initialization failed")}
		if cfg.Audio.Enabled {
			token,tokenErr:=audio.LoadControlTokenFile(cfg.Audio.ControlTokenFile)
			if tokenErr!=nil{return errors.New("audio control credential initialization failed")}
			controller,controlErr:=audio.NewHTTPController(audio.HTTPOptions{URL:cfg.Audio.ControlURL,Token:token,CAFile:cfg.Audio.CAFile,ClientCertFile:cfg.Audio.ClientCertFile,ClientKeyFile:cfg.Audio.ClientKeyFile,AllowLoopbackHTTP:cfg.Audio.AllowLoopbackHTTP})
			if controlErr!=nil{return errors.New("audio relay controller initialization failed")}
			audioService,err=audio.New(audio.Options{Owner:owner,Controller:controller,Ready:identityReady})
			if err!=nil{return errors.New("audio service initialization failed")}
		}
		if cfg.Friends.Enabled {
			friendsService, err = friends.New(friends.Options{Identity:service, Owner:owner, Store:friends.NewPostgresStore(db.Raw(),cfg.Friends.MaxPerIdentity), Ready:identityReady, MaxPerIdentity:cfg.Friends.MaxPerIdentity})
			if err!=nil {return errors.New("friends initialization failed")}
		}
		if cfg.Safety.Enabled {
			keyring, keyErr := safety.LoadKeyring(cfg.Safety.EvidenceKeyringFile)
			if keyErr != nil { return errors.New("evidence key initialization failed") }
			safetyOptions:=safety.Options{Identity: service, Owner: owner, Store: safety.NewPostgresStore(db.Raw()), Cipher: keyring, Retention: cfg.Safety.Retention, RetentionPolicyVersion: cfg.Safety.RetentionPolicyVersion, Ready: identityReady}
			if friendsService!=nil {safetyOptions.Friends=friendsService}
			safetyService, err = safety.New(safetyOptions)
			if err != nil { return errors.New("safety initialization failed") }
		}
		if cfg.Admin.Enabled {
			key, keyErr := admin.ReadKey(cfg.Admin.KeyFile)
			if keyErr != nil { return errors.New("admin key initialization failed") }
			var adminErr error
   adminOptions:=admin.Options{Admission:admissionGate,Metrics:owner,Pool: db.Raw(), Backend: safetyService, Billing:ledgerStore, Hasher: hasher, Key: key, Origin: cfg.Admin.Origin, AllowInsecureLocalhost: !cfg.Environment.Deployed()};if caseService!=nil{adminOptions.Operations=caseService};if privacyStore!=nil{adminOptions.Privacy=privacyStore};if monitor!=nil{adminOptions.Observability=monitor}
   adminHandler, adminErr = admin.New(adminOptions)
			clear(key)
			if adminErr != nil { return errors.New("admin initialization failed") }
			// This listener is private infrastructure. Public routing never mounts it.
			adminServer = &http.Server{Addr: cfg.Admin.Addr, Handler: appmw.RequestID(appmw.Recover(logger, adminHandler)), ReadHeaderTimeout: 5*time.Second, ReadTimeout: 10*time.Second, WriteTimeout: 15*time.Second, IdleTimeout: 30*time.Second, MaxHeaderBytes: 16<<10, ErrorLog: log.New(io.Discard, "", 0)}
			adminServer.BaseContext = func(net.Listener) context.Context { return serviceCtx }
		}
		if cfg.Realtime.Enabled {
			dependencies:=[]realtimeruntime.Checker{identityLifecycle,db,readyFunc(trustedClock)};if privacyStore!=nil{dependencies=append(dependencies,privacyStore)}
   realtimeLifecycle = realtimeruntime.New(owner, logger, dependencies...)
			matchingOptions := matchingauth.Options{
				Clock: clock.System{}, Identity: service, Store: matchingauth.NewPostgresStore(db.Raw()),
				Actor: owner, Ready: identityReady, Entitlements:paymentService, TextEnabled: cfg.Safety.Enabled, FriendsEnabled:cfg.Friends.Enabled, AudioEnabled:cfg.Audio.Enabled,
			}
			if friendsService!=nil {matchingOptions.Friends=friendsService}
			// Durable safety cannot be bypassed by disabling the text/report UI.
			matchingOptions.Safety = safety.NewAuthorizationSource(db.Raw())
			preferenceStore, err = matchingauth.New(matchingOptions)
			if err != nil { return errors.New("matching authorization initialization failed") }
			realtimeHandler, err = realtimehttp.New(realtimehttp.Options{
				PublicOrigin: cfg.PublicOrigin, AllowInsecureLocalhost: !cfg.Environment.Deployed(),
				Identity: service, Authorizer: preferenceStore, Actor: owner, Ready: realtimeLifecycle.Ready,
			})
			if err != nil { return errors.New("realtime transport initialization failed") }
		}
		identityOptions := identityhttp.Options{
			Service: service, Billing:paymentService, PublicOrigin: cfg.PublicOrigin,
			AllowInsecureLocalhost: !cfg.Environment.Deployed(), Ready: identityReady,
		}
		if realtimeHandler != nil {
			identityOptions.Realtime = realtimeHandler
			identityOptions.Preferences = preferenceStore
		}
		if safetyService != nil { identityOptions.Safety = safetyService }
		if friendsService != nil { identityOptions.Friends = friendsService }
		identityHandler, err = identityhttp.New(identityOptions)
		if err != nil { return errors.New("identity transport initialization failed") }
	}
 if operationsHandler==nil{operationsHandler,err=operationshttp.New(operationshttp.Options{PublicOrigin:cfg.PublicOrigin,AllowInsecureLocalhost:!cfg.Environment.Deployed()});if err!=nil{return errors.New("support transport initialization failed")}}
	ownerErr := make(chan error, 1)
	go func() { ownerErr <- owner.Run(serviceCtx) }()
 admissionDone:=make(chan struct{});go func(){defer close(admissionDone);admissionGate.Run(serviceCtx)}()
	checks := []health.Checker{owner, db, readyFunc(trustedClock)}
 privacyDone:=make(chan struct{});if privacyStore!=nil{checks=append(checks,privacyStore);go func(){defer close(privacyDone);runPrivacy(serviceCtx,privacyStore,logger)}()}else{close(privacyDone)}
 caseAlertsDone:=make(chan struct{});if caseAlertWorker!=nil{go func(){defer close(caseAlertsDone);caseAlertWorker.Run(serviceCtx)}()}else{close(caseAlertsDone)}
 monitorDone:=make(chan struct{});if monitor!=nil{checks=append(checks,monitor);go func(){defer close(monitorDone);monitor.Run(serviceCtx)}()}else{close(monitorDone)}
 if caseStore!=nil{checks=append(checks,readyFunc(func(ctx context.Context)error{return caseStore.Ready(ctx,time.Now().UTC())}))}
 exportsDone:=make(chan struct{});if adminHandler!=nil{go func(){defer close(exportsDone);adminHandler.RunExportCleanup(serviceCtx)}()}else{close(exportsDone)}
 clockDone:=make(chan struct{});go func(){defer close(clockDone);clockGuard.Run(serviceCtx)}()
 paymentDone:=make(chan struct{});if paymentService!=nil{go func(){defer close(paymentDone);paymentService.Run(serviceCtx)}()}else{close(paymentDone)}
 paymentWorkerDone:=make(chan struct{});if paymentWorker!=nil{go func(){defer close(paymentWorkerDone);paymentWorker.Run(serviceCtx)}()}else{close(paymentWorkerDone)}
 premiumUsageDone:=make(chan struct{});if preferenceStore!=nil{go func(){defer close(premiumUsageDone);_ =preferenceStore.RunPremiumUsage(serviceCtx)}()}else{close(premiumUsageDone)}
	identityDone := make(chan struct{})
	if identityLifecycle != nil {
		checks = append(checks, identityLifecycle)
		go func() { defer close(identityDone); identityLifecycle.Run(serviceCtx) }()
	} else { close(identityDone) }
	realtimeDone := make(chan struct{})
	if realtimeLifecycle != nil {
		checks = append(checks, realtimeLifecycle)
		go func() { defer close(realtimeDone); realtimeLifecycle.Run(serviceCtx) }()
	} else { close(realtimeDone) }
	safetyDone := make(chan struct{})
	if safetyService != nil {
		go func() { defer close(safetyDone); safetyService.Run(serviceCtx) }()
	} else { close(safetyDone) }
	friendsDone:=make(chan struct{})
	if friendsService!=nil {
		go func(){defer close(friendsDone);friendsService.Run(serviceCtx)}()
	} else {close(friendsDone)}
	audioDone:=make(chan struct{})
	if audioService!=nil {
		go func(){defer close(audioDone);audioService.Run(serviceCtx)}()
	} else {close(audioDone)}
	healthHandler := health.New(cfg.Database.ReadinessTimeout, checks...)
 admissionChecks=append([]health.Checker(nil),checks...)
 healthHandler = health.New(cfg.Database.ReadinessTimeout,append(checks,admissionGate)...)
	dependencies := httpserver.Dependencies{Processing:owner.ProcessingRecorder(),Logger: logger, Health: healthHandler, Identity: identityHandler, PaymentsWebhook:paymentWebhook}
 if operationsHandler!=nil{dependencies.Operations=operationsHandler}
	if realtimeHandler != nil { dependencies.Realtime = realtimeHandler }
	server := httpserver.New(cfg.HTTP, dependencies)
	server.BaseContext = func(net.Listener) context.Context { return serviceCtx }
	serverErr := make(chan error, 1)
	go func() {
		logger.Info("http_server_starting")
		serverErr <- server.ListenAndServe()
	}()
	var adminErr <-chan error
	if adminServer != nil {
		ch := make(chan error, 1)
		adminErr = ch
		go func() { logger.Info("private_admin_server_starting"); ch <- adminServer.ListenAndServe() }()
	}
	var result error
	select {
	case <-signalCtx.Done():
		logger.Info("shutdown_started")
	case <-serverErr:
		result = errors.New("HTTP server stopped unexpectedly")
	case <-adminErr:
		result = errors.New("private admin server stopped unexpectedly")
	case <-ownerErr:
		result = errors.New("coordinator stopped unexpectedly")
	}
	// Stop readiness immediately, drain HTTP while dependencies are available,
	// then cancel request contexts/owner before closing PostgreSQL.
	healthHandler.BeginShutdown()
	shutdownCtx, cancelShutdown := context.WithTimeout(context.Background(), cfg.HTTP.ShutdownTimeout)
	defer cancelShutdown()
	if adminServer != nil {
		if err := adminServer.Shutdown(shutdownCtx); err != nil {
			result = errors.New("private admin shutdown deadline exceeded")
			_ = adminServer.Close()
		}
	}
	// Hijacked WebSockets are not drained by http.Server.Shutdown. Stop their
	// admission and close/wait for the transport explicitly while the actor lives.
	if realtimeHandler != nil {
		if err := realtimeHandler.Close(shutdownCtx); err != nil { result = errors.New("realtime shutdown deadline exceeded") }
	}
	if audioService!=nil {
		audioShutdown,cancelAudio:=context.WithTimeout(shutdownCtx,5*time.Second)
		if err:=audioService.Shutdown(audioShutdown);err!=nil {result=errors.New("audio relay shutdown remains protected by lease expiry")}
		cancelAudio()
	}
	if err := server.Shutdown(shutdownCtx); err != nil {
		result = errors.New("HTTP graceful shutdown deadline exceeded")
		cancelService()
		_ = server.Close()
	}
	cancelService()
	<-owner.Done()
	<-identityDone
	<-realtimeDone
	<-safetyDone
	<-friendsDone
	<-audioDone
 <-clockDone
 <-paymentDone
 <-paymentWorkerDone
 <-premiumUsageDone
 <-privacyDone
 <-monitorDone
 <-caseAlertsDone
 <-exportsDone
 <-admissionDone
	logger.Info("http_server_stopped")
	return result
}

type readyFunc func(context.Context)error
func(f readyFunc)Ready(ctx context.Context)error{return f(ctx)}
func existingJournalDirectory(path string)error{info,err:=os.Lstat(path);if err!=nil||!info.IsDir()||info.Mode()&os.ModeSymlink!=0{return errors.New("prepared independent journal directory unavailable")};return nil}
// Replay is retried without opening identity admission. The worker separately
// waits for the deletion journal; neither readiness function calls the other.
func runPrivacy(ctx context.Context,store *privacy.Store,logger *slog.Logger){
 for{work,cancel:=context.WithTimeout(ctx,30*time.Second);err:=store.Replay(work);cancel();if err==nil{break};logger.Warn("privacy_recovery_unavailable");timer:=time.NewTimer(5*time.Second);select{case<-ctx.Done():timer.Stop();return;case<-timer.C:}}
 _ = store.Run(ctx)
}

func healthcheck(ctx context.Context, addr string) error {
	if err := config.ValidateHTTPAddr(addr); err != nil {
		return err
	}
	host, port, _ := net.SplitHostPort(addr)
	if host == "" || host == "0.0.0.0" {
		host = "127.0.0.1"
	}
	if host == "::" {
		host = "::1"
	}
	ctx, cancel := context.WithTimeout(ctx, 2*time.Second)
	defer cancel()
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, "http://"+net.JoinHostPort(host, port)+"/health/ready", nil)
	if err != nil {
		return errors.New("health probe failed")
	}
	client := &http.Client{
		Timeout: 2*time.Second,
		Transport: &http.Transport{Proxy: nil, DisableKeepAlives: true},
		CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse },
	}
	defer client.CloseIdleConnections()
	response, err := client.Do(request)
	if err != nil {
		return errors.New("health probe failed")
	}
	defer response.Body.Close()
	var body struct { Status string `json:"status"` }
	if response.StatusCode != http.StatusOK || json.NewDecoder(io.LimitReader(response.Body, 1024)).Decode(&body) != nil || body.Status != "ok" {
		return errors.New("service is not ready")
	}
	return nil
}

func newLogger(level, service, environment string) *slog.Logger {
	var severity slog.Level
	switch level {
	case "debug":
		severity = slog.LevelDebug
	case "warn":
		severity = slog.LevelWarn
	case "error":
		severity = slog.LevelError
	default:
		severity = slog.LevelInfo
	}
	return slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: severity})).With("service", service, "environment", environment)
}

// These timestamps describe remotely recoverable journal bytes, supplied by an
// approved host collector after verifying the off-host object. A local append
// or successful upload command alone is not acceptable recovery evidence.
func recoveryPoint(path string,deletion bool)func(context.Context)(time.Time,error){return func(ctx context.Context)(time.Time,error){
 if err:=ctx.Err();err!=nil{return time.Time{},err};now:=time.Now().UTC();v,err:=observability.ReadObservation(path,now);if err!=nil{return time.Time{},err};point:=v.HoldJournalRecoverableAt;if deletion{point=v.DeletionJournalRecoverableAt};if point.IsZero()||point.After(now)||now.Sub(point)>15*time.Minute{return time.Time{},errors.New("journal recovery point unavailable")};return point,nil
}}
