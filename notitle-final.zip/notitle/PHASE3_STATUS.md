# Phase 3 delivery status

Date: 9 October 2026. Baseline: NoTitle V3.2, Phase 3 “Guest accounts profiles and deletion foundation.” This cumulative package contains Phases 1–3 source. Phase 3 is implemented in source; production acceptance is not established.

## Implemented

- Required explicit Male/Female/Other, 18+ confirmation and versioned policy consent, without phone or email.
- Memory-only guest identities, authorized-activity expiry, bounded actor mailboxes/session/slot/reservation maps and safe guest-to-account handoff.
- Private usernames, Argon2id passwords, random cookie secrets and stored verifiers, saved-code recovery, code/password rotation, recent authentication and logout-all.
- Controlled topic/profession/industry/experience/interests, General Talk default and versioned partial profile edits. Explicit owner/peer DTOs exclude private peer fields.
- PostgreSQL migration 2 and transaction guards for account status, session expiry/revocation, identity generation and profile version. Restricted runtime grants and mandatory integration-test configuration.
- Exact-origin/CSRF-protected account routes, strict bounded JSON, anonymous bootstrap, secure cookie attributes, bounded pre-hash rate limits and finite log labels.
- Immediate deletion disablement and session revocation, opaque status receipt, initial retention-review job, separate atomic/fsynced tombstone journal, bounded retry and startup restore replay barrier.
- Mobile-first API-driven guest/account/profile/settings forms, once-only recovery display and truthful pending/deletion status. Conversation/audio/friends/payments remain unavailable.
- Updated deployment volumes/memory budget, configuration/schema, OpenAPI, acceptance, threat/retention documentation and real-stack identity smoke script.

## Checks actually executed in this workspace

| Check | Result | What it establishes |
| --- | --- | --- |
| `./scripts/phase3-source-check.sh` | 45 tests passed | API client, identity client/model, design-state, SEO/release and static-serving contract checks; source credential-pattern/direct-version audit |
| JSON/YAML parsing | Passed: 6 JSON, 8 YAML | Syntax/readability, not container deployment |
| `bash -n` | Passed: 17 scripts | Shell syntax, not runtime execution |
| Native Node TypeScript/script parsing | Passed: 54 script blocks/files | Syntax only; not Svelte markup compilation or TypeScript type checking |
| `node --check scripts/smoke-identity.mjs` | Passed | Smoke script JavaScript syntax; its real network/database flow was not executed |
| `node scripts/audit.mjs --release` | Correctly blocked | `web/package-lock.json` and `server/go.sum` are missing; no checksums were invented |
| `./scripts/verify.sh` | Blocked at prerequisite | Go/Docker/PostgreSQL and frontend dependencies are unavailable here; Docker Compose is required |

Independent source review found and corrected guest-handoff rollback boolean inversion, profile read/version races, tombstone timestamp precision, unrelated identity cleanup during recovery, controlled interests, General Talk and username-rule inconsistencies. Review is not a substitute for runtime tests.

## Tests added but not executed

Go domain/crypto/service tests; real service/coordinator handoff integration; coordinator expiry, capacity, alias isolation and concurrency; HTTP CSRF/cookie/strict-JSON/rate limits; PostgreSQL account/session/version/recovery/deletion/concurrent-writer integration; journal filesystem/idempotency/failure/replay tests; readiness replay-gate tests; Playwright account/recovery/profile/settings/deletion/reflow tests; and a real Caddy–Go–PostgreSQL lifecycle smoke script.

## Required next acceptance steps

1. On Linux/WSL2 with Docker Compose v2.30+ and approved registry access, run `./scripts/bootstrap.sh prepare`. Generate genuine module/npm locks, run the pinned formatters and review resulting changes.
2. Run `./scripts/verify.sh`. Do not skip mandatory PostgreSQL tests, race/vet/build, Svelte/type/lint/browser, dependency scans, reversible migration checks or the real identity smoke flow.
3. Inspect Android Chrome and iOS Safari first, then desktop keyboard/screen reader and 320–1920 CSS px layouts. Measure Argon2 latency/RSS on the target VM.
4. Approve actual operator/policy/retention values. Establish off-host journal/database backup and restore continuity, disk-full handling and final purpose-specific erasure before launch. Existing draft public-release guards remain active.

Identity is enabled by default locally and disabled by default in staging/production. No public deployment, paid service, outgoing email, real checkout or migration of user production data was performed. A separate local journal volume is not off-host disaster recovery. The initial deletion job does not complete erasure.

The finalized minimum remains 200 connected participants including 25 simultaneous two-person audio calls. No capacity benchmark is claimed and no Phase 4 realtime implementation is included in this delivery.
